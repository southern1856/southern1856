import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
      },
    });
  }

  try {
    const body = await req.json();
    const { action } = body;

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // === CONVERSION TRACKING ===
    if (action === 'conversion') {
      const { tool_id, tool_name, conversion_type, session_id } = body;

      await supabase.from('tool_conversions').insert({
        session_id: session_id || null,
        tool_id: tool_id || null,
        tool_name: tool_name || null,
        conversion_type: conversion_type || 'inspection_booking',
        created_at: new Date().toISOString(),
      });

      return new Response(JSON.stringify({ success: true, tracked: 'conversion' }), {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
      });
    }

    // === TOOL USAGE TRACKING (default) ===
    const { tool_id, tool_name } = body;

    if (!tool_id || !tool_name) {
      return new Response(
        JSON.stringify({ error: 'Missing tool_id or tool_name' }),
        {
          status: 400,
          headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
          },
        }
      );
    }

    // Atomic increment via raw SQL to avoid race conditions
    const { error } = await supabase.rpc('increment_tool_usage', {
      p_tool_id: tool_id,
      p_tool_name: tool_name,
    });

    // Fallback if RPC doesn't exist yet
    if (error && error.message.includes('increment_tool_usage')) {
      const { data: existing } = await supabase
        .from('tool_usage_stats')
        .select('usage_count')
        .eq('tool_id', tool_id)
        .maybeSingle();

      if (existing) {
        await supabase
          .from('tool_usage_stats')
          .update({
            usage_count: existing.usage_count + 1,
            last_used_at: new Date().toISOString(),
          })
          .eq('tool_id', tool_id);
      } else {
        await supabase.from('tool_usage_stats').insert({
          tool_id,
          tool_name,
          usage_count: 1,
          last_used_at: new Date().toISOString(),
        });
      }
    } else if (error) {
      throw error;
    }

    // Log time-series event for analytics dashboard
    await supabase.from('tool_usage_events').insert({
      tool_id,
      tool_name,
      used_at: new Date().toISOString(),
    });

    return new Response(JSON.stringify({ success: true, tracked: 'usage' }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
    });
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : 'Unknown error' }),
      {
        status: 500,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
      }
    );
  }
});