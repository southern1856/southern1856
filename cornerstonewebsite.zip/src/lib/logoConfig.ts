export const LogoConfig = {
  ui: '/logo.svg',
  social: '/logo-social.svg',
} as const;

export const LogoUsage = {
  navbar: {
    logo: LogoConfig.ui,
    size: '48x48',
    description: 'Fast-loading SVG logo for navigation bar',
  },
  footer: {
    logo: LogoConfig.ui,
    size: '48x48',
    description: 'Fast-loading SVG logo for footer',
  },
  favicon: {
    logo: LogoConfig.ui,
    description: 'SVG favicon - crisp at small sizes',
  },
  socialSharing: {
    logo: LogoConfig.social,
    size: '1200x630',
    description: 'High-quality logo for og:image and social cards',
  },
  // To replace with your actual PNG logo:
  // 1. Save your logo PNG as public/logo-social.png (1200x630px recommended)
  // 2. Update LogoConfig.social to '/logo-social.png'
  // 3. Pages will automatically use the PNG for social sharing
} as const;
