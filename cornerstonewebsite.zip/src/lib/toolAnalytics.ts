import { supabase } from './supabase';

const SESSION_KEY = 'tool_attribution_session';
const LAST_TOOL_KEY = 'last_tool_used';
const ATTRIBUTION_WINDOW_MS = 30 * 60 * 1000; // 30 minutes

function getSessionId(): string {
  let session = localStorage.getItem(SESSION_KEY);
  if (!session) {
    session = crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    localStorage.setItem(SESSION_KEY, session);
  }
  return session;
}

/**
 * Fire-and-forget tool usage tracking.
 * Also records the last tool used in localStorage for attribution.
 * Silently fails so analytics never break the user experience.
 */
export async function trackToolUsage(toolId: string, toolName: string) {
  try {
    // Record in localStorage for conversion attribution
    localStorage.setItem(LAST_TOOL_KEY, JSON.stringify({
      tool_id: toolId,
      tool_name: toolName,
      used_at: Date.now(),
      session_id: getSessionId(),
    }));

    await supabase.functions.invoke('track-tool-usage', {
      body: { tool_id: toolId, tool_name: toolName },
    });
  } catch {
    // Analytics should be invisible to the user
  }
}

/**
 * Track a conversion event with tool attribution.
 * Checks if a tool was used within the attribution window and attributes the conversion.
 */
export async function trackConversion(conversionType: 'inspection_booking' | 'contact_form' | 'quote_request' | 'financing_application' = 'inspection_booking') {
  try {
    const raw = localStorage.getItem(LAST_TOOL_KEY);
    if (!raw) {
      // No tool attribution - still track as organic conversion
      await supabase.functions.invoke('track-tool-usage', {
        body: { action: 'conversion', conversion_type: conversionType, session_id: getSessionId() },
      });
      return;
    }

    const lastTool = JSON.parse(raw);
    const elapsed = Date.now() - (lastTool.used_at || 0);

    // Only attribute if within the attribution window
    if (elapsed <= ATTRIBUTION_WINDOW_MS && lastTool.tool_id) {
      await supabase.functions.invoke('track-tool-usage', {
        body: {
          action: 'conversion',
          tool_id: lastTool.tool_id,
          tool_name: lastTool.tool_name,
          conversion_type: conversionType,
          session_id: lastTool.session_id || getSessionId(),
        },
      });
    } else {
      // Attribution window expired - track as organic
      await supabase.functions.invoke('track-tool-usage', {
        body: { action: 'conversion', conversion_type: conversionType, session_id: getSessionId() },
      });
    }
  } catch {
    // Analytics should be invisible to the user
  }
}

/**
 * Get the last used tool info from localStorage (for UI context)
 */
export function getLastToolUsed() {
  try {
    const raw = localStorage.getItem(LAST_TOOL_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    const elapsed = Date.now() - (parsed.used_at || 0);
    if (elapsed > ATTRIBUTION_WINDOW_MS) return null;
    return parsed;
  } catch {
    return null;
  }
}

/**
 * Clear the attribution state (e.g., after a conversion is complete)
 */
export function clearToolAttribution() {
  localStorage.removeItem(LAST_TOOL_KEY);
}