export const WEB3FORMS_ACCESS_KEY = 'b42c9d7a-bb33-4c62-8783-b7a1c3e5df49';
export const WEB3FORMS_ENDPOINT = 'https://api.web3forms.com/submit';
