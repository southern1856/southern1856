import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export interface ToolUsageStat {
  tool_id: string;
  tool_name: string;
  usage_count: number;
  last_used_at: string;
}

export function useToolUsage() {
  const [stats, setStats] = useState<ToolUsageStat[]>([]);
  const [mostUsed, setMostUsed] = useState<ToolUsageStat | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function fetchStats() {
      try {
        const { data, error } = await supabase
          .from('tool_usage_stats')
          .select('tool_id, tool_name, usage_count, last_used_at')
          .order('usage_count', { ascending: false });

        if (cancelled) return;

        if (!error && data) {
          setStats(data);
          setMostUsed(data[0] ?? null);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    fetchStats();

    // Refresh every 60 seconds to keep badge near-real-time
    const interval = setInterval(fetchStats, 60000);

    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, []);

  return { stats, mostUsed, loading };
}