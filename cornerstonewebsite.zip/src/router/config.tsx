import type { RouteObject } from "react-router-dom";
import NotFound from "../pages/NotFound";
import Home from "../pages/home/page";
import InsuranceClaims from "../pages/insurance-claims/page";
import Services from "../pages/services/page";
import ServiceAreas from "../pages/service-areas/page";
import Projects from "../pages/projects/page";
import Financing from "../pages/financing/page";
import Estimate from "../pages/estimate/page";
import Blog from "../pages/blog/page";
import BlogArticle from "../pages/blog/[slug]/page";
import Testimonials from "../pages/testimonials/page";
import BeforeAfter from "../pages/before-after/page";
import About from "../pages/about/page";
import MaintenancePlans from "../pages/maintenance-plans/page";
import Warranty from "../pages/warranty/page";
import ThankYou from "../pages/thank-you/page";
import PrivacyPolicy from "../pages/privacy-policy/page";
import TermsOfService from "../pages/terms-of-service/page";
import FAQ from "../pages/faq/page";
import StormDamage from "../pages/storm-damage/page";
import NewburghPage from "../pages/locations/newburgh/page";
import HendersonKYPage from "../pages/locations/henderson-ky/page";
import BoonvillePage from "../pages/locations/boonville/page";
import OwensboroKYPage from "../pages/locations/owensboro-ky/page";
import MountVernonPage from "../pages/locations/mount-vernon/page";
import PrincetonPage from "../pages/locations/princeton/page";
import JasperPage from "../pages/locations/jasper/page";
import ChandlerPage from "../pages/locations/chandler/page";
import TellCityPage from "../pages/locations/tell-city/page";
import RockportPage from "../pages/locations/rockport/page";
import VincennesPage from "../pages/locations/vincennes/page";
import WashingtonPage from "../pages/locations/washington/page";
import MadisonvilleKYPage from "../pages/locations/madisonville-ky/page";
import GreenvilleKYPage from "../pages/locations/greenville-ky/page";
import NewHarmonyPage from "../pages/locations/new-harmony/page";
import FortBranchPage from "../pages/locations/fort-branch/page";
import OaklandCityPage from "../pages/locations/oakland-city/page";
import HaubstadtPage from "../pages/locations/haubstadt/page";
import PoseyvillePage from "../pages/locations/poseyville/page";
import DarmstadtPage from "../pages/locations/darmstadt/page";
import PetersburgPage from "../pages/locations/petersburg/page";
import MorganfieldKYPage from "../pages/locations/morganfield-ky/page";
import SturgisKYPage from "../pages/locations/sturgis-ky/page";
import ProvidenceKYPage from "../pages/locations/providence-ky/page";
import SebreeKYPage from "../pages/locations/sebree-ky/page";
import CalhounKYPage from "../pages/locations/calhoun-ky/page";
import LivermoreKYPage from "../pages/locations/livermore-ky/page";
import BeaverDamKYPage from "../pages/locations/beaver-dam-ky/page";
import HartfordKYPage from "../pages/locations/hartford-ky/page";
import CentralCityKYPage from "../pages/locations/central-city-ky/page";
import PowderlyKYPage from "../pages/locations/powderly-ky/page";
import BremenKYPage from "../pages/locations/bremen-ky/page";
import MountCarmelILPage from "../pages/locations/mount-carmel-il/page";
import GrayvilleILPage from "../pages/locations/grayville-il/page";
import CarmiILPage from "../pages/locations/carmi-il/page";
import LawrencevilleILPage from "../pages/locations/lawrenceville-il/page";
import OlneyILPage from "../pages/locations/olney-il/page";
import FairfieldILPage from "../pages/locations/fairfield-il/page";
import OwensvillePage from "../pages/locations/owensville/page";
import LynnvillePage from "../pages/locations/lynnville/page";
import ElberfeldPage from "../pages/locations/elberfeld/page";
import DalePage from "../pages/locations/dale/page";
import SantaClausPage from "../pages/locations/santa-claus/page";
import FerdinandPage from "../pages/locations/ferdinand/page";
import HuntingburgPage from "../pages/locations/huntingburg/page";
import CynthianaPage from "../pages/locations/cynthiana/page";
import CommercialRoofing from "../pages/commercial-roofing/page";
import ResidentialRoofing from "../pages/residential-roofing/page";
import RoofFinancing from "../pages/roof-financing/page";
import IllinoisRoofFinancing from "../pages/illinois-roof-financing/page";
import IllinoisStormDamage from "../pages/illinois-storm-damage/page";
import IllinoisRoofingLicenseGuide from "../pages/illinois-roofing-license-guide/page";
import GuttersDownspouts from "../pages/gutters-downspouts/page";
import SidingExterior from "../pages/siding-exterior/page";
import ExteriorPackage from "../pages/exterior-package/page";
import AIInspector from "../pages/ai-inspector/page";
import EmergencyServices from "../pages/emergency-services/page";
import FreeInspection from "../pages/free-inspection/page";
import RoofComparison from "../pages/roof-comparison/page";
import RoofCostGuide from "../pages/roof-cost-guide/page";
import GuideSent from "../pages/guide-sent/page";
import CaseStudies from "../pages/case-studies/page";
import InspectionBooked from "../pages/inspection-booked/page";
import ShareConfirmation from "../pages/share-confirmation/page";
import PostInspection from "../pages/post-inspection/page";
import SitemapPage from "../pages/sitemap/page";
import GoogleBusinessProfileOptimization from "../pages/google-business-profile-optimization/page";
import SocialMediaTemplates from "../pages/social-media-templates/page";
import ContentCalendar from "../pages/content-calendar/page";
import SEOAuditChecklist from "../pages/seo-audit-checklist/page";
import BeforeYouHireRoofer from "../pages/before-you-hire-a-roofer/page";
import RoofMaintenanceCalendar from "../pages/roof-maintenance-calendar/page";
import RoofEstimator from "../pages/roof-estimator/page";
import RoofEstimatorLanding from "../pages/roof-estimator/landing";
import AdminAlexConversations from "../pages/admin-alex-conversations/page";
import RoofRepairPage from "../pages/roof-repair/page";
import EvansvilleRoofRepair from "../pages/evansville-roof-repair/page";
import EvansvilleRoofReplacement from "../pages/evansville-roof-replacement/page";
import ToolsLanding from "../pages/tools/page";
import QuoteComparisonPage from "../pages/quote-comparison/page";
import InstantSchedulerPage from "../pages/instant-scheduler/page";
import FinancingCalculatorPage from "../pages/financing-calculator/page";
import AdminTools from "../pages/admin-tools/page";
import AdminToolDetail from "../pages/admin-tools/detail/page";
import PortalAuth from "../pages/customer-portal/auth/page";
import CustomerPortalDashboard from "../pages/customer-portal/page";
import ProjectDetail from "../pages/customer-portal/project/[id]/page";
import PromotionsPage from "../pages/promotions/page";
import PromotionThankYou from "../pages/promotions/thank-you/page";

const routes: RouteObject[] = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/services",
    element: <Services />,
  },
  {
    path: "/service-areas",
    element: <ServiceAreas />,
  },
  {
    path: "/insurance-claims",
    element: <InsuranceClaims />,
  },
  {
    path: "/projects",
    element: <Projects />,
  },
  {
    path: "/financing",
    element: <Financing />,
  },
  {
    path: "/estimate",
    element: <Estimate />,
  },
  {
    path: "/blog",
    element: <Blog />,
  },
  {
    path: "/blog/:slug",
    element: <BlogArticle />,
  },
  {
    path: "/testimonials",
    element: <Testimonials />,
  },
  {
    path: "/before-after",
    element: <BeforeAfter />,
  },
  {
    path: "/about",
    element: <About />,
  },
  {
    path: "/maintenance-plans",
    element: <MaintenancePlans />,
  },
  {
    path: "/warranty",
    element: <Warranty />,
  },
  {
    path: "/thank-you",
    element: <ThankYou />,
  },
  {
    path: "/faq",
    element: <FAQ />,
  },
  {
    path: "/privacy-policy",
    element: <PrivacyPolicy />,
  },
  {
    path: "/terms-of-service",
    element: <TermsOfService />,
  },
  {
    path: "/storm-damage",
    element: <StormDamage />,
  },
  {
    path: "/locations/newburgh",
    element: <NewburghPage />,
  },
  {
    path: "/locations/henderson-ky",
    element: <HendersonKYPage />,
  },
  {
    path: "/locations/boonville",
    element: <BoonvillePage />,
  },
  {
    path: "/locations/owensboro-ky",
    element: <OwensboroKYPage />,
  },
  {
    path: "/locations/mount-vernon",
    element: <MountVernonPage />,
  },
  {
    path: "/locations/princeton",
    element: <PrincetonPage />,
  },
  {
    path: "/locations/jasper",
    element: <JasperPage />,
  },
  {
    path: "/locations/chandler",
    element: <ChandlerPage />,
  },
  {
    path: "/locations/tell-city",
    element: <TellCityPage />,
  },
  {
    path: "/locations/rockport",
    element: <RockportPage />,
  },
  {
    path: "/locations/vincennes",
    element: <VincennesPage />,
  },
  {
    path: "/locations/washington",
    element: <WashingtonPage />,
  },
  {
    path: "/locations/madisonville-ky",
    element: <MadisonvilleKYPage />,
  },
  {
    path: "/locations/greenville-ky",
    element: <GreenvilleKYPage />,
  },
  {
    path: "/locations/morganfield-ky",
    element: <MorganfieldKYPage />,
  },
  {
    path: "/locations/sturgis-ky",
    element: <SturgisKYPage />,
  },
  {
    path: "/locations/providence-ky",
    element: <ProvidenceKYPage />,
  },
  {
    path: "/locations/sebree-ky",
    element: <SebreeKYPage />,
  },
  {
    path: "/locations/calhoun-ky",
    element: <CalhounKYPage />,
  },
  {
    path: "/locations/livermore-ky",
    element: <LivermoreKYPage />,
  },
  {
    path: "/locations/beaver-dam-ky",
    element: <BeaverDamKYPage />,
  },
  {
    path: "/locations/hartford-ky",
    element: <HartfordKYPage />,
  },
  {
    path: "/locations/central-city-ky",
    element: <CentralCityKYPage />,
  },
  {
    path: "/locations/powderly-ky",
    element: <PowderlyKYPage />,
  },
  {
    path: "/locations/bremen-ky",
    element: <BremenKYPage />,
  },
  {
    path: "/locations/mount-carmel-il",
    element: <MountCarmelILPage />,
  },
  {
    path: "/locations/grayville-il",
    element: <GrayvilleILPage />,
  },
  {
    path: "/locations/carmi-il",
    element: <CarmiILPage />,
  },
  {
    path: "/locations/lawrenceville-il",
    element: <LawrencevilleILPage />,
  },
  {
    path: "/locations/olney-il",
    element: <OlneyILPage />,
  },
  {
    path: "/locations/fairfield-il",
    element: <FairfieldILPage />,
  },
  {
    path: "/locations/owensville",
    element: <OwensvillePage />,
  },
  {
    path: "/locations/lynnville",
    element: <LynnvillePage />,
  },
  {
    path: "/locations/elberfeld",
    element: <ElberfeldPage />,
  },
  {
    path: "/locations/dale",
    element: <DalePage />,
  },
  {
    path: "/locations/santa-claus",
    element: <SantaClausPage />,
  },
  {
    path: "/locations/ferdinand",
    element: <FerdinandPage />,
  },
  {
    path: "/locations/huntingburg",
    element: <HuntingburgPage />,
  },
  {
    path: "/locations/cynthiana",
    element: <CynthianaPage />,
  },
  {
    path: "/locations/new-harmony",
    element: <NewHarmonyPage />,
  },
  {
    path: "/locations/fort-branch",
    element: <FortBranchPage />,
  },
  {
    path: "/locations/oakland-city",
    element: <OaklandCityPage />,
  },
  {
    path: "/locations/haubstadt",
    element: <HaubstadtPage />,
  },
  {
    path: "/locations/poseyville",
    element: <PoseyvillePage />,
  },
  {
    path: "/locations/darmstadt",
    element: <DarmstadtPage />,
  },
  {
    path: "/locations/petersburg",
    element: <PetersburgPage />,
  },
  {
    path: "/commercial-roofing",
    element: <CommercialRoofing />,
  },
  {
    path: "/residential-roofing",
    element: <ResidentialRoofing />,
  },
  {
    path: "/roof-financing",
    element: <RoofFinancing />,
  },
  {
    path: "/illinois-roof-financing",
    element: <IllinoisRoofFinancing />,
  },
  {
    path: "/illinois-storm-damage",
    element: <IllinoisStormDamage />,
  },
  {
    path: "/illinois-roofing-license-guide",
    element: <IllinoisRoofingLicenseGuide />,
  },
  {
    path: "/gutters-downspouts",
    element: <GuttersDownspouts />,
  },
  {
    path: "/siding-exterior",
    element: <SidingExterior />,
  },
  {
    path: "/exterior-package",
    element: <ExteriorPackage />,
  },
  {
    path: "/ai-inspector",
    element: <AIInspector />,
  },
  {
    path: "/emergency-services",
    element: <EmergencyServices />,
  },
  {
    path: "/free-inspection",
    element: <FreeInspection />,
  },
  {
    path: "/inspection-booked",
    element: <InspectionBooked />,
  },
  {
    path: "/share-confirmation",
    element: <ShareConfirmation />,
  },
  {
    path: "/roof-comparison",
    element: <RoofComparison />,
  },
  {
    path: "/roof-cost-guide",
    element: <RoofCostGuide />,
  },
  {
    path: "/guide-sent",
    element: <GuideSent />,
  },
  {
    path: "/case-studies",
    element: <CaseStudies />,
  },
  {
    path: "/post-inspection",
    element: <PostInspection />,
  },
  {
    path: "/sitemap",
    element: <SitemapPage />,
  },
  {
    path: "/google-business-profile-optimization",
    element: <GoogleBusinessProfileOptimization />,
  },
  {
    path: "/social-media-templates",
    element: <SocialMediaTemplates />,
  },
  {
    path: "/content-calendar",
    element: <ContentCalendar />,
  },
  {
    path: "/seo-audit-checklist",
    element: <SEOAuditChecklist />,
  },
  {
    path: "/before-you-hire-a-roofer",
    element: <BeforeYouHireRoofer />,
  },
  {
    path: "/roof-maintenance-calendar",
    element: <RoofMaintenanceCalendar />,
  },
  {
    path: "/roof-estimator",
    element: <RoofEstimator />,
  },
  {
    path: "/get-roof-estimate",
    element: <RoofEstimatorLanding />,
  },
  {
    path: "/admin/alex-conversations",
    element: <AdminAlexConversations />,
  },
  {
    path: "/admin/tools",
    element: <AdminTools />,
  },
  {
    path: "/admin/tools/:toolId",
    element: <AdminToolDetail />,
  },
  {
    path: "/roof-repair",
    element: <RoofRepairPage />,
  },
  {
    path: "/evansville-roof-repair",
    element: <EvansvilleRoofRepair />,
  },
  {
    path: "/evansville-roof-replacement",
    element: <EvansvilleRoofReplacement />,
  },
  {
    path: "/tools",
    element: <ToolsLanding />,
  },
  {
    path: "/quote-comparison",
    element: <QuoteComparisonPage />,
  },
  {
    path: "/instant-scheduler",
    element: <InstantSchedulerPage />,
  },
  {
    path: "/financing-calculator",
    element: <FinancingCalculatorPage />,
  },
  {
    path: "/customer-portal",
    element: <CustomerPortalDashboard />,
  },
  {
    path: "/customer-portal/auth",
    element: <PortalAuth />,
  },
  {
    path: "/customer-portal/project/:id",
    element: <ProjectDetail />,
  },
  {
    path: "/promotions",
    element: <PromotionsPage />,
  },
  {
    path: "/promotions/thank-you",
    element: <PromotionThankYou />,
  },
  {
    path: "*",
    element: <NotFound />,
  },
];

export default routes;