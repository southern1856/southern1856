import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import AdminWatermark from "@/components/feature/AdminWatermark";
import StatsCards from "./components/StatsCards";
import ConversationList from "./components/ConversationList";
import CommonQuestions from "./components/CommonQuestions";
import { useNavigate } from "react-router-dom";

export interface ConversationMessage {
  id: number;
  session_id: string;
  role: "user" | "assistant";
  content: string;
  ai_powered: boolean;
  created_at: string;
}

export default function AdminAlexConversations() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<ConversationMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const fetchMessages = async () => {
    try {
      setRefreshing(true);
      const { data, error: sbError } = await supabase
        .from("alex_conversations")
        .select("id, session_id, role, content, ai_powered, created_at")
        .order("created_at", { ascending: false })
        .limit(2000);

      if (sbError) throw sbError;
      setMessages(data || []);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load conversations");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchMessages();
  }, []);

  const handleExport = () => {
    const csv = [
      ["ID", "Session ID", "Role", "Content", "AI Powered", "Created At"].join(","),
      ...messages.map((m) =>
        [m.id, m.session_id, m.role, `"${m.content.replace(/"/g, '""')}"`, m.ai_powered, m.created_at].join(",")
      ),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `alex-conversations-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
              <i className="ri-dashboard-line text-xl" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900">Alex Conversation Analytics</h1>
              <p className="text-xs text-gray-500">Review chats, questions, and AI performance</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigate("/admin/tools")}
              className="hidden md:flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-600 bg-gray-50 border border-gray-200 rounded-md hover:bg-gray-100 transition-colors"
            >
              <i className="ri-bar-chart-grouped-line" />
              Tool Analytics
            </button>
            <button
              onClick={fetchMessages}
              disabled={refreshing}
              className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-200 rounded-md hover:bg-gray-50 transition-colors disabled:opacity-50"
            >
              <i className={`ri-refresh-line ${refreshing ? "animate-spin" : ""}`} />
              Refresh
            </button>
            <button
              onClick={handleExport}
              className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-white bg-emerald-600 rounded-md hover:bg-emerald-700 transition-colors"
            >
              <i className="ri-download-2-line" />
              Export CSV
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-6 space-y-6">
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-sm text-red-700 flex items-center gap-2">
            <i className="ri-error-warning-line" />
            {error}
          </div>
        )}

        <StatsCards messages={messages} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <h2 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <i className="ri-chat-history-line text-gray-500" />
              Conversation Threads
            </h2>
            <ConversationList messages={messages} loading={loading} />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <i className="ri-dashboard-3-line text-gray-500" />
              Analytics
            </h2>
            <CommonQuestions messages={messages} />
          </div>
        </div>
      </div>
      <AdminWatermark />
    </div>
  );
}