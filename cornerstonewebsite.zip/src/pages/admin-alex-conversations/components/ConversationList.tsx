import { useState, useMemo } from "react";
import type { ConversationMessage } from "../page";

interface ConversationListProps {
  messages: ConversationMessage[];
  loading: boolean;
}

interface SessionThread {
  session_id: string;
  messages: ConversationMessage[];
  lastActive: string;
  messageCount: number;
  firstMessage: string;
}

export default function ConversationList({ messages, loading }: ConversationListProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedSession, setExpandedSession] = useState<string | null>(null);
  const [dateFilter, setDateFilter] = useState<"all" | "7" | "30">("all");

  const sessions = useMemo(() => {
    const now = new Date();
    const filtered = messages.filter((m) => {
      if (dateFilter === "all") return true;
      const days = parseInt(dateFilter);
      const msgDate = new Date(m.created_at);
      const diff = (now.getTime() - msgDate.getTime()) / (1000 * 60 * 60 * 24);
      return diff <= days;
    });

    const grouped = filtered.reduce<Record<string, ConversationMessage[]>>((acc, msg) => {
      if (!acc[msg.session_id]) acc[msg.session_id] = [];
      acc[msg.session_id].push(msg);
      return acc;
    }, {});

    const threads: SessionThread[] = Object.entries(grouped).map(([sessionId, msgs]) => {
      const sorted = msgs.sort(
        (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
      );
      const firstUser = sorted.find((m) => m.role === "user");
      return {
        session_id: sessionId,
        messages: sorted,
        lastActive: sorted[sorted.length - 1]?.created_at || "",
        messageCount: sorted.length,
        firstMessage: firstUser?.content.slice(0, 80) || "No user message",
      };
    });

    threads.sort((a, b) => new Date(b.lastActive).getTime() - new Date(a.lastActive).getTime());

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return threads.filter(
        (t) =>
          t.firstMessage.toLowerCase().includes(q) ||
          t.messages.some((m) => m.content.toLowerCase().includes(q))
      );
    }

    return threads;
  }, [messages, searchQuery, dateFilter]);

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg border border-gray-100 p-8 text-center">
        <div className="w-8 h-8 border-2 border-gray-200 border-t-emerald-500 rounded-full animate-spin mx-auto mb-3" />
        <p className="text-sm text-gray-500">Loading conversations...</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-gray-100 overflow-hidden">
      <div className="p-4 border-b border-gray-100 flex flex-col sm:flex-row gap-3">
        <div className="flex-1 relative">
          <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search conversations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
          />
        </div>
        <div className="flex gap-1 bg-gray-50 rounded-md p-1">
          {[
            { key: "all", label: "All Time" },
            { key: "7", label: "7 Days" },
            { key: "30", label: "30 Days" },
          ].map((opt) => (
            <button
              key={opt.key}
              onClick={() => setDateFilter(opt.key as "all" | "7" | "30")}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
                dateFilter === opt.key
                  ? "bg-white text-gray-900 shadow-sm"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      <div className="max-h-[600px] overflow-y-auto">
        {sessions.length === 0 ? (
          <div className="p-8 text-center text-sm text-gray-400">
            <i className="ri-inbox-line text-3xl mb-2 block" />
            No conversations found
          </div>
        ) : (
          sessions.map((session) => {
            const isExpanded = expandedSession === session.session_id;
            const aiCount = session.messages.filter((m) => m.ai_powered).length;

            return (
              <div key={session.session_id} className="border-b border-gray-50 last:border-0">
                <button
                  onClick={() => setExpandedSession(isExpanded ? null : session.session_id)}
                  className="w-full text-left p-4 hover:bg-gray-50 transition-colors flex items-start gap-3"
                >
                  <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                    <i className="ri-user-line" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-semibold text-gray-900 truncate">
                        {session.firstMessage}
                      </span>
                      <span className="text-xs text-gray-400 shrink-0">
                        {session.messageCount} msgs
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-gray-500">
                      <span>{formatDate(session.lastActive)}</span>
                      {aiCount > 0 && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-violet-50 text-violet-700">
                          <i className="ri-magic-line" />
                          {aiCount} AI
                        </span>
                      )}
                      <span className="font-mono text-gray-400 truncate max-w-[120px]">
                        {session.session_id.slice(0, 12)}...
                      </span>
                    </div>
                  </div>
                  <div className="w-5 h-5 flex items-center justify-center text-gray-400 shrink-0 mt-1">
                    {isExpanded ? (
                      <i className="ri-arrow-up-s-line" />
                    ) : (
                      <i className="ri-arrow-down-s-line" />
                    )}
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-4 pb-4 bg-gray-50/50">
                    <div className="space-y-3 mt-2">
                      {session.messages.map((msg) => (
                        <div
                          key={msg.id}
                          className={`flex gap-3 ${msg.role === "user" ? "" : "flex-row-reverse"}`}
                        >
                          <div
                            className={`w-7 h-7 rounded-full shrink-0 flex items-center justify-center text-xs ${
                              msg.role === "user"
                                ? "bg-emerald-100 text-emerald-700"
                                : msg.ai_powered
                                  ? "bg-violet-100 text-violet-700"
                                  : "bg-amber-100 text-amber-700"
                            }`}
                          >
                            <i
                              className={
                                msg.role === "user"
                                  ? "ri-user-line"
                                  : msg.ai_powered
                                    ? "ri-magic-line"
                                    : "ri-robot-2-line"
                              }
                            />
                          </div>
                          <div
                            className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                              msg.role === "user"
                                ? "bg-emerald-50 text-gray-800"
                                : msg.ai_powered
                                  ? "bg-violet-50 text-gray-800 border border-violet-100"
                                  : "bg-white text-gray-800 border border-gray-200"
                            }`}
                          >
                            <p className="leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                            <div className="flex items-center gap-2 mt-1.5">
                              <span className="text-[10px] text-gray-400">
                                {formatDate(msg.created_at)}
                              </span>
                              {msg.role === "assistant" && (
                                <span
                                  className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                                    msg.ai_powered
                                      ? "bg-violet-100 text-violet-700"
                                      : "bg-amber-100 text-amber-700"
                                  }`}
                                >
                                  {msg.ai_powered ? "AI" : "Rule"}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}