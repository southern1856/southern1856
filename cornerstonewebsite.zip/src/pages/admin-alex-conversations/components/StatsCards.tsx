import type { ConversationMessage } from "../page";

interface StatsCardsProps {
  messages: ConversationMessage[];
}

export default function StatsCards({ messages }: StatsCardsProps) {
  const sessions = Array.from(new Set(messages.map((m) => m.session_id)));
  const totalMessages = messages.length;
  const userMessages = messages.filter((m) => m.role === "user");
  const aiMessages = messages.filter((m) => m.role === "assistant" && m.ai_powered);
  const ruleMessages = messages.filter((m) => m.role === "assistant" && !m.ai_powered);

  const avgPerSession = sessions.length > 0 ? (totalMessages / sessions.length).toFixed(1) : "0";
  const aiPercent = totalMessages > 0 ? Math.round((aiMessages.length / totalMessages) * 100) : 0;
  const rulePercent = totalMessages > 0 ? Math.round((ruleMessages.length / totalMessages) * 100) : 0;

  const stats = [
    {
      label: "Total Sessions",
      value: sessions.length,
      icon: "ri-chat-3-line",
      color: "bg-emerald-50 text-emerald-700",
    },
    {
      label: "Total Messages",
      value: totalMessages,
      icon: "ri-message-3-line",
      color: "bg-sky-50 text-sky-700",
    },
    {
      label: "AI-Powered Responses",
      value: `${aiPercent}%`,
      sub: `${aiMessages.length} messages`,
      icon: "ri-magic-line",
      color: "bg-violet-50 text-violet-700",
    },
    {
      label: "Rule-Based Responses",
      value: `${rulePercent}%`,
      sub: `${ruleMessages.length} messages`,
      icon: "ri-stack-line",
      color: "bg-amber-50 text-amber-700",
    },
    {
      label: "Avg Messages / Session",
      value: avgPerSession,
      icon: "ri-bar-chart-box-line",
      color: "bg-rose-50 text-rose-700",
    },
    {
      label: "User Questions",
      value: userMessages.length,
      icon: "ri-questionnaire-line",
      color: "bg-teal-50 text-teal-700",
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {stats.map((stat) => (
        <div key={stat.label} className="bg-white rounded-lg border border-gray-100 p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className={`w-8 h-8 rounded-md flex items-center justify-center ${stat.color}`}>
              <i className={`${stat.icon} text-lg`} />
            </div>
          </div>
          <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
          <div className="text-xs text-gray-500 mt-0.5">{stat.label}</div>
          {stat.sub && <div className="text-xs text-gray-400 mt-0.5">{stat.sub}</div>}
        </div>
      ))}
    </div>
  );
}