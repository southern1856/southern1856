import { useMemo } from "react";
import type { ConversationMessage } from "../page";

interface CommonQuestionsProps {
  messages: ConversationMessage[];
}

const KEYWORD_GROUPS = [
  { name: "Pricing & Cost", keywords: ["cost", "price", "how much", "budget", "estimate", "quote", "bid", "pricing", "expensive", "cheap", "afford"] },
  { name: "Roof Materials", keywords: ["shingle", "architectural", "metal", "tile", "slate", "material", "asphalt", "composition", "standing seam", "copper"] },
  { name: "Insurance Claims", keywords: ["insurance", "claim", "deductible", "covered", "adjuster", "policy", "coverage", "file a claim", "denied"] },
  { name: "Timeline & Duration", keywords: ["time", "long", "days", "timeline", "when", "schedule", "how soon", "wait", "completion", "finish"] },
  { name: "Gutters & Downspouts", keywords: ["gutter", "downspout", "drainage", "leaf guard", "seamless", "gutter guard"] },
  { name: "Leaks & Emergency", keywords: ["leak", "water", "stain", "emergency", "dripping", "flood", "damage", "active leak", "rain"] },
  { name: "Financing & Payment", keywords: ["financing", "payment", "monthly", "loan", "credit", "down payment", "0 down", "interest", "apr"] },
  { name: "Warranty & Guarantee", keywords: ["warranty", "guarantee", "workmanship", "manufacturer", "lifetime", "coverage", "register"] },
  { name: "Maintenance & Care", keywords: ["maintenance", "inspect", "cleaning", "upkeep", "plan", "care", "annual", " RoofCare"] },
  { name: "Storm & Hail Damage", keywords: ["storm", "hail", "wind", "damage", "dent", "tornado", "severe", "weather"] },
  { name: "Signs of Damage / Replacement", keywords: ["signs", "need new roof", "replace", "old", "worn", "curling", "missing", "granule", "sagging"] },
  { name: "Siding & Exterior", keywords: ["siding", "vinyl", "fiber cement", "hardie", "paint", "exterior", "facade", "soffit", "fascia"] },
  { name: "Free Inspection", keywords: ["free inspection", "check my roof", "look at", "evaluate", "assessment", "examine"] },
  { name: "Contact / Human", keywords: ["call", "phone", "human", "contact", "speak to", "talk to", "person", "representative", "manager"] },
  { name: "Roof Repair", keywords: ["repair", "patch", "fix", "broken shingle", "small leak", "minor damage", "spot repair", "partial"] },
  { name: "Commercial Roofing", keywords: ["commercial", "business", "office", "warehouse", "industrial", "retail", "apartment building", "multi-family"] },
  { name: "Energy Efficiency", keywords: ["energy", "efficient", "cool roof", "insulation", "save money", "utility bill", "reflective", "solar"] },
  { name: "Ventilation & Attic", keywords: ["attic", "vent", "ventilation", "soffit", "fascia", "ridge vent", "intake", "exhaust"] },
  { name: "Home Value & Resale", keywords: ["resale", "home value", "sell my house", "property value", "curb appeal", "HOA", "association"] },
];

export default function CommonQuestions({ messages }: CommonQuestionsProps) {
  const analytics = useMemo(() => {
    const userMsgs = messages.filter((m) => m.role === "user");

    const groupCounts = KEYWORD_GROUPS.map((group) => {
      const count = userMsgs.filter((msg) =>
        group.keywords.some((kw) => msg.content.toLowerCase().includes(kw.toLowerCase()))
      ).length;
      return { ...group, count };
    }).sort((a, b) => b.count - a.count);

    const unmatched = userMsgs.filter((msg) =>
      !KEYWORD_GROUPS.some((group) =>
        group.keywords.some((kw) => msg.content.toLowerCase().includes(kw.toLowerCase()))
      )
    ).length;

    const aiFallbacks = messages.filter((m) => m.role === "assistant" && m.ai_powered).length;

    return { groupCounts, unmatched, aiFallbacks, totalUser: userMsgs.length };
  }, [messages]);

  const maxCount = Math.max(...analytics.groupCounts.map((g) => g.count), 1);

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-lg border border-gray-100 p-4">
        <h3 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
          <i className="ri-bar-chart-grouped-line text-emerald-600" />
          Common Question Topics
        </h3>
        <div className="space-y-2.5">
          {analytics.groupCounts.map((group) => (
            <div key={group.name}>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-gray-700 font-medium">{group.name}</span>
                <span className="text-gray-500">{group.count}</span>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-emerald-500 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${(group.count / maxCount) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-100 p-4">
        <h3 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
          <i className="ri-pie-chart-line text-violet-600" />
          Response Breakdown
        </h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-emerald-500" />
              <span className="text-xs text-gray-600">Keyword Matched</span>
            </div>
            <span className="text-xs font-semibold text-gray-900">
              {analytics.totalUser - analytics.unmatched}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-violet-500" />
              <span className="text-xs text-gray-600">AI Fallback (Unmatched)</span>
            </div>
            <span className="text-xs font-semibold text-gray-900">{analytics.unmatched}</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-amber-500" />
              <span className="text-xs text-gray-600">Topic Button Clicks</span>
            </div>
            <span className="text-xs font-semibold text-gray-900">
              {messages.filter((m) => m.role === "assistant" && !m.ai_powered).length - analytics.totalUser + analytics.unmatched}
            </span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-100 p-4">
        <h3 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
          <i className="ri-lightbulb-line text-amber-600" />
          Insights
        </h3>
        <div className="space-y-2">
          {analytics.unmatched > analytics.totalUser * 0.3 && (
            <div className="text-xs text-amber-700 bg-amber-50 rounded-md p-2.5 border border-amber-100">
              <strong>High AI fallback rate:</strong> {Math.round((analytics.unmatched / Math.max(analytics.totalUser, 1)) * 100)}% of questions are going to AI. Consider expanding keyword coverage.
            </div>
          )}
          {analytics.groupCounts[0]?.count > 0 && (
            <div className="text-xs text-emerald-700 bg-emerald-50 rounded-md p-2.5 border border-emerald-100">
              <strong>Top topic:</strong> {analytics.groupCounts[0].name} ({analytics.groupCounts[0].count} questions) — make sure this response is polished.
            </div>
          )}
          {analytics.totalUser === 0 && (
            <div className="text-xs text-gray-500 bg-gray-50 rounded-md p-2.5 border border-gray-100">
              No user questions yet. Conversations will appear here once visitors start chatting with Alex.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}