import { useEffect, useState } from 'react';

interface ImageLightboxProps {
  images: string[];
  initialIndex: number;
  onClose: () => void;
}

export default function ImageLightbox({ images, initialIndex, onClose }: ImageLightboxProps) {
  const [current, setCurrent] = useState(initialIndex);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, []);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') setCurrent((c) => (c + 1) % images.length);
      if (e.key === 'ArrowLeft') setCurrent((c) => (c - 1 + images.length) % images.length);
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [images.length, onClose]);

  const prev = () => setCurrent((c) => (c - 1 + images.length) % images.length);
  const next = () => setCurrent((c) => (c + 1) % images.length);

  return (
    <div
      className="fixed inset-0 z-[200] flex items-center justify-center bg-black/95"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      {/* Close */}
      <button
        onClick={onClose}
        className="absolute top-5 right-5 z-10 w-10 h-10 flex items-center justify-center bg-white/10 hover:bg-orange text-white transition-colors cursor-pointer"
        aria-label="Close lightbox"
      >
        <i className="ri-close-line text-xl" />
      </button>

      {/* Counter */}
      <div className="absolute top-5 left-1/2 -translate-x-1/2 bg-white/10 text-white text-xs font-semibold uppercase tracking-widest px-4 py-2">
        {current + 1} / {images.length}
      </div>

      {/* Prev */}
      {images.length > 1 && (
        <button
          onClick={prev}
          className="absolute left-4 md:left-8 z-10 w-12 h-12 flex items-center justify-center bg-white/10 hover:bg-orange text-white transition-colors cursor-pointer"
          aria-label="Previous image"
        >
          <i className="ri-arrow-left-line text-xl" />
        </button>
      )}

      {/* Main image */}
      <div className="w-full h-full flex items-center justify-center px-20 py-16">
        <img
          key={current}
          src={images[current]}
          alt={`Gallery image ${current + 1}`}
          className="max-w-full max-h-full object-contain"
          style={{ animation: 'fadeIn 0.2s ease' }}
        />
      </div>

      {/* Next */}
      {images.length > 1 && (
        <button
          onClick={next}
          className="absolute right-4 md:right-8 z-10 w-12 h-12 flex items-center justify-center bg-white/10 hover:bg-orange text-white transition-colors cursor-pointer"
          aria-label="Next image"
        >
          <i className="ri-arrow-right-line text-xl" />
        </button>
      )}

      {/* Thumbnails */}
      {images.length > 1 && (
        <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex gap-2 overflow-x-auto max-w-[90vw] pb-1">
          {images.map((img, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i)}
              className={`flex-shrink-0 w-14 h-10 overflow-hidden border-2 transition-all duration-200 cursor-pointer ${
                i === current ? 'border-orange opacity-100' : 'border-transparent opacity-40 hover:opacity-70'
              }`}
            >
              <img src={img} alt="" className="w-full h-full object-cover object-top" />
            </button>
          ))}
        </div>
      )}

      <style>{`@keyframes fadeIn { from { opacity: 0; transform: scale(0.97); } to { opacity: 1; transform: scale(1); } }`}</style>
    </div>
  );
}
