import { useState } from 'react';
import { projectStats } from '@/mocks/portfolioProjects';
import SocialShareCard from '@/components/feature/SocialShareCard';

function openReaddyAgent(prefill?: string) {
  const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
  if (btn) btn.click();
  if (!prefill) return;
  setTimeout(() => {
    const input = document.querySelector('input[placeholder*="message" i], textarea[placeholder*="message" i], input[placeholder*="ask" i], textarea[placeholder*="ask" i], input[placeholder*="type" i], textarea[placeholder*="type" i]') as HTMLInputElement | HTMLTextAreaElement | null;
    if (input) {
      input.value = prefill;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      const form = input.closest('form');
      if (form) {
        const submitBtn = form.querySelector('button[type="submit"], button[aria-label*="send" i]') as HTMLElement | null;
        if (submitBtn) submitBtn.click();
      }
    }
  }, 900);
}

export default function ProjectsHero() {
  const [showShare, setShowShare] = useState(false);

  return (
    <>
      <section className="relative bg-charcoal-deep pt-32 pb-16 md:pt-40 md:pb-20 overflow-hidden">
        {/* Background image */}
      <div className="absolute inset-0">
        <img
          src="/placeholders/1600x700.svg"
          alt="Corner Stone Construction roofing projects Evansville Indiana"
          className="w-full h-full object-cover object-top"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-charcoal-deep" />
      </div>

      <div className="relative w-full px-6 md:px-10 lg:px-16">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-white/40 text-xs uppercase tracking-widest mb-8">
          <a href="/" className="hover:text-orange transition-colors">Home</a>
          <i className="ri-arrow-right-s-line" />
          <span className="text-orange">Projects</span>
        </div>

        {/* Heading */}
        <div className="max-w-3xl mb-12">
          <p className="text-orange text-xs uppercase tracking-[0.3em] font-semibold mb-4">Our Portfolio</p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 6vw, 6rem)' }}>
            Real Roofs.<br />Real Results.
          </h1>
          <p className="text-white/50 text-base md:text-lg leading-relaxed max-w-xl">
            25+ years of roofing across Evansville, Henderson, and the Tri-State area. Every project tells a story — drag the sliders to see the transformations yourself.
          </p>
          <div className="flex flex-wrap items-center gap-3 mt-6">
            <button
              onClick={() => setShowShare(true)}
              className="inline-flex items-center gap-2 border border-white/30 hover:border-orange hover:text-orange text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-xs transition-colors whitespace-nowrap cursor-pointer"
            >
              <i className="ri-instagram-line text-orange text-sm" />
              Share to Instagram Stories
            </button>
            <button
              onClick={() => openReaddyAgent("Can you tell me about Corner Stone's roofing projects in Evansville?")}
              className="inline-flex items-center gap-2 bg-white/5 border border-white/10 hover:border-green-400/50 hover:text-green-400 text-white/70 font-semibold px-5 py-3.5 uppercase tracking-widest text-xs transition-colors whitespace-nowrap cursor-pointer"
            >
              <i className="ri-mic-line text-green-400 text-sm" />
              Ask AI About These Projects
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {projectStats.map((stat) => (
            <div key={stat.label} className="border border-white/10 bg-white/5 backdrop-blur-sm p-4 md:p-6">
              <div className="w-8 h-8 flex items-center justify-center mb-3">
                <i className={`${stat.icon} text-orange text-xl`} />
              </div>
              <p className="font-display text-white text-2xl md:text-3xl tracking-wider">{stat.value}</p>
              <p className="text-white/40 text-xs uppercase tracking-widest mt-1">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
      </section>

      {showShare && (
        <SocialShareCard
          title="Corner Stone Portfolio"
          subtitle="Real Roofs. Real Results."
          type="Portfolio"
          location="Evansville, IN"
          image="/placeholders/1600x700.svg"
          badge="Featured"
          stats={projectStats.map(s => ({ label: s.label, value: s.value, icon: s.icon }))}
          highlights={['Licensed & Fully Insured', 'Free Inspections & Estimates', 'Insurance Claim Specialists', 'Same-Day Emergency Response']}
          description="25+ years of roofing across Evansville, Henderson, and the Tri-State area. Every project tells a story — drag the sliders to see the transformations yourself."
          onClose={() => setShowShare(false)}
        />
      )}
    </>
  );
}