import { useNavigate } from 'react-router-dom';

export default function ProjectsCTA() {
  const navigate = useNavigate();

  return (
    <section className="bg-charcoal-deep border-t border-white/10 py-20 md:py-28 px-6 md:px-10 lg:px-16">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-10">
        <div className="max-w-2xl">
          <p className="text-orange text-xs uppercase tracking-[0.3em] font-semibold mb-4">Ready to Start?</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2rem, 5vw, 5rem)' }}>
            Your Roof Could Be<br />Our Next Project.
          </h2>
          <p className="text-white/40 text-sm md:text-base leading-relaxed">
            Free inspections, honest estimates, and the same quality you see in every project above. Serving Evansville, Henderson, and the entire Tri-State area.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-4 shrink-0">
          <a
            href="/#contact"
            onClick={(e) => { e.preventDefault(); navigate('/#contact'); }}
            className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-5 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap text-center cursor-pointer"
          >
            Get Free Estimate
          </a>
          <a
            href="tel:8122135997"
            className="border border-white/20 hover:border-white text-white font-semibold px-10 py-5 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap text-center flex items-center justify-center gap-3"
          >
            <i className="ri-phone-line text-orange" />
            812-213-5997
          </a>
        </div>
      </div>

      {/* Trust row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-14 pt-14 border-t border-white/10">
        {[
          { icon: 'ri-shield-check-line', label: 'Licensed & Insured', sub: 'Indiana & Kentucky' },
          { icon: 'ri-star-fill', label: '4.9 Google Rating', sub: '200+ verified reviews' },
          { icon: 'ri-time-line', label: 'Same-Day Response', sub: 'Emergency service available' },
          { icon: 'ri-award-line', label: 'GAF Certified', sub: 'Master Elite contractor' },
        ].map((item) => (
          <div key={item.label} className="flex items-start gap-3">
            <div className="w-9 h-9 flex items-center justify-center shrink-0">
              <i className={`${item.icon} text-orange text-xl`} />
            </div>
            <div>
              <p className="text-white text-sm font-semibold">{item.label}</p>
              <p className="text-white/40 text-xs mt-0.5">{item.sub}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
