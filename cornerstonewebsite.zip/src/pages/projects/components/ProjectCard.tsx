import { useState } from 'react';
import type { PortfolioProject } from '@/mocks/portfolioProjects';

interface ProjectCardProps {
  project: PortfolioProject;
  size: 'large' | 'medium' | 'small';
  onOpen: (project: PortfolioProject) => void;
  animDelay?: number;
  isVisible?: boolean;
}

const badgeStyles: Record<string, string> = {
  'Before & After': 'bg-orange text-white',
  'Completed': 'bg-emerald-600 text-white',
  'Storm Damage': 'bg-rose-600 text-white',
  'Insurance Claim': 'bg-amber-500 text-white',
  'Commercial': 'bg-slate-600 text-white',
};

const badgeIcons: Record<string, string> = {
  'Before & After': 'ri-arrow-left-right-line',
  'Completed': 'ri-checkbox-circle-line',
  'Storm Damage': 'ri-thunderstorms-line',
  'Insurance Claim': 'ri-shield-check-line',
  'Commercial': 'ri-building-2-line',
};

const heightMap = {
  large: 'h-72 md:h-96',
  medium: 'h-56 md:h-64',
  small: 'h-44 md:h-52',
};

export default function ProjectCard({ project, size, onOpen, animDelay = 0, isVisible = false }: ProjectCardProps) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      className={`relative overflow-hidden group cursor-pointer anim-fade-up ${isVisible ? 'is-visible' : ''}`}
      style={{ transitionDelay: `${animDelay}ms` }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={() => onOpen(project)}
    >
      {/* Before/After split preview on hover */}
      <div className="relative w-full overflow-hidden">
        <img
          src={project.afterImage}
          alt={`${project.title} - After`}
          className={`w-full ${heightMap[size]} object-cover object-top transition-transform duration-700 ${hovered ? 'scale-105' : 'scale-100'}`}
        />
        {/* Before image slides in from left on hover */}
        <div
          className={`absolute inset-0 overflow-hidden transition-all duration-500 ${hovered ? 'w-1/2' : 'w-0'}`}
        >
          <img
            src={project.beforeImage}
            alt={`${project.title} - Before`}
            className={`w-full ${heightMap[size]} object-cover object-top`}
            style={{ width: '200%', maxWidth: 'none' }}
          />
        </div>
        {/* Divider line */}
        {hovered && (
          <div className="absolute top-0 bottom-0 left-1/2 w-0.5 bg-white z-10 pointer-events-none" />
        )}
        {/* Before/After labels on hover */}
        {hovered && (
          <>
            <div className="absolute top-3 left-3 z-20 bg-rose-600 text-white text-xs font-bold px-2 py-0.5 uppercase tracking-wider">Before</div>
            <div className="absolute top-3 right-3 z-20 bg-emerald-600 text-white text-xs font-bold px-2 py-0.5 uppercase tracking-wider">After</div>
          </>
        )}
      </div>

      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent pointer-events-none" />

      {/* Badge */}
      <div className="absolute top-3 left-3 z-10">
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-bold uppercase tracking-widest ${badgeStyles[project.badge] ?? 'bg-white/20 text-white'}`}>
          <i className={`${badgeIcons[project.badge] ?? 'ri-tools-line'} text-xs`} />
          {project.badge}
        </span>
      </div>

      {/* Content */}
      <div className="absolute bottom-0 left-0 right-0 p-4 md:p-5 z-10">
        <p className="text-orange text-xs font-semibold tracking-widest uppercase mb-1">{project.type}</p>
        <h3 className={`font-display text-white uppercase tracking-wider leading-tight ${size === 'large' ? 'text-2xl md:text-3xl' : size === 'medium' ? 'text-lg md:text-xl' : 'text-base md:text-lg'}`}>
          {project.title}
        </h3>
        <div className="flex items-center gap-3 mt-1.5">
          <span className="text-white/50 text-xs flex items-center gap-1">
            <i className="ri-map-pin-line text-orange text-xs" />
            {project.location}
          </span>
          <span className="text-white/30 text-xs">{project.squareFootage}</span>
        </div>
      </div>

      {/* Arrow CTA */}
      <div className={`absolute top-3 right-3 z-10 w-9 h-9 flex items-center justify-center bg-orange transition-all duration-300 ${hovered ? 'opacity-100 scale-100' : 'opacity-0 scale-75'}`}>
        <i className="ri-arrow-right-up-line text-white text-base" />
      </div>

      {/* View details hint */}
      <div className={`absolute bottom-0 left-0 right-0 flex items-center justify-center pb-3 z-10 transition-all duration-300 ${hovered ? 'opacity-100' : 'opacity-0'}`}>
        <span className="text-white/70 text-xs uppercase tracking-widest border-b border-white/30">View Project Details</span>
      </div>
    </div>
  );
}
