import { useState, useEffect, useCallback } from 'react';
import type { PortfolioProject } from '@/mocks/portfolioProjects';
import ImageLightbox from './ImageLightbox';
import BrandedShareCard from '@/components/feature/BrandedShareCard';

interface ProjectModalProps {
  project: PortfolioProject | null;
  onClose: () => void;
}

export default function ProjectModal({ project, onClose }: ProjectModalProps) {
  const [sliderPos, setSliderPos] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const [activeGallery, setActiveGallery] = useState(0);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [showShareCard, setShowShareCard] = useState(false);

  useEffect(() => {
    if (project) {
      setSliderPos(50);
      setActiveGallery(0);
      setLightboxIndex(null);
      setShowShareCard(false);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [project]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && lightboxIndex === null && !showShareCard) onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onClose, lightboxIndex, showShareCard]);

  const handleSliderMove = useCallback((e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const rect = (e.currentTarget as HTMLDivElement).getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const pos = Math.max(5, Math.min(95, ((clientX - rect.left) / rect.width) * 100));
    setSliderPos(pos);
  }, [isDragging]);

  if (!project) return null;

  const allImages = [project.afterImage, project.beforeImage, ...project.galleryImages];

  return (
    <>
      <div
        className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8"
        onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      >
        {/* Backdrop */}
        <div className="absolute inset-0 bg-black/90 backdrop-blur-sm" onClick={onClose} />

        {/* Modal */}
        <div className="relative w-full max-w-5xl max-h-[90vh] overflow-y-auto bg-[#111] border border-white/10 z-10">
          {/* Close */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-20 w-10 h-10 flex items-center justify-center bg-white/10 hover:bg-orange text-white transition-colors cursor-pointer"
          >
            <i className="ri-close-line text-xl" />
          </button>

          {/* Share Button — top left */}
          <button
            onClick={() => setShowShareCard(true)}
            className="absolute top-4 left-4 z-20 flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-orange text-white text-xs font-semibold uppercase tracking-widest transition-colors cursor-pointer"
          >
            <i className="ri-share-forward-line text-sm" />
            Share
          </button>

          {/* Before/After Slider */}
          <div
            className="relative w-full h-64 md:h-96 overflow-hidden cursor-ew-resize select-none"
            onMouseDown={() => setIsDragging(true)}
            onMouseUp={() => setIsDragging(false)}
            onMouseLeave={() => setIsDragging(false)}
            onMouseMove={handleSliderMove}
            onTouchStart={() => setIsDragging(true)}
            onTouchEnd={() => setIsDragging(false)}
            onTouchMove={handleSliderMove}
          >
            <img
              src={project.afterImage}
              alt="After"
              className="absolute inset-0 w-full h-full object-cover object-top"
              draggable={false}
            />
            <div className="absolute inset-0 overflow-hidden" style={{ width: `${sliderPos}%` }}>
              <img
                src={project.beforeImage}
                alt="Before"
                className="absolute inset-0 h-full object-cover object-top"
                style={{ width: `${10000 / sliderPos}%`, maxWidth: 'none' }}
                draggable={false}
              />
            </div>
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-white z-10 pointer-events-none"
              style={{ left: `${sliderPos}%` }}
            />
            <div
              className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-10 h-10 flex items-center justify-center bg-white rounded-full z-20 pointer-events-none"
              style={{ left: `${sliderPos}%` }}
            >
              <i className="ri-arrow-left-right-line text-charcoal-deep text-base" />
            </div>
            <div className="absolute top-4 left-4 bg-rose-600 text-white text-xs font-bold px-3 py-1 uppercase tracking-widest z-10">Before</div>
            <div className="absolute top-4 right-4 bg-emerald-600 text-white text-xs font-bold px-3 py-1 uppercase tracking-widest z-10">After</div>
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white/60 text-xs uppercase tracking-widest z-10 pointer-events-none">
              Drag to compare
            </div>
          </div>

          {/* Content */}
          <div className="p-6 md:p-8">
            <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-orange text-xs font-semibold tracking-widest uppercase">{project.type}</span>
                  <span className="text-white/20">•</span>
                  <span className="text-white/40 text-xs">{project.year}</span>
                </div>
                <h2 className="font-display text-white text-2xl md:text-4xl uppercase tracking-wider leading-tight">{project.title}</h2>
                <p className="text-white/50 text-sm mt-1">{project.subtitle}</p>
              </div>
              <div className="flex flex-col gap-2 self-start">
                <a
                  href="/#contact"
                  onClick={(e) => { e.preventDefault(); onClose(); setTimeout(() => { document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' }); }, 300); }}
                  className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-6 py-3 uppercase tracking-widest whitespace-nowrap transition-colors cursor-pointer"
                >
                  Get a Quote
                </a>
                <button
                  onClick={() => setShowShareCard(true)}
                  className="flex items-center justify-center gap-2 border border-white/20 hover:border-orange hover:text-orange text-white/60 text-xs font-semibold uppercase tracking-widest px-6 py-2.5 transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-share-forward-line text-sm" />
                  Share This Project
                </button>
              </div>
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
              {[
                { icon: 'ri-map-pin-line', label: 'Location', value: project.location },
                { icon: 'ri-ruler-line', label: 'Scope', value: project.squareFootage },
                { icon: 'ri-time-line', label: 'Duration', value: project.duration },
                { icon: 'ri-stack-line', label: 'Material', value: project.material },
              ].map((stat) => (
                <div key={stat.label} className="bg-white/5 border border-white/10 p-3 md:p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <i className={`${stat.icon} text-orange text-sm`} />
                    <span className="text-white/40 text-xs uppercase tracking-wider">{stat.label}</span>
                  </div>
                  <p className="text-white text-sm font-semibold">{stat.value}</p>
                </div>
              ))}
            </div>

            {/* Description */}
            <p className="text-white/60 text-sm leading-relaxed mb-6">{project.description}</p>

            {/* Highlights */}
            <div className="mb-6">
              <h4 className="text-white text-xs font-semibold uppercase tracking-[0.2em] mb-3">Project Highlights</h4>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {project.highlights.map((h) => (
                  <li key={h} className="flex items-start gap-2 text-white/60 text-sm">
                    <i className="ri-checkbox-circle-fill text-orange text-sm mt-0.5 shrink-0" />
                    {h}
                  </li>
                ))}
              </ul>
            </div>

            {/* Gallery */}
            {allImages.length > 0 && (
              <div>
                <h4 className="text-white text-xs font-semibold uppercase tracking-[0.2em] mb-3">Project Gallery</h4>
                <div className="relative">
                  <div
                    className="relative cursor-zoom-in"
                    onClick={() => setLightboxIndex(activeGallery)}
                  >
                    <img
                      src={allImages[activeGallery]}
                      alt={`Gallery ${activeGallery + 1}`}
                      className="w-full h-48 md:h-64 object-cover object-top"
                    />
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-200 bg-black/30">
                      <div className="w-10 h-10 flex items-center justify-center bg-white/20 text-white">
                        <i className="ri-zoom-in-line text-xl" />
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-2 overflow-x-auto pb-1">
                    {allImages.map((img, i) => (
                      <button
                        key={i}
                        onClick={() => setActiveGallery(i)}
                        className={`shrink-0 w-16 h-12 overflow-hidden border-2 transition-colors cursor-pointer ${activeGallery === i ? 'border-orange' : 'border-transparent'}`}
                      >
                        <img src={img} alt="" className="w-full h-full object-cover object-top" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Full-screen Lightbox */}
      {lightboxIndex !== null && (
        <ImageLightbox
          images={allImages}
          initialIndex={lightboxIndex}
          onClose={() => setLightboxIndex(null)}
        />
      )}

      {/* Branded Share Card */}
      {showShareCard && (
        <BrandedShareCard
          project={project}
          onClose={() => setShowShareCard(false)}
        />
      )}
    </>
  );
}