import { useState } from 'react';
import { portfolioProjects } from '@/mocks/portfolioProjects';
import type { PortfolioProject } from '@/mocks/portfolioProjects';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import ProjectCard from './ProjectCard';
import ProjectModal from './ProjectModal';

const FILTERS = ['All', 'Residential', 'Commercial', 'Repair', 'Multi-Family'];

export default function ProjectsGallery() {
  const [activeFilter, setActiveFilter] = useState('All');
  const [selectedProject, setSelectedProject] = useState<PortfolioProject | null>(null);
  const row1 = useScrollAnimation({ threshold: 0.05 });
  const row2 = useScrollAnimation({ threshold: 0.05 });
  const row3 = useScrollAnimation({ threshold: 0.05 });
  const row4 = useScrollAnimation({ threshold: 0.05 });

  const filtered = activeFilter === 'All'
    ? portfolioProjects
    : portfolioProjects.filter((p) => p.type === activeFilter);

  const featured = filtered.filter((p) => p.featured);
  const rest = filtered.filter((p) => !p.featured);
  const row2Items = rest.slice(0, 3);
  const row3Items = rest.slice(3, 7);
  const row4Items = rest.slice(7);

  return (
    <>
      <section className="bg-charcoal-deep py-16 md:py-20">
        <div className="w-full px-6 md:px-10 lg:px-16">

          {/* Filter bar */}
          <div
            ref={row1.ref as React.RefObject<HTMLDivElement>}
            className={`flex flex-wrap items-center gap-2 mb-10 anim-fade-up ${row1.isVisible ? 'is-visible' : ''}`}
          >
            {FILTERS.map((f) => (
              <button
                key={f}
                onClick={() => setActiveFilter(f)}
                className={`px-5 py-2 text-xs uppercase tracking-widest font-semibold transition-all duration-200 whitespace-nowrap cursor-pointer border ${
                  activeFilter === f
                    ? 'bg-orange border-orange text-white'
                    : 'border-white/20 text-white/50 hover:border-white/50 hover:text-white'
                }`}
              >
                {f}
              </button>
            ))}
            <span className="ml-auto text-white/30 text-xs uppercase tracking-widest">
              {filtered.length} project{filtered.length !== 1 ? 's' : ''}
            </span>
          </div>

          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-32 text-center">
              <div className="w-12 h-12 flex items-center justify-center mb-4">
                <i className="ri-folder-open-line text-white/20 text-4xl" />
              </div>
              <p className="text-white/30 text-sm uppercase tracking-widest">No projects in this category yet</p>
            </div>
          ) : (
            <div className="space-y-2">

              {/* Row 1: Featured — large cards */}
              {featured.length > 0 && (
                <div
                  ref={row1.ref as React.RefObject<HTMLDivElement>}
                  className={`grid gap-2 ${featured.length === 1 ? 'grid-cols-1' : featured.length === 2 ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1 md:grid-cols-3'}`}
                >
                  {featured.map((project, i) => (
                    <ProjectCard
                      key={project.id}
                      project={project}
                      size="large"
                      onOpen={setSelectedProject}
                      animDelay={i * 120}
                      isVisible={row1.isVisible}
                    />
                  ))}
                </div>
              )}

              {/* Row 2: medium cards (3 across) */}
              {row2Items.length > 0 && (
                <div
                  ref={row2.ref as React.RefObject<HTMLDivElement>}
                  className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2"
                >
                  {row2Items.map((project, i) => (
                    <ProjectCard
                      key={project.id}
                      project={project}
                      size="medium"
                      onOpen={setSelectedProject}
                      animDelay={i * 100}
                      isVisible={row2.isVisible}
                    />
                  ))}
                </div>
              )}

              {/* Row 3: small cards (4 across) */}
              {row3Items.length > 0 && (
                <div
                  ref={row3.ref as React.RefObject<HTMLDivElement>}
                  className="grid grid-cols-2 lg:grid-cols-4 gap-2"
                >
                  {row3Items.map((project, i) => (
                    <ProjectCard
                      key={project.id}
                      project={project}
                      size="small"
                      onOpen={setSelectedProject}
                      animDelay={i * 80}
                      isVisible={row3.isVisible}
                    />
                  ))}
                </div>
              )}

              {/* Row 4: remaining small cards */}
              {row4Items.length > 0 && (
                <div
                  ref={row4.ref as React.RefObject<HTMLDivElement>}
                  className="grid grid-cols-2 lg:grid-cols-4 gap-2"
                >
                  {row4Items.map((project, i) => (
                    <ProjectCard
                      key={project.id}
                      project={project}
                      size="small"
                      onOpen={setSelectedProject}
                      animDelay={i * 80}
                      isVisible={row4.isVisible}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Project Detail Modal */}
      <ProjectModal project={selectedProject} onClose={() => setSelectedProject(null)} />
    </>
  );
}
