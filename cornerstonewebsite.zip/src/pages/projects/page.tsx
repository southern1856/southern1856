import FloatingCTA from '@/components/feature/FloatingCTA';
import ProjectsHero from './components/ProjectsHero';
import ProjectsGallery from './components/ProjectsGallery';
import ProjectsCTA from './components/ProjectsCTA';
import PageSEO from '@/components/feature/PageSEO';

export default function Projects() {
  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roofing Projects Portfolio Evansville Indiana | Corner Stone Construction"
        description="Browse our portfolio of completed roofing projects across Evansville IN, Newburgh, Henderson KY, and the Tri-State area. Residential roof replacements, commercial roofing, metal roofing, and storm damage restoration. Corner Stone Construction & Roofing."
        keywords="roofing projects Evansville Indiana, roof replacement portfolio Indiana, roofing gallery Evansville, completed roofing projects Tri-State, before after roofing Indiana"
        canonical="/projects"
      />
      <FloatingCTA />
      <ProjectsHero />
      <ProjectsGallery />
      <ProjectsCTA />
    </div>
  );
}