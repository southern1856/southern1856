import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { blogPosts } from '@/mocks/blog';
import PageSEO from '@/components/feature/PageSEO';
import DealExpiringSoon from '@/pages/promotions/components/DealExpiringSoon';
import { OFFERS } from '@/mocks/promotions';

const categories = ['All', 'Pricing', 'Maintenance', 'Materials', 'Storm Damage', 'Lifespan', 'DIY'];

export default function BlogPage() {
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState('All');
  const heroAnim = useScrollAnimation();
  const gridAnim = useScrollAnimation({ threshold: 0.05 });

  const filtered = activeCategory === 'All'
    ? blogPosts
    : blogPosts.filter((p) => p.category === activeCategory);

  const featured = blogPosts[0];
  const rest = blogPosts.slice(1);

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roofing Blog Evansville Indiana | Tips, Guides & Storm Damage Advice"
        description="Expert roofing tips, guides, and storm damage advice from Corner Stone Construction & Roofing in Evansville Indiana. Learn about roof maintenance, insurance claims, material comparisons, and more for Indiana & Kentucky homeowners."
        keywords="roofing blog Evansville Indiana, roof maintenance tips Indiana, storm damage roofing advice, roofing guides Evansville, Indiana roofing articles, hail damage roof tips"
        canonical="/blog"
      />

      {/* Hero */}
      <section className="relative min-h-[55vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1600x900.svg"
            alt="Corner Stone Roofing Blog — Evansville Indiana"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-charcoal-deep" />
        </div>
        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 text-center anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs md:text-sm font-semibold tracking-[0.25em] uppercase mb-5">
            The Roof Files
          </p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 8vw, 7rem)' }}>
            Stories, Guides<br />&amp; <span className="text-orange">Good Advice</span>
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-2xl mx-auto leading-relaxed">
            Real talk about roofing from the crew that does it every day in Evansville, Indiana and the Tri-State area.
          </p>
        </div>
      </section>

      {/* Featured Post */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16">
        <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-8">Featured Article</p>
        <button
          onClick={() => navigate(`/blog/${featured.slug}`)}
          className="w-full group cursor-pointer text-left"
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-0 border border-white/10 hover:border-orange/40 transition-colors duration-300">
            <div className="relative h-64 md:h-80 lg:h-auto overflow-hidden">
              <img
                src={featured.image}
                alt={featured.title}
                className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute top-5 left-5">
                <span className="bg-orange text-white text-xs font-semibold px-3 py-1.5 uppercase tracking-wider">
                  {featured.category}
                </span>
              </div>
            </div>
            <div className="bg-charcoal-mid p-8 md:p-12 flex flex-col justify-center">
              <div className="flex items-center gap-3 text-white/30 text-xs mb-5 uppercase tracking-wider">
                <span className="flex items-center gap-1.5">
                  <i className="ri-time-line" />
                  {featured.readTime}
                </span>
                <span className="w-1 h-1 bg-white/20 rounded-full" />
                <span>Evansville, IN</span>
              </div>
              <h2 className="font-display text-white text-2xl md:text-3xl lg:text-4xl uppercase tracking-wider leading-tight mb-5 group-hover:text-orange transition-colors">
                {featured.title}
              </h2>
              <p className="text-white/40 text-sm md:text-base leading-relaxed mb-8">
                {featured.excerpt}
              </p>
              <div className="flex items-center gap-2 text-orange text-sm font-semibold uppercase tracking-wide">
                Read Full Article
                <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform duration-200" />
              </div>
            </div>
          </div>
        </button>
      </section>

      {/* Category Filter + Grid */}
      <section className="pb-20 md:pb-28 px-6 md:px-10 lg:px-16">
        {/* Filter */}
        <div className="flex flex-wrap gap-2 mb-10 md:mb-14">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 text-xs uppercase tracking-wider font-semibold transition-all duration-200 whitespace-nowrap cursor-pointer ${
                activeCategory === cat
                  ? 'bg-orange text-white'
                  : 'border border-white/20 text-white/40 hover:border-orange hover:text-orange'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div
          ref={gridAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-white/10"
        >
          {(activeCategory === 'All' ? rest : filtered).map((post, i) => (
            <article
              key={post.id}
              className={`group bg-charcoal-deep hover:bg-charcoal-mid transition-colors duration-300 flex flex-col cursor-pointer anim-fade-up ${gridAnim.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 100}ms` }}
              onClick={() => navigate(`/blog/${post.slug}`)}
            >
              <div className="relative h-52 overflow-hidden">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500 opacity-80 group-hover:opacity-100"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-orange text-white text-xs font-semibold px-3 py-1.5 uppercase tracking-wider">
                    {post.category}
                  </span>
                </div>
              </div>
              <div className="p-6 md:p-8 flex flex-col flex-grow">
                <div className="flex items-center gap-3 text-white/30 text-xs mb-4 uppercase tracking-wider">
                  <span className="flex items-center gap-1">
                    <i className="ri-time-line" />
                    {post.readTime}
                  </span>
                </div>
                <h3 className="font-display text-white text-lg md:text-xl uppercase tracking-wide leading-snug mb-3 group-hover:text-orange transition-colors">
                  {post.title}
                </h3>
                <p className="text-white/40 text-sm leading-relaxed flex-grow mb-5">
                  {post.excerpt}
                </p>
                <div className="flex items-center gap-2 text-orange text-sm font-semibold">
                  Read Article
                  <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform duration-200" />
                </div>
              </div>
            </article>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20">
            <i className="ri-article-line text-white/20 text-5xl mb-4 block" />
            <p className="text-white/30 text-sm">No articles in this category yet.</p>
          </div>
        )}
      </section>

      {/* Resources Callout */}
      <section className="px-6 md:px-10 lg:px-16 pb-10">
        <div className="bg-charcoal-mid border border-white/5 p-8 md:p-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-2">Free Resource</p>
            <h3 className="font-display text-white text-lg md:text-xl uppercase tracking-wide">
              Google Business Profile Optimization Checklist
            </h3>
            <p className="text-white/40 text-sm mt-2 max-w-xl">
              A step-by-step guide to dominating local search as a roofing contractor in Evansville and the Tri-State area.
            </p>
          </div>
          <a
            href="/google-business-profile-optimization"
            onClick={(e) => { e.preventDefault(); navigate('/google-business-profile-optimization'); }}
            className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-xs transition-colors whitespace-nowrap flex items-center gap-2 flex-shrink-0"
          >
            Get the Checklist
            <i className="ri-arrow-right-line text-sm" />
          </a>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="bg-charcoal-mid border border-white/5 p-10 md:p-16 text-center">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Ready to Get Started?</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
            Questions About<br />Your Roof?
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-lg mx-auto leading-relaxed mb-10">
            Our team is happy to answer any roofing questions — no sales pitch, just honest advice from people who do this every day.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigate('/estimate')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              Get a Free Estimate
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/20 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>
      </section>

      <DealExpiringSoon offers={OFFERS} linkToPage="/promotions" />
    </div>
  );
}
