import { useParams, useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { blogPosts, blogArticles } from '@/mocks/blog';
import PageSEO from '@/components/feature/PageSEO';
import DealExpiringSoon from '@/pages/promotions/components/DealExpiringSoon';
import { OFFERS } from '@/mocks/promotions';

export default function BlogArticlePage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const heroAnim = useScrollAnimation();
  const contentAnim = useScrollAnimation();

  const post = blogPosts.find((p) => p.slug === slug);
  const article = blogArticles[slug ?? ''];

  if (!post || !article) {
    return (
      <div className="min-h-screen bg-charcoal-deep flex flex-col">
        <div className="flex-1 flex items-center justify-center flex-col gap-6 px-6">
          <i className="ri-article-line text-white/20 text-6xl" />
          <h1 className="font-display text-white text-3xl uppercase tracking-wider">Article Not Found</h1>
          <button
            onClick={() => navigate('/blog')}
            className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-3 uppercase tracking-wide text-sm transition-colors cursor-pointer"
          >
            Back to Blog
          </button>
        </div>
      </div>
    );
  }

  const related = blogPosts.filter((p) => p.id !== post.id && p.category === post.category).slice(0, 2);
  const fallbackRelated = blogPosts.filter((p) => p.id !== post.id).slice(0, 2);
  const relatedPosts = related.length > 0 ? related : fallbackRelated;

  const articleSchema = {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: post.title,
    description: post.excerpt,
    image: post.image,
    author: {
      '@type': 'Organization',
      name: 'Corner Stone Construction & Roofing',
      url: 'https://cornerstoneconstructionevansville.com',
    },
    publisher: {
      '@type': 'Organization',
      name: 'Corner Stone Construction & Roofing',
      logo: {
        '@type': 'ImageObject',
        url: '/logo.svg',
      },
    },
    mainEntityOfPage: {
      '@type': 'WebPage',
      '@id': `https://cornerstoneconstructionevansville.com/blog/${post.slug}`,
    },
    keywords: `${post.category}, roofing Evansville Indiana, ${post.title}`,
    articleSection: post.category,
    inLanguage: 'en-US',
  };

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title={`${post.title} | Corner Stone Roofing Blog Evansville IN`}
        description={`${post.excerpt} Expert roofing advice from Corner Stone Construction & Roofing — Evansville Indiana's most trusted roofer since 1995.`}
        keywords={`${post.category} roofing Evansville Indiana, ${post.title.toLowerCase()}, roofing tips Indiana, Corner Stone roofing blog`}
        canonical={`/blog/${post.slug}`}
        ogImage={post.image}
        schema={articleSchema}
      />
      {/* Hero */}
      <section className="relative min-h-[60vh] flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={post.image}
            alt={post.title}
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-charcoal-deep via-black/60 to-black/30" />
        </div>
        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 pb-14 md:pb-20 anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <button
            onClick={() => navigate('/blog')}
            className="flex items-center gap-2 text-white/40 hover:text-orange text-xs uppercase tracking-wider mb-6 transition-colors cursor-pointer"
          >
            <i className="ri-arrow-left-line" />
            Back to Blog
          </button>
          <div className="flex flex-wrap items-center gap-3 mb-5">
            <span className="bg-orange text-white text-xs font-semibold px-3 py-1.5 uppercase tracking-wider">
              {post.category}
            </span>
            <span className="text-white/30 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <i className="ri-time-line" />
              {post.readTime}
            </span>
            <span className="text-white/30 text-xs uppercase tracking-wider">Evansville, IN</span>
          </div>
          <h1 className="font-display text-white uppercase tracking-wider leading-tight max-w-4xl" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            {post.title}
          </h1>
        </div>
      </section>

      {/* Article Content */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 md:gap-16">
          {/* Main Content */}
          <div
            ref={contentAnim.ref as React.RefObject<HTMLDivElement>}
            className={`lg:col-span-2 anim-fade-up ${contentAnim.isVisible ? 'is-visible' : ''}`}
          >
            <p className="text-white/60 text-base md:text-lg leading-relaxed mb-8 border-l-2 border-orange pl-5">
              {post.excerpt}
            </p>

            <div className="space-y-8 text-white/60 text-sm md:text-base leading-relaxed">
              {article.sections.map((section, i) => (
                <div key={i}>
                  {section.heading && (
                    <h2 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider mb-4 mt-10">
                      {section.heading}
                    </h2>
                  )}
                  {section.body.map((para, j) => (
                    <p key={j} className="mb-4 leading-relaxed">
                      {para}
                    </p>
                  ))}
                  {section.list && (
                    <ul className="space-y-2 mt-4">
                      {section.list.map((item, k) => (
                        <li key={k} className="flex items-start gap-3">
                          <i className="ri-checkbox-circle-line text-orange mt-0.5 flex-shrink-0" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                  {section.link && (
                    <div className="mt-5 bg-charcoal-mid/60 border border-orange/15 rounded-md p-4 md:p-5">
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 flex items-center justify-center flex-shrink-0 bg-orange/15 rounded-md">
                          <i className="ri-lightbulb-line text-orange text-sm" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-orange text-xs uppercase tracking-wider font-semibold mb-1.5">
                            {section.link.label}
                          </p>
                          <a
                            href={section.link.url}
                            className="text-white/80 hover:text-orange text-sm leading-relaxed transition-colors inline-flex items-center gap-1.5 group"
                          >
                            <span>{section.link.text}</span>
                            <i className="ri-arrow-right-line text-orange group-hover:translate-x-0.5 transition-transform" />
                          </a>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* CTA inside article */}
            <div className="mt-12 bg-orange/10 border border-orange/20 p-6 md:p-8">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
                <div className="flex-1">
                  <h3 className="font-display text-white text-xl uppercase tracking-wider mb-2">
                    Ready for a Free Inspection?
                  </h3>
                  <p className="text-white/40 text-sm leading-relaxed">
                    Our team serves Evansville, Henderson, Owensboro, and the entire Tri-State area. No obligation, no pressure.
                  </p>
                </div>
                <button
                  onClick={() => navigate('/estimate')}
                  className="bg-orange hover:bg-orange-dark text-white font-semibold px-7 py-3 uppercase tracking-wide text-sm transition-colors whitespace-nowrap cursor-pointer flex-shrink-0"
                >
                  Get Free Estimate
                </button>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="space-y-6 lg:sticky lg:top-28">
              {/* Call CTA */}
              <div className="bg-charcoal-mid border border-white/5 p-6">
                <p className="text-orange text-xs uppercase tracking-wider font-semibold mb-3">Have Questions?</p>
                <p className="text-white font-display text-2xl uppercase tracking-wider mb-2">812-213-5997</p>
                <p className="text-white/40 text-xs leading-relaxed mb-5">
                  Talk to a real roofer — not a call center. Mon–Sat 7am–7pm.
                </p>
                <a
                  href="tel:8122135997"
                  className="flex items-center justify-center gap-2 bg-orange hover:bg-orange-dark text-white font-semibold px-6 py-3 uppercase tracking-wide text-sm transition-colors whitespace-nowrap"
                >
                  <i className="ri-phone-line" />
                  Call Now
                </a>
              </div>

              {/* Related Posts */}
              {relatedPosts.length > 0 && (
                <div className="bg-charcoal-mid border border-white/5 p-6">
                  <h4 className="text-white text-xs font-semibold uppercase tracking-[0.2em] mb-5">Related Articles</h4>
                  <div className="space-y-4">
                    {relatedPosts.map((rp) => (
                      <button
                        key={rp.id}
                        onClick={() => navigate(`/blog/${rp.slug}`)}
                        className="w-full text-left group cursor-pointer flex gap-3"
                      >
                        <div className="w-16 h-16 flex-shrink-0 overflow-hidden">
                          <img
                            src={rp.image}
                            alt={rp.title}
                            className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <span className="text-orange text-xs uppercase tracking-wider font-semibold">{rp.category}</span>
                          <p className="text-white/60 text-xs leading-snug mt-1 group-hover:text-white transition-colors line-clamp-2">
                            {rp.title}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* All articles */}
              <button
                onClick={() => navigate('/blog')}
                className="w-full border border-white/20 hover:border-orange text-white/40 hover:text-orange text-xs uppercase tracking-widest py-3 transition-all duration-200 cursor-pointer"
              >
                View All Articles
              </button>
            </div>
          </div>
        </div>
      </section>

      <DealExpiringSoon offers={OFFERS} linkToPage="/promotions" />
    </div>
  );
}
