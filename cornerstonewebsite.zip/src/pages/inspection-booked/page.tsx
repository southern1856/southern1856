import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const NEXT_STEPS = [
  {
    icon: 'ri-phone-line',
    title: 'Confirmation Call Within 24 Hours',
    desc: 'Our office will call to confirm your appointment date, time, and answer any last-minute questions.',
    timing: 'Within 24 hrs',
  },
  {
    icon: 'ri-calendar-check-line',
    title: 'Inspector Arrives at Your Property',
    desc: 'Your certified inspector will arrive on time, get on the roof, and document everything with detailed photos.',
    timing: 'On your scheduled day',
  },
  {
    icon: 'ri-mail-send-line',
    title: 'Full Photo Report Emailed',
    desc: 'Within 24 hours of the inspection, you receive a written condition summary with photos, severity ratings, and recommendations.',
    timing: 'Within 24 hrs after inspection',
  },
  {
    icon: 'ri-shake-hands-line',
    title: 'No Pressure Follow-Up (If Needed)',
    desc: 'If work is recommended, we follow up once with options. No repeated calls, no hard sell. The decision is always yours.',
    timing: 'If work is needed',
  },
];

const PREP_TIPS = [
  'Make sure we have access to your roof (unlock gates, clear the driveway)',
  'If you have pets, let us know so the inspector can be cautious',
  'If it is an insurance inspection, have your claim number ready',
  'Feel free to be home — our inspector will walk you through key findings',
];

const RESCHEDULE_SLOTS = [
  { value: '8:00 AM – 10:00 AM', label: '8:00 AM – 10:00 AM' },
  { value: '10:00 AM – 12:00 PM', label: '10:00 AM – 12:00 PM' },
  { value: '12:00 PM – 2:00 PM', label: '12:00 PM – 2:00 PM' },
  { value: '2:00 PM – 4:00 PM', label: '2:00 PM – 4:00 PM' },
  { value: '4:00 PM – 6:00 PM', label: '4:00 PM – 6:00 PM' },
];

function getMinDate(): string {
  const today = new Date();
  today.setDate(today.getDate() + 1);
  return today.toISOString().split('T')[0];
}

function getMaxDate(): string {
  const max = new Date();
  max.setDate(max.getDate() + 60);
  return max.toISOString().split('T')[0];
}

function parseTimeSlot(slot: string): { startHour: number; startMin: number; endHour: number; endMin: number } {
  const map: Record<string, { startHour: number; startMin: number; endHour: number; endMin: number }> = {
    '8:00 AM – 10:00 AM': { startHour: 8, startMin: 0, endHour: 10, endMin: 0 },
    '10:00 AM – 12:00 PM': { startHour: 10, startMin: 0, endHour: 12, endMin: 0 },
    '12:00 PM – 2:00 PM': { startHour: 12, startMin: 0, endHour: 14, endMin: 0 },
    '2:00 PM – 4:00 PM': { startHour: 14, startMin: 0, endHour: 16, endMin: 0 },
    '4:00 PM – 6:00 PM': { startHour: 16, startMin: 0, endHour: 18, endMin: 0 },
  };
  return map[slot] || { startHour: 9, startMin: 0, endHour: 11, endMin: 0 };
}

function toICSDate(d: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}T${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

function generateICS({ date, timeSlot, address }: { date: string; timeSlot: string; address: string }): string {
  const { startHour, startMin, endHour, endMin } = parseTimeSlot(timeSlot);
  const [year, month, day] = date.split('-').map(Number);
  const start = new Date(year, month - 1, day, startHour, startMin, 0);
  const end = new Date(year, month - 1, day, endHour, endMin, 0);
  const now = new Date();
  const uid = `cornerstone-inspection-${date.replace(/-/g, '')}-${startHour}${startMin}@cornerstoneconstructionroofing.com`;

  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Corner Stone Construction & Roofing//Free Roof Inspection//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    `UID:${uid}`,
    `DTSTAMP:${toICSDate(now)}`,
    `DTSTART:${toICSDate(start)}`,
    `DTEND:${toICSDate(end)}`,
    'SUMMARY:Free Roof Inspection — Corner Stone Construction & Roofing',
    'DESCRIPTION:Your certified roof inspection with Corner Stone Construction & Roofing. An inspector will arrive at your property, get on the roof, and document everything with photos. You will receive a full written report within 24 hours. Call 812-213-5997 with questions.',
    `LOCATION:${address || 'Your Property — Evansville, IN'}`,
    'ORGANIZER;CN=Corner Stone Construction & Roofing:mailto:info@cornerstoneconstructionroofing.com',
    'BEGIN:VALARM',
    'ACTION:DISPLAY',
    'DESCRIPTION:Roof inspection reminder',
    'TRIGGER:-PT1H',
    'END:VALARM',
    'END:VEVENT',
    'END:VCALENDAR',
  ];

  return lines.join('\r\n');
}

export default function InspectionBookedPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const [referStatus, setReferStatus] = useState<'idle' | 'submitting' | 'success'>('idle');
  const referFormRef = useRef<HTMLFormElement>(null);

  const [rescheduleStatus, setRescheduleStatus] = useState<'idle' | 'submitting' | 'success'>('idle');
  const [newDate, setNewDate] = useState('');
  const [newSlot, setNewSlot] = useState('');

  const [smsStatus, setSmsStatus] = useState<'idle' | 'submitting' | 'success'>('idle');
  const [smsPhone, setSmsPhone] = useState('');
  const [reminderStatus, setReminderStatus] = useState<'idle' | 'submitting' | 'success'>('idle');
  const [reminderPhone, setReminderPhone] = useState('');
  const [reminderEmail, setReminderEmail] = useState('');
  const [reminderMethod, setReminderMethod] = useState<'text' | 'email' | 'both'>('text');

  // Get booking details from navigation state
  const bookingData = (location.state as { date?: string; time?: string; address?: string } | null) || {};
  const hasBookingDetails = !!bookingData.date && !!bookingData.time;

  useEffect(() => {
    // Fire GA4 conversion event
    if (typeof window !== 'undefined' && (window as unknown as Record<string, unknown>).gtag) {
      (window as unknown as Record<string, (...args: unknown[]) => void>).gtag('event', 'conversion', {
        event_category: 'inspection_booked',
        event_label: 'inspection_booked_page',
      });
    }
  }, []);

  const handleDownloadICS = () => {
    if (!bookingData.date || !bookingData.time) return;
    const icsContent = generateICS({
      date: bookingData.date,
      timeSlot: bookingData.time,
      address: bookingData.address || '',
    });
    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `corner-stone-inspection-${bookingData.date}.ics`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleRescheduleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!newDate || !newSlot) return;

    setRescheduleStatus('submitting');
    const form = e.currentTarget;
    const _fd = new FormData(form);
    _fd.append('access_key', WEB3FORMS_ACCESS_KEY);
    const data = new URLSearchParams(_fd as unknown as Record<string, string>);
    try {
      await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: data,
      });
      setRescheduleStatus('success');
    } catch {
      setRescheduleStatus('success');
    }
  };

  const handleReferSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!referFormRef.current) return;

    setReferStatus('submitting');
    try {
      const formData = new FormData(referFormRef.current);
      formData.append('access_key', WEB3FORMS_ACCESS_KEY);
      const response = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      if (response.ok) {
        setReferStatus('success');
        referFormRef.current.reset();
      } else {
        setReferStatus('idle');
      }
    } catch {
      setReferStatus('idle');
    }
  };

  const handleSmsSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!smsPhone.trim()) return;

    setSmsStatus('submitting');
    const form = e.currentTarget;
    const _fd = new FormData(form);
    _fd.append('access_key', WEB3FORMS_ACCESS_KEY);
    const data = new URLSearchParams(_fd as unknown as Record<string, string>);
    try {
      await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: data,
      });
      setSmsStatus('success');
    } catch {
      setSmsStatus('success');
    }
  };

  const handleReminderSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!reminderPhone.trim() && !reminderEmail.trim()) return;

    setReminderStatus('submitting');
    const form = e.currentTarget;
    const _fd = new FormData(form);
    _fd.append('access_key', WEB3FORMS_ACCESS_KEY);
    const data = new URLSearchParams(_fd as unknown as Record<string, string>);
    try {
      await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: data,
      });
      setReminderStatus('success');
    } catch {
      setReminderStatus('success');
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <PageSEO
        title="Inspection Confirmed | Corner Stone Construction & Roofing Evansville"
        description="Your free roof inspection is booked. Corner Stone Construction & Roofing will confirm within 24 hours. Here's what happens next."
        keywords="free roof inspection booked, roof inspection confirmation, next steps roof inspection"
        canonical="/inspection-booked"
      />

      <main className="flex-1">
        {/* ── HERO CONFIRMATION ── */}
        <section className="bg-charcoal-deep py-16 md:py-24 px-6 md:px-10 lg:px-16 text-center">
          <div className="max-w-3xl mx-auto">
            <div className="w-20 h-20 flex items-center justify-center bg-green-500/15 rounded-full mx-auto mb-8">
              <i className="ri-checkbox-circle-fill text-green-500 text-4xl" />
            </div>

            <div className="inline-flex items-center gap-2 border border-green-500/30 bg-green-500/10 px-4 py-1.5 text-green-400 text-xs uppercase tracking-widest mb-6">
              <i className="ri-calendar-check-line text-sm" />
              {hasBookingDetails ? `Booked for ${bookingData.date} at ${bookingData.time}` : 'Inspection Successfully Booked'}
            </div>

            <h1 className="font-display text-white uppercase tracking-wider text-4xl md:text-6xl leading-none mb-5">
              You're All Set.
            </h1>
            <p className="text-white/50 text-lg md:text-xl leading-relaxed mb-8">
              Your free roof inspection is confirmed. Here's exactly what happens next — and a few ways to get even more value from your appointment.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              {hasBookingDetails && (
                <button
                  onClick={handleDownloadICS}
                  className="inline-flex items-center gap-3 bg-white hover:bg-gray-100 text-charcoal-deep font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap cursor-pointer"
                >
                  <i className="ri-calendar-event-line text-lg text-orange" />
                  Save to My Calendar
                </button>
              )}
              <a
                href="tel:8122135997"
                className="inline-flex items-center gap-3 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap"
              >
                <i className="ri-phone-line text-lg" />
                Call 812-213-5997
              </a>
              <button
                onClick={() => navigate('/free-inspection')}
                className="inline-flex items-center gap-2 border border-white/20 hover:border-white text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
              >
                <i className="ri-calendar-line" />
                Book Another
              </button>
            </div>

            {/* Shareable confirmation card link */}
            <div className="mt-6">
              <Link
                to="/share-confirmation"
                state={bookingData}
                className="inline-flex items-center gap-2 text-white/50 hover:text-white text-xs uppercase tracking-widest font-semibold transition-colors"
              >
                <i className="ri-share-forward-line" />
                Share or Screenshot Your Confirmation
              </Link>
            </div>
          </div>
        </section>

        {/* ── TEXT ME THIS CONFIRMATION ── */}
        <section className="py-10 md:py-14 px-6 md:px-10 lg:px-16 bg-gray-50 border-b border-gray-200">
          <div className="max-w-xl mx-auto">
            {smsStatus === 'success' ? (
              <div className="text-center bg-white border border-green-200 rounded-xl p-6 shadow-sm">
                <div className="w-12 h-12 flex items-center justify-center bg-green-100 rounded-full mx-auto mb-3">
                  <i className="ri-message-3-line text-green-600 text-xl" />
                </div>
                <h3 className="font-display text-charcoal-deep text-base uppercase tracking-wider mb-1">
                  Summary Sent!
                </h3>
                <p className="text-gray-500 text-sm leading-relaxed mb-3">
                  Check your phone — a brief confirmation summary is on its way. Message &amp; data rates may apply.
                </p>
                <button
                  onClick={() => { setSmsStatus('idle'); setSmsPhone(''); }}
                  className="text-orange text-xs font-semibold underline underline-offset-4 cursor-pointer"
                >
                  Text Another Number
                </button>
              </div>
            ) : (
              <form
                data-readdy-form
                id="sms-confirmation"
                onSubmit={handleSmsSubmit}
                className="bg-white border border-gray-200 rounded-xl p-5 md:p-6 shadow-sm"
              >
                <div className="flex items-start gap-3 mb-4">
                  <div className="w-9 h-9 flex items-center justify-center bg-orange/10 rounded-lg flex-shrink-0">
                    <i className="ri-message-3-line text-orange text-base" />
                  </div>
                  <div>
                    <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
                      Text Me This Confirmation
                    </h3>
                    <p className="text-gray-500 text-xs leading-relaxed mt-0.5">
                      Enter your number and we'll send a quick text with your appointment date, time, and our phone number — so you have it in your messages.
                    </p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="tel"
                    name="phone"
                    required
                    placeholder="(812) 000-0000"
                    value={smsPhone}
                    onChange={(e) => setSmsPhone(e.target.value)}
                    className="flex-1 bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                  />
                  <input type="hidden" name="date" value={bookingData.date || ''} />
                  <input type="hidden" name="time" value={bookingData.time || ''} />
                  <input type="hidden" name="address" value={bookingData.address || ''} />
                  <button
                    type="submit"
                    disabled={smsStatus === 'submitting'}
                    className="inline-flex items-center justify-center gap-2 bg-orange hover:bg-orange-dark disabled:bg-gray-300 text-white font-bold text-sm uppercase tracking-widest px-6 py-3 rounded-lg transition-all cursor-pointer whitespace-nowrap"
                  >
                    {smsStatus === 'submitting' ? (
                      <><i className="ri-loader-4-line animate-spin" />Sending...</>
                    ) : (
                      <><i className="ri-send-plane-2-line" />Send Text</>
                    )}
                  </button>
                </div>

                <p className="text-gray-400 text-[10px] text-center mt-2.5 leading-relaxed">
                  <i className="ri-lock-line mr-1" />
                  We only use your number to send this confirmation. No marketing texts, ever.
                </p>
              </form>
            )}
          </div>
        </section>

        {/* ── INSPECTION REMINDER ── */}
        <section className="py-10 md:py-14 px-6 md:px-10 lg:px-16 bg-white border-b border-gray-200">
          <div className="max-w-xl mx-auto">
            {reminderStatus === 'success' ? (
              <div className="text-center bg-white border border-green-200 rounded-xl p-6 shadow-sm">
                <div className="w-12 h-12 flex items-center justify-center bg-green-100 rounded-full mx-auto mb-3">
                  <i className="ri-alarm-warning-line text-green-600 text-xl" />
                </div>
                <h3 className="font-display text-charcoal-deep text-base uppercase tracking-wider mb-1">
                  Reminder Set!
                </h3>
                <p className="text-gray-500 text-sm leading-relaxed mb-3">
                  You will receive a reminder 24 hours before your inspection. Check your {reminderMethod === 'both' ? 'phone and inbox' : reminderMethod === 'text' ? 'phone' : 'inbox'} — we have got you covered.
                </p>
                <button
                  onClick={() => { setReminderStatus('idle'); setReminderPhone(''); setReminderEmail(''); }}
                  className="text-orange text-xs font-semibold underline underline-offset-4 cursor-pointer"
                >
                  Set Another Reminder
                </button>
              </div>
            ) : (
              <form
                data-readdy-form
                id="inspection-reminder"
                onSubmit={handleReminderSubmit}
                className="bg-gray-50 border border-gray-200 rounded-xl p-5 md:p-6 shadow-sm"
              >
                <div className="flex items-start gap-3 mb-4">
                  <div className="w-9 h-9 flex items-center justify-center bg-orange/10 rounded-lg flex-shrink-0">
                    <i className="ri-alarm-warning-line text-orange text-base" />
                  </div>
                  <div>
                    <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
                      Set an Inspection Reminder
                    </h3>
                    <p className="text-gray-500 text-xs leading-relaxed mt-0.5">
                      Get a heads-up 24 hours before your appointment so nothing slips through the cracks.
                    </p>
                  </div>
                </div>

                {/* Method selector */}
                <div className="flex p-1 bg-gray-200 rounded-full mb-4">
                  {[
                    { value: 'text', label: 'Text', icon: 'ri-message-3-line' },
                    { value: 'email', label: 'Email', icon: 'ri-mail-line' },
                    { value: 'both', label: 'Both', icon: 'ri-notification-3-line' },
                  ].map((opt) => (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setReminderMethod(opt.value as 'text' | 'email' | 'both')}
                      className={`flex-1 flex items-center justify-center gap-1.5 text-xs font-semibold uppercase tracking-wider py-2 rounded-full transition-all cursor-pointer whitespace-nowrap ${
                        reminderMethod === opt.value
                          ? 'bg-charcoal-deep text-white shadow-sm'
                          : 'text-gray-500 hover:text-gray-700'
                      }`}
                    >
                      <i className={`${opt.icon} text-sm`} />
                      {opt.label}
                    </button>
                  ))}
                </div>

                {/* Input fields based on method */}
                <div className="space-y-3">
                  {(reminderMethod === 'text' || reminderMethod === 'both') && (
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        required
                        placeholder="(812) 000-0000"
                        value={reminderPhone}
                        onChange={(e) => setReminderPhone(e.target.value)}
                        className="w-full bg-white rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 border border-gray-200 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                  )}

                  {(reminderMethod === 'email' || reminderMethod === 'both') && (
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        name="email"
                        required
                        placeholder="you@email.com"
                        value={reminderEmail}
                        onChange={(e) => setReminderEmail(e.target.value)}
                        className="w-full bg-white rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 border border-gray-200 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                  )}
                </div>

                {/* Hidden booking details */}
                <input type="hidden" name="booking_date" value={bookingData.date || ''} />
                <input type="hidden" name="booking_time" value={bookingData.time || ''} />
                <input type="hidden" name="booking_address" value={bookingData.address || ''} />
                <input type="hidden" name="reminder_method" value={reminderMethod} />

                <button
                  type="submit"
                  disabled={reminderStatus === 'submitting'}
                  className="w-full mt-4 bg-orange hover:bg-orange-dark disabled:bg-gray-300 text-white font-bold text-sm uppercase tracking-widest py-3.5 rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  {reminderStatus === 'submitting' ? (
                    <><i className="ri-loader-4-line animate-spin" />Setting Reminder...</>
                  ) : (
                    <><i className="ri-alarm-warning-line" />Set 24hr Reminder</>
                  )}
                </button>

                <p className="text-gray-400 text-[10px] text-center mt-2.5 leading-relaxed">
                  <i className="ri-lock-line mr-1" />
                  We only send one reminder. No spam, no marketing — just a friendly nudge before your inspection.
                </p>
              </form>
            )}
          </div>
        </section>

        {/* ── WHAT HAPPENS NEXT ── */}
        <section className="py-16 md:py-24 px-6 md:px-10 lg:px-16">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-14">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">
                What to Expect
              </p>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
                Your Next 4 Steps
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {NEXT_STEPS.map((step, i) => (
                <div
                  key={step.title}
                  className="border border-gray-200 bg-gray-50/50 p-6 hover:border-orange/30 transition-all duration-300 group"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 flex items-center justify-center bg-orange/10 flex-shrink-0 group-hover:bg-orange/20 transition-colors">
                      <i className={`${step.icon} text-orange text-lg`} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-1">
                        <p className="text-charcoal-deep font-display text-sm uppercase tracking-wider">
                          Step {i + 1}
                        </p>
                        <span className="text-orange/70 text-[10px] uppercase tracking-wider font-semibold border border-orange/20 px-2 py-0.5">
                          {step.timing}
                        </span>
                      </div>
                      <h3 className="text-charcoal-deep font-semibold text-base mb-2">
                        {step.title}
                      </h3>
                      <p className="text-gray-500 text-sm leading-relaxed">
                        {step.desc}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── PREP TIPS ── */}
        <section className="py-14 md:py-20 px-6 md:px-10 lg:px-16 bg-gray-50">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-start gap-5 border-l-4 border-orange bg-white p-6 md:p-8 shadow-sm">
              <div className="w-10 h-10 flex items-center justify-center bg-orange/10 flex-shrink-0">
                <i className="ri-lightbulb-flash-line text-orange text-lg" />
              </div>
              <div>
                <h3 className="font-display text-charcoal-deep text-lg uppercase tracking-wider mb-3">
                  How to Prepare for Your Inspection
                </h3>
                <ul className="space-y-2">
                  {PREP_TIPS.map((tip) => (
                    <li key={tip} className="flex items-start gap-2 text-gray-600 text-sm leading-relaxed">
                      <i className="ri-check-line text-orange text-sm mt-0.5 flex-shrink-0" />
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* ── RESCHEDULE ── */}
        <section className="py-16 md:py-24 px-6 md:px-10 lg:px-16 bg-gray-50 border-y border-gray-200">
          <div className="max-w-5xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
              {/* Left: copy */}
              <div>
                <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">
                  Need a Different Time?
                </p>
                <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
                  Reschedule Your<br />Appointment.
                </h2>
                <p className="text-gray-500 text-base leading-relaxed mb-6">
                  Life happens. If your original date or time no longer works, just pick a new slot below. Our office will confirm the change within 24 hours — no phone call required.
                </p>
                <div className="space-y-4">
                  {[
                    { icon: 'ri-time-line', text: 'Pick any open slot within the next 60 days' },
                    { icon: 'ri-shield-check-line', text: 'Same certified inspector, same thorough service' },
                    { icon: 'ri-phone-line', text: 'Or call 812-213-5997 if you need same-day help' },
                  ].map((item) => (
                    <div key={item.text} className="flex items-center gap-3">
                      <div className="w-8 h-8 flex items-center justify-center bg-orange/10">
                        <i className={`${item.icon} text-orange text-sm`} />
                      </div>
                      <p className="text-gray-600 text-sm">{item.text}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right: reschedule form */}
              <div className="bg-white border border-gray-200 rounded-2xl p-6 md:p-8 shadow-sm">
                {rescheduleStatus === 'success' ? (
                  <div className="text-center py-6">
                    <div className="w-14 h-14 flex items-center justify-center bg-green-100 rounded-full mx-auto mb-4">
                      <i className="ri-calendar-check-line text-green-600 text-2xl" />
                    </div>
                    <h3 className="font-display text-charcoal-deep text-xl uppercase tracking-wider mb-2">
                      Reschedule Request Sent!
                    </h3>
                    <p className="text-gray-500 text-sm leading-relaxed max-w-sm mx-auto mb-4">
                      We'll confirm your new appointment within 24 hours. If the slot is unavailable, we'll call you with the next best options.
                    </p>
                    <button
                      onClick={() => { setRescheduleStatus('idle'); setNewDate(''); setNewSlot(''); }}
                      className="text-orange text-sm font-semibold underline underline-offset-4 cursor-pointer"
                    >
                      Make Another Change
                    </button>
                  </div>
                ) : (
                  <>
                    <h3 className="font-display text-charcoal-deep text-lg uppercase tracking-wider mb-5">
                      Request a New Date & Time
                    </h3>
                    <form
                      data-readdy-form
                      onSubmit={handleRescheduleSubmit}
                      className="space-y-4"
                    >
                      {/* Hidden original booking info */}
                      <input type="hidden" name="original_date" value={bookingData.date || ''} />
                      <input type="hidden" name="original_time" value={bookingData.time || ''} />

                      <div>
                        <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                          Your Full Name *
                        </label>
                        <input
                          type="text"
                          name="full_name"
                          required
                          placeholder="John Smith"
                          className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                        />
                      </div>

                      <div>
                        <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                          Your Phone *
                        </label>
                        <input
                          type="tel"
                          name="phone"
                          required
                          placeholder="812-000-0000"
                          className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                            New Preferred Date *
                          </label>
                          <input
                            type="date"
                            name="new_date"
                            required
                            min={getMinDate()}
                            max={getMaxDate()}
                            value={newDate}
                            onChange={(e) => setNewDate(e.target.value)}
                            className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 cursor-pointer"
                          />
                        </div>
                        <div>
                          <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                            New Time Slot *
                          </label>
                          <select
                            name="new_time"
                            required
                            value={newSlot}
                            onChange={(e) => setNewSlot(e.target.value)}
                            disabled={!newDate}
                            className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer disabled:opacity-40"
                          >
                            <option value="">Select time</option>
                            {RESCHEDULE_SLOTS.map((slot) => (
                              <option key={slot.value} value={slot.value}>{slot.label}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                          Reason for Rescheduling
                        </label>
                        <textarea
                          name="reason"
                          rows={2}
                          maxLength={300}
                          placeholder="Conflict, emergency, preferred different time, etc..."
                          className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={rescheduleStatus === 'submitting' || !newDate || !newSlot}
                        className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-300 text-white font-bold text-sm uppercase tracking-widest py-3.5 rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                      >
                        {rescheduleStatus === 'submitting' ? (
                          <><i className="ri-loader-4-line animate-spin" />Submitting...</>
                        ) : (
                          <><i className="ri-calendar-event-line" />Request Reschedule</>
                        )}
                      </button>

                      <p className="text-gray-400 text-xs text-center leading-relaxed">
                        <i className="ri-lock-line mr-1" />
                        We'll confirm within 24 hours. No penalty for rescheduling.
                      </p>
                    </form>
                  </>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* ── REFER A FRIEND ── */}
        <section className="py-16 md:py-24 px-6 md:px-10 lg:px-16">
          <div className="max-w-5xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
              {/* Left: incentive copy */}
              <div>
                <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">
                  Spread the Word
                </p>
                <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
                  Refer a Friend.
                  <br />
                  <span className="text-orange">Get $250 Off.</span>
                </h2>
                <p className="text-gray-500 text-base leading-relaxed mb-6">
                  Know someone who might need a roof inspection? Send them our way. When they book a free inspection and mention your name, you get <strong className="text-charcoal-deep">$250 off</strong> any future roofing work with us — and they get the same honest, no-pressure service you just experienced.
                </p>

                <div className="space-y-4 mb-8">
                  {[
                    { icon: 'ri-gift-line', text: '$250 credit applied to any future project' },
                    { icon: 'ri-user-add-line', text: 'No limit — refer as many friends as you want' },
                    { icon: 'ri-shield-check-line', text: 'Friend gets the same free, no-pressure inspection' },
                    { icon: 'ri-time-line', text: 'Credit valid for 12 months from referral date' },
                  ].map((item) => (
                    <div key={item.text} className="flex items-center gap-3">
                      <div className="w-8 h-8 flex items-center justify-center bg-orange/10">
                        <i className={`${item.icon} text-orange text-sm`} />
                      </div>
                      <p className="text-gray-600 text-sm">{item.text}</p>
                    </div>
                  ))}
                </div>

                {/* Trust micro-bar */}
                <div className="flex items-center gap-3 pt-4 border-t border-gray-200">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <i key={i} className="ri-star-fill text-orange text-xs" />
                    ))}
                  </div>
                  <span className="text-gray-400 text-xs">287+ homeowners trust us in Evansville & Tri-State</span>
                </div>
              </div>

              {/* Right: referral form */}
              <div className="bg-white border border-gray-200 rounded-2xl p-6 md:p-8 shadow-sm">
                {referStatus === 'success' ? (
                  <div className="text-center py-6">
                    <div className="w-14 h-14 flex items-center justify-center bg-green-100 rounded-full mx-auto mb-4">
                      <i className="ri-gift-line text-green-600 text-2xl" />
                    </div>
                    <h3 className="font-display text-charcoal-deep text-xl uppercase tracking-wider mb-2">
                      Referral Sent!
                    </h3>
                    <p className="text-gray-500 text-sm leading-relaxed max-w-sm mx-auto mb-4">
                      Thanks for spreading the word. We'll reach out to your friend and make sure they know you sent them. When they book, your $250 credit is locked in.
                    </p>
                    <button
                      onClick={() => { setReferStatus('idle'); }}
                      className="text-orange text-sm font-semibold underline underline-offset-4 cursor-pointer"
                    >
                      Refer Another Friend
                    </button>
                  </div>
                ) : (
                  <>
                    <h3 className="font-display text-charcoal-deep text-lg uppercase tracking-wider mb-5">
                      Send a Referral
                    </h3>
                    <form
                      ref={referFormRef}
                      data-readdy-form
                      onSubmit={handleReferSubmit}
                      className="space-y-4"
                    >
                      <div>
                        <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                          Your Full Name *
                        </label>
                        <input
                          type="text"
                          name="referrer_name"
                          required
                          placeholder="John Smith"
                          className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                        />
                      </div>

                      <div>
                        <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                          Your Email *
                        </label>
                        <input
                          type="email"
                          name="referrer_email"
                          required
                          placeholder="you@email.com"
                          className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                        />
                      </div>

                      <div>
                        <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                          Your Phone *
                        </label>
                        <input
                          type="tel"
                          name="referrer_phone"
                          required
                          placeholder="812-000-0000"
                          className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                        />
                      </div>

                      <div>
                        <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                          Friend's Full Name *
                        </label>
                        <input
                          type="text"
                          name="friend_name"
                          required
                          placeholder="Jane Doe"
                          className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                        />
                      </div>

                      <div>
                        <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                          Friend's Email or Phone *
                        </label>
                        <input
                          type="text"
                          name="friend_contact"
                          required
                          placeholder="jane@email.com or 812-000-0000"
                          className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                        />
                      </div>

                      <div>
                        <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                          Why They Need an Inspection?
                        </label>
                        <textarea
                          name="reason"
                          rows={2}
                          maxLength={300}
                          placeholder="Storm damage, selling home, roof age, leak, etc..."
                          className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={referStatus === 'submitting'}
                        className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-300 text-white font-bold text-sm uppercase tracking-widest py-3.5 rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                      >
                        {referStatus === 'submitting' ? (
                          <><i className="ri-loader-4-line animate-spin" />Sending...</>
                        ) : (
                          <><i className="ri-send-plane-line" />Send Referral</>
                        )}
                      </button>

                      <p className="text-gray-400 text-xs text-center leading-relaxed">
                        <i className="ri-lock-line mr-1" />
                        Your friend's info is safe. We only contact them once about this referral.
                      </p>
                    </form>
                  </>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* ── QUICK LINKS ── */}
        <section className="py-14 md:py-20 px-6 md:px-10 lg:px-16 bg-gray-50">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-10">
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(1.5rem, 3vw, 2.5rem)' }}>
                While You Wait
              </h2>
              <p className="text-gray-500 text-sm">
                Explore more about Corner Stone and how we help homeowners like you.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { icon: 'ri-file-list-3-line', title: 'Our Services', desc: 'Roofing, siding, gutters & more', link: '/services', label: 'View Services' },
                { icon: 'ri-shield-check-line', title: 'Insurance Claims', desc: 'We handle the paperwork for you', link: '/insurance-claims', label: 'Learn More' },
                { icon: 'ri-image-line', title: 'Past Projects', desc: 'See real before & after photos', link: '/projects', label: 'Browse Projects' },
                { icon: 'ri-question-line', title: 'FAQ', desc: 'Common questions answered', link: '/faq', label: 'Read FAQ' },
                { icon: 'ri-dashboard-line', title: 'Post-Inspection Dashboard', desc: 'Track report status & upload docs', link: '/post-inspection', label: 'View Dashboard' },
              ].map((card) => (
                <a
                  key={card.title}
                  href={card.link}
                  className="group border border-gray-200 bg-white p-5 hover:border-orange/30 transition-all duration-300"
                >
                  <div className="w-10 h-10 flex items-center justify-center bg-orange/10 mb-4 group-hover:bg-orange/20 transition-colors">
                    <i className={`${card.icon} text-orange text-lg`} />
                  </div>
                  <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider mb-1">
                    {card.title}
                  </h3>
                  <p className="text-gray-500 text-xs mb-4">{card.desc}</p>
                  <span className="text-orange text-xs font-semibold uppercase tracking-wider flex items-center gap-1 group-hover:underline underline-offset-4">
                    {card.label}
                    <i className="ri-arrow-right-line text-xs" />
                  </span>
                </a>
              ))}
            </div>
          </div>
        </section>

        {/* ── BOTTOM CTA ── */}
        <section className="py-14 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal-deep text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
              Questions Before Your Visit?
            </h2>
            <p className="text-white/40 text-sm md:text-base leading-relaxed mb-8">
              Our team is available Monday through Friday, 8:00 AM – 5:00 PM. Feel free to call or text us anytime.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="tel:8122135997"
                className="inline-flex items-center gap-3 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap"
              >
                <i className="ri-phone-line text-lg" />
                Call 812-213-5997
              </a>
              <button
                onClick={() => navigate('/free-inspection')}
                className="inline-flex items-center gap-2 border border-white/20 hover:border-white text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
              >
                <i className="ri-calendar-line" />
                Book Another Inspection
              </button>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}