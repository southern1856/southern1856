import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { OFFERS } from '@/mocks/promotions';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const financingSchema = {
  '@context': 'https://schema.org',
  '@type': 'FinancialProduct',
  name: 'Roof Replacement Financing Evansville Indiana',
  provider: {
    '@type': 'RoofingContractor',
    name: 'Corner Stone Construction & Roofing',
    telephone: '+1-812-213-5997',
    address: {
      '@type': 'PostalAddress',
      streetAddress: '5800 Kansas Rd',
      addressLocality: 'Evansville',
      addressRegion: 'IN',
      postalCode: '47725',
    },
  },
  description: 'Flexible roof financing options for Evansville Indiana homeowners. 0% interest plans, low monthly payments starting at $89/month, and 90-day deferred options. Same-day approval. No prepayment penalties.',
  areaServed: ['Evansville IN', 'Henderson KY', 'Newburgh IN', 'Owensboro KY', 'Tri-State Area'],
};

const faqSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: [
    {
      '@type': 'Question',
      name: 'Can I finance a roof replacement in Evansville Indiana?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Yes. Corner Stone offers flexible roof financing options for Evansville homeowners including 0% interest plans, low monthly payments starting at $89/month, and 90-day deferred payment options. Same-day approval is available.',
      },
    },
    {
      '@type': 'Question',
      name: 'What credit score do I need to finance a roof?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'We work with multiple lenders to find options for a wide range of credit profiles. Many customers with scores as low as 580 have been approved. We encourage everyone to apply — the initial check is a soft pull that does not affect your credit score.',
      },
    },
    {
      '@type': 'Question',
      name: 'How much does a roof replacement cost in Evansville Indiana?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Most residential roof replacements in Evansville range from $8,000 to $18,000 depending on home size, pitch, and material choice. With financing starting at $89/month, most homeowners can afford a full replacement without draining savings.',
      },
    },
  ],
};

const PLANS = [
  {
    id: 'same-cash',
    name: 'Same-As-Cash',
    tag: 'Most Popular',
    highlight: true,
    rate: '0%',
    rateLabel: 'Interest',
    term: '12 Months',
    minAmount: '$2,000',
    monthlyExample: '$167/mo',
    exampleNote: 'on $2,000 project',
    desc: 'Pay nothing extra if paid in full within 12 months. Perfect for smaller repairs or homeowners who want flexibility without long-term commitment.',
    features: [
      'No interest if paid in full within 12 months',
      'Monthly payment as low as $167',
      'Same-day approval decision',
      'No prepayment penalty',
      'Soft credit check to apply',
    ],
    icon: 'ri-percent-line',
    color: 'orange',
  },
  {
    id: 'low-monthly',
    name: 'Low Monthly',
    tag: 'Best for Full Replacements',
    highlight: false,
    rate: '$89',
    rateLabel: '/ Month',
    term: 'Up to 120 Months',
    minAmount: '$3,000',
    monthlyExample: '$89/mo',
    exampleNote: 'starting payment',
    desc: 'Spread your roof replacement over up to 10 years with predictable monthly payments. Great for full replacements where upfront cost is a concern.',
    features: [
      'Terms from 24 to 120 months',
      'Fixed monthly payments',
      'Covers full replacement cost',
      'Soft credit check to apply',
      'No prepayment penalty',
    ],
    icon: 'ri-calendar-line',
    color: 'white',
  },
  {
    id: 'deferred',
    name: 'Deferred Payment',
    tag: 'No Payments Now',
    highlight: false,
    rate: '90',
    rateLabel: 'Days No Payment',
    term: 'Then Low Rate',
    minAmount: '$5,000',
    monthlyExample: '$0 now',
    exampleNote: 'for 90 days',
    desc: 'Get your roof done today and make no payments for 90 days. Ideal after a storm when insurance is still processing your claim.',
    features: [
      '90-day payment deferral',
      'No payments while claim processes',
      'Competitive rate after deferral',
      'Works alongside insurance payout',
      'No prepayment penalty',
    ],
    icon: 'ri-time-line',
    color: 'white',
  },
];

const FAQS = [
  {
    q: 'Can I finance a roof replacement in Evansville Indiana?',
    a: 'Yes. We offer flexible roof financing options for Evansville homeowners including 0% interest plans, low monthly payments starting at $89/month, and 90-day deferred payment options. Same-day approval is available for most applicants.',
  },
  {
    q: 'What credit score do I need to qualify for roof financing?',
    a: 'We work with multiple lenders to find options for a wide range of credit profiles. Many customers with scores as low as 580 have been approved. The initial application uses a soft credit pull that does not affect your score.',
  },
  {
    q: 'How much does a roof replacement cost in Evansville?',
    a: 'Most residential roof replacements in Evansville range from $8,000 to $18,000 depending on home size, pitch, and material choice. With financing starting at $89/month, most homeowners can afford a full replacement without draining savings.',
  },
  {
    q: 'Can I finance storm damage repairs while my insurance claim is processing?',
    a: 'Absolutely. Our 90-day deferred payment plan is specifically designed for this situation. Get your roof fixed now, make no payments for 90 days, and use your insurance payout when it arrives to cover the cost.',
  },
  {
    q: 'How long does financing approval take?',
    a: 'Most applicants receive a decision within minutes. In some cases it may take up to 24 hours. We walk you through the entire process during your free estimate — no surprises.',
  },
  {
    q: 'Is there a minimum project size for roof financing?',
    a: 'Financing is available for projects starting at $2,000. This covers most repairs and all full replacements. There is no maximum — we can finance projects of any size.',
  },
  {
    q: 'Can I pay off my roof loan early?',
    a: 'Yes — there are no prepayment penalties on any of our financing plans. Pay it off early and save on interest. Many customers pay off their 0% plan before the 12-month window closes.',
  },
  {
    q: 'Does applying for financing affect my credit score?',
    a: 'The initial application uses a soft credit pull, which does not affect your credit score. A hard pull is only done if you proceed with a specific loan offer and give your consent.',
  },
];

const LENDER_LOGOS = [
  { name: 'GreenSky', icon: 'ri-bank-line' },
  { name: 'Synchrony', icon: 'ri-secure-payment-line' },
  { name: 'EnerBank', icon: 'ri-building-2-line' },
  { name: 'Service Finance', icon: 'ri-funds-line' },
];

function PaymentCalculator() {
  const [amount, setAmount] = useState(10000);
  const [term, setTerm] = useState(60);
  const [rate, setRate] = useState(9.99);

  const monthly = useCallback(() => {
    if (rate === 0) return (amount / term).toFixed(2);
    const r = rate / 100 / 12;
    const payment = (amount * r * Math.pow(1 + r, term)) / (Math.pow(1 + r, term) - 1);
    return payment.toFixed(2);
  }, [amount, term, rate]);

  const totalCost = useCallback(() => {
    return (parseFloat(monthly()) * term).toFixed(0);
  }, [monthly, term]);

  const totalInterest = useCallback(() => {
    return (parseFloat(totalCost()) - amount).toFixed(0);
  }, [totalCost, amount]);

  return (
    <div className="bg-charcoal-mid border border-white/10 p-8 md:p-10">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 flex items-center justify-center bg-orange/20">
          <i className="ri-calculator-line text-orange text-lg" />
        </div>
        <div>
          <h3 className="font-display text-white text-xl uppercase tracking-wider">Payment Calculator</h3>
          <p className="text-white/40 text-xs">Estimate your monthly payment</p>
        </div>
      </div>

      <div className="space-y-6 mb-8">
        {/* Loan Amount */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-white/60 text-xs uppercase tracking-wider font-semibold">Loan Amount</label>
            <span className="font-display text-orange text-xl tracking-wider">${amount.toLocaleString()}</span>
          </div>
          <input
            type="range"
            min={2000}
            max={30000}
            step={500}
            value={amount}
            onChange={(e) => setAmount(Number(e.target.value))}
            className="w-full h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-orange"
          />
          <div className="flex justify-between text-white/20 text-xs mt-1">
            <span>$2,000</span>
            <span>$30,000</span>
          </div>
        </div>

        {/* Term */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-white/60 text-xs uppercase tracking-wider font-semibold">Loan Term</label>
            <span className="font-display text-orange text-xl tracking-wider">{term} months</span>
          </div>
          <input
            type="range"
            min={12}
            max={120}
            step={12}
            value={term}
            onChange={(e) => setTerm(Number(e.target.value))}
            className="w-full h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-orange"
          />
          <div className="flex justify-between text-white/20 text-xs mt-1">
            <span>12 mo</span>
            <span>120 mo</span>
          </div>
        </div>

        {/* Rate */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-white/60 text-xs uppercase tracking-wider font-semibold">Interest Rate (APR)</label>
            <span className="font-display text-orange text-xl tracking-wider">{rate}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={24.99}
            step={0.5}
            value={rate}
            onChange={(e) => setRate(Number(e.target.value))}
            className="w-full h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-orange"
          />
          <div className="flex justify-between text-white/20 text-xs mt-1">
            <span>0% (promo)</span>
            <span>24.99%</span>
          </div>
        </div>
      </div>

      {/* Result */}
      <div className="border-t border-white/10 pt-6">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <p className="font-display text-orange text-3xl md:text-4xl tracking-wider">${monthly()}</p>
            <p className="text-white/40 text-xs uppercase tracking-wider mt-1">Per Month</p>
          </div>
          <div>
            <p className="font-display text-white text-3xl md:text-4xl tracking-wider">${Number(totalCost()).toLocaleString()}</p>
            <p className="text-white/40 text-xs uppercase tracking-wider mt-1">Total Cost</p>
          </div>
          <div>
            <p className="font-display text-white/50 text-3xl md:text-4xl tracking-wider">${Number(totalInterest()).toLocaleString()}</p>
            <p className="text-white/40 text-xs uppercase tracking-wider mt-1">Total Interest</p>
          </div>
        </div>
        <p className="text-white/20 text-xs text-center mt-4">
          Estimate only. Actual rate depends on credit profile and lender. Subject to approval.
        </p>
      </div>
    </div>
  );
}

export default function RoofFinancingPage() {
  const navigate = useNavigate();
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [activePlan, setActivePlan] = useState(PLANS[0].id);
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [charCount, setCharCount] = useState(0);
  const formRef = useRef<HTMLFormElement>(null);

  const hero = useScrollAnimation();
  const plans = useScrollAnimation({ threshold: 0.05 });
  const calc = useScrollAnimation({ threshold: 0.05 });
  const why = useScrollAnimation({ threshold: 0.1 });
  const faqAnim = useScrollAnimation({ threshold: 0.1 });
  const formAnim = useScrollAnimation({ threshold: 0.1 });

  const nearestExpiry = useMemo(() => {
    const expiring = OFFERS.filter((o) => o.expires).sort((a, b) => new Date(a.expires!).getTime() - new Date(b.expires!).getTime());
    return expiring[0]?.expires ?? null;
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;
    const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
    const notes = formData.get('notes') as string;
    if (notes && notes.length > 500) return;
    setFormStatus('submitting');
    try {
      const res = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      if (res.ok) { setFormStatus('success'); formRef.current.reset(); setCharCount(0); }
      else setFormStatus('error');
    } catch { setFormStatus('error'); }
  };

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roof Financing Evansville Indiana | 0% Interest & $89/Month | Corner Stone"
        description="Roof replacement financing in Evansville Indiana. 0% interest plans, payments from $89/month, 90-day deferred options for storm damage. Same-day approval. Serving Evansville IN, Henderson KY & Tri-State. Call 812-213-5997."
        keywords="roof financing Evansville Indiana, roof replacement financing Evansville, roofing payment plan Indiana, 0% interest roof loan Evansville, affordable roof replacement Henderson KY, finance new roof Tri-State, roof loan Indiana"
        canonical="/roof-financing"
        schema={[financingSchema, faqSchema]}
      />

      {/* ── Hero ── */}
      <section className="relative min-h-screen flex flex-col overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1400x900.svg"
            alt="Roof financing Evansville Indiana"
            className="w-full h-full object-cover object-top opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/70 via-charcoal-deep/50 to-charcoal-deep" />
          <div className="absolute inset-0 opacity-[0.025]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '80px 80px' }} />
        </div>

        <div
          ref={hero.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 flex-1 flex flex-col justify-center px-6 md:px-10 lg:px-16 pt-32 md:pt-36 pb-16 anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-wrap items-center gap-3 mb-8">
            <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange" />
              Same-Day Approval
            </div>
            <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange" />
              Soft Credit Check Only
            </div>
            <div className="flex items-center gap-2 border border-orange/40 bg-orange/10 backdrop-blur-sm px-4 py-2 text-orange text-xs uppercase tracking-widest">
              <i className="ri-percent-line text-sm" />
              0% Interest Available
            </div>
          </div>

          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 9vw, 10rem)' }}>
            New Roof.<br />No Excuses.<br /><span className="text-orange">$89/Month.</span>
          </h1>

          <div className="flex flex-col lg:flex-row lg:items-end gap-8 lg:gap-16">
            <p className="text-white/50 text-base md:text-lg max-w-xl leading-relaxed">
              Don't let cost stand between you and a safe, solid roof. Evansville and Henderson KY homeowners can get approved for roof replacement financing today — with plans starting at $89/month and 0% interest options available.
            </p>

            <div className="w-full max-w-xl flex flex-col gap-3">
              <CountdownTimer expiresAt={nearestExpiry ?? new Date(Date.now() + 86400000 * 3).toISOString()} variant="banner" />
              <SocialProofPulse />
            </div>

            <div className="flex flex-col sm:flex-row gap-4 flex-shrink-0">
              <button
                onClick={() => document.getElementById('fin-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <i className="ri-bank-card-line" />
                Check My Options
              </button>
              <a
                href="tel:8122135997"
                className="border border-white/30 hover:border-orange text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-phone-line text-orange" />
                812-213-5997
              </a>
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div className="relative z-10 border-t border-white/10 grid grid-cols-2 md:grid-cols-4">
          {[
            { val: '0%', label: 'Interest Available' },
            { val: '$89', label: 'Starting / Month' },
            { val: '90 Days', label: 'Deferred Option' },
            { val: '10 Min', label: 'Avg. Approval Time' },
          ].map((s, i) => (
            <div key={s.label} className={`px-6 md:px-10 py-6 md:py-8 ${i < 3 ? 'border-r border-white/10' : ''}`}>
              <p className="font-display text-orange text-3xl md:text-4xl tracking-wider">{s.val}</p>
              <p className="text-white/40 text-xs uppercase tracking-widest mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Urgency Banner ── */}
      <section className="bg-orange/10 border-y border-orange/20 py-5 px-6 md:px-10 lg:px-16">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 flex items-center justify-center bg-orange/20 flex-shrink-0">
              <i className="ri-alarm-warning-line text-orange text-lg" />
            </div>
            <div>
              <p className="text-white font-semibold text-sm">A leaking roof costs more every day you wait.</p>
              <p className="text-white/50 text-xs">Water damage compounds fast — a $9K roof job can become a $25K structural repair in 6 months.</p>
            </div>
          </div>
          <button
            onClick={() => document.getElementById('fin-form')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-orange hover:bg-orange-dark text-white text-xs font-bold uppercase tracking-widest px-6 py-3 transition-colors whitespace-nowrap cursor-pointer flex-shrink-0"
          >
            Fix It Now — Check Financing
          </button>
        </div>
      </section>

      {/* ── Plans ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Payment Plans</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
            Three Ways to Pay.<br />Zero Excuses to Wait.
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Every plan is designed around real homeowner situations in Evansville and Henderson KY. Pick what works for you.
          </p>
        </div>

        <div
          ref={plans.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {PLANS.map((plan, i) => (
            <div
              key={plan.id}
              onClick={() => setActivePlan(plan.id)}
              className={`relative flex flex-col border transition-all duration-300 cursor-pointer anim-fade-up ${plans.isVisible ? 'is-visible' : ''} ${
                activePlan === plan.id
                  ? 'border-orange bg-orange/8'
                  : 'border-white/10 bg-charcoal-mid hover:border-white/30'
              }`}
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              {/* Tag */}
              <div className={`text-xs font-bold uppercase tracking-widest px-4 py-2.5 text-center ${plan.highlight ? 'bg-orange text-white' : 'bg-white/5 text-white/40'}`}>
                {plan.tag}
              </div>

              <div className="p-8 flex flex-col flex-1">
                {/* Rate display */}
                <div className="flex items-end gap-2 mb-1">
                  <span className={`font-display text-5xl uppercase tracking-wider leading-none ${activePlan === plan.id ? 'text-orange' : 'text-white'}`}>
                    {plan.rate}
                  </span>
                  <span className="text-white/40 text-sm mb-2">{plan.rateLabel}</span>
                </div>
                <p className="text-white/30 text-xs uppercase tracking-widest mb-1">{plan.term}</p>
                <p className="text-white/25 text-xs mb-6">Min. project: {plan.minAmount}</p>

                <div className="w-10 h-10 flex items-center justify-center bg-orange/15 mb-4">
                  <i className={`${plan.icon} text-orange text-lg`} />
                </div>

                <h3 className="font-display text-white text-2xl uppercase tracking-wider mb-3">{plan.name}</h3>
                <p className="text-white/40 text-sm leading-relaxed mb-6 flex-1">{plan.desc}</p>

                {/* Example payment pill */}
                <div className="bg-orange/10 border border-orange/20 px-4 py-3 mb-6 flex items-center justify-between">
                  <span className="text-white/50 text-xs uppercase tracking-wider">Example</span>
                  <div className="text-right">
                    <span className="font-display text-orange text-lg tracking-wider">{plan.monthlyExample}</span>
                    <span className="text-white/30 text-xs ml-2">{plan.exampleNote}</span>
                  </div>
                </div>

                <ul className="space-y-2.5 mb-8">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-white/50 text-xs">
                      <i className="ri-check-line text-orange text-sm mt-0.5 flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={(e) => { e.stopPropagation(); document.getElementById('fin-form')?.scrollIntoView({ behavior: 'smooth' }); }}
                  className={`w-full py-3.5 text-sm font-semibold uppercase tracking-widest transition-colors whitespace-nowrap cursor-pointer ${
                    plan.highlight
                      ? 'bg-orange hover:bg-orange-dark text-white'
                      : 'border border-white/20 hover:border-orange text-white/70 hover:text-white'
                  }`}
                >
                  Apply for This Plan
                </button>
              </div>
            </div>
          ))}
        </div>

        <p className="text-center text-white/20 text-xs mt-8">
          Subject to credit approval. Rates and terms vary by lender and credit profile. Ask us for details during your free estimate.
        </p>
      </section>

      {/* ── Payment Calculator ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Estimate Your Payment</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              See What Your<br />Roof Costs<br /><span className="text-orange">Per Month.</span>
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
              Use the calculator to estimate your monthly payment based on your project size, loan term, and interest rate. Most Evansville homeowners are surprised how affordable a new roof can be.
            </p>
            <div className="space-y-4 mb-8">
              {[
                { icon: 'ri-home-2-line', label: 'Average Evansville roof replacement', value: '$9,500 – $14,000' },
                { icon: 'ri-calendar-line', label: 'Most popular term', value: '60 months (5 years)' },
                { icon: 'ri-percent-line', label: '0% promo rate available', value: 'For qualified buyers' },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between border border-white/10 bg-charcoal-mid px-5 py-4">
                  <div className="flex items-center gap-3">
                    <i className={`${item.icon} text-orange text-base`} />
                    <span className="text-white/50 text-sm">{item.label}</span>
                  </div>
                  <span className="text-white text-sm font-semibold">{item.value}</span>
                </div>
              ))}
            </div>
            <button
              onClick={() => document.getElementById('fin-form')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap"
            >
              <i className="ri-bank-card-line" />
              Apply for Financing
            </button>
          </div>

          <div ref={calc.ref as React.RefObject<HTMLDivElement>} className={`anim-fade-up ${calc.isVisible ? 'is-visible' : ''}`}>
            <PaymentCalculator />
          </div>
        </div>
      </section>

      {/* ── Why Finance Now ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Don't Wait</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Why Finance Now<br />Instead of Later
          </h2>
        </div>

        <div
          ref={why.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {[
            {
              icon: 'ri-water-flash-line',
              title: 'Water Damage Compounds',
              desc: 'A small leak ignored for 6 months can turn a $9K roof job into a $25K structural repair. Every storm season you wait increases the risk.',
            },
            {
              icon: 'ri-line-chart-line',
              title: 'Material Costs Keep Rising',
              desc: 'Roofing materials have increased 15–30% over the past 3 years. Locking in today\'s price with financing protects you from future cost increases.',
            },
            {
              icon: 'ri-home-heart-line',
              title: 'Protect Your Home\'s Value',
              desc: 'A failing roof is the #1 red flag for home buyers. Financing a replacement now protects your equity and keeps your home market-ready.',
            },
            {
              icon: 'ri-shield-check-line',
              title: 'Insurance May Not Wait',
              desc: 'Insurance companies can deny claims on roofs that show "deferred maintenance." Financing lets you fix it before your policy is at risk.',
            },
            {
              icon: 'ri-money-dollar-circle-line',
              title: 'Keep Your Savings Intact',
              desc: 'Why drain your emergency fund on a roof when you can finance at 0% and keep your savings working for you? Smart homeowners finance.',
            },
            {
              icon: 'ri-sun-line',
              title: 'Beat Storm Season',
              desc: 'Indiana storm season peaks April–September. Get your roof replaced before the next hail event — not after. Financing makes it possible now.',
            },
          ].map((item, i) => (
            <div
              key={item.title}
              className={`border border-white/10 bg-charcoal-mid p-8 hover:border-orange/30 transition-all duration-300 group anim-fade-up ${why.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="w-12 h-12 flex items-center justify-center bg-orange/15 group-hover:bg-orange/25 transition-colors mb-5">
                <i className={`${item.icon} text-orange text-xl`} />
              </div>
              <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">{item.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Lender Trust + Testimonial ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Trusted Lenders</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              We Work With<br />Top Lenders to<br /><span className="text-orange">Get You Approved.</span>
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
              We partner with multiple financing companies to find the best rate and terms for your credit profile. Even if one lender says no, another may say yes. We fight to get you approved.
            </p>
            <div className="grid grid-cols-2 gap-3 mb-8">
              {LENDER_LOGOS.map((l) => (
                <div key={l.name} className="border border-white/10 bg-charcoal-mid px-5 py-4 flex items-center gap-3 hover:border-orange/30 transition-colors">
                  <div className="w-8 h-8 flex items-center justify-center">
                    <i className={`${l.icon} text-orange text-lg`} />
                  </div>
                  <span className="text-white/60 text-sm font-semibold">{l.name}</span>
                </div>
              ))}
            </div>
            <div className="flex items-center gap-4 text-white/30 text-xs">
              <i className="ri-lock-line text-orange" />
              <span>Soft credit check only — applying does not affect your score</span>
            </div>
          </div>

          <div className="relative">
            <div className="w-full overflow-hidden" style={{ height: '460px' }}>
              <img
                src="/placeholders/700x460.svg"
                alt="Happy homeowners with new roof financing Evansville"
                className="w-full h-full object-cover object-top"
              />
            </div>
            <div className="absolute bottom-6 left-6 right-6 bg-charcoal-deep/92 border border-white/10 p-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 flex items-center justify-center bg-orange/20 flex-shrink-0 mt-0.5">
                  <i className="ri-double-quotes-l text-orange text-lg" />
                </div>
                <div>
                  <p className="text-white/70 text-sm leading-relaxed italic mb-3">
                    "We thought we'd have to wait another year. Corner Stone got us approved in 15 minutes and our roof was done the next week. $127 a month — totally manageable."
                  </p>
                  <div className="flex items-center gap-2">
                    <div className="flex gap-0.5">
                      {[...Array(5)].map((_, i) => (
                        <i key={i} className="ri-star-fill text-orange text-xs" />
                      ))}
                    </div>
                    <span className="text-orange text-xs font-semibold uppercase tracking-wider">— Sarah M., Newburgh IN</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Common Questions</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Roof Financing FAQ
            </h2>
          </div>
          <div
            ref={faqAnim.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${faqAnim.isVisible ? 'is-visible' : ''}`}
          >
            {FAQS.map((faq, i) => (
              <div key={i} className="border-b border-white/10">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between py-5 text-left cursor-pointer group"
                >
                  <span className="font-display text-white text-base md:text-lg uppercase tracking-wider pr-4 group-hover:text-orange transition-colors">{faq.q}</span>
                  <div className={`w-8 h-8 flex items-center justify-center border flex-shrink-0 transition-all duration-300 ${openFaq === i ? 'bg-orange border-orange text-white' : 'border-white/20 text-white/40 group-hover:border-orange group-hover:text-orange'}`}>
                    <i className={`ri-${openFaq === i ? 'subtract' : 'add'}-line`} />
                  </div>
                </button>
                <div className={`overflow-hidden transition-all duration-500 ${openFaq === i ? 'max-h-48 opacity-100 pb-5' : 'max-h-0 opacity-0'}`}>
                  <p className="text-white/50 text-sm leading-relaxed pr-12">{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Application Form ── */}
      <section id="fin-form" className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div
          ref={formAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${formAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {/* Left copy */}
            <div>
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Get Pre-Qualified</p>
              <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 5vw, 5rem)' }}>
                Check Your<br />Financing<br /><span className="text-orange">Options.</span>
              </h2>
              <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
                Fill out the form and our financing specialist will contact you within 2 hours. We'll walk you through every option and get you pre-qualified — no obligation, no hard credit pull.
              </p>
              <div className="space-y-4 mb-8">
                {[
                  { icon: 'ri-timer-line', text: 'Response within 2 hours' },
                  { icon: 'ri-lock-line', text: 'Soft credit check — no score impact' },
                  { icon: 'ri-file-list-3-line', text: 'Multiple lender options presented' },
                  { icon: 'ri-shield-check-line', text: 'No obligation, no pressure' },
                ].map((item) => (
                  <div key={item.text} className="flex items-center gap-3 text-white/50 text-sm">
                    <i className={`${item.icon} text-orange text-base`} />
                    {item.text}
                  </div>
                ))}
              </div>

              {/* Storm damage callout */}
              <div className="border border-orange/20 bg-orange/5 p-5">
                <div className="flex items-start gap-3">
                  <i className="ri-thunderstorms-line text-orange text-xl flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-white font-semibold text-sm mb-1">Storm Damage? Ask About 90-Day Deferral</p>
                    <p className="text-white/40 text-xs leading-relaxed">
                      Get your roof fixed now, make no payments for 90 days, and use your insurance payout when it arrives. Perfect for active claims.
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-8 border-t border-white/10">
                <p className="text-white/30 text-xs uppercase tracking-widest mb-3">Or call us directly</p>
                <a href="tel:8122135997" className="flex items-center gap-3 text-white hover:text-orange transition-colors">
                  <i className="ri-phone-fill text-orange text-xl" />
                  <span className="font-display text-2xl tracking-wider">812-213-5997</span>
                </a>
              </div>
            </div>

            {/* Right form */}
            <div className="bg-white rounded-2xl overflow-hidden">
              <div className="bg-charcoal-deep px-8 py-6 border-b border-white/10">
                <h3 className="font-display text-white text-2xl uppercase tracking-wider">Financing Pre-Qualification</h3>
                <p className="text-white/50 text-sm mt-1">No hard credit pull — won't affect your score</p>
              </div>

              {formStatus === 'success' ? (
                <div className="px-8 py-14 flex flex-col items-center text-center">
                  <div className="w-16 h-16 flex items-center justify-center bg-green-100 rounded-full mb-4">
                    <i className="ri-checkbox-circle-fill text-green-600 text-3xl" />
                  </div>
                  <h4 className="font-display text-charcoal text-2xl uppercase tracking-wider mb-2">Request Received!</h4>
                  <p className="text-gray-500 text-sm leading-relaxed max-w-xs">
                    Our financing specialist will contact you within 2 hours to walk you through your options. Talk soon!
                  </p>
                  <button onClick={() => setFormStatus('idle')} className="mt-6 text-orange text-sm font-semibold underline underline-offset-4 cursor-pointer">
                    Submit another request
                  </button>
                </div>
              ) : (
                <form
                  ref={formRef}
                  data-readdy-form
                  onSubmit={handleSubmit}
                  className="px-8 py-7 space-y-4"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">First Name</label>
                      <input type="text" name="first_name" required placeholder="John" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Last Name</label>
                      <input type="text" name="last_name" required placeholder="Smith" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Phone</label>
                    <input type="tel" name="phone" required placeholder="812-000-0000" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Email</label>
                    <input type="email" name="email" required placeholder="you@email.com" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Home Address</label>
                    <input type="text" name="address" required placeholder="123 Main St, Evansville, IN" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Financing Plan</label>
                      <select name="financing_plan" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                        <option value="">Select plan</option>
                        <option value="same_cash">Same-As-Cash (0% / 12 mo)</option>
                        <option value="low_monthly">Low Monthly ($89+/mo)</option>
                        <option value="deferred">90-Day Deferred</option>
                        <option value="unsure">Not Sure — Show Me Options</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Est. Project Size</label>
                      <select name="project_size" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                        <option value="">Select range</option>
                        <option value="under5k">Under $5,000</option>
                        <option value="5k-10k">$5,000 – $10,000</option>
                        <option value="10k-15k">$10,000 – $15,000</option>
                        <option value="15k-20k">$15,000 – $20,000</option>
                        <option value="over20k">Over $20,000</option>
                        <option value="unknown">Don't Know Yet</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Service Needed</label>
                    <select name="service_needed" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                      <option value="">Select service</option>
                      <option value="replacement">Full Roof Replacement</option>
                      <option value="repair">Roof Repair</option>
                      <option value="storm_damage">Storm Damage Repair</option>
                      <option value="unsure">Not Sure — Need Inspection</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                      Additional Notes <span className="text-gray-400 font-normal normal-case">(optional)</span>
                    </label>
                    <textarea
                      name="notes"
                      rows={3}
                      maxLength={500}
                      onChange={(e) => setCharCount(e.target.value.length)}
                      placeholder="Storm damage, insurance claim status, timeline, questions..."
                      className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
                    />
                    <p className={`text-xs mt-1 text-right ${charCount > 500 ? 'text-red-500' : 'text-gray-400'}`}>{charCount}/500</p>
                  </div>
                  <button
                    type="submit"
                    disabled={formStatus === 'submitting'}
                    className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-300 text-white font-bold text-sm uppercase tracking-widest py-4 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  >
                    {formStatus === 'submitting' ? (
                      <><i className="ri-loader-4-line animate-spin" />Sending...</>
                    ) : (
                      <><i className="ri-bank-card-line" />Check My Financing Options</>
                    )}
                  </button>
                  {formStatus === 'error' && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2">
                      <i className="ri-alert-line text-red-500" />
                      <p className="text-red-600 text-xs">Something went wrong. Please call 812-213-5997 directly.</p>
                    </div>
                  )}
                  <p className="text-gray-400 text-xs text-center">
                    <i className="ri-lock-line mr-1" />Soft credit check only. Your information is private and secure.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ── Bottom CTA ── */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16">
        <div className="border border-white/10 bg-charcoal-mid p-10 md:p-14 text-center">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Still Have Questions?</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Talk to a Financing<br />Specialist Today
          </h2>
          <p className="text-white/40 text-sm max-w-lg mx-auto leading-relaxed mb-8">
            Our team is available Monday–Saturday, 7 AM – 6 PM. We'll answer every question and find the right plan for your situation — no pressure, ever.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="tel:8122135997"
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-phone-fill" />
              Call 812-213-5997
            </a>
            <button
              onClick={() => navigate('/residential-roofing')}
              className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all cursor-pointer whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-home-smile-line text-orange" />
              View Residential Services
            </button>
          </div>
        </div>
      </section>

    </div>
  );
}
