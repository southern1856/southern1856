import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'WebPage',
  name: 'Illinois Roof Financing & Ameren Energy Rebates',
  description: 'Illinois roof financing options including Ameren Illinois energy efficiency rebates, low monthly payment plans, and 0% interest financing for southeastern Illinois homeowners in Mount Carmel, Carmi, Lawrenceville, and beyond.',
  url: 'https://cornerstoneconstructionevansville.com/illinois-roof-financing',
};

export default function IllinoisRoofFinancingPage() {
  const navigate = useNavigate();
  const hero = useScrollAnimation();
  const rebates = useScrollAnimation();
  const why = useScrollAnimation();
  const cta = useScrollAnimation();

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Illinois Roof Financing & Ameren Energy Rebates | Corner Stone"
        description="Illinois roof financing for southeastern IL homeowners. Ameren Illinois energy efficiency rebates up to $400, 0% interest financing, low monthly payments. Serving Mount Carmel, Carmi, Lawrenceville, Olney, Fairfield &amp; beyond."
        keywords="Illinois roof financing, Ameren Illinois roofing rebates, roof loan Illinois, energy efficiency rebate Illinois, roof financing southeastern Illinois, Mount Carmel roof payment plan"
        canonical="/illinois-roof-financing"
        schema={schema}
      />

      {/* Hero */}
      <section className="relative min-h-[60vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1400x900.svg"
            alt="Illinois roof financing"
            className="w-full h-full object-cover object-top opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/70 via-charcoal-deep/50 to-charcoal-deep" />
        </div>

        <div
          ref={hero.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 pt-24 pb-16 anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-wrap items-center gap-3 mb-8">
            <span className="border border-orange/40 bg-orange/10 text-orange text-xs font-semibold px-4 py-2 uppercase tracking-widest">Ameren Illinois Rebates</span>
            <span className="border border-white/15 bg-white/5 text-white/60 text-xs font-semibold px-4 py-2 uppercase tracking-widest">0% Financing</span>
          </div>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 7vw, 6rem)' }}>
            Illinois Roof<br />Financing &amp;<br /><span className="text-orange">Energy Rebates.</span>
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-2xl leading-relaxed mb-8">
            Southeastern Illinois homeowners have unique financing advantages that Indiana and Kentucky do not — including Ameren Illinois energy efficiency rebates. Learn how to stack rebates with low-interest financing for maximum savings on your new roof.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a href="tel:8122135997" className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2">
              <i className="ri-phone-line" />
              812-213-5997
            </a>
            <button onClick={() => navigate('/illinois-roofing-license-guide')} className="border border-white/30 hover:border-orange text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap cursor-pointer flex items-center gap-2">
              <i className="ri-shield-check-line text-orange" />
              Illinois License Guide
            </button>
          </div>
        </div>
      </section>

      {/* Ameren Rebates */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-14">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Illinois Advantage</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
            Ameren Illinois<br /><span className="text-orange">Energy Rebates</span>
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Indiana and Kentucky do not offer these — but Illinois homeowners get extra savings through Ameren Illinois energy efficiency programs.
          </p>
        </div>

        <div
          ref={rebates.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {[
            {
              icon: 'ri-sun-line',
              title: 'Cool Roof Rebate',
              amount: 'Up to $400',
              desc: 'Ameren Illinois offers rebates for reflective cool roofing materials that reduce summer cooling costs. Energy Star-rated shingles and reflective metal roofing both qualify — and we handle all the paperwork.',
            },
            {
              icon: 'ri-home-gear-line',
              title: 'Attic Insulation Bundle',
              amount: 'Up to $300',
              desc: 'When you replace your roof, adding or upgrading attic insulation through the Ameren program qualifies for an additional rebate. We can bundle roof replacement with insulation for maximum savings.',
            },
            {
              icon: 'ri-funds-line',
              title: 'Home Energy Assessment',
              amount: 'Up to $100',
              desc: 'Ameren offers a discounted home energy assessment that identifies all qualifying efficiency upgrades. Use the assessment to build a complete improvement plan with rebates applied across multiple projects.',
            },
          ].map((item, i) => (
            <div key={item.title} className="border border-white/10 bg-charcoal-mid p-8 hover:border-orange/30 transition-all duration-300 group">
              <div className="w-12 h-12 flex items-center justify-center bg-orange/15 group-hover:bg-orange/25 transition-colors mb-5">
                <i className={`${item.icon} text-orange text-xl`} />
              </div>
              <div className="flex items-center gap-3 mb-2">
                <span className="font-display text-orange text-2xl tracking-wider">{item.amount}</span>
                <span className="text-white/20 text-xs uppercase tracking-wider">Ameren IL</span>
              </div>
              <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">{item.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 p-6 border border-orange/20 bg-orange/5 text-center">
          <p className="text-white text-sm mb-2">
            <strong className="text-orange">Important:</strong> Ameren Illinois rebates change annually. We verify current program availability during your free estimate. Rebates are applied as credits — we handle all the paperwork so you do not have to.
          </p>
        </div>
      </section>

      {/* Financing Plans */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Payment Plans</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
            Illinois Financing<br /><span className="text-orange">Made Simple.</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          {[
            {
              title: '0% Interest',
              term: '12 Months',
              amount: '$167/mo',
              note: 'on $2,000 project',
              desc: 'Pay nothing extra if paid within 12 months. Great for smaller repairs or when stacking with Ameren rebates.',
              features: ['No interest if paid in 12 months', 'Same-day approval', 'No prepayment penalty'],
            },
            {
              title: 'Low Monthly',
              term: 'Up to 120 Months',
              amount: '$89/mo',
              note: 'starting payment',
              desc: 'Spread your roof replacement over up to 10 years with fixed monthly payments. Perfect for full replacements.',
              features: ['Terms from 24 to 120 months', 'Fixed payments', 'Covers full replacement'],
            },
            {
              title: '90-Day Deferral',
              term: 'No Payments Now',
              amount: '$0 now',
              note: 'for 90 days',
              desc: 'Get your roof done today, make no payments for 90 days. Ideal while insurance claims process.',
              features: ['90 days no payments', 'Works alongside insurance', 'Competitive rate after'],
            },
          ].map((plan, i) => (
            <div key={plan.title} className="border border-white/10 bg-charcoal-mid p-8 hover:border-orange/30 transition-all duration-300">
              <p className="font-display text-orange text-4xl tracking-wider mb-1">{plan.amount}</p>
              <p className="text-white/30 text-xs mb-2">{plan.note}</p>
              <h3 className="font-display text-white text-2xl uppercase tracking-wider mb-2">{plan.title}</h3>
              <p className="text-white/40 text-xs mb-1">{plan.term}</p>
              <p className="text-white/50 text-sm leading-relaxed mb-5">{plan.desc}</p>
              <ul className="space-y-2">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-white/50 text-xs">
                    <i className="ri-check-line text-orange text-sm mt-0.5 flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <p className="text-center text-white/20 text-xs">
          Subject to credit approval. Rates and terms vary by lender and credit profile.
        </p>
      </section>

      {/* Why IL is different */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Why Illinois Is Different</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Stack Rebates +<br />Financing for<br /><span className="text-orange">Maximum Savings.</span>
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-6">
              Illinois is the only state in our Tri-State service area with utility-sponsored energy efficiency rebates for roofing. That means southeastern Illinois homeowners — from Mount Carmel to Olney — can combine Ameren rebates with our 0% financing to dramatically reduce out-of-pocket costs.
            </p>
            <div className="space-y-4">
              {[
                { icon: 'ri-stack-line', text: 'Layer Ameren rebates on top of manufacturer warranties and insurance payouts' },
                { icon: 'ri-file-text-line', text: 'We handle all rebate paperwork — you just enjoy the savings' },
                { icon: 'ri-timer-line', text: 'Same financing plans available to Illinois homeowners as our Indiana base' },
                { icon: 'ri-shield-check-line', text: 'Fully licensed and insured in Illinois — no out-of-state contractor risk' },
              ].map((item) => (
                <div key={item.text} className="flex items-start gap-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-orange/20 text-orange flex-shrink-0 mt-0.5">
                    <i className={`${item.icon} text-sm`} />
                  </div>
                  <p className="text-white/60 text-sm leading-relaxed">{item.text}</p>
                </div>
              ))}
            </div>
          </div>

          <div ref={why.ref as React.RefObject<HTMLDivElement>} className={`anim-fade-up ${why.isVisible ? 'is-visible' : ''}`}>
            <div className="w-full overflow-hidden" style={{ height: '420px' }}>
              <img
                src="/placeholders/700x420.svg"
                alt="Illinois home with energy-efficient roof"
                className="w-full h-full object-cover object-top"
              />
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Common Questions</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Illinois Roof Financing FAQ
            </h2>
          </div>
          <div className="space-y-4">
            {[
              { q: 'Do Ameren Illinois rebates apply to roof replacements?', a: 'Yes. Ameren Illinois offers a Cool Roof Rebate of up to $400 for Energy Star-rated reflective roofing materials, including select architectural shingles and metal roofing. We verify your eligibility and material selection during your free estimate.' },
              { q: 'Can I combine Ameren rebates with 0% financing?', a: 'Absolutely. The Ameren rebate is applied as a credit toward your project cost, and the remaining balance can be financed through our payment plans — including 0% interest for 12 months. This stacking strategy maximizes your upfront savings.' },
              { q: 'Do you offer the same financing in Illinois as Indiana?', a: 'Yes. Our financing plans are available regardless of which state you live in. Same 0% interest, low monthly, and deferred payment options — whether you are in Evansville, IN or Mount Carmel, IL.' },
              { q: 'How quickly can I get approved for Illinois roof financing?', a: 'Most Illinois homeowners receive same-day approval, often within 10 to 15 minutes of applying. The initial check is a soft credit pull that does not affect your score.' },
              { q: 'Does the Ameren rebate cover metal roofing for agricultural buildings?', a: 'Ameren Illinois rebates apply to residential properties only. However, we offer competitive financing for agricultural and commercial metal roofing projects through our standard payment plans — just without the utility rebate.' },
            ].map((faq) => (
              <div key={faq.q} className="border border-white/10 bg-charcoal-mid p-6">
                <p className="font-display text-white text-base uppercase tracking-wider mb-2">{faq.q}</p>
                <p className="text-white/50 text-sm leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div ref={cta.ref as React.RefObject<HTMLDivElement>} className={`anim-fade-up border border-white/10 p-10 md:p-14 text-center ${cta.isVisible ? 'is-visible' : ''}`}>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Check Your Illinois<br /><span className="text-orange">Rebates &amp; Financing.</span>
          </h2>
          <p className="text-white/40 text-sm max-w-lg mx-auto leading-relaxed mb-8">
            Our team will verify your Ameren Illinois rebate eligibility, walk through financing options, and provide a free, no-obligation estimate — all in one visit.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="tel:8122135997" className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2">
              <i className="ri-phone-fill" />
              Call 812-213-5997
            </a>
            <button onClick={() => navigate('/illinois-storm-damage')} className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all cursor-pointer whitespace-nowrap flex items-center gap-2">
              <i className="ri-thunderstorms-line text-orange" />
              Illinois Storm Damage Guide
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}