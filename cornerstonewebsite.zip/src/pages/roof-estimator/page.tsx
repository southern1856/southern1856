import { useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import RoofCostEstimator from '@/components/feature/RoofCostEstimator';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import FAQSection from '@/components/feature/FAQSection';
import { trackToolUsage } from '@/lib/toolAnalytics';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { OFFERS } from '@/mocks/promotions';

function openReaddyAgent(prefill?: string) {
  const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
  if (btn) btn.click();
  if (!prefill) return;
  setTimeout(() => {
    const input = document.querySelector('input[placeholder*="message" i], textarea[placeholder*="message" i], input[placeholder*="ask" i], textarea[placeholder*="ask" i], input[placeholder*="type" i], textarea[placeholder*="type" i]') as HTMLInputElement | HTMLTextAreaElement | null;
    if (input) {
      input.value = prefill;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      const form = input.closest('form');
      if (form) {
        const submitBtn = form.querySelector('button[type="submit"], button[aria-label*="send" i]') as HTMLElement | null;
        if (submitBtn) submitBtn.click();
      }
    }
  }, 900);
}

const HOW_IT_WORKS = [
  {
    step: '01',
    title: 'Enter Your Roof Size',
    desc: 'Input your home square footage, roof square footage, or roofing squares. We auto-calculate from any starting point.',
    icon: 'ri-ruler-line',
  },
  {
    step: '02',
    title: 'Describe Your Roof',
    desc: 'Select stories, pitch, complexity, and site access. These are the 4 biggest cost drivers every contractor uses.',
    icon: 'ri-home-gear-line',
  },
  {
    step: '03',
    title: 'Set Condition & Material',
    desc: 'Tell us tear-off layers, decking condition, material choice, and roof features like chimneys and skylights.',
    icon: 'ri-hammer-line',
  },
  {
    step: '04',
    title: 'See Your Range',
    desc: 'Get a personalized price range with full breakdown. Then book a free inspection for an exact written quote.',
    icon: 'ri-file-list-3-line',
  },
];

const nearestExpiry = OFFERS
  .filter((o) => o.expires)
  .map((o) => o.expires!)
  .sort()[0] || '2026-12-31';

const WHY_TRUST = [
  {
    icon: 'ri-map-pin-line',
    title: 'Evansville-Area Pricing',
    desc: 'Based on real 2026 Tri-State invoices — not national averages that miss local labor and material costs.',
  },
  {
    icon: 'ri-shield-check-line',
    title: 'No Email Required',
    desc: 'Use the estimator anonymously. No forms, no spam, no sales calls unless you choose to book an inspection.',
  },
  {
    icon: 'ri-refresh-line',
    title: 'Unlimited Estimates',
    desc: 'Try different materials and sizes. See how upgrading to architectural shingles or metal changes your number.',
  },
  {
    icon: 'ri-time-line',
    title: 'Under 60 Seconds',
    desc: 'Four quick steps with plain-language options. No roofing jargon — just honest numbers you can understand.',
  },
];

export default function RoofEstimatorPage() {
  const navigate = useNavigate();
  const hero = useScrollAnimation();
  const howItWorks = useScrollAnimation({ threshold: 0.05 });
  const trust = useScrollAnimation({ threshold: 0.05 });
  const estimatorRef = useRef<HTMLDivElement>(null);

  const scrollToEstimator = () => {
    estimatorRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const schema = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: 'Free Roof Cost Estimator for Evansville Homeowners',
    description: 'Instant roof replacement cost calculator for Evansville, Newburgh, and the Tri-State. Enter your roof size, pitch, stories, and material to get a personalized price range in 60 seconds.',
  };

  return (
    <div className="min-h-screen bg-warm-beige">
      <PageSEO
        title="Free Roof Cost Estimator 2026 | Calculate Your Roof Replacement Price"
        description="Instant roof cost calculator for Evansville homeowners. Enter roof size, stories, pitch, material, and features to get a personalized price range. No email required. Based on real 2026 Tri-State pricing."
        keywords="roof cost estimator Evansville, roof replacement calculator Indiana, how much does a new roof cost calculator, free roof estimate tool, roofing cost per square, asphalt shingle cost calculator"
        canonical="/roof-estimator"
        schema={schema}
      />

      {/* HERO */}
      <section className="relative bg-charcoal-deep pt-32 pb-16 md:pb-24 overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage:
              'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)',
            backgroundSize: '60px 60px',
          }}
        />
        <div
          className="absolute -top-40 -right-40 w-[500px] h-[500px] rounded-full opacity-10"
          style={{ background: 'radial-gradient(circle, #e8621a 0%, transparent 70%)' }}
        />

        <div className="relative z-10 w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-5xl mx-auto">
            <div
              ref={hero.ref as React.RefObject<HTMLDivElement>}
              className={`text-center anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
            >
              <div className="inline-flex items-center gap-2 bg-orange/15 border border-orange/30 px-4 py-2 mb-8">
                <i className="ri-calculator-line text-orange text-sm" />
                <span className="text-orange text-xs font-bold uppercase tracking-[0.2em]">
                  60-Second Calculator
                </span>
              </div>

              <h1
                className="font-display text-white uppercase tracking-wider leading-none mb-6"
                style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}
              >
                How Much Will Your
                <br />
                New Roof <span className="text-orange">Actually Cost</span>?
              </h1>

              <p className="text-white/50 text-base md:text-lg leading-relaxed max-w-2xl mx-auto mb-8">
                Stop guessing with vague national averages. Enter your actual roof details — size, stories, pitch, material — and get a personalized Evansville-area price range backed by real 2026 local data.
              </p>

              {/* Urgency Stack */}
              <div className="mb-8">
                <CountdownTimer expiresAt={nearestExpiry} variant="banner" />
                <div className="mt-3">
                  <SocialProofPulse />
                </div>
              </div>

              {/* Quick trust strip */}
              <div className="flex flex-wrap items-center justify-center gap-6 md:gap-10 mb-10">
                <div className="text-center">
                  <p className="font-display text-white text-3xl tracking-wider">4</p>
                  <p className="text-white/40 text-xs uppercase tracking-widest mt-1">Quick Steps</p>
                </div>
                <div className="w-px h-10 bg-white/10" />
                <div className="text-center">
                  <p className="font-display text-white text-3xl tracking-wider">6</p>
                  <p className="text-white/40 text-xs uppercase tracking-widest mt-1">Cost Factors</p>
                </div>
                <div className="w-px h-10 bg-white/10" />
                <div className="text-center">
                  <p className="font-display text-white text-3xl tracking-wider">$0</p>
                  <p className="text-white/40 text-xs uppercase tracking-widest mt-1">Cost to Use</p>
                </div>
                <div className="w-px h-10 hidden sm:block" />
                <div className="text-center hidden sm:block">
                  <p className="font-display text-white text-3xl tracking-wider">2026</p>
                  <p className="text-white/40 text-xs uppercase tracking-widest mt-1">Local Rates</p>
                </div>
              </div>

              {/* CTA buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <button
                  onClick={scrollToEstimator}
                  className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-calculator-line" />
                  Calculate My Roof Cost
                </button>
                <button
                  onClick={() => navigate('/free-inspection')}
                  className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-calendar-check-line" />
                  Skip to Free Inspection
                </button>
              </div>

              {/* AI Assistant prompt */}
              <div className="mt-8 inline-flex items-center gap-3 bg-white/5 border border-white/10 hover:border-green-400/40 px-5 py-3 cursor-pointer transition-colors duration-200"
                onClick={() => openReaddyAgent("How much does a roof replacement cost in Evansville?")}
                role="button"
              >
                <span className="relative w-2 h-2">
                  <span className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-75" />
                  <span className="relative w-2 h-2 rounded-full bg-green-400 block" />
                </span>
                <i className="ri-mic-line text-green-400 text-sm" />
                <span className="text-white/60 text-xs font-medium uppercase tracking-wider">Not sure what to enter? Ask our AI — it can walk you through it</span>
                <i className="ri-arrow-right-line text-white/40 text-xs" />
              </div>
            </div>
          </div>
        </div>
      </section>

      <TalkToAIExpert />

      {/* How It Works */}
      <section className="py-16 md:py-20 bg-white">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-5xl mx-auto">
            <div
              ref={howItWorks.ref as React.RefObject<HTMLDivElement>}
              className={`text-center mb-12 anim-fade-up ${howItWorks.isVisible ? 'is-visible' : ''}`}
            >
              <p className="text-orange text-xs font-semibold uppercase tracking-[0.25em] mb-4">
                Simple &amp; Transparent
              </p>
              <h2 className="font-display text-charcoal uppercase tracking-wider text-3xl md:text-4xl mb-3">
                How the Estimator Works
              </h2>
              <p className="text-charcoal/50 text-base max-w-xl mx-auto">
                Four steps. Real inputs. A personalized range you can actually trust — not a vague guess.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
              {HOW_IT_WORKS.map((item, i) => (
                <div
                  key={item.step}
                  className={`border border-charcoal/10 p-6 md:p-8 anim-fade-up ${howItWorks.isVisible ? 'is-visible' : ''}`}
                  style={{ transitionDelay: `${i * 80}ms` }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 flex items-center justify-center bg-orange/10">
                      <i className={`${item.icon} text-orange text-lg`} />
                    </div>
                    <span className="font-display text-charcoal/10 text-2xl tracking-wider">
                      {item.step}
                    </span>
                  </div>
                  <h3 className="font-display text-charcoal text-base uppercase tracking-wider mb-2">
                    {item.title}
                  </h3>
                  <p className="text-charcoal/50 text-sm leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ESTIMATOR — THE MAIN EVENT */}
      <div ref={estimatorRef}>
        <RoofCostEstimator onResultShown={() => trackToolUsage('roof-estimator', 'Roof Cost Estimator')} />
      </div>

      {/* Why Trust This Estimator */}
      <section className="py-16 md:py-20 bg-white">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-5xl mx-auto">
            <div
              ref={trust.ref as React.RefObject<HTMLDivElement>}
              className={`text-center mb-12 anim-fade-up ${trust.isVisible ? 'is-visible' : ''}`}
            >
              <p className="text-orange text-xs font-semibold uppercase tracking-[0.25em] mb-4">
                Built for Homeowners
              </p>
              <h2 className="font-display text-charcoal uppercase tracking-wider text-3xl md:text-4xl mb-3">
                Why Homeowners Trust This Number
              </h2>
              <p className="text-charcoal/50 text-base max-w-xl mx-auto">
                Most online calculators use national averages and ignore the 6 factors that actually drive your price. This one doesn't.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
              {WHY_TRUST.map((item, i) => (
                <div
                  key={item.title}
                  className={`flex items-start gap-4 border border-charcoal/10 p-6 anim-fade-up ${trust.isVisible ? 'is-visible' : ''}`}
                  style={{ transitionDelay: `${i * 80}ms` }}
                >
                  <div className="w-10 h-10 flex items-center justify-center bg-charcoal-deep text-orange flex-shrink-0">
                    <i className={`${item.icon} text-lg`} />
                  </div>
                  <div>
                    <h3 className="font-display text-charcoal text-base uppercase tracking-wider mb-1">
                      {item.title}
                    </h3>
                    <p className="text-charcoal/50 text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="py-16 md:py-20 bg-charcoal-deep">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-display text-white text-3xl md:text-4xl uppercase tracking-wider mb-4">
              Ready for Your Exact Number?
            </h2>
            <p className="text-white/50 text-base md:text-lg leading-relaxed mb-8">
              The estimator gives you a solid range. A free 45-minute inspection gives you a written, line-item quote with zero obligation.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => navigate('/free-inspection')}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-calendar-check-line" />
                Book Free Inspection
              </button>
              <a
                href="tel:8122135997"
                className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-phone-line" />
                Call 812-213-5997
              </a>
            </div>

            {/* AI prompt */}
            <div
              className="mt-8 inline-flex items-center gap-3 bg-white/5 border border-white/10 hover:border-green-400/40 px-5 py-3 cursor-pointer transition-colors duration-200"
              onClick={() => openReaddyAgent("What factors affect my roof replacement cost the most?")}
              role="button"
            >
              <i className="ri-mic-line text-green-400 text-sm" />
              <span className="text-white/60 text-xs font-medium uppercase tracking-wider">Ask AI to explain any part of your estimate</span>
              <i className="ri-arrow-right-line text-white/40 text-xs" />
            </div>

            <p className="text-white/30 text-xs mt-6">
              Same-day inspections available. No pressure, no obligation, no surprise fees.
            </p>
          </div>
        </div>
      </section>

      <FAQSection />
    </div>
  );
}