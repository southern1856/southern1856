import { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import RoofCostEstimator from '@/components/feature/RoofCostEstimator';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import FAQSection from '@/components/feature/FAQSection';
import { OFFERS } from '@/mocks/promotions';

const nearestExpiry = OFFERS
  .filter((o) => o.expires)
  .map((o) => o.expires!)
  .sort()[0] || '2026-12-31';

// ── A/B Split Test: Urgency Stack vs No Urgency ──
// Group A (control): CountdownTimer + SocialProofPulse visible
// Group B (variant): bare hero — no urgency stack
// Split: 50/50, persisted in localStorage for consistent experience
const AB_GROUP_KEY = 'roof_estimator_hero_ab_group';

function getABGroup(): 'A' | 'B' {
  const stored = localStorage.getItem(AB_GROUP_KEY);
  if (stored === 'A' || stored === 'B') return stored;
  const assigned = Math.random() < 0.5 ? 'A' : 'B';
  localStorage.setItem(AB_GROUP_KEY, assigned);
  return assigned;
}

const abGroup = getABGroup();

function openReaddyAgent(prefill?: string) {
  const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
  if (btn) btn.click();
  if (!prefill) return;
  setTimeout(() => {
    const input = document.querySelector('input[placeholder*="message" i], textarea[placeholder*="message" i], input[placeholder*="ask" i], textarea[placeholder*="ask" i], input[placeholder*="type" i], textarea[placeholder*="type" i]') as HTMLInputElement | HTMLTextAreaElement | null;
    if (input) {
      input.value = prefill;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      const form = input.closest('form');
      if (form) {
        const submitBtn = form.querySelector('button[type="submit"], button[aria-label*="send" i]') as HTMLElement | null;
        if (submitBtn) submitBtn.click();
      }
    }
  }, 900);
}

const TRUST_SIGNALS = [
  { icon: 'ri-map-pin-line', text: 'Evansville & Tri-State Area' },
  { icon: 'ri-star-fill', text: '4.9 Google Rating' },
  { icon: 'ri-shield-check-line', text: 'A+ BBB Accredited' },
  { icon: 'ri-award-line', text: '25+ Years Experience' },
];

// Smart defaults for "Lock In Deal" autofill — most common Evansville-area home
const LOCK_IN_DEFAULTS = {
  roofSqft: '1800',
  inputMode: 'home_sqft' as const,
  stories: '1' as const,
  pitch: 'medium' as const,
  complexity: 'moderate' as const,
  access: 'easy' as const,
  layers: '1' as const,
  decking: 'good' as const,
  materialKey: 'arch',
  chimneys: 1,
  skylights: 0,
  dormers: 0,
};

export default function RoofEstimatorLandingPage() {
  const navigate = useNavigate();
  const hero = useScrollAnimation();
  const trust = useScrollAnimation({ threshold: 0.1 });
  const estimatorRef = useRef<HTMLDivElement>(null);
  const [estimatorPrefill, setEstimatorPrefill] = useState<typeof LOCK_IN_DEFAULTS | null>(null);

  const scrollToEstimator = () => {
    estimatorRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const schema = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: 'Free Roof Cost Calculator | Evansville Roofing Estimates',
    description: 'Calculate your roof replacement cost in 60 seconds. Enter roof size, pitch, stories, and material choice for a personalized Evansville-area price range. No email required.',
  };

  return (
    <div className="min-h-screen bg-warm-beige">
      <PageSEO
        title="Free Roof Cost Calculator 2026 | Evansville Roof Replacement Estimate"
        description="Calculate your roof replacement cost in 60 seconds. Enter roof size, pitch, stories, and material for a personalized Evansville-area price range. No email required."
        keywords="roof cost calculator Evansville, roof replacement estimate Indiana, free roof price calculator, asphalt shingle cost estimator, metal roof cost calculator"
        canonical="/roof-estimator"
        schema={schema}
      />

      {/* AD HERO — short, no nav, estimator above fold */}
      <section
        className="relative bg-charcoal-deep pt-24 pb-8 md:pt-28 md:pb-10 overflow-hidden"
        data-ab-group={abGroup}
      >
        <div
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage:
              'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)',
            backgroundSize: '60px 60px',
          }}
        />
        <div className="relative z-10 w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-4xl mx-auto">
            <div
              ref={hero.ref as React.RefObject<HTMLDivElement>}
              className={`text-center anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
            >
              {/* Compact trust row */}
              <div className="flex flex-wrap items-center justify-center gap-3 md:gap-5 mb-6">
                {TRUST_SIGNALS.map((s) => (
                  <div key={s.text} className="flex items-center gap-1.5 text-white/40 text-[10px] md:text-xs uppercase tracking-wider">
                    <i className={`${s.icon} text-orange`} />
                    {s.text}
                  </div>
                ))}
              </div>

              <h1
                className="font-display text-white uppercase tracking-wider leading-none mb-4"
                style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}
              >
                What's Your Roof
                <br />
                <span className="text-orange">Replacement Cost?</span>
              </h1>

              <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-xl mx-auto mb-6">
                Enter 4 quick details about your home and get a personalized price range based on real 2026 Evansville-area rates. No email. No spam. Just numbers.
              </p>

              {abGroup === 'A' && (
                <>
                  <div className="flex justify-center mb-5">
                    <CountdownTimer expiresAt={nearestExpiry} variant="banner" />
                  </div>

                  <div className="flex justify-center mb-3">
                    <SocialProofPulse />
                  </div>
                </>
              )}

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-6">
                <button
                  onClick={() => {
                    setEstimatorPrefill(LOCK_IN_DEFAULTS);
                    setTimeout(() => scrollToEstimator(), 100);
                  }}
                  className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap mx-auto"
                >
                  <i className="ri-flashlight-line" />
                  Lock In Deal — See My Price
                  <i className="ri-arrow-down-line animate-bounce" />
                </button>
                <button
                  onClick={scrollToEstimator}
                  className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white/70 hover:text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-calculator-line" />
                  Build My Own Estimate
                </button>
              </div>

              <p className="text-white/30 text-xs mt-3">
                Takes under 60 seconds · Based on real local pricing
              </p>

              {/* AI prompt */}
              <div
                className="mt-6 inline-flex items-center gap-3 bg-white/5 border border-white/10 hover:border-green-400/40 px-4 py-2.5 cursor-pointer transition-colors duration-200 mx-auto"
                onClick={() => openReaddyAgent("How much does a roof replacement cost in Evansville?")}
                role="button"
              >
                <span className="relative w-2 h-2">
                  <span className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-75" />
                  <span className="relative w-2 h-2 rounded-full bg-green-400 block" />
                </span>
                <i className="ri-mic-line text-green-400 text-sm" />
                <span className="text-white/60 text-xs font-medium uppercase tracking-wider">Ask AI to walk you through the estimate</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ESTIMATOR — directly below hero, no sections in between */}
      <div ref={estimatorRef}>
        <RoofCostEstimator prefill={estimatorPrefill} />
      </div>

      {/* Trust bar */}
      <section className="py-10 md:py-12 bg-white border-t border-charcoal/5">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-4xl mx-auto">
            <div
              ref={trust.ref as React.RefObject<HTMLDivElement>}
              className={`text-center anim-fade-up ${trust.isVisible ? 'is-visible' : ''}`}
            >
              <p className="text-charcoal/40 text-xs uppercase tracking-widest mb-6">
                Why homeowners trust our numbers
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { num: '2,500+', label: 'Roofs Completed' },
                  { num: '$0', label: 'Cost to Estimate' },
                  { num: '24hr', label: 'Written Quote Available' },
                  { num: '4.9★', label: 'Google Rating' },
                ].map((stat) => (
                  <div key={stat.label} className="text-center">
                    <p className="font-display text-charcoal text-xl md:text-2xl tracking-wider">{stat.num}</p>
                    <p className="text-charcoal/40 text-[10px] md:text-xs uppercase tracking-widest mt-1">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Bottom CTA — no FAQ, no extra fluff */}
      <section className="py-12 md:py-16 bg-charcoal-deep">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wider mb-3">
              Want an Exact Written Quote?
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-6">
              The calculator gives you a solid range. A free 45-minute inspection gives you a line-item quote with zero obligation.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={() => navigate('/free-inspection')}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-calendar-check-line" />
                Book Free Inspection
              </button>
              <a
                href="tel:8122135997"
                className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-phone-line" />
                Call 812-213-5997
              </a>
            </div>
            <p className="text-white/30 text-xs mt-4">
              Same-day inspections · No pressure · No surprise fees
            </p>
          </div>
        </div>
      </section>

      {/* FAQ — kept for SEO but minimal */}
      <FAQSection />
    </div>
  );
}