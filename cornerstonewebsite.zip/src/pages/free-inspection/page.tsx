import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import PageSEO from '@/components/feature/PageSEO';
import { trackConversion } from '@/lib/toolAnalytics';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { OFFERS } from '@/mocks/promotions';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const timeSlots = [
  { value: '8:00 AM – 10:00 AM', label: '8:00 AM – 10:00 AM', period: 'Morning' },
  { value: '10:00 AM – 12:00 PM', label: '10:00 AM – 12:00 PM', period: 'Late Morning' },
  { value: '12:00 PM – 2:00 PM', label: '12:00 PM – 2:00 PM', period: 'Midday' },
  { value: '2:00 PM – 4:00 PM', label: '2:00 PM – 4:00 PM', period: 'Afternoon' },
  { value: '4:00 PM – 6:00 PM', label: '4:00 PM – 6:00 PM', period: 'Evening' },
];

const serviceOptions = [
  'Free Roof Inspection',
  'Storm Damage Assessment',
  'Pre-Sale Inspection',
  'Insurance Claim Inspection',
  'Annual Maintenance Check',
  'Leak Investigation',
  'Gutter Inspection',
  'Commercial Roof Inspection',
];

const referralSources = [
  'Google Search',
  'Google Reviews',
  'Facebook',
  'Neighbor / Friend Referral',
  'Yard Sign',
  'Previous Customer',
  'Insurance Agent',
  'Realtor',
  'Other',
];

function getMinDate(): string {
  const today = new Date();
  today.setDate(today.getDate() + 1);
  return today.toISOString().split('T')[0];
}

function getMaxDate(): string {
  const max = new Date();
  max.setDate(max.getDate() + 60);
  return max.toISOString().split('T')[0];
}

const TRUST_BADGES = [
  { icon: 'ri-shield-check-line', label: 'Licensed & Insured', sub: 'IN & KY' },
  { icon: 'ri-time-line', label: 'Same-Week Booking', sub: '3–5 days' },
  { icon: 'ri-money-dollar-circle-line', label: '100% Free', sub: 'No obligation' },
  { icon: 'ri-file-list-3-line', label: 'Photo Report', sub: 'Within 24 hrs' },
];

const TESTIMONIALS = [
  {
    quote: 'They showed up right on time, took photos of everything, and emailed me a detailed report the same evening. No pressure, no upsell — just honest information about my roof.',
    name: 'Sarah J.',
    loc: 'Newburgh, IN',
    stars: 5,
  },
  {
    quote: 'I was sure I needed a new roof. The inspector told me I had 3–5 years left and showed me exactly why. That honesty earned my trust forever.',
    name: 'Mike T.',
    loc: 'Evansville, IN',
    stars: 5,
  },
  {
    quote: 'After the hail storm, they came out same day and documented every bit of damage. My insurance covered the whole replacement. Couldn\'t have done it without them.',
    name: 'Denise R.',
    loc: 'Henderson, KY',
    stars: 5,
  },
];

const HOW_IT_WORKS = [
  { step: '01', icon: 'ri-calendar-check-line', title: 'Book Online or Call', desc: 'Pick a date and time in 60 seconds. Or call 812-213-5997 and we\'ll book it in under 2 minutes.' },
  { step: '02', icon: 'ri-phone-line', title: 'We Confirm Within 24 Hrs', desc: 'Our office calls to lock in your appointment and answer any questions before the inspector arrives.' },
  { step: '03', icon: 'ri-search-eye-line', title: 'Certified Inspector Arrives', desc: 'Our inspector gets on your roof, checks every surface, and documents everything with photos — usually takes 45–60 minutes.' },
  { step: '04', icon: 'ri-mail-send-line', title: 'Full Report Within 24 Hrs', desc: 'You get a written condition summary with photos, severity ratings, and honest recommendations — no pressure, ever.' },
];

const WAITING_RISKS = [
  { icon: 'ri-water-flash-line', title: 'Water Damage Spreads Fast', desc: 'A small leak can destroy insulation, drywall, and framing in weeks. A $200 repair becomes a $5,000+ interior restoration.' },
  { icon: 'ri-windy-line', title: 'Storm Season Is Here', desc: 'Indiana averages 50+ severe weather events per year. An already-compromised roof won\'t survive the next storm.' },
  { icon: 'ri-money-dollar-circle-line', title: 'Insurance Deadlines Expire', desc: 'Most insurers require claims within 6–12 months of the storm event. Wait too long and you pay 100% out of pocket.' },
  { icon: 'ri-home-4-line', title: 'Resale Value Drops', desc: 'A damaged or aging roof is the #1 reason buyers walk. An inspection lets you know where you stand before listing.' },
];

const FAQS = [
  {
    q: 'Is the inspection really free? What\'s the catch?',
    a: 'Yes, 100% free with zero catch. We believe every homeowner deserves to know the condition of their roof — especially after Indiana storms. If your roof is in good shape, we\'ll tell you. If it needs work, we\'ll show you exactly why with photos. The decision is always yours, and there is never any pressure.',
  },
  {
    q: 'How long does the inspection take?',
    a: 'Most residential inspections take 45–60 minutes. The inspector gets on the roof, checks every surface, examines the attic (if accessible), and documents all findings with photos. You don\'t need to be home the entire time, but we recommend it so we can walk you through key findings.',
  },
  {
    q: 'Will you try to sell me a new roof?',
    a: 'No. Our inspectors are trained to give honest assessments — not sales pitches. We\'ve told thousands of homeowners their roof is fine and has years of life left. If you do need work, we\'ll explain exactly why, show you the photos, and let you decide on your own timeline.',
  },
  {
    q: 'Can you help with my insurance claim?',
    a: 'Absolutely. If we find storm damage, we\'ll document everything with detailed photos and measurements. We work directly with your insurance adjuster, meet them on your roof, and help maximize your claim payout. Most of our storm damage customers pay only their deductible.',
  },
  {
    q: 'What areas do you serve?',
    a: 'We serve the entire Tri-State area including Evansville IN, Newburgh IN, Boonville IN, Mount Vernon IN, Princeton IN, Henderson KY, Owensboro KY, and surrounding communities. If you\'re unsure, just call — we probably cover your area.',
  },
  {
    q: 'How soon can you come out?',
    a: 'Most inspections are scheduled within 3–5 business days. Storm damage emergencies can often be same-day or next-day. When you book online, you\'ll see the earliest available slots.',
  },
];

const SOCIAL_PROOF_TICKER = [
  '1,200+ inspections completed this year',
  '4.9/5 average rating on Google',
  'Same-week scheduling available',
  'Serving Evansville & Tri-State since 1995',
  'GAF Master Elite Certified',
  'Free — no obligation, ever',
];

const nearestExpiry = OFFERS
  .filter((o) => o.expires)
  .map((o) => o.expires!)
  .sort()[0] || '2026-12-31';

export default function FreeInspectionPage() {
  const [submitting, setSubmitting] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedSlot, setSelectedSlot] = useState('');
  const [charCount, setCharCount] = useState(0);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const navigate = useNavigate();

  const heroAnim = useScrollAnimation();
  const trustAnim = useScrollAnimation({ threshold: 0.1 });
  const howAnim = useScrollAnimation({ threshold: 0.1 });
  const riskAnim = useScrollAnimation({ threshold: 0.1 });
  const faqAnim = useScrollAnimation({ threshold: 0.1 });
  const formAnim = useScrollAnimation({ threshold: 0.1 });

  useEffect(() => {
    setSelectedSlot('');
  }, [selectedDate]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedDate || !selectedSlot) return;

    setSubmitting(true);
    const form = e.currentTarget;
    const formData = new FormData(form);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
    const data = new URLSearchParams(formData as unknown as Record<string, string>);
    const address = String(formData.get('address') || '');
    try {
      await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: data,
      });
      trackConversion('inspection_booking');
      navigate('/inspection-booked', { state: { date: selectedDate, time: selectedSlot, address } });
    } catch {
      trackConversion('inspection_booking');
      navigate('/inspection-booked', { state: { date: selectedDate, time: selectedSlot, address } });
    } finally {
      setSubmitting(false);
    }
  };

  const InspectionForm = ({ compact = false }: { compact?: boolean }) => (
    <div className={`bg-white rounded-2xl overflow-hidden ${compact ? '' : 'shadow-2xl'}`}>
      <div className="bg-charcoal-deep px-6 py-5 border-b border-white/10">
        <h3 className="font-display text-white text-xl uppercase tracking-wider">Book Your Free Inspection</h3>
        <p className="text-white/50 text-xs mt-1">Takes 60 seconds. We confirm within 24 hours.</p>
      </div>

      <form data-readdy-form onSubmit={handleSubmit} className="px-6 py-5 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1">Full Name *</label>
              <input type="text" name="full_name" required placeholder="John Smith" className="w-full bg-gray-100 rounded-lg px-3 py-2.5 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
            </div>
            <div>
              <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1">Phone *</label>
              <input type="tel" name="phone" required placeholder="812-000-0000" className="w-full bg-gray-100 rounded-lg px-3 py-2.5 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
            </div>
          </div>
          <div>
            <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1">Email *</label>
            <input type="email" name="email" required placeholder="you@email.com" className="w-full bg-gray-100 rounded-lg px-3 py-2.5 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
          </div>
          <div>
            <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1">Property Address *</label>
            <input type="text" name="address" required placeholder="123 Main St, Evansville, IN" className="w-full bg-gray-100 rounded-lg px-3 py-2.5 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
          </div>
          <div>
            <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1">Inspection Type *</label>
            <select name="inspection_type" required defaultValue="Free Roof Inspection" className="w-full bg-gray-100 rounded-lg px-3 py-2.5 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
              {serviceOptions.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1">Preferred Date *</label>
              <input
                type="date"
                name="appointment_date"
                required
                min={getMinDate()}
                max={getMaxDate()}
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full bg-gray-100 rounded-lg px-3 py-2.5 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1">Time Slot *</label>
              <select
                name="time_slot"
                required
                value={selectedSlot}
                onChange={(e) => setSelectedSlot(e.target.value)}
                disabled={!selectedDate}
                className="w-full bg-gray-100 rounded-lg px-3 py-2.5 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer disabled:opacity-40"
              >
                <option value="">Select time</option>
                {timeSlots.map((slot) => (
                  <option key={slot.value} value={slot.value}>{slot.label}</option>
                ))}
              </select>
            </div>
          </div>
          {!selectedDate && (
            <p className="text-gray-400 text-xs">Pick a date first to unlock time slots.</p>
          )}
          <div>
            <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1">Insurance Claim?</label>
            <div className="flex gap-4">
              {['Yes', 'No', 'Not Sure'].map((opt) => (
                <label key={opt} className="flex items-center gap-1.5 cursor-pointer">
                  <input type="radio" name="insurance_claim" value={opt} className="accent-orange cursor-pointer" />
                  <span className="text-gray-600 text-xs">{opt}</span>
                </label>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1">Additional Details</label>
            <textarea
              name="message"
              rows={2}
              maxLength={500}
              placeholder="Roof age, known issues, access notes..."
              onChange={(e) => setCharCount(e.target.value.length)}
              className="w-full bg-gray-100 rounded-lg px-3 py-2.5 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
            />
            <p className={`text-xs mt-0.5 text-right ${charCount > 500 ? 'text-red-500' : 'text-gray-400'}`}>{charCount}/500</p>
          </div>
          <div>
            <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1">How Did You Hear About Us?</label>
            <select name="referral_source" defaultValue="" className="w-full bg-gray-100 rounded-lg px-3 py-2.5 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
              <option value="">Select source...</option>
              {referralSources.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
          <button
            type="submit"
            disabled={submitting || !selectedDate || !selectedSlot}
            className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-300 text-white font-bold text-sm uppercase tracking-widest py-3.5 rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
          >
            {submitting ? (
              <><i className="ri-loader-4-line animate-spin" />Booking...</>
            ) : (
              <><i className="ri-calendar-check-line" />Book Free Inspection</>
            )}
          </button>
          <p className="text-gray-400 text-xs text-center leading-relaxed">
            <i className="ri-lock-line mr-1" />No spam. We never share your information.
          </p>
        </form>
    </div>
  );

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Free Roof Inspection Evansville Indiana | Book Online in 60 Seconds | Corner Stone"
        description="Book a free roof inspection online with Corner Stone Construction & Roofing in Evansville Indiana. Same-week scheduling. No obligation, no pressure, no catch. Choose your date & time. Serving Evansville IN, Newburgh, Henderson KY & Tri-State."
        keywords="free roof inspection Evansville Indiana, book roof inspection online, schedule roof inspection Evansville, free roof check Indiana, storm damage inspection booking, roof inspection appointment"
        canonical="/free-inspection"
      />

      {/* ── SOCIAL PROOF TICKER ── */}
      <div className="bg-charcoal border-b border-white/10 overflow-hidden py-2.5">
        <div className="flex items-center gap-8 ticker-track whitespace-nowrap">
          {[...SOCIAL_PROOF_TICKER, ...SOCIAL_PROOF_TICKER, ...SOCIAL_PROOF_TICKER].map((item, i) => (
            <span key={i} className="flex items-center gap-2 text-white/40 text-xs uppercase tracking-widest">
              <i className="ri-check-line text-orange" />
              {item}
            </span>
          ))}
        </div>
      </div>

      {/* ── HERO + FORM ── */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1600x900.svg"
            alt="Free roof inspection Evansville Indiana"
            className="w-full h-full object-cover object-top opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/70 via-charcoal-deep/60 to-charcoal-deep" />
        </div>

        <div className="relative z-10 px-6 md:px-10 lg:px-16 py-16 md:py-20 lg:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-start max-w-7xl mx-auto">
            {/* Left: copy */}
            <div
              ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
              className={`anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
            >
              <div className="flex flex-wrap items-center gap-3 mb-6">
                <div className="flex items-center gap-2 border border-orange/40 bg-orange/10 backdrop-blur-sm px-3 py-1.5 text-orange text-xs uppercase tracking-widest">
                  <i className="ri-flashlight-line text-sm" />
                  Limited Spots — Book This Week
                </div>
                <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-3 py-1.5 text-white/60 text-xs uppercase tracking-widest">
                  <span className="w-1.5 h-1.5 rounded-full bg-orange" />
                  100% Free — No Catch
                </div>
              </div>

              <h1 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
                Know Your Roof.<br />
                <span className="text-orange">Free.</span> Fast. No Pressure.
              </h1>

              <p className="text-white/50 text-base md:text-lg leading-relaxed max-w-lg mb-6">
                Book a certified roof inspection in Evansville and the Tri-State area. We get on your roof, document everything with photos, and deliver a full report — completely free, zero obligation.
              </p>

              <div className="mb-8">
                <CountdownTimer expiresAt={nearestExpiry} variant="banner" />
                <div className="mt-3">
                  <SocialProofPulse />
                </div>
              </div>

              {/* Trust badges */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
                {TRUST_BADGES.map((badge) => (
                  <div key={badge.label} className="border border-white/10 bg-white/5 backdrop-blur-sm px-4 py-3">
                    <i className={`${badge.icon} text-orange text-sm mb-1 block`} />
                    <p className="text-white text-xs font-semibold">{badge.label}</p>
                    <p className="text-white/30 text-[10px] uppercase tracking-wider">{badge.sub}</p>
                  </div>
                ))}
              </div>

              {/* Phone CTA */}
              <div className="flex items-center gap-4">
                <a href="tel:8122135997" className="flex items-center gap-2 text-white hover:text-orange transition-colors">
                  <i className="ri-phone-fill text-orange text-xl" />
                  <span className="font-display text-2xl tracking-wider">812-213-5997</span>
                </a>
                <span className="text-white/30 text-xs hidden sm:inline">Or book online →</span>
              </div>
            </div>

            {/* Right: form */}
            <div className="lg:sticky lg:top-24">
              <InspectionForm compact />
            </div>
          </div>
        </div>
      </section>

      <TalkToAIExpert />

      {/* ── HOW IT WORKS ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Simple Process</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Book. Inspect. Know.<br />In 4 Easy Steps.
          </h2>
        </div>
        <div
          ref={howAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-6xl mx-auto"
        >
          {HOW_IT_WORKS.map((item, i) => (
            <div
              key={item.step}
              className={`relative border border-white/10 bg-charcoal-mid p-6 anim-fade-up ${howAnim.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="font-display text-white/10 text-5xl leading-none absolute top-3 right-4 select-none">{item.step}</div>
              <div className="w-10 h-10 flex items-center justify-center bg-orange/15 mb-4 relative z-10">
                <i className={`${item.icon} text-orange text-lg`} />
              </div>
              <h3 className="font-display text-white text-lg uppercase tracking-wider mb-2 relative z-10">{item.title}</h3>
              <p className="text-white/50 text-xs leading-relaxed relative z-10">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Real Homeowners</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 4.5rem)' }}>
            What People Say
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-6xl mx-auto">
          {TESTIMONIALS.map((t, i) => (
            <div
              key={t.name}
              ref={i === 0 ? trustAnim.ref : undefined}
              className={`border border-white/10 bg-charcoal-mid p-7 anim-fade-up ${trustAnim.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <div className="flex gap-0.5 mb-4">
                {[...Array(t.stars)].map((_, j) => (
                  <i key={j} className="ri-star-fill text-orange text-sm" />
                ))}
              </div>
              <p className="text-white/60 text-sm leading-relaxed italic mb-5">"{t.quote}"</p>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 flex items-center justify-center bg-orange/20 text-orange text-xs font-bold">
                  {t.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <p className="text-white text-xs font-semibold">{t.name}</p>
                  <p className="text-white/30 text-xs">{t.loc} — Google Review</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── WHAT HAPPENS IF YOU WAIT ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">The Cost of Waiting</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              Every Day You Wait,<br />The Risk Grows.
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
              A free inspection takes 45 minutes and costs nothing. Ignoring a potential roof problem can cost thousands — or worse, your entire roof and interior. Here is what happens when homeowners delay.
            </p>
            <button
              onClick={() => document.getElementById('booking-form')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap"
            >
              <i className="ri-calendar-check-line" />
              Book Before It Gets Worse
            </button>
          </div>
          <div
            ref={riskAnim.ref as React.RefObject<HTMLDivElement>}
            className="grid grid-cols-1 sm:grid-cols-2 gap-4"
          >
            {WAITING_RISKS.map((risk, i) => (
              <div
                key={risk.title}
                className={`border border-white/10 bg-charcoal-mid p-5 hover:border-orange/30 transition-all duration-300 group anim-fade-up ${riskAnim.isVisible ? 'is-visible' : ''}`}
                style={{ transitionDelay: `${i * 70}ms` }}
              >
                <div className="w-10 h-10 flex items-center justify-center bg-orange/15 group-hover:bg-orange/25 transition-colors mb-3">
                  <i className={`${risk.icon} text-orange text-lg`} />
                </div>
                <h3 className="text-white font-semibold text-sm mb-1.5">{risk.title}</h3>
                <p className="text-white/40 text-xs leading-relaxed">{risk.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Still Have Questions?</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Free Inspection FAQ
            </h2>
          </div>
          <div
            ref={faqAnim.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${faqAnim.isVisible ? 'is-visible' : ''}`}
          >
            {FAQS.map((faq, i) => (
              <div key={i} className="border-b border-white/10">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between py-5 text-left cursor-pointer group"
                >
                  <span className="font-display text-white text-lg uppercase tracking-wider pr-4 group-hover:text-orange transition-colors">{faq.q}</span>
                  <div className={`w-8 h-8 flex items-center justify-center border flex-shrink-0 transition-all duration-300 ${openFaq === i ? 'bg-orange border-orange text-white' : 'border-white/20 text-white/40 group-hover:border-orange group-hover:text-orange'}`}>
                    <i className={`ri-${openFaq === i ? 'subtract' : 'add'}-line`} />
                  </div>
                </button>
                <div className={`overflow-hidden transition-all duration-500 ${openFaq === i ? 'max-h-56 opacity-100 pb-5' : 'max-h-0 opacity-0'}`}>
                  <p className="text-white/50 text-sm leading-relaxed pr-12">{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FINAL CTA ── */}
      <section id="booking-form" className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="max-w-5xl mx-auto">
          <div
            ref={formAnim.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${formAnim.isVisible ? 'is-visible' : ''}`}
          >
            <div className="text-center mb-10">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Ready to Book?</p>
              <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2.5rem, 5vw, 4.5rem)' }}>
                Schedule Your Free<br />Inspection Right Now.
              </h2>
              <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
                Same-week availability. No charge. No pressure. Just honest answers from a local expert.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-10 items-start">
              <div className="lg:col-span-3">
                <InspectionForm />
              </div>
              <div className="lg:col-span-2 space-y-6">
                <div className="bg-charcoal-mid border border-white/10 p-6">
                  <h3 className="font-display text-white text-lg uppercase tracking-wider mb-4">What to Expect</h3>
                  <div className="space-y-4">
                    {[
                      { icon: 'ri-shield-check-line', title: 'Licensed & Insured', desc: 'Fully licensed in Indiana and Kentucky with $2M liability coverage.' },
                      { icon: 'ri-time-line', title: 'Same-Week Scheduling', desc: 'Most inspections are scheduled within 3–5 business days of booking.' },
                      { icon: 'ri-file-list-3-line', title: 'Detailed Report', desc: 'You receive a full written report with photos within 24 hours of the inspection.' },
                      { icon: 'ri-money-dollar-circle-line', title: '100% Free', desc: 'No charge, no obligation, no sales pressure. Ever.' },
                    ].map((item) => (
                      <div key={item.title} className="flex items-start gap-3">
                        <div className="w-8 h-8 flex items-center justify-center bg-orange/15 flex-shrink-0">
                          <i className={`${item.icon} text-orange text-sm`} />
                        </div>
                        <div>
                          <p className="text-white text-sm font-semibold">{item.title}</p>
                          <p className="text-white/40 text-xs leading-relaxed">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bg-orange/10 border border-orange/20 p-6">
                  <p className="text-orange text-xs uppercase tracking-wider font-semibold mb-3">Prefer to Call?</p>
                  <p className="text-white font-display text-2xl uppercase tracking-wider mb-2">812-213-5997</p>
                  <p className="text-white/40 text-xs leading-relaxed mb-4">
                    We can book your inspection over the phone in under 2 minutes.
                  </p>
                  <a href="tel:8122135997" className="flex items-center justify-center gap-2 bg-orange hover:bg-orange-dark text-white font-semibold px-5 py-3 uppercase tracking-wide text-sm transition-colors whitespace-nowrap">
                    <i className="ri-phone-line" />
                    Call to Book
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── BOTTOM TRUST STRIP ── */}
      <section className="border-t border-white/10 py-14 md:py-20 px-6 md:px-10 lg:px-16">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Our Promise</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}>
            No Charge. No Pressure.<br />Just Honest Answers.
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-2xl mx-auto leading-relaxed mb-8">
            Every free inspection includes a complete roof assessment, photo documentation, and a written condition summary. If your roof is in good shape, we'll tell you. If it needs attention, we'll show you exactly why — with photos and clear explanations. The decision is always yours.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="tel:8122135997" className="border border-white/20 hover:border-white text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2">
              <i className="ri-phone-line text-orange" />
              Call 812-213-5997
            </a>
            <button
              onClick={() => document.getElementById('booking-form')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
            >
              <i className="ri-calendar-check-line" />
              Book Online Now
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}