import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import { trackToolUsage, trackConversion } from '@/lib/toolAnalytics';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { OFFERS } from '@/mocks/promotions';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

/* ─── Types ─── */
interface TimeSlot {
  time: string;
  label: string;
  available: boolean;
}

interface DayInfo {
  date: number;
  month: number;
  year: number;
  fullDate: string;
  dayName: string;
  available: boolean;
  isToday: boolean;
}

const SERVICES = [
  { key: 'inspection', label: 'Free Roof Inspection', icon: 'ri-search-line', duration: '60 min' },
  { key: 'repair', label: 'Roof Repair', icon: 'ri-tools-line', duration: '2–4 hrs' },
  { key: 'replacement', label: 'Full Replacement Estimate', icon: 'ri-home-4-line', duration: '90 min' },
  { key: 'gutters', label: 'Gutter Installation', icon: 'ri-water-flash-line', duration: '2–3 hrs' },
  { key: 'siding', label: 'Siding Consultation', icon: 'ri-layout-masonry-line', duration: '60 min' },
  { key: 'emergency', label: 'Emergency Tarp / Leak', icon: 'ri-alarm-warning-line', duration: '30–60 min' },
];

const TIME_SLOTS: TimeSlot[] = [
  { time: '08:00', label: '8:00 AM', available: true },
  { time: '09:00', label: '9:00 AM', available: true },
  { time: '10:00', label: '10:00 AM', available: true },
  { time: '11:00', label: '11:00 AM', available: true },
  { time: '13:00', label: '1:00 PM', available: true },
  { time: '14:00', label: '2:00 PM', available: true },
  { time: '15:00', label: '3:00 PM', available: true },
  { time: '16:00', label: '4:00 PM', available: true },
];

const nearestExpiry = OFFERS
  .filter((o) => o.expires)
  .map((o) => o.expires!)
  .sort()[0] || '2026-12-31';

const WEATHER_TIPS = [
  { condition: 'Sunny', icon: 'ri-sun-line', tip: 'Perfect day for exterior work — full crew availability.' },
  { condition: 'Partly Cloudy', icon: 'ri-cloudy-line', tip: 'Good visibility for inspection — recommended.' },
  { condition: 'Light Rain', icon: 'ri-drizzle-line', tip: 'Inspection still possible — we use drone imaging if needed.' },
  { condition: 'Windy', icon: 'ri-windy-line', tip: 'Tarping crews available — ladder work may be limited.' },
];

function generateCalendarDays(): DayInfo[] {
  const today = new Date();
  const days: DayInfo[] = [];
  for (let i = 0; i < 21; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
    const isWeekend = d.getDay() === 0 || d.getDay() === 6;
    days.push({
      date: d.getDate(),
      month: d.getMonth(),
      year: d.getFullYear(),
      fullDate: d.toISOString().split('T')[0],
      dayName,
      available: !isWeekend,
      isToday: i === 0,
    });
  }
  return days;
}

export default function InstantSchedulerPage() {
  const navigate = useNavigate();
  const calendarDays = generateCalendarDays();
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedDay, setSelectedDay] = useState<DayInfo | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const resultRef = useRef<HTMLDivElement>(null);

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');

  const weatherTip = WEATHER_TIPS[Math.floor(Math.random() * WEATHER_TIPS.length)];

  useEffect(() => {
    if (step === 4 && resultRef.current) {
      setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
    }
  }, [step]);

  useEffect(() => {
    if (formStatus === 'success') {
      trackToolUsage('instant-scheduler', 'Instant Scheduler');
      trackConversion('inspection_booking');
    }
  }, [formStatus]);

  const handleServiceSelect = (key: string) => {
    setSelectedService(key);
    setStep(2);
  };

  const handleDaySelect = (day: DayInfo) => {
    if (!day.available) return;
    setSelectedDay(day);
    setSelectedTime(null);
    setStep(3);
  };

  const handleTimeSelect = (time: string) => {
    setSelectedTime(time);
    setStep(4);
  };

  const handleBack = () => {
    if (step === 4) { setSelectedTime(null); setStep(3); }
    else if (step === 3) { setSelectedDay(null); setStep(2); }
    else if (step === 2) { setSelectedService(null); setStep(1); }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setFormStatus('submitting');
    try {
      const formData = new FormData(e.currentTarget);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
      await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as unknown as Record<string, string>),
      });
      setFormStatus('success');
    } catch {
      setFormStatus('error');
    }
  };

  const selectedServiceData = SERVICES.find((s) => s.key === selectedService);
  const canSubmit = name && phone && address;

  return (
    <>
      <PageSEO
        title="Instant Scheduler — Book Your Roof Appointment | Corner Stone Roofing"
        description="Book your free roof inspection, repair, or estimate online in under 60 seconds. Pick your service, choose a date & time, and get confirmed instantly."
        keywords="schedule roof inspection, book roofing appointment, roof estimate scheduler, Evansville roofer booking"
        canonical="https://cornerstoneconstruction.com/instant-scheduler"
        schema={{
          '@context': 'https://schema.org',
          '@type': 'SoftwareApplication',
          name: 'Instant Roof Appointment Scheduler',
          applicationCategory: 'BusinessApplication',
          operatingSystem: 'Web',
          offers: {
            '@type': 'Offer',
            price: '0',
            priceCurrency: 'USD',
          },
          aggregateRating: {
            '@type': 'AggregateRating',
            ratingValue: '4.9',
            ratingCount: '312',
          },
          description: 'Free online scheduling tool for roofing services in Evansville and the Tri-State area. Book free inspections, repairs, replacements, gutters, siding, or emergency tarping in under 60 seconds with real-time calendar availability.',
          softwareVersion: '2026.05',
          publisher: {
            '@type': 'Organization',
            name: 'Corner Stone Construction & Roofing',
            url: 'https://cornerstoneconstructionevansville.com',
          },
        }}
      />

      {/* ── Hero ── */}
      <section className="bg-charcoal-deep pt-28 pb-16 md:pt-36 md:pb-24 px-6 md:px-10 lg:px-16">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Book in 60 Seconds</p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Instant<br /><span className="text-orange">Scheduler</span>
          </h1>
          <p className="text-white/50 text-sm md:text-base max-w-2xl mx-auto leading-relaxed mb-8">
            Skip the phone tag. Pick your service, choose a date and time that works for you, and lock in your appointment. Our crew will show up ready to work.
          </p>

          {/* Urgency Stack */}
          <div className="max-w-4xl mx-auto mb-0">
            <div className="flex justify-center">
              <CountdownTimer expiresAt={nearestExpiry} variant="banner" />
            </div>
            <div className="mt-3 flex justify-center">
              <SocialProofPulse />
            </div>
          </div>
        </div>
      </section>

      {/* ── Main Tool ── */}
      <section className="bg-warm-beige py-16 md:py-24 px-6 md:px-10 lg:px-16">
        <div className="max-w-4xl mx-auto">
          {/* Progress */}
          <div className="flex items-center bg-charcoal-deep px-6 md:px-10 py-5 mb-8">
            {[1, 2, 3, 4].map((s) => (
              <div key={s} className="flex items-center flex-1">
                <div className={`w-8 h-8 flex items-center justify-center text-xs font-bold uppercase tracking-wider transition-colors ${s <= step ? 'bg-orange text-white' : 'bg-white/10 text-white/30'}`}>
                  {s}
                </div>
                <span className={`ml-3 text-xs font-semibold uppercase tracking-wider hidden sm:block transition-colors ${s <= step ? 'text-white' : 'text-white/30'}`}>
                  {s === 1 ? 'Service' : s === 2 ? 'Date' : s === 3 ? 'Time' : 'Confirm'}
                </span>
                {s < 4 && (
                  <div className="flex-1 h-px mx-3 md:mx-4 bg-white/10">
                    <div className={`h-full bg-orange transition-all duration-500 ${s < step ? 'w-full' : 'w-0'}`} />
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Step 1: Service */}
          {step === 1 && (
            <div className="bg-white border border-charcoal/5 p-6 md:p-10">
              <h2 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider mb-2">What Do You Need?</h2>
              <p className="text-charcoal-mid/40 text-sm mb-8">Select the service type and we will match you with the right crew.</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {SERVICES.map((svc) => (
                  <button
                    key={svc.key}
                    onClick={() => handleServiceSelect(svc.key)}
                    className="group text-left p-5 border border-charcoal/10 hover:border-orange hover:bg-orange/5 transition-all duration-200 cursor-pointer"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="w-10 h-10 flex items-center justify-center bg-charcoal-deep text-white group-hover:bg-orange transition-colors">
                        <i className={`${svc.icon} text-lg`} />
                      </div>
                      <div className="w-8 h-8 flex items-center justify-center border border-charcoal/10 group-hover:border-orange group-hover:bg-orange group-hover:text-white transition-all">
                        <i className="ri-arrow-right-line text-sm" />
                      </div>
                    </div>
                    <p className="font-display text-charcoal-deep text-sm uppercase tracking-wide mb-1">{svc.label}</p>
                    <p className="text-charcoal-mid/40 text-xs">{svc.duration}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Date */}
          {step === 2 && selectedServiceData && (
            <div className="bg-white border border-charcoal/5 p-6 md:p-10">
              <div className="flex items-center gap-3 mb-6">
                <button onClick={handleBack} className="text-charcoal-mid/40 hover:text-orange text-xs uppercase tracking-wider flex items-center gap-1 transition-colors cursor-pointer">
                  <i className="ri-arrow-left-line" /> Back
                </button>
              </div>
              <h2 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider mb-2">Pick a Date</h2>
              <p className="text-charcoal-mid/40 text-sm mb-2">
                <span className="inline-flex items-center gap-1.5 text-orange text-xs font-semibold uppercase tracking-wider mr-3">
                  <i className={weatherTip.icon} />
                  {weatherTip.condition}
                </span>
                {weatherTip.tip}
              </p>
              <p className="text-charcoal-mid/30 text-xs mb-8">Gray dates are unavailable. We book Monday–Saturday with 48-hour notice.</p>

              <div className="grid grid-cols-7 gap-2 mb-6">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
                  <div key={d} className="text-center text-charcoal-mid/30 text-xs font-semibold uppercase tracking-wider py-2">
                    {d}
                  </div>
                ))}
                {calendarDays.map((day) => (
                  <button
                    key={day.fullDate}
                    onClick={() => handleDaySelect(day)}
                    disabled={!day.available}
                    className={`relative p-3 text-center border transition-all cursor-pointer ${
                      selectedDay?.fullDate === day.fullDate
                        ? 'border-orange bg-orange text-white'
                        : day.available
                        ? 'border-charcoal/10 hover:border-charcoal/30 bg-white text-charcoal-deep'
                        : 'border-transparent bg-gray-100 text-charcoal-mid/20 cursor-not-allowed'
                    }`}
                  >
                    <span className={`text-sm font-semibold ${day.isToday && selectedDay?.fullDate !== day.fullDate ? 'text-orange' : ''}`}>
                      {day.date}
                    </span>
                    <span className="block text-[10px] uppercase tracking-wider mt-0.5 opacity-60">{day.dayName}</span>
                    {day.isToday && (
                      <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-orange rounded-full" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 3: Time */}
          {step === 3 && selectedDay && selectedServiceData && (
            <div className="bg-white border border-charcoal/5 p-6 md:p-10">
              <div className="flex items-center gap-3 mb-6">
                <button onClick={handleBack} className="text-charcoal-mid/40 hover:text-orange text-xs uppercase tracking-wider flex items-center gap-1 transition-colors cursor-pointer">
                  <i className="ri-arrow-left-line" /> Back
                </button>
              </div>
              <h2 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider mb-2">Select a Time</h2>
              <p className="text-charcoal-mid/40 text-sm mb-8">
                {selectedDay.dayName}, {selectedDay.month + 1}/{selectedDay.date}/{selectedDay.year} — {selectedServiceData.label}
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {TIME_SLOTS.map((slot) => (
                  <button
                    key={slot.time}
                    onClick={() => handleTimeSelect(slot.time)}
                    disabled={!slot.available}
                    className={`p-4 border text-center transition-all cursor-pointer ${
                      selectedTime === slot.time
                        ? 'border-orange bg-orange text-white'
                        : slot.available
                        ? 'border-charcoal/10 hover:border-charcoal/30 text-charcoal-deep'
                        : 'border-transparent bg-gray-100 text-charcoal-mid/20 cursor-not-allowed'
                    }`}
                  >
                    <span className="font-display text-base uppercase tracking-wide block">{slot.label}</span>
                    {selectedTime === slot.time && (
                      <span className="text-white/70 text-xs mt-1 block">Selected</span>
                    )}
                  </button>
                ))}
              </div>

              {/* AI Suggestion */}
              <div className="mt-8 bg-charcoal-deep/5 border border-charcoal/5 p-5 flex items-start gap-3">
                <div className="w-10 h-10 flex items-center justify-center bg-charcoal-deep text-orange flex-shrink-0">
                  <i className="ri-robot-2-line text-lg" />
                </div>
                <div>
                  <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1">AI Scheduling Tip</p>
                  <p className="text-charcoal-mid/50 text-sm leading-relaxed">
                    Morning slots (8–10 AM) are best for inspections — cooler temps mean clearer thermal imaging for leak detection.
                    Afternoon slots work great for repairs — materials cure better in warmer afternoon sun.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Confirm */}
          {step === 4 && selectedDay && selectedTime && selectedServiceData && (
            <div ref={resultRef} className="bg-white border border-charcoal/5 p-6 md:p-10">
              <div className="flex items-center gap-3 mb-6">
                <button onClick={handleBack} className="text-charcoal-mid/40 hover:text-orange text-xs uppercase tracking-wider flex items-center gap-1 transition-colors cursor-pointer">
                  <i className="ri-arrow-left-line" /> Back
                </button>
              </div>

              {/* Summary */}
              <div className="bg-charcoal-deep p-6 md:p-8 mb-8 flex flex-col md:flex-row items-center gap-4 md:gap-6">
                <div className="w-14 h-14 flex items-center justify-center bg-orange text-white flex-shrink-0">
                  <i className={`${selectedServiceData.icon} text-2xl`} />
                </div>
                <div className="text-center md:text-left">
                  <p className="text-orange text-xs font-semibold uppercase tracking-wider mb-1">Appointment Summary</p>
                  <p className="text-white text-lg md:text-xl font-semibold">{selectedServiceData.label}</p>
                  <p className="text-white/50 text-sm mt-1">
                    {selectedDay.dayName}, {selectedDay.month + 1}/{selectedDay.date}/{selectedDay.year} at {TIME_SLOTS.find((t) => t.time === selectedTime)?.label}
                  </p>
                </div>
              </div>

              {formStatus === 'success' ? (
                <div className="text-center py-10">
                  <div className="w-16 h-16 flex items-center justify-center bg-orange/10 border border-orange/30 mx-auto mb-5">
                    <i className="ri-check-double-line text-orange text-3xl" />
                  </div>
                  <h3 className="font-display text-charcoal-deep text-xl uppercase tracking-wider mb-2">You're Booked!</h3>
                  <p className="text-charcoal-mid/50 text-sm max-w-md mx-auto mb-6">
                    We will send a confirmation text and email shortly. A crew lead will call 30 minutes before arrival.
                  </p>
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3">
                    <button
                      onClick={() => navigate('/')}
                      className="bg-charcoal-deep hover:bg-charcoal-mid text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
                    >
                      Back to Home
                    </button>
                    <a
                      href="tel:8122135997"
                      className="border border-charcoal/20 hover:border-charcoal-deep text-charcoal-deep font-semibold px-8 py-3.5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2"
                    >
                      <i className="ri-phone-line text-orange" />
                      812-213-5997
                    </a>
                  </div>
                </div>
              ) : (
                <form id="instant-scheduler-form" data-readdy-form onSubmit={handleSubmit}>
                  <h3 className="font-display text-charcoal-deep text-lg uppercase tracking-wider mb-6">Your Contact Info</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Full Name</label>
                      <input
                        type="text"
                        name="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                        placeholder="John Smith"
                        className="w-full bg-gray-100 px-4 py-3.5 text-charcoal-deep text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                    <div>
                      <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Phone</label>
                      <input
                        type="tel"
                        name="phone"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        required
                        placeholder="812-555-1234"
                        className="w-full bg-gray-100 px-4 py-3.5 text-charcoal-deep text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Email</label>
                      <input
                        type="email"
                        name="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="john@email.com"
                        className="w-full bg-gray-100 px-4 py-3.5 text-charcoal-deep text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                    <div>
                      <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Property Address</label>
                      <input
                        type="text"
                        name="address"
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        required
                        placeholder="123 Main St, Evansville, IN"
                        className="w-full bg-gray-100 px-4 py-3.5 text-charcoal-deep text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                  </div>
                  <div className="mb-6">
                    <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Notes (Optional)</label>
                    <textarea
                      name="notes"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Gate code, dog in yard, specific concerns..."
                      rows={3}
                      maxLength={500}
                      className="w-full bg-gray-100 px-4 py-3.5 text-charcoal-deep text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
                    />
                    <p className="text-charcoal-mid/30 text-xs mt-1">{notes.length}/500 characters</p>
                  </div>

                  {/* Hidden fields */}
                  <input type="hidden" name="service" value={selectedServiceData.label} />
                  <input type="hidden" name="date" value={`${selectedDay.month + 1}/${selectedDay.date}/${selectedDay.year}`} />
                  <input type="hidden" name="time" value={TIME_SLOTS.find((t) => t.time === selectedTime)?.label || selectedTime} />

                  <button
                    type="submit"
                    disabled={!canSubmit || formStatus === 'submitting'}
                    className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-bold text-sm uppercase tracking-widest py-4 transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                  >
                    {formStatus === 'submitting' ? (
                      <><i className="ri-loader-4-line animate-spin" />Booking...</>
                    ) : (
                      <><i className="ri-calendar-check-line" />Confirm Appointment</>
                    )}
                  </button>
                  {formStatus === 'error' && (
                    <p className="text-red-500 text-sm mt-3 text-center">Something went wrong. Please call 812-213-5997 to book.</p>
                  )}
                </form>
              )}
            </div>
          )}
        </div>
      </section>

      {/* ── Trust Bar ── */}
      <section className="bg-charcoal-deep py-12 px-6 md:px-10 lg:px-16">
        <div className="max-w-4xl mx-auto flex flex-wrap items-center justify-center gap-6 md:gap-10">
          <div className="flex items-center gap-2 text-white/30 text-xs">
            <i className="ri-time-line text-orange" />Same-day slots available
          </div>
          <div className="flex items-center gap-2 text-white/30 text-xs">
            <i className="ri-shield-check-line text-orange" />No charge until work begins
          </div>
          <div className="flex items-center gap-2 text-white/30 text-xs">
            <i className="ri-calendar-check-line text-orange" />Reschedule anytime
          </div>
        </div>
      </section>

      {/* ── Alex AI Help Strip ── */}
      <TalkToAIExpert />
    </>
  );
}