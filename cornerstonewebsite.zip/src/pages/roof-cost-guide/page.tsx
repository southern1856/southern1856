import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import TestimonialsSection from '@/components/feature/TestimonialsSection';
import FAQSection from '@/components/feature/FAQSection';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { OFFERS } from '@/mocks/promotions';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const GUIDE_CONTENT = [
  {
    icon: 'ri-money-dollar-circle-line',
    title: 'Real Local Pricing',
    desc: 'See exactly what Evansville homeowners paid for asphalt, metal, tile, and slate roofs in 2025–2026. No vague national averages — real Tri-State numbers.',
  },
  {
    icon: 'ri-home-gear-line',
    title: 'Home Size Calculator',
    desc: 'From 1,200 sq ft bungalows to 4,000+ sq ft homes — we break down costs per square foot so you can estimate your project before calling anyone.',
  },
  {
    icon: 'ri-alert-line',
    title: 'Hidden Costs Exposed',
    desc: 'Permits, tear-off, disposal, plywood replacement, flashing upgrades — the fees contractors forget to mention until the invoice arrives.',
  },
  {
    icon: 'ri-shield-star-line',
    title: 'Insurance Claim Guide',
    desc: 'How to get your insurer to cover storm damage, what documentation you need, and how to avoid getting lowballed by the adjuster.',
  },
  {
    icon: 'ri-bank-card-line',
    title: 'Financing Breakdown',
    desc: '$0 down options, monthly payment ranges, credit requirements, and how to choose the best roofing loan for your budget.',
  },
  {
    icon: 'ri-calendar-todo-line',
    title: 'Best Timing Strategy',
    desc: 'When to schedule your replacement to save money, avoid weather delays, and get the best crew availability in Evansville.',
  },
];

const SAMPLE_STATS = [
  { label: 'Asphalt Shingle', range: '$8,500 – $16,000', avg: '1,800 sq ft home', icon: 'ri-home-4-line' },
  { label: 'Metal Roof', range: '$16,000 – $30,000', avg: '1,800 sq ft home', icon: 'ri-home-5-line' },
  { label: 'Tile Roof', range: '$22,000 – $38,000', avg: '1,800 sq ft home', icon: 'ri-home-6-line' },
  { label: 'Slate Roof', range: '$35,000 – $65,000', avg: '1,800 sq ft home', icon: 'ri-building-4-line' },
];

export default function RoofCostGuidePage() {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const formRef = useRef<HTMLFormElement>(null);
  const navigate = useNavigate();
  const hero = useScrollAnimation();
  const stats = useScrollAnimation({ threshold: 0.1 });
  const content = useScrollAnimation({ threshold: 0.05 });

  const now = Date.now();
  const nearestExpiry = OFFERS.filter(o => new Date(o.expiresAt).getTime() > now)
    .sort((a, b) => new Date(a.expiresAt).getTime() - new Date(b.expiresAt).getTime())[0];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;

    const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
    const email = formData.get('email') as string;
    const name = formData.get('name') as string;
    if (!email?.trim() || !name?.trim()) return;

    setStatus('submitting');
    try {
      const response = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      if (response.ok) {
        setStatus('success');
        formRef.current.reset();
        navigate('/guide-sent');
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    }
  };

  const schema = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: '2026 Roof Replacement Cost Guide for Evansville Homeowners',
    description: 'Free downloadable PDF guide with real Evansville roof replacement pricing, material costs, financing options, and insurance claim tips.',
  };

  return (
    <div className="min-h-screen bg-warm-beige">
      <PageSEO
        title="Free Roof Replacement Cost Guide 2026 | Evansville Indiana PDF"
        description="Download our free 2026 Roof Replacement Cost Guide for Evansville homeowners. Real pricing for asphalt, metal, tile, and slate. Financing, insurance tips, and hidden fee breakdowns included."
        keywords="roof replacement cost Evansville, roof cost guide Indiana, how much does a new roof cost, Evansville roofing prices, free roof cost estimate PDF, roofing material costs 2026"
        canonical="/roof-cost-guide"
        schema={schema}
      />


      {/* HERO */}
      <section className="relative bg-charcoal-deep pt-32 pb-16 md:pb-24 overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-[0.02]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '60px 60px' }} />
        <div className="absolute -top-40 -right-40 w-[500px] h-[500px] rounded-full opacity-10" style={{ background: 'radial-gradient(circle, #e8621a 0%, transparent 70%)' }} />

        <div className="relative z-10 w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-5xl mx-auto">
            <div
              ref={hero.ref as React.RefObject<HTMLDivElement>}
              className={`text-center anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
            >
              <div className="inline-flex items-center gap-2 bg-orange/15 border border-orange/30 px-4 py-2 mb-8">
                <i className="ri-file-download-line text-orange text-sm" />
                <span className="text-orange text-xs font-bold uppercase tracking-[0.2em]">Free Download — Instant Access</span>
              </div>

              <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
                How Much Does a New<br />
                Roof <span className="text-orange">Actually Cost</span><br />
                in Evansville?
              </h1>

              <p className="text-white/50 text-base md:text-lg leading-relaxed max-w-2xl mx-auto mb-10">
                Most homeowners get quotes ranging from $8,000 to $65,000 and have no idea why. This 18-page guide reveals the real numbers — broken down by material, home size, and what's actually included.
              </p>

              {/* Quick stats strip */}
              <div className="flex flex-wrap items-center justify-center gap-6 md:gap-10 mb-10">
                <div className="text-center">
                  <p className="font-display text-white text-3xl tracking-wider">18</p>
                  <p className="text-white/40 text-xs uppercase tracking-widest mt-1">Pages</p>
                </div>
                <div className="w-px h-10 bg-white/10" />
                <div className="text-center">
                  <p className="font-display text-white text-3xl tracking-wider">4</p>
                  <p className="text-white/40 text-xs uppercase tracking-widest mt-1">Materials Covered</p>
                </div>
                <div className="w-px h-10 bg-white/10" />
                <div className="text-center">
                  <p className="font-display text-white text-3xl tracking-wider">$0</p>
                  <p className="text-white/40 text-xs uppercase tracking-widest mt-1">Cost to Download</p>
                </div>
                <div className="w-px h-10 bg-white/10 hidden sm:block" />
                <div className="text-center hidden sm:block">
                  <p className="font-display text-white text-3xl tracking-wider">2026</p>
                  <p className="text-white/40 text-xs uppercase tracking-widest mt-1">Updated Pricing</p>
                </div>
              </div>

              {/* Urgency stack — time pressure + social proof before the download CTA */}
              <div className="mb-8">
                {nearestExpiry && (
                  <CountdownTimer
                    expiryDate={nearestExpiry.expiresAt}
                    variant="banner"
                  />
                )}
                <SocialProofPulse />
              </div>

              {/* CTA buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <a
                  href="#download"
                  onClick={(e) => {
                    e.preventDefault();
                    document.querySelector('#download')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-download-2-line" />
                  Download Free Guide
                </a>
                <button
                  onClick={() => navigate('/free-inspection')}
                  className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-calendar-check-line" />
                  Book Free Inspection Instead
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <TalkToAIExpert />

      {/* Sample pricing preview */}
      <section className="py-16 md:py-20 bg-white">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-5xl mx-auto">
            <div
              ref={stats.ref as React.RefObject<HTMLDivElement>}
              className={`text-center mb-12 anim-fade-up ${stats.isVisible ? 'is-visible' : ''}`}
            >
              <p className="text-orange text-xs font-semibold uppercase tracking-[0.25em] mb-4">Sneak Peek from the Guide</p>
              <h2 className="font-display text-charcoal uppercase tracking-wider text-3xl md:text-4xl mb-3">
                Evansville Roof Replacement Costs
              </h2>
              <p className="text-charcoal/50 text-base">Based on 1,800 sq ft single-story homes in Vanderburgh County (2025–2026 data)</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {SAMPLE_STATS.map((stat, i) => (
                <div
                  key={stat.label}
                  className={`border border-charcoal/10 p-6 text-center anim-fade-up ${stats.isVisible ? 'is-visible' : ''}`}
                  style={{ transitionDelay: `${i * 80}ms` }}
                >
                  <div className="w-10 h-10 flex items-center justify-center bg-orange/10 rounded-md mx-auto mb-3">
                    <i className={`${stat.icon} text-orange text-lg`} />
                  </div>
                  <p className="text-charcoal font-semibold text-sm mb-1">{stat.label}</p>
                  <p className="font-display text-charcoal text-2xl tracking-wider">{stat.range}</p>
                  <p className="text-charcoal/40 text-xs mt-1">{stat.avg}</p>
                </div>
              ))}
            </div>

            <p className="text-charcoal/40 text-xs text-center mt-6">
              * Prices include tear-off, materials, labor, disposal, and standard permits. Complex roofs, steep pitches, or additional repairs may increase costs. Full breakdown inside the guide.
            </p>
          </div>
        </div>
      </section>

      {/* What's inside */}
      <section className="py-16 md:py-24 bg-warm-beige">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-5xl mx-auto">
            <div
              ref={content.ref as React.RefObject<HTMLDivElement>}
              className={`text-center mb-14 anim-fade-up ${content.isVisible ? 'is-visible' : ''}`}
            >
              <p className="text-orange text-xs font-semibold uppercase tracking-[0.25em] mb-4">Inside the Guide</p>
              <h2 className="font-display text-charcoal uppercase tracking-wider text-3xl md:text-4xl mb-4">
                Everything You Need to Budget<br />With Confidence
              </h2>
              <p className="text-charcoal/50 text-base max-w-xl mx-auto">
                We pulled real invoices, talked to local suppliers, and surveyed 200+ Evansville homeowners to build this. Here's what you'll learn:
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
              {GUIDE_CONTENT.map((item, i) => (
                <div
                  key={item.title}
                  className={`bg-white border border-charcoal/10 p-6 md:p-8 anim-fade-up ${content.isVisible ? 'is-visible' : ''}`}
                  style={{ transitionDelay: `${i * 80}ms` }}
                >
                  <div className="w-10 h-10 flex items-center justify-center bg-orange/10 rounded-md mb-4">
                    <i className={`${item.icon} text-orange text-lg`} />
                  </div>
                  <h3 className="font-display text-charcoal text-lg uppercase tracking-wider mb-2">{item.title}</h3>
                  <p className="text-charcoal/50 text-sm leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* DOWNLOAD FORM */}
      <section id="download" className="py-16 md:py-24 bg-charcoal-deep">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-4xl mx-auto">
            {status === 'success' ? (
              <div className="text-center">
                <div className="w-10 h-10 flex items-center justify-center mx-auto mb-4">
                  <i className="ri-loader-4-line animate-spin text-orange text-2xl" />
                </div>
                <p className="text-white/50 text-sm">Redirecting you...</p>
              </div>
            ) : (
              <>
                <div className="text-center mb-12">
                  <p className="text-orange text-xs font-semibold uppercase tracking-[0.25em] mb-4">Get Instant Access</p>
                  <h2 className="font-display text-white text-3xl md:text-5xl uppercase tracking-wider mb-4">
                    Download Your Free Guide
                  </h2>
                  <p className="text-white/50 text-base md:text-lg max-w-xl mx-auto">
                    Join 1,200+ Evansville homeowners who've used this guide to budget smarter and avoid overpaying.
                  </p>
                </div>

                <div className="bg-white rounded-2xl p-6 md:p-10 max-w-2xl mx-auto">
                  {/* PDF header */}
                  <div className="flex items-center gap-4 mb-8 pb-6 border-b border-dashed border-charcoal/10">
                    <div className="w-16 h-20 flex-shrink-0 bg-orange/10 border border-orange/20 rounded flex flex-col items-center justify-center">
                      <i className="ri-file-pdf-2-line text-orange text-2xl" />
                      <span className="text-orange/60 text-xs font-bold mt-1">PDF</span>
                      <span className="text-orange/40 text-[10px]">18 pg</span>
                    </div>
                    <div>
                      <p className="text-charcoal font-semibold">2026 Roof Replacement Cost Guide</p>
                      <p className="text-charcoal/40 text-sm mt-1">For Evansville, Newburgh, Henderson KY & the Tri-State</p>
                      <div className="flex items-center gap-3 mt-2">
                        <span className="text-charcoal/30 text-xs"><i className="ri-eye-line mr-1" />1,247 downloads</span>
                        <span className="text-charcoal/30 text-xs"><i className="ri-star-fill mr-1 text-orange" />4.9 rating</span>
                      </div>
                    </div>
                  </div>

                  <form
                    ref={formRef}
                    data-readdy-form
                    onSubmit={handleSubmit}
                    className="space-y-4"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="ldg-name" className="block text-charcoal text-xs font-semibold uppercase tracking-wider mb-2">
                          Full Name *
                        </label>
                        <input
                          type="text"
                          id="ldg-name"
                          name="name"
                          required
                          placeholder="John Smith"
                          className="w-full bg-gray-100 rounded-xl px-5 py-3.5 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none border border-transparent focus:border-orange transition-colors"
                        />
                      </div>
                      <div>
                        <label htmlFor="ldg-email" className="block text-charcoal text-xs font-semibold uppercase tracking-wider mb-2">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          id="ldg-email"
                          name="email"
                          required
                          placeholder="your@email.com"
                          className="w-full bg-gray-100 rounded-xl px-5 py-3.5 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none border border-transparent focus:border-orange transition-colors"
                        />
                      </div>
                    </div>

                    <div>
                      <label htmlFor="ldg-phone" className="block text-charcoal text-xs font-semibold uppercase tracking-wider mb-2">
                        Phone <span className="text-gray-400 font-normal normal-case">(optional — we send a text when your guide is ready)</span>
                      </label>
                      <input
                        type="tel"
                        id="ldg-phone"
                        name="phone"
                        placeholder="812-000-0000"
                        className="w-full bg-gray-100 rounded-xl px-5 py-3.5 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none border border-transparent focus:border-orange transition-colors"
                      />
                    </div>

                    <div>
                      <label htmlFor="ldg-home-size" className="block text-charcoal text-xs font-semibold uppercase tracking-wider mb-2">
                        Approximate Home Size <span className="text-gray-400 font-normal normal-case">(optional)</span>
                      </label>
                      <select
                        id="ldg-home-size"
                        name="home_size"
                        className="w-full bg-gray-100 rounded-xl px-5 py-3.5 text-charcoal text-sm focus:outline-none border border-transparent focus:border-orange transition-colors appearance-none cursor-pointer"
                      >
                        <option value="">Not sure yet</option>
                        <option value="1200">Under 1,500 sq ft</option>
                        <option value="1800">1,500 – 2,500 sq ft</option>
                        <option value="3000">2,500 – 3,500 sq ft</option>
                        <option value="4000">Over 3,500 sq ft</option>
                      </select>
                    </div>

                    <button
                      type="submit"
                      disabled={status === 'submitting'}
                      className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-400 text-white font-bold text-sm uppercase tracking-widest py-4 rounded-xl transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                    >
                      {status === 'submitting' ? (
                        <>
                          <i className="ri-loader-4-line animate-spin" />
                          Sending Your Guide...
                        </>
                      ) : (
                        <>
                          <i className="ri-download-2-line" />
                          Get My Free Cost Guide Now
                        </>
                      )}
                    </button>

                    {status === 'error' && (
                      <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-2">
                        <i className="ri-alert-line text-red-500" />
                        <p className="text-red-600 text-sm">Something went wrong. Please try again or call 812-213-5997.</p>
                      </div>
                    )}

                    <p className="text-gray-400 text-xs text-center leading-relaxed">
                      <i className="ri-lock-line mr-1" />
                      Your information is private. We never spam, sell, or share your data. Unsubscribe anytime.
                    </p>
                  </form>
                </div>

                {/* Trust row */}
                <div className="flex flex-wrap items-center justify-center gap-6 md:gap-10 mt-10">
                  <div className="flex items-center gap-2">
                    <div className="flex">
                      {[1,2,3,4,5].map(i => <i key={i} className="ri-star-fill text-orange text-xs" />)}
                    </div>
                    <span className="text-white/40 text-xs">4.9 Google Rating</span>
                  </div>
                  <div className="w-px h-4 bg-white/10" />
                  <span className="text-white/40 text-xs">A+ BBB Accredited</span>
                  <div className="w-px h-4 bg-white/10" />
                  <span className="text-white/40 text-xs">Evansville Since 1995</span>
                  <div className="w-px h-4 bg-white/10 hidden md:block" />
                  <span className="text-white/40 text-xs hidden md:block">2,500+ Roofs Completed</span>
                </div>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <TestimonialsSection />

      {/* FAQ */}
      <FAQSection />

      {/* Final CTA */}
      <section className="py-16 md:py-20 bg-charcoal">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-display text-white text-3xl md:text-4xl uppercase tracking-wider mb-4">
              Still Have Questions?
            </h2>
            <p className="text-white/50 text-base md:text-lg leading-relaxed mb-8">
              A free roof inspection is the fastest way to know exactly what your roof needs — and what it will cost. No pressure, no obligation.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => navigate('/free-inspection')}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-calendar-check-line" />
                Book Free Inspection
              </button>
              <a
                href="tel:8122135997"
                className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-phone-line" />
                Call 812-213-5997
              </a>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}