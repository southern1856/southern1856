import { useState, useMemo } from 'react';

interface YearData {
  year: number;
  sidingCost: number;
  paintCost: number;
  sidingCumulative: number;
  paintCumulative: number;
  sidingValue: number;
  paintValue: number;
}

const SIDING_INSTALL_COST = 9500;
const PAINT_PER_JOB = 4200;
const PAINT_FREQUENCY = 6; // years
const HOME_VALUE_BASE = 250000;
const SIDING_VALUE_BOOST = 0.82; // 82% ROI per Remodeling Magazine
const PAINT_VALUE_BOOST = 0.55; // 55% ROI for exterior paint

function generateData(years: number): YearData[] {
  const data: YearData[] = [];
  let paintCumulative = 0;
  for (let y = 1; y <= years; y++) {
    const paintJobs = Math.floor((y - 1) / PAINT_FREQUENCY) + 1;
    paintCumulative = paintJobs * PAINT_PER_JOB;
    data.push({
      year: y,
      sidingCost: SIDING_INSTALL_COST,
      paintCost: y % PAINT_FREQUENCY === 1 || y === 1 ? PAINT_PER_JOB : 0,
      sidingCumulative: SIDING_INSTALL_COST,
      paintCumulative,
      sidingValue: HOME_VALUE_BASE + SIDING_INSTALL_COST * SIDING_VALUE_BOOST,
      paintValue: HOME_VALUE_BASE + paintCumulative * PAINT_VALUE_BOOST,
    });
  }
  return data;
}

function formatCurrency(n: number) {
  return `$${n.toLocaleString()}`;
}

export default function SidingVsPaintROI() {
  const [years, setYears] = useState(20);
  const data = useMemo(() => generateData(years), [years]);
  const last = data[data.length - 1];
  const paintTotalSpent = last.paintCumulative;
  const savings = paintTotalSpent - SIDING_INSTALL_COST;
  const breakEvenYear = data.find((d) => d.paintCumulative >= SIDING_INSTALL_COST)?.year ?? years;
  const maxPaintCost = Math.max(SIDING_INSTALL_COST, paintTotalSpent) * 1.1;

  return (
    <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm">
      {/* Header */}
      <div className="px-5 py-4 border-b border-gray-100 flex items-center gap-3">
        <div className="w-10 h-10 flex items-center justify-center bg-orange/10 rounded-xl">
          <i className="ri-scales-3-line text-orange text-lg" />
        </div>
        <div>
          <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">Siding vs. Paint — Total Cost of Ownership</h3>
          <p className="text-gray-400 text-[10px]">See why siding pays for itself over time</p>
        </div>
      </div>

      <div className="p-5 md:p-8">
        {/* Scenario selector */}
        <div className="flex items-center gap-3 mb-6">
          <span className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider">Time Horizon:</span>
          {[10, 15, 20, 25, 30].map((y) => (
            <button
              key={y}
              onClick={() => setYears(y)}
              className={`px-3 py-1.5 rounded-full text-[10px] font-semibold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                years === y ? 'bg-charcoal-deep text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
              }`}
            >
              {y} Years
            </button>
          ))}
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <div className="bg-gray-50 border border-gray-100 rounded-xl p-5">
            <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-1">New Siding (One-Time)</p>
            <p className="font-display text-charcoal-deep text-2xl uppercase tracking-wider">{formatCurrency(SIDING_INSTALL_COST)}</p>
            <p className="text-gray-400 text-xs mt-1">Done once. Zero maintenance for 20–40 years.</p>
            <div className="mt-3 flex items-center gap-2">
              <span className="px-2 py-0.5 bg-green-50 text-green-700 text-[10px] font-semibold rounded">{Math.round(SIDING_VALUE_BOOST * 100)}% Value Recouped</span>
            </div>
          </div>
          <div className="bg-red-50 border border-red-200 rounded-xl p-5">
            <p className="text-red-600 text-[10px] uppercase tracking-widest font-semibold mb-1">Repainting Every {PAINT_FREQUENCY} Years</p>
            <p className="font-display text-red-700 text-2xl uppercase tracking-wider">{formatCurrency(paintTotalSpent)}</p>
            <p className="text-red-400 text-xs mt-1">
              {Math.ceil(years / PAINT_FREQUENCY)} paint jobs over {years} years at {formatCurrency(PAINT_PER_JOB)} each
            </p>
            <div className="mt-3 flex items-center gap-2">
              <span className="px-2 py-0.5 bg-red-100 text-red-700 text-[10px] font-semibold rounded">{Math.round((1 - PAINT_VALUE_BOOST) * 100)}% Lost to Depreciation</span>
            </div>
          </div>
          <div className="bg-orange/5 border border-orange/30 rounded-xl p-5">
            <p className="text-orange text-[10px] uppercase tracking-widest font-semibold mb-1">Net Savings with Siding</p>
            <p className="font-display text-orange text-2xl uppercase tracking-wider">
              {savings > 0 ? formatCurrency(savings) : `-${formatCurrency(Math.abs(savings))}`}
            </p>
            <p className="text-orange/70 text-xs mt-1">
              {savings > 0
                ? `Siding saves you ${formatCurrency(savings)} vs. painting over ${years} years`
                : `Break-even at ${breakEvenYear} years — then siding wins forever`}
            </p>
            <div className="mt-3 flex items-center gap-2">
              <span className="px-2 py-0.5 bg-orange/10 text-orange text-[10px] font-semibold rounded">
                Break-even: Year {breakEvenYear}
              </span>
            </div>
          </div>
        </div>

        {/* Bar chart */}
        <div className="mb-8">
          <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-4 flex items-center gap-2">
            <i className="ri-bar-chart-grouped-line text-orange" />
            Cumulative Cost Over Time
          </p>
          <div className="space-y-3">
            {data.filter((_, i) => i % 2 === 0 || i === data.length - 1).map((d) => {
              const sidingPct = (SIDING_INSTALL_COST / maxPaintCost) * 100;
              const paintPct = (d.paintCumulative / maxPaintCost) * 100;
              return (
                <div key={d.year} className="flex items-center gap-3">
                  <span className="text-gray-400 text-[10px] w-8 text-right flex-shrink-0">Yr {d.year}</span>
                  <div className="flex-1 relative h-6 bg-gray-100 rounded-md overflow-hidden">
                    {/* Siding bar (static) */}
                    <div
                      className="absolute top-0 left-0 h-full bg-charcoal-deep rounded-l-md transition-all"
                      style={{ width: `${sidingPct}%` }}
                    />
                    {/* Paint bar (growing) */}
                    <div
                      className="absolute top-0 left-0 h-full bg-red-400/60 rounded-r-md transition-all"
                      style={{ width: `${paintPct}%` }}
                    />
                  </div>
                  <span className="text-gray-500 text-[10px] w-16 flex-shrink-0 text-right">
                    {formatCurrency(d.paintCumulative)}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="flex items-center gap-4 mt-3 ml-11">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm bg-charcoal-deep" />
              <span className="text-gray-500 text-[10px]">Siding (one-time)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm bg-red-400/60" />
              <span className="text-gray-500 text-[10px]">Cumulative paint cost</span>
            </div>
          </div>
        </div>

        {/* Hidden costs comparison */}
        <div className="bg-gray-50 border border-gray-100 rounded-xl p-5 mb-6">
          <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-4 flex items-center gap-2">
            <i className="ri-alert-line text-orange" />
            The Hidden Costs of Repainting
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              { label: 'Prep & Power Wash', paint: '$400–$600 per cycle', siding: '$0 — ever' },
              { label: 'Scraping & Caulking', paint: '$300–$500 per cycle', siding: '$0 — ever' },
              { label: 'Wood Rot Repair', paint: '$200–$1,200 per cycle', siding: 'Replaced during install' },
              { label: 'Your Time & Hassle', paint: '3–5 days disruption per cycle', siding: 'One project, done forever' },
              { label: 'Weather Delay Risk', paint: 'Rain pushes schedule 2–4 weeks', siding: 'Protected under tarps' },
              { label: 'Paint Quality Risk', paint: 'Cheaper paint fades in 3–4 yrs', siding: 'Fade-resistant for 20+ yrs' },
            ].map((item) => (
              <div key={item.label} className="flex items-start gap-3 bg-white border border-gray-100 rounded-lg px-4 py-3">
                <div className="flex-1 min-w-0">
                  <p className="text-charcoal-deep text-xs font-semibold">{item.label}</p>
                  <p className="text-red-400 text-[10px] mt-0.5"><i className="ri-close-circle-line mr-1" />Paint: {item.paint}</p>
                  <p className="text-green-600 text-[10px] mt-0.5"><i className="ri-check-line mr-1" />Siding: {item.siding}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ROI at resale */}
        <div className="bg-green-50 border border-green-200 rounded-xl p-5 mb-6">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 flex items-center justify-center bg-green-100 rounded-lg flex-shrink-0">
              <i className="ri-money-dollar-circle-line text-green-600 text-sm" />
            </div>
            <div>
              <p className="text-green-800 text-xs font-semibold uppercase tracking-wider mb-1">Resale Value Impact</p>
              <p className="text-green-700 text-sm leading-relaxed">
                According to Remodeling Magazine&apos;s Cost vs. Value report, new siding recoups <strong>{Math.round(SIDING_VALUE_BOOST * 100)}%</strong> of its cost at resale. Exterior painting recoups only <strong>{Math.round(PAINT_VALUE_BOOST * 100)}%</strong>. On a {formatCurrency(SIDING_INSTALL_COST)} siding job, that&apos;s <strong>{formatCurrency(Math.round(SIDING_INSTALL_COST * SIDING_VALUE_BOOST))}</strong> added to your home&apos;s value — compared to just <strong>{formatCurrency(Math.round(PAINT_PER_JOB * PAINT_VALUE_BOOST))}</strong> for a single paint job.
              </p>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="flex flex-col sm:flex-row gap-3">
          <a
            href="#siding-form"
            className="flex-1 inline-flex items-center justify-center gap-2 bg-orange hover:bg-orange-dark text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-calendar-check-line" />
            Get a Siding Quote
          </a>
          <a
            href="tel:8122135997"
            className="flex-1 inline-flex items-center justify-center gap-2 border border-gray-300 hover:border-gray-400 text-charcoal-deep font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors whitespace-nowrap"
          >
            <i className="ri-phone-line" />
            Call 812-213-5997
          </a>
        </div>
      </div>
    </div>
  );
}