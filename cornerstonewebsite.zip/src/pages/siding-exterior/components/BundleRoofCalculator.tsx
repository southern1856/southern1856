import { useState } from 'react';

interface SavingsRow {
  label: string;
  separate: number;
  bundled: number;
  note: string;
}

const SAVINGS_DATA: SavingsRow[] = [
  { label: 'Roof Replacement (Architectural)', separate: 14500, bundled: 13500, note: 'Volume discount on materials' },
  { label: 'Siding Replacement (Vinyl)', separate: 9800, bundled: 8800, note: 'Coordinated scheduling' },
  { label: 'Gutters & Downspouts', separate: 3200, bundled: 2600, note: 'Single scaffolding setup' },
  { label: 'Permits & Inspections', separate: 850, bundled: 600, note: 'Combined permit filing' },
  { label: 'Dumpster / Disposal', separate: 1200, bundled: 700, note: 'One dumpster, one haul' },
  { label: 'Crew Mobilization', separate: 1800, bundled: 900, note: 'One crew arrival, one teardown' },
  { label: 'Project Management', separate: 1200, bundled: 600, note: 'One PM, one timeline' },
  { label: 'Cleanup & Detailing', separate: 800, bundled: 400, note: 'Single cleanup pass' },
];

const ROOF_ONLY = { label: 'Roof Only', cost: 14500 };
const SIDING_ONLY = { label: 'Siding Only', cost: 9800 };
const GUTTERS_ONLY = { label: 'Gutters Only', cost: 3200 };
const EXTERIOR_BUNDLE = { label: 'Complete Exterior Bundle', cost: 26700 };

function formatCurrency(n: number) {
  return `$${n.toLocaleString()}`;
}

export default function BundleRoofCalculator() {
  const [showBreakdown, setShowBreakdown] = useState(false);

  const separateTotal = SAVINGS_DATA.reduce((s, r) => s + r.separate, 0);
  const bundledTotal = SAVINGS_DATA.reduce((s, r) => s + r.bundled, 0);
  const totalSavings = separateTotal - bundledTotal;
  const savingsPct = Math.round((totalSavings / separateTotal) * 100);

  const roofSidingOnlySeparate = ROOF_ONLY.cost + SIDING_ONLY.cost;
  const roofSidingOnlyBundled = SAVINGS_DATA.slice(0, 2).reduce((s, r) => s + r.bundled, 0);
  const roofSidingSavings = roofSidingOnlySeparate - roofSidingOnlyBundled;

  return (
    <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm">
      {/* Header */}
      <div className="px-5 py-4 border-b border-gray-100 flex items-center gap-3">
        <div className="w-10 h-10 flex items-center justify-center bg-orange/10 rounded-xl">
          <i className="ri-price-tag-3-line text-orange text-lg" />
        </div>
        <div>
          <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">Bundle with Roof — Real Dollar Savings</h3>
          <p className="text-gray-400 text-[10px]">Typical Evansville 1,500 sq ft home with architectural roof + vinyl siding</p>
        </div>
      </div>

      <div className="p-5 md:p-8">
        {/* Big number hero */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <div className="bg-red-50 border border-red-200 rounded-xl p-5 text-center">
            <p className="text-red-600 text-[10px] uppercase tracking-widest font-semibold mb-1">Separate Contractors</p>
            <p className="font-display text-red-700 text-2xl uppercase tracking-wider">{formatCurrency(separateTotal)}</p>
            <p className="text-red-400 text-xs mt-1">Roof + siding + gutters</p>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-xl p-5 text-center">
            <p className="text-green-700 text-[10px] uppercase tracking-widest font-semibold mb-1">Complete Exterior Bundle</p>
            <p className="font-display text-green-800 text-2xl uppercase tracking-wider">{formatCurrency(bundledTotal)}</p>
            <p className="text-green-600 text-xs mt-1">One crew, one visit</p>
          </div>
          <div className="bg-orange/5 border border-orange/30 rounded-xl p-5 text-center">
            <p className="text-orange text-[10px] uppercase tracking-widest font-semibold mb-1">Your Total Savings</p>
            <p className="font-display text-orange text-2xl uppercase tracking-wider">{formatCurrency(totalSavings)}</p>
            <p className="text-orange/70 text-xs mt-1">{savingsPct}% off separate pricing</p>
          </div>
        </div>

        {/* Roof + Siding only quick view */}
        <div className="bg-gray-50 border border-gray-100 rounded-xl p-5 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <i className="ri-home-smile-line text-orange text-sm" />
            <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider">Just Roof + Siding? You Still Save Big</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="flex items-center justify-between bg-white border border-gray-100 rounded-lg px-4 py-3">
              <span className="text-gray-500 text-xs">{ROOF_ONLY.label}</span>
              <span className="text-charcoal-deep text-sm font-semibold">{formatCurrency(ROOF_ONLY.cost)}</span>
            </div>
            <div className="flex items-center justify-between bg-white border border-gray-100 rounded-lg px-4 py-3">
              <span className="text-gray-500 text-xs">{SIDING_ONLY.label}</span>
              <span className="text-charcoal-deep text-sm font-semibold">{formatCurrency(SIDING_ONLY.cost)}</span>
            </div>
            <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-lg px-4 py-3">
              <span className="text-green-700 text-xs font-semibold">Bundled together</span>
              <span className="text-green-800 text-sm font-semibold">{formatCurrency(roofSidingOnlyBundled)}</span>
            </div>
          </div>
          <p className="text-green-600 text-xs mt-3 text-center">
            <i className="ri-check-line mr-1" />
            Even just bundling roof + siding saves you <strong>{formatCurrency(roofSidingSavings)}</strong> compared to hiring separately
          </p>
        </div>

        {/* Line-item breakdown toggle */}
        <button
          onClick={() => setShowBreakdown(!showBreakdown)}
          className="w-full flex items-center justify-between bg-charcoal-deep rounded-xl px-5 py-3 text-white hover:bg-charcoal transition-colors cursor-pointer"
        >
          <span className="text-xs font-semibold uppercase tracking-wider flex items-center gap-2">
            <i className="ri-file-list-3-line" />
            See Where Every Dollar Is Saved
          </span>
          <i className={`ri-arrow-down-s-line text-lg transition-transform ${showBreakdown ? 'rotate-180' : ''}`} />
        </button>

        {showBreakdown && (
          <div className="mt-4 space-y-2">
            {SAVINGS_DATA.map((row) => {
              const saved = row.separate - row.bundled;
              return (
                <div key={row.label} className="grid grid-cols-12 gap-2 items-center bg-gray-50 border border-gray-100 rounded-lg px-4 py-3">
                  <div className="col-span-4 sm:col-span-3">
                    <p className="text-charcoal-deep text-xs font-semibold">{row.label}</p>
                  </div>
                  <div className="col-span-3 sm:col-span-2 text-right">
                    <p className="text-gray-400 text-xs line-through">{formatCurrency(row.separate)}</p>
                  </div>
                  <div className="col-span-2 sm:col-span-2 text-right">
                    <p className="text-charcoal-deep text-xs font-semibold">{formatCurrency(row.bundled)}</p>
                  </div>
                  <div className="col-span-3 sm:col-span-2 text-right">
                    <span className="inline-flex items-center gap-1 text-green-600 text-[10px] font-bold bg-green-50 px-2 py-0.5 rounded">
                      <i className="ri-arrow-down-line" />
                      {formatCurrency(saved)}
                    </span>
                  </div>
                  <div className="hidden sm:block col-span-3">
                    <p className="text-gray-400 text-[10px]">{row.note}</p>
                  </div>
                </div>
              );
            })}
            {/* Totals */}
            <div className="grid grid-cols-12 gap-2 items-center bg-orange/5 border border-orange/20 rounded-lg px-4 py-4 mt-2">
              <div className="col-span-4 sm:col-span-3">
                <p className="font-display text-charcoal-deep text-sm uppercase tracking-wider font-semibold">Total Project</p>
              </div>
              <div className="col-span-3 sm:col-span-2 text-right">
                <p className="text-gray-400 text-sm line-through">{formatCurrency(separateTotal)}</p>
              </div>
              <div className="col-span-2 sm:col-span-2 text-right">
                <p className="font-display text-charcoal-deep text-sm uppercase tracking-wider font-semibold">{formatCurrency(bundledTotal)}</p>
              </div>
              <div className="col-span-3 sm:col-span-2 text-right">
                <span className="inline-flex items-center gap-1 text-orange text-sm font-bold bg-orange/10 px-2 py-1 rounded">
                  <i className="ri-arrow-down-line" />
                  {formatCurrency(totalSavings)} saved
                </span>
              </div>
              <div className="hidden sm:block col-span-3">
                <p className="text-orange text-[10px] font-semibold">{savingsPct}% total savings</p>
              </div>
            </div>
          </div>
        )}

        {/* Financing context */}
        <div className="mt-6 bg-green-50 border border-green-200 rounded-xl p-5">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 flex items-center justify-center bg-green-100 rounded-lg flex-shrink-0">
              <i className="ri-bank-card-line text-green-600 text-sm" />
            </div>
            <div>
              <p className="text-green-800 text-xs font-semibold uppercase tracking-wider mb-1">Financing Makes It Even Easier</p>
              <p className="text-green-700 text-sm leading-relaxed">
                With our $0-down financing, the Complete Exterior Bundle breaks down to as low as <strong>{formatCurrency(Math.round(bundledTotal / 60))}/mo</strong> over 60 months — less than many homeowners spend on streaming services and gym memberships combined. And unlike those subscriptions, this adds real value to your home.
              </p>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="mt-6 flex flex-col sm:flex-row gap-3">
          <a
            href="#siding-form"
            className="flex-1 inline-flex items-center justify-center gap-2 bg-orange hover:bg-orange-dark text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-calendar-check-line" />
            Get a Bundle Quote
          </a>
          <a
            href="/exterior-package"
            className="flex-1 inline-flex items-center justify-center gap-2 border border-gray-300 hover:border-gray-400 text-charcoal-deep font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors whitespace-nowrap"
          >
            <i className="ri-home-gear-line" />
            See Complete Package
          </a>
        </div>
      </div>
    </div>
  );
}