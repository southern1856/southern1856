import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import SidingCostEstimator from '@/components/feature/SidingCostEstimator';
import PageSEO from '@/components/feature/PageSEO';
import BundleSaveBadge from '@/components/feature/BundleSaveBadge';
import RelatedServicesStrip from '@/components/feature/RelatedServicesStrip';
import ServiceProcessStrip from '@/components/feature/ServiceProcessStrip';
import CompetitorComparisonTool from '@/components/feature/CompetitorComparisonTool';
import PriceMatchBanner from '@/components/feature/PriceMatchBanner';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import SidingColorVisualizer from './components/SidingColorVisualizer';
import BundleRoofCalculator from './components/BundleRoofCalculator';
import SidingVsPaintROI from './components/SidingVsPaintROI';
import { OFFERS } from '@/mocks/promotions';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const sidingSchema = {
  '@context': 'https://schema.org',
  '@type': 'Service',
  name: 'Siding Replacement & Installation Evansville Indiana',
  provider: {
    '@type': 'RoofingContractor',
    name: 'Corner Stone Construction & Roofing',
    telephone: '+1-812-213-5997',
    address: {
      '@type': 'PostalAddress',
      streetAddress: '5800 Kansas Rd',
      addressLocality: 'Evansville',
      addressRegion: 'IN',
      postalCode: '47725',
    },
  },
  areaServed: ['Evansville IN', 'Henderson KY', 'Newburgh IN', 'Owensboro KY', 'Tri-State Area'],
  description: 'Professional siding installation and replacement in Evansville Indiana and Henderson KY. Vinyl siding, fiber cement, James Hardie, wood siding, and exterior trim. Protect and beautify your home. Free estimates — call 812-213-5997.',
  hasOfferCatalog: {
    '@type': 'OfferCatalog',
    name: 'Siding Services',
    itemListElement: [
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Vinyl Siding Installation' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'James Hardie Fiber Cement Siding' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Wood Siding Replacement' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Exterior Trim & Fascia' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Siding Repair' } },
    ],
  },
};

const SIDING_TYPES = [
  {
    id: 'vinyl',
    name: 'Vinyl Siding',
    badge: 'Most Popular',
    badgeColor: 'bg-orange text-white',
    lifespan: '20–40 Years',
    bestFor: 'Most Homes — Best Value',
    desc: 'The #1 choice for Evansville homeowners. Modern vinyl siding is nothing like the cheap stuff from the 90s — today\'s premium vinyl is thick, insulated, and virtually maintenance-free. It won\'t rot, warp, or need painting, and it comes in hundreds of colors and profiles.',
    features: ['Zero Maintenance Required', 'Won\'t Rot, Warp, or Fade', '200+ Color & Profile Options', 'Insulated Options Available', 'Impact & Wind Resistant', 'Lifetime Transferable Warranty'],
    image: '/placeholders/800x500.svg',
  },
  {
    id: 'fiber-cement',
    name: 'James Hardie',
    badge: 'Premium Choice',
    badgeColor: 'bg-white/10 text-white',
    lifespan: '30–50 Years',
    bestFor: 'Upscale Homes, High-Wind Areas',
    desc: 'James Hardie fiber cement siding is the gold standard for premium exterior cladding. It looks exactly like real wood but is completely impervious to moisture, insects, and fire. HardiePlank and HardieShingle profiles give your home a high-end look that holds its value for decades.',
    features: ['Looks Like Real Wood', 'Fire & Impact Resistant', 'Moisture & Pest Proof', 'ColorPlus Technology Finish', '30-Year Warranty', 'Increases Home Value'],
    image: '/placeholders/800x500.svg',
  },
  {
    id: 'wood',
    name: 'Wood Siding',
    badge: 'Classic Look',
    badgeColor: 'bg-white/10 text-white',
    lifespan: '20–40 Years',
    bestFor: 'Historic Homes, Custom Builds',
    desc: 'Nothing matches the warmth and character of real wood siding. Cedar and redwood siding offer natural beauty, excellent insulation, and a timeless look that synthetic materials can\'t replicate. Ideal for historic homes, custom builds, and homeowners who want an authentic aesthetic.',
    features: ['Natural Beauty & Warmth', 'Excellent Insulation Value', 'Paintable & Stainable', 'Eco-Friendly Material', 'Unique Character & Grain', 'Repairable & Refinishable'],
    image: '/placeholders/800x500.svg',
  },
  {
    id: 'repair',
    name: 'Siding Repair',
    badge: 'Storm Damage',
    badgeColor: 'bg-white/10 text-white',
    lifespan: 'Extends Existing Life',
    bestFor: 'Storm Damage, Isolated Damage',
    desc: 'Not every siding job requires a full replacement. If you have storm damage, impact holes, rotted sections, or isolated warping, targeted siding repair can restore your home\'s appearance and protection at a fraction of the cost. We match existing profiles and colors precisely.',
    features: ['Exact Profile & Color Matching', 'Storm Damage Specialists', 'Insurance Claim Assistance', 'Rot Repair & Replacement', 'Caulking & Sealing', 'Faster Than Full Replacement'],
    image: '/placeholders/800x500.svg',
  },
];

const DAMAGE_SIGNS = [
  { icon: 'ri-water-flash-line', title: 'Moisture & Mold Inside Walls', desc: 'Failing siding lets water infiltrate your wall cavity, causing mold, rot, and structural damage that\'s expensive to remediate.' },
  { icon: 'ri-temp-hot-line', title: 'Skyrocketing Energy Bills', desc: 'Old or damaged siding with no insulation backing is a major source of heat loss in winter and heat gain in summer.' },
  { icon: 'ri-bug-line', title: 'Pest Entry Points', desc: 'Gaps, cracks, and rotted siding sections are open invitations for carpenter ants, termites, and rodents to enter your walls.' },
  { icon: 'ri-home-line', title: 'Curb Appeal & Resale Value', desc: 'Faded, cracked, or outdated siding is the first thing buyers notice. New siding delivers some of the highest ROI of any home improvement.' },
  { icon: 'ri-windy-line', title: 'Storm & Wind Damage', desc: 'Indiana\'s severe storms regularly crack, dent, and blow off siding panels. Damaged siding exposes your home to water intrusion immediately.' },
  { icon: 'ri-paint-brush-line', title: 'Constant Repainting', desc: 'If you\'re repainting your siding every 5–7 years, you\'re spending more than a full vinyl replacement would cost over the same period.' },
];

const ADVANTAGES = [
  {
    icon: 'ri-home-gear-line',
    title: 'Bundle with Roofing & Gutters',
    desc: 'Getting a new roof? Add siding and gutters in one visit. One crew, one cleanup, and significant savings on mobilization costs.',
  },
  {
    icon: 'ri-shield-check-line',
    title: 'James Hardie Preferred Contractor',
    desc: 'We\'re a certified James Hardie installer — meaning you get the full manufacturer warranty and access to exclusive ColorPlus finishes.',
  },
  {
    icon: 'ri-file-shield-2-line',
    title: 'Insurance Claim Experts',
    desc: 'Storm damage to your siding? We work directly with your insurance adjuster and handle the entire claims process for you.',
  },
  {
    icon: 'ri-palette-line',
    title: 'Hundreds of Colors & Profiles',
    desc: 'From traditional lap siding to board-and-batten, shakes, and panels — we carry every profile and color to match your vision.',
  },
  {
    icon: 'ri-map-pin-line',
    title: 'Local Tri-State Experts',
    desc: 'We know Indiana and Kentucky weather — hail, ice storms, high winds. We spec siding for local conditions, not just aesthetics.',
  },
  {
    icon: 'ri-award-line',
    title: 'Lifetime Workmanship Warranty',
    desc: 'Every siding installation comes with our lifetime workmanship warranty. If it fails due to our work, we fix it — period.',
  },
];



const FAQS = [
  {
    q: 'How much does siding replacement cost in Evansville Indiana?',
    a: 'Vinyl siding replacement in Evansville typically runs $5–$10 per square foot installed, depending on the profile, thickness, and home complexity. A typical 1,500 sq ft home with 1,200 sq ft of siding runs $6,000–$12,000. James Hardie fiber cement runs $10–$18 per square foot. We provide free on-site quotes with no obligation.',
  },
  {
    q: 'What is the best siding for Indiana weather?',
    a: 'For most Evansville and Henderson KY homes, we recommend premium insulated vinyl siding or James Hardie fiber cement. Both handle Indiana\'s freeze-thaw cycles, hail, and high winds extremely well. Insulated vinyl adds R-value that helps with energy bills. James Hardie is the best choice for homes in high-wind corridors or areas with frequent hail.',
  },
  {
    q: 'Does new siding help with energy bills?',
    a: 'Significantly, yes. Insulated vinyl siding adds R-2.5 to R-6 of continuous insulation to your wall assembly — something standard siding doesn\'t provide. Homeowners in Evansville typically see 10–20% reductions in heating and cooling costs after installing insulated siding. The energy savings often offset a significant portion of the installation cost over time.',
  },
  {
    q: 'Will my insurance cover siding replacement?',
    a: 'If your siding was damaged by a covered peril — hail, wind, falling trees — your homeowner\'s insurance should cover replacement. Indiana and Kentucky see significant hail and wind events every year. We inspect your siding for storm damage, document everything, and work directly with your adjuster. Many homeowners get full siding replacements for just their deductible.',
  },
  {
    q: 'How long does siding installation take?',
    a: 'Most residential siding jobs take 2–5 days depending on home size, profile complexity, and whether substrate repairs are needed. We work efficiently and clean up completely each day. You\'ll have a fully protected home every night — we never leave your house exposed overnight.',
  },
  {
    q: 'Should I replace siding and roof at the same time?',
    a: 'If both are near end of life, absolutely — and it saves money. Bundling siding with a roof replacement means one crew, one mobilization, and coordinated scheduling. We can often save you $500–$1,500 by doing both together. We\'ll give you an honest assessment of whether your siding needs replacement now or can wait.',
  },
  {
    q: 'What is James Hardie siding and why is it better?',
    a: 'James Hardie is a fiber cement composite — a blend of cement, sand, and cellulose fibers. It\'s dimensionally stable (won\'t expand/contract like vinyl in extreme temps), fire resistant, impact resistant, and completely impervious to moisture and insects. It looks exactly like real wood but lasts 30–50 years with minimal maintenance. It\'s the premium choice for homeowners who want the best.',
  },
];

const COLORS = [
  { name: 'Arctic White', hex: '#F8F8F8', border: true },
  { name: 'Linen', hex: '#EDE8DC' },
  { name: 'Sandstone', hex: '#C8B89A' },
  { name: 'Autumn Red', hex: '#8B3A2A' },
  { name: 'Sage Green', hex: '#7A8C6E' },
  { name: 'Slate Gray', hex: '#6B7280' },
  { name: 'Charcoal', hex: '#3D3D3D' },
  { name: 'Midnight', hex: '#1E2330' },
];

const nearestExpiry = OFFERS
  .filter((o) => o.expires)
  .map((o) => o.expires!)
  .sort()[0] || '2026-12-31';

export default function SidingExteriorPage() {
  const navigate = useNavigate();
  const [activeType, setActiveType] = useState(SIDING_TYPES[0]);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [selectedColor, setSelectedColor] = useState('Arctic White');
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [charCount, setCharCount] = useState(0);
  const [showStickyBundleCTA, setShowStickyBundleCTA] = useState(false);
  const bundleSectionRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLFormElement>(null);

  const hero = useScrollAnimation();
  const types = useScrollAnimation({ threshold: 0.05 });
  const damage = useScrollAnimation({ threshold: 0.1 });
  const compareAnim = useScrollAnimation({ threshold: 0.1 });
  const advantages = useScrollAnimation({ threshold: 0.1 });
  const faqAnim = useScrollAnimation({ threshold: 0.1 });
  const formAnim = useScrollAnimation({ threshold: 0.1 });

  /* Show sticky CTA after scrolling past the bundle calculator */
  useEffect(() => {
    const section = bundleSectionRef.current;
    if (!section) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        setShowStickyBundleCTA(!entry.isIntersecting && entry.boundingClientRect.top < 0);
      },
      { threshold: 0, rootMargin: '0px 0px -100% 0px' }
    );

    observer.observe(section);
    return () => observer.disconnect();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;
    const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
    const notes = formData.get('notes') as string;
    if (notes && notes.length > 500) return;
    setFormStatus('submitting');
    try {
      const res = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      if (res.ok) { setFormStatus('success'); formRef.current.reset(); setCharCount(0); }
      else setFormStatus('error');
    } catch { setFormStatus('error'); }
  };

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Siding Replacement Evansville Indiana | James Hardie & Vinyl Siding | Corner Stone"
        description="Professional siding installation and replacement in Evansville IN and Henderson KY. Vinyl siding, James Hardie fiber cement, wood siding, and exterior trim. Storm damage specialists. Free estimates — call 812-213-5997."
        keywords="siding replacement Evansville Indiana, vinyl siding Evansville, James Hardie siding Evansville, fiber cement siding Henderson KY, siding installation Tri-State, exterior siding contractor Indiana, siding repair Evansville"
        canonical="/siding-exterior"
        schema={sidingSchema}
      />
      {/* ── Hero ── */}
      <section className="relative min-h-screen flex flex-col overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1400x900.svg"
            alt="Siding replacement and installation Evansville Indiana"
            className="w-full h-full object-cover object-top opacity-35"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/60 via-charcoal-deep/40 to-charcoal-deep" />
          <div className="absolute inset-0 opacity-[0.025]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '80px 80px' }} />
        </div>

        <div
          ref={hero.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 flex-1 flex flex-col justify-center px-6 md:px-10 lg:px-16 pt-32 md:pt-36 pb-16 anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-wrap items-center gap-3 mb-8">
            <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange" />
              James Hardie Preferred Contractor
            </div>
            <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange" />
              200+ Colors & Profiles
            </div>
            <div className="flex items-center gap-2 border border-orange/40 bg-orange/10 backdrop-blur-sm px-4 py-2 text-orange text-xs uppercase tracking-widest">
              <i className="ri-shield-check-line text-sm" />
              Lifetime Workmanship Warranty
            </div>
          </div>

          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 9vw, 10rem)' }}>
            Siding &amp;<br />Exterior<br /><span className="text-orange">Done Right.</span>
          </h1>

          <div className="mb-8">
            <CountdownTimer expiresAt={nearestExpiry} variant="banner" />
            <div className="mt-3">
              <SocialProofPulse />
            </div>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-end gap-8 lg:gap-16">
            <p className="text-white/50 text-base md:text-lg max-w-xl leading-relaxed">
              Evansville and Henderson KY's trusted siding contractor. Vinyl, James Hardie fiber cement, wood siding, and complete exterior trim — transforming homes and protecting them from Indiana's toughest weather.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 flex-shrink-0">
              <button
                onClick={() => document.getElementById('siding-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <i className="ri-file-list-3-line" />
                Get Free Siding Quote
              </button>
              <a
                href="tel:8122135997"
                className="border border-white/30 hover:border-orange text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-phone-line text-orange" />
                812-213-5997
              </a>
            </div>
          </div>
        </div>

        {/* Bottom stats */}
        <div className="relative z-10 border-t border-white/10 grid grid-cols-2 md:grid-cols-4">
          {[
            { val: '1,500+', label: 'Homes Re-Sided' },
            { val: '2–5 Days', label: 'Typical Install' },
            { val: '200+', label: 'Colors & Profiles' },
            { val: 'Lifetime', label: 'Workmanship Warranty' },
          ].map((s, i) => (
            <div key={s.label} className={`px-6 md:px-10 py-6 md:py-8 ${i < 3 ? 'border-r border-white/10' : ''}`}>
              <p className="font-display text-white text-3xl md:text-4xl tracking-wider">{s.val}</p>
              <p className="text-white/40 text-xs uppercase tracking-widest mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      <TalkToAIExpert />

      {/* ── Why Siding Matters ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Don't Ignore Failing Siding</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              Old Siding Costs<br />More Than You Think
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-6">
              Siding is your home's first line of defense against moisture, pests, and energy loss. When it fails, the damage doesn't stop at the surface — it works its way into your wall cavity, insulation, and framing. Siding replacement in Evansville is one of the highest-ROI home improvements you can make.
            </p>
            <div className="bg-orange/10 border border-orange/30 p-5 mb-8">
              <div className="flex items-start gap-3">
                <i className="ri-alert-line text-orange text-xl mt-0.5" />
                <div>
                  <p className="text-white font-semibold text-sm mb-1">Indiana Hail & Wind Season</p>
                  <p className="text-white/50 text-sm leading-relaxed">
                    The Evansville area averages 50+ severe weather events per year. Hail and high winds are the #1 cause of siding damage — and most homeowners don't realize their siding is compromised until water damage appears inside.
                  </p>
                </div>
              </div>
            </div>
            <button
              onClick={() => document.getElementById('siding-form')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap"
            >
              Schedule Free Inspection
              <i className="ri-arrow-right-line" />
            </button>
          </div>

          <div
            ref={damage.ref as React.RefObject<HTMLDivElement>}
            className="grid grid-cols-1 sm:grid-cols-2 gap-4"
          >
            {DAMAGE_SIGNS.map((sign, i) => (
              <div
                key={sign.title}
                className={`border border-white/10 bg-charcoal-mid p-5 hover:border-orange/30 transition-all duration-300 group anim-fade-up ${damage.isVisible ? 'is-visible' : ''}`}
                style={{ transitionDelay: `${i * 70}ms` }}
              >
                <div className="w-10 h-10 flex items-center justify-center bg-orange/15 group-hover:bg-orange/25 transition-colors mb-3">
                  <i className={`${sign.icon} text-orange text-lg`} />
                </div>
                <h3 className="text-white font-semibold text-sm mb-1.5">{sign.title}</h3>
                <p className="text-white/40 text-xs leading-relaxed">{sign.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Siding Types Selector ── */}
      <section id="siding-types" className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14 md:mb-18">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Siding Systems</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
            The Right Siding<br />For Your Home
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            From budget-friendly vinyl to premium James Hardie fiber cement, we install every siding system and help you choose the best fit for your home, budget, and style.
          </p>
        </div>

        <div
          ref={types.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 lg:grid-cols-5 gap-6"
        >
          {/* Type selector */}
          <div className="lg:col-span-2 flex flex-col gap-3">
            {SIDING_TYPES.map((type, i) => (
              <button
                key={type.id}
                onClick={() => setActiveType(type)}
                className={`text-left border p-5 transition-all duration-300 cursor-pointer group anim-fade-up ${types.isVisible ? 'is-visible' : ''} ${activeType.id === type.id ? 'border-orange bg-orange/10' : 'border-white/10 bg-charcoal-mid hover:border-white/30'}`}
                style={{ transitionDelay: `${i * 80}ms` }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-xs font-bold px-2 py-0.5 uppercase tracking-wider ${type.badgeColor}`}>{type.badge}</span>
                  <span className="text-white/30 text-xs">{type.lifespan}</span>
                </div>
                <h3 className={`font-display text-xl uppercase tracking-wider transition-colors ${activeType.id === type.id ? 'text-orange' : 'text-white group-hover:text-orange'}`}>
                  {type.name}
                </h3>
                <p className="text-white/40 text-xs mt-2">
                  <i className="ri-home-line mr-1 text-orange" />
                  {type.bestFor}
                </p>
              </button>
            ))}
          </div>

          {/* Type detail */}
          <div className="lg:col-span-3 flex flex-col gap-4">
            <div className="relative w-full overflow-hidden" style={{ height: '300px' }}>
              <img
                key={activeType.id}
                src={activeType.image}
                alt={activeType.name}
                className="w-full h-full object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-deep/80 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="flex items-center gap-3">
                  <span className={`text-xs font-bold px-3 py-1 uppercase tracking-wider ${activeType.badgeColor}`}>{activeType.badge}</span>
                  <span className="text-white/50 text-xs">{activeType.lifespan} lifespan</span>
                </div>
                <h3 className="font-display text-white text-3xl uppercase tracking-wider mt-2">{activeType.name}</h3>
              </div>
            </div>

            <div className="border border-white/10 bg-charcoal-mid p-6 md:p-8 flex-1">
              <p className="text-white/60 text-sm leading-relaxed mb-6">{activeType.desc}</p>
              <div className="grid grid-cols-2 gap-2 mb-6">
                {activeType.features.map((f) => (
                  <div key={f} className="flex items-center gap-2 text-white/50 text-xs">
                    <i className="ri-check-line text-orange text-sm" />
                    {f}
                  </div>
                ))}
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => document.getElementById('siding-form')?.scrollIntoView({ behavior: 'smooth' })}
                  className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-6 py-3 uppercase tracking-wide transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                >
                  Get {activeType.name} Quote
                  <i className="ri-arrow-right-line" />
                </button>
                <a
                  href="tel:8122135997"
                  className="border border-white/20 hover:border-orange text-white/70 hover:text-white text-sm font-semibold px-6 py-3 uppercase tracking-wide transition-all whitespace-nowrap flex items-center justify-center gap-2"
                >
                  <i className="ri-phone-line text-orange" />
                  Call Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Color Selector ── */}
      <section id="siding-colors" className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal border-y border-white/10">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">Visualize Your Home</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(1.8rem, 4vw, 3.5rem)' }}>
              200+ Color Options
            </h2>
            <p className="text-white/40 text-sm mt-3 max-w-md mx-auto">
              Our siding is available in hundreds of colors and profiles. Here are the most popular choices for Evansville and Henderson area homes.
            </p>
          </div>
          <div className="flex flex-wrap justify-center gap-5">
            {COLORS.map((color) => (
              <button
                key={color.name}
                onClick={() => setSelectedColor(color.name)}
                className="flex flex-col items-center gap-2 cursor-pointer group"
              >
                <div
                  className={`w-12 h-12 rounded-full transition-all duration-200 ${selectedColor === color.name ? 'ring-2 ring-orange ring-offset-2 ring-offset-charcoal scale-110' : 'group-hover:scale-105'} ${color.border ? 'border border-white/20' : ''}`}
                  style={{ backgroundColor: color.hex }}
                />
                <span className={`text-xs uppercase tracking-wider transition-colors ${selectedColor === color.name ? 'text-orange' : 'text-white/40 group-hover:text-white/70'}`}>
                  {color.name}
                </span>
              </button>
            ))}
          </div>
          <p className="text-center text-white/30 text-xs mt-8">
            <i className="ri-information-line mr-1" />
            Selected: <span className="text-orange">{selectedColor}</span> — Ask about our full color catalog during your free estimate
          </p>
        </div>
      </section>

      {/* ── Siding Color Visualizer ── */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-white border-y border-gray-200">
        <div className="text-center mb-10">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">Interactive Tool</p>
          <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(1.8rem, 4vw, 3.5rem)' }}>
            Siding Color Visualizer
          </h2>
          <p className="text-gray-400 text-sm mt-3 max-w-md mx-auto">
            Pick vinyl, James Hardie, or wood colors and see them on real homes in the Evansville area. Compare side-by-side, explore roof pairings, and preview the full exterior.
          </p>
        </div>
        <SidingColorVisualizer />
      </section>

      {/* ── Vinyl vs. Hardie Comparison ── */}
      <section id="siding-comparison" className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Head-to-Head</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Vinyl vs.<br />James Hardie
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed mt-4">
            The two most popular siding choices for Evansville homes — compared across every factor that matters. No BS, just facts to help you pick the right fit.
          </p>
        </div>

        <div
          ref={compareAnim.ref as React.RefObject<HTMLDivElement>}
          className={`max-w-5xl mx-auto anim-fade-up ${compareAnim.isVisible ? 'is-visible' : ''}`}
        >
          {/* Header row */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="hidden md:block" />
            <div className="text-center border border-white/10 bg-charcoal-mid p-6">
              <h3 className="font-display text-white text-2xl uppercase tracking-wider mb-1">Vinyl Siding</h3>
              <span className="bg-orange text-white text-xs font-bold uppercase tracking-widest px-3 py-1">Most Popular</span>
            </div>
            <div className="text-center border border-orange/30 bg-orange/5 p-6">
              <h3 className="font-display text-white text-2xl uppercase tracking-wider mb-1">James Hardie</h3>
              <span className="bg-white/10 text-white text-xs font-bold uppercase tracking-widest px-3 py-1">Premium Choice</span>
            </div>
          </div>

          {/* Comparison rows */}
          {[
            {
              label: 'Price (installed)',
              vinyl: '$5–$10 / sq ft',
              vinylDesc: 'Best value for most budgets',
              hardie: '$10–$18 / sq ft',
              hardieDesc: 'Higher upfront, better long-term value',
              winner: 'vinyl' as const,
            },
            {
              label: 'Typical 1,500 sq ft Home',
              vinyl: '$6,000–$12,000',
              vinylDesc: 'Complete tear-off & install',
              hardie: '$12,000–$22,000',
              hardieDesc: 'Complete tear-off & install',
              winner: 'vinyl' as const,
            },
            {
              label: 'Lifespan',
              vinyl: '20–40 Years',
              vinylDesc: 'Premium insulated vinyl lasts longest',
              hardie: '30–50 Years',
              hardieDesc: 'Outlasts most homeowners',
              winner: 'hardie' as const,
            },
            {
              label: 'Maintenance',
              vinyl: 'Zero — wash once a year',
              vinylDesc: 'No painting, no sealing, ever',
              hardie: 'Minimal — inspect caulk every 5 yrs',
              hardieDesc: 'ColorPlus finish never needs paint',
              winner: 'tie' as const,
            },
            {
              label: 'Looks Like Real Wood?',
              vinyl: 'Good — textured profiles available',
              vinylDesc: 'Modern vinyl looks way better than 90s stuff',
              hardie: 'Identical — indistinguishable from wood',
              hardieDesc: 'HardiePlank & HardieShingle profiles',
              winner: 'hardie' as const,
            },
            {
              label: 'Fire Resistance',
              vinyl: 'Melts at high heat',
              vinylDesc: 'Non-combustible but will deform',
              hardie: 'Non-combustible — will not burn',
              hardieDesc: 'Cement composite, Class A fire rated',
              winner: 'hardie' as const,
            },
            {
              label: 'Impact / Hail Resistance',
              vinyl: 'Good — thick panels resist denting',
              vinylDesc: 'Holds up to Indiana hail season',
              hardie: 'Excellent — cement-based core',
              hardieDesc: 'Won\'t crack or dent from hail',
              winner: 'hardie' as const,
            },
            {
              label: 'Moisture Resistance',
              vinyl: 'Excellent — waterproof plastic',
              vinylDesc: 'Won\'t absorb water or rot',
              hardie: 'Excellent — impervious to moisture',
              hardieDesc: 'Cement + sand composite, zero rot risk',
              winner: 'tie' as const,
            },
            {
              label: 'Pest Resistance',
              vinyl: 'Excellent — nothing eats plastic',
              vinylDesc: 'Termites & carpenter ants ignore it',
              hardie: 'Excellent — cement is inedible',
              hardieDesc: 'Zero pest damage risk',
              winner: 'tie' as const,
            },
            {
              label: 'Energy Efficiency',
              vinyl: 'Excellent — insulated options R-2.5 to R-6',
              vinylDesc: 'Can reduce energy bills 10–20%',
              hardie: 'Good — adds some R-value via thickness',
              hardieDesc: 'Better with added insulation board',
              winner: 'vinyl' as const,
            },
            {
              label: 'Color Fade Resistance',
              vinyl: 'Good — UV-stable pigments',
              vinylDesc: 'May fade slightly over 15+ years',
              hardie: 'Excellent — ColorPlus baked-on finish',
              hardieDesc: '15-year color warranty, virtually zero fade',
              winner: 'hardie' as const,
            },
            {
              label: 'Color Options',
              vinyl: '200+ colors & profiles',
              vinylDesc: 'Nearly unlimited customization',
              hardie: '20+ ColorPlus colors, custom paintable',
              hardieDesc: 'Curated premium palette, paint any color',
              winner: 'vinyl' as const,
            },
            {
              label: 'Wind Rating',
              vinyl: '110–140 mph (premium panels)',
              vinylDesc: 'Sufficient for most Indiana storms',
              hardie: '140+ mph',
              hardieDesc: 'Best-in-class for high-wind corridors',
              winner: 'hardie' as const,
            },
            {
              label: 'Adds Resale Value',
              vinyl: 'Good — 75–85% cost recouped',
              vinylDesc: 'One of the highest-ROI projects',
              hardie: 'Excellent — 85–95% cost recouped',
              hardieDesc: 'Buyers recognize and pay premium for Hardie',
              winner: 'hardie' as const,
            },
            {
              label: 'Warranty',
              vinyl: 'Lifetime transferable (premium brands)',
              vinylDesc: 'Covers fading, warping, cracking',
              hardie: '30-year product + 15-year ColorPlus',
              hardieDesc: 'Industry-leading manufacturer coverage',
              winner: 'tie' as const,
            },
            {
              label: 'Installation Speed',
              vinyl: '2–3 days for average home',
              vinylDesc: 'Lightweight, interlocking panels',
              hardie: '3–5 days for average home',
              hardieDesc: 'Heavier material, more cuts needed',
              winner: 'vinyl' as const,
            },
          ].map((row, i) => (
            <div
              key={row.label}
              className={`grid grid-cols-1 md:grid-cols-3 gap-4 mb-3 ${i % 2 === 0 ? '' : ''}`}
            >
              {/* Label */}
              <div className="flex items-center border border-white/10 bg-charcoal-mid px-5 py-4">
                <span className="text-white font-semibold text-sm">{row.label}</span>
              </div>

              {/* Vinyl */}
              <div className={`border px-5 py-4 ${row.winner === 'vinyl' ? 'border-orange/40 bg-orange/5' : 'border-white/10 bg-charcoal-mid'}`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-white font-semibold text-sm">{row.vinyl}</span>
                  {row.winner === 'vinyl' && (
                    <span className="bg-orange text-white text-[10px] font-bold uppercase tracking-wider px-2 py-0.5">Winner</span>
                  )}
                </div>
                <p className="text-white/40 text-xs">{row.vinylDesc}</p>
              </div>

              {/* Hardie */}
              <div className={`border px-5 py-4 ${row.winner === 'hardie' ? 'border-orange/40 bg-orange/5' : 'border-white/10 bg-charcoal-mid'}`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-white font-semibold text-sm">{row.hardie}</span>
                  {row.winner === 'hardie' && (
                    <span className="bg-orange text-white text-[10px] font-bold uppercase tracking-wider px-2 py-0.5">Winner</span>
                  )}
                </div>
                <p className="text-white/40 text-xs">{row.hardieDesc}</p>
              </div>
            </div>
          ))}

          {/* Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10">
            <div className="border border-orange/30 bg-orange/5 p-8">
              <h4 className="font-display text-orange text-xl uppercase tracking-wider mb-4">Choose Vinyl If...</h4>
              <ul className="space-y-3">
                {[
                  'You want the best value for your budget',
                  'You want maximum color & profile choices',
                  'Energy efficiency is a top priority (insulated vinyl)',
                  'You want the fastest installation turnaround',
                  'You plan to sell within 10–15 years',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2 text-white/60 text-sm">
                    <i className="ri-check-line text-orange text-sm mt-0.5 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => document.getElementById('siding-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="mt-6 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-3 uppercase tracking-widest text-sm transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap"
              >
                Get Vinyl Quote
                <i className="ri-arrow-right-line" />
              </button>
            </div>

            <div className="border border-white/10 bg-charcoal-mid p-8">
              <h4 className="font-display text-white text-xl uppercase tracking-wider mb-4">Choose Hardie If...</h4>
              <ul className="space-y-3">
                {[
                  'You want the longest-lasting, most durable siding',
                  'You want a real wood look that never needs paint',
                  'You live in a high-wind or hail-prone area',
                  'You plan to stay in your home 20+ years',
                  'You want maximum resale value and buyer appeal',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2 text-white/60 text-sm">
                    <i className="ri-check-line text-orange text-sm mt-0.5 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => document.getElementById('siding-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="mt-6 border border-orange/40 hover:bg-orange/10 text-orange font-semibold px-8 py-3 uppercase tracking-widest text-sm transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap"
              >
                Get Hardie Quote
                <i className="ri-arrow-right-line" />
              </button>
            </div>
          </div>

          <p className="text-center text-white/30 text-sm mt-8">
            <i className="ri-information-line mr-1" />
            Still not sure? We inspect your home, budget, and goals — then recommend the right material. No upsell, ever.
          </p>
        </div>
      </section>

      {/* ── Siding vs. Paint ROI ── */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal border-y border-white/10">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">Smart Investment</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(1.8rem, 4vw, 3.5rem)' }}>
              Siding vs. Repainting
            </h2>
            <p className="text-white/40 text-sm mt-3 max-w-xl mx-auto">
              Repainting every 5–7 years adds up fast. See the true lifetime cost of painting vs. a one-time siding replacement that lasts 20–40 years.
            </p>
          </div>
          <SidingVsPaintROI />
        </div>
      </section>

      {/* ── Siding Cost Estimator ── */}
      <SidingCostEstimator />

      {/* ── Why Corner Stone ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Why Choose Us</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            The Corner Stone<br />Difference
          </h2>
        </div>

        <div
          ref={advantages.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {[
            { ...ADVANTAGES[0], onClick: () => document.getElementById('bundle-save')?.scrollIntoView({ behavior: 'smooth' }) },
            { ...ADVANTAGES[1], onClick: () => document.getElementById('siding-types')?.scrollIntoView({ behavior: 'smooth' }) },
            { ...ADVANTAGES[2], onClick: () => navigate('/insurance-claims') },
            { ...ADVANTAGES[3], onClick: () => document.getElementById('siding-colors')?.scrollIntoView({ behavior: 'smooth' }) },
            { ...ADVANTAGES[4], onClick: () => document.getElementById('service-area')?.scrollIntoView({ behavior: 'smooth' }) },
            { ...ADVANTAGES[5], onClick: () => navigate('/warranty') },
          ].map((adv, i) => (
            <div
              key={adv.title}
              onClick={adv.onClick}
              className={`border border-white/10 bg-charcoal-mid p-8 hover:border-orange/30 hover:bg-charcoal-light/50 transition-all duration-300 group anim-fade-up cursor-pointer ${advantages.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="w-12 h-12 flex items-center justify-center bg-orange/15 group-hover:bg-orange/25 transition-colors mb-5">
                <i className={`${adv.icon} text-orange text-xl`} />
              </div>
              <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">{adv.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{adv.desc}</p>
              <div className="mt-4 flex items-center gap-1 text-orange text-xs uppercase tracking-widest font-semibold opacity-0 group-hover:opacity-100 transition-opacity">
                <span>Learn more</span>
                <i className="ri-arrow-right-line" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Bundle & Save CTA ── */}
      <section id="bundle-save" className="py-14 px-6 md:px-10 lg:px-16">
        <div className="relative overflow-hidden border border-orange/30 bg-orange/5">
          <div className="absolute top-0 right-0 w-64 h-64 bg-orange/10 rounded-full -translate-y-1/2 translate-x-1/2 pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-orange/5 rounded-full translate-y-1/2 -translate-x-1/2 pointer-events-none" />
          <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8 p-8 md:p-12">
            <div className="flex-1">
              <div className="inline-flex items-center gap-2 bg-orange text-white text-xs font-bold uppercase tracking-widest px-4 py-2 mb-5">
                <i className="ri-price-tag-3-line" />
                Bundle &amp; Save $800–$2,000
              </div>
              <h3 className="font-display text-white uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(1.8rem, 3.5vw, 3rem)' }}>
                Roof + Siding + Gutters.<br />One Crew. One Visit.
              </h3>
              <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-xl">
                Replacing your siding? The smartest move is bundling it with your roof and gutters. One mobilization, one crew, one cleanup — and you save big. Our Complete Exterior Package is the highest-value project we offer.
              </p>
              <div className="grid grid-cols-2 gap-3 mt-5 max-w-lg">
                {[
                  { icon: 'ri-money-dollar-circle-line', text: 'Save $800–$2,000 on mobilization' },
                  { icon: 'ri-team-line', text: 'One crew handles roof, siding & gutters' },
                  { icon: 'ri-palette-line', text: 'Perfectly matched materials & colors' },
                  { icon: 'ri-file-shield-2-line', text: 'Single insurance claim for all damage' },
                ].map((item) => (
                  <div key={item.text} className="flex items-start gap-2 text-white/50 text-xs">
                    <i className={`${item.icon} text-orange text-sm mt-0.5 flex-shrink-0`} />
                    {item.text}
                  </div>
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-3 flex-shrink-0">
              <button
                onClick={() => navigate('/exterior-package')}
                className="bg-orange hover:bg-orange-dark text-white font-bold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <i className="ri-home-gear-line" />
                See Complete Exterior Package
              </button>
              <a
                href="tel:8122135997"
                className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap flex items-center justify-center gap-2"
              >
                <i className="ri-phone-line text-orange" />
                812-213-5997
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ── Bundle with Roof Savings Calculator ── */}
      <section ref={bundleSectionRef} className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-white border-y border-gray-200">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">Real Numbers</p>
            <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(1.8rem, 4vw, 3.5rem)' }}>
              Bundle with Roof — Dollar-for-Dollar
            </h2>
            <p className="text-gray-400 text-sm mt-3 max-w-md mx-auto">
              See exactly where the savings come from when you bundle roof, siding, and gutters into one project with one crew.
            </p>
          </div>
          <BundleRoofCalculator />
        </div>
      </section>

      {/* ── Process ── */}
      <ServiceProcessStrip
        heading="How It Works"
        subheading="New Siding in\n4 Simple Steps"
        steps={[
          { num: '01', icon: 'ri-search-eye-line', title: 'Free Inspection', desc: 'We inspect your existing siding, sheathing, and moisture barrier. We identify any rot, mold, or structural issues before they become bigger problems.', detail: 'Storm damage check included' },
          { num: '02', icon: 'ri-file-list-3-line', title: 'Written Quote', desc: 'You get a detailed written quote covering material, profile, color, and any substrate repairs needed. No surprises on install day.', detail: 'Includes color & profile samples' },
          { num: '03', icon: 'ri-tools-line', title: 'Expert Installation', desc: 'Our crew removes old siding, repairs damaged sheathing, installs moisture barrier, and applies your new siding to exact manufacturer specs.', detail: 'James Hardie certified methods' },
          { num: '04', icon: 'ri-checkbox-circle-line', title: 'Final Walkthrough', desc: 'We check every seam, corner, and trim piece with you. We clean the site completely and register your warranty before you pay.', detail: 'Lifetime workmanship warranty' },
        ]}
        ctaText="Ready for new siding? Get your free estimate today."
        ctaSubtext="Free inspection · Color samples · No pressure · Tri-State area"
        buttonText="Get Free Siding Quote"
        buttonHref="#siding-form"
      />

      {/* ── Compare Quotes — Bundle vs. Separate Contractors ── */}
      <CompetitorComparisonTool />

      {/* ── Price Match Guarantee ── */}
      <PriceMatchBanner serviceName="siding replacement" highlightSavings="James Hardie Preferred quality at the best price — guaranteed" />

      {/* ── Insurance Claims CTA ── */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16">
        <div className="border border-white/10 bg-charcoal-mid p-8 md:p-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <div>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-10 h-10 flex items-center justify-center bg-orange/15">
                  <i className="ri-file-shield-2-line text-orange text-xl" />
                </div>
                <span className="text-orange text-xs uppercase tracking-[0.25em] font-semibold">Storm Damage?</span>
              </div>
              <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
                We Handle Your<br />Insurance Claim.
              </h2>
              <p className="text-white/50 text-sm md:text-base leading-relaxed">
                Hail and wind damage to siding is one of the most common insurance claims in Indiana. We inspect your siding for storm damage, document everything with photos, and work directly with your adjuster. Most homeowners get full siding replacements for just their deductible.
              </p>
            </div>
            <div className="space-y-4">
              {[
                { icon: 'ri-search-eye-line', title: 'Free Storm Damage Inspection', desc: 'We identify all hail and wind damage — even damage you can\'t see from the ground.' },
                { icon: 'ri-camera-line', title: 'Full Photo Documentation', desc: 'We document every damaged panel with photos and measurements for your insurance claim.' },
                { icon: 'ri-user-voice-line', title: 'Adjuster Coordination', desc: 'We meet with your adjuster on-site and advocate for a full replacement when warranted.' },
                { icon: 'ri-money-dollar-circle-line', title: '$0 Out of Pocket (Often)', desc: 'Many homeowners pay only their deductible. We help maximize your claim payout.' },
              ].map((item) => (
                <div key={item.title} className="flex items-start gap-4">
                  <div className="w-9 h-9 flex items-center justify-center bg-orange/15 flex-shrink-0 mt-0.5">
                    <i className={`${item.icon} text-orange text-base`} />
                  </div>
                  <div>
                    <p className="text-white font-semibold text-sm">{item.title}</p>
                    <p className="text-white/40 text-xs leading-relaxed mt-0.5">{item.desc}</p>
                  </div>
                </div>
              ))}
              <button
                onClick={() => navigate('/insurance-claims')}
                className="mt-2 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-sm transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap"
              >
                <i className="ri-file-shield-2-line" />
                Learn About Insurance Claims
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ── Service Area ── */}
      <section id="service-area" className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Where We Work</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Serving Evansville,<br />Henderson &amp; the<br />Tri-State Area
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-6">
              From Evansville to Henderson KY, Newburgh to Owensboro — we install siding across the entire Tri-State area. One call, one crew, one company you can trust.
            </p>
            <div className="space-y-3 mb-8">
              {[
                { city: 'Evansville, IN', note: 'Primary Market — Headquarters' },
                { city: 'Henderson, KY', note: 'Primary KY Market' },
                { city: 'Newburgh, IN', note: 'Warrick County' },
                { city: 'Owensboro, KY', note: 'Daviess County' },
                { city: 'Boonville, IN', note: 'Warrick County' },
                { city: 'Mount Vernon, IN', note: 'Posey County' },
              ].map((loc) => (
                <div key={loc.city} className="flex items-center justify-between py-2 border-b border-white/5">
                  <div className="flex items-center gap-3">
                    <i className="ri-map-pin-2-line text-orange text-sm" />
                    <span className="text-white text-sm font-medium">{loc.city}</span>
                  </div>
                  <span className="text-white/30 text-xs">{loc.note}</span>
                </div>
              ))}
            </div>
            <button
              onClick={() => navigate('/service-areas')}
              className="border border-white/20 hover:border-orange text-white/70 hover:text-white text-sm font-semibold px-8 py-3.5 uppercase tracking-widest transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap"
            >
              <i className="ri-map-2-line text-orange" />
              View Full Service Area
            </button>
          </div>

          <div className="w-full overflow-hidden border border-white/10" style={{ height: '420px' }}>
            <iframe
              title="Corner Stone Siding Service Area Evansville Indiana"
              src="https://www.google.com/maps/embed/v1/place?key=AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY&q=Evansville,+Indiana&zoom=9"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Common Questions</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Siding FAQ
            </h2>
          </div>
          <div
            ref={faqAnim.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${faqAnim.isVisible ? 'is-visible' : ''}`}
          >
            {FAQS.map((faq, i) => (
              <div key={i} className="border-b border-white/10">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between py-5 text-left cursor-pointer group"
                >
                  <span className="font-display text-white text-lg uppercase tracking-wider pr-4 group-hover:text-orange transition-colors">{faq.q}</span>
                  <div className={`w-8 h-8 flex items-center justify-center border flex-shrink-0 transition-all duration-300 ${openFaq === i ? 'bg-orange border-orange text-white' : 'border-white/20 text-white/40 group-hover:border-orange group-hover:text-orange'}`}>
                    <i className={`ri-${openFaq === i ? 'subtract' : 'add'}-line`} />
                  </div>
                </button>
                <div className={`overflow-hidden transition-all duration-500 ${openFaq === i ? 'max-h-56 opacity-100 pb-5' : 'max-h-0 opacity-0'}`}>
                  <p className="text-white/50 text-sm leading-relaxed pr-12">{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Quote Form ── */}
      <section id="siding-form" className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div
          ref={formAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${formAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {/* Left copy */}
            <div>
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Free Estimate</p>
              <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 5vw, 5rem)' }}>
                Get Your Free<br />Siding Quote<br /><span className="text-orange">Today.</span>
              </h2>
              <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
                Fill out the form and we'll contact you within 2 hours to schedule your free on-site estimate. We'll inspect your current siding, check for storm damage, and give you a written quote with material and color options.
              </p>
              <div className="space-y-4">
                {[
                  { icon: 'ri-timer-line', text: 'Response within 2 hours' },
                  { icon: 'ri-search-eye-line', text: 'Free storm damage inspection included' },
                  { icon: 'ri-file-list-3-line', text: 'Written quote with color & profile options' },
                  { icon: 'ri-file-shield-2-line', text: 'Insurance claim assistance available' },
                ].map((item) => (
                  <div key={item.text} className="flex items-center gap-3 text-white/50 text-sm">
                    <i className={`${item.icon} text-orange text-base`} />
                    {item.text}
                  </div>
                ))}
              </div>
              <div className="mt-8 pt-8 border-t border-white/10">
                <p className="text-white/30 text-xs uppercase tracking-widest mb-3">Or call us directly</p>
                <a href="tel:8122135997" className="flex items-center gap-3 text-white hover:text-orange transition-colors">
                  <i className="ri-phone-fill text-orange text-xl" />
                  <span className="font-display text-2xl tracking-wider">812-213-5997</span>
                </a>
              </div>
            </div>

            {/* Right form */}
            <div className="bg-white rounded-2xl overflow-hidden">
              <div className="bg-charcoal-deep px-8 py-6 border-b border-white/10">
                <h3 className="font-display text-white text-2xl uppercase tracking-wider">Siding Quote Request</h3>
                <p className="text-white/50 text-sm mt-1">Vinyl, James Hardie, wood &amp; exterior trim</p>
              </div>

              {formStatus === 'success' ? (
                <div className="px-8 py-14 flex flex-col items-center text-center">
                  <div className="w-16 h-16 flex items-center justify-center bg-green-100 rounded-full mb-4">
                    <i className="ri-checkbox-circle-fill text-green-600 text-3xl" />
                  </div>
                  <h4 className="font-display text-charcoal text-2xl uppercase tracking-wider mb-2">Request Received!</h4>
                  <p className="text-gray-500 text-sm leading-relaxed max-w-xs">
                    We'll contact you within 2 hours to schedule your free on-site siding estimate.
                  </p>
                  <button onClick={() => setFormStatus('idle')} className="mt-6 text-orange text-sm font-semibold underline underline-offset-4 cursor-pointer">
                    Submit another request
                  </button>
                </div>
              ) : (
                <form
                  ref={formRef}
                  data-readdy-form
                  onSubmit={handleSubmit}
                  className="px-8 py-7 space-y-4"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Full Name</label>
                      <input type="text" name="name" required placeholder="Jane Smith" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Phone</label>
                      <input type="tel" name="phone" required placeholder="812-000-0000" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Email</label>
                    <input type="email" name="email" required placeholder="you@email.com" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Property Address</label>
                    <input type="text" name="address" required placeholder="123 Main St, Evansville, IN" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Service Needed</label>
                      <select name="service_needed" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                        <option value="">Select service</option>
                        <option value="full-replacement">Full Siding Replacement</option>
                        <option value="new-install">New Installation</option>
                        <option value="storm-damage">Storm Damage Repair</option>
                        <option value="partial-repair">Partial Repair</option>
                        <option value="trim-fascia">Trim &amp; Fascia Only</option>
                        <option value="bundle-roof">Bundle with Roof Replacement</option>
                        <option value="inspection">Inspection / Not Sure</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Siding Material</label>
                      <select name="material_preference" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                        <option value="">Select material</option>
                        <option value="vinyl">Vinyl Siding</option>
                        <option value="james-hardie">James Hardie Fiber Cement</option>
                        <option value="wood">Wood / Cedar</option>
                        <option value="not-sure">Not Sure — Need Advice</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Storm Damage Claim?</label>
                    <select name="insurance_claim" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                      <option value="">Select option</option>
                      <option value="yes-filing">Yes — I&apos;m filing a claim</option>
                      <option value="yes-check">Yes — I want a damage inspection first</option>
                      <option value="no">No — Not storm related</option>
                      <option value="not-sure">Not Sure</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                      Additional Details <span className="text-gray-400 font-normal normal-case">(optional)</span>
                    </label>
                    <textarea
                      name="notes"
                      rows={3}
                      maxLength={500}
                      onChange={(e) => setCharCount(e.target.value.length)}
                      placeholder="Current siding condition, color preferences, timeline, bundling with roof or gutters..."
                      className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
                    />
                    <p className={`text-xs mt-1 text-right ${charCount > 500 ? 'text-red-500' : 'text-gray-400'}`}>{charCount}/500</p>
                  </div>
                  <button
                    type="submit"
                    disabled={formStatus === 'submitting'}
                    className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-300 text-white font-bold text-sm uppercase tracking-widest py-4 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  >
                    {formStatus === 'submitting' ? (
                      <><i className="ri-loader-4-line animate-spin" />Sending...</>
                    ) : (
                      <><i className="ri-send-plane-line" />Get My Free Siding Quote</>
                    )}
                  </button>
                  {formStatus === 'error' && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2">
                      <i className="ri-alert-line text-red-500" />
                      <p className="text-red-600 text-xs">Something went wrong. Please call 812-213-5997 directly.</p>
                    </div>
                  )}
                  <p className="text-gray-400 text-xs text-center">
                    <i className="ri-lock-line mr-1" />Your information is private and secure.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ── You Might Also Need ── */}
      <RelatedServicesStrip
        heading="You Might Also Need"
        subheading="Complete your exterior in one project — matched materials, one crew, one cleanup."
        services={[
          {
            icon: 'ri-home-smile-line',
            label: 'Residential Roofing',
            description: 'New siding pairs perfectly with a new roof. Bundle both and save on mobilization — most popular combo.',
            href: '/residential-roofing',
            badge: 'Most Popular Bundle',
          },
          {
            icon: 'ri-drop-line',
            label: 'Gutters & Downspouts',
            description: 'Seamless gutters complete the exterior package. Protect your new siding from water overflow damage.',
            href: '/gutters-downspouts',
          },
          {
            icon: 'ri-home-gear-line',
            label: 'Complete Exterior Package',
            description: 'Roof + Siding + Gutters bundled together. Save $800–$2,000 and get everything done in one visit.',
            href: '/exterior-package',
            badge: 'Save $800–$2,000',
            highlight: true,
          },
        ]}
      />

      {/* ── Sticky Bundle CTA ── */}
      <div
        className={`fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 shadow-[0_-4px_20px_rgba(0,0,0,0.08)] transition-transform duration-300 ${showStickyBundleCTA ? 'translate-y-0' : 'translate-y-full'}`}
      >
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 flex items-center justify-center bg-orange/10 rounded-lg flex-shrink-0">
              <i className="ri-price-tag-3-line text-orange text-lg" />
            </div>
            <div className="min-w-0">
              <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider truncate">
                Bundle Roof + Siding + Gutters — Save $6,850+
              </p>
              <p className="text-gray-400 text-[10px] hidden sm:block">
                One crew, one visit, one cleanup. See the full dollar-for-dollar breakdown above.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3 flex-shrink-0">
            <a
              href="#siding-form"
              className="bg-orange hover:bg-orange-dark text-white font-bold px-5 py-2.5 uppercase tracking-widest text-xs transition-colors whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-calendar-check-line" />
              Get Bundle Quote
            </a>
            <button
              onClick={() => setShowStickyBundleCTA(false)}
              className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 transition-colors cursor-pointer flex-shrink-0"
            >
              <i className="ri-close-line text-lg" />
            </button>
          </div>
        </div>
      </div>

      <BundleSaveBadge />
    </div>
  );
}
