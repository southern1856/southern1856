import { caseStudies } from '@/mocks/caseStudies';

const FILTERS = ['All', 'Residential', 'Commercial', 'Repair', 'Multi-Family'] as const;
type FilterKey = (typeof FILTERS)[number];

interface Props {
  active: FilterKey;
  onChange: (f: FilterKey) => void;
}

export default function CaseStudyFilter({ active, onChange }: Props) {
  const getCount = (f: FilterKey) => {
    if (f === 'All') return caseStudies.length;
    return caseStudies.filter((s) => s.type === f).length;
  };

  return (
    <div className="flex flex-wrap gap-2">
      {FILTERS.map((f) => (
        <button
          key={f}
          onClick={() => onChange(f)}
          className={`inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold uppercase tracking-wide transition-all duration-200 whitespace-nowrap cursor-pointer ${
            active === f
              ? 'bg-orange text-white'
              : 'border border-white/20 text-white/40 hover:border-orange hover:text-orange'
          }`}
        >
          {f}
          <span
            className={`text-xs px-1.5 py-0.5 ${
              active === f ? 'bg-white/20 text-white' : 'bg-white/10 text-white/30'
            }`}
          >
            {getCount(f)}
          </span>
        </button>
      ))}
    </div>
  );
}