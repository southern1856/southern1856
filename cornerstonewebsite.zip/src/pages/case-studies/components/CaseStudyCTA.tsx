import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

export default function CaseStudyCTA() {
  const navigate = useNavigate();
  const anim = useScrollAnimation({ threshold: 0.1 });

  return (
    <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal-deep">
      <div
        ref={anim.ref as React.RefObject<HTMLDivElement>}
        className={`max-w-4xl mx-auto text-center anim-fade-up ${anim.isVisible ? 'is-visible' : ''}`}
      >
        <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Your Story Starts Here</p>
        <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
          Ready to Be Our<br /><span className="text-orange">Next Case Study?</span>
        </h2>
        <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed mb-10">
          Every project above started with a free inspection. No obligation, no pressure — just honest answers and a clear plan. Let's see what your roof needs.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={() => navigate('/free-inspection')}
            className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
          >
            <i className="ri-calendar-check-line" />
            Book Free Inspection
          </button>
          <a
            href="tel:8122135997"
            className="border border-white/20 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
          >
            <i className="ri-phone-line text-orange" />
            812-213-5997
          </a>
        </div>
        <p className="text-white/20 text-xs mt-6">Mon–Sat 7am–7pm · Emergency line available 24/7</p>
      </div>
    </section>
  );
}