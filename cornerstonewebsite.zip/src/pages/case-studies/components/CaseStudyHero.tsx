import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { caseStudyStats } from '@/mocks/caseStudies';

function openReaddyAgent(prefill?: string) {
  const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
  if (btn) btn.click();
  if (!prefill) return;
  setTimeout(() => {
    const input = document.querySelector('input[placeholder*="message" i], textarea[placeholder*="message" i], input[placeholder*="ask" i], textarea[placeholder*="ask" i], input[placeholder*="type" i], textarea[placeholder*="type" i]') as HTMLInputElement | HTMLTextAreaElement | null;
    if (input) {
      input.value = prefill;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      const form = input.closest('form');
      if (form) {
        const submitBtn = form.querySelector('button[type="submit"], button[aria-label*="send" i]') as HTMLElement | null;
        if (submitBtn) submitBtn.click();
      }
    }
  }, 900);
}

export default function CaseStudyHero() {
  const hero = useScrollAnimation();

  return (
    <section className="relative bg-charcoal-deep pt-32 pb-16 md:pt-40 md:pb-20 overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="/placeholders/1600x700.svg"
          alt="Corner Stone Construction roofing case studies across Evansville Indiana"
          className="w-full h-full object-cover object-top"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-charcoal-deep" />
      </div>

      <div className="relative w-full px-6 md:px-10 lg:px-16">
        <div className="flex items-center gap-2 text-white/40 text-xs uppercase tracking-widest mb-8">
          <a href="/" className="hover:text-orange transition-colors">Home</a>
          <i className="ri-arrow-right-s-line" />
          <span className="text-orange">Case Studies</span>
        </div>

        <div className="max-w-3xl mb-12">
          <p className="text-orange text-xs uppercase tracking-[0.3em] font-semibold mb-4">Real Projects. Real Stories.</p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 6vw, 6rem)' }}>
            Case<br /><span className="text-orange">Studies</span>
          </h1>
          <p className="text-white/50 text-base md:text-lg leading-relaxed max-w-xl">
            Every roof tells a story. Here are 8 real projects we completed across Evansville, Newburgh, Henderson, and the Tri-State area — with the challenges, solutions, and outcomes that prove why homeowners trust Corner Stone.
          </p>
          <button
            onClick={() => openReaddyAgent("Tell me about Corner Stone's roofing case studies and transformations.")}
            className="mt-6 inline-flex items-center gap-2 bg-white/5 border border-white/10 hover:border-green-400/50 hover:text-green-400 text-white/70 font-semibold px-5 py-3.5 uppercase tracking-widest text-xs transition-colors whitespace-nowrap cursor-pointer"
          >
            <i className="ri-mic-line text-green-400 text-sm" />
            Ask AI About These Case Studies
          </button>
        </div>

        <div
          ref={hero.ref as React.RefObject<HTMLDivElement>}
          className={`grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
        >
          {caseStudyStats.map((stat, i) => (
            <div
              key={stat.label}
              className="border border-white/10 bg-white/5 backdrop-blur-sm p-4 md:p-6"
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <p className="font-display text-orange text-2xl md:text-3xl tracking-wider">{stat.value}</p>
              <p className="text-white text-xs font-semibold uppercase tracking-widest mt-1">{stat.label}</p>
              <p className="text-white/30 text-xs mt-0.5">{stat.sub}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}