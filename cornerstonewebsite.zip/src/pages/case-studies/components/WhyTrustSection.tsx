import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const trustItems = [
  {
    icon: 'ri-camera-line',
    title: 'Photo Documentation on Every Job',
    desc: 'We photograph every stage — before, during, and after. You get a full visual report for your records, insurance, and peace of mind.',
  },
  {
    icon: 'ri-shield-check-line',
    title: 'Manufacturer-Certified Installation',
    desc: 'GAF Master Elite, Owens Corning Preferred, and CertainTeed SELECT ShingleMaster. These credentials matter when warranties are on the line.',
  },
  {
    icon: 'ri-file-shield-line',
    title: 'Insurance Claim Expertise',
    desc: 'We have helped homeowners recover over $4.2M in insurance claims. Our 94% first-submission approval rate speaks for itself.',
  },
  {
    icon: 'ri-award-line',
    title: 'Workmanship Warranty Included',
    desc: 'Every job carries our workmanship warranty — up to lifetime coverage on qualifying GAF System Plus installations.',
  },
  {
    icon: 'ri-group-line',
    title: 'In-House Crews, No Subcontractors',
    desc: 'Every person on your roof works for Corner Stone. We do not hire day laborers or subcontract to unknown crews.',
  },
  {
    icon: 'ri-map-pin-line',
    title: 'Local for 30+ Years',
    desc: 'Founded in Evansville in 1995. We know Indiana weather, Indiana homes, and Indiana insurance adjusters.',
  },
];

export default function WhyTrustSection() {
  const anim = useScrollAnimation({ threshold: 0.05 });

  return (
    <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
      <div className="max-w-6xl mx-auto">
        <div
          ref={anim.ref as React.RefObject<HTMLDivElement>}
          className={`text-center mb-14 anim-fade-up ${anim.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Why These Stories Matter</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            What Makes Corner<br />Stone <span className="text-orange">Different</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
          {trustItems.map((item, i) => (
            <div
              key={item.title}
              className={`bg-charcoal-mid border border-white/5 hover:border-orange/20 transition-all duration-300 p-6 md:p-7 anim-fade-up ${anim.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="w-10 h-10 flex items-center justify-center bg-orange/15 text-orange mb-4">
                <i className={`${item.icon} text-lg`} />
              </div>
              <h3 className="font-display text-white text-base uppercase tracking-wider mb-2">{item.title}</h3>
              <p className="text-white/40 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}