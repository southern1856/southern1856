import { useState, useRef, useCallback, useEffect } from 'react';
import type { CaseStudy } from '@/mocks/caseStudies';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import SocialShareCard from '@/components/feature/SocialShareCard';

export default function CaseStudyCard({ study, index }: { study: CaseStudy; index: number }) {
  const [sliderPos, setSliderPos] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const [showGallery, setShowGallery] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const anim = useScrollAnimation({ threshold: 0.05 });

  const updateSlider = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const pos = Math.min(100, Math.max(0, ((clientX - rect.left) / rect.width) * 100));
    setSliderPos(pos);
  }, []);

  useEffect(() => {
    if (!isDragging) return;
    const onMove = (e: MouseEvent) => updateSlider(e.clientX);
    const onUp = () => setIsDragging(false);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
  }, [isDragging, updateSlider]);

  const isEven = index % 2 === 0;

  return (
    <div
      ref={anim.ref as React.RefObject<HTMLDivElement>}
      className={`anim-fade-up ${anim.isVisible ? 'is-visible' : ''}`}
      style={{ transitionDelay: `${(index % 2) * 150}ms` }}
    >
      <div className={`grid grid-cols-1 lg:grid-cols-2 gap-0 border border-white/5 hover:border-orange/10 transition-all duration-500 overflow-hidden ${isEven ? '' : 'lg:[direction:rtl]'}`}>
        {/* Image side */}
        <div className={`relative ${isEven ? '' : 'lg:[direction:ltr]'}`}>
          {/* Slider */}
          <div
            ref={containerRef}
            className="relative h-72 sm:h-80 md:h-96 overflow-hidden cursor-col-resize select-none"
            onMouseDown={(e) => { e.preventDefault(); setIsDragging(true); updateSlider(e.clientX); }}
            onTouchMove={(e) => updateSlider(e.touches[0].clientX)}
            onTouchStart={(e) => updateSlider(e.touches[0].clientX)}
          >
            <img
              src={study.afterImage}
              alt={`After — ${study.title}`}
              className="absolute inset-0 w-full h-full object-cover object-top"
            />
            <div className="absolute inset-0 overflow-hidden" style={{ width: `${sliderPos}%` }}>
              <img
                src={study.beforeImage}
                alt={`Before — ${study.title}`}
                className="absolute inset-0 h-full object-cover object-top"
                style={{ width: containerRef.current ? `${containerRef.current.offsetWidth}px` : '100%', maxWidth: 'none' }}
              />
            </div>
            <div className="absolute top-0 bottom-0 w-0.5 bg-white z-10 pointer-events-none" style={{ left: `${sliderPos}%`, transform: 'translateX(-50%)' }}>
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-9 h-9 bg-white rounded-full flex items-center justify-center">
                <i className="ri-arrow-left-right-line text-charcoal-deep text-sm" />
              </div>
            </div>
            <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-sm text-white text-xs font-bold px-2.5 py-1 uppercase tracking-wider pointer-events-none">Before</div>
            <div className="absolute top-3 right-3 bg-orange/90 text-white text-xs font-bold px-2.5 py-1 uppercase tracking-wider pointer-events-none">After</div>
            <div className="absolute bottom-3 left-3 text-white text-xs font-bold px-2.5 py-1 uppercase tracking-wider pointer-events-none bg-orange">{study.badge}</div>
            <div className="absolute bottom-3 right-3 text-white/50 text-xs flex items-center gap-1 pointer-events-none">
              <i className="ri-drag-move-line text-sm" />
              Drag
            </div>
          </div>

          {/* Gallery thumbnails */}
          {study.galleryImages.length > 0 && (
            <div className="flex gap-1 p-1 bg-charcoal">
              {study.galleryImages.slice(0, 3).map((img, i) => (
                <button
                  key={i}
                  onClick={() => setShowGallery(true)}
                  className="relative flex-1 h-16 md:h-20 overflow-hidden cursor-pointer group"
                >
                  <img src={img} alt={`Gallery ${i + 1}`} className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-300" />
                  {i === 2 && study.galleryImages.length > 3 && (
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">+{study.galleryImages.length - 3}</span>
                    </div>
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Content side */}
        <div className={`bg-charcoal-mid p-6 md:p-8 lg:p-10 flex flex-col ${isEven ? '' : 'lg:[direction:ltr]'}`}>
          {/* Header */}
          <div className="mb-5">
            <div className="flex items-center gap-3 mb-3 flex-wrap">
              <span className="text-orange text-xs font-semibold uppercase tracking-wider">{study.type}</span>
              <span className="text-white/20 text-xs">|</span>
              <span className="text-white/40 text-xs">{study.location}</span>
              <span className="text-white/20 text-xs">|</span>
              <span className="text-white/40 text-xs">{study.year}</span>
            </div>
            <h2 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wide leading-snug">{study.title}</h2>
            <p className="text-white/40 text-sm mt-1">{study.subtitle}</p>
          </div>

          {/* Story sections */}
          <div className="space-y-4 flex-grow">
            <div>
              <p className="text-orange text-xs font-semibold uppercase tracking-wider mb-1.5">The Challenge</p>
              <p className="text-white/50 text-sm leading-relaxed">{study.challenge}</p>
            </div>
            <div>
              <p className="text-orange text-xs font-semibold uppercase tracking-wider mb-1.5">Our Solution</p>
              <p className="text-white/50 text-sm leading-relaxed">{study.solution}</p>
            </div>
            <div>
              <p className="text-orange text-xs font-semibold uppercase tracking-wider mb-1.5">The Outcome</p>
              <p className="text-white/50 text-sm leading-relaxed">{study.outcome}</p>
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-6 mb-5">
            <div className="bg-white/5 px-3 py-2.5">
              <p className="text-orange text-xs font-bold">{study.duration}</p>
              <p className="text-white/30 text-xs">Duration</p>
            </div>
            <div className="bg-white/5 px-3 py-2.5">
              <p className="text-orange text-xs font-bold">{study.squareFootage}</p>
              <p className="text-white/30 text-xs">Size</p>
            </div>
            <div className="bg-white/5 px-3 py-2.5">
              <p className="text-orange text-xs font-bold">{study.material}</p>
              <p className="text-white/30 text-xs">Material</p>
            </div>
            {study.claimAmount ? (
              <div className="bg-white/5 px-3 py-2.5">
                <p className="text-orange text-xs font-bold">{study.claimAmount}</p>
                <p className="text-white/30 text-xs">Claim</p>
              </div>
            ) : (
              <div className="bg-white/5 px-3 py-2.5">
                <p className="text-orange text-xs font-bold">{study.year}</p>
                <p className="text-white/30 text-xs">Year</p>
              </div>
            )}
          </div>

          {/* Client quote */}
          {study.clientQuote && (
            <div className="border-t border-white/10 pt-5 mt-2">
              <i className="ri-double-quotes-l text-orange text-lg mb-2 block" />
              <p className="text-white/60 text-sm italic leading-relaxed mb-3">"{study.clientQuote}"</p>
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 flex items-center justify-center bg-orange/20 text-orange text-xs font-bold rounded-full">
                  {study.clientName.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <p className="text-white text-xs font-semibold">{study.clientName}</p>
                  <p className="text-white/30 text-xs">{study.clientRole} &bull; {study.location}</p>
                </div>
              </div>
            </div>
          )}

          {/* Share CTA */}
          <div className="pt-4 mt-4 border-t border-white/10">
            <button
              onClick={() => setShowShare(true)}
              className="flex items-center gap-2 text-white/40 hover:text-orange text-xs uppercase tracking-wider transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-share-forward-line text-sm" />
              Share This Transformation
            </button>
          </div>
        </div>
      </div>

      {/* Gallery Lightbox */}
      {showGallery && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 md:p-8" onClick={() => setShowGallery(false)}>
          <div className="max-w-4xl w-full max-h-[85vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <p className="text-white text-sm font-semibold">{study.title} — Project Gallery</p>
              <button onClick={() => setShowGallery(false)} className="w-8 h-8 flex items-center justify-center text-white/60 hover:text-white cursor-pointer">
                <i className="ri-close-line text-xl" />
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {study.galleryImages.map((img, i) => (
                <img key={i} src={img} alt={`${study.title} gallery ${i + 1}`} className="w-full h-48 md:h-64 object-cover object-top" />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Share Card */}
      {showShare && (
        <SocialShareCard
          title={study.title}
          subtitle={study.subtitle}
          type={study.type}
          location={study.location}
          year={study.year}
          image={study.afterImage}
          badge={study.badge}
          stats={[
            { label: 'Duration', value: study.duration, icon: 'ri-time-line' },
            { label: 'Size', value: study.squareFootage, icon: 'ri-ruler-line' },
            { label: 'Material', value: study.material.split(' ')[0], icon: 'ri-stack-line' },
          ]}
          highlights={study.highlights.slice(0, 4)}
          description={study.description}
          onClose={() => setShowShare(false)}
        />
      )}
    </div>
  );
}