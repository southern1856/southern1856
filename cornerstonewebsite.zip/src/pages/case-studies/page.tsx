import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import { caseStudies } from '@/mocks/caseStudies';
import CaseStudyHero from './components/CaseStudyHero';
import CaseStudyCard from './components/CaseStudyCard';
import CaseStudyFilter from './components/CaseStudyFilter';
import CaseStudyCTA from './components/CaseStudyCTA';
import WhyTrustSection from './components/WhyTrustSection';
import DealExpiringSoon from '@/pages/promotions/components/DealExpiringSoon';
import { OFFERS } from '@/mocks/promotions';

const caseStudySchema = {
  '@context': 'https://schema.org',
  '@type': 'ItemList',
  name: 'Roofing Case Studies — Corner Stone Construction & Roofing',
  description: 'Real roofing project case studies from Evansville IN, Newburgh, Henderson KY, and the Tri-State area. Residential, commercial, storm damage, and insurance claim projects with full before and after documentation.',
  numberOfItems: caseStudies.length,
  itemListElement: caseStudies.map((study, i) => ({
    '@type': 'ListItem',
    position: i + 1,
    name: `${study.title} — ${study.location}`,
    url: `https://cornerstoneconstructionevansville.com/case-studies`,
  })),
};

type FilterKey = 'All' | 'Residential' | 'Commercial' | 'Repair' | 'Multi-Family';

export default function CaseStudies() {
  const navigate = useNavigate();
  const [activeFilter, setActiveFilter] = useState<FilterKey>('All');

  const filtered = activeFilter === 'All'
    ? caseStudies
    : caseStudies.filter((s) => s.type === activeFilter);

  const featured = filtered.filter((s) => s.featured);
  const rest = filtered.filter((s) => !s.featured);

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roofing Case Studies Evansville Indiana | Corner Stone Construction"
        description="Real roofing project case studies from Corner Stone Construction & Roofing in Evansville Indiana. See before and after transformations, insurance claim wins, commercial projects, and storm damage restorations across the Tri-State area."
        keywords="roofing case studies Evansville Indiana, roof replacement case study, storm damage restoration before after, commercial roofing case study Indiana, insurance claim roofing case study, residential roofing transformation Evansville"
        canonical="/case-studies"
        schema={caseStudySchema}
      />

      <CaseStudyHero />

      {/* Featured Studies */}
      {featured.length > 0 && (
        <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center gap-3 mb-10">
              <div className="w-1 h-8 bg-orange flex-shrink-0" />
              <div>
                <p className="text-orange text-xs font-bold uppercase tracking-[0.25em]">Featured Projects</p>
                <p className="text-white/40 text-xs mt-0.5">Our most impactful transformations</p>
              </div>
            </div>
            <div className="space-y-10 md:space-y-14">
              {featured.map((study, i) => (
                <CaseStudyCard key={study.id} study={study} index={i} />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* All Studies */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-10">
            <div>
              <p className="text-orange text-xs font-bold uppercase tracking-[0.25em] mb-2">All Projects</p>
              <h2 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wider leading-none">
                Every Project. Every Detail.
              </h2>
            </div>
            <CaseStudyFilter active={activeFilter} onChange={setActiveFilter} />
          </div>

          {rest.length > 0 ? (
            <div className="space-y-10 md:space-y-14">
              {rest.map((study, i) => (
                <CaseStudyCard key={study.id} study={study} index={i} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <i className="ri-folder-open-line text-white/20 text-5xl mb-4 block" />
              <p className="text-white/30 text-sm">No projects in this category yet.</p>
              <button
                onClick={() => setActiveFilter('All')}
                className="text-orange text-sm mt-3 hover:underline cursor-pointer"
              >
                View all projects
              </button>
            </div>
          )}
        </div>
      </section>

      {/* By the Numbers */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal-deep border-y border-white/5">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-3">Results That Speak</p>
            <h2 className="font-display text-white uppercase tracking-wider text-2xl md:text-3xl">
              The Numbers Behind the Stories
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-6">
            {[
              {
                icon: 'ri-home-4-line',
                stat: '2,500+',
                label: 'Roofs Completed',
                desc: 'From historic craftsman homes to 48-unit apartment complexes across Indiana and Kentucky.',
                image: '/placeholders/600x400.svg',
              },
              {
                icon: 'ri-shield-check-line',
                stat: '94%',
                label: 'Insurance Claims Approved',
                desc: 'Of the claims we handle get approved on the first submission — saving homeowners months of appeals.',
                image: '/placeholders/600x400.svg',
              },
              {
                icon: 'ri-star-fill',
                stat: '4.9★',
                label: 'Average Google Rating',
                desc: 'Maintained across 300+ verified reviews from real customers in the Tri-State area.',
                image: '/placeholders/600x400.svg',
              },
            ].map((item) => (
              <div key={item.label} className="group bg-charcoal-mid border border-white/5 hover:border-orange/20 transition-all duration-300 overflow-hidden">
                <div className="relative h-48 overflow-hidden">
                  <img src={item.image} alt={item.label} className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-charcoal-mid via-charcoal-mid/30 to-transparent" />
                </div>
                <div className="p-6 md:p-7">
                  <div className="w-10 h-10 flex items-center justify-center bg-orange/15 text-orange mb-4">
                    <i className={`${item.icon} text-lg`} />
                  </div>
                  <p className="font-display text-orange text-3xl md:text-4xl uppercase tracking-wider mb-1">{item.stat}</p>
                  <p className="text-white font-semibold text-sm uppercase tracking-wider mb-3">{item.label}</p>
                  <p className="text-white/40 text-sm leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <WhyTrustSection />

      {/* Related Pages */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal-deep">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-3">Explore More</p>
            <h2 className="font-display text-white uppercase tracking-wider text-2xl md:text-3xl">
              Other Ways to See Our Work
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
            {[
              {
                icon: 'ri-image-2-line',
                title: 'Before & After Gallery',
                desc: 'Interactive sliders comparing real transformations.',
                link: '/before-after',
              },
              {
                icon: 'ri-folder-3-line',
                title: 'Full Project Portfolio',
                desc: 'Browse all completed projects by category.',
                link: '/projects',
              },
              {
                icon: 'ri-chat-quote-line',
                title: 'Customer Reviews',
                desc: '300+ five-star reviews from real customers.',
                link: '/testimonials',
              },
              {
                icon: 'ri-home-gear-line',
                title: 'Compare Materials',
                desc: 'Side-by-side cost, lifespan, and warranty guide.',
                link: '/roof-comparison',
              },
            ].map((card) => (
              <button
                key={card.title}
                onClick={() => navigate(card.link)}
                className="text-left bg-charcoal-mid border border-white/5 hover:border-orange/20 transition-all duration-300 p-6 md:p-7 group cursor-pointer"
              >
                <div className="w-10 h-10 flex items-center justify-center bg-orange/15 text-orange mb-4 group-hover:bg-orange/25 transition-colors">
                  <i className={`${card.icon} text-lg`} />
                </div>
                <h3 className="font-display text-white text-base uppercase tracking-wider mb-2">{card.title}</h3>
                <p className="text-white/40 text-sm leading-relaxed mb-4">{card.desc}</p>
                <span className="text-orange text-xs font-semibold uppercase tracking-wider flex items-center gap-1 group-hover:gap-2 transition-all">
                  Explore
                  <i className="ri-arrow-right-line" />
                </span>
              </button>
            ))}
          </div>
        </div>
      </section>

      <CaseStudyCTA />

      <DealExpiringSoon offers={OFFERS} linkToPage="/promotions" />
    </div>
  );
}