import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const NEXT_STEPS = [
  {
    icon: 'ri-mail-check-line',
    title: 'Check Your Inbox',
    desc: 'Your PDF should arrive within 2 minutes. If you don\'t see it, check your spam or promotions folder.',
    time: 'Now',
  },
  {
    icon: 'ri-file-list-3-line',
    title: 'Review the Guide',
    desc: 'Skim the 18 pages to get a real sense of what your roof replacement will cost based on your home and material preference.',
    time: '5 min',
  },
  {
    icon: 'ri-phone-line',
    title: 'Get Your Exact Quote',
    desc: 'The guide gives you a ballpark. A free inspection gives you the exact number — no obligation, no pressure.',
    time: '24h',
  },
];

const SERVICE_CARDS = [
  {
    icon: 'ri-search-eye-line',
    title: 'Free Roof Inspection',
    desc: 'Our certified inspector checks every inch — shingles, flashing, gutters, and decking. Full photo report included.',
    cta: 'Book Now',
    link: '/free-inspection',
    highlight: true,
  },
  {
    icon: 'ri-calculator-line',
    title: 'Get a Free Estimate',
    desc: 'Already know what you need? Submit your project details and we\'ll respond with an itemized quote within 24 hours.',
    cta: 'Get Estimate',
    link: '/estimate',
    highlight: false,
  },
  {
    icon: 'ri-thunderstorms-line',
    title: 'Storm Damage Help',
    desc: 'Suspect hail or wind damage? We document everything for your insurance claim and meet the adjuster on-site.',
    cta: 'Get Help',
    link: '/storm-damage',
    highlight: false,
  },
  {
    icon: 'ri-home-gear-line',
    title: 'Compare Materials',
    desc: 'Not sure if asphalt, metal, tile, or slate is right for your home? Side-by-side cost, lifespan, and warranty breakdown.',
    cta: 'Compare Now',
    link: '/roof-comparison',
    highlight: false,
  },
  {
    icon: 'ri-bank-card-line',
    title: 'Explore Financing',
    desc: '$0 down options, low monthly payments, and 0% interest plans available. Pre-qualify without hurting your credit.',
    cta: 'See Options',
    link: '/roof-financing',
    highlight: false,
  },
  {
    icon: 'ri-file-shield-line',
    title: 'Insurance Claims',
    desc: 'We handle the paperwork, meet your adjuster, and make sure you get the full payout your policy covers.',
    cta: 'Learn More',
    link: '/insurance-claims',
    highlight: false,
  },
];

const TRUST_SIGNALS = [
  { icon: 'ri-shield-check-line', label: 'Licensed & Insured', sub: 'Indiana & Kentucky' },
  { icon: 'ri-award-line', label: 'A+ BBB Rating', sub: 'Since 2010' },
  { icon: 'ri-star-fill', label: '4.9 Google Rating', sub: '287+ Reviews' },
  { icon: 'ri-time-line', label: 'Since 1995', sub: '30+ Years Local' },
  { icon: 'ri-group-line', label: '2,500+ Roofs', sub: 'Across Tri-State' },
  { icon: 'ri-customer-service-line', label: '5-Year Workmanship', sub: 'Warranty on All Jobs' },
];

const FAQS = [
  {
    q: 'How long until I receive the guide?',
    a: 'It should hit your inbox within 2 minutes. If you don\'t see it, check your spam or promotions folder. Still nothing? Call us at 812-213-5997 and we\'ll send it manually.',
  },
  {
    q: 'Is the pricing in the guide accurate?',
    a: 'Yes — the guide reflects real Evansville and Tri-State pricing from 2025–2026 projects. Costs vary based on roof complexity, pitch, and material grade, but the ranges are honest and up-to-date.',
  },
  {
    q: 'Will I get sales calls after downloading?',
    a: 'No pressure. We may send one follow-up email to ask if the guide was helpful and offer a free inspection — but you can unsubscribe anytime and we never share your info.',
  },
  {
    q: 'Can I share this guide with my neighbor or realtor?',
    a: 'Absolutely. Forward it to anyone who might find it useful. The more informed Evansville homeowners are, the better decisions they make.',
  },
  {
    q: 'What if I need help understanding the numbers?',
    a: 'That\'s exactly why we offer free inspections. A 20-minute visit from our inspector gives you exact numbers for your specific roof — no guesswork needed.',
  },
];

const REVIEW_SNIPPETS = [
  { text: "The estimate was exactly what the guide said it would be. No surprises, no hidden fees. Corner Stone is the real deal.", name: "Jennifer K.", location: "Evansville, IN", rating: 5 },
  { text: "I downloaded the cost guide before calling anyone. When Corner Stone came out, their quote lined up perfectly. Made the decision easy.", name: "Marcus T.", location: "Newburgh, IN", rating: 5 },
  { text: "The guide helped me understand why my metal roof quote was higher than my neighbor's asphalt quote. Worth the 5 minutes to read.", name: "Angela R.", location: "Henderson, KY", rating: 5 },
];

export default function GuideSentPage() {
  const navigate = useNavigate();
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const hero = useScrollAnimation();
  const steps = useScrollAnimation({ threshold: 0.1 });
  const services = useScrollAnimation({ threshold: 0.05 });
  const trust = useScrollAnimation({ threshold: 0.1 });
  const reviews = useScrollAnimation({ threshold: 0.1 });
  const faq = useScrollAnimation({ threshold: 0.05 });

  useEffect(() => {
    if (typeof window !== 'undefined' && (window as unknown as Record<string, unknown>).gtag) {
      (window as unknown as Record<string, (...args: unknown[]) => void>).gtag('event', 'conversion', {
        event_category: 'lead_magnet',
        event_label: 'guide_download_success',
      });
    }
  }, []);

  return (
    <div className="min-h-screen bg-warm-beige">
      <PageSEO
        title="Your Roof Cost Guide is on the Way | Corner Stone Construction & Roofing"
        description="Thank you for downloading the 2026 Roof Replacement Cost Guide. Check your inbox for the PDF. Next steps, related services, and FAQs inside."
        keywords="roof cost guide download, Evansville roofing PDF, free roof cost estimate guide"
        canonical="/guide-sent"
      />

      {/* HERO — Success confirmation */}
      <section className="relative bg-charcoal-deep pt-32 pb-16 md:pb-24 overflow-hidden">
        <div className="absolute inset-0 opacity-[0.02]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '60px 60px' }} />
        <div className="absolute -top-40 -right-40 w-[500px] h-[500px] rounded-full opacity-10" style={{ background: 'radial-gradient(circle, #e8621a 0%, transparent 70%)' }} />

        <div className="relative z-10 w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <div
              ref={hero.ref as React.RefObject<HTMLDivElement>}
              className={`anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
            >
              {/* Animated success ring */}
              <div className="relative w-20 h-20 mx-auto mb-8">
                <div className="absolute inset-0 rounded-full bg-green-500/20 animate-ping" />
                <div className="relative w-20 h-20 flex items-center justify-center bg-green-500/15 rounded-full">
                  <i className="ri-mail-check-fill text-green-400 text-4xl" />
                </div>
              </div>

              <div className="inline-flex items-center gap-2 bg-orange/15 border border-orange/30 px-4 py-2 mb-6">
                <i className="ri-checkbox-circle-line text-orange text-sm" />
                <span className="text-orange text-xs font-bold uppercase tracking-[0.2em]">Download Confirmed</span>
              </div>

              <h1 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
                Your Guide Is<br />
                <span className="text-orange">On the Way!</span>
              </h1>

              <p className="text-white/50 text-base md:text-lg leading-relaxed max-w-xl mx-auto mb-4">
                The <strong className="text-white">2026 Roof Replacement Cost Guide</strong> has been sent to your inbox. It should arrive within the next 2 minutes.
              </p>

              <p className="text-white/30 text-sm mb-8">
                Didn't see it? Check your spam or promotions folder, or <button onClick={() => window.location.reload()} className="text-orange hover:text-orange-light underline underline-offset-4 cursor-pointer">request it again</button>.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <button
                  onClick={() => navigate('/free-inspection')}
                  className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-calendar-check-line" />
                  Book Free Inspection
                </button>
                <a
                  href="tel:8122135997"
                  className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-phone-line" />
                  Call 812-213-5997
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* NEXT STEPS */}
      <section className="py-14 md:py-20 bg-white">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-5xl mx-auto">
            <div
              ref={steps.ref as React.RefObject<HTMLDivElement>}
              className={`text-center mb-12 anim-fade-up ${steps.isVisible ? 'is-visible' : ''}`}
            >
              <p className="text-orange text-xs font-semibold uppercase tracking-[0.25em] mb-3">What Happens Next</p>
              <h2 className="font-display text-charcoal uppercase tracking-wider text-2xl md:text-3xl">
                Three Simple Steps to a New Roof
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
              {NEXT_STEPS.map((step, i) => (
                <div
                  key={step.title}
                  className={`relative border border-charcoal/10 p-6 md:p-8 anim-fade-up ${steps.isVisible ? 'is-visible' : ''}`}
                  style={{ transitionDelay: `${i * 100}ms` }}
                >
                  {/* Step number badge */}
                  <div className="absolute -top-3 left-6 bg-orange text-white text-xs font-bold uppercase tracking-wider px-3 py-1">
                    Step {i + 1}
                  </div>
                  <div className="w-10 h-10 flex items-center justify-center bg-orange/10 rounded-md mb-4 mt-2">
                    <i className={`${step.icon} text-orange text-lg`} />
                  </div>
                  <h3 className="font-display text-charcoal text-lg uppercase tracking-wider mb-2">{step.title}</h3>
                  <p className="text-charcoal/50 text-sm leading-relaxed mb-4">{step.desc}</p>
                  <span className="inline-block text-orange text-xs font-semibold uppercase tracking-wider">
                    <i className="ri-time-line mr-1" />
                    {step.time}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* SERVICE CARDS — The real CTAs */}
      <section className="py-14 md:py-20 bg-warm-beige">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-5xl mx-auto">
            <div
              ref={services.ref as React.RefObject<HTMLDivElement>}
              className={`text-center mb-12 anim-fade-up ${services.isVisible ? 'is-visible' : ''}`}
            >
              <p className="text-orange text-xs font-semibold uppercase tracking-[0.25em] mb-3">While You Wait</p>
              <h2 className="font-display text-charcoal uppercase tracking-wider text-2xl md:text-3xl mb-3">
                Ready to Take the Next Step?
              </h2>
              <p className="text-charcoal/50 text-base max-w-lg mx-auto">
                The guide is great for budgeting. But nothing beats a real inspection and exact quote. Here are the best ways to move forward:
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
              {SERVICE_CARDS.map((card, i) => (
                <div
                  key={card.title}
                  className={`relative p-6 md:p-7 anim-fade-up ${services.isVisible ? 'is-visible' : ''} ${
                    card.highlight
                      ? 'bg-charcoal-deep border border-orange/30'
                      : 'bg-white border border-charcoal/10'
                  }`}
                  style={{ transitionDelay: `${i * 60}ms` }}
                >
                  {card.highlight && (
                    <div className="absolute -top-3 left-6 bg-orange text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1">
                      Most Popular
                    </div>
                  )}
                  <div className={`w-10 h-10 flex items-center justify-center rounded-md mb-4 ${card.highlight ? 'bg-orange/15' : 'bg-orange/10'}`}>
                    <i className={`${card.icon} text-orange text-lg`} />
                  </div>
                  <h3 className={`font-display text-lg uppercase tracking-wider mb-2 ${card.highlight ? 'text-white' : 'text-charcoal'}`}>
                    {card.title}
                  </h3>
                  <p className={`text-sm leading-relaxed mb-5 ${card.highlight ? 'text-white/50' : 'text-charcoal/50'}`}>
                    {card.desc}
                  </p>
                  <button
                    onClick={() => navigate(card.link)}
                    className={`inline-flex items-center gap-2 text-sm font-semibold uppercase tracking-wider transition-colors cursor-pointer whitespace-nowrap ${
                      card.highlight
                        ? 'text-orange hover:text-white'
                        : 'text-orange hover:text-orange-dark'
                    }`}
                  >
                    {card.cta}
                    <i className="ri-arrow-right-line" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* TRUST SIGNALS STRIP */}
      <section className="py-12 md:py-16 bg-charcoal">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div
            ref={trust.ref as React.RefObject<HTMLDivElement>}
            className={`max-w-5xl mx-auto anim-fade-up ${trust.isVisible ? 'is-visible' : ''}`}
          >
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 md:gap-8">
              {TRUST_SIGNALS.map((signal) => (
                <div key={signal.label} className="text-center">
                  <div className="w-10 h-10 flex items-center justify-center bg-white/5 rounded-full mx-auto mb-3">
                    <i className={`${signal.icon} text-orange text-lg`} />
                  </div>
                  <p className="text-white font-semibold text-sm mb-1">{signal.label}</p>
                  <p className="text-white/40 text-xs">{signal.sub}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* REVIEW SNIPPETS */}
      <section className="py-14 md:py-20 bg-white">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-4xl mx-auto">
            <div
              ref={reviews.ref as React.RefObject<HTMLDivElement>}
              className={`text-center mb-10 anim-fade-up ${reviews.isVisible ? 'is-visible' : ''}`}
            >
              <p className="text-orange text-xs font-semibold uppercase tracking-[0.25em] mb-3">What Homeowners Say</p>
              <h2 className="font-display text-charcoal uppercase tracking-wider text-2xl md:text-3xl">
                Real Reviews from Real Customers
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-5">
              {REVIEW_SNIPPETS.map((review, i) => (
                <div
                  key={review.name}
                  className={`border border-charcoal/10 p-6 anim-fade-up ${reviews.isVisible ? 'is-visible' : ''}`}
                  style={{ transitionDelay: `${i * 100}ms` }}
                >
                  <div className="flex gap-0.5 mb-3">
                    {Array.from({ length: review.rating }).map((_, j) => (
                      <i key={j} className="ri-star-fill text-orange text-sm" />
                    ))}
                  </div>
                  <p className="text-charcoal/60 text-sm leading-relaxed italic mb-4">"{review.text}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 flex items-center justify-center bg-orange/10 text-orange text-xs font-bold rounded-full">
                      {review.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <p className="text-charcoal text-xs font-semibold">{review.name}</p>
                      <p className="text-charcoal/40 text-xs">{review.location}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-center mt-8">
              <button
                onClick={() => navigate('/testimonials')}
                className="inline-flex items-center gap-2 text-orange hover:text-orange-dark text-sm font-semibold uppercase tracking-wider transition-colors cursor-pointer whitespace-nowrap"
              >
                Read All 287+ Reviews
                <i className="ri-arrow-right-line" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-14 md:py-20 bg-warm-beige">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-3xl mx-auto">
            <div
              ref={faq.ref as React.RefObject<HTMLDivElement>}
              className={`text-center mb-10 anim-fade-up ${faq.isVisible ? 'is-visible' : ''}`}
            >
              <p className="text-orange text-xs font-semibold uppercase tracking-[0.25em] mb-3">Quick Answers</p>
              <h2 className="font-display text-charcoal uppercase tracking-wider text-2xl md:text-3xl">
                Questions About Your Guide
              </h2>
            </div>

            <div className="space-y-3">
              {FAQS.map((item, i) => (
                <div
                  key={i}
                  className={`bg-white border border-charcoal/10 anim-fade-up ${faq.isVisible ? 'is-visible' : ''}`}
                  style={{ transitionDelay: `${i * 60}ms` }}
                >
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full flex items-center justify-between p-5 md:p-6 text-left gap-4 cursor-pointer group"
                  >
                    <h3 className={`font-semibold text-sm md:text-base transition-colors ${openFaq === i ? 'text-orange' : 'text-charcoal group-hover:text-charcoal/80'}`}>
                      {item.q}
                    </h3>
                    <div className={`w-7 h-7 flex-shrink-0 flex items-center justify-center border transition-all duration-300 ${openFaq === i ? 'border-orange bg-orange text-white rotate-45' : 'border-charcoal/20 text-charcoal/40'}`}>
                      <i className="ri-add-line text-xs" />
                    </div>
                  </button>
                  <div className={`overflow-hidden transition-all duration-500 ${openFaq === i ? 'max-h-48' : 'max-h-0'}`}>
                    <p className="text-charcoal/50 text-sm leading-relaxed px-5 md:px-6 pb-5 md:pb-6">
                      {item.a}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="py-16 md:py-20 bg-charcoal-deep">
        <div className="w-full px-4 md:px-8 lg:px-12">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-display text-white text-3xl md:text-4xl uppercase tracking-wider mb-4">
              The Best Next Step? A Free Inspection.
            </h2>
            <p className="text-white/50 text-base md:text-lg leading-relaxed mb-8 max-w-xl mx-auto">
              The guide gives you the big picture. A 20-minute inspection gives you the exact picture — your roof, your numbers, your timeline. No pressure, no obligation.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => navigate('/free-inspection')}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-12 py-4 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-calendar-check-line" />
                Schedule Free Inspection
              </button>
              <a
                href="tel:8122135997"
                className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-12 py-4 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-phone-line" />
                Call 812-213-5997
              </a>
            </div>
            <p className="text-white/20 text-xs mt-6">
              Mon–Sat 7am–7pm · Emergency line available 24/7
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}