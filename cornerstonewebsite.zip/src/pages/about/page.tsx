import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import PageSEO from '@/components/feature/PageSEO';
import DealExpiringSoon from '@/pages/promotions/components/DealExpiringSoon';

const aboutSchema = {
  '@context': 'https://schema.org',
  '@type': 'AboutPage',
  name: 'About Corner Stone Construction & Roofing',
  description: 'Family-owned roofing contractor in Evansville Indiana since 1995. 29 years of experience, 2400+ roofs completed, GAF Master Elite and Owens Corning Platinum Preferred certified.',
  url: 'https://cornerstoneconstructionevansville.com/about',
  mainEntity: {
    '@type': 'RoofingContractor',
    name: 'Corner Stone Construction & Roofing',
    foundingDate: '1995',
    founder: { '@type': 'Person', name: 'Mike Cornett' },
    numberOfEmployees: { '@type': 'QuantitativeValue', value: 30 },
    telephone: '+1-812-213-5997',
    address: {
      '@type': 'PostalAddress',
      streetAddress: '5800 Kansas Rd',
      addressLocality: 'Evansville',
      addressRegion: 'IN',
      postalCode: '47725',
      addressCountry: 'US',
    },
    aggregateRating: {
      '@type': 'AggregateRating',
      ratingValue: '4.9',
      reviewCount: '287',
    },
  },
};

const timeline = [
  {
    year: '1995',
    title: 'Founded in Evansville',
    desc: 'Mike Cornett started Corner Stone out of the back of a pickup truck with two employees and a simple promise: show up on time, do it right, and treat every home like your own.',
    icon: 'ri-home-4-line',
    milestone: 'Year One',
  },
  {
    year: '1999',
    title: 'First Commercial Contract',
    desc: 'Landed our first major commercial roofing contract — a 40,000 sq ft warehouse in Evansville. Proved we could scale without sacrificing quality.',
    icon: 'ri-building-4-line',
    milestone: '4 Years In',
  },
  {
    year: '2003',
    title: 'GAF Certification Earned',
    desc: 'Became a GAF Certified Contractor — one of the first in Vanderburgh County. This unlocked enhanced warranties and manufacturer-backed guarantees for our customers.',
    icon: 'ri-award-line',
    milestone: '8 Years In',
  },
  {
    year: '2008',
    title: 'Expanded to Kentucky',
    desc: 'Opened service to Henderson, KY and surrounding counties. The Tri-State area needed a roofer they could trust — we answered the call.',
    icon: 'ri-map-pin-2-line',
    milestone: '13 Years In',
  },
  {
    year: '2011',
    title: 'Insurance Claims Division',
    desc: 'After the devastating 2011 storm season, we formalized our insurance claims process. We hired a dedicated claims specialist and began meeting adjusters on-site for every storm job.',
    icon: 'ri-shield-check-line',
    milestone: '16 Years In',
  },
  {
    year: '2015',
    title: '1,000 Roofs Milestone',
    desc: 'Completed our 1,000th roof installation. Celebrated with the team and the community that made it possible. Still the same crew, same values.',
    icon: 'ri-trophy-line',
    milestone: '20 Years In',
  },
  {
    year: '2018',
    title: 'Metal Roofing Division',
    desc: 'Launched a dedicated metal roofing division with specialized crews trained in standing seam and corrugated systems. Now one of the top metal roofers in the Tri-State area.',
    icon: 'ri-tools-line',
    milestone: '23 Years In',
  },
  {
    year: '2021',
    title: 'Owens Corning Platinum Preferred',
    desc: 'Achieved Owens Corning Platinum Preferred Contractor status — the highest tier available. Only the top 1% of roofing contractors in the country earn this designation.',
    icon: 'ri-medal-line',
    milestone: '26 Years In',
  },
  {
    year: '2024',
    title: '2,400+ Roofs & 4.9 Stars',
    desc: 'Crossed 2,400 completed roofs and maintained a 4.9-star Google rating across 300+ reviews. Still family-owned, still Evansville-based, still doing it the right way.',
    icon: 'ri-star-line',
    milestone: '29 Years In',
  },
];

const team = [
  {
    name: 'Mike Cornett',
    role: 'Founder & Owner',
    bio: '29 years in roofing. Started Corner Stone with a handshake and a work ethic. Still on job sites every week.',
    img: '/placeholders/400x480.svg',
    certs: ['GAF Master Elite', 'OSHA 30-Hour'],
  },
  {
    name: 'Jason Cornett',
    role: 'Operations Manager',
    bio: 'Mike\'s son. Grew up on job sites and now runs day-to-day operations, scheduling, and crew management.',
    img: '/placeholders/400x480.svg',
    certs: ['Owens Corning Certified', 'OSHA 10-Hour'],
  },
  {
    name: 'Dave Holloway',
    role: 'Lead Insurance Claims Specialist',
    bio: '12 years handling storm damage claims. Has recovered over $2.4M for homeowners across Indiana and Kentucky.',
    img: '/placeholders/400x480.svg',
    certs: ['Xactimate Certified', 'Public Adjuster Liaison'],
  },
  {
    name: 'Sarah Mitchell',
    role: 'Customer Relations Manager',
    bio: 'The voice you hear when you call. Sarah has been with Corner Stone for 11 years and knows every customer by name.',
    img: '/placeholders/400x480.svg',
    certs: ['BBB Accredited Business Rep'],
  },
  {
    name: 'Tony Reyes',
    role: 'Lead Crew Foreman',
    bio: '18 years installing roofs. Tony leads our largest residential crew and has personally installed over 600 roofs.',
    img: '/placeholders/400x480.svg',
    certs: ['GAF Certified Installer', 'OSHA 30-Hour'],
  },
  {
    name: 'Chris Walton',
    role: 'Commercial Roofing Specialist',
    bio: 'Leads all commercial projects. Has completed over 80 commercial roofs including warehouses, retail centers, and schools.',
    img: '/placeholders/400x480.svg',
    certs: ['TPO Certified', 'EPDM Specialist', 'OSHA 30-Hour'],
  },
];

const certifications = [
  {
    name: 'GAF Master Elite Contractor',
    desc: 'Only the top 3% of roofing contractors in the US earn this designation. Unlocks the Golden Pledge Lifetime Warranty.',
    icon: 'ri-award-line',
    color: 'text-amber-500',
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/20',
  },
  {
    name: 'Owens Corning Platinum Preferred',
    desc: 'The highest tier in the Owens Corning contractor program. Top 1% nationally. Enhanced warranty coverage for customers.',
    icon: 'ri-medal-line',
    color: 'text-orange',
    bg: 'bg-orange/10',
    border: 'border-orange/20',
  },
  {
    name: 'CertainTeed SELECT ShingleMaster',
    desc: 'Certified installer for CertainTeed\'s full product line. Qualifies customers for the SureStart PLUS warranty.',
    icon: 'ri-shield-star-line',
    color: 'text-green-500',
    bg: 'bg-green-500/10',
    border: 'border-green-500/20',
  },
  {
    name: 'Atlas Signature Select Contractor',
    desc: 'Certified for Atlas roofing systems with access to the Pinnacle Pristine and StormMaster product lines.',
    icon: 'ri-verified-badge-line',
    color: 'text-amber-400',
    bg: 'bg-amber-400/10',
    border: 'border-amber-400/20',
  },
  {
    name: 'BBB A+ Accredited Business',
    desc: 'Accredited by the Better Business Bureau with an A+ rating. Zero unresolved complaints in 29 years.',
    icon: 'ri-thumb-up-line',
    color: 'text-orange',
    bg: 'bg-orange/10',
    border: 'border-orange/20',
  },
  {
    name: 'Indiana Licensed & Insured',
    desc: 'Fully licensed in Indiana and Kentucky. $2M general liability coverage and full workers\' compensation insurance.',
    icon: 'ri-file-shield-2-line',
    color: 'text-green-400',
    bg: 'bg-green-400/10',
    border: 'border-green-400/20',
  },
];

const values = [
  {
    icon: 'ri-shake-hands-line',
    title: 'Honesty First',
    desc: 'We tell you what your roof actually needs — not what makes us the most money. If a repair will do, we\'ll say so.',
  },
  {
    icon: 'ri-home-heart-line',
    title: 'Your Home, Our Standard',
    desc: 'We treat every house like it\'s our own. That means daily cleanup, careful landscaping protection, and zero shortcuts.',
  },
  {
    icon: 'ri-community-line',
    title: 'Evansville Is Home',
    desc: 'We live here, our kids go to school here, and we\'re invested in this community. That\'s not marketing — it\'s just true.',
  },
  {
    icon: 'ri-time-line',
    title: 'We Show Up',
    desc: 'On time, every time. If something changes, you hear from us first — not after you\'ve been waiting all morning.',
  },
];

function TimelineItem({ item, index }: { item: typeof timeline[0]; index: number }) {
  const anim = useScrollAnimation({ threshold: 0.15 });
  const isLeft = index % 2 === 0;

  return (
    <div
      ref={anim.ref as React.RefObject<HTMLDivElement>}
      className={`relative grid grid-cols-1 lg:grid-cols-[1fr_auto_1fr] gap-0 anim-fade-up ${anim.isVisible ? 'is-visible' : ''}`}
      style={{ transitionDelay: `${(index % 3) * 100}ms` }}
    >
      {/* Left content (desktop) */}
      <div className={`hidden lg:flex ${isLeft ? 'justify-end pr-12' : 'justify-start pl-12 order-3'}`}>
        {isLeft && (
          <div className="max-w-sm text-right pb-12">
            <span className="text-orange text-xs font-bold uppercase tracking-widest">{item.milestone}</span>
            <h3 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider mt-1 mb-3">{item.title}</h3>
            <p className="text-white/60 text-sm leading-relaxed">{item.desc}</p>
          </div>
        )}
        {!isLeft && (
          <div className="max-w-sm text-left pb-12">
            <span className="text-orange text-xs font-bold uppercase tracking-widest">{item.milestone}</span>
            <h3 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider mt-1 mb-3">{item.title}</h3>
            <p className="text-white/60 text-sm leading-relaxed">{item.desc}</p>
          </div>
        )}
      </div>

      {/* Center spine */}
      <div className="hidden lg:flex flex-col items-center order-2">
        <div className="w-14 h-14 flex items-center justify-center bg-orange border-4 border-charcoal-deep z-10 flex-shrink-0">
          <i className={`${item.icon} text-white text-lg`} />
        </div>
        <div className="flex-1 w-px bg-white/10 min-h-[3rem]" />
        <div className="bg-charcoal border border-white/20 px-3 py-1 mb-2">
          <span className="font-display text-orange text-lg tracking-wider">{item.year}</span>
        </div>
        <div className="flex-1 w-px bg-white/10 min-h-[3rem]" />
      </div>

      {/* Right placeholder (desktop) */}
      <div className={`hidden lg:block ${isLeft ? 'order-3' : 'order-1'}`} />

      {/* Mobile layout */}
      <div className="lg:hidden flex gap-5 pb-10 pl-2">
        <div className="flex flex-col items-center flex-shrink-0">
          <div className="w-10 h-10 flex items-center justify-center bg-orange flex-shrink-0">
            <i className={`${item.icon} text-white text-sm`} />
          </div>
          <div className="flex-1 w-px bg-white/10 mt-2" />
        </div>
        <div className="pb-4">
          <div className="flex items-center gap-3 mb-2">
            <span className="font-display text-orange text-xl tracking-wider">{item.year}</span>
            <span className="text-white/50 text-xs uppercase tracking-widest">{item.milestone}</span>
          </div>
          <h3 className="font-display text-white text-lg uppercase tracking-wider mb-2">{item.title}</h3>
          <p className="text-white/60 text-sm leading-relaxed">{item.desc}</p>
        </div>
      </div>
    </div>
  );
}

export default function AboutPage() {
  const navigate = useNavigate();
  const heroAnim = useScrollAnimation();
  const storyAnim = useScrollAnimation({ threshold: 0.1 });
  const valuesAnim = useScrollAnimation({ threshold: 0.05 });
  const certsAnim = useScrollAnimation({ threshold: 0.05 });
  const teamAnim = useScrollAnimation({ threshold: 0.05 });
  const ctaAnim = useScrollAnimation({ threshold: 0.1 });

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="About Corner Stone Construction & Roofing | Evansville Indiana Since 1995"
        description="Family-owned roofing contractor in Evansville Indiana since 1995. 29 years of experience, 2,400+ roofs completed, GAF Master Elite & Owens Corning Platinum Preferred certified. Meet the team behind the Tri-State's most trusted roofer."
        keywords="about Corner Stone roofing Evansville, family owned roofing contractor Indiana, GAF Master Elite Evansville, Owens Corning Platinum Preferred Indiana, roofing company history Evansville"
        canonical="/about"
        schema={aboutSchema}
      />

      {/* ── Hero ── */}
      <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1600x900.svg"
            alt="Corner Stone Construction & Roofing team — Evansville Indiana"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-charcoal-deep" />
        </div>
        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 text-center anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs md:text-sm font-semibold tracking-[0.25em] uppercase mb-5">
            Evansville, Indiana — Est. 1995
          </p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 8vw, 7rem)' }}>
            29 Years.<br />One Standard.<br /><span className="text-orange">No Shortcuts.</span>
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-2xl mx-auto leading-relaxed mb-10">
            We are a family-owned roofing company that has been protecting homes and businesses across the Tri-State area since 1995. Same values, same crew, same commitment — just a lot more roofs under our belt.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigate('/estimate')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              Get a Free Estimate
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/30 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>
      </section>

      {/* ── Stats Bar ── */}
      <section className="bg-charcoal border-y border-white/10 py-10 md:py-14 px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
          {[
            { value: '1995', label: 'Year Founded', sub: 'Family-owned since day one' },
            { value: '2,400+', label: 'Roofs Completed', sub: 'Homes & commercial buildings' },
            { value: '4.9★', label: 'Google Rating', sub: '300+ verified reviews' },
            { value: 'A+', label: 'BBB Rating', sub: 'Zero unresolved complaints' },
          ].map((stat, i) => (
            <div key={stat.label} className={`anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`} style={{ transitionDelay: `${i * 100}ms` }}>
              <p className="font-display text-orange text-4xl md:text-5xl uppercase tracking-wider mb-1">{stat.value}</p>
              <p className="text-white text-xs font-semibold uppercase tracking-wider mb-0.5">{stat.label}</p>
              <p className="text-white/50 text-xs">{stat.sub}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Company Story ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div
          ref={storyAnim.ref as React.RefObject<HTMLDivElement>}
          className={`grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-20 items-center anim-fade-up ${storyAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="relative">
            <img
              src="/placeholders/800x600.svg"
              alt="Corner Stone founding story 1995"
              className="w-full h-80 md:h-[480px] object-cover object-top"
            />
            <div className="absolute bottom-6 left-6 bg-orange px-6 py-4">
              <p className="font-display text-white text-3xl tracking-wider leading-none">1995</p>
              <p className="text-white/80 text-xs uppercase tracking-widest mt-1">Where It All Started</p>
            </div>
            <div className="absolute -bottom-6 -right-6 hidden md:block w-48 h-48 border border-orange/20" />
          </div>

          <div>
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Our Story</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-8" style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
              Started With a<br />Pickup Truck and<br /><span className="text-orange">A Promise</span>
            </h2>
            <div className="space-y-5 text-white/50 text-sm md:text-base leading-relaxed">
              <p>
                In 1995, Mike Cornett started Corner Stone Construction & Roofing with two employees, a used pickup truck, and a simple belief: if you do honest work at a fair price and treat people right, the rest takes care of itself.
              </p>
              <p>
                Twenty-nine years later, that belief still drives everything we do. We have grown from a two-man crew to a team of 30+ certified professionals, but the core has never changed. We are still family-owned, still Evansville-based, and still showing up to every job like it is the most important one we have ever done.
              </p>
              <p>
                We have weathered Indiana's worst storm seasons, helped hundreds of homeowners navigate insurance claims, and built a reputation that we are genuinely proud of. Not because of the awards or the certifications — though we have earned plenty — but because of the neighbors who call us back when they need a new roof, and the referrals from customers who trusted us with their homes.
              </p>
              <p>
                That is the Corner Stone story. And we are just getting started.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── Values ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-14 md:mb-18">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">What We Stand For</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 5vw, 4.5rem)' }}>
            Our Values
          </h2>
        </div>
        <div
          ref={valuesAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8"
        >
          {values.map((v, i) => (
            <div
              key={v.title}
              className={`anim-fade-up ${valuesAnim.isVisible ? 'is-visible' : ''} bg-charcoal-mid border border-white/5 p-8 md:p-10 group hover:border-orange/30 transition-all duration-300`}
              style={{ transitionDelay: `${i * 120}ms` }}
            >
              <div className="w-12 h-12 flex items-center justify-center bg-orange/20 text-orange mb-6 group-hover:bg-orange group-hover:text-white transition-all duration-300">
                <i className={`${v.icon} text-xl`} />
              </div>
              <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">{v.title}</h3>
              <p className="text-white/60 text-sm leading-relaxed">{v.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── 29-Year Timeline ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 overflow-hidden">
        <div className="text-center mb-16 md:mb-20">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">29 Years of Growth</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2.5rem, 5vw, 4.5rem)' }}>
            The Corner Stone<br />Timeline
          </h2>
          <p className="text-white/60 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            From a two-man crew in 1995 to the Tri-State's most trusted roofing company — here's how we got here.
          </p>
        </div>

        <div className="relative max-w-5xl mx-auto">
          {/* Vertical spine line (desktop) */}
          <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-px bg-white/10 -translate-x-1/2" />

          {timeline.map((item, index) => (
            <TimelineItem key={item.year} item={item} index={index} />
          ))}
        </div>
      </section>

      {/* ── Certifications ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-14 md:mb-18">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Credentials</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2.5rem, 5vw, 4.5rem)' }}>
            Certified by the Best.<br />Trusted by Thousands.
          </h2>
          <p className="text-white/60 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Our certifications are not just plaques on the wall — they mean better warranties, better materials, and better outcomes for your home.
          </p>
        </div>

        <div
          ref={certsAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6"
        >
          {certifications.map((cert, i) => (
            <div
              key={cert.name}
              className={`anim-fade-up ${certsAnim.isVisible ? 'is-visible' : ''} border ${cert.border} ${cert.bg} p-7 md:p-8 group hover:border-orange/40 transition-all duration-300`}
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <div className={`w-12 h-12 flex items-center justify-center ${cert.bg} ${cert.color} mb-5`}>
                <i className={`${cert.icon} text-xl`} />
              </div>
              <h3 className={`font-display text-lg uppercase tracking-wider mb-3 ${cert.color}`}>{cert.name}</h3>
              <p className="text-white/60 text-sm leading-relaxed">{cert.desc}</p>
            </div>
          ))}
        </div>

        {/* Manufacturer logos strip */}
        <div className="mt-14 border border-white/10 p-8 md:p-10">
          <p className="text-white/50 text-xs uppercase tracking-widest text-center mb-8">Certified Installer For</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            {[
              { name: 'GAF', sub: 'Master Elite Contractor', icon: 'ri-award-line', color: 'text-amber-500' },
              { name: 'Owens Corning', sub: 'Platinum Preferred', icon: 'ri-medal-line', color: 'text-orange' },
              { name: 'CertainTeed', sub: 'SELECT ShingleMaster', icon: 'ri-shield-star-line', color: 'text-green-500' },
              { name: 'Atlas Roofing', sub: 'Signature Select', icon: 'ri-verified-badge-line', color: 'text-amber-400' },
            ].map((brand) => (
              <div key={brand.name} className="text-center">
                <div className={`w-10 h-10 mx-auto mb-3 flex items-center justify-center ${brand.color}`}>
                  <i className={`${brand.icon} text-2xl`} />
                </div>
                <p className="text-white font-display text-base uppercase tracking-wider">{brand.name}</p>
                <p className="text-white/50 text-xs mt-0.5">{brand.sub}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Team ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14 md:mb-18">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">The People Behind the Roofs</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2.5rem, 5vw, 4.5rem)' }}>
            Meet the Team
          </h2>
          <p className="text-white/60 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Real people, real expertise. Every member of our team is background-checked, OSHA-certified, and genuinely invested in doing great work.
          </p>
        </div>

        <div
          ref={teamAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
        >
          {team.map((member, i) => (
            <div
              key={member.name}
              className={`anim-fade-up ${teamAnim.isVisible ? 'is-visible' : ''} group bg-charcoal-mid border border-white/5 hover:border-orange/20 transition-all duration-300 overflow-hidden`}
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              {/* Photo */}
              <div className="relative h-64 md:h-72 overflow-hidden">
                <img
                  src={member.img}
                  alt={member.name}
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal-mid via-transparent to-transparent" />
              </div>

              {/* Info */}
              <div className="p-6 md:p-7">
                <h3 className="font-display text-white text-xl uppercase tracking-wider mb-0.5">{member.name}</h3>
                <p className="text-orange text-xs font-semibold uppercase tracking-widest mb-3">{member.role}</p>
                <p className="text-white/60 text-sm leading-relaxed mb-4">{member.bio}</p>

                {/* Certs */}
                <div className="flex flex-wrap gap-2">
                  {member.certs.map((cert) => (
                    <span key={cert} className="bg-white/5 border border-white/10 text-white/60 text-xs px-2.5 py-1 uppercase tracking-wide">
                      {cert}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Community Section ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-center">
          <div>
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Community</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
              Evansville Is<br />More Than Our<br /><span className="text-orange">Market</span>
            </h2>
            <p className="text-white/70 text-sm md:text-base leading-relaxed mb-8">
              We are not a national chain that parachutes in after storms and disappears. We live here. Our kids go to school here. We coach little league, sponsor local events, and donate roofing services to families in need every year through our community program.
            </p>
            <div className="space-y-4">
              {[
                { icon: 'ri-heart-line', text: 'Annual free roof for a family in need through our "Roofs for Neighbors" program' },
                { icon: 'ri-team-line', text: 'Sponsor of Evansville youth sports leagues since 2005' },
                { icon: 'ri-building-2-line', text: 'Donated roofing services to 3 local churches and 2 community centers' },
                { icon: 'ri-graduation-cap-line', text: 'Annual scholarship for Evansville-area students pursuing trades education' },
              ].map((item) => (
                <div key={item.text} className="flex items-start gap-3">
                  <div className="w-8 h-8 flex items-center justify-center bg-orange/20 text-orange flex-shrink-0 mt-0.5">
                    <i className={`${item.icon} text-sm`} />
                  </div>
                  <p className="text-white/60 text-sm leading-relaxed">{item.text}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {[
              { src: '/placeholders/400x300.svg', alt: 'Community volunteering' },
              { src: '/placeholders/400x300.svg', alt: 'Youth sports sponsorship' },
              { src: '/placeholders/400x300.svg', alt: 'Free roof program' },
              { src: '/placeholders/400x300.svg', alt: 'Scholarship presentation' },
            ].map((img, i) => (
              <div key={i} className="relative overflow-hidden aspect-[4/3]">
                <img
                  src={img.src}
                  alt={img.alt}
                  className="w-full h-full object-cover object-top hover:scale-105 transition-transform duration-500"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div
          ref={ctaAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${ctaAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="relative overflow-hidden bg-charcoal-mid border border-white/5 p-10 md:p-16 lg:p-20 text-center">
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute -top-20 -right-20 w-80 h-80 bg-orange/5 rounded-full blur-3xl" />
              <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-orange/5 rounded-full blur-3xl" />
            </div>
            <div className="relative z-10">
              <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Ready to Work Together?</p>
              <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
                29 Years of Trust.<br /><span className="text-orange">Your Roof Is Next.</span>
              </h2>
              <p className="text-white/60 text-sm md:text-base max-w-lg mx-auto leading-relaxed mb-10">
                Free inspections, honest quotes, and the same quality that has kept Evansville families dry for nearly three decades. Let's get started.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <button
                  onClick={() => navigate('/estimate')}
                  className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
                >
                  Get a Free Estimate
                </button>
                <a
                  href="tel:8122135997"
                  className="border border-white/20 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
                >
                  <i className="ri-phone-line text-orange" />
                  812-213-5997
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <DealExpiringSoon linkToPage={true} />
    </div>
  );
}
