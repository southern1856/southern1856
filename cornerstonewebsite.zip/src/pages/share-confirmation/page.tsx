import { useEffect, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';

interface BookingState {
  date?: string;
  time?: string;
  address?: string;
  name?: string;
}

export default function ShareConfirmationPage() {
  const location = useLocation();
  const cardRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);
  const [flashCopied, setFlashCopied] = useState(false);

  const bookingData = (location.state as BookingState | null) || {};
  const hasDetails = !!bookingData.date && !!bookingData.time;

  const dateStr = bookingData.date
    ? new Date(bookingData.date + 'T12:00:00').toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      })
    : 'To Be Confirmed';

  useEffect(() => {
    if (copied) {
      const t = setTimeout(() => setCopied(false), 2000);
      return () => clearTimeout(t);
    }
  }, [copied]);

  useEffect(() => {
    if (flashCopied) {
      const t = setTimeout(() => setFlashCopied(false), 2000);
      return () => clearTimeout(t);
    }
  }, [flashCopied]);

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
    } catch {
      // ignore
    }
  };

  const handleScreenshotFlash = () => {
    setFlashCopied(true);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'My Roof Inspection is Booked — Corner Stone',
          text: `I booked a free roof inspection with Corner Stone on ${dateStr}.`,
          url: window.location.href,
        });
      } catch {
        // ignore
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <PageSEO
        title="Inspection Confirmation — Corner Stone Construction & Roofing"
        description="Your free roof inspection is confirmed. Booked with Corner Stone Construction & Roofing in Evansville, Indiana."
        keywords="roof inspection confirmation, booked inspection, Corner Stone Roofing"
        canonical="/share-confirmation"
      />

      {/* Hidden-only Navbar spacer */}
      <div className="h-16 bg-charcoal-deep" />

      <main className="max-w-lg mx-auto px-4 py-8 md:py-12">
        {/* Top Actions */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="font-display text-charcoal-deep text-lg uppercase tracking-wider">
            Confirmation Card
          </h1>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyLink}
              className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-charcoal-deep/70 hover:text-charcoal-deep transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className={`ri-${copied ? 'checkbox-circle' : 'link'} text-sm`} />
              {copied ? 'Copied' : 'Copy Link'}
            </button>
            {typeof navigator !== 'undefined' && (navigator as unknown as { share?: unknown }).share && (
              <button
                onClick={handleNativeShare}
                className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-charcoal-deep/70 hover:text-charcoal-deep transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-share-forward-line text-sm" />
                Share
              </button>
            )}
          </div>
        </div>

        {/* Screenshot flash message */}
        {flashCopied && (
          <div className="mb-4 bg-green-50 border border-green-200 rounded-lg px-4 py-3 flex items-center gap-2 animate-pulse">
            <i className="ri-camera-line text-green-600" />
            <span className="text-green-700 text-sm font-semibold">Screenshot this card and share it!</span>
          </div>
        )}

        {/* ── THE SHAREABLE CARD ── */}
        <div
          ref={cardRef}
          className="bg-white border border-gray-200 shadow-sm overflow-hidden"
        >
          {/* Card Header */}
          <div className="bg-charcoal-deep px-6 py-5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 flex items-center justify-center bg-orange">
                <i className="ri-home-4-line text-white text-xl" />
              </div>
              <div>
                <p className="font-display text-white text-sm uppercase tracking-wider leading-tight">
                  Corner Stone
                </p>
                <p className="text-white/40 text-[10px] uppercase tracking-widest">
                  Construction & Roofing
                </p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-orange text-[10px] uppercase tracking-widest font-semibold">
                Confirmed
              </p>
              <p className="text-white/30 text-[10px] uppercase tracking-widest">
                Evansville, IN
              </p>
            </div>
          </div>

          {/* Confirmation Hero */}
          <div className="px-6 pt-8 pb-6 text-center border-b border-gray-100">
            <div className="w-16 h-16 flex items-center justify-center bg-green-500/10 rounded-full mx-auto mb-4">
              <i className="ri-checkbox-circle-fill text-green-600 text-3xl" />
            </div>
            <h2 className="font-display text-charcoal-deep text-2xl md:text-3xl uppercase tracking-wider leading-tight mb-2">
              You're Booked.
            </h2>
            <p className="text-gray-400 text-sm">
              {hasDetails
                ? `Inspection scheduled for ${dateStr}`
                : 'Inspection appointment confirmed'}
            </p>
          </div>

          {/* Appointment Details */}
          <div className="px-6 py-5 border-b border-gray-100">
            <p className="text-orange text-[10px] uppercase tracking-[0.25em] font-semibold mb-3">
              Appointment Details
            </p>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 flex items-center justify-center bg-orange/10 flex-shrink-0">
                  <i className="ri-calendar-line text-orange" />
                </div>
                <div>
                  <p className="text-gray-400 text-[10px] uppercase tracking-wider">Date</p>
                  <p className="text-charcoal-deep text-sm font-semibold">{dateStr}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 flex items-center justify-center bg-orange/10 flex-shrink-0">
                  <i className="ri-time-line text-orange" />
                </div>
                <div>
                  <p className="text-gray-400 text-[10px] uppercase tracking-wider">Time</p>
                  <p className="text-charcoal-deep text-sm font-semibold">
                    {bookingData.time || 'To Be Confirmed'}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 flex items-center justify-center bg-orange/10 flex-shrink-0">
                  <i className="ri-map-pin-line text-orange" />
                </div>
                <div>
                  <p className="text-gray-400 text-[10px] uppercase tracking-wider">Location</p>
                  <p className="text-charcoal-deep text-sm font-semibold">
                    {bookingData.address || 'Your Property — Evansville, IN'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* What Happens Next */}
          <div className="px-6 py-5 border-b border-gray-100">
            <p className="text-orange text-[10px] uppercase tracking-[0.25em] font-semibold mb-3">
              What Happens Next
            </p>
            <div className="space-y-2.5">
              {[
                { icon: 'ri-phone-line', text: 'Confirmation call within 24 hours' },
                { icon: 'ri-search-eye-line', text: 'Certified inspector arrives on time' },
                { icon: 'ri-mail-send-line', text: 'Full photo report emailed within 24 hrs' },
                { icon: 'ri-shield-check-line', text: 'No-pressure follow-up if work is needed' },
              ].map((item) => (
                <div key={item.text} className="flex items-center gap-2.5">
                  <i className={`${item.icon} text-orange text-sm`} />
                  <p className="text-gray-600 text-xs">{item.text}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Contact / Call CTA */}
          <div className="px-6 py-5 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-[10px] uppercase tracking-widest mb-0.5">Questions?</p>
                <p className="font-display text-charcoal-deep text-lg uppercase tracking-wider">812-213-5997</p>
              </div>
              <a
                href="tel:8122135997"
                className="w-10 h-10 flex items-center justify-center bg-orange text-white hover:bg-orange-dark transition-colors"
              >
                <i className="ri-phone-fill text-lg" />
              </a>
            </div>
          </div>

          {/* Footer Branding */}
          <div className="bg-gray-50 px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 flex items-center justify-center bg-orange">
                <i className="ri-shield-check-line text-white text-xs" />
              </div>
              <div>
                <p className="text-charcoal-deep text-[10px] font-semibold uppercase tracking-wider">Licensed & Insured</p>
                <p className="text-gray-400 text-[10px] uppercase tracking-wider">IN & KY</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-charcoal-deep text-[10px] font-semibold uppercase tracking-wider">Free Inspection</p>
              <p className="text-gray-400 text-[10px] uppercase tracking-wider">No Obligation</p>
            </div>
          </div>
        </div>

        {/* ── SMS / EMAIL TEMPLATE ── */}
        <div className="mt-8 bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
              Copy as Text
            </h3>
            <button
              onClick={async () => {
                const text = `My roof inspection is booked!\n\nCorner Stone Construction & Roofing\n${dateStr} at ${bookingData.time || 'TBC'}\n${bookingData.address || 'Evansville, IN'}\n\nCall 812-213-5997 with questions.`;
                try {
                  await navigator.clipboard.writeText(text);
                  setCopied(true);
                } catch {
                  // ignore
                }
              }}
              className="text-xs font-semibold uppercase tracking-wider text-orange hover:text-orange-dark transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-clipboard-line mr-1" />
              {copied ? 'Copied!' : 'Copy Text'}
            </button>
          </div>

          <div className="bg-gray-50 border border-gray-100 rounded-lg p-4">
            <p className="text-gray-600 text-sm leading-relaxed whitespace-pre-wrap">
              My roof inspection is booked!
              {'\n\n'}
              Corner Stone Construction & Roofing{'\n'}
              {dateStr} at {bookingData.time || 'TBC'}{'\n'}
              {bookingData.address || 'Evansville, IN'}
              {'\n\n'}
              Call 812-213-5997 with questions.
            </p>
          </div>
        </div>

        {/* ── SCREENSHOT CTA ── */}
        <div className="mt-6 flex items-center justify-center">
          <button
            onClick={handleScreenshotFlash}
            className="flex items-center gap-2 bg-charcoal-deep hover:bg-charcoal text-white font-semibold px-6 py-3 uppercase tracking-widest text-xs transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-camera-line text-sm" />
            Tap to Screenshot This Card
          </button>
        </div>

        {/* ── BACK TO FULL CONFIRMATION ── */}
        <div className="mt-8 text-center">
          <a
            href="/inspection-booked"
            className="text-charcoal-deep text-sm hover:text-orange transition-colors underline underline-offset-4"
          >
            View Full Confirmation Page
          </a>
        </div>
      </main>
    </div>
  );
}