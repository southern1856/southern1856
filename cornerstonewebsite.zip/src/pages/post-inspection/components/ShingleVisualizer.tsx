import { useState } from 'react';
import {
  SHINGLE_COLOR_PALETTES,
  SHINGLE_ROOF_PREVIEWS,
  COLOR_PAIRINGS,
  DEFAULT_PAIRING,
  type ShinglePaletteType,
  type ShingleColor,
} from '@/mocks/shingleColors';
import ColorPairings from './ColorPairings';
import FullExteriorPreview from './FullExteriorPreview';
import { INSPECTOR_MATERIAL_RECOMMENDATION } from '@/mocks/materialComparison';

/* ─── Neighborhood homes (real local portfolio) ─── */
const NEIGHBORHOOD_HOMES = [
  {
    id: 1,
    title: 'Colonial on Oakmont',
    location: 'Evansville, IN — 0.8 mi away',
    image:
      '/placeholders/900x520.svg',
    material: 'GAF Timberline HDZ',
    year: 2024,
    overlayOpacity: 0.22,
  },
  {
    id: 2,
    title: 'Craftsman on Riverside',
    location: 'Evansville, IN — 1.2 mi away',
    image:
      '/placeholders/900x520.svg',
    material: 'Owens Corning Duration',
    year: 2024,
    overlayOpacity: 0.25,
  },
  {
    id: 3,
    title: 'Ranch on Springdale',
    location: 'Newburgh, IN — 2.4 mi away',
    image:
      '/placeholders/900x520.svg',
    material: 'CertainTeed Landmark Pro',
    year: 2023,
    overlayOpacity: 0.20,
  },
  {
    id: 4,
    title: 'Split-Level on Willow',
    location: 'Evansville, IN — 1.6 mi away',
    image:
      '/placeholders/900x520.svg',
    material: 'GAF Timberline HDZ',
    year: 2024,
    overlayOpacity: 0.23,
  },
];

/* ─── Inspector recommendation colors (hard-mapped to known SKUs) ─── */
const INSPECTOR_PICK = {
  materialKey: 'architectural' as const,
  colorSku: 'ARCH-PGW',
};

const UPGRADE_PICK = {
  materialKey: 'premium' as const,
  colorSku: 'PREM-STG',
};

function findColor(materialKey: string, sku: string): ShingleColor | null {
  const palette = SHINGLE_COLOR_PALETTES.find((p) => p.key === materialKey);
  return palette?.colors.find((c) => c.sku === sku) ?? null;
}

function SwatchTile({
  color,
  isSelected,
  onClick,
  isPinned,
  compareMode,
}: {
  color: ShingleColor;
  isSelected: boolean;
  onClick: () => void;
  isPinned?: boolean;
  compareMode?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`group relative w-full aspect-square rounded-xl overflow-hidden border-2 transition-all cursor-pointer ${
        isPinned
          ? 'border-orange ring-2 ring-orange/20 shadow-md'
          : isSelected
          ? 'border-orange ring-2 ring-orange/20 shadow-md'
          : 'border-gray-200 hover:border-gray-300 hover:shadow-sm'
      }`}
      title={color.name}
    >
      {/* Pin badge */}
      {compareMode && isPinned && (
        <div className="absolute top-1.5 left-1.5 z-10 w-5 h-5 flex items-center justify-center bg-orange rounded-full shadow-sm">
          <i className="ri-pushpin-fill text-white text-[9px]" />
        </div>
      )}
      {/* Color fill */}
      <div
        className="absolute inset-0"
        style={{ backgroundColor: color.hex }}
      />
      {/* Texture overlay - subtle noise */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage:
            'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noise%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.65%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noise)%22 opacity=%220.4%22/%3E%3C/svg%3E")',
          backgroundSize: '100px 100px',
        }}
      />
      {/* Hover overlay */}
      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
      {/* Selected indicator (only in single mode) */}
      {!compareMode && isSelected && (
        <div className="absolute top-2 right-2 w-6 h-6 flex items-center justify-center bg-orange rounded-full shadow-sm">
          <i className="ri-check-line text-white text-xs" />
        </div>
      )}
      {/* Compare mode: add hint overlay */}
      {compareMode && (
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="bg-black/50 backdrop-blur-sm rounded-full px-2 py-1">
            <span className="text-white text-[9px] font-semibold uppercase tracking-wider">
              {isPinned ? 'Unpin' : 'Pin'}
            </span>
          </div>
        </div>
      )}
      {/* Color name on hover */}
      <div className="absolute bottom-0 left-0 right-0 px-2 py-1.5 bg-black/60 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity">
        <p className="text-white text-[10px] font-semibold leading-tight truncate">
          {color.name}
        </p>
      </div>
    </button>
  );
}

function MaterialPanel({
  palette,
  selectedColor,
  onColorSelect,
  pinnedColors,
  compareMode,
}: {
  palette: ShinglePaletteType;
  selectedColor: ShingleColor | null;
  onColorSelect: (color: ShingleColor) => void;
  pinnedColors?: Array<{ materialKey: string; color: ShingleColor }>;
  compareMode?: boolean;
}) {
  const preview = SHINGLE_ROOF_PREVIEWS[palette.key as keyof typeof SHINGLE_ROOF_PREVIEWS];

  return (
    <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm">
      {/* Top bar */}
      <div className="px-5 py-4 border-b border-gray-100 flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 flex items-center justify-center rounded-xl flex-shrink-0"
            style={{ backgroundColor: `${palette.accentColor}15` }}
          >
            <i
              className="ri-stack-line text-lg"
              style={{ color: palette.accentColor }}
            />
          </div>
          <div>
            <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
              {palette.name}
            </h3>
            <p className="text-gray-400 text-[10px] mt-0.5">
              {palette.colors.length} colors available
            </p>
          </div>
        </div>
        {selectedColor && (
          <div className="flex items-center gap-2 flex-shrink-0">
            <div
              className="w-5 h-5 rounded-md border border-gray-200"
              style={{ backgroundColor: selectedColor.hex }}
            />
            <span className="text-gray-600 text-xs font-medium">
              {selectedColor.name}
            </span>
          </div>
        )}
      </div>

      {/* Texture preview strip */}
      <div className="relative aspect-[3/1] overflow-hidden bg-gray-100">
        <img
          src={palette.textureImage}
          alt={`${palette.name} texture`}
          className="w-full h-full object-cover object-top"
          loading="lazy"
        />
        {/* Color tint overlay when selected */}
        {selectedColor && (
          <div
            className="absolute inset-0 mix-blend-multiply transition-all duration-500"
            style={{
              backgroundColor: selectedColor.hex,
              opacity: 0.35,
            }}
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
        <div className="absolute bottom-3 left-4 right-4">
          <p className="text-white text-[10px] uppercase tracking-widest font-semibold mb-0.5">
            Texture Preview
          </p>
          <p className="text-white/70 text-xs leading-snug">
            {palette.description}
          </p>
        </div>
      </div>

      {/* Color grid */}
      <div className="p-5">
        <div className="flex items-center justify-between mb-3">
          <p className="text-charcoal-deep text-[10px] uppercase tracking-widest font-semibold">
            {compareMode ? 'Click to Pin (up to 3 total)' : 'Choose a Color'}
          </p>
          {selectedColor && !compareMode && (
            <span className="text-orange text-[10px] font-semibold">
              {selectedColor.sku}
            </span>
          )}
        </div>
        <div
          className={`grid gap-2 ${
            palette.colors.length <= 8
              ? 'grid-cols-4 sm:grid-cols-4'
              : 'grid-cols-4 sm:grid-cols-6'
          }`}
        >
          {palette.colors.map((color) => (
            <SwatchTile
              key={color.sku}
              color={color}
              isSelected={selectedColor?.sku === color.sku}
              onClick={() => onColorSelect(color)}
              isPinned={
                pinnedColors?.some(
                  (p) => p.color.sku === color.sku && p.materialKey === palette.key
                ) ?? false
              }
              compareMode={compareMode}
            />
          ))}
        </div>
      </div>

      {/* Selected color detail */}
      {selectedColor && !compareMode && (
        <div className="px-5 pb-5">
          <div className="bg-gray-50 border border-gray-100 rounded-xl p-4 flex items-center gap-4">
            <div
              className="w-16 h-16 rounded-xl border border-gray-200 flex-shrink-0 shadow-sm"
              style={{ backgroundColor: selectedColor.hex }}
            />
            <div className="min-w-0 flex-1">
              <p className="font-display text-charcoal-deep text-sm uppercase tracking-wider mb-0.5">
                {selectedColor.name}
              </p>
              <p className="text-gray-400 text-[10px] mb-1">
                SKU: {selectedColor.sku}
              </p>
              <div className="flex items-center gap-2">
                <span className="text-gray-500 text-[10px] font-mono bg-white border border-gray-200 px-1.5 py-0.5 rounded">
                  {selectedColor.hex}
                </span>
                <span className="text-gray-400 text-[10px]">
                  {palette.name}
                </span>
              </div>
            </div>
            <button
              onClick={() => onColorSelect(selectedColor)}
              className="flex-shrink-0 inline-flex items-center gap-1.5 bg-orange hover:bg-orange-dark text-white font-bold text-[10px] uppercase tracking-wider px-3 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-add-line" />
              Add to Estimate
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Roof Preview Panel ─── */
function RoofPreview({
  selectedShingle,
  selectedColor,
}: {
  selectedShingle: string | null;
  selectedColor: ShingleColor | null;
}) {
  const currentPreview = selectedShingle
    ? SHINGLE_ROOF_PREVIEWS[selectedShingle as keyof typeof SHINGLE_ROOF_PREVIEWS]
    : null;

  return (
    <div className="bg-charcoal-deep rounded-2xl overflow-hidden shadow-sm">
      {/* Header */}
      <div className="px-5 py-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 flex items-center justify-center bg-orange/20 rounded-xl">
            <i className="ri-home-4-line text-orange text-lg" />
          </div>
          <div>
            <h3 className="font-display text-white text-sm uppercase tracking-wider">
              Your Roof Preview
            </h3>
            <p className="text-white/40 text-[10px] mt-0.5">
              See how your selection would look installed
            </p>
          </div>
        </div>
      </div>

      {/* Preview image */}
      <div className="relative aspect-[16/10] overflow-hidden bg-gray-900">
        {currentPreview ? (
          <>
            <img
              src={currentPreview.houseImage}
              alt="Roof preview"
              className="w-full h-full object-cover object-top transition-all duration-500"
              loading="lazy"
            />
            {/* Color overlay on roof */}
            {selectedColor && (
              <div
                className="absolute inset-0 mix-blend-color transition-all duration-700"
                style={{
                  backgroundColor: selectedColor.hex,
                  opacity: 0.25,
                }}
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          </>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="w-14 h-14 flex items-center justify-center bg-white/5 rounded-full mx-auto mb-3">
                <i className="ri-eye-line text-white/30 text-xl" />
              </div>
              <p className="text-white/30 text-xs">
                Select a material and color to preview
              </p>
            </div>
          </div>
        )}

        {/* Floating detail badge */}
        {selectedColor && currentPreview && (
          <div className="absolute bottom-4 left-4 right-4">
            <div className="bg-white/90 backdrop-blur-sm rounded-xl p-3 flex items-center gap-3">
              <div
                className="w-8 h-8 rounded-lg border border-gray-200 flex-shrink-0"
                style={{ backgroundColor: selectedColor.hex }}
              />
              <div className="min-w-0 flex-1">
                <p className="text-charcoal-deep text-xs font-semibold truncate">
                  {selectedColor.name}
                </p>
                <p className="text-gray-400 text-[10px]">
                  {SHINGLE_COLOR_PALETTES.find(
                    (p) => p.key === selectedShingle
                  )?.name}
                </p>
              </div>
              <span className="text-orange text-[10px] font-semibold flex-shrink-0">
                {selectedColor.sku}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Recommendation note */}
      <div className="px-5 py-4">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 flex items-center justify-center bg-orange/20 rounded-lg flex-shrink-0 mt-0.5">
            <i className="ri-lightbulb-line text-orange text-sm" />
          </div>
          <div>
            <p className="text-white text-xs font-semibold mb-1">
              Inspector Tip
            </p>
            <p className="text-white/50 text-[11px] leading-relaxed">
              Colors appear different in direct sunlight vs. shade. For this Evansville
              property with mixed tree cover, medium-toned colors like Pewter Gray
              and Heather Blend hide algae streaks best and look consistent year-round.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── Material Quick-Pick Card ─── */
function QuickPickCard({
  type,
  materialKey,
  color,
  onSelect,
  isActive,
}: {
  type: 'recommended' | 'upgrade';
  materialKey: string;
  color: ShingleColor;
  onSelect: () => void;
  isActive: boolean;
}) {
  const palette = SHINGLE_COLOR_PALETTES.find((p) => p.key === materialKey)!;
  const isRec = type === 'recommended';

  return (
    <button
      onClick={onSelect}
      className={`group relative w-full text-left rounded-2xl border-2 transition-all cursor-pointer overflow-hidden ${
        isActive
          ? 'border-orange ring-2 ring-orange/15 shadow-md'
          : 'border-gray-200 hover:border-orange/40 hover:shadow-sm'
      }`}
    >
      {/* Header band */}
      <div
        className={`px-5 py-3 flex items-center gap-2 ${
          isRec ? 'bg-orange' : 'bg-charcoal-deep'
        }`}
      >
        <i
          className={`${isRec ? 'ri-star-fill' : 'ri-vip-crown-line'} text-white text-sm`}
        />
        <span className="text-white text-xs font-bold uppercase tracking-widest">
          {isRec ? "Inspector's Pick" : 'Upgrade Option'}
        </span>
        {isActive && (
          <span className="ml-auto text-white text-[10px] font-semibold bg-white/20 rounded-full px-2 py-0.5">
            Selected
          </span>
        )}
      </div>

      <div className="p-5 flex items-center gap-4">
        {/* Large color swatch */}
        <div
          className="w-16 h-16 rounded-xl border border-gray-200 flex-shrink-0 shadow-sm relative overflow-hidden"
          style={{ backgroundColor: color.hex }}
        >
          <div
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage:
                'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noise%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.65%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noise)%22 opacity=%220.4%22/%3E%3C/svg%3E")',
              backgroundSize: '100px 100px',
            }}
          />
        </div>

        <div className="min-w-0 flex-1">
          <p className="font-display text-charcoal-deep text-sm uppercase tracking-wider mb-0.5 truncate">
            {palette.name}
          </p>
          <p className="text-charcoal-deep text-xs font-semibold mb-1">
            {color.name}
          </p>
          <p className="text-gray-400 text-[10px] leading-relaxed line-clamp-2">
            {isRec
              ? 'Best value for a 14-year roof. 25–30 year lifespan, 110 mph wind rating, and dimensional curb appeal that boosts resale.'
              : 'Maximum protection for forever homes. 35–50 year lifespan, 130 mph wind rating, Class 4 impact resistance, and cool-roof energy savings.'}
          </p>
        </div>

        {/* Arrow / check */}
        <div
          className={`w-8 h-8 flex items-center justify-center rounded-full flex-shrink-0 transition-colors ${
            isActive ? 'bg-orange text-white' : 'bg-gray-100 text-gray-400 group-hover:bg-orange/10 group-hover:text-orange'
          }`}
        >
          <i className={`${isActive ? 'ri-check-line' : 'ri-arrow-right-line'} text-sm`} />
        </div>
      </div>
    </button>
  );
}

/* ─── Neighborhood Match Panel ─── */
function NeighborhoodMatch({
  pinnedColors,
}: {
  pinnedColors: Array<{ materialKey: string; color: ShingleColor }>;
}) {
  // Track which pinned color is active for each home independently
  const [homeColorIdx, setHomeColorIdx] = useState(
    () => new Array(NEIGHBORHOOD_HOMES.length).fill(0)
  );

  if (pinnedColors.length === 0) return null;

  return (
    <div className="bg-white border border-gray-200 rounded-2xl p-5 md:p-8 shadow-sm">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-5">
        <div>
          <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
            Neighborhood Match
          </h3>
          <p className="text-gray-400 text-xs mt-1">
            See how your pinned colors look on real homes in the Evansville area
          </p>
        </div>
        <span className="text-gray-400 text-[10px] uppercase tracking-widest">
          Local project portfolio
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        {NEIGHBORHOOD_HOMES.map((home, hIdx) => {
          const activePin = pinnedColors[homeColorIdx[hIdx]];
          const palette = activePin
            ? SHINGLE_COLOR_PALETTES.find(
                (p) => p.key === activePin.materialKey
              )!
            : null;

          return (
            <div
              key={home.id}
              className="border border-gray-100 rounded-xl overflow-hidden bg-gray-50"
            >
              {/* House photo with color overlay */}
              <div className="relative aspect-[16/10] overflow-hidden bg-gray-200">
                <img
                  src={home.image}
                  alt={home.title}
                  className="w-full h-full object-cover object-top"
                  loading="lazy"
                />
                {activePin && (
                  <div
                    className="absolute inset-0 mix-blend-color transition-all duration-500"
                    style={{
                      backgroundColor: activePin.color.hex,
                      opacity: home.overlayOpacity,
                    }}
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />

                {/* Home info badge */}
                <div className="absolute top-3 left-3">
                  <div className="bg-white/90 backdrop-blur-sm rounded-lg px-2.5 py-1.5">
                    <p className="text-charcoal-deep text-[10px] font-semibold">
                      {home.title}
                    </p>
                    <p className="text-gray-400 text-[9px]">
                      {home.location}
                    </p>
                  </div>
                </div>

                {/* Active color badge */}
                {activePin && (
                  <div className="absolute bottom-3 left-3">
                    <div className="bg-white/90 backdrop-blur-sm rounded-lg px-2.5 py-1.5 flex items-center gap-2">
                      <div
                        className="w-5 h-5 rounded-md border border-gray-200"
                        style={{ backgroundColor: activePin.color.hex }}
                      />
                      <span className="text-charcoal-deep text-[10px] font-semibold">
                        {activePin.color.name}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Color switcher + home details */}
              <div className="p-4">
                {pinnedColors.length > 1 && (
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-gray-400 text-[9px] uppercase tracking-widest font-semibold">
                      Try color:
                    </span>
                    <div className="flex gap-1.5">
                      {pinnedColors.map((pin, pIdx) => (
                        <button
                          key={pin.color.sku}
                          onClick={() =>
                            setHomeColorIdx((prev) => {
                              const next = [...prev];
                              next[hIdx] = pIdx;
                              return next;
                            })
                          }
                          className={`w-7 h-7 rounded-md border-2 transition-all cursor-pointer ${
                            homeColorIdx[hIdx] === pIdx
                              ? 'border-orange ring-1 ring-orange/20'
                              : 'border-transparent hover:border-gray-300'
                          }`}
                          style={{ backgroundColor: pin.color.hex }}
                          title={pin.color.name}
                        />
                      ))}
                    </div>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[9px] font-semibold bg-gray-100 text-gray-500">
                      {home.material}
                    </span>
                    <span className="text-gray-400 text-[9px]">{home.year}</span>
                  </div>
                  {palette && (
                    <span
                      className="px-2 py-0.5 rounded text-[9px] font-semibold"
                      style={{
                        backgroundColor: `${palette.accentColor}15`,
                        color: palette.accentColor,
                      }}
                    >
                      {palette.name}
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Print Palette Modal ─── */
function PrintPaletteModal({
  pinnedColors,
  selectedByMaterial,
  onClose,
}: {
  pinnedColors: Array<{ materialKey: string; color: ShingleColor }>;
  selectedByMaterial: Record<string, ShingleColor | null>;
  onClose: () => void;
}) {
  const items =
    pinnedColors.length > 0
      ? pinnedColors
      : Object.entries(selectedByMaterial)
          .filter(([, c]) => c !== null)
          .map(([key, color]) => ({ materialKey: key, color: color! }));

  return (
    <div className="fixed inset-0 z-[100] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 py-5 border-b border-gray-100 flex items-center justify-between">
          <div>
            <h3 className="font-display text-charcoal-deep text-lg uppercase tracking-wider">My Shingle Palette</h3>
            <p className="text-gray-400 text-xs mt-0.5">{items.length} color{items.length !== 1 ? 's' : ''} selected</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-charcoal-deep transition-colors cursor-pointer">
            <i className="ri-close-line text-lg" />
          </button>
        </div>

        <div className="px-6 py-6 space-y-4">
          {items.map((item) => {
            const palette = SHINGLE_COLOR_PALETTES.find((p) => p.key === item.materialKey)!;
            const pairing = COLOR_PAIRINGS[item.color.sku] ?? DEFAULT_PAIRING;
            return (
              <div key={item.color.sku} className="flex items-start gap-4 border border-gray-100 rounded-xl p-4">
                <div className="w-16 h-16 rounded-xl border border-gray-200 flex-shrink-0 shadow-sm" style={{ backgroundColor: item.color.hex }} />
                <div className="min-w-0 flex-1">
                  <p className="font-display text-charcoal-deep text-sm uppercase tracking-wider">{item.color.name}</p>
                  <p className="text-gray-400 text-[10px] mt-0.5">{palette.name} — SKU: {item.color.sku}</p>
                  <p className="text-gray-400 text-[10px] font-mono bg-gray-50 border border-gray-100 px-1.5 py-0.5 rounded inline-block mt-1">{item.color.hex}</p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <span className="text-[10px] font-semibold text-gray-500 bg-gray-50 border border-gray-100 px-2 py-0.5 rounded">Siding: {pairing.siding[0].name}</span>
                    <span className="text-[10px] font-semibold text-gray-500 bg-gray-50 border border-gray-100 px-2 py-0.5 rounded">Trim: {pairing.trim[0].name}</span>
                    <span className="text-[10px] font-semibold text-gray-500 bg-gray-50 border border-gray-100 px-2 py-0.5 rounded">Accent: {pairing.accent[0].name}</span>
                  </div>
                </div>
              </div>
            );
          })}

          {items.length === 0 && (
            <div className="text-center py-8">
              <div className="w-12 h-12 flex items-center justify-center bg-gray-100 rounded-full mx-auto mb-3">
                <i className="ri-palette-line text-gray-400 text-xl" />
              </div>
              <p className="text-gray-400 text-sm">No colors selected yet.</p>
              <p className="text-gray-300 text-xs mt-1">Pick colors from the palettes below to build your palette.</p>
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-gray-100 flex items-center gap-3">
          <button
            onClick={() => window.print()}
            className="flex-1 inline-flex items-center justify-center gap-2 bg-charcoal-deep hover:bg-charcoal text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-printer-line" />
            Print Palette
          </button>
          <button
            onClick={onClose}
            className="flex-1 inline-flex items-center justify-center gap-2 border border-gray-300 hover:border-gray-400 text-charcoal-deep font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-close-line" />
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── main component ─── */
export default function ShingleVisualizer() {
  const [selectedByMaterial, setSelectedByMaterial] = useState<
    Record<string, ShingleColor | null>
  >({
    three_tab: null,
    architectural: null,
    premium: null,
  });

  const [activeMaterial, setActiveMaterial] = useState<string>('architectural');

  /* ─── Pin state for Compare Mode ─── */
  const [compareMode, setCompareMode] = useState(false);
  const [pinnedColors, setPinnedColors] = useState<
    Array<{ materialKey: string; color: ShingleColor }>
  >([]);
  const [showPrintModal, setShowPrintModal] = useState(false);

  const handleColorSelect = (materialKey: string, color: ShingleColor) => {
    if (compareMode) {
      // In compare mode: pin / unpin
      setPinnedColors((prev) => {
        const exists = prev.find(
          (p) => p.color.sku === color.sku && p.materialKey === materialKey
        );
        if (exists) {
          return prev.filter(
            (p) => !(p.color.sku === color.sku && p.materialKey === materialKey)
          );
        }
        if (prev.length >= 3) return prev; // max 3
        return [...prev, { materialKey, color }];
      });
    } else {
      // Normal mode: single selection per material
      setSelectedByMaterial((prev) => ({
        ...prev,
        [materialKey]: prev[materialKey]?.sku === color.sku ? null : color,
      }));
      setActiveMaterial(materialKey);
    }
  };

  const applyQuickPick = (materialKey: string, colorSku: string) => {
    const color = findColor(materialKey, colorSku);
    if (!color) return;

    setCompareMode(false);
    setPinnedColors([]);
    setActiveMaterial(materialKey);
    setSelectedByMaterial((prev) => ({
      ...prev,
      [materialKey]: color,
      // Clear other materials to keep it clean
      three_tab: materialKey === 'three_tab' ? color : prev.three_tab,
      premium: materialKey === 'premium' ? color : prev.premium,
      architectural: materialKey === 'architectural' ? color : prev.architectural,
    }));
  };

  const removePinned = (sku: string) => {
    setPinnedColors((prev) => prev.filter((p) => p.color.sku !== sku));
  };

  const clearAllPinned = () => setPinnedColors([]);

  // Find the currently "active" selection for preview
  const activeSelection = selectedByMaterial[activeMaterial];

  // Count total selections
  const totalSelected = Object.values(selectedByMaterial).filter(Boolean).length;

  // Resolved quick-pick colors
  const inspectorColor = findColor(INSPECTOR_PICK.materialKey, INSPECTOR_PICK.colorSku);
  const upgradeColor = findColor(UPGRADE_PICK.materialKey, UPGRADE_PICK.colorSku);

  // House image used for fair comparison (architectural = middle-tier, most representative)
  const COMPARISON_HOUSE_IMAGE =
    '/placeholders/900x520.svg';

  return (
    <div className="space-y-10">
      {/* ─── MATERIAL QUICK-PICK ─── */}
      <div className="bg-white border border-gray-200 rounded-2xl p-5 md:p-8 shadow-sm">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 flex items-center justify-center bg-orange/10 rounded-xl">
            <i className="ri-magic-line text-orange text-lg" />
          </div>
          <div>
            <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
              Material Quick-Pick
            </h3>
            <p className="text-gray-400 text-xs mt-0.5">
              Skip the browsing — jump straight to what Mike recommends for your 14-year roof
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {inspectorColor && (
            <QuickPickCard
              type="recommended"
              materialKey={INSPECTOR_PICK.materialKey}
              color={inspectorColor}
              onSelect={() => applyQuickPick(INSPECTOR_PICK.materialKey, INSPECTOR_PICK.colorSku)}
              isActive={
                activeMaterial === INSPECTOR_PICK.materialKey &&
                activeSelection?.sku === INSPECTOR_PICK.colorSku
              }
            />
          )}
          {upgradeColor && (
            <QuickPickCard
              type="upgrade"
              materialKey={UPGRADE_PICK.materialKey}
              color={upgradeColor}
              onSelect={() => applyQuickPick(UPGRADE_PICK.materialKey, UPGRADE_PICK.colorSku)}
              isActive={
                activeMaterial === UPGRADE_PICK.materialKey &&
                activeSelection?.sku === UPGRADE_PICK.colorSku
              }
            />
          )}
        </div>
      </div>

      {/* Mode Toggle + Print Button */}
      <div className="flex flex-col items-center gap-4">
        <div className="flex items-center gap-3 flex-wrap justify-center">
          <div className="inline-flex items-center bg-gray-100 rounded-full p-1">
            <button
              onClick={() => {
                setCompareMode(false);
                setPinnedColors([]);
              }}
              className={`px-5 py-2 rounded-full text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                !compareMode
                  ? 'bg-white text-charcoal-deep shadow-sm'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <i className="ri-eye-line mr-1.5" />
              Single Preview
            </button>
            <button
              onClick={() => setCompareMode(true)}
              className={`px-5 py-2 rounded-full text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                compareMode
                  ? 'bg-white text-charcoal-deep shadow-sm'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <i className="ri-layout-masonry-line mr-1.5" />
              Compare Colors
              <span className="ml-1.5 text-[10px] font-normal normal-case tracking-normal text-gray-400">
                (up to 3)
              </span>
            </button>
          </div>

          {/* Print / Save Palette Button */}
          <button
            onClick={() => setShowPrintModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap bg-white border border-gray-200 text-charcoal-deep hover:border-orange hover:text-orange shadow-sm"
          >
            <i className="ri-printer-line" />
            Print / Save My Palette
          </button>
        </div>

        {compareMode && (
          <p className="text-gray-500 text-sm text-center max-w-md">
            Click any color swatch to pin it. We&apos;ll show all pinned colors side-by-side on the same house so you can compare curb appeal.
          </p>
        )}

        {/* Pinned color chips — visible in compare mode */}
        {compareMode && pinnedColors.length > 0 && (
          <div className="flex flex-wrap items-center justify-center gap-2">
            <span className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mr-1">
              Pinned:
            </span>
            {pinnedColors.map((pin) => {
              const palette = SHINGLE_COLOR_PALETTES.find(
                (p) => p.key === pin.materialKey
              )!;
              return (
                <div
                  key={pin.color.sku}
                  className="flex items-center gap-2 bg-white border border-gray-200 rounded-full pl-1 pr-3 py-1 shadow-sm"
                >
                  <div
                    className="w-5 h-5 rounded-full border border-gray-200"
                    style={{ backgroundColor: pin.color.hex }}
                  />
                  <span className="text-charcoal-deep text-xs font-medium">
                    {pin.color.name}
                  </span>
                  <span className="text-gray-400 text-[10px]">
                    {palette.name}
                  </span>
                  <button
                    onClick={() => removePinned(pin.color.sku)}
                    className="w-5 h-5 flex items-center justify-center text-gray-400 hover:text-red-500 transition-colors cursor-pointer ml-1"
                  >
                    <i className="ri-close-line text-xs" />
                  </button>
                </div>
              );
            })}
            {pinnedColors.length > 0 && (
              <button
                onClick={clearAllPinned}
                className="text-gray-400 hover:text-red-500 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ml-2"
              >
                Clear All
              </button>
            )}
          </div>
        )}
      </div>

      {/* Print Modal */}
      {showPrintModal && (
        <PrintPaletteModal
          pinnedColors={pinnedColors}
          selectedByMaterial={selectedByMaterial}
          onClose={() => setShowPrintModal(false)}
        />
      )}

      {/* ─── COMPARE MODE: Side-by-side house previews ─── */}
      {compareMode && pinnedColors.length > 0 && (
        <div className="bg-white border border-gray-200 rounded-2xl p-5 md:p-8 shadow-sm">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
              Side-by-Side Comparison
            </h3>
            <span className="text-gray-400 text-[10px] uppercase tracking-widest">
              Same house, different colors
            </span>
          </div>
          <div
            className={`grid gap-5 ${
              pinnedColors.length === 1
                ? 'grid-cols-1 max-w-lg mx-auto'
                : pinnedColors.length === 2
                ? 'grid-cols-1 sm:grid-cols-2'
                : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
            }`}
          >
            {pinnedColors.map((pin) => {
              const palette = SHINGLE_COLOR_PALETTES.find(
                (p) => p.key === pin.materialKey
              )!;
              return (
                <div
                  key={pin.color.sku}
                  className="border border-gray-100 rounded-xl overflow-hidden bg-gray-50"
                >
                  {/* House preview */}
                  <div className="relative aspect-[16/10] overflow-hidden bg-gray-200">
                    <img
                      src={COMPARISON_HOUSE_IMAGE}
                      alt="House preview"
                      className="w-full h-full object-cover object-top"
                      loading="lazy"
                    />
                    {/* Color tint overlay */}
                    <div
                      className="absolute inset-0 mix-blend-color transition-all duration-700"
                      style={{
                        backgroundColor: pin.color.hex,
                        opacity: 0.28,
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />

                    {/* Floating color badge */}
                    <div className="absolute bottom-3 left-3 right-3">
                      <div className="bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2 flex items-center gap-2">
                        <div
                          className="w-6 h-6 rounded-md border border-gray-200 flex-shrink-0"
                          style={{ backgroundColor: pin.color.hex }}
                        />
                        <div className="min-w-0 flex-1">
                          <p className="text-charcoal-deep text-xs font-semibold truncate">
                            {pin.color.name}
                          </p>
                          <p className="text-gray-400 text-[10px]">
                            {palette.name}
                          </p>
                        </div>
                        <span className="text-orange text-[10px] font-semibold flex-shrink-0">
                          {pin.color.sku}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Detail strip below preview */}
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-charcoal-deep text-xs font-semibold">
                        {pin.color.name}
                      </span>
                      <span className="text-gray-400 text-[10px] font-mono bg-white border border-gray-200 px-1.5 py-0.5 rounded">
                        {pin.color.hex}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mb-3">
                      <span
                        className="px-2 py-0.5 rounded text-[10px] font-semibold"
                        style={{
                          backgroundColor: `${palette.accentColor}15`,
                          color: palette.accentColor,
                        }}
                      >
                        {palette.name}
                      </span>
                      <span className="text-gray-400 text-[10px]">
                        {palette.colors.length} colors
                      </span>
                    </div>
                    <button
                      onClick={() => {
                        setSelectedByMaterial((prev) => ({
                          ...prev,
                          [pin.materialKey]: pin.color,
                        }));
                        setActiveMaterial(pin.materialKey);
                        setCompareMode(false);
                      }}
                      className="w-full inline-flex items-center justify-center gap-1.5 bg-orange hover:bg-orange-dark text-white font-bold text-[10px] uppercase tracking-widest px-3 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-check-line" />
                      Select This Color
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Full Exterior Preview for each pinned color */}
          <div className="mt-6 pt-6 border-t border-gray-100">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 flex items-center justify-center bg-orange/10 rounded-xl">
                <i className="ri-home-gear-line text-orange text-lg" />
              </div>
              <div>
                <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
                  Full Exterior Preview
                </h3>
                <p className="text-gray-400 text-xs">
                  See roof + siding + trim + accent together on a single illustration
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-5">
              {pinnedColors.map((pin) => (
                <FullExteriorPreview key={pin.color.sku} color={pin.color} />
              ))}
            </div>
          </div>

          {/* Color Pairings for each pinned color */}
          <div className="mt-6 pt-6 border-t border-gray-100">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 flex items-center justify-center bg-orange/10 rounded-xl">
                <i className="ri-palette-line text-orange text-lg" />
              </div>
              <div>
                <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
                  Color Pairings
                </h3>
                <p className="text-gray-400 text-xs">
                  Complementary siding, trim, and accent colors for each pinned selection
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-5">
              {pinnedColors.map((pin) => (
                <ColorPairings
                  key={pin.color.sku}
                  color={pin.color}
                  paletteName={
                    SHINGLE_COLOR_PALETTES.find((p) => p.key === pin.materialKey)?.name
                  }
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ─── NEIGHBORHOOD MATCH (always visible when pins exist) ─── */}
      {pinnedColors.length > 0 && (
        <NeighborhoodMatch pinnedColors={pinnedColors} />
      )}

      {/* Main layout: panels + preview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Left: material panels */}
        <div className="lg:col-span-2 space-y-6">
          {SHINGLE_COLOR_PALETTES.map((palette) => (
            <MaterialPanel
              key={palette.key}
              palette={palette}
              selectedColor={selectedByMaterial[palette.key]}
              onColorSelect={(color) => handleColorSelect(palette.key, color)}
              pinnedColors={compareMode ? pinnedColors : undefined}
              compareMode={compareMode}
            />
          ))}
        </div>

        {/* Right: sticky preview (only in single-preview mode) */}
        {!compareMode && (
          <div className="lg:col-span-1">
            <div className="lg:sticky lg:top-24 space-y-5">
              <RoofPreview
                selectedShingle={activeMaterial}
                selectedColor={activeSelection}
              />

              {/* Summary box */}
              {totalSelected > 0 && (
                <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
                  <p className="text-charcoal-deep text-[10px] uppercase tracking-widest font-semibold mb-3">
                    Your Selections ({totalSelected})
                  </p>
                  <div className="space-y-2">
                    {Object.entries(selectedByMaterial)
                      .filter(([, c]) => c !== null)
                      .map(([key, color]) => {
                        const palette = SHINGLE_COLOR_PALETTES.find(
                          (p) => p.key === key
                        )!;
                        return (
                          <div
                            key={key}
                            className="flex items-center gap-3 bg-gray-50 rounded-lg p-3"
                          >
                            <div
                              className="w-6 h-6 rounded-md border border-gray-200 flex-shrink-0"
                              style={{ backgroundColor: color!.hex }}
                            />
                            <div className="min-w-0 flex-1">
                              <p className="text-charcoal-deep text-xs font-semibold truncate">
                                {color!.name}
                              </p>
                              <p className="text-gray-400 text-[10px]">
                                {palette.name}
                              </p>
                            </div>
                            <button
                              onClick={() =>
                                handleColorSelect(key, color!)
                              }
                              className="w-6 h-6 flex items-center justify-center text-gray-400 hover:text-red-500 transition-colors cursor-pointer flex-shrink-0"
                            >
                              <i className="ri-close-line text-xs" />
                            </button>
                          </div>
                        );
                      })}
                  </div>
                  <a
                    href="#schedule-repair"
                    className="mt-4 w-full inline-flex items-center justify-center gap-2 bg-orange hover:bg-orange-dark text-white font-bold text-xs uppercase tracking-widest px-4 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-calendar-check-line" />
                    Schedule with Selection
                  </a>
                </div>
              )}

              {/* Full Exterior Preview for active selection */}
              {activeSelection && (
                <FullExteriorPreview color={activeSelection} />
              )}

              {/* Color Pairings for active selection */}
              {activeSelection && (
                <ColorPairings
                  color={activeSelection}
                  paletteName={
                    SHINGLE_COLOR_PALETTES.find((p) => p.key === activeMaterial)?.name
                  }
                />
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}