import { useState } from 'react';
import {
  SHINGLE_COMPARISON,
  INSPECTOR_MATERIAL_RECOMMENDATION,
  COST_PROJECTION_22_YEAR,
  type ShingleType,
} from '@/mocks/materialComparison';

/* ─── helpers ─── */
function LifespanBar({ years, maxYears, color }: { years: number; maxYears: number; color: string }) {
  const pct = (years / maxYears) * 100;
  return (
    <div className="w-full h-2.5 bg-gray-100 rounded-full overflow-hidden">
      <div
        className="h-full rounded-full transition-all duration-700"
        style={{ width: `${pct}%`, backgroundColor: color }}
      />
    </div>
  );
}

function FeatureRow({ feature }: { feature: ShingleType['features'][number] }) {
  return (
    <div className="flex items-center gap-2 py-1.5">
      {feature.included ? (
        <div className="w-4 h-4 flex items-center justify-center rounded-full bg-green-100 flex-shrink-0">
          <i className="ri-check-line text-green-600 text-[10px]" />
        </div>
      ) : (
        <div className="w-4 h-4 flex items-center justify-center rounded-full bg-gray-100 flex-shrink-0">
          <i className="ri-close-line text-gray-400 text-[10px]" />
        </div>
      )}
      <span className={`text-[11px] ${feature.included ? 'text-gray-700' : 'text-gray-400'}`}>
        {feature.label}
      </span>
    </div>
  );
}

function ProjectionRow({
  shingle,
  projection,
  isRec,
}: {
  shingle: ShingleType;
  projection: (typeof COST_PROJECTION_22_YEAR)[number];
  isRec: boolean;
}) {
  const lifetimeRange = `$${projection.lifetimeCostLow.toLocaleString()}–$${projection.lifetimeCostHigh.toLocaleString()}`;
  return (
    <div
      className={`rounded-xl border p-4 ${
        isRec ? 'border-orange bg-orange/5' : 'border-gray-200 bg-white'
      }`}
    >
      <div className="flex items-center gap-2 mb-3">
        <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: shingle.accentColor }} />
        <span className="text-sm font-semibold text-charcoal-deep">{shingle.name}</span>
        {isRec && (
          <span className="ml-auto px-2 py-0.5 bg-orange text-white text-[9px] font-bold uppercase tracking-wider rounded">
            Recommended
          </span>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3 mb-3">
        <div>
          <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">First Replace</p>
          <p className="font-display text-charcoal-deep text-sm uppercase tracking-wider">{projection.firstReplacementYear}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">Next Replace</p>
          <p className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
            {projection.secondReplacementYear}
          </p>
          <p className="text-[10px] text-gray-400">At age {projection.secondReplacementAge}</p>
        </div>
      </div>

      <div className="border-t border-gray-100 pt-3">
        <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold mb-1">
          Total 22-Year Cost
        </p>
        <p className="font-display text-charcoal-deep text-lg uppercase tracking-wider">
          {lifetimeRange}
        </p>
        <p className="text-[10px] text-gray-400 mt-0.5">
          Includes replacement + avg. ${projection.maintenancePerYear}/yr maintenance
        </p>
      </div>
    </div>
  );
}

/* ─── individual shingle card ─── */
function ShingleCard({
  shingle,
  isRec,
  isSelected,
  onSelect,
}: {
  shingle: ShingleType;
  isRec: boolean;
  isSelected: boolean;
  onSelect: () => void;
}) {
  const lifespanNum = parseInt(shingle.lifespan.years.split('–')[1] ?? shingle.lifespan.years, 10);
  const maxLifespan = 50;

  return (
    <div
      className={`rounded-2xl border overflow-hidden transition-all duration-300 flex flex-col ${
        isRec ? 'border-orange shadow-sm' : 'border-gray-200'
      } ${isSelected ? 'ring-2 ring-orange/30' : ''}`}
    >
      {/* header */}
      <div className={`px-5 py-4 ${isRec ? 'bg-orange/5' : 'bg-white'}`}>
        <div className="flex items-center gap-2 mb-3">
          <span className={`px-2.5 py-1 rounded-md border text-[10px] font-bold uppercase tracking-wider ${shingle.tierColor}`}>
            {shingle.tier}
          </span>
          {shingle.popular && (
            <span className="px-2 py-0.5 bg-orange text-white text-[9px] font-bold uppercase tracking-wider rounded">
              Most Popular
            </span>
          )}
          {isRec && !shingle.popular && (
            <span className="px-2 py-0.5 bg-green-600 text-white text-[9px] font-bold uppercase tracking-wider rounded">
              Inspector Pick
            </span>
          )}
        </div>

        <div className="flex items-center gap-3 mb-2">
          <div
            className="w-10 h-10 flex items-center justify-center rounded-xl flex-shrink-0"
            style={{ backgroundColor: `${shingle.accentColor}15` }}
          >
            <i className={`${shingle.icon} text-lg`} style={{ color: shingle.accentColor }} />
          </div>
          <div>
            <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
              {shingle.name}
            </h3>
            <p className="text-gray-400 text-[10px]">{shingle.badge}</p>
          </div>
        </div>

        <p className="text-gray-600 text-xs leading-relaxed">{shingle.headline}</p>
      </div>

      {/* stats strip */}
      <div className="px-5 py-4 border-y border-gray-100 space-y-3">
        {/* lifespan */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">
              Lifespan
            </span>
            <span className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
              {shingle.lifespan.years} <span className="text-gray-400 text-[10px]">{shingle.lifespan.label}</span>
            </span>
          </div>
          <LifespanBar years={lifespanNum} maxYears={maxLifespan} color={shingle.accentColor} />
        </div>

        {/* two-col stats */}
        <div className="grid grid-cols-2 gap-x-4 gap-y-2">
          <div>
            <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">Wind Rating</p>
            <p className="text-charcoal-deep text-xs font-semibold">{shingle.windRating}</p>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">Algae Resist</p>
            <p className="text-charcoal-deep text-xs font-semibold">{shingle.algaeResistance}</p>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">Fire Rating</p>
            <p className="text-charcoal-deep text-xs font-semibold">{shingle.fireRating}</p>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">Energy Rating</p>
            <p className="text-charcoal-deep text-xs font-semibold">{shingle.energyRating}</p>
          </div>
        </div>

        {/* cost */}
        <div className="flex items-end justify-between pt-1">
          <div>
            <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">Cost / Sq</p>
            <p className="text-charcoal-deep text-xs font-semibold">{shingle.costPerSq}</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">Full Roof</p>
            <p className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
              ${shingle.costTotalLow.toLocaleString()}–${shingle.costTotalHigh.toLocaleString()}
            </p>
          </div>
        </div>
      </div>

      {/* feature checklist */}
      <div className="px-5 py-4 border-b border-gray-100">
        <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold mb-1">
          Feature Checklist
        </p>
        <div className="space-y-0">
          {shingle.features.map((f) => (
            <FeatureRow key={f.label} feature={f} />
          ))}
        </div>
      </div>

      {/* pros & cons */}
      <div className="px-5 py-4 border-b border-gray-100 space-y-3">
        <div>
          <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold mb-1.5">Pros</p>
          <ul className="space-y-1">
            {shingle.pros.map((p) => (
              <li key={p} className="flex items-start gap-2 text-xs text-gray-600 leading-relaxed">
                <i className="ri-add-line text-green-500 mt-0.5 flex-shrink-0" />
                {p}
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold mb-1.5">Cons</p>
          <ul className="space-y-1">
            {shingle.cons.map((c) => (
              <li key={c} className="flex items-start gap-2 text-xs text-gray-500 leading-relaxed">
                <i className="ri-subtract-line text-gray-400 mt-0.5 flex-shrink-0" />
                {c}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* best for */}
      <div className="px-5 py-4 bg-gray-50/50">
        <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold mb-1.5">Best For</p>
        <p className="text-gray-600 text-xs leading-relaxed">{shingle.bestFor}</p>
      </div>

      {/* CTA */}
      <div className="px-5 py-4 mt-auto">
        <button
          onClick={onSelect}
          className={`w-full inline-flex items-center justify-center gap-2 font-bold text-xs uppercase tracking-widest px-4 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
            isRec
              ? 'bg-orange hover:bg-orange-dark text-white'
              : 'border border-gray-300 hover:border-gray-400 text-charcoal-deep'
          }`}
        >
          {isSelected ? (
            <>
              <i className="ri-check-line" />
              Selected for Estimate
            </>
          ) : (
            <>
              <i className="ri-add-line" />
              Add to My Estimate
            </>
          )}
        </button>
      </div>
    </div>
  );
}

/* ─── main component ─── */
export default function MaterialComparison() {
  const [selectedKey, setSelectedKey] = useState<string>(INSPECTOR_MATERIAL_RECOMMENDATION.recommendedKey);
  const [showProjection, setShowProjection] = useState(false);

  const rec = SHINGLE_COMPARISON.find(
    (s) => s.key === INSPECTOR_MATERIAL_RECOMMENDATION.recommendedKey
  )!;
  const alt = SHINGLE_COMPARISON.find(
    (s) => s.key === INSPECTOR_MATERIAL_RECOMMENDATION.alternativeKey
  )!;

  return (
    <div className="space-y-10">
      {/* ── Inspector recommendation banner ── */}
      <div className="bg-charcoal-deep rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center gap-5">
        <div className="w-12 h-12 flex-shrink-0 flex items-center justify-center bg-orange/20 rounded-xl">
          <i className="ri-user-star-line text-orange text-xl" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <h4 className="font-display text-white text-sm uppercase tracking-wider">
              Inspector Recommendation
            </h4>
            <span className="px-2 py-0.5 bg-orange text-white text-[9px] font-bold uppercase tracking-wider rounded">
              Based on Your 14-Year Roof
            </span>
          </div>
          <p className="text-white/60 text-xs leading-relaxed">
            {INSPECTOR_MATERIAL_RECOMMENDATION.reason}
          </p>
        </div>
        <div className="flex-shrink-0 text-right hidden md:block">
          <p className="font-display text-white text-lg uppercase tracking-wider">{rec.name}</p>
          <p className="text-white/40 text-[10px]">{rec.warranty}</p>
        </div>
      </div>

      {/* ── 3-column card grid ── */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 items-stretch">
        {SHINGLE_COMPARISON.map((shingle) => (
          <ShingleCard
            key={shingle.key}
            shingle={shingle}
            isRec={shingle.key === INSPECTOR_MATERIAL_RECOMMENDATION.recommendedKey}
            isSelected={selectedKey === shingle.key}
            onSelect={() => setSelectedKey(shingle.key)}
          />
        ))}
      </div>

      {/* ── Alternative recommendation ── */}
      <div className="bg-amber-50/60 border border-amber-200 rounded-xl p-5 flex flex-col sm:flex-row items-start gap-4">
        <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center bg-amber-100 rounded-lg">
          <i className="ri-lightbulb-line text-amber-600 text-lg" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1">
            Also Consider: {alt.name}
          </p>
          <p className="text-gray-600 text-xs leading-relaxed">
            {INSPECTOR_MATERIAL_RECOMMENDATION.alternativeReason}
          </p>
        </div>
      </div>

      {/* ── Lifetime Cost Projection toggle ── */}
      <div>
        <button
          onClick={() => setShowProjection(!showProjection)}
          className="w-full flex items-center justify-between bg-white border border-gray-200 rounded-xl px-5 py-4 hover:border-gray-300 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 flex items-center justify-center bg-charcoal-deep rounded-lg">
              <i className="ri-bar-chart-grouped-line text-white text-sm" />
            </div>
            <div className="text-left">
              <p className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
                22-Year Lifetime Cost Projection
              </p>
              <p className="text-gray-400 text-[10px]">
                See total spend including replacement cycles and maintenance
              </p>
            </div>
          </div>
          <div className="w-8 h-8 flex items-center justify-center rounded-lg bg-gray-100 flex-shrink-0">
            <i className={`ri-arrow-down-s-line text-gray-500 text-sm transition-transform duration-200 ${showProjection ? 'rotate-180' : ''}`} />
          </div>
        </button>

        {showProjection && (
          <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4 animate-[fadeIn_0.25s_ease-out]">
            {COST_PROJECTION_22_YEAR.map((proj) => {
              const shingle = SHINGLE_COMPARISON.find((s) => s.key === proj.key)!;
              const isRec = proj.key === INSPECTOR_MATERIAL_RECOMMENDATION.recommendedKey;
              return (
                <ProjectionRow
                  key={proj.key}
                  shingle={shingle}
                  projection={proj}
                  isRec={isRec}
                />
              );
            })}
          </div>
        )}
      </div>

      {/* ── Summary CTA ── */}
      <div className="flex flex-col sm:flex-row gap-3">
        <a
          href="#compare-estimates"
          className="flex-1 inline-flex items-center justify-center gap-2 bg-orange hover:bg-orange-dark text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
        >
          <i className="ri-file-list-3-line" />
          Apply Selection to Estimate
        </a>
        <a
          href="#schedule-repair"
          className="flex-1 inline-flex items-center justify-center gap-2 border border-gray-300 hover:border-gray-400 text-charcoal-deep font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
        >
          <i className="ri-calendar-check-line" />
          Schedule with Selected Material
        </a>
      </div>
    </div>
  );
}