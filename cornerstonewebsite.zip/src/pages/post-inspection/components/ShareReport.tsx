import { useState, useRef, useCallback } from 'react';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

/* ─── types ─── */
type ShareMethod = 'email' | 'sms' | 'copy' | 'print';

interface ShareOption {
  key: string;
  label: string;
  description: string;
  checked: boolean;
}

/* ─── constants ─── */
const SHARE_OPTIONS: ShareOption[] = [
  { key: 'photo_report', label: 'Photo Report', description: 'All 14 photos with severity labels & inspector notes', checked: true },
  { key: 'estimate_breakdown', label: 'Estimate Breakdown', description: 'Repair-only, partial, and full replacement costs', checked: true },
  { key: 'financing_options', label: 'Financing Options', description: 'Payment plans, APR, and pre-approval link', checked: true },
  { key: 'insurance_docs', label: 'Insurance Documents', description: 'Claim number, adjuster notes, uploaded files', checked: false },
  { key: 'inspector_notes', label: 'Inspector Notes', description: 'Full written report from Mike R.', checked: true },
];

const EMAIL_FORM_URL = WEB3FORMS_ENDPOINT;
const SMS_FORM_URL = WEB3FORMS_ENDPOINT;

/* ─── helper: copy to clipboard ─── */
function useCopyToClipboard(text: string) {
  const [copied, setCopied] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const copy = useCallback(() => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => setCopied(false), 2000);
    });
  }, [text]);

  return { copied, copy };
}

/* ─── main component ─── */
export default function ShareReport() {
  const [activeMethod, setActiveMethod] = useState<ShareMethod>('email');
  const [options, setOptions] = useState<ShareOption[]>(SHARE_OPTIONS);
  const [emailSubmitted, setEmailSubmitted] = useState(false);
  const [smsSubmitted, setSmsSubmitted] = useState(false);
  const [emailError, setEmailError] = useState('');
  const [smsError, setSmsError] = useState('');

  const shareLink = typeof window !== 'undefined'
    ? `${window.location.origin}/post-inspection?share=report&id=ins-2026-0428`
    : 'https://cornerstoneconstructionroofing.com/post-inspection?share=report&id=ins-2026-0428';

  const { copied, copy } = useCopyToClipboard(shareLink);

  const selectedCount = options.filter((o) => o.checked).length;
  const selectedLabels = options.filter((o) => o.checked).map((o) => o.label);

  const toggleOption = (key: string) => {
    setOptions((prev) =>
      prev.map((o) => (o.key === key ? { ...o, checked: !o.checked } : o))
    );
  };

  const handleEmailSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const emailInput = form.elements.namedItem('recipient_email') as HTMLInputElement;
    if (!emailInput?.value || !emailInput.value.includes('@')) {
      setEmailError('Please enter a valid email address');
      return;
    }
    setEmailError('');
    const data = new FormData(form);
    data.append('access_key', WEB3FORMS_ACCESS_KEY);
    fetch(form.action, {
      method: 'POST',
      body: new URLSearchParams(data as unknown as Record<string, string>),
    })
      .then(() => setEmailSubmitted(true))
      .catch(() => setEmailSubmitted(true));
  };

  const handleSmsSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const phoneInput = form.elements.namedItem('recipient_phone') as HTMLInputElement;
    if (!phoneInput?.value || phoneInput.value.replace(/\D/g, '').length < 10) {
      setSmsError('Please enter a valid 10-digit phone number');
      return;
    }
    setSmsError('');
    const data = new FormData(form);
    data.append('access_key', WEB3FORMS_ACCESS_KEY);
    fetch(form.action, {
      method: 'POST',
      body: new URLSearchParams(data as unknown as Record<string, string>),
    })
      .then(() => setSmsSubmitted(true))
      .catch(() => setSmsSubmitted(true));
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-white border border-gray-200 rounded-2xl p-6 md:p-8 shadow-sm">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-8">
        <div>
          <h3 className="font-display text-charcoal-deep text-lg md:text-xl uppercase tracking-wider mb-1">
            Share Report
          </h3>
          <p className="text-gray-500 text-xs leading-relaxed max-w-lg">
            Send your inspection report, estimates, and financing details to a spouse, co-owner, property manager, or insurance agent. They will receive a read-only link.
          </p>
        </div>
        <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-xl px-4 py-2 flex-shrink-0">
          <div className="w-2 h-2 rounded-full bg-green-500" />
          <span className="text-gray-500 text-[10px] uppercase tracking-wider font-semibold">
            {selectedCount} sections selected
          </span>
        </div>
      </div>

      {/* Method Tabs */}
      <div className="flex flex-wrap gap-2 mb-8">
        {[
          { key: 'email' as ShareMethod, icon: 'ri-mail-send-line', label: 'Email' },
          { key: 'sms' as ShareMethod, icon: 'ri-smartphone-line', label: 'Text Message' },
          { key: 'copy' as ShareMethod, icon: 'ri-link', label: 'Copy Link' },
          { key: 'print' as ShareMethod, icon: 'ri-printer-line', label: 'Print' },
        ].map((m) => (
          <button
            key={m.key}
            onClick={() => setActiveMethod(m.key)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-xs font-bold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
              activeMethod === m.key
                ? 'bg-charcoal-deep text-white border-charcoal-deep'
                : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'
            }`}
          >
            <i className={`${m.icon} text-sm`} />
            {m.label}
          </button>
        ))}
      </div>

      {/* Email Form */}
      {activeMethod === 'email' && (
        <div>
          {emailSubmitted ? (
            <div className="text-center py-8">
              <div className="w-14 h-14 flex items-center justify-center bg-green-50 rounded-full mx-auto mb-4">
                <i className="ri-checkbox-circle-fill text-green-500 text-2xl" />
              </div>
              <h4 className="font-display text-charcoal-deep text-lg uppercase tracking-wider mb-2">
                Email Sent
              </h4>
              <p className="text-gray-500 text-sm max-w-md mx-auto mb-6">
                Your inspection report has been emailed. The recipient will receive a secure link to view your selected sections.
              </p>
              <div className="bg-gray-50 border border-gray-100 rounded-xl p-4 text-left max-w-md mx-auto mb-6">
                <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-2">
                  Included in this email
                </p>
                <ul className="space-y-1.5">
                  {selectedLabels.map((label) => (
                    <li key={label} className="flex items-center gap-2 text-sm text-gray-600">
                      <i className="ri-check-line text-green-500" />
                      {label}
                    </li>
                  ))}
                </ul>
              </div>
              <button
                onClick={() => setEmailSubmitted(false)}
                className="text-orange text-xs font-semibold uppercase tracking-wider hover:underline underline-offset-4 cursor-pointer"
              >
                Send to Another Email
              </button>
            </div>
          ) : (
            <form
              data-readdy-form
              id="share-report-email"
              action={EMAIL_FORM_URL}
              method="POST"
              onSubmit={handleEmailSubmit}
              className="space-y-5"
            >
              {/* Recipient */}
              <div>
                <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                  Recipient Email *
                </label>
                <input
                  type="email"
                  name="recipient_email"
                  required
                  placeholder="spouse@email.com"
                  className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                />
                {emailError && (
                  <p className="text-red-500 text-xs mt-1.5">{emailError}</p>
                )}
                <p className="text-gray-400 text-[10px] mt-1.5">
                  Separate multiple emails with commas
                </p>
              </div>

              {/* Your info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    name="sender_name"
                    required
                    placeholder="John Smith"
                    className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                  />
                </div>
                <div>
                  <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                    Your Email *
                  </label>
                  <input
                    type="email"
                    name="sender_email"
                    required
                    placeholder="you@email.com"
                    className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                  />
                </div>
              </div>

              {/* Optional message */}
              <div>
                <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                  Personal Message (Optional)
                </label>
                <textarea
                  name="personal_message"
                  rows={2}
                  maxLength={250}
                  placeholder="Hey, here is our roof inspection report from Corner Stone. Take a look and let me know what you think..."
                  className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
                />
                <p className="text-gray-400 text-[10px] mt-1.5">
                  A default message will be sent if you leave this blank
                </p>
              </div>

              {/* Content Selection */}
              <div>
                <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-3">
                  What to Include
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {options.map((opt) => (
                    <button
                      key={opt.key}
                      type="button"
                      onClick={() => toggleOption(opt.key)}
                      className={`flex items-start gap-3 text-left border rounded-xl p-3 transition-all cursor-pointer ${
                        opt.checked
                          ? 'border-orange bg-orange/5'
                          : 'border-gray-200 bg-white hover:border-gray-300'
                      }`}
                    >
                      <div className="flex-shrink-0 mt-0.5">
                        <div
                          className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors ${
                            opt.checked
                              ? 'border-orange bg-orange'
                              : 'border-gray-300'
                          }`}
                        >
                          {opt.checked && <i className="ri-check-line text-white text-xs" />}
                        </div>
                      </div>
                      <div className="min-w-0">
                        <span className="text-charcoal-deep text-xs font-semibold block">{opt.label}</span>
                        <span className="text-gray-400 text-[10px] block mt-0.5">{opt.description}</span>
                      </div>
                      <input type="hidden" name={`include_${opt.key}`} value={opt.checked ? 'yes' : 'no'} />
                    </button>
                  ))}
                </div>
              </div>

              {/* Hidden link */}
              <input type="hidden" name="share_link" value={shareLink} />
              <input type="hidden" name="inspection_date" value="April 28, 2026" />
              <input type="hidden" name="property_address" value="1842 Oakmont Drive, Evansville, IN 47714" />
              <input type="hidden" name="inspector_name" value="Mike R." />

              {/* Submit */}
              <button
                type="submit"
                className="w-full bg-charcoal-deep hover:bg-charcoal text-white font-bold text-sm uppercase tracking-widest py-3.5 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-mail-send-line" />
                Send Report via Email
              </button>
            </form>
          )}
        </div>
      )}

      {/* SMS Form */}
      {activeMethod === 'sms' && (
        <div>
          {smsSubmitted ? (
            <div className="text-center py-8">
              <div className="w-14 h-14 flex items-center justify-center bg-green-50 rounded-full mx-auto mb-4">
                <i className="ri-checkbox-circle-fill text-green-500 text-2xl" />
              </div>
              <h4 className="font-display text-charcoal-deep text-lg uppercase tracking-wider mb-2">
                Text Message Sent
              </h4>
              <p className="text-gray-500 text-sm max-w-md mx-auto mb-6">
                A text message with your report link has been sent. The recipient can tap the link to view your selected sections on any device.
              </p>
              <div className="bg-gray-50 border border-gray-100 rounded-xl p-4 text-left max-w-md mx-auto mb-6">
                <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-2">
                  Included in this text
                </p>
                <ul className="space-y-1.5">
                  {selectedLabels.map((label) => (
                    <li key={label} className="flex items-center gap-2 text-sm text-gray-600">
                      <i className="ri-check-line text-green-500" />
                      {label}
                    </li>
                  ))}
                </ul>
              </div>
              <button
                onClick={() => setSmsSubmitted(false)}
                className="text-orange text-xs font-semibold uppercase tracking-wider hover:underline underline-offset-4 cursor-pointer"
              >
                Send to Another Number
              </button>
            </div>
          ) : (
            <form
              data-readdy-form
              id="share-report-sms"
              action={SMS_FORM_URL}
              method="POST"
              onSubmit={handleSmsSubmit}
              className="space-y-5"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                    Recipient Phone *
                  </label>
                  <input
                    type="tel"
                    name="recipient_phone"
                    required
                    placeholder="(812) 213-5997"
                    className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                  />
                  {smsError && (
                    <p className="text-red-500 text-xs mt-1.5">{smsError}</p>
                  )}
                </div>
                <div>
                  <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    name="sender_name"
                    required
                    placeholder="John Smith"
                    className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                  />
                </div>
              </div>

              <div>
                <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                  Your Phone (for reply) *
                </label>
                <input
                  type="tel"
                  name="sender_phone"
                  required
                  placeholder="(812) 213-5997"
                  className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                />
              </div>

              {/* Content Selection */}
              <div>
                <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-3">
                  What to Include
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {options.map((opt) => (
                    <button
                      key={opt.key}
                      type="button"
                      onClick={() => toggleOption(opt.key)}
                      className={`flex items-start gap-3 text-left border rounded-xl p-3 transition-all cursor-pointer ${
                        opt.checked
                          ? 'border-orange bg-orange/5'
                          : 'border-gray-200 bg-white hover:border-gray-300'
                      }`}
                    >
                      <div className="flex-shrink-0 mt-0.5">
                        <div
                          className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors ${
                            opt.checked
                              ? 'border-orange bg-orange'
                              : 'border-gray-300'
                          }`}
                        >
                          {opt.checked && <i className="ri-check-line text-white text-xs" />}
                        </div>
                      </div>
                      <div className="min-w-0">
                        <span className="text-charcoal-deep text-xs font-semibold block">{opt.label}</span>
                        <span className="text-gray-400 text-[10px] block mt-0.5">{opt.description}</span>
                      </div>
                      <input type="hidden" name={`include_${opt.key}`} value={opt.checked ? 'yes' : 'no'} />
                    </button>
                  ))}
                </div>
              </div>

              {/* Preview of text message */}
              <div className="bg-gray-50 border border-gray-200 rounded-xl p-4">
                <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-2">
                  Preview Text Message
                </p>
                <p className="text-gray-600 text-sm leading-relaxed font-mono bg-white rounded-lg p-3 border border-gray-100">
                  Hi! John Smith shared their roof inspection report with you from Corner Stone Construction & Roofing. View photos, estimates & financing options here: {shareLink.slice(0, 50)}...
                </p>
              </div>

              <input type="hidden" name="share_link" value={shareLink} />
              <input type="hidden" name="inspection_date" value="April 28, 2026" />
              <input type="hidden" name="property_address" value="1842 Oakmont Drive, Evansville, IN 47714" />

              <button
                type="submit"
                className="w-full bg-charcoal-deep hover:bg-charcoal text-white font-bold text-sm uppercase tracking-widest py-3.5 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-smartphone-line" />
                Send Report via Text
              </button>
            </form>
          )}
        </div>
      )}

      {/* Copy Link */}
      {activeMethod === 'copy' && (
        <div className="text-center py-4">
          <div className="bg-gray-50 border border-gray-200 rounded-xl p-5 mb-6 max-w-lg mx-auto">
            <div className="flex items-center justify-between gap-3 mb-3">
              <span className="text-gray-500 text-[10px] uppercase tracking-widest font-semibold">
                Secure Share Link
              </span>
              <span className="px-2 py-0.5 bg-green-50 border border-green-200 rounded text-[10px] text-green-600 font-semibold uppercase tracking-wider">
                Active for 30 days
              </span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={shareLink}
                className="flex-1 bg-white border border-gray-200 rounded-lg px-3 py-2.5 text-gray-600 text-xs font-mono focus:outline-none"
              />
              <button
                onClick={copy}
                className={`px-4 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                  copied
                    ? 'bg-green-500 text-white'
                    : 'bg-charcoal-deep text-white hover:bg-charcoal'
                }`}
              >
                <i className={`${copied ? 'ri-check-line' : 'ri-clipboard-line'} text-sm`} />
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>
          </div>

          {/* Content preview */}
          <div className="text-left max-w-lg mx-auto">
            <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-3">
              This link includes
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {options.map((opt) => (
                <button
                  key={opt.key}
                  type="button"
                  onClick={() => toggleOption(opt.key)}
                  className={`flex items-start gap-3 text-left border rounded-xl p-3 transition-all cursor-pointer ${
                    opt.checked
                      ? 'border-orange bg-orange/5'
                      : 'border-gray-200 bg-white hover:border-gray-300'
                  }`}
                >
                  <div className="flex-shrink-0 mt-0.5">
                    <div
                      className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors ${
                        opt.checked
                          ? 'border-orange bg-orange'
                          : 'border-gray-300'
                      }`}
                    >
                      {opt.checked && <i className="ri-check-line text-white text-xs" />}
                    </div>
                  </div>
                  <div>
                    <span className="text-charcoal-deep text-xs font-semibold">{opt.label}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* QR code hint */}
          <div className="mt-6 max-w-lg mx-auto bg-charcoal-deep rounded-xl p-5 flex items-center gap-4">
            <div className="w-12 h-12 flex items-center justify-center bg-white/10 rounded-lg flex-shrink-0">
              <i className="ri-qr-code-line text-white text-xl" />
            </div>
            <div className="text-left">
              <p className="text-white text-xs font-semibold uppercase tracking-wider">
                Scan to view on mobile
              </p>
              <p className="text-white/50 text-[10px] mt-0.5">
                Anyone with this link can view your report on their phone — no login required
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Print */}
      {activeMethod === 'print' && (
        <div className="text-center py-4">
          <div className="w-14 h-14 flex items-center justify-center bg-gray-50 rounded-full mx-auto mb-4">
            <i className="ri-printer-line text-charcoal-deep text-2xl" />
          </div>
          <h4 className="font-display text-charcoal-deep text-lg uppercase tracking-wider mb-2">
            Print Report
          </h4>
          <p className="text-gray-500 text-sm max-w-md mx-auto mb-6">
            Generate a printer-friendly version of your inspection report, estimates, and financing details. Perfect for insurance adjusters or your personal records.
          </p>

          {/* Content Selection */}
          <div className="text-left max-w-lg mx-auto mb-6">
            <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-3">
              Sections to print
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {options.map((opt) => (
                <button
                  key={opt.key}
                  type="button"
                  onClick={() => toggleOption(opt.key)}
                  className={`flex items-start gap-3 text-left border rounded-xl p-3 transition-all cursor-pointer ${
                    opt.checked
                      ? 'border-orange bg-orange/5'
                      : 'border-gray-200 bg-white hover:border-gray-300'
                  }`}
                >
                  <div className="flex-shrink-0 mt-0.5">
                    <div
                      className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors ${
                        opt.checked
                          ? 'border-orange bg-orange'
                          : 'border-gray-300'
                      }`}
                    >
                      {opt.checked && <i className="ri-check-line text-white text-xs" />}
                    </div>
                  </div>
                  <div>
                    <span className="text-charcoal-deep text-xs font-semibold">{opt.label}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-2 bg-charcoal-deep hover:bg-charcoal text-white font-bold text-sm uppercase tracking-widest px-8 py-3.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-printer-line" />
            Print Selected Sections
          </button>
        </div>
      )}
    </div>
  );
}