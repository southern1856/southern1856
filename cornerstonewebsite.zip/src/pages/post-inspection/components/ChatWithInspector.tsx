import { useState, useRef, useEffect, useCallback } from 'react';

/* ─── types ─── */
interface Message {
  id: string;
  sender: 'user' | 'inspector';
  text: string;
  timestamp: string;
}

interface QuickReply {
  key: string;
  label: string;
}

/* ─── mock inspector responses keyed by topic ─── */
const INSPECTOR_RESPONSES: Record<string, string> = {
  repair_or_replace: `Based on what I saw up there, you do NOT need a full replacement right now. The roof structure is solid — it\'s just storm damage on the surface. Here\'s my honest take:\n\n**Repair** — Fixes the hail bruises, missing shingles, and re-seals the flashing. You\'re looking at $2,400–$4,800. The roof still has 6–10 years of life left after that.\n\n**Replace** — Only makes sense if you want to upgrade materials or if your insurance is covering it. It\'d be $14,500–$18,200.\n\nMy recommendation? Repair now, schedule a follow-up in 12 months. If more issues show up by then, we can revisit replacement.`,

  urgency: `The **missing shingles on the west eave** are the most urgent — that exposed underlayment can let water in with the next hard rain. I\'d get that patched within 3–5 days.\n\nThe **hail damage** is localized and the underlayment is still intact underneath, so it\'s not an emergency, but I wouldn\'t wait more than 2–3 weeks. Every storm makes it worse.\n\nThe **flashing and skylight seal** are \`warning\` level — plan to fix them within 6 months, ideally bundled with the hail repair so you only pay one trip charge.`,

  insurance: `Great question — and yes, this is exactly what homeowner\'s insurance is for. Here\'s what typically happens:\n\n1. **File a claim** with your provider and mention \`hail and wind damage\`.\n2. **The adjuster** schedules a visit (usually within 5–10 days).\n3. **We meet the adjuster on-site** and walk them through every photo and finding. We do this for free — it\'s part of our service.\n4. **Insurance pays the Actual Cash Value (ACV)** first, then releases the recoverable depreciation once work is completed.\n\nYour hail damage + missing shingles should absolutely be covered. The flashing re-seal might be classified as maintenance — but we always argue for it. Want me to connect you with our claims specialist?`,

  timeline: `For the **repair scope** (hail + missing shingles + flashing):\n\n- **Prep & material delivery:** 1–2 days after you approve\n- **Actual work:** 1 day for a crew of 3\n- **Cleanup & inspection:** Same day\n\nSo from \`yes\` to \`done\` is typically **3–5 business days** total.\n\nIf you go with **full replacement**, it\'s 2–3 days of work plus a day for dumpster and delivery — about **5–7 days** total.\n\nWe also offer emergency tarping if that exposed eave starts leaking before we can get out there.`,

  wait: `I won\'t sugarcoat it — waiting has real risks:\n\n- **Missing shingles** → Water gets under the underlayment → plywood rot → mold in the attic. A $400 patch becomes a $2,000 deck repair.\n- **Hail bruises** → Granules wash off → UV breaks down the asphalt mat → the whole section fails faster.\n- **Flashing gaps** → Slow leak into your chimney chase → drywall damage inside.\n\nThe good news? The damage is localized. Catch it now and you\'re fine. Wait through another storm season and you\'re rolling the dice. I\'ve seen $3,000 repairs turn into $15,000 replacements because the homeowner waited 8 months.`,

  photos: `You\'ve got **8 documented photos** in your report:\n\n1. Roof overview (north slope)\n2. Hail impact — Section A (ridge line)\n3. Hail impact — Section B (near valley)\n4. Missing shingles — west eave ⚠️\n5. Chimney flashing rust\n6. Gutter system condition\n7. Attic ventilation\n8. Skylight seal wear\n\nClick any photo in the gallery above to zoom in. The severity labels (Critical / Warning / Info) are color-coded so you know what to prioritize.\n\nWant me to walk through any specific photo in detail?`,

  financing: `We partner with a few financing companies that specialize in home improvement loans. Here\'s the breakdown:\n\n- **$0 down** on approved credit\n- **Rates start around 9.5% APR** (can be lower with excellent credit)\n- **Terms:** 12 to 60 months\n- **Approval** usually comes back within 1 business hour\n- **No prepayment penalty** — pay it off early anytime\n\nFor your repair estimate ($2,400–$4,800), you\'re looking at roughly **$70–$140/month** on a 36-month plan. That\'s less than most people spend on streaming services.\n\nThere\'s a financing pre-approval form right on this page if you want to lock in a rate before scheduling.`,

  warranty: `Here\'s what you get with us:\n\n**Repair Work:**\n- 2-year workmanship warranty on all repairs\n- Manufacturer warranty on any replacement shingles (typically 25–50 years)\n- 1-year leak-free guarantee — if water gets in where we worked, we fix it free\n\n**Full Replacement:**\n- 10-year workmanship warranty\n- Lifetime limited material warranty (transferable if you sell)\n- Annual free inspection for 3 years post-install\n\nWe also back everything with our **Good Neighbor Guarantee** — if you\'re not happy, we make it right. No arguments.`,

  custom: `That\'s a great question — let me look at your specific report and get back to you with a detailed answer. I\'ll also flag anything that might affect your insurance claim or repair timeline.\n\nIn the meantime, feel free to check the **Compare Estimates** and **Payment Calculator** sections on this page. They\'re built from your actual inspection data.`,
};

const QUICK_REPLIES: QuickReply[] = [
  { key: 'repair_or_replace', label: 'Should I repair or replace?' },
  { key: 'urgency', label: 'How urgent is the damage?' },
  { key: 'insurance', label: 'Will insurance cover this?' },
  { key: 'timeline', label: 'How long will repairs take?' },
  { key: 'wait', label: 'What if I wait?' },
  { key: 'photos', label: 'Walk me through the photos' },
  { key: 'financing', label: 'Tell me about financing' },
  { key: 'warranty', label: 'What warranty do I get?' },
];

/* ─── helpers ─── */
function formatTime(): string {
  const now = new Date();
  return now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
}

function typingDelay(text: string): number {
  return Math.min(Math.max(text.length * 25, 800), 2800);
}

/* ─── initial greeting ─── */
const INITIAL_MESSAGES: Message[] = [
  {
    id: 'greeting-1',
    sender: 'inspector',
    text: `Hi! I\'m Mike — the inspector who was on your roof this past Tuesday. I\'m online and happy to answer any questions about your report, the photos, or next steps.`,
    timestamp: formatTime(),
  },
  {
    id: 'greeting-2',
    sender: 'inspector',
    text: `I can see your full inspection data right here, so I\'ll be able to reference specific findings — like the hail damage on the north slope or the missing shingles on the west eave. What would you like to know?`,
    timestamp: formatTime(),
  },
];

/* ─── main component ─── */
export default function ChatWithInspector() {
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [inspectorOnline, setInspectorOnline] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping, scrollToBottom]);

  /* simulate inspector typing + response */
  const sendInspectorReply = useCallback((replyKey: string, customText?: string) => {
    setIsTyping(true);
    const text = customText ?? INSPECTOR_RESPONSES[replyKey] ?? INSPECTOR_RESPONSES.custom;
    const delay = typingDelay(text);

    setTimeout(() => {
      setIsTyping(false);
      setMessages((prev) => [
        ...prev,
        {
          id: `inspector-${Date.now()}`,
          sender: 'inspector',
          text,
          timestamp: formatTime(),
        },
      ]);
    }, delay);
  }, []);

  const handleQuickReply = (key: string) => {
    const reply = QUICK_REPLIES.find((r) => r.key === key);
    if (!reply) return;

    setMessages((prev) => [
      ...prev,
      {
        id: `user-${Date.now()}`,
        sender: 'user',
        text: reply.label,
        timestamp: formatTime(),
      },
    ]);

    sendInspectorReply(key);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const text = inputValue.trim();
    if (!text) return;

    setMessages((prev) => [
      ...prev,
      {
        id: `user-${Date.now()}`,
        sender: 'user',
        text,
        timestamp: formatTime(),
      },
    ]);

    setInputValue('');

    /* simple keyword matching for mock responses */
    const lower = text.toLowerCase();
    let matchedKey = 'custom';
    if (lower.includes('repair') && lower.includes('replace')) matchedKey = 'repair_or_replace';
    else if (lower.includes('urgent') || lower.includes('wait') || lower.includes('how long')) matchedKey = 'urgency';
    else if (lower.includes('insurance') || lower.includes('cover') || lower.includes('claim')) matchedKey = 'insurance';
    else if (lower.includes('timeline') || lower.includes('how long') || lower.includes('time')) matchedKey = 'timeline';
    else if (lower.includes('wait') || lower.includes('delay') || lower.includes('later')) matchedKey = 'wait';
    else if (lower.includes('photo') || lower.includes('picture') || lower.includes('image')) matchedKey = 'photos';
    else if (lower.includes('financ') || lower.includes('payment') || lower.includes('monthly') || lower.includes('loan')) matchedKey = 'financing';
    else if (lower.includes('warranty') || lower.includes('guarantee')) matchedKey = 'warranty';

    sendInspectorReply(matchedKey);
  };

  /* simulate inspector going offline briefly */
  useEffect(() => {
    const interval = setInterval(() => {
      setInspectorOnline((prev) => {
        if (prev && Math.random() > 0.92) return false;
        if (!prev && Math.random() > 0.6) return true;
        return prev;
      });
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden flex flex-col" style={{ maxHeight: '720px' }}>
      {/* ── Header ── */}
      <div className="bg-charcoal-deep px-5 py-4 flex items-center gap-3">
        <div className="relative">
          <div className="w-10 h-10 flex items-center justify-center bg-orange/20 rounded-full">
            <i className="ri-user-star-line text-orange text-lg" />
          </div>
          <span
            className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-charcoal-deep ${
              inspectorOnline ? 'bg-green-500' : 'bg-gray-400'
            }`}
          />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h4 className="font-display text-white text-sm uppercase tracking-wider">
              Inspector Mike R.
            </h4>
            <span className="px-1.5 py-0.5 bg-orange/20 text-orange text-[9px] font-bold uppercase tracking-wider rounded">
              Certified
            </span>
          </div>
          <p className="text-white/40 text-[10px] mt-0.5">
            {inspectorOnline ? 'Online now — replies in under a minute' : 'Away — back shortly'}
          </p>
        </div>
        <div className="hidden sm:flex items-center gap-1.5 text-white/30 text-[10px] uppercase tracking-wider">
          <i className="ri-shield-check-line" />
          <span>Inspection #042826</span>
        </div>
      </div>

      {/* ── Messages area ── */}
      <div className="flex-1 overflow-y-auto px-4 md:px-5 py-4 space-y-4 bg-gray-50/50" style={{ minHeight: '320px', maxHeight: '480px' }}>
        {/* Context banner */}
        <div className="flex items-start gap-2 bg-orange/5 border border-orange/10 rounded-xl px-3 py-2.5">
          <i className="ri-information-line text-orange text-sm mt-0.5 flex-shrink-0" />
          <p className="text-orange/80 text-[11px] leading-relaxed">
            Mike has access to your full inspection report from April 28, 2026. Ask him anything about the findings, photos, estimates, or next steps.
          </p>
        </div>

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`max-w-[85%] sm:max-w-[75%] ${msg.sender === 'user' ? 'order-1' : 'order-1'}`}>
              {/* Avatar + name row for inspector */}
              {msg.sender === 'inspector' && (
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-5 h-5 flex items-center justify-center bg-orange/10 rounded-full">
                    <i className="ri-user-star-line text-orange text-[10px]" />
                  </div>
                  <span className="text-[10px] text-gray-400 uppercase tracking-wider font-semibold">Mike R.</span>
                  <span className="text-[10px] text-gray-300">{msg.timestamp}</span>
                </div>
              )}

              <div
                className={`rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                  msg.sender === 'user'
                    ? 'bg-orange text-white rounded-br-none'
                    : 'bg-white border border-gray-200 text-gray-700 rounded-bl-none shadow-sm'
                }`}
              >
                {msg.text.split('\n').map((line, i) => {
                  if (line.startsWith('**') && line.endsWith('**')) {
                    return (
                      <p key={i} className="font-semibold text-charcoal-deep mt-2 mb-1">
                        {line.replace(/\*\*/g, '')}
                      </p>
                    );
                  }
                  if (line.startsWith('- ')) {
                    return (
                      <p key={i} className="pl-3 text-gray-600 text-xs leading-relaxed">
                        <span className="text-orange mr-1">•</span>
                        {line.replace('- ', '')}
                      </p>
                    );
                  }
                  if (line.match(/^\d\./)) {
                    return (
                      <p key={i} className="pl-3 text-gray-600 text-xs leading-relaxed">
                        <span className="text-orange font-semibold mr-1">{line.slice(0, 2)}</span>
                        {line.slice(2)}
                      </p>
                    );
                  }
                  if (line.trim() === '') {
                    return <div key={i} className="h-1" />;
                  }
                  return (
                    <p key={i} className="text-xs leading-relaxed">
                      {line}
                    </p>
                  );
                })}
              </div>

              {msg.sender === 'user' && (
                <p className="text-right text-[10px] text-gray-300 mt-1">{msg.timestamp}</p>
              )}
            </div>
          </div>
        ))}

        {/* Typing indicator */}
        {isTyping && (
          <div className="flex justify-start">
            <div className="max-w-[75%]">
              <div className="flex items-center gap-2 mb-1">
                <div className="w-5 h-5 flex items-center justify-center bg-orange/10 rounded-full">
                  <i className="ri-user-star-line text-orange text-[10px]" />
                </div>
                <span className="text-[10px] text-gray-400 uppercase tracking-wider font-semibold">Mike R.</span>
              </div>
              <div className="bg-white border border-gray-200 rounded-2xl rounded-bl-none px-4 py-3 shadow-sm">
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-1.5 h-1.5 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* ── Quick Replies ── */}
      <div className="px-4 md:px-5 py-3 bg-white border-t border-gray-100">
        <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-2">
          Common Questions
        </p>
        <div className="flex flex-wrap gap-2">
          {QUICK_REPLIES.map((qr) => (
            <button
              key={qr.key}
              onClick={() => handleQuickReply(qr.key)}
              disabled={isTyping}
              className="px-3 py-1.5 bg-gray-50 hover:bg-orange/10 border border-gray-200 hover:border-orange/30 rounded-lg text-[11px] text-gray-600 hover:text-orange font-medium transition-all cursor-pointer whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {qr.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Input area ── */}
      <form
        onSubmit={handleSubmit}
        className="px-4 md:px-5 py-3 bg-white border-t border-gray-100 flex items-center gap-2"
      >
        <input
          ref={inputRef}
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Ask Mike anything about your report..."
          disabled={isTyping}
          maxLength={200}
          className="flex-1 bg-gray-100 border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/30 focus:border-orange/30 transition-all disabled:opacity-60"
        />
        <button
          type="submit"
          disabled={isTyping || !inputValue.trim()}
          className="w-10 h-10 flex items-center justify-center bg-orange hover:bg-orange-dark disabled:bg-gray-200 text-white rounded-xl transition-colors flex-shrink-0 cursor-pointer disabled:cursor-not-allowed"
        >
          <i className="ri-send-plane-fill text-sm" />
        </button>
      </form>

      {/* ── Footer note ── */}
      <div className="px-5 py-2 bg-gray-50 border-t border-gray-100 text-center">
        <p className="text-gray-400 text-[10px] leading-relaxed">
          This chat is based on your inspection data. For urgent issues, call{' '}
          <a href="tel:8122135997" className="text-orange font-semibold hover:underline">
            812-213-5997
          </a>{' '}
          or use the callback button below.
        </p>
      </div>
    </div>
  );
}