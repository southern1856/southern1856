import { useState } from 'react';
import {
  EVANSVILLE_WEATHER,
  getWeatherAlertSummary,
  REPAIR_WINDOW_DAYS,
  type WeatherDay,
} from '@/mocks/weather';

/* ─── severity styling ─── */
const SEVERITY_META: Record<string, { bg: string; border: string; text: string; accent: string; icon: string; headline: string }> = {
  clear: {
    bg: 'bg-green-50',
    border: 'border-green-200',
    text: 'text-green-700',
    accent: 'text-green-600',
    icon: 'ri-check-line',
    headline: 'Good Conditions for Roof Work',
  },
  caution: {
    bg: 'bg-amber-50',
    border: 'border-amber-200',
    text: 'text-amber-700',
    accent: 'text-amber-600',
    icon: 'ri-alert-line',
    headline: 'Watch the Forecast',
  },
  warning: {
    bg: 'bg-orange-50',
    border: 'border-orange-200',
    text: 'text-orange-700',
    accent: 'text-orange-600',
    icon: 'ri-error-warning-line',
    headline: 'Weather Warning — Work May Be Delayed',
  },
  severe: {
    bg: 'bg-red-50',
    border: 'border-red-200',
    text: 'text-red-700',
    accent: 'text-red-600',
    icon: 'ri-error-warning-line',
    headline: 'Severe Weather Alert — Do Not Schedule',
  },
};

/* ─── small day card ─── */
function DayMiniCard({ day, isToday }: { day: WeatherDay; isToday?: boolean }) {
  const meta = SEVERITY_META[day.severity];
  const isAlert = day.severity === 'warning' || day.severity === 'severe';

  return (
    <div
      className={`flex flex-col items-center text-center rounded-xl border p-2.5 min-w-[72px] flex-shrink-0 transition-colors ${
        isToday
          ? 'border-charcoal-deep bg-charcoal-deep'
          : isAlert
          ? `border ${meta.border} ${meta.bg}`
          : 'border-gray-100 bg-white hover:border-gray-200'
      }`}
    >
      <span className={`text-[9px] uppercase tracking-widest font-semibold ${isToday ? 'text-white/60' : 'text-gray-400'}`}>
        {day.dayName}
      </span>
      <span className={`font-display text-base mt-0.5 ${isToday ? 'text-white' : 'text-charcoal-deep'}`}>
        {day.monthDay.split(' ')[1]}
      </span>
      <div className={`w-7 h-7 flex items-center justify-center mt-1 rounded-lg ${isToday ? 'bg-white/10' : 'bg-gray-50'}`}>
        <i className={`${day.icon} text-sm ${isToday ? 'text-white/80' : day.severity === 'severe' ? 'text-red-500' : day.severity === 'warning' ? 'text-orange-500' : 'text-gray-500'}`} />
      </div>
      <span className={`text-[10px] mt-1 ${isToday ? 'text-white/70' : 'text-gray-500'}`}>
        {day.tempHigh}° / {day.tempLow}°
      </span>
      {day.rainChance > 0 && (
        <span className={`text-[9px] mt-0.5 ${isToday ? 'text-white/50' : isAlert ? meta.accent : 'text-gray-400'}`}>
          {day.rainChance}% rain
        </span>
      )}
    </div>
  );
}

/* ─── main component ─── */
export default function WeatherAlert() {
  const [expanded, setExpanded] = useState(false);
  const summary = getWeatherAlertSummary(EVANSVILLE_WEATHER, REPAIR_WINDOW_DAYS);
  const meta = SEVERITY_META[summary.worstSeverity];
  const today = EVANSVILLE_WEATHER[0];

  return (
    <div className={`border rounded-2xl overflow-hidden ${meta.border} ${meta.bg}`}>
      {/* ── compact banner ── */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full text-left px-5 py-4 md:px-6 md:py-5 flex items-start md:items-center gap-4 cursor-pointer"
      >
        {/* icon */}
        <div
          className={`w-10 h-10 md:w-11 md:h-11 flex-shrink-0 flex items-center justify-center rounded-xl ${
            summary.worstSeverity === 'severe'
              ? 'bg-red-100'
              : summary.worstSeverity === 'warning'
              ? 'bg-orange-100'
              : summary.worstSeverity === 'caution'
              ? 'bg-amber-100'
              : 'bg-green-100'
          }`}
        >
          <i
            className={`${meta.icon} text-lg md:text-xl ${
              summary.worstSeverity === 'severe'
                ? 'text-red-500'
                : summary.worstSeverity === 'warning'
                ? 'text-orange-500'
                : summary.worstSeverity === 'caution'
                ? 'text-amber-500'
                : 'text-green-600'
            }`}
          />
        </div>

        {/* text */}
        <div className="flex-1 min-w-0">
          <h4 className={`font-display text-sm md:text-base uppercase tracking-wider ${meta.text}`}>
            {meta.headline}
          </h4>
          <p className={`text-xs mt-0.5 leading-relaxed ${meta.text} opacity-80`}>
            {summary.hasAlert ? (
              <>
                {summary.activeAlerts.length} day{summary.activeAlerts.length > 1 ? 's' : ''} in your repair window (
                {REPAIR_WINDOW_DAYS}-day ASAP) with{' '}
                {summary.worstSeverity === 'severe' ? 'severe' : summary.worstSeverity === 'warning' ? 'wet' : 'marginal'}{' '}
                conditions. Crew safety is our first priority.
              </>
            ) : (
              <>
                Forecast looks clear for the next {REPAIR_WINDOW_DAYS} days. Any available slot is a green light for your
                crew to start work safely.
              </>
            )}
          </p>
        </div>

        {/* expand chevron */}
        <div className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-lg bg-black/5">
          <i
            className={`ri-arrow-down-s-line text-sm ${meta.text} transition-transform duration-200 ${expanded ? 'rotate-180' : ''}`}
          />
        </div>
      </button>

      {/* ── expanded detail panel ── */}
      {expanded && (
        <div className="border-t border-gray-200/60 px-5 py-5 md:px-6">
          {/* 7-day mini strip */}
          <div className="mb-5">
            <p className="text-[10px] uppercase tracking-widest font-semibold text-gray-400 mb-3">
              Evansville, IN — 7-Day Forecast
            </p>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {EVANSVILLE_WEATHER.map((day, i) => (
                <DayMiniCard key={day.date} day={day} isToday={i === 0} />
              ))}
            </div>
          </div>

          {/* alert cards for active warning/severe days */}
          {summary.activeAlerts.length > 0 && (
            <div className="space-y-3 mb-5">
              <p className="text-[10px] uppercase tracking-widest font-semibold text-gray-400">
                Days Requiring Attention
              </p>
              {summary.activeAlerts.map((day) => {
                const dm = SEVERITY_META[day.severity];
                return (
                  <div
                    key={day.date}
                    className={`flex items-start gap-3 rounded-xl border p-3.5 ${dm.border} bg-white`}
                  >
                    <div
                      className={`w-8 h-8 flex-shrink-0 flex items-center justify-center rounded-lg ${
                        day.severity === 'severe' ? 'bg-red-100' : 'bg-orange-100'
                      }`}
                    >
                      <i
                        className={`${day.icon} text-sm ${
                          day.severity === 'severe' ? 'text-red-500' : 'text-orange-500'
                        }`}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-xs font-semibold ${dm.text}`}>
                        {day.dayName}, {day.monthDay} — {day.condition}
                      </p>
                      <p className="text-gray-500 text-xs mt-0.5 leading-relaxed">
                        {day.alertMessage}
                      </p>
                      {day.precipAmount !== undefined && day.precipAmount > 0 && (
                        <div className="flex flex-wrap gap-3 mt-1.5">
                          <span className="text-[10px] text-gray-400">
                            <i className="ri-water-percent-line mr-1" />
                            {day.rainChance}% chance
                          </span>
                          <span className="text-[10px] text-gray-400">
                            <i className="ri-windy-line mr-1" />
                            {day.windSpeed} mph wind
                          </span>
                          {day.precipAmount > 0 && (
                            <span className="text-[10px] text-gray-400">
                              <i className="ri-drop-line mr-1" />
                              {day.precipAmount}" rain
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                    <span
                      className={`flex-shrink-0 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border ${dm.border} ${dm.bg} ${dm.text}`}
                    >
                      {day.severity === 'severe' ? 'Severe' : 'Warning'}
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {/* recommendation */}
          <div className="bg-white border border-gray-200 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="w-9 h-9 flex-shrink-0 flex items-center justify-center bg-charcoal-deep rounded-lg">
              <i className="ri-calendar-check-line text-white text-sm" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider">
                Our Recommendation
              </p>
              <p className="text-gray-500 text-xs mt-0.5 leading-relaxed">
                {summary.recommendedDate ? (
                  <>
                    Schedule your repair for{' '}
                    <strong className="text-charcoal-deep">
                      {EVANSVILLE_WEATHER.find((d) => d.date === summary.recommendedDate)?.dayName ?? 'the first clear day'}
                    </strong>
                    . That&apos;s the first day in your window with good working conditions. We monitor weather in real time and will contact you immediately if we need to
                    reschedule for safety.
                  </>
                ) : (
                  <>
                    The next {REPAIR_WINDOW_DAYS} days all have challenging conditions. We recommend booking a date at least{' '}
                    {REPAIR_WINDOW_DAYS + 2} days out and we&apos;ll keep watching the forecast.
                  </>
                )}
              </p>
            </div>
            {summary.recommendedDate && (
              <a
                href="#appointment-calendar"
                className="flex-shrink-0 inline-flex items-center gap-1.5 bg-orange hover:bg-orange-dark text-white font-bold text-[10px] uppercase tracking-widest px-4 py-2.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              >
                <i className="ri-calendar-event-line" />
                Book That Date
              </a>
            )}
          </div>

          {/* disclaimer */}
          <p className="text-[10px] text-gray-400 mt-3 text-center">
            Forecast sourced from National Weather Service. Updates hourly. Conditions can change — we call you the evening before every job to confirm.
          </p>
        </div>
      )}
    </div>
  );
}