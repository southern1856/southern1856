import { COLOR_PAIRINGS, DEFAULT_PAIRING } from '@/mocks/shingleColors';
import type { ShingleColor } from '@/mocks/shingleColors';

interface FullExteriorPreviewProps {
  color: ShingleColor;
}

export default function FullExteriorPreview({ color }: FullExteriorPreviewProps) {
  const pairing = COLOR_PAIRINGS[color.sku] ?? DEFAULT_PAIRING;

  const roofColor = color.hex;
  const sidingColor = pairing.siding[0].hex;
  const trimColor = pairing.trim[0].hex;
  const accentColor = pairing.accent[0].hex;

  return (
    <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm">
      {/* Header */}
      <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 flex items-center justify-center bg-orange/10 rounded-xl">
            <i className="ri-home-gear-line text-orange text-lg" />
          </div>
          <div className="min-w-0">
            <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider truncate">
              Full Exterior Preview
            </h3>
            <p className="text-gray-400 text-[10px]">
              Roof + siding + trim + accent, all together
            </p>
          </div>
        </div>
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-orange/10 text-orange text-[10px] font-bold uppercase tracking-wider whitespace-nowrap">
          <i className="ri-magic-line" />
          Live
        </span>
      </div>

      {/* CSS House illustration */}
      <div className="p-5 md:p-8 bg-gray-50 flex items-center justify-center">
        <div className="relative w-full max-w-[360px]">
          {/* Sky background */}
          <div className="relative w-full aspect-[4/3] bg-gray-50 overflow-hidden">
            {/* Ground */}
            <div className="absolute bottom-0 left-0 right-0 h-[15%] bg-gray-200 rounded-b-xl" />

            {/* Walkway */}
            <div
              className="absolute bottom-[12%] left-1/2 -translate-x-1/2 w-[12%] h-[20%] origin-bottom"
              style={{ backgroundColor: '#b8a890' }}
            />

            {/* House body */}
            <div className="absolute bottom-[15%] left-1/2 -translate-x-1/2 w-[56%] h-[45%] rounded-t-sm">
              {/* Siding */}
              <div
                className="absolute inset-0 rounded-t-sm"
                style={{ backgroundColor: sidingColor }}
              />

              {/* Siding texture lines */}
              <div className="absolute inset-0 opacity-15">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div
                    key={i}
                    className="absolute left-0 right-0 border-t border-black/10"
                    style={{ top: `${(i + 1) * 16}%` }}
                  />
                ))}
              </div>

              {/* Left window */}
              <div
                className="absolute top-[18%] left-[18%] w-[18%] h-[22%] rounded-sm"
                style={{ backgroundColor: '#a0b8c8' }}
              >
                <div
                  className="absolute top-0 left-0 right-0 h-[10%]"
                  style={{ backgroundColor: trimColor }}
                />
                <div
                  className="absolute top-[48%] left-0 right-0 h-[4%]"
                  style={{ backgroundColor: trimColor }}
                />
                <div
                  className="absolute top-0 left-[48%] bottom-0 w-[4%]"
                  style={{ backgroundColor: trimColor }}
                />
              </div>

              {/* Right window */}
              <div
                className="absolute top-[18%] right-[18%] w-[18%] h-[22%] rounded-sm"
                style={{ backgroundColor: '#a0b8c8' }}
              >
                <div
                  className="absolute top-0 left-0 right-0 h-[10%]"
                  style={{ backgroundColor: trimColor }}
                />
                <div
                  className="absolute top-[48%] left-0 right-0 h-[4%]"
                  style={{ backgroundColor: trimColor }}
                />
                <div
                  className="absolute top-0 left-[48%] bottom-0 w-[4%]"
                  style={{ backgroundColor: trimColor }}
                />
              </div>

              {/* Door */}
              <div
                className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[22%] h-[35%] rounded-t-sm"
                style={{ backgroundColor: accentColor }}
              >
                {/* Door panel detail */}
                <div className="absolute top-[12%] left-[20%] right-[20%] h-[35%] border-2 border-white/20 rounded-sm" />
                <div className="absolute bottom-[12%] left-[20%] right-[20%] h-[25%] border-2 border-white/20 rounded-sm" />
                {/* Doorknob */}
                <div className="absolute top-[50%] right-[12%] w-[8%] aspect-square bg-white/30 rounded-full" />
              </div>

              {/* Bottom trim */}
              <div
                className="absolute bottom-0 left-0 right-0 h-[4%]"
                style={{ backgroundColor: trimColor }}
              />
            </div>

            {/* Roof */}
            <div
              className="absolute bottom-[60%] left-1/2 -translate-x-1/2 w-[0] h-[0]"
              style={{
                borderLeftWidth: '120px',
                borderRightWidth: '120px',
                borderBottomWidth: '75px',
                borderLeftColor: 'transparent',
                borderRightColor: 'transparent',
                borderBottomColor: roofColor,
              }}
            />

            {/* Roof overhang shading */}
            <div
              className="absolute bottom-[60%] left-[9%] right-[9%] h-[6px] rounded-sm"
              style={{ backgroundColor: `${roofColor}cc` }}
            />

            {/* Chimney */}
            <div
              className="absolute bottom-[62%] left-[62%] w-[10%] h-[12%] rounded-t-sm"
              style={{ backgroundColor: '#8a7a6a' }}
            />

            {/* Garage */}
            <div
              className="absolute bottom-[15%] right-[16%] w-[26%] h-[32%] rounded-t-sm"
              style={{ backgroundColor: sidingColor }}
            >
              {/* Garage door lines */}
              {Array.from({ length: 4 }).map((_, i) => (
                <div
                  key={i}
                  className="absolute left-[10%] right-[10%] h-[2%] bg-black/8 rounded-sm"
                  style={{ top: `${15 + i * 20}%` }}
                />
              ))}
              {/* Garage trim */}
              <div
                className="absolute top-0 left-0 right-0 h-[6%]"
                style={{ backgroundColor: trimColor }}
              />
              <div
                className="absolute top-0 left-0 w-[4%] h-full"
                style={{ backgroundColor: trimColor }}
              />
              <div
                className="absolute top-0 right-0 w-[4%] h-full"
                style={{ backgroundColor: trimColor }}
              />
            </div>

            {/* Trees (simple circles) */}
            <div className="absolute bottom-[15%] left-[5%] w-[14%] aspect-square rounded-full bg-green-700/80" />
            <div className="absolute bottom-[25%] left-[2%] w-[10%] aspect-square rounded-full bg-green-600/70" />
            <div className="absolute bottom-[15%] right-[8%] w-[12%] aspect-square rounded-full bg-green-700/80" />
            <div className="absolute bottom-[22%] right-[4%] w-[8%] aspect-square rounded-full bg-green-600/70" />
          </div>
        </div>
      </div>

      {/* Color legend */}
      <div className="px-5 py-4 border-t border-gray-100">
        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center gap-2">
            <div
              className="w-5 h-5 rounded-md border border-gray-200 flex-shrink-0"
              style={{ backgroundColor: roofColor }}
            />
            <div className="min-w-0">
              <p className="text-charcoal-deep text-[11px] font-semibold truncate">{color.name}</p>
              <p className="text-gray-400 text-[9px]">Roof</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div
              className="w-5 h-5 rounded-md border border-gray-200 flex-shrink-0"
              style={{ backgroundColor: sidingColor }}
            />
            <div className="min-w-0">
              <p className="text-charcoal-deep text-[11px] font-semibold truncate">{pairing.siding[0].name}</p>
              <p className="text-gray-400 text-[9px]">Siding</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div
              className="w-5 h-5 rounded-md border border-gray-200 flex-shrink-0"
              style={{ backgroundColor: trimColor }}
            />
            <div className="min-w-0">
              <p className="text-charcoal-deep text-[11px] font-semibold truncate">{pairing.trim[0].name}</p>
              <p className="text-gray-400 text-[9px]">Trim</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div
              className="w-5 h-5 rounded-md border border-gray-200 flex-shrink-0"
              style={{ backgroundColor: accentColor }}
            />
            <div className="min-w-0">
              <p className="text-charcoal-deep text-[11px] font-semibold truncate">{pairing.accent[0].name}</p>
              <p className="text-gray-400 text-[9px]">Door / Accent</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}