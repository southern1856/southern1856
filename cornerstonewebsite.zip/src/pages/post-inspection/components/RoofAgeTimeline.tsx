import { useState, useMemo, useRef, useEffect } from 'react';
import {
  ROOF_LIFECYCLE,
  ROOF_EVENTS,
  USER_ROOF_PROFILE,
  type LifecycleStage,
  type RoofEvent,
} from '@/mocks/roofLifecycle';

/* ─── helpers ─── */
function stageWidthPct(stage: LifecycleStage): number {
  const total = ROOF_LIFECYCLE[ROOF_LIFECYCLE.length - 1].endYear;
  return ((stage.endYear - stage.startYear) / total) * 100;
}

function currentPositionPct(age: number): number {
  const total = ROOF_LIFECYCLE[ROOF_LIFECYCLE.length - 1].endYear;
  return (age / total) * 100;
}

function eventPositionPct(year: number): number {
  const total = ROOF_LIFECYCLE[ROOF_LIFECYCLE.length - 1].endYear;
  return (year / total) * 100;
}

function clamp(n: number, min: number, max: number) {
  return Math.min(Math.max(n, min), max);
}

/* ─── condition score gauge ─── */
function ConditionGauge({ score }: { score: number }) {
  const circumference = 2 * Math.PI * 36;
  const offset = circumference - (score / 100) * circumference;

  let color = '#22C55E';
  if (score < 50) color = '#EF4444';
  else if (score < 70) color = '#F97316';
  else if (score < 85) color = '#EAB308';

  return (
    <div className="relative w-20 h-20 flex-shrink-0">
      <svg viewBox="0 0 80 80" className="w-full h-full -rotate-90">
        <circle cx="40" cy="40" r="36" stroke="#E5E7EB" strokeWidth="6" fill="none" />
        <circle
          cx="40"
          cy="40"
          r="36"
          stroke={color}
          strokeWidth="6"
          fill="none"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 1s ease-out' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-charcoal-deep text-lg leading-none">{score}</span>
        <span className="text-[9px] text-gray-400 uppercase tracking-wider">/100</span>
      </div>
    </div>
  );
}

/* ─── event dot ─── */
function EventDot({ event, isProjected }: { event: RoofEvent; isProjected: boolean }) {
  const left = eventPositionPct(event.year);
  return (
    <div
      className="absolute top-0 -translate-x-1/2 flex flex-col items-center group cursor-pointer"
      style={{ left: `${left}%` }}
    >
      {/* tooltip */}
      <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute bottom-full mb-2 whitespace-nowrap z-10">
        <div className="bg-charcoal-deep text-white text-[10px] px-2.5 py-1.5 rounded-lg shadow-sm">
          <span className="font-semibold">Year {event.year}</span>
          <span className="mx-1 text-white/40">|</span>
          <span>{event.label}</span>
        </div>
        <div className="w-2 h-2 bg-charcoal-deep rotate-45 mx-auto -mt-1" />
      </div>

      {/* dot */}
      <div
        className={`w-3 h-3 rounded-full border-2 ${
          isProjected
            ? 'bg-white border-gray-400'
            : event.type === 'install'
            ? 'bg-green-500 border-green-500'
            : event.type === 'storm'
            ? 'bg-red-500 border-red-500'
            : 'bg-orange border-orange'
        }`}
      />
      {/* projected ring */}
      {isProjected && (
        <div className="w-5 h-5 rounded-full border border-dashed border-gray-300 absolute -top-1 -left-1" />
      )}
    </div>
  );
}

/* ─── main component ─── */
export default function RoofAgeTimeline() {
  const [activeStage, setActiveStage] = useState<LifecycleStage | null>(null);
  const [hoverStage, setHoverStage] = useState<string | null>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const [barWidth, setBarWidth] = useState(0);

  useEffect(() => {
    function measure() {
      if (barRef.current) setBarWidth(barRef.current.offsetWidth);
    }
    measure();
    window.addEventListener('resize', measure);
    return () => window.removeEventListener('resize', measure);
  }, []);

  const currentPos = currentPositionPct(USER_ROOF_PROFILE.currentAge);
  const isInActive = (stage: LifecycleStage) =>
    USER_ROOF_PROFILE.currentAge >= stage.startYear &&
    USER_ROOF_PROFILE.currentAge <= stage.endYear;

  const timelineTotalYears = ROOF_LIFECYCLE[ROOF_LIFECYCLE.length - 1].endYear;

  /* projected events for upcoming 8 years */
  const upcomingEvents = useMemo(
    () =>
      ROOF_EVENTS.filter(
        (e) => e.year > USER_ROOF_PROFILE.currentAge && e.year <= USER_ROOF_PROFILE.currentAge + 8
      ),
    []
  );

  return (
    <div className="bg-white border border-gray-200 rounded-2xl p-6 md:p-8 shadow-sm space-y-8">
      {/* ── Roof Profile Summary ── */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5 pb-6 border-b border-gray-100">
        <ConditionGauge score={USER_ROOF_PROFILE.conditionScore} />
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 mb-1">
            <h3 className="font-display text-charcoal-deep text-base uppercase tracking-wider">
              {USER_ROOF_PROFILE.shingleType}
            </h3>
            <span className="px-2 py-0.5 rounded-md bg-green-50 border border-green-200 text-green-700 text-[10px] font-bold uppercase tracking-wider">
              {USER_ROOF_PROFILE.warrantyStatus}
            </span>
          </div>
          <p className="text-gray-500 text-xs leading-relaxed">
            Installed <strong className="text-charcoal-deep">{USER_ROOF_PROFILE.installedYear}</strong> • Current age{' '}
            <strong className="text-charcoal-deep">{USER_ROOF_PROFILE.currentAge} years</strong> • Expected lifespan{' '}
            <strong className="text-charcoal-deep">{USER_ROOF_PROFILE.expectedLifespan} years</strong>
          </p>
        </div>
        <div className="flex flex-col items-end text-right">
          <span className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">
            Current Stage
          </span>
          <span className="font-display text-orange text-lg uppercase tracking-wider">
            {USER_ROOF_PROFILE.currentStage}
          </span>
          <span className="text-[10px] text-gray-400 mt-0.5">
            {USER_ROOF_PROFILE.nextMilestone}
          </span>
        </div>
      </div>

      {/* ── Inspector Quote ── */}
      <div className="bg-gray-50 border border-gray-100 rounded-xl p-4 flex items-start gap-3">
        <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center bg-orange/10 rounded-lg">
          <i className="ri-user-settings-line text-orange text-sm" />
        </div>
        <p className="text-gray-600 text-xs leading-relaxed italic">
          “{USER_ROOF_PROFILE.inspectorQuote}”
        </p>
      </div>

      {/* ── Interactive Timeline Bar ── */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold">
            Lifecycle Timeline — {timelineTotalYears} Year Span
          </p>
          <p className="text-[10px] text-gray-400">
            Click a stage for details
          </p>
        </div>

        {/* segmented bar */}
        <div ref={barRef} className="relative h-12 rounded-xl overflow-hidden flex">
          {ROOF_LIFECYCLE.map((stage) => {
            const width = stageWidthPct(stage);
            const isActive = isInActive(stage);
            const isHovered = hoverStage === stage.label;
            const isSelected = activeStage?.label === stage.label;

            return (
              <button
                key={stage.label}
                onClick={() =>
                  setActiveStage(activeStage?.label === stage.label ? null : stage)
                }
                onMouseEnter={() => setHoverStage(stage.label)}
                onMouseLeave={() => setHoverStage(null)}
                className="relative h-full flex items-center justify-center transition-all duration-200 cursor-pointer outline-none"
                style={{
                  width: `${width}%`,
                  backgroundColor: isActive || isSelected || isHovered ? stage.color : `${stage.color}40`,
                }}
              >
                {/* label */}
                <span
                  className={`text-[10px] md:text-xs font-semibold uppercase tracking-wider transition-colors ${
                    isActive || isSelected || isHovered ? 'text-white' : 'text-white/70'
                  }`}
                >
                  {stage.label}
                </span>

                {/* subtle border between segments */}
                <div className="absolute right-0 top-1 bottom-1 w-px bg-white/20" />
              </button>
            );
          })}

          {/* current position marker */}
          <div
            className="absolute top-0 bottom-0 flex flex-col items-center z-10 pointer-events-none"
            style={{ left: `${clamp(currentPos, 2, 98)}%` }}
          >
            {/* triangle */}
            <div className="w-0 h-0 border-l-[6px] border-r-[6px] border-t-[8px] border-l-transparent border-r-transparent border-t-charcoal-deep -mt-1" />
            {/* line */}
            <div className="flex-1 w-0.5 bg-charcoal-deep/30" />
            {/* label */}
            <div className="bg-charcoal-deep text-white text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md -mb-2">
              Year {USER_ROOF_PROFILE.currentAge}
            </div>
          </div>
        </div>

        {/* year axis */}
        <div className="flex justify-between mt-2 px-0.5">
          {[0, 5, 10, 15, 20, 25, 30].map((y) => (
            <div key={y} className="flex flex-col items-center">
              <div className="w-px h-2 bg-gray-300" />
              <span className="text-[10px] text-gray-400 mt-0.5">{y}yr</span>
            </div>
          ))}
        </div>

        {/* event strip */}
        <div className="relative h-5 mt-3 mx-1">
          {ROOF_EVENTS.map((evt) => (
            <EventDot
              key={evt.year + evt.label}
              event={evt}
              isProjected={evt.type === 'projected'}
            />
          ))}
        </div>

        {/* event legend */}
        <div className="flex flex-wrap items-center gap-4 mt-2 ml-1">
          <span className="flex items-center gap-1 text-[10px] text-gray-400">
            <span className="w-2 h-2 rounded-full bg-green-500" /> Install
          </span>
          <span className="flex items-center gap-1 text-[10px] text-gray-400">
            <span className="w-2 h-2 rounded-full bg-orange" /> Inspection / Repair
          </span>
          <span className="flex items-center gap-1 text-[10px] text-gray-400">
            <span className="w-2 h-2 rounded-full bg-red-500" /> Storm Event
          </span>
          <span className="flex items-center gap-1 text-[10px] text-gray-400">
            <span className="w-2 h-2 rounded-full border-2 border-gray-400" /> Projected
          </span>
        </div>
      </div>

      {/* ── Active Stage Detail Panel ── */}
      {activeStage && (
        <div className="border border-gray-200 rounded-xl overflow-hidden animate-[fadeIn_0.25s_ease-out]">
          {/* header */}
          <div
            className="px-5 py-4 flex items-center gap-3"
            style={{ backgroundColor: `${activeStage.color}15` }}
          >
            <div
              className="w-9 h-9 flex items-center justify-center rounded-lg"
              style={{ backgroundColor: `${activeStage.color}25` }}
            >
              <i className={`${activeStage.icon} text-sm`} style={{ color: activeStage.color }} />
            </div>
            <div>
              <h4 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
                {activeStage.headline}
              </h4>
              <p className={`text-xs mt-0.5 ${activeStage.textColor}`}>
                Years {activeStage.startYear}–{activeStage.endYear} • {activeStage.label}
              </p>
            </div>
            <span
              className={`ml-auto px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                activeStage.priority === 'critical'
                  ? 'bg-red-50 text-red-700 border-red-200'
                  : activeStage.priority === 'urgent'
                  ? 'bg-orange-50 text-orange-700 border-orange-200'
                  : activeStage.priority === 'recommended'
                  ? 'bg-amber-50 text-amber-700 border-amber-200'
                  : 'bg-green-50 text-green-700 border-green-200'
              }`}
            >
              {activeStage.priority}
            </span>
          </div>

          {/* body */}
          <div className="p-5 space-y-4">
            <p className="text-gray-600 text-sm leading-relaxed">
              {activeStage.description}
            </p>

            {/* maintenance tasks */}
            <div>
              <p className="text-[10px] uppercase tracking-widest font-semibold text-gray-400 mb-2">
                Recommended Actions
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {activeStage.maintenanceTasks.map((task) => (
                  <div
                    key={task}
                    className="flex items-start gap-2 bg-gray-50 border border-gray-100 rounded-lg px-3 py-2"
                  >
                    <i className="ri-check-line text-green-500 text-sm mt-0.5 flex-shrink-0" />
                    <span className="text-gray-600 text-xs">{task}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* cost + timeframe row */}
            <div className="flex flex-col sm:flex-row gap-3 pt-3 border-t border-gray-100">
              <div className="flex-1 bg-gray-50 rounded-lg p-3">
                <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold mb-1">
                  Average Annual Cost
                </p>
                <p className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
                  {activeStage.averageCost}
                </p>
              </div>
              <div className="flex-1 bg-gray-50 rounded-lg p-3">
                <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold mb-1">
                  Duration
                </p>
                <p className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
                  {activeStage.endYear - activeStage.startYear + 1} years
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Upcoming Milestones ── */}
      <div>
        <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold mb-3">
          Upcoming Milestones (Next 8 Years)
        </p>
        <div className="space-y-2">
          {upcomingEvents.map((evt, i) => {
            const isFirst = i === 0;
            const yearsFromNow = evt.year - USER_ROOF_PROFILE.currentAge;
            return (
              <div
                key={evt.year + evt.label}
                className={`flex items-start gap-3 rounded-xl border p-3.5 ${
                  isFirst ? 'border-orange bg-orange/5' : 'border-gray-200 bg-white'
                }`}
              >
                <div
                  className={`w-8 h-8 flex-shrink-0 flex items-center justify-center rounded-lg ${
                    isFirst ? 'bg-orange/10' : 'bg-gray-100'
                  }`}
                >
                  <i className={`${evt.icon} text-sm ${isFirst ? 'text-orange' : 'text-gray-500'}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className={`text-xs font-semibold ${isFirst ? 'text-orange' : 'text-charcoal-deep'}`}>
                      {evt.label}
                    </p>
                    {isFirst && (
                      <span className="px-2 py-0.5 rounded-full bg-orange text-white text-[9px] font-bold uppercase tracking-wider">
                        Next Up
                      </span>
                    )}
                  </div>
                  <p className="text-gray-400 text-xs mt-0.5">
                    Year {evt.year} ({yearsFromNow} year{yearsFromNow > 1 ? 's' : ''} from now)
                  </p>
                </div>
                <i className="ri-arrow-right-line text-gray-300 text-sm flex-shrink-0 mt-1" />
              </div>
            );
          })}
        </div>
      </div>

      {/* ── Projected Replacement Window ── */}
      <div className="bg-charcoal-deep rounded-xl p-5 flex flex-col sm:flex-row items-start sm:items-center gap-4">
        <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center bg-orange/20 rounded-lg">
          <i className="ri-refresh-line text-orange text-lg" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-display text-white text-sm uppercase tracking-wider">
            Projected Full Replacement Window
          </p>
          <p className="text-white/50 text-xs mt-0.5">
            Based on shingle type, current condition, and local climate patterns
          </p>
        </div>
        <div className="text-right flex-shrink-0">
          <p className="font-display text-white text-lg uppercase tracking-wider">
            {USER_ROOF_PROFILE.projectedReplacement}
          </p>
          <p className="text-white/40 text-[10px]">
            ~{USER_ROOF_PROFILE.yearsUntilReplace} years away
          </p>
        </div>
      </div>

      {/* ── CTA ── */}
      <div className="flex flex-col sm:flex-row gap-3 pt-2">
        <a
          href="#schedule-repair"
          className="flex-1 inline-flex items-center justify-center gap-2 bg-orange hover:bg-orange-dark text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
        >
          <i className="ri-calendar-check-line" />
          Schedule Repair Now
        </a>
        <a
          href="#compare-estimates"
          className="flex-1 inline-flex items-center justify-center gap-2 border border-gray-300 hover:border-gray-400 text-charcoal-deep font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
        >
          <i className="ri-file-list-3-line" />
          See Replacement Estimate
        </a>
      </div>
    </div>
  );
}