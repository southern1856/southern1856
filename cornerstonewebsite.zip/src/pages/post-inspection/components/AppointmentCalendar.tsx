import { useState, useMemo, useCallback } from 'react';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

/* ─── types ─── */
interface TimeSlot {
  time: string;
  label: string;
  crew: string;
  available: boolean;
}

interface DayAvailability {
  date: string; // YYYY-MM-DD
  dayNum: number;
  month: number;
  year: number;
  slots: TimeSlot[];
  crewCount: number;
  status: 'available' | 'limited' | 'booked' | 'emergency-only';
  note?: string;
}

/* ─── helpers ─── */
function getMonthName(monthIndex: number): string {
  return [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
  ][monthIndex];
}

function getDayLabel(dateStr: string): string {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', { weekday: 'short' });
}

function formatDateDisplay(dateStr: string): string {
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
}

/* ─── generate mock availability for next 6 weeks ─── */
function generateAvailability(): DayAvailability[] {
  const today = new Date(2026, 4, 2); // May 2, 2026
  const days: DayAvailability[] = [];

  const allSlots: TimeSlot[] = [
    { time: '07:00', label: '7:00 AM – Early Start', crew: 'Alpha Crew', available: true },
    { time: '08:30', label: '8:30 AM – Morning Block', crew: 'Bravo Crew', available: true },
    { time: '10:00', label: '10:00 AM – Mid-Morning', crew: 'Charlie Crew', available: true },
    { time: '12:00', label: '12:00 PM – Noon Start', crew: 'Delta Crew', available: true },
    { time: '13:30', label: '1:30 PM – Afternoon Block', crew: 'Echo Crew', available: true },
    { time: '15:00', label: '3:00 PM – Late Afternoon', crew: 'Night Watch', available: true },
  ];

  for (let i = 0; i < 45; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const isWeekend = d.getDay() === 0 || d.getDay() === 6;
    const isPast = i < 0;

    if (isPast) continue;

    // Simulate varying availability
    const rand = (seed: number) => {
      const x = Math.sin(seed * 9999 + i * 137) * 10000;
      return x - Math.floor(x);
    };

    let status: DayAvailability['status'] = 'available';
    let note: string | undefined;
    let slots: TimeSlot[] = [];
    let crewCount = 4;

    if (isWeekend) {
      // Fewer crews on weekends
      crewCount = 2;
      slots = allSlots.slice(0, 3).map((s) => ({ ...s, available: rand(s.time.length) > 0.4 }));
      if (slots.filter((s) => s.available).length <= 1) {
        status = 'limited';
        note = 'Limited weekend availability';
      }
    } else if (rand(i) > 0.82) {
      status = 'booked';
      crewCount = 0;
      slots = allSlots.map((s) => ({ ...s, available: false }));
      note = 'Fully booked — call for waitlist';
    } else if (rand(i + 50) > 0.72) {
      status = 'limited';
      crewCount = 1;
      slots = allSlots.map((s, idx) => ({ ...s, available: idx % 3 === 0 }));
      note = '1 crew available — limited slots';
    } else if (rand(i + 100) > 0.9) {
      status = 'emergency-only';
      crewCount = 1;
      slots = allSlots.map((s) => ({ ...s, available: false }));
      note = 'Emergency response only';
    } else {
      // Normal availability
      crewCount = 3 + Math.floor(rand(i + 200) * 2);
      slots = allSlots.map((s) => ({
        ...s,
        available: rand(s.time.length + i) > 0.25,
        crew: ['Alpha Crew', 'Bravo Crew', 'Charlie Crew', 'Delta Crew', 'Echo Crew', 'Night Watch'][Math.floor(rand(s.time.length + i + 10) * 6)],
      }));
    }

    days.push({
      date: dateStr,
      dayNum: d.getDate(),
      month: d.getMonth(),
      year: d.getFullYear(),
      slots,
      crewCount,
      status,
      note,
    });
  }

  return days;
}

const ALL_AVAILABILITY = generateAvailability();

const BOOKING_FORM_URL = WEB3FORMS_ENDPOINT;

/* ─── status badge colors ─── */
const STATUS_META: Record<string, { dot: string; badge: string; text: string }> = {
  available: { dot: 'bg-green-500', badge: 'bg-green-50 text-green-700 border-green-200', text: 'Available' },
  limited: { dot: 'bg-amber-500', badge: 'bg-amber-50 text-amber-700 border-amber-200', text: 'Limited' },
  booked: { dot: 'bg-gray-400', badge: 'bg-gray-100 text-gray-500 border-gray-200', text: 'Booked' },
  'emergency-only': { dot: 'bg-red-500', badge: 'bg-red-50 text-red-700 border-red-200', text: 'Emergency' },
};

/* ─── main component ─── */
export default function AppointmentCalendar() {
  const today = new Date(2026, 4, 2);
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [currentYear, setCurrentYear] = useState(today.getFullYear());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<TimeSlot | null>(null);
  const [bookingSubmitted, setBookingSubmitted] = useState(false);
  const [bookingError, setBookingError] = useState('');

  const daysInMonth = useMemo(() => {
    const firstDay = new Date(currentYear, currentMonth, 1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    const startWeekday = firstDay.getDay(); // 0 = Sunday
    const totalDays = lastDay.getDate();

    const blanks = Array.from({ length: startWeekday }, () => null);
    const days = Array.from({ length: totalDays }, (_, i) => i + 1);
    return [...blanks, ...days];
  }, [currentMonth, currentYear]);

  const monthAvailability = useMemo(() => {
    return ALL_AVAILABILITY.filter((d) => d.month === currentMonth && d.year === currentYear);
  }, [currentMonth, currentYear]);

  const getDayData = useCallback(
    (dayNum: number): DayAvailability | undefined => {
      return monthAvailability.find((d) => d.dayNum === dayNum);
    },
    [monthAvailability]
  );

  const selectedDayData = useMemo(() => {
    if (!selectedDate) return undefined;
    return ALL_AVAILABILITY.find((d) => d.date === selectedDate);
  }, [selectedDate]);

  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear((y) => y - 1);
    } else {
      setCurrentMonth((m) => m - 1);
    }
    setSelectedDate(null);
    setSelectedSlot(null);
  };

  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear((y) => y + 1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
    setSelectedDate(null);
    setSelectedSlot(null);
  };

  const canGoPrev = !(currentYear === today.getFullYear() && currentMonth === today.getMonth());

  const handleDateClick = (dayNum: number) => {
    const data = getDayData(dayNum);
    if (!data || data.status === 'booked' || data.status === 'emergency-only') return;
    const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
    setSelectedDate(dateStr);
    setSelectedSlot(null);
    setBookingError('');
  };

  const handleSlotClick = (slot: TimeSlot) => {
    if (!slot.available) return;
    setSelectedSlot(slot);
    setBookingError('');
  };

  const handleBookingSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const emailInput = form.elements.namedItem('email') as HTMLInputElement;
    const phoneInput = form.elements.namedItem('phone') as HTMLInputElement;

    if (!emailInput?.value || !emailInput.value.includes('@')) {
      setBookingError('Please enter a valid email address');
      return;
    }
    if (!phoneInput?.value || phoneInput.value.replace(/\D/g, '').length < 10) {
      setBookingError('Please enter a valid 10-digit phone number');
      return;
    }

    setBookingError('');
    const data = new FormData(form);
    data.append('access_key', WEB3FORMS_ACCESS_KEY);
    fetch(form.action, {
      method: 'POST',
      body: new URLSearchParams(data as unknown as Record<string, string>),
    })
      .then(() => setBookingSubmitted(true))
      .catch(() => setBookingSubmitted(true));
  };

  return (
    <div className="bg-white border border-gray-200 rounded-2xl p-6 md:p-8 shadow-sm">
      {bookingSubmitted ? (
        <div className="text-center py-6">
          <div className="w-14 h-14 flex items-center justify-center bg-green-50 rounded-full mx-auto mb-4">
            <i className="ri-checkbox-circle-fill text-green-500 text-2xl" />
          </div>
          <h4 className="font-display text-charcoal-deep text-xl uppercase tracking-wider mb-2">
            Appointment Confirmed
          </h4>
          <p className="text-gray-500 text-sm max-w-md mx-auto mb-4">
            Your repair appointment is booked. A confirmation text and email will arrive within 5 minutes.
          </p>

          <div className="bg-gray-50 border border-gray-100 rounded-xl p-5 text-left max-w-md mx-auto mb-6 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold">Date</span>
              <span className="text-charcoal-deep text-sm font-semibold">{selectedDate && formatDateDisplay(selectedDate)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold">Time</span>
              <span className="text-charcoal-deep text-sm font-semibold">{selectedSlot?.label}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold">Crew</span>
              <span className="text-charcoal-deep text-sm font-semibold">{selectedSlot?.crew}</span>
            </div>
          </div>

          <div className="bg-gray-50 border border-gray-100 rounded-xl p-5 text-left max-w-md mx-auto mb-6">
            <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-2">
              What happens next
            </p>
            <ul className="space-y-2">
              {[
                'Confirmation text + email sent within 5 minutes',
                'Crew lead calls you the evening before to confirm',
                'Team arrives within a 30-minute arrival window',
                'Work begins immediately — no re-inspection needed',
              ].map((s) => (
                <li key={s} className="flex items-start gap-2 text-sm text-gray-600">
                  <i className="ri-check-line text-green-500 mt-0.5" />
                  {s}
                </li>
              ))}
            </ul>
          </div>

          <button
            onClick={() => {
              setBookingSubmitted(false);
              setSelectedDate(null);
              setSelectedSlot(null);
            }}
            className="text-orange text-xs font-semibold uppercase tracking-wider hover:underline underline-offset-4 cursor-pointer"
          >
            Book Another Appointment
          </button>
        </div>
      ) : (
        <div>
          {/* Month header */}
          <div className="flex items-center justify-between mb-6">
            <button
              onClick={prevMonth}
              disabled={!canGoPrev}
              className={`w-9 h-9 flex items-center justify-center rounded-lg border transition-colors ${
                canGoPrev
                  ? 'border-gray-200 hover:border-orange text-charcoal-deep cursor-pointer'
                  : 'border-gray-100 text-gray-300 cursor-not-allowed'
              }`}
            >
              <i className="ri-arrow-left-s-line text-lg" />
            </button>
            <h4 className="font-display text-charcoal-deep text-lg uppercase tracking-wider">
              {getMonthName(currentMonth)} {currentYear}
            </h4>
            <button
              onClick={nextMonth}
              className="w-9 h-9 flex items-center justify-center rounded-lg border border-gray-200 hover:border-orange text-charcoal-dark transition-colors cursor-pointer"
            >
              <i className="ri-arrow-right-s-line text-lg" />
            </button>
          </div>

          {/* Weekday labels */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
              <div key={d} className="text-center text-[10px] uppercase tracking-widest font-semibold text-gray-400 py-2">
                {d}
              </div>
            ))}
          </div>

          {/* Calendar grid */}
          <div className="grid grid-cols-7 gap-1">
            {daysInMonth.map((dayNum, idx) => {
              if (dayNum === null) {
                return <div key={`blank-${idx}`} className="aspect-square" />;
              }

              const data = getDayData(dayNum);
              const isToday =
                currentYear === today.getFullYear() &&
                currentMonth === today.getMonth() &&
                dayNum === today.getDate();
              const isSelected = selectedDate === data?.date;
              const isClickable = data && data.status !== 'booked' && data.status !== 'emergency-only';
              const meta = data ? STATUS_META[data.status] : null;

              return (
                <button
                  key={dayNum}
                  onClick={() => handleDateClick(dayNum)}
                  disabled={!isClickable}
                  className={`aspect-square flex flex-col items-center justify-center rounded-xl border text-sm transition-all relative ${
                    isSelected
                      ? 'border-orange bg-orange text-white'
                      : isToday
                      ? 'border-charcoal-deep bg-charcoal-deep text-white'
                      : isClickable
                      ? 'border-gray-200 bg-white hover:border-orange/50 hover:bg-orange/5 text-charcoal-deep cursor-pointer'
                      : 'border-gray-100 bg-gray-50 text-gray-300 cursor-not-allowed'
                  }`}
                >
                  <span className={`font-display text-base ${isSelected || isToday ? 'text-white' : ''}`}>
                    {dayNum}
                  </span>
                  {meta && (
                    <span
                      className={`w-1.5 h-1.5 rounded-full mt-0.5 ${
                        isSelected || isToday ? 'bg-white/60' : meta.dot
                      }`}
                    />
                  )}
                  {data && data.crewCount > 0 && (
                    <span
                      className={`text-[8px] mt-0.5 ${
                        isSelected || isToday ? 'text-white/60' : 'text-gray-400'
                      }`}
                    >
                      {data.crewCount} crew{data.crewCount > 1 ? 's' : ''}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center gap-3 mt-4 pt-4 border-t border-gray-100">
            {Object.entries(STATUS_META).map(([key, meta]) => (
              <div key={key} className="flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${meta.dot}`} />
                <span className="text-[10px] text-gray-400 uppercase tracking-wider">{meta.text}</span>
              </div>
            ))}
          </div>

          {/* Day detail panel — appears when a date is selected */}
          {selectedDayData && (
            <div className="mt-6 pt-6 border-t border-gray-100 animate-[fadeIn_0.3s_ease-out]">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h5 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
                    {formatDateDisplay(selectedDayData.date)}
                  </h5>
                  {selectedDayData.note && (
                    <p className="text-gray-400 text-xs mt-0.5">{selectedDayData.note}</p>
                  )}
                </div>
                {selectedDayData.status !== 'booked' && selectedDayData.status !== 'emergency-only' && (
                  <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-[10px] font-bold uppercase tracking-wider ${STATUS_META[selectedDayData.status].badge}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${STATUS_META[selectedDayData.status].dot}`} />
                    {STATUS_META[selectedDayData.status].text}
                  </span>
                )}
              </div>

              {/* Time slots */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 mb-6">
                {selectedDayData.slots.map((slot) => (
                  <button
                    key={slot.time}
                    onClick={() => handleSlotClick(slot)}
                    disabled={!slot.available}
                    className={`flex items-center gap-3 text-left border rounded-xl p-3.5 transition-all ${
                      selectedSlot?.time === slot.time
                        ? 'border-orange bg-orange/5'
                        : slot.available
                        ? 'border-gray-200 hover:border-orange/50 bg-white cursor-pointer'
                        : 'border-gray-100 bg-gray-50 opacity-50 cursor-not-allowed'
                    }`}
                  >
                    <div className="flex-shrink-0">
                      <div
                        className={`w-8 h-8 flex items-center justify-center rounded-lg ${
                          selectedSlot?.time === slot.time
                            ? 'bg-orange text-white'
                            : slot.available
                            ? 'bg-gray-100 text-charcoal-deep'
                            : 'bg-gray-100 text-gray-300'
                        }`}
                      >
                        <i className={`${slot.available ? 'ri-time-line' : 'ri-close-circle-line'} text-sm`} />
                      </div>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className={`text-sm font-semibold ${selectedSlot?.time === slot.time ? 'text-orange' : slot.available ? 'text-charcoal-deep' : 'text-gray-400'}`}>
                        {slot.label}
                      </p>
                      <p className="text-[10px] text-gray-400 mt-0.5">
                        {slot.available ? `Crew: ${slot.crew}` : 'Slot unavailable'}
                      </p>
                    </div>
                    {selectedSlot?.time === slot.time && (
                      <i className="ri-check-line text-orange text-sm flex-shrink-0" />
                    )}
                  </button>
                ))}
              </div>

              {/* Booking form — appears when a slot is selected */}
              {selectedSlot && (
                <div className="bg-gray-50 border border-gray-200 rounded-xl p-5 md:p-6 animate-[slideUp_0.3s_ease-out]">
                  <div className="flex items-center gap-3 mb-5 pb-4 border-b border-gray-200">
                    <div className="w-10 h-10 flex items-center justify-center bg-orange/10 rounded-lg">
                      <i className="ri-calendar-check-line text-orange" />
                    </div>
                    <div>
                      <p className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
                        Confirm Your Appointment
                      </p>
                      <p className="text-gray-400 text-xs">
                        {formatDateDisplay(selectedDayData.date)} at {selectedSlot.label}
                      </p>
                    </div>
                  </div>

                  <form
                    data-readdy-form
                    id="book-appointment-slot"
                    action={BOOKING_FORM_URL}
                    method="POST"
                    onSubmit={handleBookingSubmit}
                    className="space-y-4"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                          Full Name *
                        </label>
                        <input
                          type="text"
                          name="name"
                          required
                          placeholder="John Smith"
                          className="w-full bg-white border border-gray-200 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                        />
                      </div>
                      <div>
                        <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                          Phone *
                        </label>
                        <input
                          type="tel"
                          name="phone"
                          required
                          placeholder="(812) 213-5997"
                          className="w-full bg-white border border-gray-200 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                          Email *
                        </label>
                        <input
                          type="email"
                          name="email"
                          required
                          placeholder="you@email.com"
                          className="w-full bg-white border border-gray-200 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                        />
                      </div>
                      <div>
                        <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                          Property Address
                        </label>
                        <input
                          type="text"
                          name="property_address"
                          defaultValue="1842 Oakmont Drive, Evansville, IN 47714"
                          className="w-full bg-white border border-gray-200 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Notes for the Crew (Optional)
                      </label>
                      <textarea
                        name="crew_notes"
                        rows={2}
                        maxLength={250}
                        placeholder="Gate code, driveway access, pets in yard, preferred arrival window..."
                        className="w-full bg-white border border-gray-200 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
                      />
                    </div>

                    {bookingError && (
                      <p className="text-red-500 text-xs">{bookingError}</p>
                    )}

                    {/* Hidden appointment details */}
                    <input type="hidden" name="appointment_date" value={selectedDate ?? ''} />
                    <input type="hidden" name="appointment_time" value={selectedSlot.time} />
                    <input type="hidden" name="appointment_label" value={selectedSlot.label} />
                    <input type="hidden" name="assigned_crew" value={selectedSlot.crew} />
                    <input type="hidden" name="inspection_date" value="April 28, 2026" />
                    <input type="hidden" name="inspector_name" value="Mike R." />

                    <div className="flex flex-col sm:flex-row gap-3">
                      <button
                        type="submit"
                        className="flex-1 bg-orange hover:bg-orange-dark text-white font-bold text-sm uppercase tracking-widest py-3.5 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                      >
                        <i className="ri-calendar-check-line" />
                        Confirm Appointment
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedSlot(null);
                          setBookingError('');
                        }}
                        className="flex-1 border border-gray-300 hover:border-gray-400 text-charcoal-deep font-bold text-sm uppercase tracking-widest py-3.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                      >
                        Pick a Different Time
                      </button>
                    </div>

                    <p className="text-center text-gray-400 text-xs">
                      No payment required today. You will receive a text confirmation within 5 minutes.
                    </p>
                  </form>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}