import { useState, useEffect, useRef, useCallback } from 'react';
import { ESTIMATE_SCENARIOS, MATERIAL_TIERS } from '@/mocks/estimates';

interface PaymentCalculatorProps {
  activeScenario: typeof ESTIMATE_SCENARIOS[number]['id'];
  activeMaterial: typeof MATERIAL_TIERS[number]['key'];
}

const MONTHLY_RATE = 0.0079; // ~9.5% APR divided by 12 (realistic for home improvement financing)

function calculateMonthlyPayment(principal: number, months: number): number {
  if (months <= 0) return principal;
  // amortized loan formula: P * (r(1+r)^n) / ((1+r)^n - 1)
  const pow = Math.pow(1 + MONTHLY_RATE, months);
  const payment = principal * ((MONTHLY_RATE * pow) / (pow - 1));
  return Math.round(payment);
}

function useAnimatedNumber(target: number, duration = 400) {
  const [display, setDisplay] = useState(target);
  const rafRef = useRef<number | null>(null);
  const startRef = useRef<number>(0);
  const fromRef = useRef<number>(target);

  useEffect(() => {
    fromRef.current = display;
    startRef.current = performance.now();

    const animate = (now: number) => {
      const elapsed = now - startRef.current;
      const progress = Math.min(elapsed / duration, 1);
      // easeOutQuart
      const eased = 1 - Math.pow(1 - progress, 4);
      const current = Math.round(fromRef.current + (target - fromRef.current) * eased);
      setDisplay(current);
      if (progress < 1) {
        rafRef.current = requestAnimationFrame(animate);
      }
    };

    rafRef.current = requestAnimationFrame(animate);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target, duration]);

  return display;
}

/* ─── Animated monthly badge ─── */
function MonthlyBadge({ value, months, isHighlighted }: { value: number; months: number; isHighlighted: boolean }) {
  const animated = useAnimatedNumber(value);
  return (
    <div className={`inline-flex flex-col items-end transition-all duration-300 ${isHighlighted ? 'scale-105' : ''}`}>
      <span className={`font-display text-xl md:text-2xl uppercase tracking-wider ${isHighlighted ? 'text-orange' : 'text-charcoal-deep'}`}>
        ${animated.toLocaleString()}
        <span className="text-sm text-gray-400 normal-case tracking-normal">/mo</span>
      </span>
      <span className="text-[10px] text-gray-400 uppercase tracking-wider">
        {months} months
      </span>
    </div>
  );
}

/* ─── Animated total ─── */
function AnimatedTotal({ value }: { value: number }) {
  const animated = useAnimatedNumber(value);
  return (
    <span className="font-display text-sm text-gray-500 uppercase tracking-wider">
      ${animated.toLocaleString()}
    </span>
  );
}

/* ─── Scenario Card ─── */
function ScenarioCard({
  scenario,
  materialKey,
  months,
  isActiveScenario,
}: {
  scenario: typeof ESTIMATE_SCENARIOS[number];
  materialKey: string;
  months: number;
  isActiveScenario: boolean;
}) {
  return (
    <div className={`bg-white border rounded-2xl overflow-hidden transition-all duration-500 ${isActiveScenario ? 'border-orange shadow-md' : 'border-gray-200'}`}>
      {/* Card Header */}
      <div className={`p-5 md:p-6 transition-colors duration-500 ${isActiveScenario ? 'bg-orange/5' : 'bg-gray-50/50'}`}>
        <div className="flex items-center justify-between mb-2">
          <span className={`text-[10px] uppercase tracking-widest font-semibold ${isActiveScenario ? 'text-orange' : 'text-gray-400'}`}>
            {scenario.shortLabel}
          </span>
          <span className="text-gray-400 text-[10px] uppercase tracking-wider">{scenario.timeline}</span>
        </div>
        <h3 className="font-display text-charcoal-deep text-lg md:text-xl uppercase tracking-wider mb-1">
          {scenario.label}
        </h3>
        <p className="text-gray-500 text-xs leading-relaxed">{scenario.tagline}</p>
      </div>

      {/* Material Tiers */}
      <div className="divide-y divide-gray-100">
        {MATERIAL_TIERS.map((mat) => {
          const totalLow = Math.round(scenario.baseRange[0] * (1 + mat.modifier));
          const totalHigh = Math.round(scenario.baseRange[1] * (1 + mat.modifier));
          const avgTotal = Math.round((totalLow + totalHigh) / 2);
          const monthlyLow = calculateMonthlyPayment(totalLow, months);
          const monthlyHigh = calculateMonthlyPayment(totalHigh, months);
          const avgMonthly = calculateMonthlyPayment(avgTotal, months);
          const isActiveCombo = isActiveScenario && materialKey === mat.key;

          return (
            <div
              key={mat.key}
              className={`p-4 md:p-5 flex items-center justify-between gap-4 transition-all duration-300 ${isActiveCombo ? 'bg-orange/5' : ''}`}
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-sm font-semibold ${isActiveCombo ? 'text-orange' : 'text-charcoal-deep'}`}>
                    {mat.label}
                  </span>
                  {isActiveCombo && (
                    <span className="px-2 py-0.5 bg-orange text-white text-[9px] font-bold uppercase tracking-wider rounded-full">
                      Selected
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 text-[10px] text-gray-400">
                  <span>{mat.shingleType}</span>
                  <span className="text-gray-300">|</span>
                  <span>{mat.warranty}</span>
                </div>
                <div className="mt-1.5 flex items-center gap-1.5">
                  <AnimatedTotal value={avgTotal} />
                  <span className="text-gray-300 text-xs">total est.</span>
                </div>
              </div>

              <MonthlyBadge value={avgMonthly} months={months} isHighlighted={isActiveCombo} />
            </div>
          );
        })}
      </div>

      {/* Mini bar chart — payment as % of most expensive option */}
      <div className="px-5 pb-5 md:px-6 md:pb-6">
        <div className="flex items-end gap-1 h-8 mt-2">
          {MATERIAL_TIERS.map((mat) => {
            const total = Math.round(
              ((scenario.baseRange[0] + scenario.baseRange[1]) / 2) * (1 + mat.modifier)
            );
            const monthly = calculateMonthlyPayment(total, months);
            // find max monthly across all scenarios/tiers for this term
            const allMonthly = ESTIMATE_SCENARIOS.flatMap((s) =>
              MATERIAL_TIERS.map((m) => {
                const t = Math.round(((s.baseRange[0] + s.baseRange[1]) / 2) * (1 + m.modifier));
                return calculateMonthlyPayment(t, months);
              })
            );
            const maxMonthly = Math.max(...allMonthly);
            const pct = maxMonthly > 0 ? (monthly / maxMonthly) * 100 : 0;
            const isActiveCombo = isActiveScenario && materialKey === mat.key;

            return (
              <div key={mat.key} className="flex-1 flex flex-col items-center gap-1">
                <div
                  className={`w-full rounded-t transition-all duration-500 ${isActiveCombo ? 'bg-orange' : 'bg-gray-200'}`}
                  style={{ height: `${Math.max(pct, 8)}%` }}
                />
                <span className="text-[9px] text-gray-400 uppercase tracking-wider">{mat.label.slice(0, 3)}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ─── Main Widget ─── */
export default function PaymentCalculator({ activeScenario, activeMaterial }: PaymentCalculatorProps) {
  const [months, setMonths] = useState(36);
  const [isDragging, setIsDragging] = useState(false);

  const termLabels = [
    { value: 12, label: '12 mo', short: '1yr' },
    { value: 24, label: '24 mo', short: '2yr' },
    { value: 36, label: '36 mo', short: '3yr' },
    { value: 48, label: '48 mo', short: '4yr' },
    { value: 60, label: '60 mo', short: '5yr' },
  ];

  const handleSliderChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setMonths(Number(e.target.value));
  }, []);

  // Generate preset pill values close to standard terms
  const presetValues = [12, 24, 36, 48, 60];

  return (
    <div className="bg-white border border-gray-200 rounded-2xl p-6 md:p-8 shadow-sm">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
        <div>
          <h3 className="font-display text-charcoal-deep text-lg md:text-xl uppercase tracking-wider mb-1">
            Payment Calculator
          </h3>
          <p className="text-gray-500 text-xs">
            Drag to explore monthly payments across every scenario and material tier.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className={`px-4 py-2 rounded-xl border text-center transition-all duration-300 ${isDragging ? 'border-orange bg-orange/5 scale-105' : 'border-gray-200 bg-gray-50'}`}>
            <span className="font-display text-charcoal-deep text-xl uppercase tracking-wider">
              {months}
            </span>
            <span className="text-gray-400 text-xs ml-1">months</span>
          </div>
          <div className="text-right">
            <p className="text-[10px] text-gray-400 uppercase tracking-wider">Est. APR</p>
            <p className="font-display text-sm text-charcoal-deep uppercase tracking-wider">9.5%</p>
          </div>
        </div>
      </div>

      {/* Slider */}
      <div className="mb-10 relative">
        <input
          type="range"
          min={12}
          max={60}
          step={1}
          value={months}
          onChange={handleSliderChange}
          onMouseDown={() => setIsDragging(true)}
          onMouseUp={() => setIsDragging(false)}
          onTouchStart={() => setIsDragging(true)}
          onTouchEnd={() => setIsDragging(false)}
          className="w-full h-2 bg-gray-200 rounded-full appearance-none cursor-pointer accent-orange focus:outline-none"
          style={{
            background: `linear-gradient(to right, #f97316 0%, #f97316 ${((months - 12) / (60 - 12)) * 100}%, #e5e7eb ${((months - 12) / (60 - 12)) * 100}%, #e5e7eb 100%)`,
          }}
        />

        {/* Tick marks */}
        <div className="flex justify-between mt-3 px-1">
          {termLabels.map((t) => (
            <button
              key={t.value}
              onClick={() => setMonths(t.value)}
              className={`flex flex-col items-center gap-1 transition-all cursor-pointer ${months === t.value ? 'scale-110' : ''}`}
            >
              <span
                className={`w-2 h-2 rounded-full transition-colors ${months === t.value ? 'bg-orange' : 'bg-gray-300'}`}
              />
              <span
                className={`text-[10px] uppercase tracking-wider transition-colors ${months === t.value ? 'text-orange font-semibold' : 'text-gray-400'}`}
              >
                {t.label}
              </span>
            </button>
          ))}
        </div>

        {/* Floating value bubble above slider thumb */}
        <div
          className="absolute -top-8 pointer-events-none transition-all duration-150"
          style={{ left: `calc(${((months - 12) / (60 - 12)) * 100}% - 20px)` }}
        >
          <div className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider whitespace-nowrap transition-colors ${isDragging ? 'bg-orange text-white' : 'bg-charcoal-deep text-white'}`}>
            ${Math.round(
              calculateMonthlyPayment(
                Math.round(
                  ((ESTIMATE_SCENARIOS.find(s => s.id === activeScenario)?.baseRange[0] ?? 2400) +
                   (ESTIMATE_SCENARIOS.find(s => s.id === activeScenario)?.baseRange[1] ?? 4800)) / 2 *
                  (1 + (MATERIAL_TIERS.find(m => m.key === activeMaterial)?.modifier ?? 0))
                ),
                months
              )
            ).toLocaleString()}/mo
          </div>
          <div className={`w-2 h-2 rotate-45 mx-auto -mt-1 transition-colors ${isDragging ? 'bg-orange' : 'bg-charcoal-deep'}`} />
        </div>
      </div>

      {/* Scenario Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {ESTIMATE_SCENARIOS.map((scenario) => (
          <ScenarioCard
            key={scenario.id}
            scenario={scenario}
            materialKey={activeMaterial}
            months={months}
            isActiveScenario={activeScenario === scenario.id}
          />
        ))}
      </div>

      {/* Legend / Note */}
      <div className="mt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-5 border-t border-gray-100">
        <div className="flex items-center gap-4 text-[10px] text-gray-400 uppercase tracking-wider">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-1 bg-orange rounded-full" />
            <span>Your Selection</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-1 bg-gray-200 rounded-full" />
            <span>Other Options</span>
          </div>
        </div>
        <p className="text-gray-400 text-[10px] leading-relaxed max-w-md text-left sm:text-right">
          Payment estimates include estimated 9.5% APR. Actual rates vary by credit profile.
          $0 down payment plans available for qualified buyers.
        </p>
      </div>

      {/* Quick preset pills */}
      <div className="mt-5 flex flex-wrap gap-2">
        {presetValues.map((val) => {
          const avgTotal = Math.round(
            ((ESTIMATE_SCENARIOS.find(s => s.id === activeScenario)?.baseRange[0] ?? 2400) +
             (ESTIMATE_SCENARIOS.find(s => s.id === activeScenario)?.baseRange[1] ?? 4800)) / 2 *
            (1 + (MATERIAL_TIERS.find(m => m.key === activeMaterial)?.modifier ?? 0))
          );
          const monthly = calculateMonthlyPayment(avgTotal, val);
          return (
            <button
              key={val}
              onClick={() => setMonths(val)}
              className={`px-3 py-2 rounded-lg border text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                months === val
                  ? 'bg-charcoal-deep text-white border-charcoal-deep'
                  : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'
              }`}
            >
              {val} mo — ${monthly.toLocaleString()}/mo
            </button>
          );
        })}
      </div>
    </div>
  );
}