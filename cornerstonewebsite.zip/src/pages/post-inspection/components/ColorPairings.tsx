import { useState } from 'react';
import { COLOR_PAIRINGS, DEFAULT_PAIRING } from '@/mocks/shingleColors';
import type { ShingleColor } from '@/mocks/shingleColors';

interface ColorPairingsProps {
  color: ShingleColor;
  paletteName?: string;
}

function PrintOverlay({
  color,
  paletteName,
  onClose,
}: {
  color: ShingleColor;
  paletteName?: string;
  onClose: () => void;
}) {
  const pairing = COLOR_PAIRINGS[color.sku] ?? DEFAULT_PAIRING;
  const [copied, setCopied] = useState(false);

  const today = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const textSummary = `CORNER STONE CONSTRUCTION — EXTERIOR PALETTE SUMMARY
======================================================
Property: 1842 Oakmont Drive, Evansville, IN 47714
Generated: ${today}
Roof Material: ${paletteName || 'Architectural Laminated'}

ROOF
  Color: ${color.name}
  SKU:   ${color.sku}
  Hex:   ${color.hex}

SIDING (Recommended)
  Color: ${pairing.siding[0].name}
  Hex:   ${pairing.siding[0].hex}

TRIM (Recommended)
  Color: ${pairing.trim[0].name}
  Hex:   ${pairing.trim[0].hex}

ACCENT (Recommended)
  Color: ${pairing.accent[0].name}
  Hex:   ${pairing.accent[0].hex}

Designer Notes: ${pairing.mood}
${pairing.description}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(textSummary).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 print:p-0 print:bg-white print:static print:block print:z-auto print:backdrop-blur-none">
      <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full overflow-hidden print:shadow-none print:rounded-none print:max-w-none print:w-full">
        {/* Print-only header */}
        <div className="hidden print:flex print:items-center print:gap-3 print:px-8 print:pt-8 print:pb-4 print:border-b print:border-gray-200">
          <div className="w-10 h-10 flex items-center justify-center bg-orange/10 rounded-xl">
            <i className="ri-home-gear-line text-orange text-lg" />
          </div>
          <div>
            <h2 className="font-display text-charcoal-deep text-base uppercase tracking-wider">
              Corner Stone Construction
            </h2>
            <p className="text-gray-400 text-xs">Exterior Palette Summary</p>
          </div>
        </div>

        {/* Screen header with close */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 print:hidden">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 flex items-center justify-center bg-orange/10 rounded-lg">
              <i className="ri-printer-line text-orange" />
            </div>
            <div>
              <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
                Print / Save Palette
              </h3>
              <p className="text-gray-400 text-[10px]">For your siding contractor</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-charcoal-deep transition-colors cursor-pointer"
          >
            <i className="ri-close-line text-lg" />
          </button>
        </div>

        {/* Card body */}
        <div className="p-6 md:p-8">
          {/* Property info */}
          <div className="mb-6 pb-4 border-b border-gray-100">
            <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-1">
              Property
            </p>
            <p className="text-charcoal-deep text-sm font-semibold">
              1842 Oakmont Drive, Evansville, IN 47714
            </p>
            <p className="text-gray-400 text-xs mt-0.5">Generated {today}</p>
          </div>

          {/* Color rows */}
          <div className="space-y-4">
            {/* Roof */}
            <div className="flex items-start gap-4">
              <div
                className="w-14 h-14 rounded-xl border border-gray-200 flex-shrink-0 shadow-sm"
                style={{ backgroundColor: color.hex }}
              />
              <div className="min-w-0 flex-1">
                <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold">
                  Roof
                </p>
                <p className="text-charcoal-deep text-base font-semibold">
                  {color.name}
                </p>
                <div className="flex flex-wrap items-center gap-2 mt-1">
                  <span className="text-gray-500 text-xs font-mono bg-gray-50 border border-gray-100 px-2 py-0.5 rounded">
                    {color.sku}
                  </span>
                  <span className="text-gray-500 text-xs font-mono bg-gray-50 border border-gray-100 px-2 py-0.5 rounded">
                    {color.hex}
                  </span>
                  {paletteName && (
                    <span className="text-gray-400 text-xs">{paletteName}</span>
                  )}
                </div>
              </div>
            </div>

            {/* Siding */}
            <div className="flex items-start gap-4">
              <div
                className="w-14 h-14 rounded-xl border border-gray-200 flex-shrink-0 shadow-sm"
                style={{ backgroundColor: pairing.siding[0].hex }}
              />
              <div className="min-w-0 flex-1">
                <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold">
                  Siding (Primary)
                </p>
                <p className="text-charcoal-deep text-base font-semibold">
                  {pairing.siding[0].name}
                </p>
                <span className="text-gray-500 text-xs font-mono bg-gray-50 border border-gray-100 px-2 py-0.5 rounded mt-1 inline-block">
                  {pairing.siding[0].hex}
                </span>
              </div>
            </div>

            {/* Trim */}
            <div className="flex items-start gap-4">
              <div
                className="w-14 h-14 rounded-xl border border-gray-200 flex-shrink-0 shadow-sm"
                style={{ backgroundColor: pairing.trim[0].hex }}
              />
              <div className="min-w-0 flex-1">
                <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold">
                  Trim
                </p>
                <p className="text-charcoal-deep text-base font-semibold">
                  {pairing.trim[0].name}
                </p>
                <span className="text-gray-500 text-xs font-mono bg-gray-50 border border-gray-100 px-2 py-0.5 rounded mt-1 inline-block">
                  {pairing.trim[0].hex}
                </span>
              </div>
            </div>

            {/* Accent */}
            <div className="flex items-start gap-4">
              <div
                className="w-14 h-14 rounded-xl border border-gray-200 flex-shrink-0 shadow-sm"
                style={{ backgroundColor: pairing.accent[0].hex }}
              />
              <div className="min-w-0 flex-1">
                <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold">
                  Accent — {pairing.accent[0].use}
                </p>
                <p className="text-charcoal-deep text-base font-semibold">
                  {pairing.accent[0].name}
                </p>
                <span className="text-gray-500 text-xs font-mono bg-gray-50 border border-gray-100 px-2 py-0.5 rounded mt-1 inline-block">
                  {pairing.accent[0].hex}
                </span>
              </div>
            </div>
          </div>

          {/* Designer notes */}
          <div className="mt-6 pt-5 border-t border-gray-100">
            <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-2">
              Designer Notes — {pairing.mood}
            </p>
            <p className="text-gray-500 text-sm leading-relaxed">
              {pairing.description}
            </p>
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex flex-wrap items-center justify-between gap-3 print:hidden">
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 bg-charcoal-deep hover:bg-charcoal text-white font-bold text-xs uppercase tracking-widest px-4 py-2.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-printer-line" />
              Print
            </button>
            <button
              onClick={handleCopy}
              className="inline-flex items-center gap-2 border border-gray-300 hover:border-gray-400 text-charcoal-deep font-bold text-xs uppercase tracking-widest px-4 py-2.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className={`${copied ? 'ri-check-line text-green-600' : 'ri-file-copy-line'} transition-colors`} />
              {copied ? 'Copied!' : 'Copy as Text'}
            </button>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-charcoal-deep text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

export default function ColorPairings({ color, paletteName }: ColorPairingsProps) {
  const [showPrint, setShowPrint] = useState(false);
  const pairing = COLOR_PAIRINGS[color.sku] ?? DEFAULT_PAIRING;

  return (
    <>
      <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm">
        {/* Header */}
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div
              className="w-10 h-10 rounded-xl border border-gray-200 flex-shrink-0 shadow-sm"
              style={{ backgroundColor: color.hex }}
            />
            <div className="min-w-0">
              <h4 className="font-display text-charcoal-deep text-sm uppercase tracking-wider truncate">
                {color.name}
              </h4>
              {paletteName && (
                <p className="text-gray-400 text-[10px]">{paletteName}</p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              onClick={() => setShowPrint(true)}
              className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-orange transition-colors cursor-pointer"
              title="Print / Save Palette"
            >
              <i className="ri-printer-line" />
            </button>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange/10 text-orange text-[10px] font-bold uppercase tracking-wider whitespace-nowrap">
              <i className="ri-palette-line" />
              {pairing.mood}
            </span>
          </div>
        </div>

        {/* Three pairing categories */}
        <div className="p-5 grid grid-cols-1 sm:grid-cols-3 gap-5">
          {/* Siding */}
          <div>
            <p className="text-charcoal-deep text-[10px] uppercase tracking-widest font-semibold mb-3 flex items-center gap-1.5">
              <i className="ri-home-4-line text-orange" />
              Siding Colors
            </p>
            <div className="space-y-3">
              {pairing.siding.map((s) => (
                <div key={s.name} className="flex items-center gap-3">
                  <div
                    className="w-8 h-8 rounded-lg border border-gray-200 flex-shrink-0 shadow-sm"
                    style={{ backgroundColor: s.hex }}
                  />
                  <div className="min-w-0">
                    <p className="text-charcoal-deep text-xs font-semibold truncate">{s.name}</p>
                    <p className="text-gray-400 text-[10px]">{s.vibe}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Trim */}
          <div>
            <p className="text-charcoal-deep text-[10px] uppercase tracking-widest font-semibold mb-3 flex items-center gap-1.5">
              <i className="ri-layout-top-2-line text-orange" />
              Trim Colors
            </p>
            <div className="space-y-3">
              {pairing.trim.map((t) => (
                <div key={t.name} className="flex items-center gap-3">
                  <div
                    className="w-8 h-8 rounded-lg border border-gray-200 flex-shrink-0 shadow-sm"
                    style={{ backgroundColor: t.hex }}
                  />
                  <div className="min-w-0">
                    <p className="text-charcoal-deep text-xs font-semibold truncate">{t.name}</p>
                    <p className="text-gray-400 text-[10px]">{t.accent}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Accent */}
          <div>
            <p className="text-charcoal-deep text-[10px] uppercase tracking-widest font-semibold mb-3 flex items-center gap-1.5">
              <i className="ri-door-open-line text-orange" />
              Accent Colors
            </p>
            <div className="space-y-3">
              {pairing.accent.map((a) => (
                <div key={a.name} className="flex items-center gap-3">
                  <div
                    className="w-8 h-8 rounded-lg border border-gray-200 flex-shrink-0 shadow-sm"
                    style={{ backgroundColor: a.hex }}
                  />
                  <div className="min-w-0">
                    <p className="text-charcoal-deep text-xs font-semibold truncate">{a.name}</p>
                    <p className="text-gray-400 text-[10px]">{a.use}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Description */}
        <div className="px-5 pb-5">
          <div className="bg-gray-50 border border-gray-100 rounded-xl p-4">
            <div className="flex items-start gap-2">
              <i className="ri-lightbulb-line text-orange text-sm mt-0.5 flex-shrink-0" />
              <p className="text-gray-500 text-xs leading-relaxed">
                {pairing.description}
              </p>
            </div>
          </div>
        </div>
      </div>

      {showPrint && (
        <PrintOverlay
          color={color}
          paletteName={paletteName}
          onClose={() => setShowPrint(false)}
        />
      )}
    </>
  );
}