import { useState, useRef, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import MyProjectsBadge from '@/components/feature/MyProjectsBadge';
import { PHOTO_REPORTS, REPORT_SUMMARY } from '@/mocks/photoReport';
import { ESTIMATE_SCENARIOS, MATERIAL_TIERS } from '@/mocks/estimates';
import PaymentCalculator from './components/PaymentCalculator';
import ShareReport from './components/ShareReport';
import AppointmentCalendar from './components/AppointmentCalendar';
import ChatWithInspector from './components/ChatWithInspector';
import WeatherAlert from './components/WeatherAlert';
import RoofAgeTimeline from './components/RoofAgeTimeline';
import MaterialComparison from './components/MaterialComparison';
import ShingleVisualizer from './components/ShingleVisualizer';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

/* ─── severity helpers ─── */
const SEVERITY_META = {
  critical: { label: 'Critical', dot: 'bg-red-500', badge: 'bg-red-50 text-red-700 border-red-200' },
  warning: { label: 'Warning', dot: 'bg-amber-500', badge: 'bg-amber-50 text-amber-700 border-amber-200' },
  info: { label: 'Info', dot: 'bg-blue-500', badge: 'bg-sky-50 text-sky-700 border-sky-200' },
} as const;

/* ─── status tracker steps ─── */
const STATUS_STEPS = [
  { id: 'booked', label: 'Inspection Booked', icon: 'ri-calendar-check-line' },
  { id: 'complete', label: 'Inspection Complete', icon: 'ri-search-eye-line' },
  { id: 'review', label: 'Report in Review', icon: 'ri-file-list-3-line' },
  { id: 'photos', label: 'Photos Ready', icon: 'ri-image-line' },
  { id: 'delivered', label: 'Report Delivered', icon: 'ri-mail-check-line' },
];
const CURRENT_STATUS = 'photos'; // pretend we're at "Photos Ready"

/* ─── photo severity filter ─── */
const FILTERS = [
  { key: 'all', label: 'All Photos', count: PHOTO_REPORTS.length },
  { key: 'critical', label: 'Critical', count: PHOTO_REPORTS.filter((p) => p.severity === 'critical').length },
  { key: 'warning', label: 'Warning', count: PHOTO_REPORTS.filter((p) => p.severity === 'warning').length },
  { key: 'info', label: 'Info', count: PHOTO_REPORTS.filter((p) => p.severity === 'info').length },
] as const;

/* ─── repair type options ─── */
const REPAIR_TYPES = [
  { key: 'repair', label: 'Repairs Only', desc: 'Fix specific damaged areas' },
  { key: 'replacement', label: 'Full Replacement', desc: 'Replace the entire roof system' },
  { key: 'both', label: 'Repairs + Replacement', desc: 'Repair now, replace later' },
] as const;

const URGENCY_OPTIONS = [
  { key: 'asap', label: 'ASAP', desc: 'Within 3–5 days' },
  { key: '2weeks', label: 'Within 2 Weeks', desc: 'Flexible but soon' },
  { key: 'flexible', label: 'Flexible', desc: 'No hard deadline' },
] as const;

/* ─── main page ─── */
export default function PostInspectionPage() {
  const navigate = useNavigate();
  const [activeFilter, setActiveFilter] = useState<'all' | 'critical' | 'warning' | 'info'>('all');
  const [lightboxIdx, setLightboxIdx] = useState<number | null>(null);

  /* schedule repair form state */
  const [repairType, setRepairType] = useState<'repair' | 'replacement' | 'both'>('repair');
  const [urgency, setUrgency] = useState<'asap' | '2weeks' | 'flexible'>('2weeks');
  const [repairSubmitted, setRepairSubmitted] = useState(false);

  /* compare estimates state */
  const [activeScenario, setActiveScenario] = useState<typeof ESTIMATE_SCENARIOS[number]['id']>('repair-only');
  const [activeMaterial, setActiveMaterial] = useState<typeof MATERIAL_TIERS[number]['key']>('standard');

  /* mobile swipeable estimate cards */
  const [mobileScenarioIdx, setMobileScenarioIdx] = useState(0);
  const mobileCardRef = useRef<HTMLDivElement>(null);
  const touchStartX = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);

  const onMobileTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.changedTouches[0].screenX;
  };
  const onMobileTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.changedTouches[0].screenX;
  };
  const onMobileTouchEnd = () => {
    if (touchStartX.current === null || touchEndX.current === null) return;
    const diff = touchStartX.current - touchEndX.current;
    const threshold = 50;
    if (diff > threshold && mobileScenarioIdx < ESTIMATE_SCENARIOS.length - 1) {
      setMobileScenarioIdx((i) => i + 1);
    } else if (diff < -threshold && mobileScenarioIdx > 0) {
      setMobileScenarioIdx((i) => i - 1);
    }
    touchStartX.current = null;
    touchEndX.current = null;
  };

  /* financing pre-approval form state */
  const [paymentPlan, setPaymentPlan] = useState<'12' | '24' | '36' | '60'>('36');
  const [financingSubmitted, setFinancingSubmitted] = useState(false);

  /* upload */
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadedFiles, setUploadedFiles] = useState<{ name: string; size: string }[]>([
    { name: 'Insurance_Claim_2026.pdf', size: '2.4 MB' },
    { name: 'Adjuster_Notes_May1.pdf', size: '1.1 MB' },
  ]);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'success'>('idle');

  const filteredPhotos =
    activeFilter === 'all'
      ? PHOTO_REPORTS
      : PHOTO_REPORTS.filter((p) => p.severity === activeFilter);

  /* lightbox helpers */
  const openLightbox = (idx: number) => setLightboxIdx(idx);
  const closeLightbox = () => setLightboxIdx(null);
  const nextPhoto = useCallback(() => {
    if (lightboxIdx === null) return;
    setLightboxIdx((lightboxIdx + 1) % filteredPhotos.length);
  }, [lightboxIdx, filteredPhotos.length]);
  const prevPhoto = useCallback(() => {
    if (lightboxIdx === null) return;
    setLightboxIdx((lightboxIdx - 1 + filteredPhotos.length) % filteredPhotos.length);
  }, [lightboxIdx, filteredPhotos.length]);

  /* keyboard nav in lightbox */
  const onLightboxKey = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowRight') nextPhoto();
      if (e.key === 'ArrowLeft') prevPhoto();
    },
    [nextPhoto, prevPhoto]
  );

  /* upload handler */
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploadStatus('uploading');
    // simulate upload delay
    setTimeout(() => {
      const newFiles = Array.from(files).map((f) => ({
        name: f.name,
        size: `${(f.size / (1024 * 1024)).toFixed(1)} MB`,
      }));
      setUploadedFiles((prev) => [...prev, ...newFiles]);
      setUploadStatus('success');
      setTimeout(() => setUploadStatus('idle'), 2500);
    }, 1200);
  };

  const removeFile = (name: string) => {
    setUploadedFiles((prev) => prev.filter((f) => f.name !== name));
  };

  const handleRepairSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);
    data.append('access_key', WEB3FORMS_ACCESS_KEY);
    fetch(form.action, {
      method: 'POST',
      body: new URLSearchParams(data as unknown as Record<string, string>),
    })
      .then(() => setRepairSubmitted(true))
      .catch(() => setRepairSubmitted(true));
  };

  const handleFinancingSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);
    data.append('access_key', WEB3FORMS_ACCESS_KEY);
    fetch(form.action, {
      method: 'POST',
      body: new URLSearchParams(data as unknown as Record<string, string>),
    })
      .then(() => setFinancingSubmitted(true))
      .catch(() => setFinancingSubmitted(true));
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <PageSEO
        title="Your Inspection Report | Corner Stone Construction & Roofing"
        description="View your roof inspection photo report, track report status, and upload insurance documents."
        keywords="roof inspection report, photo report, roof damage photos, insurance claim upload"
        canonical="/post-inspection"
      />

      <main className="flex-1">
        {/* ── HERO / STATUS TRACKER ── */}
        <section className="bg-charcoal-deep pt-20 pb-12 md:pt-28 md:pb-16 px-6 md:px-10 lg:px-16 relative">
          <div className="max-w-6xl mx-auto relative">
            {/* My Projects quick-access badge */}
            <MyProjectsBadge className="absolute top-0 right-0 z-10" />

            <div className="text-center mb-10">
              <div className="inline-flex items-center gap-2 border border-orange/30 bg-orange/10 px-4 py-1.5 text-orange text-xs uppercase tracking-widest mb-6">
                <i className="ri-shield-check-line text-sm" />
                Inspection Complete
              </div>
              <h1 className="font-display text-white uppercase tracking-wider text-3xl md:text-5xl leading-none mb-4">
                Your Inspection Report
              </h1>
              <p className="text-white/50 text-base md:text-lg max-w-2xl mx-auto leading-relaxed">
                Your certified inspector visited your property on{' '}
                <strong className="text-white">April 28, 2026</strong>. Review your photo report, upload insurance documents, and track what&apos;s next.
              </p>
            </div>

            {/* Status Tracker */}
            <div className="flex flex-wrap justify-center gap-2 md:gap-0 md:justify-between max-w-4xl mx-auto">
              {STATUS_STEPS.map((step, i) => {
                const isActive = step.id === CURRENT_STATUS;
                const isPast =
                  STATUS_STEPS.findIndex((s) => s.id === CURRENT_STATUS) > i;
                return (
                  <div
                    key={step.id}
                    className={`flex items-center gap-2 px-3 py-2 md:px-4 md:py-2.5 rounded-full border text-xs font-semibold uppercase tracking-wider transition-colors ${
                      isActive
                        ? 'bg-orange border-orange text-white'
                        : isPast
                        ? 'bg-green-500/10 border-green-500/30 text-green-400'
                        : 'bg-white/5 border-white/10 text-white/30'
                    }`}
                  >
                    <i className={`${step.icon} text-sm`} />
                    <span className="hidden sm:inline">{step.label}</span>
                    {isPast && (
                      <i className="ri-check-line text-sm ml-0.5" />
                    )}
                  </div>
                );
              })}
            </div>

            {/* Customer Portal Card */}
            <div className="mt-8 max-w-4xl mx-auto">
              <div className="bg-gradient-to-r from-orange/10 via-orange/5 to-transparent border border-orange/20 rounded-xl p-5 md:p-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex items-start gap-3 min-w-0">
                  <div className="w-10 h-10 flex items-center justify-center bg-orange/20 rounded-lg flex-shrink-0">
                    <i className="ri-folder-user-line text-orange text-lg" />
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-white text-sm font-bold uppercase tracking-wider mb-1">
                      Customer Portal
                    </h3>
                    <p className="text-white/40 text-xs leading-relaxed max-w-lg">
                      Track your project timeline, photos, messages, and documents in real time. Your inspection report is already synced — jump in and see what's next.
                    </p>
                  </div>
                </div>
                <Link
                  to="/customer-portal"
                  className="inline-flex items-center gap-2 bg-orange hover:bg-orange-dark text-white font-bold text-xs uppercase tracking-widest px-5 py-2.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap flex-shrink-0"
                >
                  <i className="ri-arrow-right-up-line" />
                  Open My Projects
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* ── REPORT SUMMARY CARD ── */}
        <section className="py-10 md:py-14 px-6 md:px-10 lg:px-16 bg-gray-50 border-b border-gray-200">
          <div className="max-w-5xl mx-auto">
            <div className="bg-white border border-gray-200 rounded-2xl p-6 md:p-10 shadow-sm">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
                <div>
                  <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-1">
                    Overall Condition
                  </p>
                  <div className="flex items-center gap-3">
                    <h2 className="font-display text-charcoal-deep text-2xl md:text-3xl uppercase tracking-wider">
                      {REPORT_SUMMARY.overallCondition}
                    </h2>
                    <span
                      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-bold uppercase tracking-wider ${
                        SEVERITY_META[REPORT_SUMMARY.overallSeverity].badge
                      }`}
                    >
                      <span
                        className={`w-2 h-2 rounded-full ${
                          SEVERITY_META[REPORT_SUMMARY.overallSeverity].dot
                        }`}
                      />
                      {SEVERITY_META[REPORT_SUMMARY.overallSeverity].label}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => navigate('/insurance-claims')}
                  className="inline-flex items-center gap-2 bg-orange hover:bg-orange-dark text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-file-list-3-line" />
                  Start Insurance Claim
                </button>
              </div>

              {/* Metrics grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                {[
                  { label: 'Roof Age', value: REPORT_SUMMARY.estimatedAge, icon: 'ri-time-line' },
                  { label: 'Expected Lifespan', value: REPORT_SUMMARY.expectedLifespan, icon: 'ri-hourglass-line' },
                  { label: 'Total Photos', value: String(REPORT_SUMMARY.totalPhotos), icon: 'ri-image-line' },
                  { label: 'Critical Issues', value: String(REPORT_SUMMARY.criticalItems), icon: 'ri-error-warning-line', highlight: true },
                ].map((m) => (
                  <div
                    key={m.label}
                    className={`bg-gray-50 border border-gray-100 rounded-xl p-4 ${
                      m.highlight ? 'border-red-200 bg-red-50/30' : ''
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <i className={`${m.icon} ${m.highlight ? 'text-red-500' : 'text-orange'} text-sm`} />
                      <span className="text-gray-400 text-[10px] uppercase tracking-wider font-semibold">
                        {m.label}
                      </span>
                    </div>
                    <p
                      className={`font-display text-lg md:text-xl uppercase tracking-wider ${
                        m.highlight ? 'text-red-600' : 'text-charcoal-deep'
                      }`}
                    >
                      {m.value}
                    </p>
                  </div>
                ))}
              </div>

              {/* Inspector Notes */}
              <div className="border-t border-gray-100 pt-6">
                <div className="flex items-start gap-3 mb-4">
                  <div className="w-9 h-9 flex items-center justify-center bg-orange/10 rounded-lg flex-shrink-0">
                    <i className="ri-user-settings-line text-orange text-base" />
                  </div>
                  <div>
                    <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
                      Inspector Notes
                    </h3>
                    <p className="text-gray-400 text-xs mt-0.5">
                      Certified Inspector — Mike R.
                    </p>
                  </div>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed bg-gray-50 rounded-xl p-4 border border-gray-100">
                  {REPORT_SUMMARY.inspectorNotes}
                </p>
              </div>

              {/* Estimate range */}
              <div className="border-t border-gray-100 pt-6 mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-green-50 border border-green-200 rounded-xl p-5">
                  <p className="text-green-700 text-[10px] uppercase tracking-widest font-semibold mb-1">
                    Repair Estimate Range
                  </p>
                  <p className="font-display text-green-800 text-xl uppercase tracking-wider">
                    {REPORT_SUMMARY.estimatedRepairRange}
                  </p>
                  <p className="text-green-600/70 text-xs mt-1">
                    Hail damage + missing shingles + flashing re-seal
                  </p>
                </div>
                <div className="bg-gray-50 border border-gray-200 rounded-xl p-5">
                  <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-1">
                    Full Replacement Estimate
                  </p>
                  <p className="font-display text-charcoal-deep text-xl uppercase tracking-wider">
                    {REPORT_SUMMARY.fullReplacementEstimate}
                  </p>
                  <p className="text-gray-400 text-xs mt-1">
                    If repair is not viable — 18–22 year system
                  </p>
                </div>
              </div>

              {/* Next action CTA */}
              <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
                <a
                  href="#compare-estimates"
                  className="inline-flex items-center gap-2 bg-charcoal-deep hover:bg-charcoal text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-file-list-3-line" />
                  Compare Estimates
                </a>
                <a
                  href="#photo-report"
                  className="inline-flex items-center gap-2 bg-gray-800 hover:bg-gray-700 text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-image-line" />
                  View Photo Report
                </a>
                <a
                  href="#schedule-repair"
                  className="inline-flex items-center gap-2 bg-orange hover:bg-orange-dark text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-calendar-check-line" />
                  Schedule Repair
                </a>
                <a
                  href="#financing-preapproval"
                  className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-bank-card-line" />
                  Financing Pre-Approval
                </a>
                <a
                  href="#upload"
                  className="inline-flex items-center gap-2 border border-gray-300 hover:border-gray-400 text-charcoal-deep font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors whitespace-nowrap"
                >
                  <i className="ri-upload-cloud-2-line" />
                  Upload Docs
                </a>
                <a
                  href="#share-report"
                  className="inline-flex items-center gap-2 bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-share-forward-line" />
                  Share Report
                </a>
                <a
                  href="#appointment-calendar"
                  className="inline-flex items-center gap-2 bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-calendar-event-line" />
                  Book Appointment
                </a>
                <a
                  href="#chat-inspector"
                  className="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-message-3-line" />
                  Chat with Inspector
                </a>
                <a
                  href="#weather-alert"
                  className="inline-flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-heavy-showers-line" />
                  Weather Alert
                </a>
                <a
                  href="#roof-timeline"
                  className="inline-flex items-center gap-2 bg-stone-600 hover:bg-stone-700 text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-timeline-view" />
                  Roof Timeline
                </a>
                <a
                  href="#material-comparison"
                  className="inline-flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-stack-line" />
                  Compare Materials
                </a>
                <a
                  href="#shingle-visualizer"
                  className="inline-flex items-center gap-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-palette-line" />
                  Color Visualizer
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* ── ROOF AGE TIMELINE ── */}
        <section id="roof-timeline" className="py-14 md:py-20 px-6 md:px-10 lg:px-16 bg-gray-50 border-y border-gray-200">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-10">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">
                Lifecycle Visualization
              </p>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
                Your Roof Age Timeline
              </h2>
              <p className="text-gray-500 text-sm max-w-lg mx-auto leading-relaxed">
                See exactly where your 14-year roof sits in its 22-year expected lifespan. Click any stage to explore what maintenance looks like at each phase and when to start budgeting for replacement.
              </p>
            </div>
            <RoofAgeTimeline />
          </div>
        </section>

        {/* ── MATERIAL COMPARISON ── */}
        <section id="material-comparison" className="py-14 md:py-20 px-6 md:px-10 lg:px-16 bg-white border-y border-gray-200">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-10">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">
                Side-by-Side Analysis
              </p>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
                Material Comparison
              </h2>
              <p className="text-gray-500 text-sm max-w-xl mx-auto leading-relaxed">
                See how 3-tab, architectural, and premium designer shingles stack up on lifespan, warranty, wind resistance, and total lifetime cost — with your inspector's personalized recommendation.
              </p>
            </div>
            <MaterialComparison />
          </div>
        </section>

        {/* ── SHINGLE VISUALIZER ── */}
        <section id="shingle-visualizer" className="py-14 md:py-20 px-6 md:px-10 lg:px-16 bg-stone-50 border-y border-stone-200">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-10">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">
                See It On Your Home
              </p>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
                Shingle Visualizer
              </h2>
              <p className="text-gray-500 text-sm max-w-xl mx-auto leading-relaxed">
                Pick colors from each material tier and see how they would actually look on your roof. Pin colors to compare them side-by-side on the same house, then try them on real local homes from our Evansville project portfolio.
              </p>
            </div>
            <ShingleVisualizer />
          </div>
        </section>

        {/* ── PHOTO REPORT GALLERY ── */}
        <section id="photo-report" className="py-14 md:py-20 px-6 md:px-10 lg:px-16">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-10">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">
                Photo Documentation
              </p>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
                Your Photo Report
              </h2>
              <p className="text-gray-500 text-sm max-w-xl mx-auto">
                Every issue documented with photos, location tags, and severity ratings. Click any photo to zoom in.
              </p>
            </div>

            {/* Filter bar */}
            <div className="flex flex-wrap justify-center gap-2 mb-8">
              {FILTERS.map((f) => (
                <button
                  key={f.key}
                  onClick={() => setActiveFilter(f.key)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold uppercase tracking-wider border transition-all cursor-pointer whitespace-nowrap ${
                    activeFilter === f.key
                      ? 'bg-charcoal-deep text-white border-charcoal-deep shadow-sm'
                      : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'
                  }`}
                >
                  {f.label}
                  <span
                    className={`inline-flex items-center justify-center w-5 h-5 rounded-full text-[10px] ${
                      activeFilter === f.key ? 'bg-white/20 text-white' : 'bg-gray-100 text-gray-500'
                    }`}
                  >
                    {f.count}
                  </span>
                </button>
              ))}
            </div>

            {/* Photo grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {filteredPhotos.map((photo, idx) => {
                const meta = SEVERITY_META[photo.severity];
                return (
                  <div
                    key={photo.id}
                    className="group bg-white border border-gray-200 rounded-xl overflow-hidden hover:border-orange/30 transition-all duration-300 shadow-sm hover:shadow-md cursor-pointer"
                    onClick={() => openLightbox(idx)}
                  >
                    {/* Image container */}
                    <div className="relative aspect-[3/2] overflow-hidden bg-gray-100">
                      <img
                        src={photo.image}
                        alt={photo.label}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        loading="lazy"
                      />
                      {/* severity badge */}
                      <div className="absolute top-3 left-3">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-[10px] font-bold uppercase tracking-wider bg-white/90 backdrop-blur-sm ${meta.badge}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${meta.dot}`} />
                          {meta.label}
                        </span>
                      </div>
                      {/* zoom icon */}
                      <div className="absolute bottom-3 right-3 w-8 h-8 flex items-center justify-center bg-charcoal-deep/80 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                        <i className="ri-zoom-in-line" />
                      </div>
                    </div>

                    {/* Info */}
                    <div className="p-4">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-orange text-[10px] uppercase tracking-widest font-semibold">
                          {photo.category}
                        </span>
                        <span className="text-gray-300">|</span>
                        <span className="text-gray-400 text-[10px] uppercase tracking-wider">
                          {photo.area}
                        </span>
                      </div>
                      <h3 className="text-charcoal-deep font-semibold text-sm mb-2 group-hover:text-orange transition-colors">
                        {photo.label}
                      </h3>
                      <p className="text-gray-500 text-xs leading-relaxed line-clamp-2">
                        {photo.notes}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* ── COMPARE ESTIMATES ── */}
        <section id="compare-estimates" className="py-14 md:py-20 px-4 sm:px-6 md:px-10 lg:px-16 bg-amber-50/40 border-y border-amber-100 overflow-hidden">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8 md:mb-10">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">
                Cost Breakdowns
              </p>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
                Compare Estimates
              </h2>
              <p className="text-gray-500 text-sm max-w-xl mx-auto leading-relaxed">
                Toggle between repair-only, partial replacement, and full replacement to see exactly what each option costs and what materials you get.
              </p>
            </div>

            {/* Desktop: scenario toggle + grid layout */}
            <div className="hidden md:block">
              <div className="flex flex-wrap justify-center gap-2 mb-6">
                {ESTIMATE_SCENARIOS.map((s) => {
                  const isActive = activeScenario === s.id;
                  return (
                    <button
                      key={s.id}
                      onClick={() => setActiveScenario(s.id)}
                      className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-xs font-bold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                        isActive
                          ? 'bg-charcoal-deep text-white border-charcoal-deep shadow-sm'
                          : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      {s.label}
                      {isActive && (
                        <span className="text-[10px] normal-case tracking-normal font-normal opacity-70">
                          {s.timeline}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Scenario detail card */}
              {(() => {
                const scenario = ESTIMATE_SCENARIOS.find((s) => s.id === activeScenario)!;
                const mat = MATERIAL_TIERS.find((m) => m.key === activeMaterial)!;
                const low = Math.round(scenario.baseRange[0] * (1 + mat.modifier));
                const high = Math.round(scenario.baseRange[1] * (1 + mat.modifier));

                return (
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Left column — overview + material selector */}
                    <div className="lg:col-span-1 space-y-5">
                      {/* Total cost card */}
                      <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
                        <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-1">
                          Estimated Total
                        </p>
                        <p className="font-display text-charcoal-deep text-3xl uppercase tracking-wider mb-1">
                          ${low.toLocaleString()} – ${high.toLocaleString()}
                        </p>
                        <p className="text-gray-400 text-xs mb-4">
                          Range depends on material tier and job complexity
                        </p>
                        <div className="flex items-center gap-2 text-xs text-gray-500 mb-1">
                          <i className="ri-time-line text-orange" />
                          <span>{scenario.timeline}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-gray-500">
                          <i className="ri-shield-check-line text-green-500" />
                          <span>{scenario.warranty}</span>
                        </div>
                      </div>

                      {/* Material selector */}
                      <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
                        <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-3">
                          Material Tier
                        </p>
                        <div className="space-y-2">
                          {MATERIAL_TIERS.map((m) => {
                            const mLow = Math.round(scenario.baseRange[0] * (1 + m.modifier));
                            const mHigh = Math.round(scenario.baseRange[1] * (1 + m.modifier));
                            const isSel = activeMaterial === m.key;
                            return (
                              <button
                                key={m.key}
                                onClick={() => setActiveMaterial(m.key)}
                                className={`w-full text-left border rounded-xl p-4 transition-all cursor-pointer ${
                                  isSel
                                    ? 'border-orange bg-orange/5'
                                    : 'border-gray-200 hover:border-gray-300'
                                }`}
                              >
                                <div className="flex items-center justify-between mb-1">
                                  <span className="text-sm font-semibold text-charcoal-deep">{m.label}</span>
                                  <span className="text-xs text-gray-400">
                                    ${mLow.toLocaleString()}–${mHigh.toLocaleString()}
                                  </span>
                                </div>
                                <p className="text-gray-500 text-xs">{m.description}</p>
                                {isSel && (
                                  <div className="mt-2 flex flex-wrap gap-1">
                                    <span className="px-2 py-0.5 bg-gray-100 rounded text-[10px] text-gray-500">{m.shingleType}</span>
                                    <span className="px-2 py-0.5 bg-gray-100 rounded text-[10px] text-gray-500">{m.underlayment}</span>
                                    <span className="px-2 py-0.5 bg-gray-100 rounded text-[10px] text-gray-500">{m.colorOptions}</span>
                                  </div>
                                )}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Scenario description */}
                      <div className="bg-charcoal-deep rounded-2xl p-6">
                        <h3 className="font-display text-white text-sm uppercase tracking-wider mb-2">
                          {scenario.label}
                        </h3>
                        <p className="text-white/60 text-xs leading-relaxed mb-3">
                          {scenario.description}
                        </p>
                        <p className="text-orange text-[10px] uppercase tracking-widest font-semibold">
                          {scenario.tagline}
                        </p>
                      </div>
                    </div>

                    {/* Right column — line items */}
                    <div className="lg:col-span-2">
                      <div className="bg-white border border-gray-200 rounded-2xl p-6 md:p-8 shadow-sm">
                        <div className="flex items-center justify-between mb-6">
                          <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider">
                            Line Items
                          </h3>
                          <span className="text-gray-400 text-[10px] uppercase tracking-wider">
                            {mat.label} Materials
                          </span>
                        </div>

                        <div className="space-y-1">
                          {scenario.lineItems.map((item) => {
                            const iLow = Math.round(item.low * (1 + mat.modifier));
                            const iHigh = Math.round(item.high * (1 + mat.modifier));
                            return (
                              <div
                                key={item.label}
                                className="flex items-start gap-4 py-3 border-b border-gray-100 last:border-b-0"
                              >
                                <div className="flex-1 min-w-0">
                                  <p className="text-charcoal-deep text-sm font-semibold">{item.label}</p>
                                  <p className="text-gray-400 text-xs mt-0.5">{item.note}</p>
                                </div>
                                <div className="text-right flex-shrink-0">
                                  <p className="text-charcoal-deep text-sm font-semibold">
                                    ${iLow.toLocaleString()} – ${iHigh.toLocaleString()}
                                  </p>
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        {/* Subtotal + financing hint */}
                        <div className="mt-6 pt-5 border-t border-gray-200">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-gray-500 text-xs uppercase tracking-wider">Estimated Total</span>
                            <span className="font-display text-charcoal-deep text-lg uppercase tracking-wider">
                              ${low.toLocaleString()} – ${high.toLocaleString()}
                            </span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-400 text-xs">As low as</span>
                            <span className="text-green-600 text-sm font-semibold">
                              ${Math.round(low / 36).toLocaleString()}/mo with financing
                            </span>
                          </div>
                        </div>

                        {/* CTA */}
                        <div className="mt-6 flex flex-col sm:flex-row gap-3">
                          <a
                            href="#schedule-repair"
                            className="flex-1 inline-flex items-center justify-center gap-2 bg-orange hover:bg-orange-dark text-white font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                          >
                            <i className="ri-calendar-check-line" />
                            Schedule This Scope
                          </a>
                          <a
                            href="#financing-preapproval"
                            className="flex-1 inline-flex items-center justify-center gap-2 border border-gray-300 hover:border-gray-400 text-charcoal-deep font-bold text-xs uppercase tracking-widest px-5 py-3 rounded-lg transition-colors whitespace-nowrap"
                          >
                            <i className="ri-bank-card-line" />
                            Check Financing
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Mobile: swipeable card carousel */}
            <div className="md:hidden">
              <div
                ref={mobileCardRef}
                className="relative"
                onTouchStart={onMobileTouchStart}
                onTouchMove={onMobileTouchMove}
                onTouchEnd={onMobileTouchEnd}
              >
                {/* Card track */}
                <div
                  className="flex transition-transform duration-300 ease-out"
                  style={{ transform: `translateX(-${mobileScenarioIdx * 100}%)` }}
                >
                  {ESTIMATE_SCENARIOS.map((scenario) => {
                    const mat = MATERIAL_TIERS.find((m) => m.key === activeMaterial)!;
                    const low = Math.round(scenario.baseRange[0] * (1 + mat.modifier));
                    const high = Math.round(scenario.baseRange[1] * (1 + mat.modifier));
                    return (
                      <div key={scenario.id} className="w-full flex-shrink-0 px-1">
                        <div className="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
                          {/* Card header */}
                          <div className="bg-charcoal-deep p-5">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-orange text-[10px] uppercase tracking-widest font-semibold">
                                {scenario.shortLabel}
                              </span>
                              <span className="text-white/40 text-[10px] uppercase tracking-wider">
                                {scenario.timeline}
                              </span>
                            </div>
                            <h3 className="font-display text-white text-lg uppercase tracking-wider mb-1">
                              {scenario.label}
                            </h3>
                            <p className="text-white/50 text-xs leading-relaxed">
                              {scenario.tagline}
                            </p>
                          </div>

                          {/* Total cost */}
                          <div className="p-5 border-b border-gray-100">
                            <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-1">
                              Estimated Total
                            </p>
                            <p className="font-display text-charcoal-deep text-2xl uppercase tracking-wider">
                              ${low.toLocaleString()} – ${high.toLocaleString()}
                            </p>
                            <p className="text-green-600 text-sm font-semibold mt-1">
                              ${Math.round(low / 36).toLocaleString()}/mo with financing
                            </p>
                          </div>

                          {/* Material tier pills */}
                          <div className="p-5 border-b border-gray-100">
                            <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-3">
                              Material Tier
                            </p>
                            <div className="flex gap-2 overflow-x-auto pb-1">
                              {MATERIAL_TIERS.map((m) => {
                                const mLow = Math.round(scenario.baseRange[0] * (1 + m.modifier));
                                const mHigh = Math.round(scenario.baseRange[1] * (1 + m.modifier));
                                const isSel = activeMaterial === m.key;
                                return (
                                  <button
                                    key={m.key}
                                    onClick={() => setActiveMaterial(m.key)}
                                    className={`flex-shrink-0 text-left border rounded-xl p-3 transition-all cursor-pointer min-w-[140px] ${
                                      isSel
                                        ? 'border-orange bg-orange/5'
                                        : 'border-gray-200'
                                    }`}
                                  >
                                    <p className="text-sm font-semibold text-charcoal-deep">{m.label}</p>
                                    <p className="text-gray-400 text-[10px] mt-0.5">
                                      ${mLow.toLocaleString()}–${mHigh.toLocaleString()}
                                    </p>
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {/* Line items — top 5 only on mobile */}
                          <div className="p-5 border-b border-gray-100">
                            <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-3">
                              Key Line Items
                            </p>
                            <div className="space-y-3">
                              {scenario.lineItems.slice(0, 5).map((item) => {
                                const iLow = Math.round(item.low * (1 + mat.modifier));
                                const iHigh = Math.round(item.high * (1 + mat.modifier));
                                return (
                                  <div key={item.label} className="flex items-start justify-between gap-3">
                                    <div className="min-w-0">
                                      <p className="text-charcoal-deep text-xs font-semibold">{item.label}</p>
                                      <p className="text-gray-400 text-[10px]">{item.note}</p>
                                    </div>
                                    <p className="text-charcoal-deep text-xs font-semibold flex-shrink-0">
                                      ${iLow.toLocaleString()}–${iHigh.toLocaleString()}
                                    </p>
                                  </div>
                                );
                              })}
                            </div>
                            {scenario.lineItems.length > 5 && (
                              <p className="text-gray-400 text-[10px] mt-3 text-center">
                                +{scenario.lineItems.length - 5} more items — view on desktop for full breakdown
                              </p>
                            )}
                          </div>

                          {/* CTA buttons */}
                          <div className="p-5 space-y-2">
                            <a
                              href="#schedule-repair"
                              className="w-full inline-flex items-center justify-center gap-2 bg-orange hover:bg-orange-dark text-white font-bold text-xs uppercase tracking-widest px-4 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                            >
                              <i className="ri-calendar-check-line" />
                              Schedule This Scope
                            </a>
                            <a
                              href="#financing-preapproval"
                              className="w-full inline-flex items-center justify-center gap-2 border border-gray-300 hover:border-gray-400 text-charcoal-deep font-bold text-xs uppercase tracking-widest px-4 py-3 rounded-lg transition-colors whitespace-nowrap"
                            >
                              <i className="ri-bank-card-line" />
                              Check Financing
                            </a>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Swipe hint */}
                <div className="flex items-center justify-center gap-2 mt-4 text-gray-400 text-xs">
                  <i className="ri-arrow-left-s-line" />
                  <span>Swipe to compare</span>
                  <i className="ri-arrow-right-s-line" />
                </div>
              </div>

              {/* Dot indicators */}
              <div className="flex items-center justify-center gap-2 mt-4">
                {ESTIMATE_SCENARIOS.map((s, i) => (
                  <button
                    key={s.id}
                    onClick={() => setMobileScenarioIdx(i)}
                    className={`w-2.5 h-2.5 rounded-full transition-all cursor-pointer ${
                      i === mobileScenarioIdx ? 'bg-orange w-6' : 'bg-gray-300'
                    }`}
                    aria-label={`Go to ${s.label}`}
                  />
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ── PAYMENT CALCULATOR ── */}
        <section className="py-14 md:py-20 px-4 sm:px-6 md:px-10 lg:px-16 bg-gray-50 border-y border-gray-200">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8 md:mb-10">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">
                Explore Your Options
              </p>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
                Payment Calculator
              </h2>
              <p className="text-gray-500 text-sm max-w-xl mx-auto leading-relaxed">
                Adjust the term length and instantly see how your monthly payment changes across all three repair scenarios and every material tier.
              </p>
            </div>
            <PaymentCalculator
              activeScenario={activeScenario}
              activeMaterial={activeMaterial}
            />
          </div>
        </section>

        {/* ── SHARE REPORT ── */}
        <section id="share-report" className="py-14 md:py-20 px-6 md:px-10 lg:px-16 bg-white border-y border-gray-200">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-10">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">
                Get a Second Opinion
              </p>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
                Share Your Report
              </h2>
              <p className="text-gray-500 text-sm max-w-lg mx-auto leading-relaxed">
                Send your inspection report, estimates, and financing details to anyone who needs to see it — spouse, co-owner, property manager, or insurance agent.
              </p>
            </div>
            <ShareReport />
          </div>
        </section>

        {/* ── APPOINTMENT CALENDAR ── */}
        <section id="appointment-calendar" className="py-14 md:py-20 px-6 md:px-10 lg:px-16 bg-gray-50 border-y border-gray-200">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-10">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">
                Pick Your Date
              </p>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
                Appointment Calendar
              </h2>
              <p className="text-gray-500 text-sm max-w-lg mx-auto leading-relaxed">
                See real crew availability and book your repair directly. No phone calls needed — pick a date, choose a time slot, and confirm in under a minute.
              </p>
            </div>
            <AppointmentCalendar />
          </div>
        </section>

        {/* ── CHAT WITH INSPECTOR ── */}
        <section id="chat-inspector" className="py-14 md:py-20 px-6 md:px-10 lg:px-16 bg-white border-y border-gray-200">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-10">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">
                Real-Time Answers
              </p>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
                Chat with Your Inspector
              </h2>
              <p className="text-gray-500 text-sm max-w-lg mx-auto leading-relaxed">
                Mike reviewed your roof in person and has your full report at his fingertips. Ask him anything — repair vs. replacement, insurance coverage, urgency, or what a specific photo means.
              </p>
            </div>
            <ChatWithInspector />
          </div>
        </section>

        {/* ── WEATHER ALERT ── */}
        <section id="weather-alert" className="py-14 md:py-20 px-6 md:px-10 lg:px-16 bg-gray-50 border-y border-gray-200">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-10">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">
                Before You Book
              </p>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
                Weather Check
              </h2>
              <p className="text-gray-500 text-sm max-w-lg mx-auto leading-relaxed">
                We pull live local weather data so you know if rain or storms are headed your way before your repair date. Crew safety comes first — if conditions turn, we reschedule at no charge.
              </p>
            </div>
            <WeatherAlert />
          </div>
        </section>

        {/* ── SCHEDULE REPAIR ── */}
        <section id="schedule-repair" className="py-14 md:py-20 px-6 md:px-10 lg:px-16 bg-gray-50 border-y border-gray-200">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-10">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">
                Ready to Fix It?
              </p>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
                Schedule Your Repair
              </h2>
              <p className="text-gray-500 text-sm max-w-lg mx-auto leading-relaxed">
                Based on your inspection, we already know your roof. Book your repair or replacement in under 2 minutes — no re-inspection needed.
              </p>
            </div>

            <div className="bg-white border border-gray-200 rounded-2xl p-6 md:p-8 shadow-sm">
              {repairSubmitted ? (
                <div className="text-center py-6">
                  <div className="w-14 h-14 flex items-center justify-center bg-green-50 rounded-full mx-auto mb-4">
                    <i className="ri-checkbox-circle-fill text-green-500 text-2xl" />
                  </div>
                  <h3 className="font-display text-charcoal-deep text-xl uppercase tracking-wider mb-2">
                    Repair Request Sent
                  </h3>
                  <p className="text-gray-500 text-sm max-w-md mx-auto mb-6">
                    We received your request and will call you within 24 hours to confirm your appointment and walk through the scope.
                  </p>
                  <div className="bg-gray-50 border border-gray-100 rounded-xl p-5 text-left max-w-md mx-auto mb-6">
                    <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-2">
                      What happens next
                    </p>
                    <ul className="space-y-2">
                      {[
                        'Our scheduler calls you within 24 hours',
                        'We confirm your preferred date and scope',
                        'You receive a written estimate via email',
                        'Work begins on the agreed start date',
                      ].map((s) => (
                        <li key={s} className="flex items-start gap-2 text-sm text-gray-600">
                          <i className="ri-check-line text-green-500 mt-0.5" />
                          {s}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <button
                    onClick={() => setRepairSubmitted(false)}
                    className="text-orange text-xs font-semibold uppercase tracking-wider hover:underline underline-offset-4 cursor-pointer"
                  >
                    Schedule Another Repair
                  </button>
                </div>
              ) : (
                <form
                  data-readdy-form
                  id="schedule-repair"
                  action={WEB3FORMS_ENDPOINT}
                  method="POST"
                  onSubmit={handleRepairSubmit}
                  className="space-y-6"
                >
                  {/* Contact info */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        name="name"
                        required
                        placeholder="John Smith"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Email *
                      </label>
                      <input
                        type="email"
                        name="email"
                        required
                        placeholder="you@email.com"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Phone *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        required
                        placeholder="(812) 213-5997"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Property Address
                      </label>
                      <input
                        type="text"
                        name="property_address"
                        defaultValue="1842 Oakmont Drive, Evansville, IN 47714"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                  </div>

                  {/* Repair type selector */}
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-2">
                      What Do You Need?
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {REPAIR_TYPES.map((rt) => (
                        <button
                          key={rt.key}
                          type="button"
                          onClick={() => setRepairType(rt.key)}
                          className={`text-left border rounded-xl p-4 transition-all cursor-pointer ${
                            repairType === rt.key
                              ? 'border-orange bg-orange/5'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <span
                              className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                                repairType === rt.key ? 'border-orange' : 'border-gray-300'
                              }`}
                            >
                              {repairType === rt.key && (
                                <span className="w-2 h-2 rounded-full bg-orange" />
                              )}
                            </span>
                            <span className="text-charcoal-deep text-sm font-semibold">
                              {rt.label}
                            </span>
                          </div>
                          <p className="text-gray-400 text-xs ml-6">{rt.desc}</p>
                          <input type="hidden" name="repair_type" value={repairType} />
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Urgency + preferred date */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-2">
                        How Urgent Is It?
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {URGENCY_OPTIONS.map((u) => (
                          <button
                            key={u.key}
                            type="button"
                            onClick={() => setUrgency(u.key)}
                            className={`flex flex-col items-center px-4 py-2.5 rounded-xl border text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                              urgency === u.key
                                ? 'bg-charcoal-deep text-white border-charcoal-deep'
                                : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'
                            }`}
                          >
                            <span>{u.label}</span>
                            <span className={`text-[10px] normal-case tracking-normal mt-0.5 ${urgency === u.key ? 'text-white/60' : 'text-gray-400'}`}>
                              {u.desc}
                            </span>
                          </button>
                        ))}
                      </div>
                      <input type="hidden" name="urgency" value={urgency} />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Preferred Start Date
                      </label>
                      <input
                        type="date"
                        name="preferred_date"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                  </div>

                  {/* Notes */}
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                      Anything Else We Should Know?
                    </label>
                    <textarea
                      name="notes"
                      rows={3}
                      maxLength={500}
                      placeholder="Specific areas of concern, access instructions, gate codes, preferred time of day..."
                      className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
                    />
                  </div>

                  {/* Hidden inspection context */}
                  <input type="hidden" name="inspection_date" value="April 28, 2026" />
                  <input type="hidden" name="repair_estimate" value={REPORT_SUMMARY.estimatedRepairRange} />
                  <input type="hidden" name="full_replacement_estimate" value={REPORT_SUMMARY.fullReplacementEstimate} />
                  <input type="hidden" name="critical_items" value={String(REPORT_SUMMARY.criticalItems)} />
                  <input type="hidden" name="inspector_name" value="Mike R." />

                  {/* Submit */}
                  <button
                    type="submit"
                    className="w-full bg-orange hover:bg-orange-dark text-white font-bold text-sm uppercase tracking-widest py-3.5 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-calendar-check-line" />
                    Request Repair Appointment
                  </button>

                  <p className="text-center text-gray-400 text-xs">
                    No upfront payment required. We&apos;ll call to confirm scope and pricing before scheduling.
                  </p>
                </form>
              )}
            </div>
          </div>
        </section>

        {/* ── FINANCING PRE-APPROVAL ── */}
        <section id="financing-preapproval" className="py-14 md:py-20 px-6 md:px-10 lg:px-16 bg-green-50/40 border-y border-green-100">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-10">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">
                $0 Down Payment Plans
              </p>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
                Financing Pre-Approval
              </h2>
              <p className="text-gray-500 text-sm max-w-lg mx-auto leading-relaxed">
                Lock in your payment plan before your repair appointment. No impact on your credit score. Approval in as little as 1 business hour.
              </p>
            </div>

            <div className="bg-white border border-gray-200 rounded-2xl p-6 md:p-8 shadow-sm">
              {financingSubmitted ? (
                <div className="text-center py-6">
                  <div className="w-14 h-14 flex items-center justify-center bg-green-50 rounded-full mx-auto mb-4">
                    <i className="ri-checkbox-circle-fill text-green-500 text-2xl" />
                  </div>
                  <h3 className="font-display text-charcoal-deep text-xl uppercase tracking-wider mb-2">
                    Application Submitted
                  </h3>
                  <p className="text-gray-500 text-sm max-w-md mx-auto mb-6">
                    Our financing partner is reviewing your pre-approval. You&apos;ll receive a decision via text and email within 1 business hour.
                  </p>
                  <div className="bg-gray-50 border border-gray-100 rounded-xl p-5 text-left max-w-md mx-auto mb-6">
                    <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-2">
                      What happens next
                    </p>
                    <ul className="space-y-2">
                      {[
                        'Financing partner reviews your application',
                        'You receive a pre-approval decision within 1 hour',
                        'Approved? We lock in your rate for 30 days',
                        'Schedule your repair — $0 due at signing',
                      ].map((s) => (
                        <li key={s} className="flex items-start gap-2 text-sm text-gray-600">
                          <i className="ri-check-line text-green-500 mt-0.5" />
                          {s}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                    <button
                      onClick={() => setFinancingSubmitted(false)}
                      className="text-orange text-xs font-semibold uppercase tracking-wider hover:underline underline-offset-4 cursor-pointer"
                    >
                      Apply for Another Property
                    </button>
                    <span className="hidden sm:inline text-gray-300">|</span>
                    <a href="/financing" className="text-gray-500 text-xs hover:text-charcoal-deep transition-colors">
                      Learn more about financing options
                    </a>
                  </div>
                </div>
              ) : (
                <form
                  data-readdy-form
                  id="financing-preapproval"
                  action={WEB3FORMS_ENDPOINT}
                  method="POST"
                  onSubmit={handleFinancingSubmit}
                  className="space-y-6"
                >
                  {/* Contact info */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        name="name"
                        required
                        placeholder="John Smith"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Email *
                      </label>
                      <input
                        type="email"
                        name="email"
                        required
                        placeholder="you@email.com"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Phone *
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        required
                        placeholder="(812) 213-5997"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Property Address
                      </label>
                      <input
                        type="text"
                        name="property_address"
                        defaultValue="1842 Oakmont Drive, Evansville, IN 47714"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                  </div>

                  {/* Employment + Income */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Employment Status
                      </label>
                      <select
                        name="employment_status"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none"
                      >
                        <option value="">Select status</option>
                        <option value="full_time">Full-Time Employed</option>
                        <option value="part_time">Part-Time Employed</option>
                        <option value="self_employed">Self-Employed</option>
                        <option value="retired">Retired</option>
                        <option value="ssdi">Disabled / SSDI</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Estimated Annual Household Income
                      </label>
                      <select
                        name="annual_income"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none"
                      >
                        <option value="">Select range</option>
                        <option value="under_40k">Under $40,000</option>
                        <option value="40k_60k">$40,000 – $60,000</option>
                        <option value="60k_80k">$60,000 – $80,000</option>
                        <option value="80k_100k">$80,000 – $100,000</option>
                        <option value="100k_150k">$100,000 – $150,000</option>
                        <option value="150k_plus">$150,000+</option>
                      </select>
                    </div>
                  </div>

                  {/* Project cost + payment plan */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Estimated Project Cost
                      </label>
                      <input
                        type="text"
                        name="project_cost"
                        defaultValue={REPORT_SUMMARY.estimatedRepairRange}
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                      <p className="text-gray-400 text-[10px] mt-1">Based on your inspection repair estimate. Edit if you expect a different scope.</p>
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-2">
                        Preferred Payment Plan
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {[
                          { key: '12' as const, label: '12 Months', payment: 'Higher monthly, lowest total' },
                          { key: '24' as const, label: '24 Months', payment: 'Balanced monthly cost' },
                          { key: '36' as const, label: '36 Months', payment: 'Lower monthly payments' },
                          { key: '60' as const, label: '60 Months', payment: 'Lowest monthly, $0 down' },
                        ].map((p) => (
                          <button
                            key={p.key}
                            type="button"
                            onClick={() => setPaymentPlan(p.key)}
                            className={`flex flex-col items-center px-3 py-2 rounded-xl border text-[10px] font-semibold uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                              paymentPlan === p.key
                                ? 'bg-charcoal-deep text-white border-charcoal-deep'
                                : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'
                            }`}
                          >
                            <span>{p.label}</span>
                            <span className={`text-[9px] normal-case tracking-normal mt-0.5 ${paymentPlan === p.key ? 'text-white/60' : 'text-gray-400'}`}>
                              {p.payment}
                            </span>
                          </button>
                        ))}
                      </div>
                      <input type="hidden" name="payment_plan" value={paymentPlan} />
                    </div>
                  </div>

                  {/* Authorization checkbox */}
                  <div className="flex items-start gap-3 bg-gray-50 border border-gray-100 rounded-xl p-4">
                    <input
                      type="checkbox"
                      name="credit_auth"
                      id="credit_auth"
                      required
                      className="w-4 h-4 mt-0.5 accent-orange rounded"
                    />
                    <label htmlFor="credit_auth" className="text-gray-600 text-xs leading-relaxed cursor-pointer">
                      I authorize Corner Stone Construction to run a <strong className="text-charcoal-deep">soft credit inquiry</strong> for financing pre-approval. This will not affect my credit score. I understand this is not a final loan agreement and terms are subject to full underwriting.
                    </label>
                  </div>

                  {/* Hidden inspection context */}
                  <input type="hidden" name="inspection_date" value="April 28, 2026" />
                  <input type="hidden" name="repair_estimate" value={REPORT_SUMMARY.estimatedRepairRange} />
                  <input type="hidden" name="full_replacement_estimate" value={REPORT_SUMMARY.fullReplacementEstimate} />
                  <input type="hidden" name="critical_items" value={String(REPORT_SUMMARY.criticalItems)} />
                  <input type="hidden" name="inspector_name" value="Mike R." />

                  {/* Submit */}
                  <button
                    type="submit"
                    className="w-full bg-green-600 hover:bg-green-700 text-white font-bold text-sm uppercase tracking-widest py-3.5 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-bank-card-line" />
                    Apply for Pre-Approval
                  </button>

                  <p className="text-center text-gray-400 text-xs">
                    Pre-approval takes 2–3 minutes. No obligation. You can still pay cash or use insurance if approved.
                  </p>
                </form>
              )}
            </div>
          </div>
        </section>

        {/* ── INSURANCE DOCUMENT UPLOAD ── */}
        <section id="upload" className="py-14 md:py-20 px-6 md:px-10 lg:px-16 bg-gray-50 border-y border-gray-200">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-10">
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">
                Insurance Claim Support
              </p>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
                Upload Your Insurance Docs
              </h2>
              <p className="text-gray-500 text-sm max-w-lg mx-auto leading-relaxed">
                Upload your insurance claim, adjuster notes, or any relevant paperwork so we can prepare an accurate estimate aligned with your coverage.
              </p>
            </div>

            <div className="bg-white border border-gray-200 rounded-2xl p-6 md:p-8 shadow-sm">
              {/* Upload area */}
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-gray-300 hover:border-orange/50 rounded-xl p-8 md:p-10 text-center cursor-pointer transition-colors bg-gray-50/50 hover:bg-orange/5"
              >
                <div className="w-14 h-14 flex items-center justify-center bg-orange/10 rounded-full mx-auto mb-4">
                  <i className="ri-upload-cloud-2-line text-orange text-2xl" />
                </div>
                <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider mb-2">
                  Drag & Drop Files Here
                </h3>
                <p className="text-gray-400 text-xs mb-4">
                  Or click to browse from your device
                </p>
                <p className="text-gray-400 text-[10px] uppercase tracking-wider">
                  PDF, JPG, PNG — up to 10 MB each
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept=".pdf,.jpg,.jpeg,.png"
                  className="hidden"
                  onChange={handleFileChange}
                />
              </div>

              {/* Upload status */}
              {uploadStatus === 'uploading' && (
                <div className="mt-4 flex items-center gap-3 text-orange text-sm">
                  <i className="ri-loader-4-line animate-spin" />
                  Uploading files...
                </div>
              )}
              {uploadStatus === 'success' && (
                <div className="mt-4 flex items-center gap-3 text-green-600 text-sm bg-green-50 border border-green-200 rounded-lg px-4 py-3">
                  <i className="ri-checkbox-circle-fill" />
                  Files uploaded successfully!
                </div>
              )}

              {/* File list */}
              {uploadedFiles.length > 0 && (
                <div className="mt-6">
                  <h4 className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-3">
                    Uploaded Documents ({uploadedFiles.length})
                  </h4>
                  <div className="space-y-2">
                    {uploadedFiles.map((file) => (
                      <div
                        key={file.name}
                        className="flex items-center justify-between bg-gray-50 border border-gray-100 rounded-lg px-4 py-3"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-8 h-8 flex items-center justify-center bg-red-50 rounded-lg flex-shrink-0">
                            <i className="ri-file-pdf-line text-red-500 text-sm" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-charcoal-deep text-sm font-medium truncate">
                              {file.name}
                            </p>
                            <p className="text-gray-400 text-xs">{file.size}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => removeFile(file.name)}
                          className="w-7 h-7 flex items-center justify-center text-gray-400 hover:text-red-500 transition-colors flex-shrink-0 cursor-pointer"
                          title="Remove file"
                        >
                          <i className="ri-close-line" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Manual upload form fallback */}
              <div className="mt-8 pt-6 border-t border-gray-100">
                <p className="text-gray-500 text-xs mb-4 leading-relaxed">
                  Prefer to send documents another way? You can also email them to{' '}
                  <a href="mailto:claims@cornerstoneconstructionroofing.com" className="text-orange font-semibold underline underline-offset-2">
                    claims@cornerstoneconstructionroofing.com
                  </a>{' '}
                  or text photos to{' '}
                  <a href="tel:8122135997" className="text-orange font-semibold underline underline-offset-2">
                    812-213-5997
                  </a>.
                </p>

                <form
                  data-readdy-form
                  id="insurance-document-upload"
                  action={WEB3FORMS_ENDPOINT}
                  method="POST"
                  className="space-y-4"
                >
                  <input type="hidden" name="access_key" value={WEB3FORMS_ACCESS_KEY} />
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Your Name *
                      </label>
                      <input
                        type="text"
                        name="name"
                        required
                        placeholder="John Smith"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        Your Email *
                      </label>
                      <input
                        type="email"
                        name="email"
                        required
                        placeholder="you@email.com"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                      Insurance Claim Number
                    </label>
                    <input
                      type="text"
                      name="claim_number"
                      placeholder="e.g. CLM-2026-004592"
                      className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                      Additional Notes
                    </label>
                    <textarea
                      name="notes"
                      rows={3}
                      maxLength={500}
                      placeholder="Describe what documents you are sending, your insurance company, adjuster name, etc..."
                      className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-orange hover:bg-orange-dark text-white font-bold text-sm uppercase tracking-widest py-3.5 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-send-plane-line" />
                    Submit Document Details
                  </button>
                </form>
              </div>
            </div>
          </div>
        </section>

        {/* ── REPORT REQUEST SUPPORT ── */}
        <section className="py-14 md:py-20 px-6 md:px-10 lg:px-16">
          <div className="max-w-3xl mx-auto">
            <div className="bg-charcoal-deep rounded-2xl p-8 md:p-10 text-center">
              <div className="w-14 h-14 flex items-center justify-center bg-orange/20 rounded-full mx-auto mb-5">
                <i className="ri-question-answer-line text-orange text-2xl" />
              </div>
              <h2 className="font-display text-white uppercase tracking-wider text-2xl mb-3">
                Questions About Your Report?
              </h2>
              <p className="text-white/50 text-sm max-w-lg mx-auto leading-relaxed mb-6">
                Your inspector is available to walk through the findings, explain severity ratings, and discuss repair vs. replacement options. No pressure — just honest answers.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <a
                  href="tel:8122135997"
                  className="inline-flex items-center gap-2 bg-orange hover:bg-orange-dark text-white font-bold text-xs uppercase tracking-widest px-6 py-3 rounded-lg transition-colors whitespace-nowrap"
                >
                  <i className="ri-phone-line" />
                  Call 812-213-5997
                </a>
                <form
                  data-readdy-form
                  id="report-request-callback"
                  action={WEB3FORMS_ENDPOINT}
                  method="POST"
                  className="inline-flex"
                >
                  <input type="hidden" name="access_key" value={WEB3FORMS_ACCESS_KEY} />
                  <input type="hidden" name="request_type" value="report_callback" />
                  <button
                    type="submit"
                    className="inline-flex items-center gap-2 border border-white/20 hover:border-white text-white font-bold text-xs uppercase tracking-widest px-6 py-3 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                  >
                    <i className="ri-customer-service-2-line" />
                    Request a Callback
                  </button>
                </form>
              </div>
            </div>
          </div>
        </section>

        {/* ── QUICK LINKS ── */}
        <section className="py-14 md:py-20 px-6 md:px-10 lg:px-16 bg-gray-50">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-10">
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(1.5rem, 3vw, 2.5rem)' }}>
                What You Can Do Next
              </h2>
              <p className="text-gray-500 text-sm">
                Take the next step based on your report findings.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { icon: 'ri-shield-check-line', title: 'Insurance Claims', desc: 'We handle the paperwork for you', link: '/insurance-claims', label: 'Learn More' },
                { icon: 'ri-calendar-line', title: 'Schedule Repair', desc: 'Book your repair appointment now', link: '#schedule-repair', label: 'Book Repair' },
                { icon: 'ri-file-list-3-line', title: 'Financing Options', desc: 'Apply for $0 down payment plans', link: '#financing-preapproval', label: 'Apply Now' },
                { icon: 'ri-user-line', title: 'My Projects', desc: 'Track your project in real time', link: '/customer-portal', label: 'Open Portal' },
              ].map((card) => (
                <Link
                  key={card.title}
                  to={card.link}
                  className="group border border-gray-200 bg-white p-5 hover:border-orange/30 transition-all duration-300 rounded-xl"
                >
                  <div className="w-10 h-10 flex items-center justify-center bg-orange/10 mb-4 rounded-lg group-hover:bg-orange/20 transition-colors">
                    <i className={`${card.icon} text-orange text-lg`} />
                  </div>
                  <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-wider mb-1">
                    {card.title}
                  </h3>
                  <p className="text-gray-500 text-xs mb-4">{card.desc}</p>
                  <span className="text-orange text-xs font-semibold uppercase tracking-wider flex items-center gap-1 group-hover:underline underline-offset-4">
                    {card.label}
                    <i className="ri-arrow-right-line text-xs" />
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* ── LIGHTBOX ── */}
      {lightboxIdx !== null && filteredPhotos[lightboxIdx] && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 md:p-8"
          onClick={closeLightbox}
          onKeyDown={onLightboxKey}
          tabIndex={0}
          role="dialog"
          aria-modal="true"
        >
          {/* Close */}
          <button
            onClick={closeLightbox}
            className="absolute top-4 right-4 md:top-6 md:right-6 w-10 h-10 flex items-center justify-center bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors cursor-pointer z-10"
          >
            <i className="ri-close-line text-xl" />
          </button>

          {/* Prev */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              prevPhoto();
            }}
            className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 w-10 h-10 md:w-12 md:h-12 flex items-center justify-center bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors cursor-pointer z-10"
          >
            <i className="ri-arrow-left-line text-lg md:text-xl" />
          </button>

          {/* Next */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              nextPhoto();
            }}
            className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 w-10 h-10 md:w-12 md:h-12 flex items-center justify-center bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors cursor-pointer z-10"
          >
            <i className="ri-arrow-right-line text-lg md:text-xl" />
          </button>

          {/* Content */}
          <div
            className="relative max-w-4xl w-full max-h-[85vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={filteredPhotos[lightboxIdx].image}
              alt={filteredPhotos[lightboxIdx].label}
              className="w-full max-h-[60vh] object-contain rounded-lg bg-black"
            />
            <div className="mt-4 bg-charcoal-deep rounded-xl p-5">
              <div className="flex items-center gap-3 mb-2">
                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-[10px] font-bold uppercase tracking-wider ${SEVERITY_META[filteredPhotos[lightboxIdx].severity].badge}`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${SEVERITY_META[filteredPhotos[lightboxIdx].severity].dot}`} />
                  {SEVERITY_META[filteredPhotos[lightboxIdx].severity].label}
                </span>
                <span className="text-orange text-[10px] uppercase tracking-widest font-semibold">
                  {filteredPhotos[lightboxIdx].category}
                </span>
                <span className="text-white/20">|</span>
                <span className="text-white/40 text-[10px] uppercase tracking-wider">
                  {filteredPhotos[lightboxIdx].area}
                </span>
              </div>
              <h3 className="font-display text-white text-lg uppercase tracking-wider mb-2">
                {filteredPhotos[lightboxIdx].label}
              </h3>
              <p className="text-white/50 text-sm leading-relaxed">
                {filteredPhotos[lightboxIdx].notes}
              </p>
            </div>
            {/* counter */}
            <p className="text-center text-white/30 text-xs mt-3">
              {lightboxIdx + 1} / {filteredPhotos.length}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}