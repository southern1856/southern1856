import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';

const sections = [
  {
    title: 'Acceptance of Terms',
    content: [
      'By accessing or using the Corner Stone Construction & Roofing website (cornerstoneconstructionevansville.com), you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our website.',
      'These terms apply to all visitors, users, and anyone who accesses or uses our website or services.',
    ],
  },
  {
    title: 'Services Description',
    content: [
      'Corner Stone Construction & Roofing provides residential and commercial roofing services in Evansville, Indiana and the surrounding Tri-State area, including roof installation, repair, replacement, inspection, and insurance claim assistance.',
      'Information on this website is provided for general informational purposes. Specific pricing, timelines, and project details are determined through individual estimates and contracts.',
      'Free estimates are provided at no obligation. An estimate does not constitute a contract or guarantee of service.',
    ],
  },
  {
    title: 'Use of Website',
    content: [
      'You agree to use this website only for lawful purposes and in a manner that does not infringe the rights of others.',
      'You may not use our website to transmit any harmful, offensive, or disruptive content.',
      'You may not attempt to gain unauthorized access to any part of our website or its related systems.',
      'We reserve the right to terminate access to our website for any user who violates these terms.',
    ],
  },
  {
    title: 'Estimate & Quote Requests',
    content: [
      'Submitting an estimate request form does not create a binding contract. All work is subject to a written contract signed by both parties.',
      'Estimates are valid for 30 days from the date of issuance unless otherwise stated in writing.',
      'Final pricing may vary from estimates based on actual site conditions, material availability, or scope changes discovered during the project.',
      'We reserve the right to decline any project at our discretion.',
    ],
  },
  {
    title: 'Intellectual Property',
    content: [
      'All content on this website — including text, images, logos, graphics, and design — is the property of Corner Stone Construction & Roofing or its content suppliers and is protected by applicable copyright and trademark laws.',
      'You may not reproduce, distribute, modify, or create derivative works from any content on this website without our express written permission.',
      'The Corner Stone Construction & Roofing name and logo are trademarks of the company.',
    ],
  },
  {
    title: 'Disclaimer of Warranties',
    content: [
      'This website and its content are provided "as is" without warranties of any kind, either express or implied.',
      'We do not warrant that the website will be uninterrupted, error-free, or free of viruses or other harmful components.',
      'We do not warrant the accuracy, completeness, or usefulness of any information on the website.',
      'Any reliance you place on information from this website is strictly at your own risk.',
    ],
  },
  {
    title: 'Limitation of Liability',
    content: [
      'To the fullest extent permitted by law, Corner Stone Construction & Roofing shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising from your use of this website.',
      'Our total liability for any claim arising from use of this website shall not exceed $100.',
      'Some jurisdictions do not allow limitations on implied warranties or liability, so some of the above limitations may not apply to you.',
    ],
  },
  {
    title: 'Third-Party Links',
    content: [
      'Our website may contain links to third-party websites. These links are provided for your convenience only.',
      'We have no control over the content of those sites and accept no responsibility for them or for any loss or damage that may arise from your use of them.',
    ],
  },
  {
    title: 'Governing Law',
    content: [
      'These Terms of Service shall be governed by and construed in accordance with the laws of the State of Indiana, without regard to its conflict of law provisions.',
      'Any disputes arising from these terms or your use of our website shall be subject to the exclusive jurisdiction of the courts located in Vanderburgh County, Indiana.',
    ],
  },
  {
    title: 'Changes to Terms',
    content: [
      'We reserve the right to modify these Terms of Service at any time. Changes will be effective immediately upon posting to the website.',
      'Your continued use of the website after any changes constitutes your acceptance of the new terms.',
      'We encourage you to review these terms periodically.',
    ],
  },
  {
    title: 'Contact Information',
    content: [
      'If you have questions about these Terms of Service, please contact us:',
      'Corner Stone Construction & Roofing\n5800 Kansas Rd, Evansville, IN 47725\nPhone: 812-213-5997\nEmail: themainstoneconstruction@gmail.com',
    ],
  },
];

export default function TermsOfServicePage() {
  const navigate = useNavigate();

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, []);

  return (
    <div className="min-h-screen bg-charcoal-deep">

      {/* Hero */}
      <section className="pt-32 pb-16 px-6 md:px-10 lg:px-16 border-b border-white/10">
        <div className="max-w-4xl">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Legal</p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Terms of Service
          </h1>
          <p className="text-white/40 text-sm md:text-base leading-relaxed max-w-2xl">
            Please read these terms carefully before using our website or requesting services. By using our site, you agree to these terms.
          </p>
          <p className="text-white/25 text-xs mt-5 uppercase tracking-widest">Last Updated: April 29, 2026</p>
        </div>
      </section>

      {/* Content */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16">
        <div className="max-w-4xl space-y-12">
          {sections.map((section, i) => (
            <div key={section.title} className="border-b border-white/5 pb-12 last:border-0">
              <div className="flex items-start gap-5 mb-5">
                <span className="font-display text-orange/40 text-2xl tracking-wider leading-none mt-1 flex-shrink-0">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <h2 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider">{section.title}</h2>
              </div>
              <div className="pl-12 space-y-4">
                {section.content.map((para, j) => (
                  <p key={j} className="text-white/50 text-sm md:text-base leading-relaxed whitespace-pre-line">{para}</p>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-6 md:px-10 lg:px-16 bg-charcoal border-t border-white/10">
        <div className="max-w-4xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div>
            <p className="text-white font-semibold mb-1">Have questions about our terms?</p>
            <p className="text-white/40 text-sm">We're always happy to clarify. Just reach out.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <a
              href="mailto:themainstoneconstruction@gmail.com"
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-7 py-3 uppercase tracking-widest text-xs transition-colors whitespace-nowrap text-center"
            >
              Email Us
            </a>
            <button
              onClick={() => navigate('/')}
              className="border border-white/20 hover:border-white text-white font-semibold px-7 py-3 uppercase tracking-widest text-xs transition-colors whitespace-nowrap cursor-pointer"
            >
              Back to Home
            </button>
          </div>
        </div>
      </section>

    </div>
  );
}
