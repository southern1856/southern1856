import { useState, useRef, useMemo } from 'react';
import PageSEO from '@/components/feature/PageSEO';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import StormAIAssessment from './components/StormAIAssessment';
import HailSeverityMap from './components/HailSeverityMap';
import { OFFERS } from '@/mocks/promotions';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

function openReaddyAgent(prefill?: string) {
  const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
  if (btn) btn.click();
  if (!prefill) return;
  setTimeout(() => {
    const input = document.querySelector('input[placeholder*="message" i], textarea[placeholder*="message" i], input[placeholder*="ask" i], textarea[placeholder*="ask" i], input[placeholder*="type" i], textarea[placeholder*="type" i]') as HTMLInputElement | HTMLTextAreaElement | null;
    if (input) {
      input.value = prefill;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      const form = input.closest('form');
      if (form) {
        const submitBtn = form.querySelector('button[type="submit"], button[aria-label*="send" i]') as HTMLElement | null;
        if (submitBtn) submitBtn.click();
      }
    }
  }, 900);
}

const SIGNS = [
  'Missing or lifted shingles after a storm',
  'Water stains on ceilings or walls',
  'Granules collecting in gutters',
  'Dents on metal flashing or vents',
  'Daylight visible through attic',
  'Sagging or soft spots on the roof',
  'Cracked or broken shingles',
  'Gutters pulling away from fascia',
];

const PROCESS_STEPS = [
  {
    num: '01',
    icon: 'ri-shield-flash-line',
    title: 'Emergency Tarping',
    desc: 'We arrive within 60 minutes to tarp exposed areas and stop water intrusion immediately. No charge for emergency tarp.',
    detail: '24/7 dispatch · Same-night arrival · Interior protected',
  },
  {
    num: '02',
    icon: 'ri-camera-3-line',
    title: 'Damage Documentation',
    desc: 'Certified inspector photographs every damaged shingle, dent, and leak. Full report compiled for your insurance adjuster.',
    detail: 'Drone photography · Date-stamped evidence · Hidden damage found',
  },
  {
    num: '03',
    icon: 'ri-file-shield-2-line',
    title: 'Adjuster Meeting',
    desc: 'We meet your adjuster on-site, walk them through every documented issue, and advocate for the full payout your policy covers.',
    detail: 'We file the claim · We negotiate · You get full coverage',
  },
  {
    num: '04',
    icon: 'ri-hammer-line',
    title: 'Full Repair / Replace',
    desc: 'Permanent repair or full roof replacement using premium materials — installed fast and backed by our lifetime workmanship warranty.',
    detail: 'Most jobs 1–2 days · GAF Golden Pledge · Site cleaned completely',
  },
];

const stormSchema = {
  '@context': 'https://schema.org',
  '@type': 'Service',
  name: 'Emergency Storm Damage Roofing Repair',
  provider: {
    '@type': 'RoofingContractor',
    name: 'Corner Stone Construction & Roofing',
    telephone: '+1-812-213-5997',
    address: { '@type': 'PostalAddress', addressLocality: 'Evansville', addressRegion: 'IN' },
  },
  areaServed: ['Evansville IN', 'Newburgh IN', 'Henderson KY', 'Tri-State Area'],
  description: '24/7 emergency storm damage roofing repair in Evansville Indiana. Hail damage, wind damage, fallen trees. Free AI photo assessment, storm tracker, and insurance claim handling.',
  offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD', description: 'Free storm damage inspection + AI assessment' },
};

export default function StormDamagePage() {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [charCount, setCharCount] = useState(0);
  const formRef = useRef<HTMLFormElement>(null);
  const hero = useScrollAnimation();
  const signs = useScrollAnimation({ threshold: 0.1 });
  const process = useScrollAnimation({ threshold: 0.1 });

  const nearestExpiry = useMemo(() => {
    const expiring = OFFERS.filter((o) => o.expires).sort((a, b) => new Date(a.expires!).getTime() - new Date(b.expires!).getTime());
    return expiring[0]?.expires ?? null;
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;
    const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
    const notes = formData.get('notes') as string;
    if (notes && notes.length > 500) return;
    setStatus('submitting');
    try {
      const res = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      if (res.ok) { setStatus('success'); formRef.current.reset(); setCharCount(0); }
      else setStatus('error');
    } catch { setStatus('error'); }
  };

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Storm Damage Roof Repair Evansville IN | Free AI Assessment + 24/7 Emergency"
        description="Storm hit your roof? Get a free AI photo damage assessment in 30 seconds + see recent hail events near you. Corner Stone responds 24/7 across Evansville, Newburgh, Henderson KY. Emergency tarping, insurance claims, full repair."
        keywords="storm damage roofing Evansville, hail damage AI assessment, emergency roofing Indiana, 24/7 roof repair Evansville, insurance claim roofing, storm damage assessment Tri-State"
        canonical="/storm-damage"
        schema={stormSchema}
      />
      {/* ── EMERGENCY HERO ── */}
      <section className="relative min-h-screen flex flex-col overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1400x900.svg"
            alt="Storm damage roof repair Evansville Indiana"
            className="w-full h-full object-cover object-top opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/70 via-charcoal-deep/50 to-charcoal-deep" />
        </div>

        {/* Emergency pulse badge */}
        <div className="relative z-10 flex items-center gap-3 px-6 md:px-10 lg:px-16 pt-32 md:pt-36">
          <div className="relative flex items-center gap-2 bg-red-600/15 border border-red-500/30 px-4 py-2">
            <span className="relative w-2 h-2">
              <span className="absolute inset-0 rounded-full bg-red-500 animate-ping opacity-75" />
              <span className="relative w-2 h-2 rounded-full bg-red-500 block" />
            </span>
            <span className="text-red-400 text-xs font-bold uppercase tracking-widest">24/7 Emergency Response</span>
          </div>
          <span className="text-white/30 text-xs hidden sm:block">We respond within 60 minutes across the Tri-State</span>
        </div>

        <div className="relative z-10 px-6 md:px-10 lg:px-16 mb-2 space-y-2">
          <CountdownTimer expiresAt={nearestExpiry ?? new Date(Date.now() + 86400000 * 3).toISOString()} variant="banner" />
          <SocialProofPulse />
        </div>

        <div
          ref={hero.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 flex-1 flex flex-col lg:flex-row items-start gap-12 px-6 md:px-10 lg:px-16 py-16 anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
        >
          {/* Left copy */}
          <div className="flex-1 max-w-2xl">
            <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 8vw, 7rem)' }}>
              Storm Hit<br />Your Roof?<br /><span className="text-red-400">3 Steps to Safety.</span>
            </h1>
            <p className="text-white/50 text-base md:text-lg leading-relaxed mb-8">
              Every hour you wait, water damage spreads. Use our free AI photo inspector, check the live storm tracker, or request emergency help — all on this page.
            </p>

            {/* 3-step funnel */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-10">
              {[
                { step: '1', icon: 'ri-camera-line', label: 'AI Photo Check', sub: '30 seconds, instant result', action: () => document.getElementById('ai-assessment')?.scrollIntoView({ behavior: 'smooth' }) },
                { step: '2', icon: 'ri-thunderstorms-line', label: 'Check Storm Map', sub: 'See hail near your area', action: () => document.getElementById('storm-map')?.scrollIntoView({ behavior: 'smooth' }) },
                { step: '3', icon: 'ri-alarm-warning-line', label: 'Request Emergency Help', sub: 'We call back in 30 min', action: () => document.getElementById('emergency-form')?.scrollIntoView({ behavior: 'smooth' }) },
              ].map((item) => (
                <button
                  key={item.step}
                  onClick={item.action}
                  className="group text-left p-4 border border-white/10 hover:border-orange/40 bg-white/5 hover:bg-orange/5 transition-all duration-200 cursor-pointer"
                >
                  <div className="flex items-center gap-3 mb-2">
                    <span className="font-display text-white/20 text-xl">{item.step}</span>
                    <i className={`${item.icon} text-orange text-lg`} />
                  </div>
                  <p className="text-white font-semibold text-sm uppercase tracking-wider">{item.label}</p>
                  <p className="text-white/30 text-xs mt-0.5">{item.sub}</p>
                </button>
              ))}
            </div>

            {/* AI Assistant prompt */}
            <div
              className="inline-flex items-center gap-3 bg-white/5 border border-white/10 hover:border-green-400/40 px-5 py-3 cursor-pointer transition-colors duration-200 mb-8"
              onClick={() => openReaddyAgent("I think my roof has storm damage. What should I do first?")}
              role="button"
            >
              <span className="relative w-2 h-2">
                <span className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-75" />
                <span className="relative w-2 h-2 rounded-full bg-green-400 block" />
              </span>
              <i className="ri-mic-line text-green-400 text-sm" />
              <span className="text-white/60 text-xs font-medium uppercase tracking-wider">Not sure if it's damage? Ask our AI — it'll guide you step by step</span>
              <i className="ri-arrow-right-line text-white/40 text-xs" />
            </div>

            <div className="flex flex-wrap gap-6">
              {[
                { icon: 'ri-timer-line', text: '60-Min Response' },
                { icon: 'ri-shield-check-line', text: 'Fully Insured' },
                { icon: 'ri-file-list-3-line', text: 'Insurance Handled' },
                { icon: 'ri-tools-line', text: 'Emergency Tarping' },
              ].map((item) => (
                <div key={item.text} className="flex items-center gap-2 text-white/40 text-xs uppercase tracking-wider">
                  <i className={`${item.icon} text-orange text-sm`} />
                  {item.text}
                </div>
              ))}
            </div>
          </div>

          {/* Right — Emergency Form */}
          <div id="emergency-form" className="w-full lg:w-[420px] flex-shrink-0">
            <div className="bg-white overflow-hidden">
              <div className="bg-red-600 px-6 py-4 flex items-center justify-between">
                <div>
                  <h2 className="font-display text-white text-xl uppercase tracking-wider">Emergency Request</h2>
                  <p className="text-white/80 text-xs mt-0.5">We call you back within 30 minutes</p>
                </div>
                <div className="w-10 h-10 flex items-center justify-center bg-white/15">
                  <i className="ri-alarm-warning-line text-white text-lg" />
                </div>
              </div>
              {status === 'success' ? (
                <div className="px-6 py-12 flex flex-col items-center text-center">
                  <div className="w-14 h-14 flex items-center justify-center bg-green-500/15 mb-4">
                    <i className="ri-checkbox-circle-fill text-green-400 text-2xl" />
                  </div>
                  <h3 className="font-display text-charcoal-deep text-xl uppercase tracking-wider mb-2">Request Received!</h3>
                  <p className="text-charcoal-mid/50 text-sm max-w-xs">
                    Our emergency team will call within 30 minutes. If urgent, call us directly.
                  </p>
                  <a href="tel:8122135997" className="mt-6 bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-3 uppercase tracking-widest text-sm transition-colors whitespace-nowrap">
                    Call 812-213-5997
                  </a>
                </div>
              ) : (
                <form ref={formRef} data-readdy-form onSubmit={handleSubmit} className="px-6 py-5 space-y-3.5">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-charcoal-mid/70 text-xs font-semibold uppercase tracking-wider mb-1">Name</label>
                      <input type="text" name="name" required placeholder="John Smith" className="w-full bg-warm-beige border border-charcoal/10 px-3 py-2.5 text-charcoal-deep text-sm placeholder:text-charcoal-mid/50 focus:outline-none focus:border-orange/40" />
                    </div>
                    <div>
                      <label className="block text-charcoal-mid/70 text-xs font-semibold uppercase tracking-wider mb-1">Phone</label>
                      <input type="tel" name="phone" required placeholder="812-000-0000" className="w-full bg-warm-beige border border-charcoal/10 px-3 py-2.5 text-charcoal-deep text-sm placeholder:text-charcoal-mid/50 focus:outline-none focus:border-orange/40" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-charcoal-mid/70 text-xs font-semibold uppercase tracking-wider mb-1">Address</label>
                    <input type="text" name="address" required placeholder="123 Main St, Evansville, IN" className="w-full bg-warm-beige border border-charcoal/10 px-3 py-2.5 text-charcoal-deep text-sm placeholder:text-charcoal-mid/50 focus:outline-none focus:border-orange/40" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-charcoal-mid/70 text-xs font-semibold uppercase tracking-wider mb-1">Damage Type</label>
                      <select name="damage_type" className="w-full bg-warm-beige border border-charcoal/10 px-3 py-2.5 text-charcoal-deep text-sm focus:outline-none focus:border-orange/40 appearance-none cursor-pointer">
                        <option value="">Select</option>
                        <option value="hail">Hail Damage</option>
                        <option value="wind">Wind / Missing Shingles</option>
                        <option value="water">Active Leak</option>
                        <option value="tree">Tree / Debris</option>
                        <option value="multiple">Multiple</option>
                        <option value="unknown">Not Sure</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-charcoal-mid/70 text-xs font-semibold uppercase tracking-wider mb-1">Insurance?</label>
                      <select name="has_insurance" className="w-full bg-warm-beige border border-charcoal/10 px-3 py-2.5 text-charcoal-deep text-sm focus:outline-none focus:border-orange/40 appearance-none cursor-pointer">
                        <option value="">Select</option>
                        <option value="yes">Yes — Need help</option>
                        <option value="no">No insurance</option>
                        <option value="unsure">Not sure</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-charcoal-mid/70 text-xs font-semibold uppercase tracking-wider mb-1">Notes (optional)</label>
                    <textarea name="notes" rows={2} maxLength={500} onChange={(e) => setCharCount(e.target.value.length)} placeholder="What happened?" className="w-full bg-warm-beige border border-charcoal/10 px-3 py-2.5 text-charcoal-deep text-sm placeholder:text-charcoal-mid/50 focus:outline-none focus:border-orange/40 resize-none" />
                    <p className={`text-[10px] mt-0.5 text-right ${charCount > 500 ? 'text-red-500' : 'text-charcoal-mid/20'}`}>{charCount}/500</p>
                  </div>
                  <button
                    type="submit"
                    disabled={status === 'submitting'}
                    className="w-full bg-red-600 hover:bg-red-700 disabled:bg-charcoal-mid/30 text-white font-bold text-sm uppercase tracking-widest py-3.5 transition-colors flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  >
                    {status === 'submitting' ? (
                      <><i className="ri-loader-4-line animate-spin" />Sending...</>
                    ) : (
                      <><i className="ri-alarm-warning-line" />Send Emergency Request</>
                    )}
                  </button>
                  {status === 'error' && (
                    <div className="bg-red-500/10 border border-red-500/20 p-2.5 flex items-center gap-2">
                      <i className="ri-alert-line text-red-400 text-sm" />
                      <p className="text-red-400 text-xs">Error sending. Call 812-213-5997 directly.</p>
                    </div>
                  )}
                  <p className="text-charcoal-mid/30 text-xs text-center">
                    <i className="ri-lock-line mr-1" />Your info is private and secure.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      <TalkToAIExpert />

      {/* ── STEP 1: AI ASSESSMENT ── */}
      <section id="ai-assessment" className="bg-charcoal-mid border-y border-white/10 py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="max-w-4xl mx-auto text-center mb-10">
          <div className="inline-flex items-center gap-2 border border-orange/30 bg-orange/5 px-4 py-2 mb-5">
            <span className="font-display text-orange text-sm">01</span>
            <span className="text-orange text-xs font-semibold uppercase tracking-[0.25em]">AI Assessment</span>
          </div>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}>
            Upload a Photo.<br />Get Instant AI Results.
          </h2>
          <p className="text-white/50 text-sm md:text-base max-w-lg mx-auto">
            Snap a photo of your roof from the ground. Our AI scans for hail damage, missing shingles, granule loss, and flashing issues — 30 seconds, no signup.
          </p>
        </div>
        <StormAIAssessment />
      </section>

      {/* ── STEP 2: HAIL SEVERITY MAP ── */}
      <div id="storm-map">
        <HailSeverityMap />
      </div>

      {/* ── WARNING SIGNS ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div
            ref={signs.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-left ${signs.isVisible ? 'is-visible' : ''}`}
          >
            <div className="inline-flex items-center gap-2 border border-red-500/30 bg-red-500/5 px-4 py-2 mb-5">
              <i className="ri-error-warning-line text-red-400 text-sm" />
              <span className="text-red-400 text-xs font-semibold uppercase tracking-[0.25em]">Don't Ignore These</span>
            </div>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-8" style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}>
              Warning Signs<br />After a Storm
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {SIGNS.map((sign, i) => (
                <div
                  key={sign}
                  className={`flex items-start gap-3 p-4 border border-white/5 bg-charcoal-deep anim-fade-up ${signs.isVisible ? 'is-visible' : ''}`}
                  style={{ transitionDelay: `${i * 60}ms` }}
                >
                  <i className="ri-error-warning-line text-red-400 text-sm mt-0.5 flex-shrink-0" />
                  <p className="text-white/60 text-sm leading-relaxed">{sign}</p>
                </div>
              ))}
            </div>
            <div className="mt-8 p-5 bg-red-600/10 border border-red-500/20">
              <p className="text-red-300 text-sm font-semibold mb-1">
                <i className="ri-alarm-warning-line mr-2" />
                Don't wait — water damage compounds fast
              </p>
              <p className="text-white/40 text-xs leading-relaxed">
                A small leak can cause $10,000+ in structural damage within 48 hours. Every hour counts after a storm.
              </p>
            </div>
          </div>

          <div className={`anim-fade-right ${signs.isVisible ? 'is-visible' : ''}`}>
            <div className="relative w-full h-[500px] overflow-hidden">
              <img
                src="/placeholders/700x500.svg"
                alt="Hail damage on roof shingles"
                className="w-full h-full object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal/60 to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 bg-charcoal-deep/90 border border-white/10 p-5">
                <p className="text-white font-semibold text-sm mb-1">This is what hail damage looks like up close</p>
                <p className="text-white/40 text-xs">Invisible from the ground — only a certified inspector finds it. Our AI gets you started.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── STEP 3: OUR PROCESS ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal-deep">
        <div
          ref={process.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${process.isVisible ? 'is-visible' : ''}`}
        >
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 border border-orange/30 bg-orange/5 px-4 py-2 mb-5">
              <span className="font-display text-orange text-sm">03</span>
              <span className="text-orange text-xs font-semibold uppercase tracking-[0.25em]">What Happens Next</span>
            </div>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}>
              From Emergency Call<br />To Done Right
            </h2>
          </div>

          <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {PROCESS_STEPS.map((stepItem, i) => (
              <div
                key={stepItem.num}
                className={`border border-white/10 bg-charcoal p-6 hover:border-orange/30 transition-all duration-300 anim-fade-up ${process.isVisible ? 'is-visible' : ''}`}
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                <div className="font-display text-white/10 text-5xl tracking-wider mb-2">{stepItem.num}</div>
                <div className="w-10 h-10 flex items-center justify-center bg-orange/10 mb-4">
                  <i className={`${stepItem.icon} text-orange text-lg`} />
                </div>
                <h3 className="font-display text-white text-sm uppercase tracking-widest mb-3">{stepItem.title}</h3>
                <p className="text-white/50 text-sm leading-relaxed mb-3">{stepItem.desc}</p>
                <p className="text-orange/60 text-[10px] uppercase tracking-wider">{stepItem.detail}</p>
              </div>
            ))}
          </div>

          {/* CTA bar */}
          <div className="max-w-4xl mx-auto mt-14 p-6 border border-white/10 bg-charcoal">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="text-center md:text-left">
                <p className="text-white font-semibold text-lg uppercase tracking-wider mb-1">Storm damage doesn't wait. Neither do we.</p>
                <p className="text-white/40 text-sm">24/7 dispatch · 60-min response · Insurance claims handled</p>
              </div>
              <div className="flex flex-col sm:flex-row gap-3 flex-shrink-0">
                <a href="tel:8122135997" className="bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2">
                  <i className="ri-phone-fill" />
                  812-213-5997
                </a>
                <button
                  onClick={() => document.getElementById('emergency-form')?.scrollIntoView({ behavior: 'smooth' })}
                  className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
                >
                  Request Emergency Help
                </button>
              </div>
            </div>

            {/* AI prompt in CTA bar */}
            <div className="mt-6 pt-5 border-t border-white/10 flex flex-col sm:flex-row items-center justify-center gap-3">
              <div
                className="inline-flex items-center gap-3 bg-white/5 border border-white/10 hover:border-green-400/40 px-5 py-3 cursor-pointer transition-colors duration-200"
                onClick={() => openReaddyAgent("Will my insurance cover storm damage to my roof?")}
                role="button"
              >
                <i className="ri-mic-line text-green-400 text-sm" />
                <span className="text-white/60 text-xs font-medium uppercase tracking-wider">Ask AI about insurance, timelines, or what to expect</span>
                <i className="ri-arrow-right-line text-white/40 text-xs" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── FINAL CTA ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal-deep border-t border-white/10">
        <div className="max-w-3xl mx-auto text-center">
          <div className="w-16 h-16 flex items-center justify-center bg-red-600/15 mx-auto mb-6">
            <i className="ri-alarm-warning-line text-red-400 text-2xl" />
          </div>
          <h2 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wider mb-4">
            Roof Damage Can't Wait.<br />Neither Should You.
          </h2>
          <p className="text-white/40 text-sm md:text-base leading-relaxed mb-8 max-w-lg mx-auto">
            Whether you just used the AI inspector, checked the storm map, or you're reading this at 2 AM after a storm — we're here. Call now or send the emergency form. We'll respond fast.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="tel:8122135997" className="bg-red-600 hover:bg-red-700 text-white font-bold px-10 py-5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-3">
              <i className="ri-phone-fill" />
              Call 812-213-5997
            </a>
            <button
              onClick={() => document.getElementById('emergency-form')?.scrollIntoView({ behavior: 'smooth' })}
              className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-10 py-5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              Send Emergency Request
            </button>
          </div>
          <p className="text-white/20 text-xs mt-6">Corner Stone Construction & Roofing · Evansville IN · 24/7 Emergency Response</p>
        </div>
      </section>

    </div>
  );
}
