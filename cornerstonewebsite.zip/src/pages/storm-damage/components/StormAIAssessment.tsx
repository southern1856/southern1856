import { useState, useRef, useCallback } from 'react';

type AssessmentStep = 'upload' | 'analyzing' | 'results';

type QuickResult = {
  grade: string;
  label: string;
  urgency: string;
  topIssues: { label: string; severity: 'none' | 'mild' | 'moderate' | 'severe' }[];
  recommendation: string;
};

const quickResults: QuickResult[] = [
  {
    grade: 'B+', label: 'Minor Wear', urgency: 'Schedule inspection in 3–6 months',
    topIssues: [
      { label: 'Granule Loss', severity: 'mild' },
      { label: 'Flashing', severity: 'mild' },
      { label: 'Hail Marks', severity: 'none' },
    ],
    recommendation: 'Annual inspection sufficient. Monitor valleys for debris buildup.',
  },
  {
    grade: 'C', label: 'Moderate Concerns', urgency: 'Inspection in 30 days',
    topIssues: [
      { label: 'Missing Shingles', severity: 'moderate' },
      { label: 'Granule Loss', severity: 'moderate' },
      { label: 'Hail Marks', severity: 'mild' },
    ],
    recommendation: 'File insurance claim. Multiple failure points suggest coverage-eligible damage.',
  },
  {
    grade: 'D+', label: 'Significant Wear', urgency: 'Inspect within 1–2 weeks',
    topIssues: [
      { label: 'Missing Shingles', severity: 'severe' },
      { label: 'Decking Exposure', severity: 'severe' },
      { label: 'Hail Impact', severity: 'moderate' },
    ],
    recommendation: 'High water damage risk. File insurance claim immediately and book emergency inspection.',
  },
  {
    grade: 'A-', label: 'Good Condition', urgency: 'Routine annual inspection',
    topIssues: [
      { label: 'Granule Loss', severity: 'none' },
      { label: 'Flashing', severity: 'none' },
      { label: 'Hail Marks', severity: 'none' },
    ],
    recommendation: 'Keep annual inspections. Clean gutters twice per year.',
  },
];

const severityDot: Record<string, string> = {
  none: 'bg-emerald-400',
  mild: 'bg-amber-400',
  moderate: 'bg-orange-400',
  severe: 'bg-red-400',
};

const gradeColor: Record<string, string> = {
  'A-': 'text-emerald-400',
  'B+': 'text-emerald-300',
  'C': 'text-amber-400',
  'D+': 'text-orange-400',
};

export default function StormAIAssessment() {
  const [step, setStep] = useState<AssessmentStep>('upload');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [result, setResult] = useState<QuickResult | null>(null);
  const [progress, setProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      setUploadedImage(reader.result as string);
      startAnalysis();
    };
    reader.readAsDataURL(file);
  };

  const startAnalysis = () => {
    setStep('analyzing');
    setProgress(0);
    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(interval);
          setResult(quickResults[Math.floor(Math.random() * quickResults.length)]);
          setStep('results');
          return 100;
        }
        return p + Math.random() * 20 + 8;
      });
    }, 250);
  };

  const handleReset = () => {
    setStep('upload');
    setUploadedImage(null);
    setResult(null);
    setProgress(0);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const openWidget = () => {
    const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
    if (btn) btn.click();
  };

  return (
    <div className="max-w-3xl mx-auto bg-white border border-charcoal/5 overflow-hidden">
      {step === 'upload' && (
        <div className="p-8 md:p-10">
          <div className="text-center mb-6">
            <div className="w-14 h-14 flex items-center justify-center bg-charcoal-deep text-orange mx-auto mb-4">
              <i className="ri-camera-line text-xl" />
            </div>
            <h3 className="font-display text-charcoal-deep text-lg uppercase tracking-wider mb-1">Instant AI Roof Assessment</h3>
            <p className="text-charcoal-mid/40 text-sm">Upload a photo to see if the storm left hidden damage — 30 seconds, no signup.</p>
          </div>
          <div
            onClick={() => fileInputRef.current?.click()}
            onDrop={(e) => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
            onDragOver={(e) => e.preventDefault()}
            className="border-2 border-dashed border-charcoal/10 hover:border-orange/40 bg-warm-beige/30 hover:bg-orange/5 transition-all duration-300 p-10 text-center cursor-pointer"
          >
            <i className="ri-upload-cloud-2-line text-charcoal-mid/30 text-2xl mb-3 block" />
            <p className="text-charcoal-deep font-semibold text-sm">Click or drag a photo here</p>
            <p className="text-charcoal-mid/25 text-xs mt-1">JPG, PNG — up to 10MB</p>
            <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }} />
          </div>
          <div className="mt-6 flex items-center justify-center gap-6">
            {[
              { icon: 'ri-time-line', text: '30 seconds' },
              { icon: 'ri-shield-check-line', text: 'No signup' },
              { icon: 'ri-flashlight-line', text: 'Instant result' },
            ].map((item) => (
              <div key={item.text} className="flex items-center gap-1.5 text-charcoal-mid/30 text-xs">
                <i className={`${item.icon} text-orange`} />
                {item.text}
              </div>
            ))}
          </div>
        </div>
      )}

      {step === 'analyzing' && uploadedImage && (
        <div className="p-8 md:p-10">
          <div className="flex flex-col md:flex-row gap-6">
            <div className="w-full md:w-56 flex-shrink-0">
              <img src={uploadedImage} alt="Roof" className="w-full h-44 object-cover border border-charcoal/5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-5">
                <div className="w-8 h-8 flex items-center justify-center bg-orange/10 text-orange">
                  <i className="ri-robot-2-line animate-pulse" />
                </div>
                <p className="font-display text-charcoal-deep text-sm uppercase tracking-wider">Analyzing storm damage...</p>
              </div>
              <div className="w-full h-1.5 bg-charcoal/5 mb-5">
                <div className="h-full bg-orange transition-all duration-300" style={{ width: `${Math.min(progress, 100)}%` }} />
              </div>
              <div className="space-y-2.5">
                {[
                  'Scanning for hail impact patterns',
                  'Checking shingle lift / wind damage',
                  'Evaluating flashing & valleys',
                  'Assessing granule loss depth',
                  'Generating severity score',
                ].map((label, i) => (
                  <div key={label} className="flex items-center gap-2">
                    <div className={`w-4 h-4 flex items-center justify-center ${progress >= (i + 1) * 20 ? 'bg-orange text-white' : 'bg-charcoal/5 text-charcoal-mid/20'}`}>
                      <i className={`${progress >= (i + 1) * 20 ? 'ri-check-line' : 'ri-loader-4-line animate-spin'} text-[10px]`} />
                    </div>
                    <span className={`text-xs ${progress >= (i + 1) * 20 ? 'text-charcoal-deep' : 'text-charcoal-mid/25'}`}>{label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {step === 'results' && result && (
        <div className="p-8 md:p-10">
          <div className="flex items-center gap-4 mb-6 pb-6 border-b border-charcoal/5">
            <div className={`w-16 h-16 flex items-center justify-center bg-charcoal-deep ${gradeColor[result.grade]}`}>
              <span className="font-display text-2xl tracking-wider">{result.grade}</span>
            </div>
            <div>
              <h3 className="font-display text-charcoal-deep text-lg uppercase tracking-wider">{result.label}</h3>
              <p className="text-charcoal-mid/50 text-sm">{result.urgency}</p>
            </div>
          </div>

          <div className="mb-6">
            <p className="text-charcoal-mid/30 text-xs uppercase tracking-widest mb-3">Top Concerns</p>
            <div className="space-y-2">
              {result.topIssues.map((issue) => (
                <div key={issue.label} className="flex items-center gap-3">
                  <span className={`w-2.5 h-2.5 rounded-full ${severityDot[issue.severity]}`} />
                  <span className="text-charcoal-deep text-sm">{issue.label}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-warm-beige border border-charcoal/5 p-5 mb-6">
            <p className="text-charcoal-mid/50 text-sm leading-relaxed">
              <strong className="text-charcoal-deep">AI recommendation:</strong> {result.recommendation}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => {
                const el = document.getElementById('emergency-form');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="flex-1 bg-orange hover:bg-orange-dark text-white font-semibold px-6 py-3.5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
            >
              <i className="ri-calendar-check-line" />
              Book Free Inspection
            </button>
            <button
              onClick={openWidget}
              className="flex-1 border border-charcoal/20 hover:border-charcoal-deep text-charcoal-deep font-semibold px-6 py-3.5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
            >
              <i className="ri-robot-2-line" />
              Ask AI About Results
            </button>
            <button
              onClick={handleReset}
              className="border border-charcoal/10 hover:border-charcoal/30 text-charcoal-mid/40 hover:text-charcoal-mid font-semibold px-6 py-3.5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              <i className="ri-restart-line" />
            </button>
          </div>

          <p className="text-charcoal-mid/20 text-xs text-center mt-4">
            AI estimate only. A professional inspection is required for insurance and repair decisions.
          </p>
        </div>
      )}
    </div>
  );
}