import { useState } from 'react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const STORM_DATA = [
  {
    id: 1,
    date: 'April 22, 2026',
    time: '4:37 PM – 5:12 PM',
    area: 'Evansville, Newburgh, McCutchanville',
    hailSize: '1.75" (golf ball)',
    windSpeed: '68 mph',
    severity: 'severe',
    color: 'bg-red-500',
    claimsReported: 342,
    status: 'Active — Filing Open',
    damage: 'Extensive shingle bruising, dented gutters, cracked skylights. Hail was large enough to cause decking damage on older roofs.',
  },
  {
    id: 2,
    date: 'April 14, 2026',
    time: '2:15 PM – 2:48 PM',
    area: 'Henderson KY, Evansville Eastside',
    hailSize: '1.25" (half dollar)',
    windSpeed: '55 mph',
    severity: 'moderate',
    color: 'bg-orange-500',
    claimsReported: 187,
    status: 'Filing Period Open',
    damage: 'Moderate granule loss on south-facing slopes. Multiple missing shingles reported in Henderson KY area.',
  },
  {
    id: 3,
    date: 'March 28, 2026',
    time: '7:22 PM – 8:05 PM',
    area: 'Boonville, Warrick County',
    hailSize: '1.00" (quarter)',
    windSpeed: '48 mph',
    severity: 'mild',
    color: 'bg-amber-500',
    claimsReported: 89,
    status: 'Filing Period Open',
    damage: 'Minor denting on metal vents and flashing. Some granule loss on ridge caps. Wind-driven rain caused isolated interior leaks.',
  },
  {
    id: 4,
    date: 'March 12, 2026',
    time: '9:45 PM – 10:30 PM',
    area: 'Mount Vernon, Posey County',
    hailSize: '2.00" (hen egg)',
    windSpeed: '72 mph',
    severity: 'severe',
    color: 'bg-red-600',
    claimsReported: 156,
    status: 'Active — Filing Open',
    damage: 'Severe hail with sustained high winds. Large areas of missing shingles, broken tree limbs, multiple roof punctures reported.',
  },
];

const SEVERITY_BADGE: Record<string, { bg: string; text: string; label: string }> = {
  severe: { bg: 'bg-red-500/10 border-red-500/30', text: 'text-red-400', label: 'SEVERE' },
  moderate: { bg: 'bg-orange-500/10 border-orange-500/30', text: 'text-orange-400', label: 'MODERATE' },
  mild: { bg: 'bg-amber-500/10 border-amber-500/30', text: 'text-amber-400', label: 'MILD' },
};

export default function HailSeverityMap() {
  const [selectedStorm, setSelectedStorm] = useState(STORM_DATA[0]);
  const anim = useScrollAnimation({ threshold: 0.1 });

  return (
    <section className="bg-charcoal-deep border-t border-white/10 py-20 md:py-28 px-6 md:px-10 lg:px-16">
      <div
        ref={anim.ref as React.RefObject<HTMLDivElement>}
        className={`anim-fade-up ${anim.isVisible ? 'is-visible' : ''}`}
      >
        {/* Header */}
        <div className="text-center mb-12 md:mb-16">
          <div className="inline-flex items-center gap-2 border border-red-500/30 bg-red-500/5 px-4 py-2 mb-5">
            <span className="relative w-2 h-2">
              <span className="absolute inset-0 rounded-full bg-red-500 animate-ping opacity-75" />
              <span className="relative w-2 h-2 rounded-full bg-red-500 block" />
            </span>
            <span className="text-red-400 text-xs font-semibold uppercase tracking-[0.25em]">Live Storm Tracker</span>
          </div>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Recent Hail Events<br /><span className="text-orange">in Your Area</span>
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Indiana and Kentucky have seen significant hail activity in 2026. If your area is listed below, your roof may have hidden damage even if it looks fine from the ground.
          </p>
        </div>

        {/* Map + Data grid */}
        <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Storm list */}
          <div className="lg:col-span-2 space-y-3">
            <p className="text-white/30 text-xs uppercase tracking-widest mb-3">Select a Storm Event</p>
            {STORM_DATA.map((storm) => {
              const badge = SEVERITY_BADGE[storm.severity];
              const isSelected = selectedStorm.id === storm.id;
              return (
                <button
                  key={storm.id}
                  onClick={() => setSelectedStorm(storm)}
                  className={`w-full text-left p-5 border transition-all duration-200 cursor-pointer ${
                    isSelected
                      ? 'border-orange/40 bg-orange/5'
                      : 'border-white/5 hover:border-white/15 bg-charcoal/30'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white text-sm font-semibold">{storm.date}</span>
                    <span className={`text-xs font-bold uppercase tracking-wider px-2 py-0.5 border ${badge.bg} ${badge.text}`}>
                      {badge.label}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-white/30 text-xs">
                    <span className="flex items-center gap-1">
                      <i className="ri-time-line" />
                      {storm.time}
                    </span>
                    <span className="flex items-center gap-1">
                      <i className="ri-map-pin-line" />
                      {storm.area}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Selected storm detail */}
          <div className="lg:col-span-3">
            <div className="bg-charcoal/40 border border-white/10 p-6 md:p-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="font-display text-white text-lg uppercase tracking-wider">{selectedStorm.date}</h3>
                  <p className="text-white/30 text-xs mt-1">{selectedStorm.time}</p>
                </div>
                <div className={`w-12 h-12 flex items-center justify-center ${selectedStorm.color}`}>
                  <i className="ri-thunderstorms-line text-white text-xl" />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                <div className="border border-white/10 p-4 text-center">
                  <p className="text-white/30 text-xs uppercase tracking-wider mb-1">Hail Size</p>
                  <p className="text-white font-display text-sm uppercase tracking-wide">{selectedStorm.hailSize}</p>
                </div>
                <div className="border border-white/10 p-4 text-center">
                  <p className="text-white/30 text-xs uppercase tracking-wider mb-1">Wind</p>
                  <p className="text-white font-display text-sm uppercase tracking-wide">{selectedStorm.windSpeed}</p>
                </div>
                <div className="border border-white/10 p-4 text-center">
                  <p className="text-white/30 text-xs uppercase tracking-wider mb-1">Claims</p>
                  <p className="text-white font-display text-sm uppercase tracking-wide">{selectedStorm.claimsReported}+</p>
                </div>
                <div className="border border-white/10 p-4 text-center">
                  <p className="text-white/30 text-xs uppercase tracking-wider mb-1">Status</p>
                  <p className="text-orange font-display text-sm uppercase tracking-wide">{selectedStorm.status}</p>
                </div>
              </div>

              <div className="mb-6">
                <p className="text-white/30 text-xs uppercase tracking-widest mb-3">Storm Damage Report</p>
                <p className="text-white/50 text-sm leading-relaxed">{selectedStorm.damage}</p>
              </div>

              {/* Visual impact indicator */}
              <div className="border border-white/10 p-5">
                <p className="text-white/30 text-xs uppercase tracking-widest mb-4">Hail Impact Size Comparison</p>
                <div className="flex items-end justify-around gap-4 h-24">
                  {['0.5"', '1.0"', '1.5"', '2.0"'].map((size, i) => {
                    const targetSize = parseFloat(selectedStorm.hailSize);
                    const currentSize = parseFloat(size);
                    const isMatch = currentSize === targetSize;
                    const isLarger = targetSize > currentSize;
                    return (
                      <div key={size} className="flex flex-col items-center gap-2">
                        <div
                          className={`rounded-full transition-all duration-500 ${
                            isMatch
                              ? 'bg-orange scale-110'
                              : isLarger
                                ? 'bg-white/10'
                                : 'bg-white/5'
                          }`}
                          style={{
                            width: `${16 + i * 14}px`,
                            height: `${16 + i * 14}px`,
                          }}
                        />
                        <span className={`text-xs uppercase tracking-wider ${isMatch ? 'text-orange font-semibold' : 'text-white/25'}`}>
                          {size}
                        </span>
                      </div>
                    );
                  })}
                </div>
                <p className="text-white/20 text-xs text-center mt-3">
                  Orange = Actual hail size for this storm · {selectedStorm.hailSize} hail can bruise shingles and crack decking.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Urgency CTA */}
        <div className="max-w-5xl mx-auto mt-8 p-6 border border-red-500/20 bg-red-500/5">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 flex items-center justify-center bg-red-500/15 flex-shrink-0">
                <i className="ri-alarm-warning-line text-red-400 text-xl" />
              </div>
              <div>
                <p className="text-white font-semibold text-sm mb-1">Storm near you? Act within 30 days.</p>
                <p className="text-white/40 text-xs leading-relaxed">
                  Indiana has a 1-year statute of limitations for storm damage claims, but insurance companies prioritize recent events. The sooner you file, the stronger your case.
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                const el = document.getElementById('emergency-form');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="flex-shrink-0 bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
            >
              <i className="ri-alarm-warning-line" />
              Start Your Claim
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}