import { useState, useCallback, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import ExteriorFinancingCalculator from '@/components/feature/ExteriorFinancingCalculator';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import { trackToolUsage } from '@/lib/toolAnalytics';

function formatCurrency(n: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);
}

/* ─── Affordability Reverse Calculator ─── */
function AffordabilityCalculator() {
  const [monthlyBudget, setMonthlyBudget] = useState<number>(300);
  const [preferredTerm, setPreferredTerm] = useState<number>(84);
  const [estimatedAPR, setEstimatedAPR] = useState<number>(9.99);
  const [downPayment, setDownPayment] = useState<number>(0);

  const monthlyRate = estimatedAPR / 100 / 12;
  const numPayments = preferredTerm;

  let maxProjectCost = 0;
  if (estimatedAPR === 0) {
    maxProjectCost = monthlyBudget * numPayments + downPayment;
  } else {
    maxProjectCost = (monthlyBudget * (1 - Math.pow(1 + monthlyRate, -numPayments))) / monthlyRate + downPayment;
  }

  return (
    <div className="bg-white border border-charcoal/5 p-6 md:p-10 mb-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 flex items-center justify-center bg-charcoal-deep text-orange flex-shrink-0">
          <i className="ri-calculator-line text-lg" />
        </div>
        <div>
          <h3 className="font-display text-charcoal-deep text-lg uppercase tracking-wider">What Can I Afford?</h3>
          <p className="text-charcoal-mid/40 text-xs">Reverse calculator — enter your monthly budget and see your max project size.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Monthly Budget</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-charcoal-mid/30 text-sm font-semibold">$</span>
            <input
              type="number"
              value={monthlyBudget}
              onChange={(e) => setMonthlyBudget(Number(e.target.value))}
              className="w-full bg-gray-100 px-4 py-3 pl-8 text-charcoal-deep text-sm focus:outline-none focus:ring-2 focus:ring-orange/40"
            />
          </div>
        </div>
        <div>
          <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Preferred Term</label>
          <select
            value={preferredTerm}
            onChange={(e) => setPreferredTerm(Number(e.target.value))}
            className="w-full bg-gray-100 px-4 py-3 text-charcoal-deep text-sm focus:outline-none focus:ring-2 focus:ring-orange/40"
          >
            <option value={12}>12 Months (Same-As-Cash)</option>
            <option value={24}>24 Months</option>
            <option value={36}>36 Months</option>
            <option value={60}>60 Months (5 Years)</option>
            <option value={84}>84 Months (7 Years)</option>
            <option value={120}>120 Months (10 Years)</option>
            <option value={180}>180 Months (15 Years)</option>
          </select>
        </div>
        <div>
          <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Est. APR</label>
          <div className="relative">
            <input
              type="number"
              step={0.01}
              value={estimatedAPR}
              onChange={(e) => setEstimatedAPR(Number(e.target.value))}
              className="w-full bg-gray-100 px-4 py-3 text-charcoal-deep text-sm focus:outline-none focus:ring-2 focus:ring-orange/40"
            />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-charcoal-mid/30 text-sm font-semibold">%</span>
          </div>
        </div>
      </div>

      <div>
        <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Down Payment (Optional)</label>
        <div className="relative max-w-xs">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-charcoal-mid/30 text-sm font-semibold">$</span>
          <input
            type="number"
            value={downPayment}
            onChange={(e) => setDownPayment(Number(e.target.value))}
            className="w-full bg-gray-100 px-4 py-3 pl-8 text-charcoal-deep text-sm focus:outline-none focus:ring-2 focus:ring-orange/40"
          />
        </div>
      </div>

      {/* Result */}
      <div className="mt-8 bg-charcoal-deep p-6 md:p-8 text-center">
        <p className="text-white/30 text-xs font-semibold uppercase tracking-[0.25em] mb-3">Maximum Project Budget</p>
        <p className="font-display text-orange text-4xl md:text-5xl uppercase tracking-wider mb-2">{formatCurrency(Math.round(maxProjectCost))}</p>
        <p className="text-white/30 text-sm">
          At {formatCurrency(monthlyBudget)}/mo for {preferredTerm} months @ {estimatedAPR}% APR
        </p>
        <div className="flex flex-wrap justify-center gap-3 mt-5">
          {[
            { label: 'Small Repair', range: [2000, 5000] },
            { label: 'Partial Roof', range: [8000, 15000] },
            { label: 'Full Roof', range: [18000, 35000] },
            { label: 'Complete Exterior', range: [35000, 70000] },
          ].map((item) => {
            const inRange = maxProjectCost >= item.range[0];
            return (
              <span
                key={item.label}
                className={`px-3 py-1.5 text-xs font-semibold uppercase tracking-wider border ${
                  inRange ? 'border-orange text-orange bg-orange/5' : 'border-white/10 text-white/20'
                }`}
              >
                {inRange && <i className="ri-check-line mr-1" />}
                {item.label}
              </span>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ─── Cash vs Finance Comparison ─── */
function CashVsFinance() {
  const [projectCost, setProjectCost] = useState<number>(25000);
  const [cashDiscount, setCashDiscount] = useState<number>(3);
  const [financeRate, setFinanceRate] = useState<number>(9.99);
  const [financeTerm, setFinanceTerm] = useState<number>(84);

  const cashPrice = projectCost * (1 - cashDiscount / 100);
  const monthlyRate = financeRate / 100 / 12;
  const numPayments = financeTerm;

  let monthlyPayment = 0;
  let totalFinanceCost = 0;
  if (financeRate === 0) {
    monthlyPayment = projectCost / numPayments;
    totalFinanceCost = projectCost;
  } else {
    monthlyPayment = (projectCost * monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / (Math.pow(1 + monthlyRate, numPayments) - 1);
    totalFinanceCost = monthlyPayment * numPayments;
  }

  const interestPaid = totalFinanceCost - projectCost;
  const savingsWithCash = totalFinanceCost - cashPrice;

  return (
    <div className="bg-white border border-charcoal/5 p-6 md:p-10 mb-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 flex items-center justify-center bg-charcoal-deep text-orange flex-shrink-0">
          <i className="ri-scales-3-line text-lg" />
        </div>
        <div>
          <h3 className="font-display text-charcoal-deep text-lg uppercase tracking-wider">Cash vs. Financing</h3>
          <p className="text-charcoal-mid/40 text-xs">See the real cost difference between paying cash and financing your project.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Project Cost</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-charcoal-mid/30 text-sm font-semibold">$</span>
            <input
              type="number"
              value={projectCost}
              onChange={(e) => setProjectCost(Number(e.target.value))}
              className="w-full bg-gray-100 px-4 py-3 pl-8 text-charcoal-deep text-sm focus:outline-none focus:ring-2 focus:ring-orange/40"
            />
          </div>
        </div>
        <div>
          <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Cash Discount</label>
          <div className="relative">
            <input
              type="number"
              value={cashDiscount}
              onChange={(e) => setCashDiscount(Number(e.target.value))}
              className="w-full bg-gray-100 px-4 py-3 text-charcoal-deep text-sm focus:outline-none focus:ring-2 focus:ring-orange/40"
            />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-charcoal-mid/30 text-sm font-semibold">%</span>
          </div>
        </div>
        <div>
          <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Finance Rate</label>
          <div className="relative">
            <input
              type="number"
              step={0.01}
              value={financeRate}
              onChange={(e) => setFinanceRate(Number(e.target.value))}
              className="w-full bg-gray-100 px-4 py-3 text-charcoal-deep text-sm focus:outline-none focus:ring-2 focus:ring-orange/40"
            />
            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-charcoal-mid/30 text-sm font-semibold">%</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Cash Column */}
        <div className="bg-charcoal-deep p-6 md:p-8 text-center">
          <div className="w-12 h-12 flex items-center justify-center bg-orange/20 mx-auto mb-4">
            <i className="ri-money-dollar-circle-line text-orange text-2xl" />
          </div>
          <p className="text-white/30 text-xs font-semibold uppercase tracking-[0.25em] mb-2">Pay Cash</p>
          <p className="font-display text-white text-3xl md:text-4xl uppercase tracking-wider mb-1">{formatCurrency(Math.round(cashPrice))}</p>
          <p className="text-white/30 text-sm">Save {formatCurrency(Math.round(projectCost - cashPrice))} ({cashDiscount}% discount)</p>
          <ul className="mt-5 space-y-2 text-left max-w-xs mx-auto">
            <li className="text-white/50 text-sm flex items-start gap-2">
              <i className="ri-check-line text-orange text-xs mt-1 flex-shrink-0" />
              No interest charges
            </li>
            <li className="text-white/50 text-sm flex items-start gap-2">
              <i className="ri-check-line text-orange text-xs mt-1 flex-shrink-0" />
              No credit check required
            </li>
            <li className="text-white/50 text-sm flex items-start gap-2">
              <i className="ri-check-line text-orange text-xs mt-1 flex-shrink-0" />
              Project paid in full
            </li>
            <li className="text-white/50 text-sm flex items-start gap-2">
              <i className="ri-check-line text-orange text-xs mt-1 flex-shrink-0" />
              Eligible for cash discount
            </li>
          </ul>
        </div>

        {/* Finance Column */}
        <div className="bg-charcoal-mid border border-white/10 p-6 md:p-8 text-center">
          <div className="w-12 h-12 flex items-center justify-center bg-white/10 mx-auto mb-4">
            <i className="ri-bank-card-line text-white text-2xl" />
          </div>
          <p className="text-white/30 text-xs font-semibold uppercase tracking-[0.25em] mb-2">Finance It</p>
          <p className="font-display text-white text-3xl md:text-4xl uppercase tracking-wider mb-1">{formatCurrency(Math.round(monthlyPayment))}<span className="text-white/30 text-lg">/mo</span></p>
          <p className="text-white/30 text-sm">{financeTerm} months @ {financeRate}% APR</p>
          <div className="mt-5 space-y-3 max-w-xs mx-auto">
            <div className="flex items-center justify-between text-sm border-b border-white/5 pb-2">
              <span className="text-white/40">Total Payments</span>
              <span className="text-white font-semibold">{formatCurrency(Math.round(totalFinanceCost))}</span>
            </div>
            <div className="flex items-center justify-between text-sm border-b border-white/5 pb-2">
              <span className="text-white/40">Interest Paid</span>
              <span className="text-orange font-semibold">{formatCurrency(Math.round(interestPaid))}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-white/40">Extra vs Cash</span>
              <span className="text-red-400 font-semibold">+{formatCurrency(Math.round(savingsWithCash))}</span>
            </div>
          </div>
          <ul className="mt-5 space-y-2 text-left max-w-xs mx-auto">
            <li className="text-white/50 text-sm flex items-start gap-2">
              <i className="ri-check-line text-orange text-xs mt-1 flex-shrink-0" />
              Keep cash for emergencies
            </li>
            <li className="text-white/50 text-sm flex items-start gap-2">
              <i className="ri-check-line text-orange text-xs mt-1 flex-shrink-0" />
              Same-as-cash options (0% APR)
            </li>
            <li className="text-white/50 text-sm flex items-start gap-2">
              <i className="ri-check-line text-orange text-xs mt-1 flex-shrink-0" />
              No prepayment penalties
            </li>
            <li className="text-white/50 text-sm flex items-start gap-2">
              <i className="ri-check-line text-orange text-xs mt-1 flex-shrink-0" />
              Tax-deductible interest possible
            </li>
          </ul>
        </div>
      </div>

      {/* Recommendation */}
      <div className="mt-6 bg-orange/5 border border-orange/15 p-5 flex items-start gap-3">
        <div className="w-10 h-10 flex items-center justify-center bg-orange text-white flex-shrink-0">
          <i className="ri-robot-2-line text-lg" />
        </div>
        <div>
          <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1">AI Recommendation</p>
          <p className="text-charcoal-mid/50 text-sm leading-relaxed">
            {cashDiscount >= 5 && projectCost <= 30000
              ? `With a ${cashDiscount}% cash discount, paying upfront saves you ${formatCurrency(Math.round(savingsWithCash))} vs financing. If you have the liquidity, cash is the better deal.`
              : interestPaid < 2000
              ? 'The interest cost is relatively low. Financing preserves your cash reserves while the project gets done now — a solid choice if you prefer liquidity.'
              : `Financing adds ${formatCurrency(Math.round(interestPaid))} in interest. Consider our 12-month same-as-cash option to eliminate interest entirely, or increase your down payment to reduce the financed amount.`}
          </p>
        </div>
      </div>
    </div>
  );
}

/* ─── Main Page ─── */
export default function FinancingCalculatorPage() {
  const navigate = useNavigate();
  const heroAnim = useScrollAnimation({ threshold: 0.08 });

  useEffect(() => {
    // Track after 10 seconds to confirm genuine engagement (not a quick bounce)
    const timer = setTimeout(() => {
      trackToolUsage('financing-calculator', 'Financing Calculator');
    }, 10000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      <PageSEO
        title="Financing Calculator — Roof Payment Planner | Corner Stone Roofing"
        description="Calculate your exact monthly roof payment, compare cash vs financing, and find out what project size fits your budget. Free, instant, no credit check."
        keywords="roof financing calculator, roofing payment estimator, monthly roof payment, roof loan calculator, Evansville roof financing"
        canonical="https://cornerstoneconstruction.com/financing-calculator"
        schema={{
          '@context': 'https://schema.org',
          '@type': 'SoftwareApplication',
          name: 'Roof Financing Calculator Suite',
          applicationCategory: 'FinanceApplication',
          operatingSystem: 'Web',
          offers: {
            '@type': 'Offer',
            price: '0',
            priceCurrency: 'USD',
          },
          aggregateRating: {
            '@type': 'AggregateRating',
            ratingValue: '4.8',
            ratingCount: '183',
          },
          description: 'Free 3-in-1 roof financing calculator suite: monthly payment estimator, reverse affordability calculator, and cash-vs-financing comparison with AI-powered recommendations. No credit check required.',
          softwareVersion: '2026.05',
          publisher: {
            '@type': 'Organization',
            name: 'Corner Stone Construction & Roofing',
            url: 'https://cornerstoneconstructionevansville.com',
          },
        }}
      />

      {/* ── Hero ── */}
      <section className="bg-charcoal-deep pt-28 pb-16 md:pt-36 md:pb-24 px-6 md:px-10 lg:px-16">
        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''} max-w-4xl mx-auto text-center`}
        >
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">No Credit Check Required</p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Roof Financing<br /><span className="text-orange">Calculator</span>
          </h1>
          <p className="text-white/50 text-sm md:text-base max-w-2xl mx-auto leading-relaxed mb-8">
            Three powerful tools in one: estimate your monthly payment, calculate what you can afford, and compare cash vs financing side-by-side. No personal info required.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 text-white/30 text-xs">
            <span className="flex items-center gap-1.5"><i className="ri-shield-check-line text-orange" />Soft credit check only</span>
            <span className="flex items-center gap-1.5"><i className="ri-time-line text-orange" />Same-day approval</span>
            <span className="flex items-center gap-1.5"><i className="ri-lock-line text-orange" />100% private</span>
          </div>
        </div>
      </section>

      {/* ── Tool 1: Monthly Payment Calculator ── */}
      <section className="bg-charcoal py-16 md:py-24 px-6 md:px-10 lg:px-16">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-3">Tool 1 of 3</p>
            <h2 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider mb-2">Monthly Payment Calculator</h2>
            <p className="text-white/40 text-sm max-w-xl mx-auto">Enter your project cost, down payment, credit tier, and preferred term. See your exact monthly payment instantly.</p>
          </div>
          <ExteriorFinancingCalculator />
        </div>
      </section>

      {/* ── Tool 2: Affordability Calculator ── */}
      <section className="bg-warm-beige py-16 md:py-24 px-6 md:px-10 lg:px-16">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-3">Tool 2 of 3</p>
            <h2 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider mb-2">What Can I Afford?</h2>
            <p className="text-charcoal-mid/40 text-sm max-w-xl mx-auto">Start with your monthly budget and work backwards to find your maximum project size.</p>
          </div>
          <AffordabilityCalculator />
        </div>
      </section>

      {/* ── Tool 3: Cash vs Finance ── */}
      <section className="bg-warm-beige py-16 md:py-24 px-6 md:px-10 lg:px-16 border-t border-charcoal/5">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-3">Tool 3 of 3</p>
            <h2 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider mb-2">Cash vs. Financing</h2>
            <p className="text-charcoal-mid/40 text-sm max-w-xl mx-auto">See the total cost difference between paying cash and taking a loan — with AI-powered guidance on which makes sense for you.</p>
          </div>
          <CashVsFinance />
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="bg-charcoal-deep py-16 md:py-24 px-6 md:px-10 lg:px-16">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wider mb-4">Ready to Get Pre-Qualified?</h2>
          <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8 max-w-xl mx-auto">
            We work with GreenSky, Synchrony, and EnerBank to offer flexible financing. No impact on your credit score for pre-qualification. Most approvals in under 5 minutes.
          </p>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3">
            <button
              onClick={() => navigate('/financing')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
            >
              <i className="ri-bank-card-line" />
              See Full Financing Options
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/20 hover:border-orange text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              Call 812-213-5997
            </a>
          </div>
        </div>
      </section>

      {/* ── Alex AI Help Strip ── */}
      <TalkToAIExpert />
    </>
  );
}