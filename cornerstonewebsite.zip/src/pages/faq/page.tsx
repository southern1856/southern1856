import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import PageSEO from '@/components/feature/PageSEO';

const faqPageSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: [
    {
      '@type': 'Question',
      name: 'How much does a new roof cost in Evansville Indiana?',
      acceptedAnswer: { '@type': 'Answer', text: 'The average cost of a new roof in Evansville ranges from $8,000 to $25,000 depending on your home\'s size, the roofing material you choose, and the complexity of the job. We offer free, no-obligation estimates.' },
    },
    {
      '@type': 'Question',
      name: 'How long does a roof replacement take in Evansville?',
      acceptedAnswer: { '@type': 'Answer', text: 'Most residential roof replacements in Evansville are completed in 1-3 days. Larger homes or complex rooflines may take 3-5 days.' },
    },
    {
      '@type': 'Question',
      name: 'Will my insurance cover roof damage in Indiana?',
      acceptedAnswer: { '@type': 'Answer', text: 'Most Indiana homeowners insurance policies cover roof damage caused by sudden events like hail, windstorms, falling trees, or fire. We work directly with all major insurance companies and can help document damage and guide you through the claims process.' },
    },
    {
      '@type': 'Question',
      name: 'Do you offer emergency roof repair in Evansville?',
      acceptedAnswer: { '@type': 'Answer', text: 'Yes! We provide 24/7 emergency roof repair services throughout Evansville, Newburgh, and Vanderburgh County. Call our emergency line at 812-213-5997 any time, day or night.' },
    },
    {
      '@type': 'Question',
      name: 'What roofing material is best for Indiana weather?',
      acceptedAnswer: { '@type': 'Answer', text: 'For Indiana\'s climate, architectural asphalt shingles are the most popular and cost-effective choice. For maximum durability, metal roofing is excellent and can last 40-70 years. We also install impact-resistant shingles ideal for hail-prone areas like Vanderburgh County.' },
    },
    {
      '@type': 'Question',
      name: 'Do you offer financing for roof replacement?',
      acceptedAnswer: { '@type': 'Answer', text: 'Yes, we offer flexible financing options including 0% interest plans for qualified homeowners in Evansville and surrounding areas. Plans start from $89/month.' },
    },
  ],
};

const faqCategories = [
  {
    id: 'pricing',
    label: 'Pricing & Estimates',
    icon: 'ri-money-dollar-circle-line',
    faqs: [
      {
        q: 'How much does a new roof cost in Evansville, Indiana?',
        a: 'The average cost of a new roof in Evansville ranges from $8,000 to $25,000 depending on your home\'s size, the roofing material you choose, and the complexity of the job. Asphalt shingles typically cost $4–7 per square foot installed, while metal roofing runs $8–14 per square foot. We offer free, no-obligation estimates so you know exactly what to expect before any work begins.',
      },
      {
        q: 'Do you offer free estimates?',
        a: 'Yes — always. Every estimate from Corner Stone is 100% free and comes with no pressure or obligation. We\'ll inspect your roof, document any issues with photos, and give you a detailed written quote. Most estimates are completed within 24–48 hours of your request.',
      },
      {
        q: 'Do you offer financing for roof replacement?',
        a: 'Yes, we offer flexible financing options for qualified homeowners in Evansville and the surrounding area. We partner with several financing providers to offer plans with low monthly payments, deferred interest options, and terms up to 120 months. During your free estimate, we can discuss financing options that fit your budget.',
      },
      {
        q: 'How long is my estimate valid?',
        a: 'Our estimates are valid for 30 days from the date of issuance. Material prices can fluctuate, especially after major storm events when demand is high. If your estimate expires, just give us a call — we\'ll update it quickly at no charge.',
      },
    ],
  },
  {
    id: 'process',
    label: 'The Roofing Process',
    icon: 'ri-tools-line',
    faqs: [
      {
        q: 'How long does a roof replacement take in Evansville?',
        a: 'Most residential roof replacements in Evansville are completed in 1–3 days. Smaller homes with simple rooflines may take just a single day, while larger homes or those with complex architecture, multiple dormers, or steep pitches can take 3–5 days. Weather is also a factor — we monitor Indiana forecasts closely and will reschedule if conditions are unsafe.',
      },
      {
        q: 'What happens during a roof replacement?',
        a: 'Here\'s what to expect: First, we protect your landscaping and driveway with tarps and plywood. Then we remove the old shingles and inspect the decking for damage. Any damaged decking is replaced. We install underlayment, ice & water shield in valleys, then the new shingles, ridge cap, and all flashing. Finally, we do a thorough cleanup — including a magnetic sweep for nails. You\'ll receive a final walkthrough and photo documentation.',
      },
      {
        q: 'Do I need to be home during the roof replacement?',
        a: 'You don\'t need to be home during the work itself, but we do ask that someone is available at the start of the project for a quick walkthrough and to answer any questions. We\'ll keep you updated throughout the day via text or phone, and we\'ll do a final walkthrough with you when the job is complete.',
      },
      {
        q: 'Will you clean up after the job?',
        a: 'Absolutely. We take cleanup seriously. Our crew uses tarps to catch debris as we work, and we do a full property cleanup at the end of every job — including a magnetic nail sweep of your lawn, driveway, and landscaping. We leave your property cleaner than we found it.',
      },
    ],
  },
  {
    id: 'materials',
    label: 'Materials & Products',
    icon: 'ri-stack-line',
    faqs: [
      {
        q: 'What roofing material is best for Indiana weather?',
        a: 'For Indiana\'s climate — hot humid summers, heavy spring rains, and winter ice dams — architectural asphalt shingles are the most popular and cost-effective choice. They handle temperature swings well and resist wind up to 130 mph. For maximum durability, metal roofing is excellent for Indiana and can last 40–70 years. We also install impact-resistant shingles that are ideal for areas prone to hail, like Vanderburgh County.',
      },
      {
        q: 'What shingle brands do you install?',
        a: 'We are certified installers for GAF, Owens Corning, CertainTeed, and Atlas Roofing — the four leading shingle manufacturers in the US. Being certified with all four means we can offer you the best product for your specific situation and budget, and you get access to enhanced manufacturer warranties that non-certified contractors can\'t provide.',
      },
      {
        q: 'How long do asphalt shingles last in Indiana?',
        a: 'Standard 3-tab shingles typically last 15–20 years in Indiana\'s climate. Architectural (dimensional) shingles last 25–30 years. Premium impact-resistant shingles can last 30–40 years. Metal roofing lasts 40–70 years. Proper installation, ventilation, and maintenance all significantly affect lifespan.',
      },
      {
        q: 'Do you install metal roofing?',
        a: 'Yes — we have a dedicated metal roofing division with crews specifically trained in standing seam and corrugated metal systems. Metal roofing is one of the best long-term investments for Indiana homeowners. It\'s energy-efficient, extremely durable, and can last 50+ years with minimal maintenance.',
      },
    ],
  },
  {
    id: 'insurance',
    label: 'Insurance & Storm Damage',
    icon: 'ri-shield-check-line',
    faqs: [
      {
        q: 'Will my insurance cover roof damage in Indiana?',
        a: 'Most Indiana homeowners insurance policies cover roof damage caused by sudden, accidental events like hail, windstorms, falling trees, or fire. They typically do NOT cover damage from normal wear and tear or lack of maintenance. We work directly with all major insurance companies and can help document damage, provide detailed estimates, and guide you through the claims process to maximize your coverage.',
      },
      {
        q: 'How do I know if my roof has hail damage?',
        a: 'Hail damage isn\'t always visible from the ground. Signs include dents or bruising on shingles (look for dark spots where granules have been knocked off), damaged gutters or downspouts, dented AC units or vents, and cracked or broken skylights. The best way to know for sure is a professional inspection — ours are always free.',
      },
      {
        q: 'Do you work with insurance companies?',
        a: 'Yes — this is one of our specialties. We have a dedicated insurance claims specialist on staff who has helped homeowners recover over $2.4M in insurance claims. We document all damage with photos and detailed reports, provide insurance-grade estimates, and meet your adjuster on-site to make sure nothing gets missed.',
      },
      {
        q: 'How long do I have to file a storm damage claim in Indiana?',
        a: 'Most Indiana homeowners insurance policies require you to file a claim within 1–2 years of the damage event, but this varies by policy. We strongly recommend getting an inspection as soon as possible after a storm — the sooner damage is documented, the stronger your claim. Don\'t wait until you see a leak inside your home.',
      },
    ],
  },
  {
    id: 'service',
    label: 'Service & Warranty',
    icon: 'ri-award-line',
    faqs: [
      {
        q: 'Do you offer emergency roof repair in Evansville?',
        a: 'Yes! We provide 24/7 emergency roof repair services throughout Evansville, Newburgh, and Vanderburgh County. If a storm has damaged your roof, we can typically arrive within 2–4 hours to tarp the damaged area and prevent further water damage to your home. Call our emergency line at 812-213-5997 any time, day or night.',
      },
      {
        q: 'What warranty do you offer on your work?',
        a: 'We offer a 10-year workmanship warranty on all full roof replacements — one of the strongest in the Evansville area. This covers any installation-related issues. In addition, the shingle manufacturers we work with offer product warranties ranging from 25 years to lifetime, depending on the product. As a certified contractor, we can offer enhanced warranties that non-certified contractors cannot.',
      },
      {
        q: 'How often should I have my roof inspected?',
        a: 'We recommend having your roof professionally inspected at least once a year, ideally in the fall before winter weather hits. You should also schedule an inspection after any major storm, if you notice leaks or water stains inside your home, or if your roof is over 15 years old. Our Evansville roof inspections are thorough, free, and come with a detailed report and photo documentation.',
      },
      {
        q: 'What areas do you serve besides Evansville?',
        a: 'Corner Stone Construction & Roofing proudly serves all of Vanderburgh County including Evansville, Newburgh, and McCutchanville. We also work in surrounding areas such as Boonville (Warrick County), Mount Vernon (Posey County), Princeton (Gibson County), and across the river in Henderson, Kentucky. If you\'re unsure whether we cover your area, just give us a call — we likely do!',
      },
    ],
  },
];

function FAQItem({ q, a, index }: { q: string; a: string; index: number }) {
  const [open, setOpen] = useState(false);
  return (
    <div className={`border-b border-white/5 last:border-0 transition-colors duration-200 ${open ? 'bg-white/3' : ''}`}>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-start justify-between gap-4 py-5 px-6 text-left cursor-pointer group"
      >
        <div className="flex items-start gap-3 min-w-0">
          <span className="font-display text-orange/40 text-sm tracking-wider flex-shrink-0 mt-0.5">
            {String(index + 1).padStart(2, '0')}
          </span>
          <span className={`text-sm md:text-base font-medium leading-snug transition-colors duration-200 ${open ? 'text-white' : 'text-white/70 group-hover:text-white'}`}>
            {q}
          </span>
        </div>
        <div className={`w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5 transition-all duration-300 ${open ? 'text-orange rotate-45' : 'text-white/30 group-hover:text-white/60'}`}>
          <i className="ri-add-line text-lg" />
        </div>
      </button>
      <div className={`overflow-hidden transition-all duration-300 ${open ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'}`}>
        <p className="text-white/50 text-sm leading-relaxed px-6 pb-5 pl-[3.25rem]">{a}</p>
      </div>
    </div>
  );
}

export default function FAQPage() {
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState('pricing');
  const heroAnim = useScrollAnimation();
  const contentAnim = useScrollAnimation({ threshold: 0.05 });

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, []);

  const currentCategory = faqCategories.find((c) => c.id === activeCategory)!;

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roofing FAQ Evansville Indiana | Cost, Insurance, Materials & More"
        description="Answers to the most common roofing questions in Evansville Indiana. Learn about roof replacement cost, how long it takes, insurance claims, best materials for Indiana weather, warranties, and emergency repairs. Corner Stone Construction & Roofing."
        keywords="roofing FAQ Evansville Indiana, how much does a roof cost Indiana, roof replacement questions, roofing insurance claims FAQ, best roofing material Indiana, emergency roof repair Evansville"
        canonical="/faq"
        schema={faqPageSchema}
      />

      {/* Hero */}
      <section className="relative pt-32 pb-20 px-6 md:px-10 lg:px-16 overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-orange/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
        </div>
        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 max-w-3xl anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Knowledge Base</p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
            Frequently Asked<br /><span className="text-orange">Questions</span>
          </h1>
          <p className="text-white/40 text-sm md:text-base leading-relaxed max-w-xl">
            Everything you need to know about roofing in Evansville, Indiana — from pricing and materials to insurance claims and warranties. Can't find your answer? Just call us.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 mt-8">
            <button
              onClick={() => navigate('/estimate')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-xs transition-colors whitespace-nowrap cursor-pointer"
            >
              Get a Free Estimate
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/20 hover:border-white text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-xs transition-colors whitespace-nowrap flex items-center justify-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>
      </section>

      {/* FAQ Content */}
      <section className="pb-24 px-6 md:px-10 lg:px-16">
        <div
          ref={contentAnim.ref as React.RefObject<HTMLDivElement>}
          className={`flex flex-col lg:flex-row gap-8 anim-fade-up ${contentAnim.isVisible ? 'is-visible' : ''}`}
        >
          {/* Sidebar categories */}
          <div className="lg:w-64 flex-shrink-0">
            <div className="lg:sticky lg:top-28 space-y-1">
              <p className="text-white/30 text-xs uppercase tracking-widest mb-4 px-3">Categories</p>
              {faqCategories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-all duration-200 cursor-pointer ${
                    activeCategory === cat.id
                      ? 'bg-orange/15 border-l-2 border-orange text-white'
                      : 'text-white/50 hover:text-white hover:bg-white/5 border-l-2 border-transparent'
                  }`}
                >
                  <i className={`${cat.icon} text-base flex-shrink-0 ${activeCategory === cat.id ? 'text-orange' : ''}`} />
                  <span className="text-sm font-medium">{cat.label}</span>
                  <span className={`ml-auto text-xs ${activeCategory === cat.id ? 'text-orange' : 'text-white/20'}`}>
                    {cat.faqs.length}
                  </span>
                </button>
              ))}

              {/* Still have questions */}
              <div className="mt-8 bg-charcoal border border-white/10 p-5">
                <p className="text-white text-sm font-semibold mb-1">Still have questions?</p>
                <p className="text-white/40 text-xs leading-relaxed mb-4">Our team is happy to help. Call or text us anytime.</p>
                <a
                  href="tel:8122135997"
                  className="flex items-center gap-2 text-orange text-sm font-semibold hover:text-orange-dark transition-colors"
                >
                  <i className="ri-phone-line" />
                  812-213-5997
                </a>
              </div>
            </div>
          </div>

          {/* FAQ list */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 flex items-center justify-center bg-orange/15 text-orange">
                <i className={`${currentCategory.icon} text-lg`} />
              </div>
              <div>
                <h2 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider">{currentCategory.label}</h2>
                <p className="text-white/30 text-xs">{currentCategory.faqs.length} questions</p>
              </div>
            </div>

            <div className="bg-charcoal border border-white/5">
              {currentCategory.faqs.map((faq, i) => (
                <FAQItem key={faq.q} q={faq.q} a={faq.a} index={i} />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 md:px-10 lg:px-16 bg-charcoal border-t border-white/10">
        <div className="text-center max-w-2xl mx-auto">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Ready to Get Started?</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
            Free Inspection.<br /><span className="text-orange">No Pressure. Ever.</span>
          </h2>
          <p className="text-white/40 text-sm leading-relaxed mb-8">
            Evansville's most trusted roofing contractor since 1995. We'll give you an honest assessment and a fair price — guaranteed.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigate('/estimate')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              Request Free Estimate
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/20 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
