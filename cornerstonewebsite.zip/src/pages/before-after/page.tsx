import { useState, useRef, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import PageSEO from '@/components/feature/PageSEO';
import SocialShareCard from '@/components/feature/SocialShareCard';

const beforeAfterSchema = [
  {
    '@context': 'https://schema.org',
    '@type': 'ImageGallery',
    name: 'Before & After Roofing Projects — Corner Stone Construction & Roofing',
    description: 'Real before and after photos of roofing projects completed by Corner Stone Construction & Roofing across Evansville IN, Newburgh, Henderson KY, and the Tri-State area.',
    url: 'https://cornerstoneconstructionevansville.com/before-after',
    author: {
      '@type': 'Organization',
      name: 'Corner Stone Construction & Roofing',
      telephone: '+1-812-213-5997',
    },
    image: [
      { '@type': 'ImageObject', name: 'Hail Damage Full Replacement — Evansville IN', description: 'Before and after hail damage roof replacement in Evansville Indiana', contentUrl: '/placeholders/800x560.svg' },
      { '@type': 'ImageObject', name: 'Full Residential Replacement — Newburgh IN', description: 'Before and after full residential roof replacement in Newburgh Indiana', contentUrl: '/placeholders/800x560.svg' },
      { '@type': 'ImageObject', name: 'Standing Seam Metal Roof — Henderson KY', description: 'Before and after metal roof installation in Henderson Kentucky', contentUrl: '/placeholders/800x560.svg' },
      { '@type': 'ImageObject', name: 'Commercial TPO Flat Roof — Evansville IN', description: 'Before and after commercial TPO flat roof replacement in Evansville Indiana', contentUrl: '/placeholders/800x560.svg' },
    ],
  },
  {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name: 'Roofing Project Portfolio — Corner Stone Construction & Roofing',
    description: 'Portfolio of completed roofing projects including residential, commercial, storm damage, and metal roofing across the Tri-State area.',
    numberOfItems: 9,
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Hail Damage Full Replacement — Evansville IN', url: 'https://cornerstoneconstructionevansville.com/before-after' },
      { '@type': 'ListItem', position: 2, name: 'Full Residential Replacement — Newburgh IN', url: 'https://cornerstoneconstructionevansville.com/before-after' },
      { '@type': 'ListItem', position: 3, name: 'Asphalt to Standing Seam Metal — Henderson KY', url: 'https://cornerstoneconstructionevansville.com/before-after' },
      { '@type': 'ListItem', position: 4, name: 'Wind Damage Partial Replacement — Boonville IN', url: 'https://cornerstoneconstructionevansville.com/before-after' },
      { '@type': 'ListItem', position: 5, name: 'Commercial Flat Roof TPO — Evansville IN', url: 'https://cornerstoneconstructionevansville.com/before-after' },
    ],
  },
];

type Category = 'all' | 'residential' | 'commercial' | 'storm' | 'metal';

const projects = [
  {
    id: 1,
    category: 'storm' as Category,
    title: 'Hail Damage — Full Replacement',
    location: 'Evansville, IN',
    date: 'April 2026',
    claimAmount: '$14,200',
    description: 'Quarter-sized hail stripped granules across the entire south-facing slope. Insurance initially offered $6,800 — we supplemented to full replacement approval.',
    tag: 'Insurance Claim',
    tagColor: 'bg-red-500',
    stats: [
      { label: 'Roof Size', value: '28 Squares' },
      { label: 'Material', value: 'Arch. Shingles' },
      { label: 'Duration', value: '1 Day' },
      { label: 'Claim', value: '$14,200' },
    ],
    before: '/placeholders/800x560.svg',
    after: '/placeholders/800x560.svg',
  },
  {
    id: 2,
    category: 'residential' as Category,
    title: 'Full Residential Replacement',
    location: 'Newburgh, IN',
    date: 'March 2026',
    claimAmount: null,
    description: 'Complete tear-off and replacement of a 30-year-old 3-tab shingle roof. Upgraded to architectural shingles with a 50-year warranty and new ridge ventilation system.',
    tag: 'Full Replacement',
    tagColor: 'bg-orange',
    stats: [
      { label: 'Roof Size', value: '32 Squares' },
      { label: 'Material', value: 'GAF Timberline' },
      { label: 'Duration', value: '2 Days' },
      { label: 'Warranty', value: '50 Years' },
    ],
    before: '/placeholders/800x560.svg',
    after: '/placeholders/800x560.svg',
  },
  {
    id: 3,
    category: 'metal' as Category,
    title: 'Asphalt to Standing Seam Metal',
    location: 'Henderson, KY',
    date: 'February 2026',
    claimAmount: null,
    description: 'Homeowner wanted a permanent solution. Removed aging asphalt and installed a full standing seam metal roof system in charcoal gray. 50+ year lifespan, energy efficient.',
    tag: 'Metal Upgrade',
    tagColor: 'bg-charcoal-deep border border-white/20',
    stats: [
      { label: 'Roof Size', value: '24 Squares' },
      { label: 'Material', value: 'Standing Seam' },
      { label: 'Duration', value: '3 Days' },
      { label: 'Lifespan', value: '50+ Years' },
    ],
    before: '/placeholders/800x560.svg',
    after: '/placeholders/800x560.svg',
  },
  {
    id: 4,
    category: 'storm' as Category,
    title: 'Wind Damage — Partial Replacement',
    location: 'Boonville, IN',
    date: 'February 2026',
    claimAmount: '$8,750',
    description: 'Straight-line winds at 62 mph lifted and cracked ridge cap and tore off 18 shingles. Adjuster missed the flashing damage — we caught it and got it included.',
    tag: 'Insurance Claim',
    tagColor: 'bg-red-500',
    stats: [
      { label: 'Damage Area', value: '8 Squares' },
      { label: 'Material', value: 'Arch. Shingles' },
      { label: 'Duration', value: '1 Day' },
      { label: 'Claim', value: '$8,750' },
    ],
    before: '/placeholders/800x560.svg',
    after: '/placeholders/800x560.svg',
  },
  {
    id: 5,
    category: 'commercial' as Category,
    title: 'Commercial Flat Roof — TPO',
    location: 'Evansville, IN',
    date: 'January 2026',
    claimAmount: null,
    description: 'Complete replacement of a failing EPDM flat roof on a 12,000 sq ft warehouse. Upgraded to a white TPO membrane system with improved drainage and 20-year warranty.',
    tag: 'Commercial',
    tagColor: 'bg-amber-600',
    stats: [
      { label: 'Roof Size', value: '12,000 sq ft' },
      { label: 'Material', value: 'TPO Membrane' },
      { label: 'Duration', value: '5 Days' },
      { label: 'Warranty', value: '20 Years' },
    ],
    before: '/placeholders/800x560.svg',
    after: '/placeholders/800x560.svg',
  },
  {
    id: 6,
    category: 'storm' as Category,
    title: 'Golf Ball Hail — Full Exterior',
    location: 'Owensboro, KY',
    date: 'December 2025',
    claimAmount: '$19,600',
    description: 'Golf ball-sized hail caused catastrophic damage to roof, gutters, siding, and two skylights. Full exterior replacement approved after supplement filing.',
    tag: 'Full Exterior',
    tagColor: 'bg-red-600',
    stats: [
      { label: 'Roof Size', value: '36 Squares' },
      { label: 'Material', value: 'Arch. Shingles' },
      { label: 'Duration', value: '3 Days' },
      { label: 'Claim', value: '$19,600' },
    ],
    before: '/placeholders/800x560.svg',
    after: '/placeholders/800x560.svg',
  },
  {
    id: 7,
    category: 'residential' as Category,
    title: 'Historic Home Restoration',
    location: 'Evansville, IN',
    date: 'November 2025',
    claimAmount: null,
    description: 'Careful restoration of a 1920s craftsman home in the Haynie\'s Corner district. Matched original profile with premium architectural shingles and restored all original copper flashing.',
    tag: 'Historic Restoration',
    tagColor: 'bg-amber-700',
    stats: [
      { label: 'Roof Size', value: '18 Squares' },
      { label: 'Material', value: 'Premium Shingles' },
      { label: 'Duration', value: '3 Days' },
      { label: 'Warranty', value: '30 Years' },
    ],
    before: '/placeholders/800x560.svg',
    after: '/placeholders/800x560.svg',
  },
  {
    id: 8,
    category: 'metal' as Category,
    title: 'Barn & Agricultural Metal Roof',
    location: 'Mount Vernon, IN',
    date: 'October 2025',
    claimAmount: null,
    description: 'Large agricultural barn with a failing corrugated metal roof. Replaced with a new standing seam system in barn red. Completed in 4 days with zero disruption to livestock operations.',
    tag: 'Agricultural',
    tagColor: 'bg-red-800',
    stats: [
      { label: 'Roof Size', value: '48 Squares' },
      { label: 'Material', value: 'Standing Seam' },
      { label: 'Duration', value: '4 Days' },
      { label: 'Lifespan', value: '50+ Years' },
    ],
    before: '/placeholders/800x560.svg',
    after: '/placeholders/800x560.svg',
  },
  {
    id: 9,
    category: 'residential' as Category,
    title: 'New Construction — Luxury Home',
    location: 'Newburgh, IN',
    date: 'September 2025',
    claimAmount: null,
    description: 'New construction installation on a 4,200 sq ft luxury home. Designer shingles in slate gray with copper valleys, custom ridge cap, and full ice and water shield underlayment.',
    tag: 'New Construction',
    tagColor: 'bg-orange',
    stats: [
      { label: 'Roof Size', value: '42 Squares' },
      { label: 'Material', value: 'Designer Shingles' },
      { label: 'Duration', value: '2 Days' },
      { label: 'Warranty', value: '50 Years' },
    ],
    before: '/placeholders/800x560.svg',
    after: '/placeholders/800x560.svg',
  },
];

const filterTabs: { key: Category; label: string; icon: string }[] = [
  { key: 'all', label: 'All Projects', icon: 'ri-grid-line' },
  { key: 'residential', label: 'Residential', icon: 'ri-home-4-line' },
  { key: 'storm', label: 'Storm Damage', icon: 'ri-thunderstorms-line' },
  { key: 'metal', label: 'Metal Roofing', icon: 'ri-shield-check-line' },
  { key: 'commercial', label: 'Commercial', icon: 'ri-building-4-line' },
];

function SliderCard({ project, index }: { project: typeof projects[0]; index: number }) {
  const [sliderPos, setSliderPos] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const anim = useScrollAnimation({ threshold: 0.08 });

  const updateSlider = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const pos = Math.min(100, Math.max(0, ((clientX - rect.left) / rect.width) * 100));
    setSliderPos(pos);
  }, []);

  useEffect(() => {
    if (!isDragging) return;
    const onMove = (e: MouseEvent) => updateSlider(e.clientX);
    const onUp = () => setIsDragging(false);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
  }, [isDragging, updateSlider]);

  return (
    <>
      <div
        ref={anim.ref as React.RefObject<HTMLDivElement>}
        className={`anim-fade-up ${anim.isVisible ? 'is-visible' : ''} group bg-charcoal-mid border border-white/5 hover:border-orange/20 transition-all duration-300 overflow-hidden`}
        style={{ transitionDelay: `${(index % 3) * 100}ms` }}
      >
      {/* Slider */}
      <div
        ref={containerRef}
        className="relative h-64 md:h-72 overflow-hidden cursor-col-resize select-none"
        onMouseDown={(e) => { e.preventDefault(); setIsDragging(true); updateSlider(e.clientX); }}
        onTouchMove={(e) => updateSlider(e.touches[0].clientX)}
        onTouchStart={(e) => updateSlider(e.touches[0].clientX)}
      >
        {/* After (full width behind) */}
        <img
          src={project.after}
          alt={`After — ${project.title}`}
          className="absolute inset-0 w-full h-full object-cover object-top"
        />
        {/* Before (clipped) */}
        <div className="absolute inset-0 overflow-hidden" style={{ width: `${sliderPos}%` }}>
          <img
            src={project.before}
            alt={`Before — ${project.title}`}
            className="absolute inset-0 h-full object-cover object-top"
            style={{ width: `${10000 / sliderPos}%`, maxWidth: 'none' }}
          />
        </div>
        {/* Divider line */}
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-white z-10 pointer-events-none"
          style={{ left: `${sliderPos}%`, transform: 'translateX(-50%)' }}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-9 h-9 bg-white rounded-full flex items-center justify-center">
            <i className="ri-arrow-left-right-line text-charcoal-deep text-sm" />
          </div>
        </div>
        {/* Labels */}
        <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-sm text-white text-xs font-bold px-2.5 py-1 uppercase tracking-wider pointer-events-none">
          Before
        </div>
        <div className="absolute top-3 right-3 bg-orange/90 text-white text-xs font-bold px-2.5 py-1 uppercase tracking-wider pointer-events-none">
          After
        </div>
        {/* Tag */}
        <div className={`absolute bottom-3 left-3 text-white text-xs font-bold px-2.5 py-1 uppercase tracking-wider pointer-events-none ${project.tagColor}`}>
          {project.tag}
        </div>
        {/* Drag hint */}
        <div className="absolute bottom-3 right-3 text-white/50 text-xs flex items-center gap-1 pointer-events-none">
          <i className="ri-drag-move-line text-sm" />
          Drag
        </div>
      </div>

      {/* Card content */}
      <div className="p-5 md:p-6">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div>
            <p className="text-white/30 text-xs uppercase tracking-wider mb-1">{project.location} &bull; {project.date}</p>
            <h3 className="font-display text-white text-lg md:text-xl uppercase tracking-wide leading-snug">{project.title}</h3>
          </div>
          {project.claimAmount && (
            <div className="text-right flex-shrink-0">
              <p className="text-white/30 text-xs uppercase tracking-wider">Claim Recovered</p>
              <p className="font-display text-orange text-lg">{project.claimAmount}</p>
            </div>
          )}
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-4 gap-2 mb-4">
          {project.stats.map((s) => (
            <div key={s.label} className="bg-white/5 px-2 py-2 text-center">
              <p className="text-orange text-xs font-bold">{s.value}</p>
              <p className="text-white/30 text-xs mt-0.5 leading-tight">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between gap-3">
          {/* Description toggle */}
          <button
            onClick={() => setExpanded(!expanded)}
            className="flex-1 text-left cursor-pointer group/desc"
          >
            <div className={`overflow-hidden transition-all duration-300 ${expanded ? 'max-h-24' : 'max-h-0'}`}>
              <p className="text-white/40 text-sm leading-relaxed pb-3">{project.description}</p>
            </div>
            <div className="flex items-center gap-1.5 text-white/30 hover:text-orange text-xs uppercase tracking-wider transition-colors">
              <i className={`${expanded ? 'ri-arrow-up-s-line' : 'ri-arrow-down-s-line'} text-sm`} />
              {expanded ? 'Less' : 'Project Details'}
            </div>
          </button>

          {/* Share button */}
          <button
            onClick={() => setShowShare(true)}
            className="flex-shrink-0 flex items-center gap-1.5 text-white/30 hover:text-orange text-xs uppercase tracking-wider transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-share-forward-line text-sm" />
            Share
          </button>
        </div>
      </div>
    </div>

      {showShare && (
        <SocialShareCard
          title={project.title}
          subtitle={project.description}
          type={project.tag}
          location={project.location}
          year={project.date}
          image={project.after}
          badge={project.tag}
          stats={project.stats}
          description={project.description}
          onClose={() => setShowShare(false)}
        />
      )}
    </>
  );
}

export default function BeforeAfterPage() {
  const navigate = useNavigate();
  const [activeFilter, setActiveFilter] = useState<Category>('all');
  const heroAnim = useScrollAnimation();
  const statsAnim = useScrollAnimation({ threshold: 0.1 });

  const filtered = activeFilter === 'all' ? projects : projects.filter((p) => p.category === activeFilter);

  const totalClaims = projects.filter((p) => p.claimAmount).reduce((acc, p) => {
    const val = parseFloat((p.claimAmount ?? '0').replace(/[$,]/g, ''));
    return acc + val;
  }, 0);

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Before & After Roofing Photos Evansville Indiana | Corner Stone Construction"
        description="See real before and after roofing transformations from Corner Stone Construction & Roofing in Evansville Indiana. Residential replacements, storm damage restorations, metal roofing, and commercial projects across the Tri-State area. Drag the slider to compare."
        keywords="before after roofing Evansville Indiana, roof replacement photos Indiana, roofing transformation gallery, storm damage before after Indiana, metal roofing before after Evansville, roofing portfolio Tri-State"
        canonical="/before-after"
        schema={beforeAfterSchema}
      />

      {/* Hero */}
      <section className="relative min-h-[62vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1600x900.svg"
            alt="Before and after roofing transformations — Corner Stone Evansville Indiana"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/65 via-black/55 to-charcoal-deep" />
        </div>
        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 text-center anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs md:text-sm font-semibold tracking-[0.25em] uppercase mb-5">
            Real Projects. Real Results.
          </p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 8vw, 7rem)' }}>
            Before<br />&amp; <span className="text-orange">After</span>
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-2xl mx-auto leading-relaxed mb-10">
            Drag the slider on any project to see the transformation. Every photo is a real job we completed across Evansville, Henderson, and the Tri-State area.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigate('/estimate')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              Get a Free Estimate
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/30 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="bg-charcoal border-y border-white/10 py-10 md:py-12 px-6 md:px-10 lg:px-16">
        <div
          ref={statsAnim.ref as React.RefObject<HTMLDivElement>}
          className={`grid grid-cols-2 lg:grid-cols-4 gap-8 text-center anim-fade-up ${statsAnim.isVisible ? 'is-visible' : ''}`}
        >
          {[
            { value: `${projects.length}`, label: 'Projects Shown', sub: 'All real Tri-State jobs' },
            { value: '$2.4M+', label: 'Total Recovered', sub: 'For insurance clients' },
            { value: '94%', label: 'Claims Approved', sub: 'First submission' },
            { value: '1 Day', label: 'Avg. Residential', sub: 'Most jobs done in a day' },
          ].map((stat, i) => (
            <div
              key={stat.label}
              className={`anim-fade-up ${statsAnim.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <p className="font-display text-orange text-4xl md:text-5xl uppercase tracking-wider mb-1">{stat.value}</p>
              <p className="text-white text-xs font-semibold uppercase tracking-wider mb-0.5">{stat.label}</p>
              <p className="text-white/30 text-xs">{stat.sub}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Filter + Grid */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        {/* Filter tabs */}
        <div className="flex flex-wrap gap-2 mb-12 md:mb-16">
          {filterTabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveFilter(tab.key)}
              className={`inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold uppercase tracking-wide transition-all duration-200 whitespace-nowrap cursor-pointer ${
                activeFilter === tab.key
                  ? 'bg-orange text-white'
                  : 'border border-white/20 text-white/40 hover:border-orange hover:text-orange'
              }`}
            >
              <i className={tab.icon} />
              {tab.label}
              {tab.key === 'all' && (
                <span className={`text-xs px-1.5 py-0.5 ${activeFilter === 'all' ? 'bg-white/20 text-white' : 'bg-white/10 text-white/30'}`}>
                  {projects.length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {filtered.map((project, i) => (
            <SliderCard key={project.id} project={project} index={i} />
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20">
            <i className="ri-image-2-line text-white/20 text-5xl mb-4 block" />
            <p className="text-white/30 text-sm">No projects in this category yet.</p>
          </div>
        )}
      </section>

      {/* How We Work section */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-center">
          <div>
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Our Standard</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              Every Job Gets<br />The Same Care
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
              Whether it is a $3,000 repair or a $20,000 full replacement, our crew shows up the same way every time — on time, fully equipped, and ready to do it right. We do not cut corners on materials, labor, or cleanup.
            </p>
            <div className="space-y-4 mb-10">
              {[
                { icon: 'ri-shield-check-line', title: 'Premium Materials Only', desc: 'GAF, Owens Corning, CertainTeed, and Atlas — manufacturer-certified installs with enhanced warranties.' },
                { icon: 'ri-delete-bin-line', title: 'Daily Cleanup Guaranteed', desc: 'We run a magnet over your yard every evening. You will not find a single nail after we leave.' },
                { icon: 'ri-camera-line', title: 'Photo Documentation', desc: 'Every job is photographed before, during, and after. You get a full report for your records.' },
                { icon: 'ri-award-line', title: 'Workmanship Warranty', desc: 'Every installation is backed by our workmanship warranty — up to lifetime on qualifying projects.' },
              ].map((item) => (
                <div key={item.title} className="flex items-start gap-4">
                  <div className="w-9 h-9 flex items-center justify-center bg-orange/20 text-orange flex-shrink-0 mt-0.5">
                    <i className={`${item.icon} text-sm`} />
                  </div>
                  <div>
                    <p className="text-white text-sm font-semibold mb-0.5">{item.title}</p>
                    <p className="text-white/40 text-xs leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
            <button
              onClick={() => navigate('/estimate')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-3"
            >
              Start Your Project
              <i className="ri-arrow-right-line" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {[
              { src: '/placeholders/400x300.svg', alt: 'Crew installing shingles' },
              { src: '/placeholders/400x300.svg', alt: 'Shingle detail' },
              { src: '/placeholders/400x300.svg', alt: 'Job site cleanup' },
              { src: '/placeholders/400x300.svg', alt: 'Happy homeowner' },
            ].map((img, i) => (
              <div key={i} className="relative overflow-hidden aspect-[4/3]">
                <img
                  src={img.src}
                  alt={img.alt}
                  className="w-full h-full object-cover object-top hover:scale-105 transition-transform duration-500"
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="bg-charcoal-mid border border-white/5 p-10 md:p-16 lg:p-20 text-center">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Your Home Could Be Next</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Ready for Your<br /><span className="text-orange">Transformation?</span>
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-lg mx-auto leading-relaxed mb-10">
            Free inspections, honest quotes, and the same quality you see in every photo above. Let's get started.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigate('/estimate')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              Get a Free Estimate
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/20 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
