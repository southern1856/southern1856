import { useState, useRef, useEffect, useCallback } from 'react';

export type GalleryFilter = 'all' | 'hail' | 'wind' | 'water';

export interface GalleryItem {
  id: number;
  category: GalleryFilter;
  location: string;
  stormDate: string;
  damageType: string;
  claimAmount: string;
  description: string;
  beforeImg: string;
  afterImg: string;
  tag: string;
  tagColor: string;
}

export const galleryItems: GalleryItem[] = [
  {
    id: 1,
    category: 'hail',
    location: 'Evansville, IN',
    stormDate: 'April 2026',
    damageType: 'Hail Damage',
    claimAmount: '$14,200',
    description: 'Quarter-sized hail stripped granules across entire south-facing slope. Insurance initially offered $6,800 — we supplemented to full replacement.',
    beforeImg: '/placeholders/600x400.svg',
    afterImg: '/placeholders/600x400.svg',
    tag: 'Full Replacement',
    tagColor: 'bg-red-500',
  },
  {
    id: 2,
    category: 'wind',
    location: 'Henderson, KY',
    stormDate: 'March 2026',
    damageType: 'Wind Damage',
    claimAmount: '$8,750',
    description: 'Straight-line winds at 62 mph lifted and cracked ridge cap and tore off 18 shingles. Adjuster missed the flashing damage — we caught it.',
    beforeImg: '/placeholders/600x400.svg',
    afterImg: '/placeholders/600x400.svg',
    tag: 'Partial Replacement',
    tagColor: 'bg-amber-500',
  },
  {
    id: 3,
    category: 'water',
    location: 'Owensboro, KY',
    stormDate: 'March 2026',
    damageType: 'Water Intrusion',
    claimAmount: '$11,400',
    description: 'Ice dam caused water to back up under shingles and saturate decking. Ceiling damage in two rooms. Full decking replacement required.',
    beforeImg: '/placeholders/600x400.svg',
    afterImg: '/placeholders/600x400.svg',
    tag: 'Deck + Interior',
    tagColor: 'bg-orange',
  },
  {
    id: 4,
    category: 'hail',
    location: 'Boonville, IN',
    stormDate: 'February 2026',
    damageType: 'Hail + Wind',
    claimAmount: '$19,600',
    description: 'Golf ball-sized hail caused catastrophic damage to roof, gutters, siding, and two skylights. Full exterior replacement approved after supplement.',
    beforeImg: '/placeholders/600x400.svg',
    afterImg: '/placeholders/600x400.svg',
    tag: 'Full Exterior',
    tagColor: 'bg-red-500',
  },
  {
    id: 5,
    category: 'wind',
    location: 'Newburgh, IN',
    stormDate: 'February 2026',
    damageType: 'Wind + Debris',
    claimAmount: '$6,300',
    description: 'Large tree limb punctured decking and cracked three rafters. Emergency tarp deployed same day. Full structural repair completed in 4 days.',
    beforeImg: '/placeholders/600x400.svg',
    afterImg: '/placeholders/600x400.svg',
    tag: 'Structural Repair',
    tagColor: 'bg-amber-500',
  },
  {
    id: 6,
    category: 'hail',
    location: 'Mt. Vernon, IN',
    stormDate: 'January 2026',
    damageType: 'Hail Damage',
    claimAmount: '$9,100',
    description: 'Nickel-sized hail damaged 60% of roof surface. Insurance denied claim citing "cosmetic damage" — we appealed with proper documentation and won.',
    beforeImg: '/placeholders/600x400.svg',
    afterImg: '/placeholders/600x400.svg',
    tag: 'Denied → Approved',
    tagColor: 'bg-green-600',
  },
];

export default function GalleryCard({ item }: { item: GalleryItem }) {
  const [sliderPos, setSliderPos] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const updateSlider = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const pos = Math.min(100, Math.max(0, ((clientX - rect.left) / rect.width) * 100));
    setSliderPos(pos);
  }, []);

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  useEffect(() => {
    if (!isDragging) return;
    const onMove = (e: MouseEvent) => updateSlider(e.clientX);
    const onUp = () => setIsDragging(false);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
  }, [isDragging, updateSlider]);

  const handleTouchMove = (e: React.TouchEvent) => {
    updateSlider(e.touches[0].clientX);
  };

  return (
    <div className="group bg-white border border-stone-200 hover:border-orange/30 transition-colors duration-300 overflow-hidden">
      {/* Before/After Slider */}
      <div
        ref={containerRef}
        className="relative h-52 overflow-hidden cursor-col-resize select-none"
        onMouseDown={handleMouseDown}
        onTouchMove={handleTouchMove}
        onTouchStart={(e) => updateSlider(e.touches[0].clientX)}
      >
        {/* After image (full width, behind) */}
        <img
          src={item.afterImg}
          alt={`After repair - ${item.damageType}`}
          className="absolute inset-0 w-full h-full object-cover object-top"
        />
        {/* Before image (clipped) */}
        <div
          className="absolute inset-0 overflow-hidden"
          style={{ width: `${sliderPos}%` }}
        >
          <img
            src={item.beforeImg}
            alt={`Before repair - ${item.damageType}`}
            className="absolute inset-0 w-full h-full object-cover object-top"
            style={{ width: `${10000 / sliderPos}%`, maxWidth: 'none' }}
          />
        </div>
        {/* Slider handle */}
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-white z-10"
          style={{ left: `${sliderPos}%`, transform: 'translateX(-50%)' }}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full flex items-center justify-center">
            <i className="ri-arrow-left-right-line text-charcoal text-sm" />
          </div>
        </div>
        {/* Labels */}
        <div className="absolute top-3 left-3 bg-black/60 text-white text-xs font-semibold px-2 py-1 uppercase tracking-wide pointer-events-none">
          Before
        </div>
        <div className="absolute top-3 right-3 bg-orange/90 text-white text-xs font-semibold px-2 py-1 uppercase tracking-wide pointer-events-none">
          After
        </div>
        {/* Damage tag */}
        <div className={`absolute bottom-3 left-3 ${item.tagColor} text-white text-xs font-semibold px-2.5 py-1 uppercase tracking-wide pointer-events-none`}>
          {item.tag}
        </div>
      </div>

      {/* Card content */}
      <div className="p-5">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div>
            <p className="text-stone-400 text-xs uppercase tracking-wide mb-0.5">{item.location} &bull; {item.stormDate}</p>
            <h3 className="font-display text-sm text-charcoal uppercase tracking-wide">{item.damageType}</h3>
          </div>
          <div className="text-right flex-shrink-0">
            <p className="text-stone-400 text-xs uppercase tracking-wide">Claim Recovered</p>
            <p className="font-display text-base text-orange">{item.claimAmount}</p>
          </div>
        </div>
        <p className="text-stone-500 text-xs leading-relaxed">{item.description}</p>
      </div>
    </div>
  );
}