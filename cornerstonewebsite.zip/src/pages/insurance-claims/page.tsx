import { useState, useEffect, useRef, useCallback } from 'react';
import PageSEO from '@/components/feature/PageSEO';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { OFFERS } from '@/mocks/promotions';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const insuranceClaimsSchema = [
  {
    '@context': 'https://schema.org',
    '@type': 'Service',
    name: 'Storm Damage Insurance Claims Assistance',
    description: 'Corner Stone Construction & Roofing helps Evansville Indiana homeowners navigate insurance claims for hail, wind, and storm damage. Free inspections, adjuster meetings, and supplement filing.',
    provider: {
      '@type': 'RoofingContractor',
      name: 'Corner Stone Construction & Roofing',
      telephone: '+1-812-213-5997',
    },
    areaServed: [
      { '@type': 'City', name: 'Evansville' },
      { '@type': 'City', name: 'Newburgh' },
      { '@type': 'City', name: 'Henderson' },
    ],
    offers: {
      '@type': 'Offer',
      price: '0',
      priceCurrency: 'USD',
      description: 'Free storm damage inspection and insurance claim assistance',
    },
  },
  {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: [
      {
        '@type': 'Question',
        name: 'Will my insurance rates go up if I file a storm damage claim?',
        acceptedAnswer: { '@type': 'Answer', text: 'In most cases, no. Storm damage claims are considered Acts of God and are treated differently than at-fault claims. Your rates are typically based on regional storm activity, not individual claims.' },
      },
      {
        '@type': 'Question',
        name: 'How long do I have to file a storm damage claim in Indiana?',
        acceptedAnswer: { '@type': 'Answer', text: 'Most policies give you 1 year from the date of loss. We recommend acting within 6 months. The sooner you file, the easier it is to prove the damage was storm-related.' },
      },
      {
        '@type': 'Question',
        name: 'What if my insurance company denies my storm damage claim?',
        acceptedAnswer: { '@type': 'Answer', text: 'We help you appeal. Often denials happen because damage was not properly documented. We re-inspect, take new photos, and work with your adjuster to get a fair second look.' },
      },
    ],
  },
];

const steps = [
  {
    num: '01',
    title: 'Free Storm Damage Inspection',
    desc: 'We inspect your roof, siding, gutters, and exterior for hail, wind, or debris damage. We document everything with photos and detailed notes.',
    icon: 'ri-search-line',
  },
  {
    num: '02',
    title: 'We Meet Your Adjuster',
    desc: 'Our team meets with your insurance adjuster on-site to ensure every damaged area is identified and included in your claim. We speak their language.',
    icon: 'ri-shield-check-line',
  },
  {
    num: '03',
    title: 'Claim Approval & Estimate',
    desc: 'Once approved, we provide a detailed scope of work and transparent pricing. No surprises, no hidden fees — just honest numbers.',
    icon: 'ri-file-list-3-line',
  },
  {
    num: '04',
    title: 'Quality Repair or Replacement',
    desc: 'Our certified crew completes the work on schedule with premium materials. We handle permits, cleanup, and final inspection.',
    icon: 'ri-hammer-line',
  },
];

const benefits = [
  {
    title: 'We Work With ALL Insurance Companies',
    desc: 'State Farm, Allstate, Farmers, Liberty Mutual, USAA — we have experience with every major carrier in Indiana and Kentucky.',
    icon: 'ri-building-4-line',
  },
  {
    title: 'No Out-of-Pocket for Covered Damage',
    desc: 'If your claim is approved, you typically only pay your deductible. We help you understand exactly what your policy covers.',
    icon: 'ri-wallet-3-line',
  },
  {
    title: 'Adjuster Meeting Included',
    desc: 'Most roofers skip this step. We show up when your adjuster does to make sure nothing gets missed or underpaid.',
    icon: 'ri-user-follow-line',
  },
  {
    title: 'Supplementing Expertise',
    desc: 'If the initial estimate is too low, we file supplements with proper documentation to get you the full amount you are owed.',
    icon: 'ri-funds-line',
  },
  {
    title: 'Emergency Tarping Available',
    desc: 'Storms do not wait. We offer 24/7 emergency tarping and temporary repairs to prevent further interior damage.',
    icon: 'ri-flashlight-line',
  },
  {
    title: 'Lifetime Workmanship Warranty',
    desc: 'Every insurance claim job is backed by our lifetime workmanship warranty. We stand behind our work long after the check clears.',
    icon: 'ri-award-line',
  },
];

const recentStorms = [
  {
    date: 'April 2, 2026',
    daysAgo: 25,
    location: 'Evansville, IN',
    counties: ['Vanderburgh', 'Warrick'],
    type: 'Hail + High Winds',
    hailSize: '1.75"',
    windSpeed: '62 mph',
    severity: 'severe',
    claimsHandled: 34,
    zipCodes: ['47710', '47711', '47712', '47714', '47715'],
  },
  {
    date: 'March 18, 2026',
    daysAgo: 40,
    location: 'Henderson, KY',
    counties: ['Henderson', 'Webster'],
    type: 'Hail Storm',
    hailSize: '1.25"',
    windSpeed: '45 mph',
    severity: 'moderate',
    claimsHandled: 19,
    zipCodes: ['42420', '42431', '42441'],
  },
  {
    date: 'March 5, 2026',
    daysAgo: 53,
    location: 'Owensboro, KY',
    counties: ['Daviess', 'Ohio'],
    type: 'Straight-Line Winds',
    hailSize: 'N/A',
    windSpeed: '78 mph',
    severity: 'severe',
    claimsHandled: 27,
    zipCodes: ['42301', '42303', '42320'],
  },
  {
    date: 'February 21, 2026',
    daysAgo: 65,
    location: 'Boonville, IN',
    counties: ['Warrick', 'Spencer'],
    type: 'Hail + Tornado Warning',
    hailSize: '2.0"',
    windSpeed: '55 mph',
    severity: 'critical',
    claimsHandled: 41,
    zipCodes: ['47601', '47610', '47619'],
  },
  {
    date: 'February 8, 2026',
    daysAgo: 78,
    location: 'Newburgh, IN',
    counties: ['Warrick'],
    type: 'Ice Storm + Wind',
    hailSize: 'N/A',
    windSpeed: '50 mph',
    severity: 'moderate',
    claimsHandled: 15,
    zipCodes: ['47630', '47629'],
  },
  {
    date: 'January 14, 2026',
    daysAgo: 103,
    location: 'Mt. Vernon, IN',
    counties: ['Posey'],
    type: 'Hail Storm',
    hailSize: '1.0"',
    windSpeed: '38 mph',
    severity: 'moderate',
    claimsHandled: 11,
    zipCodes: ['47620', '47633'],
  },
];

const severityConfig = {
  critical: { label: 'Critical', bg: 'bg-red-500/15', text: 'text-red-500', border: 'border-red-500/30', dot: 'bg-red-500' },
  severe: { label: 'Severe', bg: 'bg-orange/15', text: 'text-orange', border: 'border-orange/30', dot: 'bg-orange' },
  moderate: { label: 'Moderate', bg: 'bg-amber-500/15', text: 'text-amber-600', border: 'border-amber-500/30', dot: 'bg-amber-500' },
};

const stormSigns = [
  'Dents or bruising on shingles',
  'Granules collecting in gutters',
  'Missing, cracked, or curled shingles',
  'Water stains on ceilings or walls',
  'Dented gutters, vents, or flashing',
  'Loose or exposed nail heads',
];

const checklistSections = [
  {
    title: 'Immediate Safety (First 24 Hours)',
    icon: 'ri-alarm-warning-line',
    items: [
      'Ensure all family members are safe and accounted for',
      'Stay away from downed power lines or electrical hazards',
      'Do NOT walk on a damaged roof — call a professional',
      'Move valuables away from active leaks',
      'Place buckets under drips to prevent interior damage',
    ],
  },
  {
    title: 'Document the Damage',
    icon: 'ri-camera-line',
    items: [
      'Photograph all visible exterior damage from ground level',
      'Take wide shots and close-ups of affected areas',
      'Document dented gutters, vents, AC units, and skylights',
      'Photograph interior water stains, ceiling damage, wet insulation',
      'Note the date and time on all photos if possible',
      'Video walkthrough of entire property exterior',
    ],
  },
  {
    title: 'Contact Your Insurance Company',
    icon: 'ri-phone-line',
    items: [
      'Call your insurance company within 48 hours of the storm',
      'Get a claim number and write it down',
      'Ask for the name of your assigned adjuster',
      'Request the adjuster inspection date in writing',
      'Do NOT accept a settlement before a contractor reviews it',
    ],
  },
  {
    title: 'Before the Adjuster Arrives',
    icon: 'ri-user-follow-line',
    items: [
      'Call Corner Stone to schedule a free inspection BEFORE the adjuster',
      'Have your policy number and claim number ready',
      'Gather any previous repair receipts or roof documentation',
      'Do NOT make permanent repairs before the adjuster visit',
      'Emergency tarping is OK — document it with photos and receipts',
    ],
  },
  {
    title: 'During the Adjuster Inspection',
    icon: 'ri-search-line',
    items: [
      'Have your roofing contractor present at the adjuster meeting',
      'Point out every area of damage — do not assume they will find it',
      'Ask the adjuster to explain every line item in their estimate',
      'Do not sign anything on the spot — review with your contractor first',
      'Request a copy of the adjuster\'s report before they leave',
    ],
  },
  {
    title: 'After Claim Approval',
    icon: 'ri-file-check-line',
    items: [
      'Review the settlement amount with your contractor',
      'If the estimate is too low, ask your contractor to file a supplement',
      'Understand your deductible and how it applies',
      'Get a written contract before any work begins',
      'Keep all receipts and documentation for your records',
    ],
  },
];

type GalleryFilter = 'all' | 'hail' | 'wind' | 'water';

const galleryItems = [
  {
    id: 1,
    category: 'hail' as GalleryFilter,
    location: 'Evansville, IN',
    stormDate: 'April 2026',
    damageType: 'Hail Damage',
    claimAmount: '$14,200',
    description: 'Quarter-sized hail stripped granules across entire south-facing slope. Insurance initially offered $6,800 — we supplemented to full replacement.',
    beforeImg: '/placeholders/600x400.svg',
    afterImg: '/placeholders/600x400.svg',
    tag: 'Full Replacement',
    tagColor: 'bg-red-500',
  },
  {
    id: 2,
    category: 'wind' as GalleryFilter,
    location: 'Henderson, KY',
    stormDate: 'March 2026',
    damageType: 'Wind Damage',
    claimAmount: '$8,750',
    description: 'Straight-line winds at 62 mph lifted and cracked ridge cap and tore off 18 shingles. Adjuster missed the flashing damage — we caught it.',
    beforeImg: '/placeholders/600x400.svg',
    afterImg: '/placeholders/600x400.svg',
    tag: 'Partial Replacement',
    tagColor: 'bg-amber-500',
  },
  {
    id: 3,
    category: 'water' as GalleryFilter,
    location: 'Owensboro, KY',
    stormDate: 'March 2026',
    damageType: 'Water Intrusion',
    claimAmount: '$11,400',
    description: 'Ice dam caused water to back up under shingles and saturate decking. Ceiling damage in two rooms. Full decking replacement required.',
    beforeImg: '/placeholders/600x400.svg',
    afterImg: '/placeholders/600x400.svg',
    tag: 'Deck + Interior',
    tagColor: 'bg-orange',
  },
  {
    id: 4,
    category: 'hail' as GalleryFilter,
    location: 'Boonville, IN',
    stormDate: 'February 2026',
    damageType: 'Hail + Wind',
    claimAmount: '$19,600',
    description: 'Golf ball-sized hail caused catastrophic damage to roof, gutters, siding, and two skylights. Full exterior replacement approved after supplement.',
    beforeImg: '/placeholders/600x400.svg',
    afterImg: '/placeholders/600x400.svg',
    tag: 'Full Exterior',
    tagColor: 'bg-red-500',
  },
  {
    id: 5,
    category: 'wind' as GalleryFilter,
    location: 'Newburgh, IN',
    stormDate: 'February 2026',
    damageType: 'Wind + Debris',
    claimAmount: '$6,300',
    description: 'Large tree limb punctured decking and cracked three rafters. Emergency tarp deployed same day. Full structural repair completed in 4 days.',
    beforeImg: '/placeholders/600x400.svg',
    afterImg: '/placeholders/600x400.svg',
    tag: 'Structural Repair',
    tagColor: 'bg-amber-500',
  },
  {
    id: 6,
    category: 'hail' as GalleryFilter,
    location: 'Mt. Vernon, IN',
    stormDate: 'January 2026',
    damageType: 'Hail Damage',
    claimAmount: '$9,100',
    description: 'Nickel-sized hail damaged 60% of roof surface. Insurance denied claim citing "cosmetic damage" — we appealed with proper documentation and won.',
    beforeImg: '/placeholders/600x400.svg',
    afterImg: '/placeholders/600x400.svg',
    tag: 'Denied → Approved',
    tagColor: 'bg-green-600',
  },
];

function ClaimTimelineCalculator() {
  const [stormDate, setStormDate] = useState('');
  const [result, setResult] = useState<null | {
    daysElapsed: number;
    daysRemaining: number;
    deadlineDate: string;
    urgencyLevel: 'safe' | 'warning' | 'critical' | 'expired';
    progressPct: number;
  }>(null);

  const today = new Date();
  const maxDateStr = today.toISOString().split('T')[0];
  // earliest storm date we allow: 12 months ago
  const minDate = new Date(today);
  minDate.setFullYear(minDate.getFullYear() - 1);
  const minDateStr = minDate.toISOString().split('T')[0];

  const calculate = () => {
    if (!stormDate) return;
    const storm = new Date(stormDate);
    const deadline = new Date(storm);
    deadline.setFullYear(deadline.getFullYear() + 1);
    const totalWindow = 365;
    const elapsed = Math.floor((today.getTime() - storm.getTime()) / (1000 * 60 * 60 * 24));
    const remaining = Math.max(0, totalWindow - elapsed);
    const progressPct = Math.min(100, (elapsed / totalWindow) * 100);
    let urgencyLevel: 'safe' | 'warning' | 'critical' | 'expired';
    if (remaining === 0) urgencyLevel = 'expired';
    else if (remaining <= 60) urgencyLevel = 'critical';
    else if (remaining <= 120) urgencyLevel = 'warning';
    else urgencyLevel = 'safe';
    const deadlineDate = deadline.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    setResult({ daysElapsed: elapsed, daysRemaining: remaining, deadlineDate, urgencyLevel, progressPct });
  };

  const urgencyConfig = {
    safe: {
      bar: 'bg-green-500',
      badge: 'bg-green-50 border-green-200 text-green-700',
      icon: 'ri-checkbox-circle-line',
      headline: 'You Have Plenty of Time',
      sub: 'Your claim window is still wide open — but don\'t wait too long. Storm evidence fades and adjusters get busier as the deadline approaches.',
      cta: 'Schedule Your Free Inspection',
      ctaStyle: 'bg-orange hover:bg-orange-dark text-white',
      glow: 'border-green-200',
    },
    warning: {
      bar: 'bg-amber-500',
      badge: 'bg-amber-50 border-amber-200 text-amber-700',
      icon: 'ri-alarm-warning-line',
      headline: 'Time Is Running Short',
      sub: 'You have less than 4 months left. Insurance companies get harder to work with as deadlines approach. Start your claim now while you still have leverage.',
      cta: 'Start My Claim Before It\'s Too Late',
      ctaStyle: 'bg-amber-600 hover:bg-amber-700 text-white',
      glow: 'border-amber-200',
    },
    critical: {
      bar: 'bg-red-500',
      badge: 'bg-red-50 border-red-200 text-red-600',
      icon: 'ri-error-warning-line',
      headline: 'URGENT: Less Than 60 Days Left',
      sub: 'Your claim window is almost closed. Every day you wait makes it harder to get approved. Call us today — we can fast-track your inspection and submission.',
      cta: 'Call Now — Don\'t Miss Your Deadline',
      ctaStyle: 'bg-red-600 hover:bg-red-700 text-white',
      glow: 'border-red-300',
    },
    expired: {
      bar: 'bg-stone-400',
      badge: 'bg-stone-100 border-stone-300 text-stone-600',
      icon: 'ri-close-circle-line',
      headline: 'Standard Window Has Closed',
      sub: 'Your 12-month standard filing window has passed. However, some policies have exceptions — call us for a free consultation. We may still be able to help.',
      cta: 'Talk to a Claims Specialist',
      ctaStyle: 'bg-charcoal-deep hover:bg-black text-white',
      glow: 'border-stone-300',
    },
  };

  const cfg = result ? urgencyConfig[result.urgencyLevel] : null;

  // milestone markers on the timeline
  const milestones = [
    { pct: 0, label: 'Storm Date' },
    { pct: 33, label: '4 Months' },
    { pct: 67, label: '8 Months' },
    { pct: 83, label: '10 Months' },
    { pct: 100, label: 'Deadline' },
  ];

  return (
    <section className="py-16 md:py-24 bg-white border-b border-stone-100">
      <div className="w-full px-6 md:px-10 lg:px-16">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-orange/10 border border-orange/20 text-orange px-4 py-1.5 text-xs font-semibold uppercase tracking-wider mb-5">
              <i className="ri-timer-line" />
              Free Tool
            </div>
            <h2 className="font-display text-2xl md:text-4xl text-charcoal uppercase tracking-wide mt-1 mb-4">
              Claim Timeline Calculator
            </h2>
            <p className="text-stone-500 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
              Enter the date of your storm and we\'ll show you exactly how much time you have left to file your insurance claim — and how urgent your situation is.
            </p>
          </div>

          {/* Calculator card */}
          <div className={`bg-white border-2 transition-colors duration-500 ${result ? cfg!.glow : 'border-stone-200'} overflow-hidden`}>

            {/* Input row */}
            <div className="p-6 md:p-10 border-b border-stone-100">
              <div className="flex flex-col sm:flex-row gap-4 items-end">
                <div className="flex-1">
                  <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">
                    When did the storm hit?
                  </label>
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center text-stone-400 pointer-events-none">
                      <i className="ri-calendar-event-line text-base" />
                    </div>
                    <input
                      type="date"
                      value={stormDate}
                      min={minDateStr}
                      max={maxDateStr}
                      onChange={(e) => { setStormDate(e.target.value); setResult(null); }}
                      className="w-full pl-11 pr-4 py-3.5 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                    />
                  </div>
                  <p className="text-stone-400 text-xs mt-1.5">Enter the approximate date — even a month estimate is fine</p>
                </div>
                <button
                  type="button"
                  onClick={calculate}
                  disabled={!stormDate}
                  className="flex-shrink-0 bg-orange hover:bg-orange-dark disabled:bg-stone-200 disabled:text-stone-400 text-white text-sm font-semibold px-8 py-3.5 transition-colors uppercase tracking-wide whitespace-nowrap flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed"
                >
                  <i className="ri-calculator-line" />
                  Calculate My Deadline
                </button>
              </div>
            </div>

            {/* Result area */}
            {result && cfg ? (
              <div className="p-6 md:p-10">

                {/* Urgency badge + headline */}
                <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-8">
                  <div className={`inline-flex items-center gap-2 border px-4 py-2 text-sm font-semibold ${cfg.badge}`}>
                    <i className={cfg.icon} />
                    {cfg.headline}
                  </div>
                  {result.urgencyLevel === 'critical' && (
                    <span className="inline-flex items-center gap-1.5 text-red-600 text-xs font-semibold animate-pulse">
                      <span className="w-2 h-2 rounded-full bg-red-500" />
                      Act immediately
                    </span>
                  )}
                </div>

                {/* Big numbers row */}
                <div className="grid grid-cols-3 gap-4 md:gap-6 mb-8">
                  <div className="bg-stone-50 border border-stone-100 p-4 md:p-6 text-center">
                    <p className="text-stone-400 text-xs uppercase tracking-wide mb-2">Days Elapsed</p>
                    <p className="font-display text-3xl md:text-4xl text-charcoal">{result.daysElapsed}</p>
                    <p className="text-stone-400 text-xs mt-1">since storm</p>
                  </div>
                  <div className={`border p-4 md:p-6 text-center ${
                    result.urgencyLevel === 'expired' ? 'bg-stone-50 border-stone-200' :
                    result.urgencyLevel === 'critical' ? 'bg-red-50 border-red-200' :
                    result.urgencyLevel === 'warning' ? 'bg-amber-50 border-amber-200' :
                    'bg-green-50 border-green-200'
                  }`}>
                    <p className="text-stone-400 text-xs uppercase tracking-wide mb-2">Days Remaining</p>
                    <p className={`font-display text-3xl md:text-4xl ${
                      result.urgencyLevel === 'expired' ? 'text-stone-400' :
                      result.urgencyLevel === 'critical' ? 'text-red-600' :
                      result.urgencyLevel === 'warning' ? 'text-amber-600' :
                      'text-green-600'
                    }`}>
                      {result.urgencyLevel === 'expired' ? '0' : result.daysRemaining}
                    </p>
                    <p className="text-stone-400 text-xs mt-1">to file claim</p>
                  </div>
                  <div className="bg-stone-50 border border-stone-100 p-4 md:p-6 text-center">
                    <p className="text-stone-400 text-xs uppercase tracking-wide mb-2">Deadline</p>
                    <p className="font-display text-lg md:text-xl text-charcoal leading-tight">{result.deadlineDate}</p>
                    <p className="text-stone-400 text-xs mt-1">last day to file</p>
                  </div>
                </div>

                {/* Timeline bar */}
                <div className="mb-8">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-charcoal text-xs font-semibold uppercase tracking-wide">Your 12-Month Claim Window</p>
                    <p className="text-stone-400 text-xs">{Math.round(result.progressPct)}% elapsed</p>
                  </div>
                  <div className="relative h-4 bg-stone-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-700 ${cfg.bar}`}
                      style={{ width: `${result.progressPct}%` }}
                    />
                    {/* Today marker */}
                    <div
                      className="absolute top-0 bottom-0 w-0.5 bg-white/80"
                      style={{ left: `${result.progressPct}%`, transform: 'translateX(-50%)' }}
                    />
                  </div>
                  {/* Milestone labels */}
                  <div className="relative mt-2 h-5">
                    {milestones.map((m) => (
                      <div
                        key={m.pct}
                        className="absolute flex flex-col items-center"
                        style={{ left: `${m.pct}%`, transform: 'translateX(-50%)' }}
                      >
                        <div className="w-px h-1.5 bg-stone-300" />
                        <span className="text-stone-400 text-xs whitespace-nowrap hidden sm:block">{m.label}</span>
                      </div>
                    ))}
                    {/* "You Are Here" marker */}
                    <div
                      className="absolute flex flex-col items-center"
                      style={{ left: `${result.progressPct}%`, transform: 'translateX(-50%)' }}
                    >
                      <div className="w-px h-1.5 bg-orange" />
                      <span className="text-orange text-xs font-semibold whitespace-nowrap">You Are Here</span>
                    </div>
                  </div>
                </div>

                {/* What happens next cards */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                  {[
                    {
                      icon: 'ri-search-eye-line',
                      title: 'Step 1: Free Inspection',
                      desc: 'We document all damage with photos and a detailed report — usually within 48 hours.',
                      time: '48 hrs',
                    },
                    {
                      icon: 'ri-file-text-line',
                      title: 'Step 2: Claim Filed',
                      desc: 'We submit your claim with full documentation and meet your adjuster on-site.',
                      time: '3–5 days',
                    },
                    {
                      icon: 'ri-money-dollar-circle-line',
                      title: 'Step 3: Payout',
                      desc: 'Most claims are approved within 2–4 weeks. We handle all follow-up and supplements.',
                      time: '2–4 weeks',
                    },
                  ].map((step) => (
                    <div key={step.title} className="bg-stone-50 border border-stone-100 p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-7 h-7 flex items-center justify-center bg-orange/10 text-orange flex-shrink-0">
                          <i className={`${step.icon} text-sm`} />
                        </div>
                        <span className="text-orange text-xs font-semibold">{step.time}</span>
                      </div>
                      <p className="text-charcoal text-xs font-semibold mb-1">{step.title}</p>
                      <p className="text-stone-500 text-xs leading-relaxed">{step.desc}</p>
                    </div>
                  ))}
                </div>

                {/* Urgency message */}
                <div className={`p-5 border-l-4 mb-8 ${
                  result.urgencyLevel === 'expired' ? 'bg-stone-50 border-stone-400' :
                  result.urgencyLevel === 'critical' ? 'bg-red-50 border-red-500' :
                  result.urgencyLevel === 'warning' ? 'bg-amber-50 border-amber-500' :
                  'bg-green-50 border-green-500'
                }`}>
                  <p className="text-charcoal text-sm font-semibold mb-1">
                    <i className={`${cfg.icon} mr-2`} />
                    {cfg.headline}
                  </p>
                  <p className="text-stone-600 text-sm leading-relaxed">{cfg.sub}</p>
                </div>

                {/* CTA */}
                <div className="flex flex-col sm:flex-row gap-4">
                  <a
                    href="#claim-form"
                    className={`flex-1 text-center text-sm font-semibold px-8 py-4 transition-colors uppercase tracking-wide whitespace-nowrap ${cfg.ctaStyle}`}
                  >
                    <i className="ri-arrow-right-line mr-2" />
                    {cfg.cta}
                  </a>
                  <a
                    href="tel:8122135997"
                    className="flex-shrink-0 border border-stone-300 hover:border-orange text-charcoal hover:text-orange text-sm font-semibold px-8 py-4 transition-colors uppercase tracking-wide whitespace-nowrap flex items-center justify-center gap-2"
                  >
                    <i className="ri-phone-line" />
                    812-213-5997
                  </a>
                </div>
              </div>
            ) : (
              /* Empty state */
              <div className="p-6 md:p-10">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  {[
                    { icon: 'ri-time-line', label: 'Safe Zone', desc: 'More than 4 months remaining', color: 'text-green-600', bg: 'bg-green-50 border-green-200' },
                    { icon: 'ri-alarm-warning-line', label: 'Warning Zone', desc: '2–4 months remaining', color: 'text-amber-600', bg: 'bg-amber-50 border-amber-200' },
                    { icon: 'ri-error-warning-line', label: 'Critical Zone', desc: 'Less than 60 days left', color: 'text-red-600', bg: 'bg-red-50 border-red-200' },
                  ].map((zone) => (
                    <div key={zone.label} className={`border p-5 text-center ${zone.bg}`}>
                      <div className={`w-10 h-10 mx-auto mb-3 flex items-center justify-center ${zone.color}`}>
                        <i className={`${zone.icon} text-2xl`} />
                      </div>
                      <p className={`font-display text-sm uppercase tracking-wide mb-1 ${zone.color}`}>{zone.label}</p>
                      <p className="text-stone-500 text-xs">{zone.desc}</p>
                    </div>
                  ))}
                </div>
                <div className="bg-stone-50 border border-stone-100 p-5 flex items-start gap-4">
                  <div className="w-9 h-9 flex-shrink-0 flex items-center justify-center bg-orange/10 text-orange">
                    <i className="ri-information-line text-lg" />
                  </div>
                  <div>
                    <p className="text-charcoal text-sm font-semibold mb-1">How does the 12-month window work?</p>
                    <p className="text-stone-500 text-sm leading-relaxed">
                      Most homeowner insurance policies in Indiana and Kentucky require you to file a storm damage claim within 12 months of the storm event — not when you discover the damage. Enter your storm date above to see exactly where you stand.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Fine print */}
          <p className="text-stone-400 text-xs text-center mt-4 leading-relaxed">
            <i className="ri-information-line mr-1" />
            This calculator is based on the standard 12-month filing window common to most IN &amp; KY homeowner policies. Your specific policy may differ. Always verify your deadline with your insurance carrier.
          </p>
        </div>
      </div>
    </section>
  );
}

function GalleryCard({ item }: { item: typeof galleryItems[0] }) {
  const [showAfter, setShowAfter] = useState(false);
  const [sliderPos, setSliderPos] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const updateSlider = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const pos = Math.min(100, Math.max(0, ((clientX - rect.left) / rect.width) * 100));
    setSliderPos(pos);
  }, []);

  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  useEffect(() => {
    if (!isDragging) return;
    const onMove = (e: MouseEvent) => updateSlider(e.clientX);
    const onUp = () => setIsDragging(false);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
  }, [isDragging, updateSlider]);

  const handleTouchMove = (e: React.TouchEvent) => {
    updateSlider(e.touches[0].clientX);
  };

  return (
    <div className="group bg-white border border-stone-200 hover:border-orange/30 transition-colors duration-300 overflow-hidden">
      {/* Before/After Slider */}
      <div
        ref={containerRef}
        className="relative h-52 overflow-hidden cursor-col-resize select-none"
        onMouseDown={handleMouseDown}
        onTouchMove={handleTouchMove}
        onTouchStart={(e) => updateSlider(e.touches[0].clientX)}
      >
        {/* After image (full width, behind) */}
        <img
          src={item.afterImg}
          alt={`After repair - ${item.damageType}`}
          className="absolute inset-0 w-full h-full object-cover object-top"
        />
        {/* Before image (clipped) */}
        <div
          className="absolute inset-0 overflow-hidden"
          style={{ width: `${sliderPos}%` }}
        >
          <img
            src={item.beforeImg}
            alt={`Before repair - ${item.damageType}`}
            className="absolute inset-0 w-full h-full object-cover object-top"
            style={{ width: `${10000 / sliderPos}%`, maxWidth: 'none' }}
          />
        </div>
        {/* Slider handle */}
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-white z-10"
          style={{ left: `${sliderPos}%`, transform: 'translateX(-50%)' }}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full flex items-center justify-center">
            <i className="ri-arrow-left-right-line text-charcoal text-sm" />
          </div>
        </div>
        {/* Labels */}
        <div className="absolute top-3 left-3 bg-black/60 text-white text-xs font-semibold px-2 py-1 uppercase tracking-wide pointer-events-none">
          Before
        </div>
        <div className="absolute top-3 right-3 bg-orange/90 text-white text-xs font-semibold px-2 py-1 uppercase tracking-wide pointer-events-none">
          After
        </div>
        {/* Damage tag */}
        <div className={`absolute bottom-3 left-3 ${item.tagColor} text-white text-xs font-semibold px-2.5 py-1 uppercase tracking-wide pointer-events-none`}>
          {item.tag}
        </div>
      </div>

      {/* Card content */}
      <div className="p-5">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div>
            <p className="text-stone-400 text-xs uppercase tracking-wide mb-0.5">{item.location} &bull; {item.stormDate}</p>
            <h3 className="font-display text-sm text-charcoal uppercase tracking-wide">{item.damageType}</h3>
          </div>
          <div className="text-right flex-shrink-0">
            <p className="text-stone-400 text-xs uppercase tracking-wide">Claim Recovered</p>
            <p className="font-display text-base text-orange">{item.claimAmount}</p>
          </div>
        </div>
        <p className="text-stone-500 text-xs leading-relaxed">{item.description}</p>
      </div>
    </div>
  );
}

const nowClaims = new Date();
const nearestExpiryClaims = [...OFFERS]
  .filter((o) => o.expires && new Date(o.expires) > nowClaims)
  .sort((a, b) => new Date(a.expires).getTime() - new Date(b.expires).getTime())[0];

export default function InsuranceClaims() {
  const [galleryFilter, setGalleryFilter] = useState<GalleryFilter>('all');
  const filteredGallery = galleryFilter === 'all' ? galleryItems : galleryItems.filter((g) => g.category === galleryFilter);

  const [alertStatus, setAlertStatus] = useState<'idle' | 'submitting' | 'success'>('idle');
  const [alertData, setAlertData] = useState({ name: '', email: '', zip: '', radius: '25' });
  const alertFormRef = useRef<HTMLFormElement>(null);

  const handleAlertChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setAlertData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleAlertSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlertStatus('submitting');
    try {
      const params = new URLSearchParams();
      params.append('name', alertData.name);
      params.append('email', alertData.email);
      params.append('zip', alertData.zip);
      params.append('radius', alertData.radius + ' miles');
      params.append('source', 'Storm Alert Signup');
      params.append('access_key', WEB3FORMS_ACCESS_KEY);
      await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: params,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      setAlertStatus('success');
    } catch {
      setAlertStatus('idle');
    }
  };

  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success'>('idle');
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    insuranceCompany: '',
    policyNumber: '',
    stormDate: '',
    damageType: '',
    notes: '',
  });

  const [checklistStatus, setChecklistStatus] = useState<'idle' | 'submitting' | 'unlocked'>('idle');
  const [checklistEmail, setChecklistEmail] = useState('');
  const [checklistName, setChecklistName] = useState('');
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});

  const handleChecklistSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setChecklistStatus('submitting');
    try {
      const params = new URLSearchParams();
      params.append('name', checklistName);
      params.append('email', checklistEmail);
      params.append('source', 'Storm Damage Checklist Lead Magnet');
      params.append('access_key', WEB3FORMS_ACCESS_KEY);
      await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: params,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      setChecklistStatus('unlocked');
    } catch {
      setChecklistStatus('idle');
    }
  };

  const toggleCheck = (key: string) => {
    setCheckedItems((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const totalItems = checklistSections.reduce((acc, s) => acc + s.items.length, 0);
  const checkedCount = Object.values(checkedItems).filter(Boolean).length;

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('submitting');
    const form = e.target as HTMLFormElement;
    const data = new FormData(form);
    data.append('access_key', WEB3FORMS_ACCESS_KEY);
    try {
      await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(data as any),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      setFormStatus('success');
    } catch {
      setFormStatus('idle');
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <PageSEO
        title="Storm Damage Insurance Claims Evansville Indiana | Corner Stone Roofing"
        description="Hail or wind damage to your roof? Corner Stone Construction & Roofing handles the entire insurance claim process in Evansville IN — free inspection, adjuster meeting, documentation, and supplement filing. Most clients pay only their deductible. Call 812-213-5997."
        keywords="storm damage insurance claim Evansville Indiana, hail damage roof claim Indiana, wind damage roofing insurance, roof insurance claim Evansville, storm damage roofing contractor Indiana, insurance adjuster roofing Evansville"
        canonical="/insurance-claims"
        schema={insuranceClaimsSchema}
      />

      {/* Hero */}
      <section className="relative min-h-[520px] md:min-h-[640px] flex items-center overflow-hidden">
        <img
          src="/placeholders/800x600.svg"
          alt="Storm damaged roof"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40" />
        <div className="relative z-10 w-full px-6 md:px-10 lg:px-16 pt-24 md:pt-28">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-orange/20 border border-orange/30 text-orange px-4 py-1.5 text-xs font-semibold uppercase tracking-wider mb-6">
              <i className="ri-flashlight-line" />
              Storm Damage Specialists
            </div>
            <h1 className="font-display text-3xl md:text-5xl lg:text-6xl text-white uppercase tracking-wide leading-tight mb-6">
              Insurance Claims<br />Made Simple
            </h1>
            <p className="text-white/80 text-base md:text-lg leading-relaxed max-w-xl mb-6">
              Hail, wind, or storm damage to your roof? We handle the entire insurance claim process from inspection to approval — so you get every dollar you are owed without the headache.
            </p>
            {/* Urgency Stack */}
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="flex-shrink-0">
                <CountdownTimer
                  expiresAt={nearestExpiryClaims ? nearestExpiryClaims.expires : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()}
                  variant="card"
                />
              </div>
              <SocialProofPulse />
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="#claim-form"
                className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-8 py-3.5 transition-colors duration-200 text-center uppercase tracking-wide whitespace-nowrap"
              >
                Start Your Claim
              </a>
              <a
                href="tel:8122135997"
                className="border border-white/30 hover:border-white/60 text-white text-sm font-semibold px-8 py-3.5 transition-colors duration-200 text-center uppercase tracking-wide whitespace-nowrap flex items-center justify-center gap-2"
              >
                <i className="ri-phone-line" />
                Call 812-213-5997
              </a>
            </div>
          </div>
        </div>
      </section>

      <TalkToAIExpert />

      {/* Recent Storms */}
      <section className="bg-white py-14 md:py-20 border-b border-stone-100">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-10">
            <div>
              <div className="inline-flex items-center gap-2 bg-red-50 border border-red-200 text-red-600 px-3 py-1 text-xs font-semibold uppercase tracking-wider mb-4">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                Live Storm Activity
              </div>
              <h2 className="font-display text-2xl md:text-4xl text-charcoal uppercase tracking-wide">
                Recent Storms in Your Area
              </h2>
              <p className="text-stone-500 mt-2 text-sm md:text-base max-w-xl">
                These storms have caused significant roof damage across the Tri-State area. Insurance claim windows are open — but they close fast.
              </p>
            </div>
            <div className="flex-shrink-0 text-right">
              <p className="text-stone-400 text-xs uppercase tracking-wide">Claim filing deadline</p>
              <p className="text-charcoal font-display text-lg uppercase tracking-wide">Within 12 Months of Storm</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-10">
            {recentStorms.map((storm) => {
              const cfg = severityConfig[storm.severity as keyof typeof severityConfig];
              const daysLeft = 365 - storm.daysAgo;
              const urgency = daysLeft < 120 ? 'text-red-500' : daysLeft < 200 ? 'text-amber-600' : 'text-green-600';
              return (
                <div key={storm.date} className={`bg-white border ${cfg.border} p-5 md:p-6 group hover:border-orange/40 transition-all duration-300`}>
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className={`inline-flex items-center gap-1.5 ${cfg.bg} ${cfg.text} border ${cfg.border} px-2.5 py-1 text-xs font-semibold uppercase tracking-wide mb-2`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
                        {cfg.label}
                      </div>
                      <h3 className="font-display text-base text-charcoal uppercase tracking-wide">{storm.location}</h3>
                      <p className="text-stone-400 text-xs mt-0.5">{storm.date} &bull; {storm.daysAgo} days ago</p>
                    </div>
                    <div className="w-10 h-10 flex items-center justify-center bg-stone-50 text-stone-400 flex-shrink-0">
                      <i className="ri-thunderstorms-line text-xl" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="bg-stone-50 px-3 py-2">
                      <p className="text-stone-400 text-xs uppercase tracking-wide">Storm Type</p>
                      <p className="text-charcoal text-xs font-semibold mt-0.5">{storm.type}</p>
                    </div>
                    <div className="bg-stone-50 px-3 py-2">
                      <p className="text-stone-400 text-xs uppercase tracking-wide">Hail Size</p>
                      <p className="text-charcoal text-xs font-semibold mt-0.5">{storm.hailSize}</p>
                    </div>
                    <div className="bg-stone-50 px-3 py-2">
                      <p className="text-stone-400 text-xs uppercase tracking-wide">Wind Speed</p>
                      <p className="text-charcoal text-xs font-semibold mt-0.5">{storm.windSpeed}</p>
                    </div>
                    <div className="bg-stone-50 px-3 py-2">
                      <p className="text-stone-400 text-xs uppercase tracking-wide">Claims Handled</p>
                      <p className="text-charcoal text-xs font-semibold mt-0.5">{storm.claimsHandled} homes</p>
                    </div>
                  </div>

                  <div className="mb-4">
                    <p className="text-stone-400 text-xs uppercase tracking-wide mb-1.5">Affected ZIP Codes</p>
                    <div className="flex flex-wrap gap-1.5">
                      {storm.zipCodes.map((zip) => (
                        <span key={zip} className="bg-stone-100 text-stone-600 text-xs px-2 py-0.5 font-mono">{zip}</span>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-stone-100">
                    <div>
                      <p className="text-stone-400 text-xs">Claim window</p>
                      <p className={`text-xs font-semibold ${urgency}`}>{daysLeft} days remaining</p>
                    </div>
                    <a
                      href="#claim-form"
                      className="bg-orange hover:bg-orange-dark text-white text-xs font-semibold px-4 py-2 transition-colors uppercase tracking-wide whitespace-nowrap"
                    >
                      File Claim
                    </a>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="bg-amber-50 border border-amber-200 p-5 flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center bg-amber-100 text-amber-600">
              <i className="ri-alarm-warning-line text-xl" />
            </div>
            <div className="flex-1">
              <p className="text-amber-800 text-sm font-semibold">Don&apos;t see your storm listed?</p>
              <p className="text-amber-700 text-xs mt-0.5 leading-relaxed">We track storm activity across all of Indiana and Kentucky. Even if your event is not listed, you may still have claimable damage. A free inspection takes 30 minutes and costs you nothing.</p>
            </div>
            <a
              href="#claim-form"
              className="flex-shrink-0 bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold px-5 py-2.5 transition-colors uppercase tracking-wide whitespace-nowrap"
            >
              Get Free Inspection
            </a>
          </div>
        </div>
      </section>

      {/* Storm Alert Signup */}
      <section id="storm-alerts" className="bg-gradient-to-br from-charcoal-deep via-[#1a1a1a] to-[#111] py-16 md:py-20 relative overflow-hidden">
        {/* Decorative background elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-orange/5 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-orange/5 rounded-full blur-3xl" />
        </div>
        <div className="relative z-10 w-full px-6 md:px-10 lg:px-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">

            {/* Left: Messaging */}
            <div>
              <div className="inline-flex items-center gap-2 bg-orange/15 border border-orange/25 text-orange px-3 py-1.5 text-xs font-semibold uppercase tracking-wider mb-6">
                <span className="w-2 h-2 rounded-full bg-orange animate-pulse" />
                Free Storm Alerts
              </div>
              <h2 className="font-display text-2xl md:text-4xl text-white uppercase tracking-wide leading-tight mb-5">
                Get Notified When<br />Storms Hit Your Area
              </h2>
              <p className="text-white/60 text-sm md:text-base leading-relaxed mb-8">
                Sign up for free storm alerts and be the first to know when severe weather hits your ZIP code. We track hail, high winds, and tornado activity across Indiana and Kentucky — and alert you before the insurance claim window starts closing.
              </p>

              <div className="space-y-4">
                {[
                  { icon: 'ri-notification-3-line', title: 'Instant Email Alerts', desc: 'Get notified within hours of a storm event in your area — not days later.' },
                  { icon: 'ri-map-pin-2-line', title: 'ZIP Code Precision', desc: 'Alerts are targeted to your exact location, not just your county or region.' },
                  { icon: 'ri-calendar-check-line', title: 'Claim Window Reminders', desc: 'We remind you as your 12-month filing deadline approaches so you never miss out.' },
                  { icon: 'ri-shield-check-line', title: 'No Spam, Ever', desc: 'Only real storm alerts. Unsubscribe anytime with one click.' },
                ].map((item) => (
                  <div key={item.title} className="flex items-start gap-4">
                    <div className="w-9 h-9 flex-shrink-0 flex items-center justify-center bg-orange/15 text-orange">
                      <i className={`${item.icon} text-base`} />
                    </div>
                    <div>
                      <p className="text-white text-sm font-semibold mb-0.5">{item.title}</p>
                      <p className="text-white/50 text-xs leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Recent alert examples */}
              <div className="mt-8 p-4 bg-white/5 border border-white/10">
                <p className="text-white/40 text-xs uppercase tracking-wide mb-3">Recent alerts sent to subscribers</p>
                <div className="space-y-2">
                  {[
                    { zip: '47710', event: 'Hail 1.75" — Evansville, IN', time: '2 hrs after storm', color: 'text-red-400' },
                    { zip: '42420', event: 'Hail 1.25" — Henderson, KY', time: '3 hrs after storm', color: 'text-amber-400' },
                    { zip: '47601', event: 'Tornado Warning + Hail 2.0"', time: '1 hr after storm', color: 'text-red-400' },
                  ].map((alert) => (
                    <div key={alert.zip} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-white/30 text-xs">{alert.zip}</span>
                        <span className={`text-xs font-semibold ${alert.color}`}>{alert.event}</span>
                      </div>
                      <span className="text-white/30 text-xs whitespace-nowrap">{alert.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right: Signup form */}
            <div>
              {alertStatus === 'success' ? (
                <div className="bg-white/5 border border-white/10 p-8 md:p-10 text-center">
                  <div className="w-16 h-16 mx-auto mb-5 flex items-center justify-center bg-orange/15 text-orange">
                    <i className="ri-notification-3-line text-3xl" />
                  </div>
                  <h3 className="font-display text-xl text-white uppercase tracking-wide mb-3">You&apos;re On the List!</h3>
                  <p className="text-white/60 text-sm leading-relaxed mb-6">
                    Storm alerts for ZIP <strong className="text-orange">{alertData.zip}</strong> are now active. We&apos;ll email you within hours of any significant storm activity in your area.
                  </p>
                  <div className="bg-white/5 border border-white/10 p-4 text-left">
                    <p className="text-white/40 text-xs uppercase tracking-wide mb-2">Your alert settings</p>
                    <div className="space-y-1.5">
                      <div className="flex justify-between">
                        <span className="text-white/50 text-xs">ZIP Code</span>
                        <span className="text-white text-xs font-semibold">{alertData.zip}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/50 text-xs">Alert Radius</span>
                        <span className="text-white text-xs font-semibold">{alertData.radius} miles</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/50 text-xs">Email</span>
                        <span className="text-white text-xs font-semibold">{alertData.email}</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-white/30 text-xs mt-5">Check your inbox for a confirmation email. Add us to your contacts so alerts don&apos;t go to spam.</p>
                </div>
              ) : (
                <div className="bg-white/5 border border-white/10 p-6 md:p-8">
                  <div className="mb-6">
                    <h3 className="font-display text-lg text-white uppercase tracking-wide mb-2">Set Up Your Storm Alert</h3>
                    <p className="text-white/50 text-sm">Takes 30 seconds. Free forever. No credit card needed.</p>
                  </div>

                  <form ref={alertFormRef} data-readdy-form onSubmit={handleAlertSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-white/60 text-xs font-semibold uppercase tracking-wide mb-2">Your Name *</label>
                        <input
                          type="text"
                          name="name"
                          required
                          value={alertData.name}
                          onChange={handleAlertChange}
                          className="w-full px-4 py-3 bg-white/10 border border-white/15 text-white text-sm placeholder-white/30 focus:outline-none focus:border-orange transition-colors"
                          placeholder="John Smith"
                        />
                      </div>
                      <div>
                        <label className="block text-white/60 text-xs font-semibold uppercase tracking-wide mb-2">ZIP Code *</label>
                        <input
                          type="text"
                          name="zip"
                          required
                          maxLength={5}
                          pattern="[0-9]{5}"
                          value={alertData.zip}
                          onChange={handleAlertChange}
                          className="w-full px-4 py-3 bg-white/10 border border-white/15 text-white text-sm placeholder-white/30 focus:outline-none focus:border-orange transition-colors"
                          placeholder="47710"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-white/60 text-xs font-semibold uppercase tracking-wide mb-2">Email Address *</label>
                      <input
                        type="email"
                        name="email"
                        required
                        value={alertData.email}
                        onChange={handleAlertChange}
                        className="w-full px-4 py-3 bg-white/10 border border-white/15 text-white text-sm placeholder-white/30 focus:outline-none focus:border-orange transition-colors"
                        placeholder="john@email.com"
                      />
                    </div>

                    <div>
                      <label className="block text-white/60 text-xs font-semibold uppercase tracking-wide mb-2">Alert Radius</label>
                      <select
                        name="radius"
                        value={alertData.radius}
                        onChange={handleAlertChange}
                        className="w-full px-4 py-3 bg-white/10 border border-white/15 text-white text-sm focus:outline-none focus:border-orange transition-colors"
                      >
                        <option value="10" className="bg-charcoal-deep">10 miles from my ZIP</option>
                        <option value="25" className="bg-charcoal-deep">25 miles from my ZIP</option>
                        <option value="50" className="bg-charcoal-deep">50 miles from my ZIP</option>
                        <option value="75" className="bg-charcoal-deep">75 miles from my ZIP</option>
                      </select>
                    </div>

                    {/* Alert type checkboxes */}
                    <div>
                      <label className="block text-white/60 text-xs font-semibold uppercase tracking-wide mb-3">Alert Me For</label>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          { label: 'Hail (any size)', icon: 'ri-cloud-line' },
                          { label: 'High Winds 50+ mph', icon: 'ri-windy-line' },
                          { label: 'Tornado Warnings', icon: 'ri-tornado-line' },
                          { label: 'Claim Deadlines', icon: 'ri-calendar-line' },
                        ].map((type) => (
                          <div key={type.label} className="flex items-center gap-2.5 bg-white/5 border border-white/10 px-3 py-2.5">
                            <div className="w-4 h-4 flex items-center justify-center bg-orange text-white flex-shrink-0">
                              <i className="ri-check-line text-xs" />
                            </div>
                            <div className="flex items-center gap-1.5">
                              <i className={`${type.icon} text-white/40 text-xs`} />
                              <span className="text-white/70 text-xs">{type.label}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <input type="hidden" name="source" value="Storm Alert Signup" />

                    <button
                      type="submit"
                      disabled={alertStatus === 'submitting'}
                      className="w-full bg-orange hover:bg-orange-dark disabled:bg-stone-600 text-white text-sm font-semibold px-8 py-4 transition-colors duration-200 uppercase tracking-wide whitespace-nowrap flex items-center justify-center gap-2"
                    >
                      {alertStatus === 'submitting' ? (
                        <><i className="ri-loader-4-line animate-spin" /> Setting Up Alerts...</>
                      ) : (
                        <><i className="ri-notification-3-line" /> Activate My Storm Alerts</>
                      )}
                    </button>

                    <p className="text-white/30 text-xs text-center">
                      <i className="ri-lock-line mr-1" />
                      No spam. Unsubscribe anytime. We only send real storm alerts.
                    </p>
                  </form>

                  {/* Subscriber count */}
                  <div className="mt-6 pt-5 border-t border-white/10 flex items-center justify-between">
                    <div className="flex -space-x-2">
                      {[
                        '/placeholders/40x40.svg',
                        '/placeholders/40x40.svg',
                        '/placeholders/40x40.svg',
                        '/placeholders/40x40.svg',
                      ].map((src, i) => (
                        <img key={i} src={src} alt="subscriber" className="w-8 h-8 rounded-full border-2 border-[#1a1a1a] object-cover" />
                      ))}
                    </div>
                    <p className="text-white/40 text-xs"><strong className="text-white/70">1,240+ homeowners</strong> already subscribed</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Trust Bar */}
      <section className="bg-charcoal-deep py-6">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="flex flex-wrap items-center justify-center gap-6 md:gap-12">
            <div className="flex items-center gap-2 text-white/70 text-sm">
              <i className="ri-shield-check-line text-orange text-lg" />
              <span>Licensed & Insured</span>
            </div>
            <div className="flex items-center gap-2 text-white/70 text-sm">
              <i className="ri-award-line text-orange text-lg" />
              <span>Lifetime Warranty</span>
            </div>
            <div className="flex items-center gap-2 text-white/70 text-sm">
              <i className="ri-time-line text-orange text-lg" />
              <span>24/7 Emergency Response</span>
            </div>
            <div className="flex items-center gap-2 text-white/70 text-sm">
              <i className="ri-map-pin-line text-orange text-lg" />
              <span>Serving Indiana & Kentucky</span>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 md:py-24 bg-stone-50">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="text-center mb-14">
            <span className="text-orange text-xs font-semibold uppercase tracking-widest">The Process</span>
            <h2 className="font-display text-2xl md:text-4xl text-charcoal uppercase tracking-wide mt-3">
              How Insurance Claims Work
            </h2>
            <p className="text-stone-500 mt-3 max-w-xl mx-auto text-sm md:text-base">
              We guide you through every step so you never feel lost or taken advantage of.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step) => (
              <div key={step.num} className="bg-white p-6 md:p-8 border border-stone-200 group hover:border-orange/30 transition-colors duration-300">
                <div className="flex items-center justify-between mb-5">
                  <div className="w-12 h-12 flex items-center justify-center bg-orange/10 text-orange">
                    <i className={`${step.icon} text-xl`} />
                  </div>
                  <span className="font-display text-3xl text-stone-200 group-hover:text-orange/20 transition-colors">{step.num}</span>
                </div>
                <h3 className="font-display text-lg text-charcoal uppercase tracking-wide mb-3">{step.title}</h3>
                <p className="text-stone-500 text-sm leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 md:py-24 bg-white">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
            <div>
              <span className="text-orange text-xs font-semibold uppercase tracking-widest">Why Corner Stone</span>
              <h2 className="font-display text-2xl md:text-4xl text-charcoal uppercase tracking-wide mt-3 mb-6">
                We Fight for Your Full Payout
              </h2>
              <p className="text-stone-500 text-sm md:text-base leading-relaxed mb-8">
                Insurance companies are not in the business of paying out maximum claims. They are in the business of minimizing payouts. That is why you need a roofing contractor who knows how to document damage properly, speak the adjuster\'s language, and file supplements when the initial estimate falls short.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {benefits.map((b) => (
                  <div key={b.title} className="flex gap-4">
                    <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center bg-orange/10 text-orange">
                      <i className={`${b.icon} text-lg`} />
                    </div>
                    <div>
                      <h4 className="font-display text-sm text-charcoal uppercase tracking-wide mb-1">{b.title}</h4>
                      <p className="text-stone-500 text-xs leading-relaxed">{b.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <img
                src="/placeholders/800x600.svg"
                alt="Roof inspection after storm"
                className="w-full h-[400px] md:h-[520px] object-cover"
              />
              <div className="absolute bottom-6 left-6 right-6 bg-white p-5 border-l-4 border-orange">
                <p className="text-charcoal text-sm font-medium italic leading-relaxed">
                  "Corner Stone met my adjuster, pointed out damage he missed, and got my claim approved for $8,400 more than the initial estimate."
                </p>
                <p className="text-stone-400 text-xs mt-2 uppercase tracking-wide">— Mike R., Henderson, KY</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Storm Damage Signs */}
      <section className="py-16 md:py-24 bg-charcoal-deep">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-orange text-xs font-semibold uppercase tracking-widest">Know the Signs</span>
              <h2 className="font-display text-2xl md:text-4xl text-white uppercase tracking-wide mt-3 mb-6">
                Does Your Roof Have Storm Damage?
              </h2>
              <p className="text-white/60 text-sm md:text-base leading-relaxed mb-8">
                Not all storm damage is obvious from the ground. Hail can bruise shingles and strip granules without leaving a hole. Wind can lift shingles and break the seal without tearing them off completely. Here is what to look for:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {stormSigns.map((sign) => (
                  <div key={sign} className="flex items-start gap-3">
                    <div className="w-5 h-5 flex-shrink-0 flex items-center justify-center bg-orange/20 text-orange mt-0.5">
                      <i className="ri-check-line text-xs" />
                    </div>
                    <span className="text-white/80 text-sm">{sign}</span>
                  </div>
                ))}
              </div>
              <div className="mt-8 p-4 bg-white/5 border border-white/10">
                <p className="text-white/70 text-sm">
                  <i className="ri-information-line text-orange mr-2" />
                  Even if you do not see leaks yet, hidden damage can lead to costly problems months later. A free inspection now could save you thousands.
                </p>
              </div>
            </div>
            <div className="relative">
              <img
                src="/placeholders/800x600.svg"
                alt="Hail damaged shingles close up"
                className="w-full h-[360px] md:h-[480px] object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Checklist Lead Magnet */}
      <section id="checklist" className="py-16 md:py-24 bg-white">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">

            {/* Left: Value prop + PDF preview */}
            <div className="lg:sticky lg:top-28">
              <span className="text-orange text-xs font-semibold uppercase tracking-widest">Free Download</span>
              <h2 className="font-display text-2xl md:text-4xl text-charcoal uppercase tracking-wide mt-3 mb-4">
                The Complete Storm Damage Checklist
              </h2>
              <p className="text-stone-500 text-sm md:text-base leading-relaxed mb-6">
                Not sure if you have a claim? Not ready to call yet? That is totally fine. Download our free 6-step checklist so you know exactly what to do, what to document, and what to say to your insurance company.
              </p>

              {/* Mock PDF preview card */}
              <div className="relative bg-stone-50 border border-stone-200 p-6 mb-6 overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-orange to-amber-400" />
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 flex items-center justify-center bg-orange/10 text-orange flex-shrink-0">
                    <i className="ri-file-pdf-2-line text-xl" />
                  </div>
                  <div>
                    <p className="text-charcoal text-sm font-semibold">Storm Damage Checklist.pdf</p>
                    <p className="text-stone-400 text-xs">Corner Stone Construction &amp; Roofing &bull; 6 Sections &bull; 32 Action Items</p>
                  </div>
                </div>
                <div className="space-y-2.5">
                  {checklistSections.map((s) => (
                    <div key={s.title} className="flex items-center gap-2.5 text-stone-500 text-xs">
                      <div className="w-4 h-4 flex items-center justify-center text-orange flex-shrink-0">
                        <i className={s.icon} />
                      </div>
                      <span>{s.title}</span>
                    </div>
                  ))}
                </div>
                {checklistStatus !== 'unlocked' && (
                  <div className="absolute inset-0 bg-white/60 backdrop-blur-[2px] flex items-center justify-center">
                    <div className="flex items-center gap-2 bg-white border border-stone-200 px-4 py-2 text-stone-500 text-xs font-semibold uppercase tracking-wide">
                      <i className="ri-lock-line text-orange" />
                      Enter your email to unlock
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-3 gap-3">
                {[
                  { icon: 'ri-time-line', label: '5 min read' },
                  { icon: 'ri-shield-check-line', label: 'Expert-written' },
                  { icon: 'ri-download-line', label: 'Free forever' },
                ].map((item) => (
                  <div key={item.label} className="bg-stone-50 border border-stone-100 p-3 text-center">
                    <div className="w-6 h-6 mx-auto mb-1 flex items-center justify-center text-orange">
                      <i className={`${item.icon} text-base`} />
                    </div>
                    <p className="text-stone-500 text-xs">{item.label}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Gate form OR interactive checklist */}
            <div>
              {checklistStatus !== 'unlocked' ? (
                <div className="bg-stone-50 border border-stone-200 p-6 md:p-8">
                  <div className="mb-6">
                    <h3 className="font-display text-lg text-charcoal uppercase tracking-wide mb-2">Get Instant Access</h3>
                    <p className="text-stone-500 text-sm leading-relaxed">
                      Enter your name and email below. We will send you the checklist and occasionally share storm alerts for your area. No spam, ever.
                    </p>
                  </div>
                  <form data-readdy-form onSubmit={handleChecklistSubmit} className="space-y-4">
                    <div>
                      <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Your Name *</label>
                      <input
                        type="text"
                        name="name"
                        required
                        value={checklistName}
                        onChange={(e) => setChecklistName(e.target.value)}
                        className="w-full px-4 py-3 bg-white border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                        placeholder="John Smith"
                      />
                    </div>
                    <div>
                      <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Email Address *</label>
                      <input
                        type="email"
                        name="email"
                        required
                        value={checklistEmail}
                        onChange={(e) => setChecklistEmail(e.target.value)}
                        className="w-full px-4 py-3 bg-white border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                        placeholder="john@email.com"
                      />
                    </div>
                    <input type="hidden" name="source" value="Storm Damage Checklist Lead Magnet" />
                    <button
                      type="submit"
                      disabled={checklistStatus === 'submitting'}
                      className="w-full bg-orange hover:bg-orange-dark disabled:bg-stone-300 text-white text-sm font-semibold px-8 py-4 transition-colors duration-200 uppercase tracking-wide whitespace-nowrap flex items-center justify-center gap-2"
                    >
                      {checklistStatus === 'submitting' ? (
                        <><i className="ri-loader-4-line animate-spin" /> Unlocking...</>
                      ) : (
                        <><i className="ri-download-line" /> Get Free Checklist</>
                      )}
                    </button>
                    <p className="text-stone-400 text-xs text-center">
                      <i className="ri-lock-line mr-1" />
                      No spam. Unsubscribe anytime. Your info stays private.
                    </p>
                  </form>

                  {/* Social proof */}
                  <div className="mt-6 pt-5 border-t border-stone-200 flex items-center gap-3">
                    <div className="flex -space-x-2">
                      {[
                        '/placeholders/40x40.svg',
                        '/placeholders/40x40.svg',
                        '/placeholders/40x40.svg',
                      ].map((src, i) => (
                        <img key={i} src={src} alt="homeowner" className="w-8 h-8 rounded-full border-2 border-white object-cover" />
                      ))}
                    </div>
                    <p className="text-stone-500 text-xs"><strong className="text-charcoal">847 homeowners</strong> downloaded this month</p>
                  </div>
                </div>
              ) : (
                <div>
                  {/* Progress bar */}
                  <div className="bg-stone-50 border border-stone-200 p-4 mb-5">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-charcoal text-xs font-semibold uppercase tracking-wide">Your Progress</p>
                      <p className="text-orange text-xs font-semibold">{checkedCount} / {totalItems} completed</p>
                    </div>
                    <div className="w-full bg-stone-200 h-2">
                      <div
                        className="bg-orange h-2 transition-all duration-500"
                        style={{ width: `${totalItems > 0 ? (checkedCount / totalItems) * 100 : 0}%` }}
                      />
                    </div>
                    {checkedCount === totalItems && totalItems > 0 && (
                      <p className="text-green-600 text-xs font-semibold mt-2 flex items-center gap-1">
                        <i className="ri-check-double-line" /> All done! You are ready to file your claim.
                      </p>
                    )}
                  </div>

                  <div className="space-y-4">
                    {checklistSections.map((section) => (
                      <div key={section.title} className="bg-stone-50 border border-stone-200">
                        <div className="flex items-center gap-3 px-5 py-3.5 border-b border-stone-200 bg-white">
                          <div className="w-7 h-7 flex items-center justify-center bg-orange/10 text-orange flex-shrink-0">
                            <i className={`${section.icon} text-xl`} />
                          </div>
                          <h4 className="font-display text-sm text-charcoal uppercase tracking-wide">{section.title}</h4>
                        </div>
                        <div className="p-4 space-y-2.5">
                          {section.items.map((item, idx) => {
                            const key = `${section.title}-${idx}`;
                            const checked = !!checkedItems[key];
                            return (
                              <button
                                key={key}
                                type="button"
                                onClick={() => toggleCheck(key)}
                                className="w-full flex items-start gap-3 text-left group cursor-pointer"
                              >
                                <div className={`w-5 h-5 flex-shrink-0 flex items-center justify-center border mt-0.5 transition-colors ${
                                  checked ? 'bg-orange border-orange text-white' : 'border-stone-300 bg-white text-transparent group-hover:border-orange/50'
                                }`}>
                                  <i className="ri-check-line text-xs" />
                                </div>
                                <span className={`text-sm leading-relaxed transition-colors ${
                                  checked ? 'text-stone-400 line-through' : 'text-stone-600 group-hover:text-charcoal'
                                }`}>{item}</span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 p-5 bg-orange/5 border border-orange/20">
                    <p className="text-charcoal text-sm font-semibold mb-1">Ready to take the next step?</p>
                    <p className="text-stone-500 text-xs leading-relaxed mb-3">Our team handles everything on this checklist for you — for free. No obligation, no pressure.</p>
                    <a
                      href="#claim-form"
                      className="inline-flex items-center gap-2 bg-orange hover:bg-orange-dark text-white text-xs font-semibold px-5 py-2.5 transition-colors uppercase tracking-wide whitespace-nowrap"
                    >
                      <i className="ri-arrow-right-line" />
                      Start My Free Inspection
                    </a>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Claim Timeline Calculator */}
      <ClaimTimelineCalculator />

      {/* Claim Form */}
      <section id="claim-form" className="py-16 md:py-24 bg-stone-50">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-10">
              <span className="text-orange text-xs font-semibold uppercase tracking-widest">Get Started</span>
              <h2 className="font-display text-2xl md:text-4xl text-charcoal uppercase tracking-wide mt-3">
                Start Your Insurance Claim
              </h2>
              <p className="text-stone-500 mt-3 max-w-lg mx-auto text-sm md:text-base">
                Fill out the form below and our claims specialist will contact you within 24 hours to schedule your free inspection.
              </p>
            </div>

            {formStatus === 'success' ? (
              <div className="bg-white p-10 md:p-14 text-center border border-stone-200">
                <div className="w-16 h-16 mx-auto mb-6 flex items-center justify-center bg-green-50 text-green-600">
                  <i className="ri-check-double-line text-3xl" />
                </div>
                <h3 className="font-display text-xl md:text-2xl text-charcoal uppercase tracking-wide mb-3">
                  Claim Request Received
                </h3>
                <p className="text-stone-500 text-sm md:text-base max-w-md mx-auto leading-relaxed">
                  Our insurance claims specialist will call you within 24 hours. In the meantime, take photos of any visible damage and avoid making temporary repairs until we inspect.
                </p>
                <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
                  <a href="tel:8122135997" className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-6 py-3 transition-colors uppercase tracking-wide whitespace-nowrap">
                    <i className="ri-phone-line mr-2" />
                    Call Now: 812-213-5997
                  </a>
                </div>
              </div>
            ) : (
              <form
                data-readdy-form
                onSubmit={handleSubmit}
                className="bg-white p-6 md:p-10 border border-stone-200"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
                  <div>
                    <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Full Name *</label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                      placeholder="John Smith"
                    />
                  </div>
                  <div>
                    <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Phone Number *</label>
                    <input
                      type="tel"
                      name="phone"
                      required
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                      placeholder="(812) 213-5997"
                    />
                  </div>
                  <div>
                    <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Email Address *</label>
                    <input
                      type="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                      placeholder="john@email.com"
                    />
                  </div>
                  <div>
                    <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Property Address *</label>
                    <input
                      type="text"
                      name="address"
                      required
                      value={formData.address}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                      placeholder="123 Main St, Evansville, IN"
                    />
                  </div>
                  <div>
                    <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Insurance Company</label>
                    <input
                      type="text"
                      name="insuranceCompany"
                      value={formData.insuranceCompany}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                      placeholder="State Farm, Allstate, etc."
                    />
                  </div>
                  <div>
                    <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Policy Number</label>
                    <input
                      type="text"
                      name="policyNumber"
                      value={formData.policyNumber}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                      placeholder="Optional"
                    />
                  </div>
                  <div>
                    <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Storm Date (approximate)</label>
                    <input
                      type="date"
                      name="stormDate"
                      value={formData.stormDate}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Type of Damage *</label>
                    <select
                      name="damageType"
                      required
                      value={formData.damageType}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                    >
                      <option value="">Select damage type</option>
                      <option value="hail">Hail Damage</option>
                      <option value="wind">Wind Damage</option>
                      <option value="fallen-tree">Fallen Tree / Debris</option>
                      <option value="water">Water / Leak</option>
                      <option value="unknown">Not Sure — Need Inspection</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>
                <div className="mb-6">
                  <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Additional Details</label>
                  <textarea
                    name="notes"
                    value={formData.notes}
                    onChange={handleChange}
                    maxLength={500}
                    rows={4}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors resize-none"
                    placeholder="Describe what you have noticed, any leaks, missing shingles, etc."
                  />
                  <p className="text-stone-400 text-xs mt-1 text-right">{formData.notes.length}/500</p>
                </div>
                <button
                  type="submit"
                  disabled={formStatus === 'submitting'}
                  className="w-full bg-orange hover:bg-orange-dark disabled:bg-stone-300 text-white text-sm font-semibold px-8 py-4 transition-colors duration-200 uppercase tracking-wide whitespace-nowrap"
                >
                  {formStatus === 'submitting' ? (
                    <span className="flex items-center justify-center gap-2">
                      <i className="ri-loader-4-line animate-spin" />
                      Submitting...
                    </span>
                  ) : (
                    'Submit Claim Request'
                  )}
                </button>
                <p className="text-stone-400 text-xs text-center mt-4">
                  <i className="ri-lock-line mr-1" />
                  Your information is secure and will never be shared with third parties.
                </p>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* What Your Insurance Company Won't Tell You */}
      <section className="py-16 md:py-24 bg-white">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 bg-red-50 border border-red-200 text-red-600 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider mb-5">
              <i className="ri-eye-off-line" />
              Industry Insider
            </div>
            <h2 className="font-display text-2xl md:text-4xl text-charcoal uppercase tracking-wide mt-1 mb-4">
              What Your Insurance Company<br />Won&apos;t Tell You
            </h2>
            <p className="text-stone-500 text-sm md:text-base max-w-2xl mx-auto leading-relaxed">
              After handling hundreds of insurance claims across Indiana and Kentucky, we&apos;ve seen every trick in the book. Here&apos;s what adjusters know — and hope you don&apos;t.
            </p>
          </div>

          {/* Big numbered tips */}
          <div className="space-y-6 mb-16">
            {[
              {
                num: '01',
                title: 'The First Offer Is Almost Never the Final Offer',
                body: 'Insurance adjusters are trained to settle claims quickly and cheaply. The first estimate they hand you is a starting point — not a final number. Homeowners who accept the first offer without a contractor review leave thousands of dollars on the table. We have seen initial estimates revised upward by $4,000 to $12,000 after a proper supplement is filed.',
                tag: 'Negotiation',
                tagColor: 'bg-red-50 text-red-600 border-red-200',
                icon: 'ri-money-dollar-circle-line',
                stat: '$6,200',
                statLabel: 'avg. supplement increase',
              },
              {
                num: '02',
                title: 'Adjusters Use Software That Undervalues Labor',
                body: 'Most insurance companies use estimating software called Xactimate. The labor rates built into this software are often 15–30% below actual market rates in our area. A contractor who knows how to write a proper supplement can challenge these line items with real-world pricing — and win.',
                tag: 'Pricing',
                tagColor: 'bg-amber-50 text-amber-700 border-amber-200',
                icon: 'ri-computer-line',
                stat: '15–30%',
                statLabel: 'below-market labor rates',
              },
              {
                num: '03',
                title: 'You Have the Right to a Public Adjuster or Attorney',
                body: 'If your claim is denied or severely underpaid, you are not stuck. You have the legal right to hire a public adjuster or insurance attorney to fight on your behalf — often on a contingency basis, meaning no upfront cost. Most homeowners never know this option exists.',
                tag: 'Legal Rights',
                tagColor: 'bg-orange/10 text-orange border-orange/20',
                icon: 'ri-scales-3-line',
                stat: '100%',
                statLabel: 'your legal right',
              },
              {
                num: '04',
                title: 'Depreciation Can Be Recovered — If You Know How',
                body: 'When your claim is approved, the insurance company pays Actual Cash Value (ACV) first — which deducts depreciation from your payout. Once the work is completed, you can file for the Recoverable Depreciation (RCV) to get the rest. Many homeowners never file for it and lose thousands. We walk you through every step.',
                tag: 'Depreciation',
                tagColor: 'bg-stone-100 text-stone-600 border-stone-200',
                icon: 'ri-refund-2-line',
                stat: 'RCV',
                statLabel: 'most homeowners never claim',
              },
              {
                num: '05',
                title: 'Matching Is Your Right — Not a Courtesy',
                body: 'If only part of your roof is damaged, your insurance company may try to replace just that section. But if the replacement shingles don\'t match the existing ones — due to age, color, or discontinued product — you are legally entitled to a full replacement in most states. Indiana and Kentucky both have strong matching laws. We know how to invoke them.',
                tag: 'Matching Laws',
                tagColor: 'bg-green-50 text-green-700 border-green-200',
                icon: 'ri-layout-grid-line',
                stat: 'IN & KY',
                statLabel: 'strong matching laws',
              },
              {
                num: '06',
                title: 'The Clock Starts the Day of the Storm — Not When You Notice',
                body: 'Your 12-month filing window begins on the date of the storm event, not the date you discover the damage. A slow leak from April hail might not show up as a ceiling stain until August — but your deadline is still April of next year. Don\'t wait until you see visible damage inside your home.',
                tag: 'Deadlines',
                tagColor: 'bg-red-50 text-red-600 border-red-200',
                icon: 'ri-time-line',
                stat: '12 mo.',
                statLabel: 'from storm date — not discovery',
              },
            ].map((tip) => (
              <div key={tip.num} className="group grid grid-cols-1 lg:grid-cols-[auto_1fr] gap-0 border border-stone-200 hover:border-orange/30 transition-colors duration-300 overflow-hidden">
                {/* Left accent bar */}
                <div className="hidden lg:flex flex-col items-center justify-between bg-stone-50 border-r border-stone-200 group-hover:border-orange/20 px-6 py-7 min-w-[120px] transition-colors">
                  <span className="font-display text-4xl text-stone-200 group-hover:text-orange/20 transition-colors leading-none">{tip.num}</span>
                  <div className="text-center">
                    <p className="font-display text-xl text-charcoal">{tip.stat}</p>
                    <p className="text-stone-400 text-xs leading-tight mt-1 max-w-[80px]">{tip.statLabel}</p>
                  </div>
                </div>
                {/* Content */}
                <div className="p-6 md:p-8">
                  <div className="flex flex-wrap items-start gap-3 mb-4">
                    <div className="w-9 h-9 flex-shrink-0 flex items-center justify-center bg-orange/10 text-orange">
                      <i className={`${tip.icon} text-base`} />
                    </div>
                    <div className="flex-1">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <span className={`inline-block border text-xs font-semibold uppercase tracking-wide px-2.5 py-0.5 ${tip.tagColor}`}>{tip.tag}</span>
                        <span className="lg:hidden text-stone-300 text-xs font-display">{tip.num}</span>
                      </div>
                      <h3 className="font-display text-base md:text-lg text-charcoal uppercase tracking-wide leading-snug">{tip.title}</h3>
                    </div>
                  </div>
                  <p className="text-stone-500 text-sm leading-relaxed">{tip.body}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Bottom CTA banner */}
          <div className="relative bg-charcoal-deep overflow-hidden">
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-0 right-0 w-64 h-64 bg-orange/10 rounded-full blur-3xl" />
            </div>
            <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6 px-8 md:px-12 py-8">
              <div className="flex items-start gap-5">
                <div className="w-12 h-12 flex-shrink-0 flex items-center justify-center bg-orange/15 text-orange">
                  <i className="ri-shield-user-line text-2xl" />
                </div>
                <div>
                  <p className="text-white font-display text-base md:text-lg uppercase tracking-wide mb-1">We Know Every One of These Tactics</p>
                  <p className="text-white/50 text-sm leading-relaxed max-w-lg">Our team has handled hundreds of claims and knows exactly how to counter every underpayment strategy. Let us put that knowledge to work for you — at no extra cost.</p>
                </div>
              </div>
              <div className="flex-shrink-0 flex flex-col sm:flex-row gap-3">
                <a
                  href="#claim-form"
                  className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-7 py-3.5 transition-colors uppercase tracking-wide whitespace-nowrap text-center"
                >
                  Start My Free Claim Review
                </a>
                <a
                  href="tel:8122135997"
                  className="border border-white/20 hover:border-white/40 text-white text-sm font-semibold px-7 py-3.5 transition-colors uppercase tracking-wide whitespace-nowrap text-center flex items-center justify-center gap-2"
                >
                  <i className="ri-phone-line" />
                  812-213-5997
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Storm Damage Photo Gallery */}
      <section className="py-16 md:py-24 bg-stone-50">
        <div className="w-full px-6 md:px-10 lg:px-16">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-orange/10 border border-orange/20 text-orange px-4 py-1.5 text-xs font-semibold uppercase tracking-wider mb-5">
              <i className="ri-image-2-line" />
              Real Results
            </div>
            <h2 className="font-display text-2xl md:text-4xl text-charcoal uppercase tracking-wide mt-1 mb-4">
              Storm Damage Photo Gallery
            </h2>
            <p className="text-stone-500 text-sm md:text-base max-w-2xl mx-auto leading-relaxed">
              Drag the slider on each photo to see the before &amp; after transformation. Every project below was an insurance claim we handled from inspection to completion.
            </p>
          </div>

          {/* Filter tabs */}
          <div className="flex flex-wrap justify-center gap-2 mb-10">
            {([
              { key: 'all', label: 'All Projects', icon: 'ri-grid-line' },
              { key: 'hail', label: 'Hail Damage', icon: 'ri-cloud-line' },
              { key: 'wind', label: 'Wind Damage', icon: 'ri-windy-line' },
              { key: 'water', label: 'Water Damage', icon: 'ri-drop-line' },
            ] as { key: GalleryFilter; label: string; icon: string }[]).map((tab) => (
              <button
                key={tab.key}
                type="button"
                onClick={() => setGalleryFilter(tab.key)}
                className={`inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold uppercase tracking-wide transition-colors duration-200 whitespace-nowrap cursor-pointer ${
                  galleryFilter === tab.key
                    ? 'bg-orange text-white'
                    : 'bg-white border border-stone-200 text-stone-500 hover:border-orange/40 hover:text-orange'
                }`}
              >
                <i className={tab.icon} />
                {tab.label}
                {tab.key === 'all' && (
                  <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                    galleryFilter === 'all' ? 'bg-white/20 text-white' : 'bg-stone-100 text-stone-400'
                  }`}>{galleryItems.length}</span>
                )}
              </button>
            ))}
          </div>

          {/* Gallery grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-14">
            {filteredGallery.map((item) => (
              <GalleryCard key={item.id} item={item} />
            ))}
          </div>

          {/* Stats bar */}
          <div className="bg-white border border-stone-200 p-6 md:p-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
              {[
                { value: '400+', label: 'Claims Handled', icon: 'ri-file-list-3-line' },
                { value: '$2.4M+', label: 'Total Recovered for Homeowners', icon: 'ri-money-dollar-circle-line' },
                { value: '94%', label: 'Claims Approved on First Submission', icon: 'ri-check-double-line' },
                { value: '$6,200', label: 'Average Supplement Increase', icon: 'ri-funds-line' },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="w-10 h-10 mx-auto mb-3 flex items-center justify-center bg-orange/10 text-orange">
                    <i className={`${stat.icon} text-lg`} />
                  </div>
                  <p className="font-display text-2xl md:text-3xl text-charcoal mb-1">{stat.value}</p>
                  <p className="text-stone-400 text-xs leading-tight">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Bottom CTA */}
          <div className="mt-10 text-center">
            <p className="text-stone-500 text-sm mb-5">Your home could be next. Get a free inspection and see what we can recover for you.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="#claim-form"
                className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-8 py-3.5 transition-colors uppercase tracking-wide whitespace-nowrap"
              >
                Start My Free Inspection
              </a>
              <a
                href="tel:8122135997"
                className="border border-stone-300 hover:border-orange text-charcoal hover:text-orange text-sm font-semibold px-8 py-3.5 transition-colors uppercase tracking-wide whitespace-nowrap flex items-center justify-center gap-2"
              >
                <i className="ri-phone-line" />
                812-213-5997
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 md:py-24 bg-white">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <span className="text-orange text-xs font-semibold uppercase tracking-widest">Common Questions</span>
              <h2 className="font-display text-2xl md:text-4xl text-charcoal uppercase tracking-wide mt-3">
                Insurance Claim FAQs
              </h2>
            </div>
            <div className="space-y-4">
              {[
                {
                  q: 'Will my insurance rates go up if I file a claim?',
                  a: 'In most cases, no. Storm damage claims are considered "Acts of God" and are treated differently than at-fault claims. Your rates are typically based on regional storm activity, not individual claims.',
                },
                {
                  q: 'How long do I have to file a claim after a storm?',
                  a: 'Most policies give you 1 year from the date of loss, but we recommend acting within 6 months. The sooner you file, the easier it is to prove the damage was storm-related.',
                },
                {
                  q: 'What if my insurance company denies my claim?',
                  a: 'We help you appeal. Often denials happen because damage was not properly documented. We re-inspect, take new photos, and work with your adjuster to get a fair second look.',
                },
                {
                  q: 'Do I need to get multiple estimates?',
                  a: 'No. Your insurance company will provide an estimate based on their pricing software. We review that estimate and supplement if it is too low. You do not need to shop around for the cheapest bid.',
                },
                {
                  q: 'Can you do the work if I already have an approved claim?',
                  a: 'Absolutely. If your claim is already approved, send us the paperwork and we will review the scope, schedule the work, and handle all communication with your insurance company.',
                },
              ].map((faq, i) => (
                <details key={i} className="group bg-stone-50 border border-stone-200 open:border-orange/30 transition-colors">
                  <summary className="flex items-center justify-between p-5 cursor-pointer list-none">
                    <span className="font-display text-sm text-charcoal uppercase tracking-wide pr-4">{faq.q}</span>
                    <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center bg-white border border-stone-200 text-stone-400 group-open:text-orange group-open:border-orange/30 transition-colors">
                      <i className="ri-add-line group-open:hidden" />
                      <i className="ri-subtract-line hidden group-open:block" />
                    </div>
                  </summary>
                  <div className="px-5 pb-5 text-stone-500 text-sm leading-relaxed">
                    {faq.a}
                  </div>
                </details>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 md:py-20 bg-charcoal-deep">
        <div className="w-full px-6 md:px-10 lg:px-16 text-center">
          <h2 className="font-display text-2xl md:text-4xl text-white uppercase tracking-wide mb-4">
            Do Not Let the Insurance Company Underpay You
          </h2>
          <p className="text-white/60 text-sm md:text-base max-w-xl mx-auto mb-8 leading-relaxed">
            Every day you wait, evidence fades and deadlines approach. Get your free storm damage inspection today and make sure you get the full payout your policy promises.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#claim-form"
              className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-8 py-3.5 transition-colors duration-200 text-center uppercase tracking-wide whitespace-nowrap"
            >
              Start Your Claim Now
            </a>
            <a
              href="tel:8122135997"
              className="border border-white/30 hover:border-white/60 text-white text-sm font-semibold px-8 py-3.5 transition-colors duration-200 text-center uppercase tracking-wide whitespace-nowrap flex items-center justify-center gap-2"
            >
              <i className="ri-phone-line" />
              812-213-5997
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}