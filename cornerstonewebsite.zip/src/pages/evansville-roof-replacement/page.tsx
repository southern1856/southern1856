import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const MATERIALS = [
  {
    id: 'architectural',
    name: 'Architectural Asphalt Shingles',
    icon: 'ri-home-2-line',
    badge: 'Best Value — #1 in Evansville',
    lifespan: '25–30 Years',
    cost: '$9,000 – $14,000',
    desc: 'The most popular roof replacement choice across Evansville neighborhoods. Dimensional shingles from GAF Timberline HDZ and Owens Corning Duration deliver a rich, layered look with Lifetime Limited Warranty coverage. Wind-rated to 130 mph — built for Indiana storm seasons.',
    features: ['Lifetime Limited Warranty', 'Class A Fire Rated', '130 mph Wind Rating', 'Algae Resistant Protection', 'Wide Color Selection', 'Affordable & Proven in Vanderburgh County'],
    image: '/placeholders/800x500.svg',
  },
  {
    id: 'metal',
    name: 'Standing Seam Metal',
    icon: 'ri-home-gear-line',
    badge: 'Longest Lifespan — 50+ Years',
    lifespan: '40–70 Years',
    cost: '$14,000 – $28,000',
    desc: 'The forever roof. Standing seam metal handles Indiana hail, ice dams, and 90 mph gusts better than any material on the market. Energy-efficient with cool-roof reflectivity that lowers summer AC bills. The last roof your Evansville home will ever need.',
    features: ['50+ Year Expected Life', 'Hail & Wind Proof', 'Energy Efficient Cool Roof', 'No Moss or Algae Growth', 'Fire Rated Class A', 'Increases Evansville Home Value'],
    image: '/placeholders/800x500.svg',
  },
  {
    id: 'designer',
    name: 'Designer Luxury Shingles',
    icon: 'ri-star-line',
    badge: 'Premium Curb Appeal',
    lifespan: '30–50 Years',
    cost: '$12,000 – $20,000',
    desc: 'Get the look of natural slate or cedar shake without the weight, maintenance, or cost. GAF Camelot II and Owens Corning Berkshire shingles are impact-rated and offer superior dimensional depth. Ideal for Evansville historic districts and high-end homes.',
    features: ['Authentic Slate & Shake Look', 'Impact Resistant Options', 'Superior Curb Appeal', 'Lifetime Warranty Coverage', 'Low Maintenance Luxury', 'Boosts Resale Value'],
    image: '/placeholders/800x500.svg',
  },
];

const WHY_REPLACE_NOW = [
  {
    icon: 'ri-water-flash-line',
    title: 'Leaks Compound Fast',
    desc: 'A small leak left for 6 months can turn a $9,000 Evansville roof replacement into a $25,000+ job that includes framing repair and interior restoration.',
  },
  {
    icon: 'ri-line-chart-line',
    title: 'Material Costs Keep Climbing',
    desc: 'Roofing materials have risen 15–30% over the past 3 years. Lock in today\'s pricing with a replacement now — before the next round of supplier increases hit Evansville.',
  },
  {
    icon: 'ri-home-heart-line',
    title: 'Protect Your Evansville Equity',
    desc: 'A failing roof is the #1 dealbreaker for home buyers. A new roof adds measurable value and makes your home market-ready whenever you decide to sell.',
  },
  {
    icon: 'ri-shield-check-line',
    title: 'Insurance Won\'t Wait Forever',
    desc: 'Most insurers require storm damage claims within 6–12 months. Waiting risks denied claims. Replace now and your insurance covers most of the cost.',
  },
  {
    icon: 'ri-sun-line',
    title: 'Beat the Next Storm Season',
    desc: 'Indiana storm season peaks April through September. A new roof installed now means you face the next hail event with confidence — not anxiety.',
  },
  {
    icon: 'ri-money-dollar-circle-line',
    title: 'Keep Savings Intact',
    desc: 'Finance your Evansville roof replacement at 0% interest and keep your emergency fund untouched. Smart homeowners finance, even when they have cash.',
  },
];

const FAQS = [
  {
    q: 'How much does a roof replacement cost in Evansville Indiana?',
    a: 'Most residential roof replacements in Evansville range from $9,000 to $18,000 depending on home size, roof pitch, material choice, and complexity. Architectural asphalt shingles on an average 2,000 sq ft Evansville home typically fall between $10,000 and $14,000. Metal roofing runs higher. Every project gets an exact written quote after our free on-site inspection.',
  },
  {
    q: 'Does my Evansville homeowner insurance cover a roof replacement?',
    a: 'If your roof damage is from a covered peril like hail, high wind, or falling debris — all common in Indiana — your insurance should cover most or all of the replacement cost. Our team meets your adjuster on-site, documents all damage with photos, and handles the entire claim process. Most storm damage customers pay only their deductible.',
  },
  {
    q: 'How long does a roof replacement take on an Evansville home?',
    a: 'Most residential replacements are completed in a single day — typically 6–8 hours for an average-sized Evansville home. Larger homes, steep pitches, or complex roof lines may take 2 days. We provide a specific timeline during your free estimate and never leave the site messy.',
  },
  {
    q: 'What roofing material do you recommend for Evansville weather?',
    a: 'For most Evansville homeowners, GAF Timberline HDZ architectural shingles hit the sweet spot — excellent durability, 130 mph wind rating, algae resistance, and a Lifetime Limited Warranty at a reasonable price. For maximum Indiana weather protection, standing seam metal is the best-performing option, especially for homes that get frequent hail.',
  },
  {
    q: 'Do you offer financing for Evansville roof replacements?',
    a: 'Yes. We offer 0% interest plans, low monthly payments starting at $89/month, and 90-day deferred options for storm damage claims. Same-day approval is available for most applicants. Visit our financing page or call 812-213-5997 to check your options.',
  },
  {
    q: 'What warranties come with an Evansville roof replacement?',
    a: 'As GAF Master Elite contractors — a certification held by only 3% of roofers nationwide — we offer the GAF Golden Pledge warranty. It covers materials AND labor for up to 25 years with no dollar limit. It is the strongest residential roofing warranty in America, and it is available exclusively for Evansville homeowners who choose Corner Stone.',
  },
  {
    q: 'Do I need permits for a roof replacement in Evansville?',
    a: 'Yes, the City of Evansville and Vanderburgh County require building permits for roof replacements. Corner Stone handles all permit applications and inspections as part of your project — you never need to visit City Hall. We know the Evansville building department and their inspectors well.',
  },
  {
    q: 'What happens to my old roof during replacement?',
    a: 'We strip the old shingles down to the decking, inspect for any hidden damage, replace any rotted decking, and install the new roofing system. All debris is collected in dump trailers — never on your lawn. We do a full magnetic sweep for nails before we leave. Your Evansville property is left cleaner than we found it.',
  },
];

const SHINGLE_COLORS = [
  { name: 'Charcoal', hex: '#3a3a3a' },
  { name: 'Weathered Wood', hex: '#7a6a52' },
  { name: 'Pewter Gray', hex: '#8a8a8a' },
  { name: 'Barkwood', hex: '#5c4a32' },
  { name: 'Shakewood', hex: '#6b5a42' },
  { name: 'Slate', hex: '#5a6070' },
  { name: 'Oyster Gray', hex: '#b0a898' },
  { name: 'Hickory', hex: '#6a5040' },
];

const schema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: FAQS.map((f) => ({
    '@type': 'Question',
    name: f.q,
    acceptedAnswer: { '@type': 'Answer', text: f.a },
  })),
};

export default function EvansvilleRoofReplacementPage() {
  const navigate = useNavigate();
  const [activeMaterial, setActiveMaterial] = useState(MATERIALS[0]);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [charCount, setCharCount] = useState(0);
  const formRef = useRef<HTMLFormElement>(null);

  const heroAnim = useScrollAnimation();
  const materialsAnim = useScrollAnimation({ threshold: 0.05 });
  const whyAnim = useScrollAnimation({ threshold: 0.1 });
  const faqAnim = useScrollAnimation({ threshold: 0.1 });
  const formAnim = useScrollAnimation({ threshold: 0.1 });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;
    const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
    const notes = formData.get('notes') as string;
    if (notes && notes.length > 500) return;
    setFormStatus('submitting');
    try {
      const res = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      if (res.ok) { setFormStatus('success'); formRef.current.reset(); setCharCount(0); }
      else setFormStatus('error');
    } catch { setFormStatus('error'); }
  };

  const openReaddyAgent = (prefill?: string) => {
    const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
    if (btn) btn.click();
    if (prefill) {
      setTimeout(() => {
        const input = document.querySelector('input[placeholder*="message"], textarea[placeholder*="message"], input[placeholder*="ask"], textarea[placeholder*="ask"]') as HTMLInputElement | HTMLTextAreaElement | null;
        if (input) {
          input.value = prefill;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          const form = input.closest('form');
          if (form) {
            const submitBtn = form.querySelector('button[type="submit"], button[aria-label*="send"], button svg') as HTMLElement | null;
            if (submitBtn) submitBtn.click();
          }
        }
      }, 900);
    }
  };

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roof Replacement Evansville IN | New Roof Installation & Estimates | Corner Stone"
        description="Evansville Indiana roof replacement contractor. Full tear-off and new roof installation. Asphalt shingles, metal roofing, designer shingles. GAF Master Elite with Golden Pledge warranty. Free inspection & estimate. Financing from $89/month. Call 812-213-5997."
        keywords="roof replacement Evansville, Evansville roof replacement, new roof Evansville Indiana, roof installation Evansville IN, GAF Master Elite Evansville, roof replacement cost Evansville, Evansville roofing contractor, Vanderburgh County roof replacement"
        canonical="/evansville-roof-replacement"
        schema={schema}
      />

      {/* ── Hero ── */}
      <section className="relative min-h-screen flex flex-col overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1400x900.svg"
            alt="Roof replacement contractor in Evansville Indiana"
            className="w-full h-full object-cover object-top opacity-35"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/60 via-charcoal-deep/40 to-charcoal-deep" />
        </div>

        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 flex-1 flex flex-col justify-center px-6 md:px-10 lg:px-16 pt-32 md:pt-36 pb-16 anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-wrap items-center gap-3 mb-8">
            <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange" />
              GAF Master Elite — Top 3% Nationwide
            </div>
            <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange" />
              Most Evansville Jobs Done in 1 Day
            </div>
            <div className="flex items-center gap-2 border border-orange/40 bg-orange/10 backdrop-blur-sm px-4 py-2 text-orange text-xs uppercase tracking-widest">
              <i className="ri-shield-check-line text-sm" />
              Golden Pledge 25-Year Warranty
            </div>
          </div>

          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 9vw, 10rem)' }}>
            Evansville Roof<br />Replacement.<br /><span className="text-orange">No Shortcuts.</span>
          </h1>

          <div className="flex flex-col lg:flex-row lg:items-end gap-8 lg:gap-16">
            <p className="text-white/50 text-base md:text-lg max-w-xl leading-relaxed">
              Full tear-off roof replacement for Evansville homeowners who want it done right. GAF Master Elite installation, Golden Pledge warranty, and honest pricing — from East Side to West Side and every neighborhood in Vanderburgh County.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 flex-shrink-0">
              <button
                onClick={() => document.getElementById('evv-replace-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <i className="ri-home-smile-line" />
                Free Evansville Estimate
              </button>
              <a
                href="tel:8122135997"
                className="border border-white/30 hover:border-orange text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-phone-line text-orange" />
                812-213-5997
              </a>
            </div>
          </div>
        </div>

        {/* Bottom stats */}
        <div className="relative z-10 border-t border-white/10 grid grid-cols-2 md:grid-cols-4">
          {[
            { val: '1,200+', label: 'Evansville Roofs Replaced' },
            { val: '1 Day', label: 'Average Installation' },
            { val: '25yr', label: 'Golden Pledge Warranty' },
            { val: '$0', label: 'Out-of-Pocket (Storm Claims)' },
          ].map((s, i) => (
            <div key={s.label} className={`px-6 md:px-10 py-6 md:py-8 ${i < 3 ? 'border-r border-white/10' : ''}`}>
              <p className="font-display text-white text-3xl md:text-4xl tracking-wider">{s.val}</p>
              <p className="text-white/40 text-xs uppercase tracking-widest mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      <TalkToAIExpert />

      {/* ── Materials ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Roofing Materials</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
            Choose Your Evansville
            <br />
            <span className="text-white/50">Replacement Roof</span>
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            We install every major residential roofing system. Pick the material that matches your Evansville home, budget, and long-term goals.
          </p>
        </div>

        <div
          ref={materialsAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 lg:grid-cols-5 gap-6"
        >
          {/* Material selector */}
          <div className="lg:col-span-2 flex flex-col gap-3">
            {MATERIALS.map((mat, i) => (
              <button
                key={mat.id}
                onClick={() => setActiveMaterial(mat)}
                className={`text-left border p-5 transition-all duration-300 cursor-pointer group anim-fade-up ${materialsAnim.isVisible ? 'is-visible' : ''} ${activeMaterial.id === mat.id ? 'border-orange bg-orange/10' : 'border-white/10 bg-charcoal-mid hover:border-white/30'}`}
                style={{ transitionDelay: `${i * 80}ms` }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-orange text-xs uppercase tracking-wider font-bold">{mat.badge}</span>
                  <span className="text-white/30 text-xs">{mat.lifespan}</span>
                </div>
                <h3 className={`font-display text-xl uppercase tracking-wider transition-colors ${activeMaterial.id === mat.id ? 'text-orange' : 'text-white group-hover:text-orange'}`}>
                  {mat.name}
                </h3>
                <p className="text-white/45 text-sm mt-2">{mat.cost}</p>
              </button>
            ))}
          </div>

          {/* Material detail */}
          <div className="lg:col-span-3 flex flex-col gap-4">
            <div className="relative w-full overflow-hidden" style={{ height: '300px' }}>
              <img
                key={activeMaterial.id}
                src={activeMaterial.image}
                alt={activeMaterial.name}
                className="w-full h-full object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-deep/80 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="flex items-center gap-3">
                  <span className="text-white/50 text-xs">{activeMaterial.lifespan}</span>
                  <span className="text-orange text-sm font-bold">{activeMaterial.cost}</span>
                </div>
                <h3 className="font-display text-white text-3xl uppercase tracking-wider mt-2">{activeMaterial.name}</h3>
              </div>
            </div>

            <div className="border border-white/10 bg-charcoal-mid p-6 md:p-8 flex-1">
              <p className="text-white/60 text-sm leading-relaxed mb-6">{activeMaterial.desc}</p>
              <div className="grid grid-cols-2 gap-2 mb-6">
                {activeMaterial.features.map((f) => (
                  <div key={f} className="flex items-center gap-2 text-white/50 text-xs">
                    <i className="ri-check-line text-orange text-sm" />
                    {f}
                  </div>
                ))}
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => document.getElementById('evv-replace-form')?.scrollIntoView({ behavior: 'smooth' })}
                  className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-6 py-3 uppercase tracking-wide transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                >
                  Get {activeMaterial.name.split(' ')[0]} Quote
                  <i className="ri-arrow-right-line" />
                </button>
                <button
                  onClick={() => navigate('/roof-financing')}
                  className="border border-white/20 hover:border-orange text-white/70 hover:text-white text-sm font-semibold px-6 py-3 uppercase tracking-wide transition-all whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                >
                  <i className="ri-bank-card-line text-orange" />
                  See Financing
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Shingle Color Selector ── */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal-mid border-y border-white/10">
        <div className="text-center mb-10">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">Popular in Evansville</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(1.8rem, 4vw, 3.5rem)' }}>
            Pick Your Shingle Color
          </h2>
          <p className="text-white/40 text-sm mt-3 max-w-lg mx-auto">
            We carry the full GAF and Owens Corning color lines. These are the most popular shingle colors on Evansville homes.
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-4 max-w-3xl mx-auto">
          {SHINGLE_COLORS.map((color) => (
            <div key={color.name} className="flex flex-col items-center gap-2 cursor-pointer group">
              <div
                className="w-14 h-14 rounded-full border-2 border-white/10 group-hover:border-orange transition-all duration-200 shadow-inner"
                style={{ backgroundColor: color.hex }}
              />
              <span className="text-white/40 text-xs group-hover:text-white/70 transition-colors">{color.name}</span>
            </div>
          ))}
        </div>
        <p className="text-center text-white/25 text-xs mt-8">
          We bring physical samples to your free Evansville inspection so you can see them on your actual home.
        </p>
      </section>

      {/* ── Why Replace Now ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Don't Wait Until It's Too Late</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Why Evansville Homeowners
            <br />
            <span className="text-white/50">Replace Now — Not Later</span>
          </h2>
        </div>

        <div
          ref={whyAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {WHY_REPLACE_NOW.map((item, i) => (
            <div
              key={item.title}
              className={`border border-white/10 bg-charcoal-mid p-8 hover:border-orange/30 transition-all duration-300 group anim-fade-up ${whyAnim.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 70}ms` }}
            >
              <div className="w-12 h-12 flex items-center justify-center bg-orange/15 group-hover:bg-orange/25 transition-colors mb-5">
                <i className={`${item.icon} text-orange text-xl`} />
              </div>
              <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">{item.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Process ── */}
      <section className="py-20 md:py-28 px-4 md:px-10 lg:px-16 bg-charcoal-mid">
        <div className="text-center mb-14 md:mb-20">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">The Evansville Replacement Process</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
            New Roof in 4 Steps.
            <br />
            <span className="text-white/50">Most Done in 1 Day.</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 md:gap-6">
          {[
            { num: '01', title: 'Free Inspection & Quote', desc: 'We inspect your Evansville roof, attic, and flashing. You get a full written estimate with material options and honest recommendations the same day.' },
            { num: '02', title: 'Permit & Material Order', desc: 'We pull all required Evansville and Vanderburgh County permits. Materials arrive at your home the morning of installation — never days before.' },
            { num: '03', title: 'Expert Installation', desc: 'Our certified crew strips the old roof, inspects the decking, and installs your new system. Clean worksite, magnetic nail sweep, and total respect for your property.' },
            { num: '04', title: 'Final Walkthrough & Warranty', desc: 'We walk the finished roof with you, register your Golden Pledge warranty, and hand over all documentation. You pay only when you are 100% satisfied.' },
          ].map((step, i) => (
            <div key={step.num} className="relative">
              {i < 3 && (
                <div className="hidden md:block absolute top-8 left-full w-full h-px bg-white/10" />
              )}
              <span className="font-display text-white/10 text-5xl md:text-6xl leading-none block mb-4">{step.num}</span>
              <h3 className="font-serif font-bold text-white text-lg md:text-xl mb-3">{step.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Insurance Claims ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <div className="w-full overflow-hidden" style={{ height: '460px' }}>
              <img
                src="/placeholders/700x460.svg"
                alt="Insurance claim roof replacement Evansville"
                className="w-full h-full object-cover object-top"
              />
            </div>
            <div className="absolute bottom-6 left-6 right-6 bg-charcoal-deep/90 border border-white/10 p-5">
              <div className="flex items-center gap-3 mb-2">
                <i className="ri-money-dollar-circle-line text-orange text-xl" />
                <p className="text-white font-semibold text-sm">Most Storm Claims = $0 Out-of-Pocket</p>
              </div>
              <p className="text-white/40 text-xs leading-relaxed">
                We handle everything — from damage documentation to adjuster meetings. You pay your deductible, insurance covers the rest.
              </p>
            </div>
          </div>

          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Indiana Storm Damage?</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              Your Insurance Pays.
              <br />
              <span className="text-white/50">We Handle the Rest.</span>
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
              Evansville gets hit hard by hail and high winds. If your roof has storm damage, your homeowner insurance likely covers a full replacement. Corner Stone are insurance claim specialists — we document every damaged shingle, meet your adjuster on-site, and fight to maximize your payout.
            </p>
            <div className="space-y-4 mb-8">
              {[
                { icon: 'ri-search-eye-line', text: 'Free storm damage inspection — often same-day' },
                { icon: 'ri-file-list-3-line', text: 'Complete damage documentation with labeled photos' },
                { icon: 'ri-user-voice-line', text: 'We meet your adjuster and advocate for your claim' },
                { icon: 'ri-check-double-line', text: 'Approved claims = full replacement, you pay only deductible' },
              ].map((item) => (
                <div key={item.text} className="flex items-center gap-3 text-white/50 text-sm">
                  <i className={`${item.icon} text-orange text-base flex-shrink-0`} />
                  {item.text}
                </div>
              ))}
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => navigate('/insurance-claims')}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap"
              >
                <i className="ri-shield-check-line" />
                How Insurance Claims Work
              </button>
              <button
                onClick={() => document.getElementById('evv-replace-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap"
              >
                Free Damage Check
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal-mid">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Common Questions</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Evansville Roof Replacement FAQ
            </h2>
          </div>
          <div
            ref={faqAnim.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${faqAnim.isVisible ? 'is-visible' : ''}`}
          >
            {FAQS.map((faq, i) => (
              <div key={i} className="border-b border-white/10">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between py-5 text-left cursor-pointer group"
                >
                  <span className="font-display text-white text-lg uppercase tracking-wider pr-4 group-hover:text-orange transition-colors">{faq.q}</span>
                  <div className={`w-8 h-8 flex items-center justify-center border flex-shrink-0 transition-all duration-300 ${openFaq === i ? 'bg-orange border-orange text-white' : 'border-white/20 text-white/40 group-hover:border-orange group-hover:text-orange'}`}>
                    <i className={`ri-${openFaq === i ? 'subtract' : 'add'}-line`} />
                  </div>
                </button>
                <div className={`overflow-hidden transition-all duration-500 ${openFaq === i ? 'max-h-56 opacity-100 pb-5' : 'max-h-0 opacity-0'}`}>
                  <p className="text-white/50 text-sm leading-relaxed pr-12">{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Estimate Form ── */}
      <section id="evv-replace-form" className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div
          ref={formAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${formAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            <div>
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Free Evansville Estimate</p>
              <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 5vw, 5rem)' }}>
                Ready for a New
                <br />
                <span className="text-orange">Evansville Roof?</span>
              </h2>
              <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
                Fill out the form and we will contact you within 2 hours to schedule your free on-site inspection. We will measure, assess, and give you an exact written quote — no pressure, no games, just honest numbers.
              </p>
              <div className="space-y-4 mb-8">
                {[
                  { icon: 'ri-timer-line', text: 'Response within 2 hours, same-day available' },
                  { icon: 'ri-search-eye-line', text: 'Free on-site inspection with photo report' },
                  { icon: 'ri-file-list-3-line', text: 'Written, itemized quote — zero hidden fees' },
                  { icon: 'ri-shield-check-line', text: 'GAF Golden Pledge warranty included' },
                ].map((item) => (
                  <div key={item.text} className="flex items-center gap-3 text-white/50 text-sm">
                    <i className={`${item.icon} text-orange text-base`} />
                    {item.text}
                  </div>
                ))}
              </div>

              <div className="border border-orange/20 bg-orange/5 p-5 mb-8">
                <div className="flex items-start gap-3">
                  <i className="ri-bank-card-line text-orange text-xl flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-white font-semibold text-sm mb-1">Financing from $89/Month</p>
                    <p className="text-white/40 text-xs leading-relaxed">
                      0% interest plans available. 90-day deferred option for storm claims. Same-day approval. Check your options during your free estimate.
                    </p>
                  </div>
                </div>
              </div>

              <div className="pt-8 border-t border-white/10">
                <p className="text-white/30 text-xs uppercase tracking-widest mb-3">Or call us directly</p>
                <a href="tel:8122135997" className="flex items-center gap-3 text-white hover:text-orange transition-colors">
                  <i className="ri-phone-fill text-orange text-xl" />
                  <span className="font-display text-2xl tracking-wider">812-213-5997</span>
                </a>
              </div>
            </div>

            <div className="bg-white rounded-2xl overflow-hidden">
              <div className="bg-charcoal-deep px-8 py-6 border-b border-white/10">
                <h3 className="font-display text-white text-2xl uppercase tracking-wider">Free Replacement Estimate</h3>
                <p className="text-white/50 text-sm mt-1">For Evansville & Vanderburgh County homeowners</p>
              </div>

              {formStatus === 'success' ? (
                <div className="px-8 py-14 flex flex-col items-center text-center">
                  <div className="w-16 h-16 flex items-center justify-center bg-green-100 rounded-full mb-4">
                    <i className="ri-checkbox-circle-fill text-green-600 text-3xl" />
                  </div>
                  <h4 className="font-display text-charcoal text-2xl uppercase tracking-wider mb-2">Estimate Request Received!</h4>
                  <p className="text-gray-500 text-sm leading-relaxed max-w-xs">
                    We will contact you within 2 hours to schedule your free Evansville roof inspection. Talk soon!
                  </p>
                  <button onClick={() => setFormStatus('idle')} className="mt-6 text-orange text-sm font-semibold underline underline-offset-4 cursor-pointer">
                    Submit another request
                  </button>
                </div>
              ) : (
                <form
                  ref={formRef}
                  data-readdy-form
                  onSubmit={handleSubmit}
                  className="px-8 py-7 space-y-4"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">First Name</label>
                      <input type="text" name="first_name" required placeholder="John" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Last Name</label>
                      <input type="text" name="last_name" required placeholder="Smith" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Phone</label>
                    <input type="tel" name="phone" required placeholder="812-000-0000" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Email</label>
                    <input type="email" name="email" required placeholder="you@email.com" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Evansville Address</label>
                    <input type="text" name="address" required placeholder="123 Main St, Evansville, IN 47725" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Material Preference</label>
                      <select name="material_preference" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                        <option value="">Select material</option>
                        <option value="asphalt">Architectural Asphalt Shingles</option>
                        <option value="metal">Standing Seam Metal</option>
                        <option value="designer">Designer / Luxury Shingles</option>
                        <option value="unsure">Not Sure — Need Recommendation</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Timeline</label>
                      <select name="timeline" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                        <option value="">Select timeline</option>
                        <option value="urgent">ASAP — Leaking / Emergency</option>
                        <option value="this_month">This Month</option>
                        <option value="next_month">Next Month</option>
                        <option value="planning">Planning Ahead — 2–3 Months</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Insurance Claim?</label>
                    <select name="insurance_claim" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                      <option value="">Select option</option>
                      <option value="yes">Yes — Storm damage, filing a claim</option>
                      <option value="maybe">Maybe — Need inspection first</option>
                      <option value="no">No — Paying out of pocket</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                      Additional Notes <span className="text-gray-400 font-normal normal-case">(optional)</span>
                    </label>
                    <textarea
                      name="notes"
                      rows={3}
                      maxLength={500}
                      onChange={(e) => setCharCount(e.target.value.length)}
                      placeholder="Roof age, known issues, storm date, questions about materials or financing..."
                      className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
                    />
                    <p className={`text-xs mt-1 text-right ${charCount > 500 ? 'text-red-500' : 'text-gray-400'}`}>{charCount}/500</p>
                  </div>
                  <button
                    type="submit"
                    disabled={formStatus === 'submitting'}
                    className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-300 text-white font-bold text-sm uppercase tracking-widest py-4 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  >
                    {formStatus === 'submitting' ? (
                      <><i className="ri-loader-4-line animate-spin" />Sending...</>
                    ) : (
                      <><i className="ri-home-smile-line" />Get My Free Evansville Estimate</>
                    )}
                  </button>
                  {formStatus === 'error' && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2">
                      <i className="ri-alert-line text-red-500" />
                      <p className="text-red-600 text-xs">Something went wrong. Please call 812-213-5997 directly.</p>
                    </div>
                  )}
                  <p className="text-gray-400 text-xs text-center">
                    <i className="ri-lock-line mr-1" />Your information is private and secure. No spam, ever.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ── Final CTA ── */}
      <section className="py-20 md:py-28 px-4 md:px-10 lg:px-16 bg-charcoal-mid text-center">
        <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
          Your Evansville Home
          <br />
          <span className="text-orange">Deserves the Best Roof</span>
        </h2>
        <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-lg mx-auto mb-8">
          Since 1995, Corner Stone has replaced over 1,200 roofs in Evansville and Vanderburgh County. GAF Master Elite certified. Golden Pledge warranty. Financing from $89/month. One call and we handle everything — from permits to final cleanup.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
          <button
            onClick={() => document.getElementById('evv-replace-form')?.scrollIntoView({ behavior: 'smooth' })}
            className="group bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-all duration-300 whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
          >
            Get Free Evansville Estimate
            <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform duration-200" />
          </button>
          <a
            href="tel:8122135997"
            className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-all duration-300 whitespace-nowrap flex items-center justify-center gap-3"
          >
            <i className="ri-phone-line text-orange" />
            812-213-5997
          </a>
        </div>
        <div className="mt-6 flex justify-center">
          <button
            onClick={() => openReaddyAgent("How much does a roof replacement cost in Evansville Indiana?")}
            className="group flex items-center gap-2 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-question-answer-line text-sm" />
            <span className="underline underline-offset-2">Ask AI about Evansville replacement costs</span>
            <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>
      </section>
    </div>
  );
}