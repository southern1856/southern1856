import { useState, useRef } from 'react';
import PageSEO from '@/components/feature/PageSEO';

interface MaintenanceTask {
  id: string;
  month: string;
  monthShort: string;
  season: string;
  task: string;
  area: string;
  description: string;
  severity: 'Critical' | 'Important' | 'Routine';
}

const tasks: MaintenanceTask[] = [
  // JANUARY
  {
    id: 'jan1',
    month: 'January',
    monthShort: 'JAN',
    season: 'Winter',
    task: 'Check attic for frost or condensation buildup',
    area: 'Attic',
    description: 'Frost on nails or condensation on rafters means poor ventilation. This leads to mold, rot, and shortened shingle life.',
    severity: 'Critical',
  },
  {
    id: 'jan2',
    month: 'January',
    monthShort: 'JAN',
    season: 'Winter',
    task: 'Inspect interior ceilings and walls for water stains',
    area: 'Interior',
    description: 'Winter leaks often start small. A yellowish stain on the ceiling is the first sign of a compromised roof seal.',
    severity: 'Critical',
  },
  {
    id: 'jan3',
    month: 'January',
    monthShort: 'JAN',
    season: 'Winter',
    task: 'Monitor roof edges for ice dam formation',
    area: 'Roof',
    description: 'Icicles hanging from gutters are a warning sign. Ice dams force water under shingles and into your home.',
    severity: 'Important',
  },
  {
    id: 'jan4',
    month: 'January',
    monthShort: 'JAN',
    season: 'Winter',
    task: 'Clear heavy snow accumulation from valleys',
    area: 'Roof',
    description: 'Snow deeper than 6 inches in roof valleys adds significant weight and can trap meltwater. Use a roof rake from the ground.',
    severity: 'Routine',
  },

  // FEBRUARY
  {
    id: 'feb1',
    month: 'February',
    monthShort: 'FEB',
    season: 'Winter',
    task: 'Schedule spring professional roof inspection',
    area: 'Roof',
    description: 'The best roofers book up by March. Schedule your inspection now to get on the calendar before spring rush.',
    severity: 'Important',
  },
  {
    id: 'feb2',
    month: 'February',
    monthShort: 'FEB',
    season: 'Winter',
    task: 'Check exterior walls for moisture damage near roofline',
    area: 'Siding',
    description: 'Water running down from a compromised roof edge often shows up as peeling paint or soft siding below the eaves.',
    severity: 'Critical',
  },
  {
    id: 'feb3',
    month: 'February',
    monthShort: 'FEB',
    season: 'Winter',
    task: 'Inspect soffit vents for blockage from insulation',
    area: 'Attic',
    description: 'Insulation pushed against soffit vents blocks airflow and causes ice dams. Baffles should keep insulation 2-3 inches back.',
    severity: 'Important',
  },
  {
    id: 'feb4',
    month: 'February',
    monthShort: 'FEB',
    season: 'Winter',
    task: 'Trim back tree branches near roof (if accessible)',
    area: 'Trees',
    description: 'Winter is the best time to trim deciduous trees. No leaves means you can see branch structure and roof contact points clearly.',
    severity: 'Routine',
  },

  // MARCH
  {
    id: 'mar1',
    month: 'March',
    monthShort: 'MAR',
    season: 'Spring',
    task: 'Professional roof inspection after winter thaw',
    area: 'Roof',
    description: 'Winter contraction and expansion crack sealant and loosen flashing. A professional inspection catches this before spring rains.',
    severity: 'Critical',
  },
  {
    id: 'mar2',
    month: 'March',
    monthShort: 'MAR',
    season: 'Spring',
    task: 'Clean gutters and downspouts of leaves and debris',
    area: 'Gutters',
    description: 'Clogged gutters overflow and rot fascia boards. Spring rains will test your drainage system — make sure it passes.',
    severity: 'Important',
  },
  {
    id: 'mar3',
    month: 'March',
    monthShort: 'MAR',
    season: 'Spring',
    task: 'Inspect shingles for curling, cracking, or missing pieces',
    area: 'Roof',
    description: 'Winter wind and ice expose damage that was hidden under snow. Look for bare spots, lifted tabs, and shingle grit in the gutters.',
    severity: 'Critical',
  },
  {
    id: 'mar4',
    month: 'March',
    monthShort: 'MAR',
    season: 'Spring',
    task: 'Check flashing around chimneys, vents, and skylights',
    area: 'Roof',
    description: 'Flashing is the #1 source of leaks. Winter movement loosens sealant. Re-caulk any gaps with roofing-grade sealant.',
    severity: 'Critical',
  },

  // APRIL
  {
    id: 'apr1',
    month: 'April',
    monthShort: 'APR',
    season: 'Spring',
    task: 'Inspect gutters for sagging, loose hangers, or leaks',
    area: 'Gutters',
    description: 'Winter ice pulls gutters away from the fascia. A sagging gutter does not drain — it holds water and accelerates rot.',
    severity: 'Important',
  },
  {
    id: 'apr2',
    month: 'April',
    monthShort: 'APR',
    season: 'Spring',
    task: 'Check attic ventilation for wasp or bird nests',
    area: 'Attic',
    description: 'Spring is when animals nest in vents. Blocked ventilation leads to heat buildup in summer and ice dams next winter.',
    severity: 'Routine',
  },
  {
    id: 'apr3',
    month: 'April',
    monthShort: 'APR',
    season: 'Spring',
    task: 'Inspect siding for cracks or water stains below roof lines',
    area: 'Siding',
    description: 'Stained or warped siding beneath the roof edge is a telltale sign of water running behind the gutter or through the fascia.',
    severity: 'Important',
  },
  {
    id: 'apr4',
    month: 'April',
    monthShort: 'APR',
    season: 'Spring',
    task: 'Check downspout extensions and drainage direction',
    area: 'Gutters',
    description: 'Water should discharge at least 6 feet from the foundation. Spring rains reveal if your drainage is undermining your basement.',
    severity: 'Routine',
  },

  // MAY
  {
    id: 'may1',
    month: 'May',
    monthShort: 'MAY',
    season: 'Spring',
    task: 'Document roof condition with dated photos',
    area: 'Roof',
    description: 'Take photos of every roof surface, valleys, and penetrations. This baseline helps you and your insurance adjuster after future storms.',
    severity: 'Important',
  },
  {
    id: 'may2',
    month: 'May',
    monthShort: 'MAY',
    season: 'Spring',
    task: 'Inspect for hail damage after spring storms',
    area: 'Roof',
    description: 'Soft metal vents and gutters show hail damage most clearly. Dented vents mean shingles took impact too — get an inspection.',
    severity: 'Critical',
  },
  {
    id: 'may3',
    month: 'May',
    monthShort: 'MAY',
    season: 'Spring',
    task: 'Check fascia and soffit boards for rot or insect damage',
    area: 'Siding',
    description: 'Probe the fascia with a screwdriver. Soft wood means rot, often from gutter overflow or roof edge leaks.',
    severity: 'Important',
  },
  {
    id: 'may4',
    month: 'May',
    monthShort: 'MAY',
    season: 'Spring',
    task: 'Trim all tree branches within 6 feet of the roof',
    area: 'Trees',
    description: 'Branches scratch shingles in wind, drop debris that clogs gutters, and provide a highway for squirrels and raccoons.',
    severity: 'Routine',
  },

  // JUNE
  {
    id: 'jun1',
    month: 'June',
    monthShort: 'JUN',
    season: 'Summer',
    task: 'Inspect attic temperature during peak heat',
    area: 'Attic',
    description: 'Attic temps above 120 degrees mean inadequate ventilation. Excessive heat bakes shingles from below and spikes cooling bills.',
    severity: 'Important',
  },
  {
    id: 'jun2',
    month: 'June',
    monthShort: 'JUN',
    season: 'Summer',
    task: 'Check for shingle granule loss in gutters and downspouts',
    area: 'Roof',
    description: 'Granules protect shingles from UV. Heavy granule buildup in gutters means your shingles are aging rapidly and need professional evaluation.',
    severity: 'Important',
  },
  {
    id: 'jun3',
    month: 'June',
    monthShort: 'JUN',
    season: 'Summer',
    task: 'Inspect sealant around plumbing vents and exhaust fans',
    area: 'Roof',
    description: 'Heat causes sealant to crack and pull away from vent pipes. A $5 tube of sealant prevents a $500 interior repair.',
    severity: 'Routine',
  },
  {
    id: 'jun4',
    month: 'June',
    monthShort: 'JUN',
    season: 'Summer',
    task: 'Check exterior paint and caulk on dormers and gables',
    area: 'Siding',
    description: 'Summer sun degrades caulk and paint. Cracked caulk where dormers meet the roof is a direct path for rainwater.',
    severity: 'Routine',
  },

  // JULY
  {
    id: 'jul1',
    month: 'July',
    monthShort: 'JUL',
    season: 'Summer',
    task: 'Inspect for wind-lifted shingles after summer storms',
    area: 'Roof',
    description: 'July thunderstorms pack wind that lifts shingle tabs. Lifted shingles are not yet leaking but will be with the next rain.',
    severity: 'Critical',
  },
  {
    id: 'jul2',
    month: 'July',
    monthShort: 'JUL',
    season: 'Summer',
    task: 'Check gutters for granule accumulation and clear it',
    area: 'Gutters',
    description: 'If granules are filling your gutters monthly, your shingles are actively shedding protection. Schedule a roof evaluation.',
    severity: 'Important',
  },
  {
    id: 'jul3',
    month: 'July',
    monthShort: 'JUL',
    season: 'Summer',
    task: 'Inspect roof penetrations (AC units, satellite dishes) for seal integrity',
    area: 'Roof',
    description: 'Every hole in your roof is a leak waiting to happen. Check the rubber boots around pipes and the sealant around mounted equipment.',
    severity: 'Routine',
  },
  {
    id: 'jul4',
    month: 'July',
    monthShort: 'JUL',
    season: 'Summer',
    task: 'Check for moss or algae growth on shaded roof areas',
    area: 'Roof',
    description: 'Moss holds moisture against shingles and accelerates decay. Zinc or copper strips at the ridge prevent regrowth after cleaning.',
    severity: 'Routine',
  },

  // AUGUST
  {
    id: 'aug1',
    month: 'August',
    monthShort: 'AUG',
    season: 'Summer',
    task: 'Schedule fall gutter cleaning and roof inspection',
    area: 'Gutters',
    description: 'Roofers and gutter companies book up in September. Schedule now to beat the fall rush and lock in pricing.',
    severity: 'Important',
  },
  {
    id: 'aug2',
    month: 'August',
    monthShort: 'AUG',
    season: 'Summer',
    task: 'Inspect attic insulation depth and condition',
    area: 'Attic',
    description: 'Proper insulation keeps attic temperatures stable. Blown insulation settles over time. R-38 to R-60 is recommended for Indiana.',
    severity: 'Routine',
  },
  {
    id: 'aug3',
    month: 'August',
    monthShort: 'AUG',
    season: 'Summer',
    task: 'Check for proper bathroom and kitchen exhaust venting',
    area: 'Attic',
    description: 'Exhaust fans that vent into the attic dump moisture directly onto your rafters. Ducts should vent outside through the roof or soffit.',
    severity: 'Important',
  },
  {
    id: 'aug4',
    month: 'August',
    monthShort: 'AUG',
    season: 'Summer',
    task: 'Inspect drip edge for separation or rust',
    area: 'Roof',
    description: 'The drip edge directs water into the gutter. If it is bent, rusted, or missing, water runs behind the fascia and rots it from inside.',
    severity: 'Routine',
  },

  // SEPTEMBER
  {
    id: 'sep1',
    month: 'September',
    monthShort: 'SEP',
    season: 'Fall',
    task: 'Professional fall roof inspection and tune-up',
    area: 'Roof',
    description: 'A pre-winter inspection addresses minor issues before snow and ice arrive. This is the single highest-ROI maintenance step you can take.',
    severity: 'Critical',
  },
  {
    id: 'sep2',
    month: 'September',
    monthShort: 'SEP',
    season: 'Fall',
    task: 'Deep clean gutters and install leaf guards if needed',
    area: 'Gutters',
    description: 'Fall leaves drop fast. Clean gutters now, or install gutter guards before the first major leaf fall clogs your entire system.',
    severity: 'Important',
  },
  {
    id: 'sep3',
    month: 'September',
    monthShort: 'SEP',
    season: 'Fall',
    task: 'Inspect valley areas for debris accumulation',
    area: 'Roof',
    description: 'Leaves and pine needles collect in valleys and trap moisture. A clogged valley does not drain and becomes a leak source.',
    severity: 'Important',
  },
  {
    id: 'sep4',
    month: 'September',
    monthShort: 'SEP',
    season: 'Fall',
    task: 'Check roof fasteners and nail pops on shingle edges',
    area: 'Roof',
    description: 'Nail pops lift shingles and create entry points for wind-driven rain. They are a 5-minute fix if caught early, a $500 repair if ignored.',
    severity: 'Routine',
  },

  // OCTOBER
  {
    id: 'oct1',
    month: 'October',
    monthShort: 'OCT',
    season: 'Fall',
    task: 'Inspect chimney crown and cap for cracks',
    area: 'Roof',
    description: 'A cracked chimney crown lets water into the chimney structure, which then freezes, expands, and destroys brickwork from inside.',
    severity: 'Important',
  },
  {
    id: 'oct2',
    month: 'October',
    monthShort: 'OCT',
    season: 'Fall',
    task: 'Clear all leaves from valleys, behind chimneys, and near vents',
    area: 'Roof',
    description: 'These are the three most common leak locations. Trapped leaves hold moisture against shingles through winter, causing rot.',
    severity: 'Important',
  },
  {
    id: 'oct3',
    month: 'October',
    monthShort: 'OCT',
    season: 'Fall',
    task: 'Check and caulk around window and door headers below roof lines',
    area: 'Siding',
    description: 'Water from roof leaks often shows up at window headers before it ever drips from the ceiling. Caulk gaps now before freeze-thaw cycles open them wider.',
    severity: 'Routine',
  },
  {
    id: 'oct4',
    month: 'October',
    monthShort: 'OCT',
    season: 'Fall',
    task: 'Verify attic access hatch is sealed and insulated',
    area: 'Attic',
    description: 'An uninsulated attic hatch is a massive heat leak. It warms the roof deck unevenly and creates localized ice dam conditions.',
    severity: 'Routine',
  },

  // NOVEMBER
  {
    id: 'nov1',
    month: 'November',
    monthShort: 'NOV',
    season: 'Fall',
    task: 'Final pre-winter gutter check and downspout flow test',
    area: 'Gutters',
    description: 'Run a hose into each gutter and verify water exits the downspout quickly. Slow drainage means a hidden clog that will freeze solid.',
    severity: 'Important',
  },
  {
    id: 'nov2',
    month: 'November',
    monthShort: 'NOV',
    season: 'Fall',
    task: 'Inspect rubber boots around vent pipes for cracking',
    area: 'Roof',
    description: 'Rubber deteriorates in UV. A cracked boot around a plumbing vent is one of the most common and preventable leak sources in winter.',
    severity: 'Important',
  },
  {
    id: 'nov3',
    month: 'November',
    monthShort: 'NOV',
    season: 'Fall',
    task: 'Check roof edge and rake overhangs for lifted shingles',
    area: 'Roof',
    description: 'Wind hits the edges hardest. Lifted shingles at the perimeter are the first to let water in during winter storms.',
    severity: 'Routine',
  },
  {
    id: 'nov4',
    month: 'November',
    monthShort: 'NOV',
    season: 'Fall',
    task: 'Confirm roof rake or snow removal tool is accessible',
    area: 'Roof',
    description: 'If you get heavy snow, a roof rake lets you clear the lower 3-4 feet from the ground. Do not wait until the first blizzard to find yours.',
    severity: 'Routine',
  },

  // DECEMBER
  {
    id: 'dec1',
    month: 'December',
    monthShort: 'DEC',
    season: 'Winter',
    task: 'Monitor for ice dams and icicle formation after first freeze',
    area: 'Roof',
    description: 'Icicles larger than 2 inches in diameter signal an ice dam. Address immediately with roof heat cable or professional steam removal.',
    severity: 'Critical',
  },
  {
    id: 'dec2',
    month: 'December',
    monthShort: 'DEC',
    season: 'Winter',
    task: 'Check interior for new cracks or stains after first major cold snap',
    area: 'Interior',
    description: 'The first hard freeze tests every compromised seal. New interior stains that appear in December were weaknesses hiding since fall.',
    severity: 'Critical',
  },
  {
    id: 'dec3',
    month: 'December',
    monthShort: 'DEC',
    season: 'Winter',
    task: 'Verify bathroom and dryer vents are exhausting outside (not into attic)',
    area: 'Attic',
    description: 'Winter moisture from vents dumps directly onto cold rafters. This is a year-round issue but creates the most damage in freezing conditions.',
    severity: 'Important',
  },
  {
    id: 'dec4',
    month: 'December',
    monthShort: 'DEC',
    season: 'Winter',
    task: 'Check holiday light installation points for shingle damage',
    area: 'Roof',
    description: 'Clip-on lights, nails, and staples puncture shingles and create leak paths. Inspect attachment points when you take decorations down.',
    severity: 'Routine',
  },
];

const seasons = ['All', 'Winter', 'Spring', 'Summer', 'Fall'];
const areas = ['All Areas', 'Roof', 'Gutters', 'Siding', 'Attic', 'Interior', 'Trees'];

const severityPoints: Record<string, number> = {
  Critical: 3,
  Important: 2,
  Routine: 1,
};

const maxPoints = tasks.reduce((sum, t) => sum + severityPoints[t.severity], 0);

export default function RoofMaintenanceCalendarPage() {
  const [checked, setChecked] = useState<Set<string>>(new Set());
  const [activeSeason, setActiveSeason] = useState('All');
  const [activeArea, setActiveArea] = useState('All Areas');
  const [printMode, setPrintMode] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  const toggleItem = (id: string) => {
    const next = new Set(checked);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setChecked(next);
  };

  const handlePrint = () => {
    setPrintMode(true);
    setTimeout(() => {
      window.print();
      setPrintMode(false);
    }, 100);
  };

  const filtered = tasks.filter((t) => {
    const seasonMatch = activeSeason === 'All' || t.season === activeSeason;
    const areaMatch = activeArea === 'All Areas' || t.area === activeArea;
    return seasonMatch && areaMatch;
  });

  const score = tasks.reduce((s, t) => s + (checked.has(t.id) ? severityPoints[t.severity] : 0), 0);
  const completedCount = checked.size;
  const totalCount = tasks.length;

  const criticalDone = tasks.filter((t) => t.severity === 'Critical' && checked.has(t.id)).length;
  const criticalTotal = tasks.filter((t) => t.severity === 'Critical').length;

  const schema = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: 'Roof Maintenance Calendar for Homeowners',
    description:
      'A year-round printable roof maintenance calendar with monthly tasks for shingles, gutters, siding, and attic. Keep your roof warranty valid and prevent costly repairs.',
    url: 'https://cornerstoneconstructionevansville.com/roof-maintenance-calendar',
  };

  const severityBadge = (s: string) => {
    switch (s) {
      case 'Critical':
        return 'bg-red-50 text-red-600 border-red-200';
      case 'Important':
        return 'bg-orange/10 text-orange border-orange/20';
      case 'Routine':
        return 'bg-gray-100 text-gray-600 border-gray-200';
      default:
        return '';
    }
  };

  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  return (
    <div className="min-h-screen bg-white print:bg-white" ref={printRef}>
      <PageSEO
        title="Roof Maintenance Calendar for Homeowners | Year-Round Checklist | Corner Stone"
        description="Free printable roof maintenance calendar with monthly tasks for shingles, gutters, siding, and attic. Prevent costly repairs and keep your warranty valid."
        keywords="roof maintenance calendar, roof care schedule, homeowner roof checklist, gutter maintenance schedule, seasonal roof inspection, roof upkeep calendar"
        canonical="/roof-maintenance-calendar"
        schema={schema}
      />

      {/* Print Header */}
      <div className="hidden print:block print:p-8">
        <div className="flex items-center justify-between border-b-2 border-gray-300 pb-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 uppercase tracking-wider">
              Roof Maintenance Calendar
            </h1>
            <p className="text-sm text-gray-600 mt-1">
              Year-Round Homeowner Protection Checklist
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600">Corner Stone Construction & Roofing</p>
            <p className="text-sm text-gray-600">812-213-5997</p>
            <p className="text-sm text-gray-600">cornerstoneconstructionevansville.com</p>
          </div>
        </div>
        <p className="text-xs text-gray-500 mb-4">
          Instructions: Check each box as you complete the monthly task. Critical tasks are marked in red and should never be skipped.
        </p>
      </div>

      {/* Screen Header */}
      <div className={`${printMode ? 'hidden' : 'block'} bg-charcoal-deep`}>
        <div className="px-6 md:px-10 lg:px-16 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <h1 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wider">
                Roof Maintenance Calendar
              </h1>
              <p className="text-white/40 text-sm mt-2">
                48 monthly tasks to protect your roof, gutters, siding, and attic year-round.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setChecked(new Set())}
                className="border border-white/20 hover:border-orange text-white/40 hover:text-orange text-xs uppercase tracking-widest py-2.5 px-5 transition-all duration-200 whitespace-nowrap cursor-pointer"
              >
                Reset
              </button>
              <button
                onClick={handlePrint}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-5 py-2.5 uppercase tracking-wide text-xs transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <i className="ri-printer-line" />
                Print Calendar
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Score Bar */}
      <div className={`${printMode ? 'hidden' : 'block'} bg-charcoal-mid border-y border-white/5`}>
        <div className="px-6 md:px-10 lg:px-16 py-5">
          <div className="flex flex-wrap items-center gap-4 md:gap-8">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 flex items-center justify-center border-2 border-orange/30 bg-orange/10">
                <span className="text-white text-xl font-bold">{completedCount}</span>
              </div>
              <div>
                <p className="text-white text-sm font-semibold">Tasks Done</p>
                <p className="text-white/40 text-xs">of {totalCount} this year</p>
              </div>
            </div>
            <div className="h-8 w-px bg-white/10 hidden md:block" />
            <div>
              <p className="text-white/60 text-xs uppercase tracking-wider">Score</p>
              <p className="text-white text-sm font-semibold">{score} / {maxPoints} pts</p>
            </div>
            <div className="h-8 w-px bg-white/10 hidden md:block" />
            <div>
              <p className="text-white/60 text-xs uppercase tracking-wider">Critical Tasks</p>
              <p className="text-white text-sm font-semibold">
                <span className={criticalDone === criticalTotal ? 'text-green-400' : criticalDone >= criticalTotal * 0.8 ? 'text-orange' : 'text-red-400'}>
                  {criticalDone}
                </span>
                {' '}/ {criticalTotal}
              </p>
            </div>
            <div className="flex-1 min-w-[200px]">
              <div className="h-2 bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-orange transition-all duration-500"
                  style={{ width: `${(completedCount / totalCount) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Print Score */}
      <div className="hidden print:block print:px-8 print:mb-6">
        <div className="grid grid-cols-4 gap-4 mb-4">
          <div className="border border-gray-300 p-3 text-center">
            <p className="text-[10px] uppercase tracking-wider text-gray-500">Tasks Done</p>
            <p className="text-2xl font-bold text-gray-900 mt-1">{completedCount}</p>
            <p className="text-xs text-gray-500">of {totalCount}</p>
          </div>
          <div className="border border-gray-300 p-3 text-center">
            <p className="text-[10px] uppercase tracking-wider text-gray-500">Score</p>
            <p className="text-2xl font-bold text-gray-900 mt-1">{score}</p>
            <p className="text-xs text-gray-500">of {maxPoints} pts</p>
          </div>
          <div className="border border-gray-300 p-3 text-center">
            <p className="text-[10px] uppercase tracking-wider text-gray-500">Critical Done</p>
            <p className="text-2xl font-bold text-gray-900 mt-1">{criticalDone}</p>
            <p className="text-xs text-gray-500">of {criticalTotal}</p>
          </div>
          <div className="border border-gray-300 p-3 text-center">
            <p className="text-[10px] uppercase tracking-wider text-gray-500">Completion</p>
            <p className="text-2xl font-bold text-gray-900 mt-1">{Math.round((completedCount / totalCount) * 100)}%</p>
          </div>
        </div>
      </div>

      {/* Section Filters */}
      <div className={`${printMode ? 'hidden' : 'block'} py-5 px-6 md:px-10 lg:px-16 border-b border-white/5`}>
        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
          <div className="flex flex-wrap gap-2">
            {seasons.map((s) => (
              <button
                key={s}
                onClick={() => setActiveSeason(s)}
                className={`px-3 py-1.5 text-[10px] uppercase tracking-wider font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  activeSeason === s
                    ? 'bg-orange text-white'
                    : 'bg-charcoal-mid text-white/40 hover:text-white border border-white/10'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
          <div className="h-4 w-px bg-white/10 hidden sm:block" />
          <div className="flex flex-wrap gap-2">
            {areas.map((a) => (
              <button
                key={a}
                onClick={() => setActiveArea(a)}
                className={`px-3 py-1.5 text-[10px] uppercase tracking-wider font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  activeArea === a
                    ? 'bg-orange/20 text-orange border border-orange/30'
                    : 'bg-charcoal-mid text-white/40 hover:text-white border border-white/10'
                }`}
              >
                {a}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 md:px-8 lg:px-12 py-6 md:py-10 print:px-8 print:py-4">
        {activeSeason === 'All' && activeArea === 'All Areas' ? (
          months.map((month) => {
            const monthTasks = tasks.filter((t) => t.month === month);
            if (monthTasks.length === 0) return null;
            const monthScore = monthTasks.reduce((s, t) => s + (checked.has(t.id) ? severityPoints[t.severity] : 0), 0);
            const monthMax = monthTasks.reduce((s, t) => s + severityPoints[t.severity], 0);
            return (
              <div key={month} className="mb-8 print:mb-5 print:break-inside-avoid">
                <div className="flex items-center gap-3 mb-4 print:mb-3 border-b border-gray-200 pb-3 print:border-gray-300">
                  <span className="text-xs font-bold text-gray-400 uppercase tracking-wider w-12">{monthTasks[0]?.monthShort}</span>
                  <h2 className="font-display text-gray-900 text-base md:text-lg uppercase tracking-wider print:text-gray-900 flex-1">
                    {month}
                  </h2>
                  <span className="text-[10px] font-bold text-orange uppercase tracking-wider">
                    {monthScore} / {monthMax} pts
                  </span>
                </div>
                <div className="space-y-2 print:space-y-1.5">
                  {monthTasks.map((task) => (
                    <TaskRow key={task.id} task={task} checked={checked.has(task.id)} onToggle={() => toggleItem(task.id)} severityBadge={severityBadge} />
                  ))}
                </div>
              </div>
            );
          })
        ) : (
          <div className="space-y-2 print:space-y-1.5">
            {filtered.map((task) => (
              <TaskRow key={task.id} task={task} checked={checked.has(task.id)} onToggle={() => toggleItem(task.id)} severityBadge={severityBadge} />
            ))}
          </div>
        )}

        {/* Severity Legend */}
        <div className="hidden print:block print:mt-6 print:mb-6 print:break-inside-avoid">
          <h3 className="font-display text-gray-900 text-sm uppercase tracking-wider mb-3 print:text-gray-900">Severity Key</h3>
          <div className="flex gap-4 text-xs text-gray-700">
            <span className="flex items-center gap-1.5"><span className="w-3 h-3 bg-red-50 border border-red-200 inline-block" /> Critical — Do not skip</span>
            <span className="flex items-center gap-1.5"><span className="w-3 h-3 bg-orange/10 border border-orange/20 inline-block" /> Important — High impact</span>
            <span className="flex items-center gap-1.5"><span className="w-3 h-3 bg-gray-100 border border-gray-200 inline-block" /> Routine — Preventive care</span>
          </div>
        </div>

        {/* Annual Summary (screen) */}
        <div className={`${printMode ? 'hidden' : 'block'} border border-gray-200 p-6 md:p-8 mb-10 mt-8`}>
          <h3 className="font-display text-gray-900 text-lg uppercase tracking-wider mb-6">
            Your Annual Maintenance Summary
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center p-5 border border-gray-200">
              <p className="text-xs uppercase tracking-wider text-gray-400 mb-2">Tasks Completed</p>
              <p className="text-4xl font-bold text-gray-900">{completedCount}</p>
              <p className="text-sm text-gray-500 mt-1">of {totalCount} total</p>
            </div>
            <div className="text-center p-5 border border-gray-200">
              <p className="text-xs uppercase tracking-wider text-gray-400 mb-2">Points Earned</p>
              <p className="text-4xl font-bold text-gray-900">{score}</p>
              <p className="text-sm text-gray-500 mt-1">of {maxPoints} possible</p>
            </div>
            <div className="text-center p-5 border border-gray-200">
              <p className="text-xs uppercase tracking-wider text-gray-400 mb-2">Critical Done</p>
              <p className={`text-4xl font-bold ${criticalDone === criticalTotal ? 'text-green-600' : criticalDone >= criticalTotal * 0.8 ? 'text-orange' : 'text-red-500'}`}>
                {criticalDone}
              </p>
              <p className="text-sm text-gray-500 mt-1">of {criticalTotal} required</p>
            </div>
            <div className="text-center p-5 border border-gray-200">
              <p className="text-xs uppercase tracking-wider text-gray-400 mb-2">Completion</p>
              <p className="text-4xl font-bold text-gray-900">{Math.round((completedCount / totalCount) * 100)}%</p>
            </div>
          </div>
          <div className="border-t border-gray-200 pt-5">
            <p className="text-sm text-gray-600 leading-relaxed">
              Completing all 48 tasks keeps your roof warranty valid, prevents 90% of emergency repairs, and extends your roof life by 3-5 years. The two professional inspections (March and September) are the highest-ROI items on this calendar.
            </p>
          </div>
        </div>

        {/* Print Annual Summary */}
        <div className="hidden print:block print:mt-6 print:border-t-2 print:border-gray-300 print:pt-6 print:break-inside-avoid">
          <h3 className="font-display text-gray-900 text-base uppercase tracking-wider mb-4 print:text-gray-900">Annual Summary</h3>
          <div className="grid grid-cols-4 gap-4 mb-4">
            <div className="border border-gray-300 p-3 text-center">
              <p className="text-[10px] uppercase tracking-wider text-gray-500">Completed</p>
              <p className="text-xl font-bold text-gray-900">{completedCount}</p>
              <p className="text-xs text-gray-500">of {totalCount}</p>
            </div>
            <div className="border border-gray-300 p-3 text-center">
              <p className="text-[10px] uppercase tracking-wider text-gray-500">Points</p>
              <p className="text-xl font-bold text-gray-900">{score}</p>
              <p className="text-xs text-gray-500">of {maxPoints}</p>
            </div>
            <div className="border border-gray-300 p-3 text-center">
              <p className="text-[10px] uppercase tracking-wider text-gray-500">Critical</p>
              <p className="text-xl font-bold text-gray-900">{criticalDone}</p>
              <p className="text-xs text-gray-500">of {criticalTotal}</p>
            </div>
            <div className="border border-gray-300 p-3 text-center">
              <p className="text-[10px] uppercase tracking-wider text-gray-500">Completion</p>
              <p className="text-xl font-bold text-gray-900">{Math.round((completedCount / totalCount) * 100)}%</p>
            </div>
          </div>
          <p className="text-xs text-gray-600 leading-relaxed">
            Completing all tasks keeps your roof warranty valid and extends roof life by 3-5 years. Professional inspections in March and September are the highest-ROI items.
          </p>
        </div>

        {/* Print Footer */}
        <div className="hidden print:block mt-8 pt-4 border-t border-gray-300">
          <div className="flex items-center justify-between text-xs text-gray-500">
            <p>Generated from cornerstoneconstructionevansville.com/roof-maintenance-calendar</p>
            <p>Schedule your free inspection at our website.</p>
          </div>
        </div>
      </div>

      {/* Screen Footer CTA */}
      <div className={`${printMode ? 'hidden' : 'block'} bg-charcoal-deep border-t border-white/5`}>
        <div className="px-6 md:px-10 lg:px-16 py-12">
          <div className="bg-orange/10 border border-orange/20 p-8 max-w-4xl">
            <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">
              Need Help With a Task?
            </h3>
            <p className="text-white/40 text-sm leading-relaxed mb-6">
              Some tasks on this calendar are DIY-friendly. Others — like professional inspections, flashing repairs, and ice dam removal — are best handled by a licensed roofer. We offer free inspections and maintenance plans that cover everything on this calendar.
            </p>
            <div className="flex flex-wrap gap-3">
              <a
                href="/free-inspection"
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-6 py-2.5 uppercase tracking-wide text-xs transition-colors whitespace-nowrap"
              >
                Free Roof Inspection
              </a>
              <a
                href="/maintenance-plans"
                className="border border-white/20 hover:border-orange text-white/40 hover:text-orange text-xs uppercase tracking-widest py-2.5 px-6 transition-all duration-200"
              >
                Maintenance Plans
              </a>
              <a
                href="/before-you-hire-a-roofer"
                className="border border-white/20 hover:border-orange text-white/40 hover:text-orange text-xs uppercase tracking-widest py-2.5 px-6 transition-all duration-200"
              >
                Hiring a Roofer Checklist
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function TaskRow({
  task,
  checked,
  onToggle,
  severityBadge,
}: {
  task: MaintenanceTask;
  checked: boolean;
  onToggle: () => void;
  severityBadge: (s: string) => string;
}) {
  const severityPointsMap: Record<string, number> = { Critical: 3, Important: 2, Routine: 1 };

  return (
    <div
      className={`border p-3 md:p-4 print:p-2.5 print:bg-white print:border-gray-300 flex gap-3 items-start transition-all ${
        checked
          ? 'border-orange/20 bg-orange/[0.02] print:border-gray-300 print:bg-white'
          : 'border-gray-200 bg-white print:border-gray-300'
      }`}
    >
      <div className="flex-shrink-0 mt-0.5">
        <div
          onClick={onToggle}
          className={`w-5 h-5 border-2 flex items-center justify-center cursor-pointer print:border-gray-400 transition-all ${
            checked ? 'bg-orange border-orange' : 'bg-white border-gray-300 hover:border-orange'
          }`}
        >
          {checked && <i className="ri-check-line text-white text-xs print:text-gray-800" />}
        </div>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex flex-wrap items-center gap-2 mb-1">
          <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 border ${severityBadge(task.severity)}`}>
            {task.severity}
          </span>
          <span className="text-[10px] text-gray-400 uppercase tracking-wider">{task.area}</span>
        </div>
        <p
          className={`text-sm font-semibold leading-snug ${
            checked ? 'text-gray-900 line-through print:no-underline print:text-gray-400' : 'text-gray-900'
          }`}
        >
          {task.task}
        </p>
        <p
          className={`text-xs leading-relaxed mt-1 ${
            checked ? 'text-gray-400' : 'text-gray-500'
          } print:text-gray-600`}
        >
          {task.description}
        </p>
      </div>
      <span
        className={`text-[10px] font-bold uppercase tracking-wider flex-shrink-0 whitespace-nowrap ${
          checked ? 'text-orange/40 print:text-gray-400' : 'text-orange'
        }`}
      >
        +{severityPointsMap[task.severity]} pts
      </span>
    </div>
  );
}