import { Link } from "react-router-dom";
import PageSEO from "../../components/feature/PageSEO";

const primaryServices = [
  { path: "/services", label: "Our Services" },
  { path: "/residential-roofing", label: "Residential Roofing" },
  { path: "/commercial-roofing", label: "Commercial Roofing" },
  { path: "/roof-repair", label: "Roof Repair" },
  { path: "/gutters-downspouts", label: "Gutters & Downspouts" },
  { path: "/siding-exterior", label: "Siding & Exterior" },
  { path: "/exterior-package", label: "Complete Exterior Package" },
  { path: "/emergency-services", label: "Emergency Roofing Services" },
  { path: "/storm-damage", label: "Storm Damage Repair" },
  { path: "/insurance-claims", label: "Insurance Claims Help" },
  { path: "/maintenance-plans", label: "Roof Maintenance Plans" },
  { path: "/warranty", label: "Warranty Information" },
];

const planningTools = [
  { path: "/estimate", label: "Free Estimate" },
  { path: "/free-inspection", label: "Free Roof Inspection" },
  { path: "/roof-comparison", label: "Roof Material Comparison" },
  { path: "/roof-cost-guide", label: "Roof Cost Guide" },
  { path: "/roof-financing", label: "Roof Financing Options" },
  { path: "/financing", label: "Financing Calculator" },
  { path: "/ai-inspector", label: "AI Roof Inspector" },
];

const aboutTrust = [
  { path: "/about", label: "About Us" },
  { path: "/projects", label: "Our Projects" },
  { path: "/before-after", label: "Before & After Gallery" },
  { path: "/testimonials", label: "Customer Testimonials" },
  { path: "/case-studies", label: "Case Studies" },
  { path: "/faq", label: "FAQ" },
  { path: "/blog", label: "Blog" },
];

const cityPages: { path: string; label: string; state: string }[] = [
  { path: "/locations/newburgh", label: "Newburgh", state: "IN" },
  { path: "/locations/boonville", label: "Boonville", state: "IN" },
  { path: "/locations/mount-vernon", label: "Mount Vernon", state: "IN" },
  { path: "/locations/princeton", label: "Princeton", state: "IN" },
  { path: "/locations/jasper", label: "Jasper", state: "IN" },
  { path: "/locations/chandler", label: "Chandler", state: "IN" },
  { path: "/locations/tell-city", label: "Tell City", state: "IN" },
  { path: "/locations/rockport", label: "Rockport", state: "IN" },
  { path: "/locations/vincennes", label: "Vincennes", state: "IN" },
  { path: "/locations/washington", label: "Washington", state: "IN" },
  { path: "/locations/henderson-ky", label: "Henderson", state: "KY" },
  { path: "/locations/owensboro-ky", label: "Owensboro", state: "KY" },
  { path: "/locations/madisonville-ky", label: "Madisonville", state: "KY" },
  { path: "/locations/greenville-ky", label: "Greenville", state: "KY" },
];

const legal = [
  { path: "/privacy-policy", label: "Privacy Policy" },
  { path: "/terms-of-service", label: "Terms of Service" },
];

function LinkGroup({
  title,
  links,
}: {
  title: string;
  links: { path: string; label: string }[];
}) {
  return (
    <div className="mb-10">
      <h2 className="text-xl font-bold text-stone-800 mb-4 font-[family-name:var(--font-playfair)]">
        {title}
      </h2>
      <ul className="space-y-2">
        {links.map((link) => (
          <li key={link.path}>
            <Link
              to={link.path}
              className="text-stone-600 hover:text-orange-600 transition-colors text-sm md:text-base inline-flex items-center gap-2"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-orange-500 flex-shrink-0" />
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function SitemapPage() {
  return (
    <>
      <PageSEO
        title="Sitemap | Corner Stone Construction & Roofing"
        description="Complete sitemap of Corner Stone Construction & Roofing. Browse all services, city pages, tools, and resources for Evansville, Indiana, and the Tri-State area."
        canonical="https://cornerstoneconstructionevansville.com/sitemap"
      />
      <main className="min-h-screen bg-stone-50 pt-24 pb-20">
        <div className="max-w-6xl mx-auto px-4 md:px-6">
          {/* Header */}
          <div className="mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-stone-800 font-[family-name:var(--font-playfair)] mb-3">
              Sitemap
            </h1>
            <p className="text-stone-600 text-base md:text-lg max-w-2xl">
              A complete directory of every page on our website. Use this to
              quickly find the roofing service, city page, or resource you need
              across Evansville, Indiana, and the Tri-State area.
            </p>
          </div>

          {/* XML Sitemap Link */}
          <div className="bg-white rounded-lg border border-stone-200 p-5 mb-10 flex items-center gap-4">
            <div className="w-10 h-10 rounded-lg bg-orange-50 flex items-center justify-center flex-shrink-0">
              <i className="ri-file-list-3-line text-orange-600 text-lg" />
            </div>
            <div>
              <p className="text-stone-800 font-semibold text-sm">
                XML Sitemap for Search Engines
              </p>
              <a
                href="/sitemap.xml"
                className="text-orange-600 hover:text-orange-700 text-sm inline-flex items-center gap-1 mt-0.5"
                rel="nofollow"
              >
                View sitemap.xml
                <i className="ri-external-link-line text-xs" />
              </a>
            </div>
          </div>

          {/* Link Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-2">
            <LinkGroup title="Services" links={primaryServices} />
            <LinkGroup title="Planning & Tools" links={planningTools} />
            <LinkGroup title="About & Trust" links={aboutTrust} />

            {/* City Pages */}
            <div className="sm:col-span-2 lg:col-span-3 mb-10">
              <h2 className="text-xl font-bold text-stone-800 mb-4 font-[family-name:var(--font-playfair)]">
                Service Areas & City Pages
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {cityPages.map((city) => (
                  <Link
                    key={city.path}
                    to={city.path}
                    className="flex items-center justify-between bg-white rounded-lg border border-stone-200 px-4 py-3 hover:border-orange-300 hover:shadow-sm transition-all"
                  >
                    <span className="text-stone-700 text-sm font-medium">
                      {city.label}
                    </span>
                    <span className="text-xs text-stone-400 bg-stone-100 px-2 py-0.5 rounded-full">
                      {city.state}
                    </span>
                  </Link>
                ))}
              </div>
              <div className="mt-4">
                <Link
                  to="/service-areas"
                  className="text-orange-600 hover:text-orange-700 text-sm font-medium inline-flex items-center gap-1"
                >
                  View full service areas map
                  <i className="ri-arrow-right-line text-xs" />
                </Link>
              </div>
            </div>

            <LinkGroup title="Legal" links={legal} />
          </div>

          {/* Schema.org Breadcrumb */}
          <script type="application/ld+json">
            {JSON.stringify({
              "@context": "https://schema.org",
              "@type": "BreadcrumbList",
              itemListElement: [
                {
                  "@type": "ListItem",
                  position: 1,
                  name: "Home",
                  item: "https://cornerstoneconstructionevansville.com/",
                },
                {
                  "@type": "ListItem",
                  position: 2,
                  name: "Sitemap",
                  item: "https://cornerstoneconstructionevansville.com/sitemap",
                },
              ],
            })}
          </script>
        </div>
      </main>
    </>
  );
}