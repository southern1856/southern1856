import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import ContactSection from '@/components/feature/ContactSection';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const PROBLEMS = [
  {
    icon: 'ri-drop-line',
    title: 'Roof Leaks',
    desc: 'Water stains on Evansville ceilings, dripping during heavy Indiana rain, or wet attic insulation — we find the source and seal it before mold spreads to your drywall.',
  },
  {
    icon: 'ri-windy-line',
    title: 'Wind & Storm Damage',
    desc: 'Missing shingles, lifted flashing, or wind-driven debris impact across Vanderburgh County. Same-day tarping and repair when the next storm hits Evansville.',
  },
  {
    icon: 'ri-hail-line',
    title: 'Hail Damage',
    desc: 'Indiana hail storms cause dented vents, bruised shingles, and cracked flashing. We document every bit of damage for your insurance so you get maximum payout.',
  },
  {
    icon: 'ri-home-smile-line',
    title: 'Sagging or Soft Spots',
    desc: 'Spongy decking or dips in your roofline mean structural trouble underneath. We open it up, repair the rot, reinforce the framing, and restore your Evansville roof.',
  },
  {
    icon: 'ri-flashlight-line',
    title: 'Flashing Failures',
    desc: 'Leaks around chimneys, skylights, ridge vents, and valleys are common on older Evansville homes. We replace worn flashing with code-compliant metal that lasts decades.',
  },
  {
    icon: 'ri-stack-line',
    title: 'Shingle Granule Loss',
    desc: 'Bald spots on your shingles mean they are aging out. We patch affected areas affordably or advise honestly when a full Evansville roof replacement is the smarter move.',
  },
];

const LOCAL_LANDMARKS = [
  { name: 'East Side', desc: 'Mature subdivisions with 15–25 year old roofs needing leak repair and storm patching' },
  { name: 'West Side', desc: 'Historic districts near downtown Evansville — flashing, valley, and chimney repairs' },
  { name: 'North Side', desc: 'Newer construction off First Ave — wind damage, nail pops, and missing shingles' },
  { name: 'McCullough Park Area', desc: 'Established neighborhood homes — granule loss, hail impact, and gutter repair' },
  { name: 'Wesselman Park Area', desc: 'Large lot homes with complex roof lines — skylight leaks and valley repair specialists' },
  { name: 'Stringtown', desc: 'Working-class homes needing affordable, honest repair — not a replacement upsell' },
];

const REPAIR_VS_REPLACE = [
  {
    label: 'When to Repair',
    when: [
      'Damage is localized to one section of your Evansville roof',
      'Roof is less than 15 years old with solid decking',
      'Underlayment is intact — just shingle damage',
      'A few cracked or missing shingles from a storm',
      'Quick fix needed before the next Indiana storm season',
    ],
  },
  {
    label: 'When to Replace',
    when: [
      'Damage covers more than 30% of your total roof area',
      'Roof is 20+ years old with widespread granule loss',
      'Multiple layers of old shingles exist underneath',
      'Curling, cupping, or bald shingles across most of the roof',
      'Active leaks in multiple rooms after every heavy rain',
    ],
  },
];

const FAQS = [
  {
    q: 'How fast can you fix a roof leak in Evansville?',
    a: 'We offer same-day emergency tarping and temporary sealing for active leaks in Evansville. Most non-emergency repairs are scheduled and completed within 24–48 hours. Call 812-213-5997 for urgent situations.',
  },
  {
    q: 'Does my Evansville homeowner insurance cover roof repairs?',
    a: 'If the damage is from a covered peril like wind, hail, or falling debris — and Indiana gets all three — insurance typically covers repairs. Our team meets your adjuster on-site and provides full photo documentation so you get every dollar you are owed.',
  },
  {
    q: 'How much does roof repair cost in Evansville Indiana?',
    a: 'Minor repairs like sealing a small leak or replacing a few shingles typically run $300–$800. Larger repairs involving decking replacement, flashing work, or multiple damaged sections range from $1,200–$3,000. Every job gets an exact written quote after our free on-site inspection.',
  },
  {
    q: 'Can you repair just part of my roof?',
    a: 'Absolutely. If the damage is contained to one slope or section, we can patch and blend new materials to match your existing roof. We will always be upfront if a partial repair is not the best long-term solution for your Evansville home.',
  },
  {
    q: 'Do you offer emergency roof repair at night or on weekends in Evansville?',
    a: 'Yes. Our 24/7 emergency line is 812-213-5997. We dispatch crews to Evansville homes for tarping, temporary sealing, and storm damage response any time — day or night, weekday or weekend.',
  },
  {
    q: 'What parts of Evansville do you serve for roof repair?',
    a: 'We serve all of Evansville — East Side, West Side, North Side, downtown, Stringtown, McCullough Park, Wesselman Park, and every neighborhood in between. We also cover Newburgh, Henderson KY, and the full Tri-State area.',
  },
];

const schema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: FAQS.map((f) => ({
    '@type': 'Question',
    name: f.q,
    acceptedAnswer: { '@type': 'Answer', text: f.a },
  })),
};

export default function EvansvilleRoofRepairPage() {
  const navigate = useNavigate();
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const heroAnim = useScrollAnimation();
  const problemsAnim = useScrollAnimation({ threshold: 0.05 });
  const areasAnim = useScrollAnimation({ threshold: 0.1 });
  const faqAnim = useScrollAnimation({ threshold: 0.1 });

  const openReaddyAgent = (prefill?: string) => {
    const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
    if (btn) btn.click();
    if (prefill) {
      setTimeout(() => {
        const input = document.querySelector('input[placeholder*="message"], textarea[placeholder*="message"], input[placeholder*="ask"], textarea[placeholder*="ask"]') as HTMLInputElement | HTMLTextAreaElement | null;
        if (input) {
          input.value = prefill;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          const form = input.closest('form');
          if (form) {
            const submitBtn = form.querySelector('button[type="submit"], button[aria-label*="send"], button svg') as HTMLElement | null;
            if (submitBtn) submitBtn.click();
          }
        }
      }, 900);
    }
  };

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roof Repair Evansville IN | Emergency Leak Fix & Storm Damage | Corner Stone"
        description="Fast, reliable roof repair in Evansville Indiana. Same-day emergency tarping, leak repairs, storm damage, hail damage, and shingle replacement. Serving all Evansville neighborhoods. Free inspection. 24/7 emergency line 812-213-5997."
        keywords="roof repair Evansville, Evansville roof leak repair, emergency roof repair Evansville Indiana, storm damage roof repair Evansville, hail damage roof repair Evansville, roof patching Evansville, roof tarping Evansville IN, Vanderburgh County roof repair"
        canonical="/evansville-roof-repair"
        schema={schema}
      />

      {/* ── Hero ── */}
      <section className="relative min-h-[70dvh] md:min-h-[80dvh] flex flex-col justify-center overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <img
            src="/placeholders/1200x800.svg"
            alt="Roof repair contractor in Evansville Indiana"
            className="w-full h-full object-cover object-top opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/70 via-charcoal-deep/50 to-charcoal-deep" />
        </div>

        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 px-4 md:px-10 lg:px-16 pt-28 md:pt-32 pb-16 anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-wrap items-center gap-2 md:gap-3 mb-6">
            <span className="flex items-center gap-1.5 border border-white/15 bg-white/5 backdrop-blur-sm px-3 md:px-4 py-1.5 text-white/60 text-[10px] md:text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange inline-block" />
              24/7 Evansville Emergency Service
            </span>
            <span className="flex items-center gap-1.5 border border-white/15 bg-white/5 backdrop-blur-sm px-3 md:px-4 py-1.5 text-white/60 text-[10px] md:text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 inline-block" />
              Same-Day Tarping in Vanderburgh County
            </span>
          </div>

          <h1
            className="font-display text-white leading-none tracking-wider uppercase max-w-5xl"
            style={{ fontSize: 'clamp(2.8rem, 7vw, 6.5rem)' }}
          >
            Evansville Roof Repair
            <br />
            <span className="text-orange">Done Right</span>
            <br />
            <span className="text-white/90">The First Time</span>
          </h1>

          <p className="text-white/60 text-sm md:text-base max-w-lg mt-6 md:mt-8 leading-relaxed">
            Leaks, storm damage, missing shingles, and sagging spots — we fix them all across Evansville, the East Side, West Side, and every neighborhood in between. Free inspection, honest quote, same-day turnaround when you need it most.
          </p>

          <div className="mt-8 md:mt-10 flex flex-col sm:flex-row gap-3 md:gap-4">
            <button
              onClick={() => navigate('/free-inspection')}
              className="group bg-orange hover:bg-orange-dark text-white font-semibold px-6 md:px-8 py-3.5 md:py-4 uppercase tracking-widest text-xs md:text-sm transition-all duration-300 whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
            >
              Free Evansville Inspection
              <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform duration-200" />
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-6 md:px-8 py-3.5 md:py-4 uppercase tracking-widest text-xs md:text-sm transition-all duration-300 whitespace-nowrap flex items-center justify-center gap-3"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>

          <div className="mt-6 flex items-center gap-3">
            <button
              onClick={() => openReaddyAgent("I have a roof leak in Evansville. How fast can you come out?")}
              className="group flex items-center gap-2 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-question-answer-line text-sm" />
              <span className="underline underline-offset-2">Ask AI how fast we can fix your Evansville leak</span>
              <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      <TalkToAIExpert />

      {/* ── Problems We Fix ── */}
      <section className="py-20 md:py-28 px-4 md:px-10 lg:px-16">
        <div className="mb-14 md:mb-20">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Common Issues in Evansville</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.2rem, 5vw, 4.5rem)' }}>
            Problems We Fix
            <br />
            <span className="text-white/50">Every Single Day in Vanderburgh County</span>
          </h2>
        </div>

        <div
          ref={problemsAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-white/10"
        >
          {PROBLEMS.map((p, i) => (
            <div
              key={p.title}
              className={`bg-charcoal-deep p-8 md:p-10 group hover:bg-charcoal-mid transition-colors duration-300 anim-fade-up ${problemsAnim.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <div className="w-12 h-12 flex items-center justify-center border border-orange/40 mb-6 group-hover:bg-orange group-hover:border-orange transition-all duration-300">
                <i className={`${p.icon} text-orange group-hover:text-white text-xl transition-colors duration-300`} />
              </div>
              <h3 className="font-serif font-bold text-white text-lg md:text-xl mb-3 leading-snug">{p.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Evansville Neighborhoods ── */}
      <section className="py-20 md:py-28 px-4 md:px-10 lg:px-16 bg-charcoal-mid">
        <div
          ref={areasAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${areasAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="text-center mb-14 md:mb-20">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Local Coverage</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              Every Evansville Neighborhood
              <br />
              <span className="text-white/50">We Know Your Block</span>
            </h2>
            <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto mt-4 leading-relaxed">
              Corner Stone has been roofing Evansville homes since 1995. We know which neighborhoods have older flashing that needs attention and which newer subdivisions see wind-driven damage after every storm.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl mx-auto">
            {LOCAL_LANDMARKS.map((area, i) => (
              <div
                key={area.name}
                className="border border-white/10 bg-charcoal-deep p-6 hover:border-orange/30 transition-all duration-300"
                style={{ transitionDelay: `${i * 70}ms` }}
              >
                <div className="flex items-center gap-3 mb-3">
                  <i className="ri-map-pin-line text-orange text-lg" />
                  <h3 className="font-display text-white text-lg uppercase tracking-wider">{area.name}</h3>
                </div>
                <p className="text-white/40 text-xs leading-relaxed">{area.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Repair vs Replace ── */}
      <section className="py-20 md:py-28 px-4 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Honest Guidance for Evansville Homeowners</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 4.5vw, 4rem)' }}>
              Repair or Replace?
              <br />
              <span className="text-white/50">We Will Tell You Straight — No Games</span>
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-md">
              Not every damaged Evansville roof needs a full teardown. We get up there, inspect the decking, underlayment, and every shingle — then give you the honest answer. If a $400 patch buys you 5 more years, we will tell you. We are not here to sell you something you do not need.
            </p>
            <button
              onClick={() => navigate('/free-inspection')}
              className="mt-8 group bg-orange hover:bg-orange-dark text-white font-semibold px-6 py-3.5 uppercase tracking-widest text-xs transition-all duration-300 whitespace-nowrap cursor-pointer flex items-center gap-2"
            >
              Get Free Evansville Inspection
              <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform duration-200" />
            </button>
            <div className="mt-4">
              <button
                onClick={() => openReaddyAgent("Should I repair my Evansville roof or replace it?")}
                className="group flex items-center gap-2 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-question-answer-line text-sm" />
                <span className="underline underline-offset-2">Ask AI: repair or replace my Evansville roof?</span>
                <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-6">
            {REPAIR_VS_REPLACE.map((col) => (
              <div key={col.label} className="flex-1 border border-white/10 p-6 md:p-8">
                <h3 className={`font-display uppercase tracking-wider text-xl md:text-2xl mb-6 ${col.label === 'When to Repair' ? 'text-green-400' : 'text-orange'}`}>
                  {col.label}
                </h3>
                <ul className="space-y-4">
                  {col.when.map((item) => (
                    <li key={item} className="flex items-start gap-3 text-white/60 text-sm leading-relaxed">
                      <i className={`${col.label === 'When to Repair' ? 'ri-check-line text-green-400' : 'ri-close-line text-orange'} mt-0.5`} />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Emergency CTA ── */}
      <section className="relative py-20 md:py-28 px-4 md:px-10 lg:px-16 overflow-hidden bg-charcoal-mid">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1200x600.svg"
            alt="Emergency roof repair during Evansville storm"
            className="w-full h-full object-cover opacity-15"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-charcoal-mid via-charcoal-mid/90 to-charcoal-mid/70" />
        </div>

        <div className="relative z-10 max-w-3xl">
          <div className="flex items-center gap-2 mb-6">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-red-400 text-xs uppercase tracking-[0.25em] font-semibold">Indiana Storm Season Is Active</span>
          </div>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.2rem, 5vw, 4.5rem)' }}>
            Emergency?
            <br />
            <span className="text-orange">We Are On Our Way — Evansville</span>
          </h2>
          <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-lg mb-8">
            Active leak soaking your ceiling? Tree limb on your roof? Hail just rolled through your Evansville neighborhood? Call our 24/7 emergency line. We dispatch a crew for tarping and temporary sealing — usually within the hour for Evansville addresses.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4">
            <a
              href="tel:8122135997"
              className="bg-red-600 hover:bg-red-500 text-white font-semibold px-6 md:px-8 py-3.5 md:py-4 uppercase tracking-widest text-xs md:text-sm transition-all duration-300 whitespace-nowrap flex items-center justify-center gap-2 cursor-pointer"
            >
              <i className="ri-phone-line" />
              Call 812-213-5997 — 24/7
            </a>
            <button
              onClick={() => navigate('/emergency-services')}
              className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-6 md:px-8 py-3.5 md:py-4 uppercase tracking-widest text-xs md:text-sm transition-all duration-300 whitespace-nowrap flex items-center justify-center gap-2 cursor-pointer"
            >
              Emergency Services
              <i className="ri-arrow-right-line" />
            </button>
          </div>
          <div className="mt-5">
            <button
              onClick={() => openReaddyAgent("My Evansville roof is leaking right now. What should I do?")}
              className="group flex items-center gap-2 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-question-answer-line text-sm" />
              <span className="underline underline-offset-2">Ask AI what to do for an active Evansville leak</span>
              <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* ── Process ── */}
      <section className="py-20 md:py-28 px-4 md:px-10 lg:px-16">
        <div className="text-center mb-14 md:mb-20">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">How It Works in Evansville</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
            From Call to Fixed
            <br />
            <span className="text-white/50">In as Little as 24 Hours</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 md:gap-6">
          {[
            { num: '01', title: 'Call or Book Online', desc: 'Reach us 24/7 by phone at 812-213-5997 or schedule a free Evansville inspection through our site in 60 seconds.' },
            { num: '02', title: 'Free On-Site Diagnosis', desc: 'We come to your Evansville address, inspect every inch, photograph the damage, and explain exactly what needs fixing.' },
            { num: '03', title: 'Honest Quote & Plan', desc: 'You get a clear, itemized quote with zero pressure. We tell you if a repair or replacement is the smarter move for your Evansville home.' },
            { num: '04', title: 'Fast, Clean Repair', desc: 'Our crew fixes the damage, cleans the site completely — including a magnetic nail sweep — and you get photos of the finished work.' },
          ].map((step, i) => (
            <div key={step.num} className="relative">
              {i < 3 && (
                <div className="hidden md:block absolute top-8 left-full w-full h-px bg-white/10" />
              )}
              <span className="font-display text-white/10 text-5xl md:text-6xl leading-none block mb-4">{step.num}</span>
              <h3 className="font-serif font-bold text-white text-lg md:text-xl mb-3">{step.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-20 md:py-28 px-4 md:px-10 lg:px-16 bg-charcoal-mid">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-14 md:mb-20">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">FAQ</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              Evansville Roof Repair
              <br />
              <span className="text-white/50">Questions Answered</span>
            </h2>
          </div>

          <div
            ref={faqAnim.ref as React.RefObject<HTMLDivElement>}
            className="border-t border-white/10"
          >
            {FAQS.map((faq, i) => (
              <div key={i} className="border-b border-white/10">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between py-5 md:py-6 text-left cursor-pointer group"
                >
                  <span className="font-serif font-bold text-white text-base md:text-lg pr-4 group-hover:text-orange transition-colors duration-200">
                    {faq.q}
                  </span>
                  <i className={`ri-${openFaq === i ? 'subtract-line' : 'add-line'} text-orange flex-shrink-0 text-lg transition-transform duration-200`} />
                </button>
                <div
                  className="overflow-hidden transition-all duration-300"
                  style={{ maxHeight: openFaq === i ? 300 : 0, opacity: openFaq === i ? 1 : 0 }}
                >
                  <p className="text-white/50 text-sm md:text-base leading-relaxed pb-5 md:pb-6 pr-8">
                    {faq.a}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Final CTA ── */}
      <section className="py-20 md:py-28 px-4 md:px-10 lg:px-16 text-center">
        <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
          Stop the Evansville Leak
          <br />
          <span className="text-orange">Before It Gets Worse</span>
        </h2>
        <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-lg mx-auto mb-8">
          Water damage does not wait. Every day you delay, it spreads further into your Evansville home — into insulation, drywall, and framing. Book your free inspection now and get an honest repair quote from a roofer who has served Vanderburgh County since 1995.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
          <button
            onClick={() => navigate('/free-inspection')}
            className="group bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-all duration-300 whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
          >
            Book Free Evansville Inspection
            <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform duration-200" />
          </button>
          <a
            href="tel:8122135997"
            className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-all duration-300 whitespace-nowrap flex items-center justify-center gap-3"
          >
            <i className="ri-phone-line text-orange" />
            812-213-5997
          </a>
        </div>
        <div className="mt-6 flex justify-center">
          <button
            onClick={() => openReaddyAgent("How much does a typical roof repair cost in Evansville Indiana?")}
            className="group flex items-center gap-2 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-question-answer-line text-sm" />
            <span className="underline underline-offset-2">Ask AI about Evansville repair costs</span>
            <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>
      </section>

      <ContactSection />
    </div>
  );
}