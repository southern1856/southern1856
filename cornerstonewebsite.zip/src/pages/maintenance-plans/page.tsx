import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import PageSEO from '@/components/feature/PageSEO';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { OFFERS } from '@/mocks/promotions';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const nearestExpiry = OFFERS
  .filter((o) => o.expires)
  .map((o) => o.expires!)
  .sort()[0] || '2026-12-31';

const plans = [
  {
    name: 'Essential',
    tag: 'Best for New Roofs',
    highlight: false,
    price: '$149',
    period: '/ year',
    desc: 'Annual peace of mind for newer roofs in good condition. One inspection, one report, one less thing to worry about.',
    features: [
      'Annual full-roof inspection',
      'Photo documentation report',
      'Gutter & downspout check',
      'Attic ventilation assessment',
      'Written condition summary',
      'Priority scheduling',
    ],
    notIncluded: ['Minor repair labor', 'Emergency call-outs', 'Gutter cleaning'],
    icon: 'ri-shield-line',
    color: 'border-white/10',
    btnStyle: 'border border-white/20 hover:border-orange text-white/70 hover:text-white',
  },
  {
    name: 'Protection',
    tag: 'Most Popular',
    highlight: true,
    price: '$299',
    period: '/ year',
    desc: 'Our most popular plan. Two inspections per year plus minor repairs included — the smart choice for most homeowners.',
    features: [
      'Spring & fall inspections (2x/year)',
      'Photo documentation reports',
      'Gutter cleaning (1x/year)',
      'Minor repairs included (up to $200)',
      'Flashing & sealant touch-ups',
      'Attic ventilation check',
      'Priority emergency response',
      '10% discount on all other work',
    ],
    notIncluded: ['Major repairs', 'Full replacements'],
    icon: 'ri-shield-check-line',
    color: 'border-orange',
    btnStyle: 'bg-orange hover:bg-orange-dark text-white',
  },
  {
    name: 'Total Care',
    tag: 'Best Value',
    highlight: false,
    price: '$499',
    period: '/ year',
    desc: 'Complete roof care with quarterly check-ins, unlimited minor repairs, and first-in-line emergency service.',
    features: [
      'Quarterly inspections (4x/year)',
      'Unlimited minor repairs included',
      'Gutter cleaning (2x/year)',
      'Full photo documentation',
      'Flashing, sealant & ridge cap service',
      'Attic & ventilation optimization',
      '24/7 priority emergency line',
      '15% discount on all other work',
      'Annual roof health certificate',
    ],
    notIncluded: [],
    icon: 'ri-shield-star-line',
    color: 'border-white/10',
    btnStyle: 'border border-white/20 hover:border-orange text-white/70 hover:text-white',
  },
];

const whyMaintain = [
  {
    icon: 'ri-money-dollar-circle-line',
    title: 'Save Thousands Long-Term',
    desc: 'A $299/year plan can prevent a $12,000 emergency repair. Small issues caught early cost a fraction of what they cost when ignored.',
    stat: '10x',
    statLabel: 'avg. repair cost vs. prevention',
  },
  {
    icon: 'ri-time-line',
    title: 'Extend Your Roof\'s Life',
    desc: 'Regular maintenance can add 5–10 years to your roof\'s lifespan. That\'s thousands of dollars in delayed replacement costs.',
    stat: '+8 yrs',
    statLabel: 'avg. lifespan extension',
  },
  {
    icon: 'ri-file-shield-2-line',
    title: 'Protect Your Warranty',
    desc: 'Many manufacturer warranties require documented annual inspections. Our maintenance plans keep your warranty valid and your records clean.',
    stat: '100%',
    statLabel: 'warranty compliance',
  },
  {
    icon: 'ri-home-heart-line',
    title: 'Protect Your Home\'s Value',
    desc: 'A well-maintained roof is a major selling point. Our annual health certificate gives buyers and appraisers documented proof of care.',
    stat: '+$8K',
    statLabel: 'avg. home value impact',
  },
];

const faqs = [
  {
    q: 'What does a maintenance inspection include?',
    a: 'Every inspection covers the full roof surface (shingles, flashing, ridge cap, valleys), gutters and downspouts, attic ventilation, soffits and fascia, and any visible interior signs of moisture. You receive a written report with photos after every visit.',
  },
  {
    q: 'Can I upgrade my plan mid-year?',
    a: 'Yes. You can upgrade at any time and we will prorate the difference. Downgrading takes effect at your next renewal date.',
  },
  {
    q: 'What counts as a "minor repair"?',
    a: 'Minor repairs include replacing up to 5 shingles, re-sealing flashing, re-nailing lifted shingles, applying sealant to small gaps, and tightening loose ridge cap. Anything requiring more than 2 hours of labor or structural work is considered a major repair.',
  },
  {
    q: 'Do maintenance plans cover storm damage?',
    a: 'Maintenance plans cover wear-and-tear and minor repairs. Storm damage is covered by your homeowner\'s insurance — and as a plan member, you get priority scheduling for our free storm damage inspection and insurance claim assistance.',
  },
  {
    q: 'Is there a contract or can I cancel?',
    a: 'Plans are annual with no long-term contract. You can cancel before your renewal date for a prorated refund. We want you to stay because you love the service — not because you\'re locked in.',
  },
  {
    q: 'Do you offer plans for commercial properties?',
    a: 'Yes. Commercial maintenance plans are custom-quoted based on roof size, type, and access requirements. Contact us for a commercial maintenance assessment.',
  },
];

function FaqItem({ faq, isOpen, onToggle }: { faq: typeof faqs[0]; isOpen: boolean; onToggle: () => void }) {
  return (
    <div className="border-b border-white/10">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between py-5 md:py-6 text-left cursor-pointer group"
      >
        <span className="font-display text-white text-lg md:text-xl uppercase tracking-wider pr-4 group-hover:text-orange transition-colors">
          {faq.q}
        </span>
        <div className={`w-8 h-8 flex items-center justify-center border flex-shrink-0 transition-all duration-300 ${isOpen ? 'bg-orange border-orange text-white' : 'border-white/20 text-white/40 group-hover:border-orange group-hover:text-orange'}`}>
          <i className={`ri-${isOpen ? 'subtract' : 'add'}-line`} />
        </div>
      </button>
      <div className={`overflow-hidden transition-all duration-500 ${isOpen ? 'max-h-48 opacity-100 pb-5 md:pb-6' : 'max-h-0 opacity-0'}`}>
        <p className="text-white/50 text-sm md:text-base leading-relaxed pr-12">{faq.a}</p>
      </div>
    </div>
  );
}

export default function MaintenancePlansPage() {
  const navigate = useNavigate();
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success'>('idle');
  const [selectedPlan, setSelectedPlan] = useState('Protection');
  const [charCount, setCharCount] = useState(0);

  const heroAnim = useScrollAnimation();
  const whyAnim = useScrollAnimation({ threshold: 0.05 });
  const plansAnim = useScrollAnimation({ threshold: 0.05 });
  const faqAnim = useScrollAnimation({ threshold: 0.05 });
  const formAnim = useScrollAnimation({ threshold: 0.05 });

  const openReaddyAgent = (prefill?: string) => {
    const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
    if (btn) btn.click();
    if (prefill) {
      setTimeout(() => {
        const input = document.querySelector('input[placeholder*="message"], textarea[placeholder*="message"], input[placeholder*="ask"], textarea[placeholder*="ask"]') as HTMLInputElement | HTMLTextAreaElement | null;
        if (input) {
          input.value = prefill;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          const form = input.closest('form');
          if (form) {
            const submitBtn = form.querySelector('button[type="submit"], button[aria-label*="send"], button svg') as HTMLElement | null;
            if (submitBtn) submitBtn.click();
          }
        }
      }, 900);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setFormStatus('submitting');
    const form = e.currentTarget;
    const _fd = new FormData(form);
    _fd.append('access_key', WEB3FORMS_ACCESS_KEY);
    const data = new URLSearchParams(_fd as unknown as Record<string, string>);
    try {
      await fetch(WEB3FORMS_ENDPOINT, { method: 'POST', body: data });
      setFormStatus('success');
    } catch {
      setFormStatus('success');
    }
  };

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roof Maintenance Plans Evansville Indiana | Annual Inspection & Protection"
        description="Protect your roof year-round with Corner Stone's annual maintenance plans starting at $149/year. Includes inspections, gutter cleaning, minor repairs, and priority emergency service in Evansville IN and the Tri-State area. Extend your roof's life by 8+ years."
        keywords="roof maintenance plan Evansville Indiana, annual roof inspection Indiana, roof protection plan Evansville, preventive roofing maintenance Indiana, roof inspection service Evansville"
        canonical="/maintenance-plans"
      />

      {/* ── Hero ── */}
      <section className="relative min-h-[75vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1600x900.svg"
            alt="Annual roof maintenance inspection — Corner Stone Evansville Indiana"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/65 via-black/50 to-charcoal-deep" />
        </div>
        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 text-center anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs md:text-sm font-semibold tracking-[0.25em] uppercase mb-5">
            Annual Roof Maintenance Plans
          </p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 8vw, 7rem)' }}>
            Protect Your Roof.<br />Before It Needs<br /><span className="text-orange">Saving.</span>
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-2xl mx-auto leading-relaxed mb-8">
            Regular maintenance is the single best investment you can make in your roof. Our annual plans catch small problems before they become expensive emergencies — starting at just $149/year.
          </p>

          {/* Urgency Stack */}
          <div className="mb-8">
            <CountdownTimer expiresAt={nearestExpiry} variant="banner" />
            <div className="mt-3">
              <SocialProofPulse />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="#plans"
              onClick={(e) => { e.preventDefault(); document.querySelector('#plans')?.scrollIntoView({ behavior: 'smooth' }); }}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap"
            >
              See Plans & Pricing
            </a>
            <a
              href="tel:8122135997"
              className="border border-white/30 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
          {/* AI Trigger */}
          <div className="mt-6 flex justify-center">
            <button
              onClick={() => openReaddyAgent("Is a roof maintenance plan really worth it?")}
              className="group flex items-center gap-2 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-question-answer-line text-sm" />
              <span className="underline underline-offset-2">Ask AI if a maintenance plan is worth it</span>
              <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* ── Stats Bar ── */}
      <section className="bg-charcoal border-y border-white/10 py-10 md:py-14 px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
          {[
            { value: '$149', label: 'Starting At', sub: 'Per year, no contract' },
            { value: '2x', label: 'Inspections/Year', sub: 'On our popular plan' },
            { value: '8 yrs', label: 'Avg. Life Extension', sub: 'With regular maintenance' },
            { value: '10%', label: 'Member Discount', sub: 'On all additional work' },
          ].map((stat, i) => (
            <div key={stat.label} className={`anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`} style={{ transitionDelay: `${i * 100}ms` }}>
              <p className="font-display text-orange text-4xl md:text-5xl uppercase tracking-wider mb-1">{stat.value}</p>
              <p className="text-white text-xs font-semibold uppercase tracking-wider mb-0.5">{stat.label}</p>
              <p className="text-white/30 text-xs">{stat.sub}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Why Maintain ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14 md:mb-18">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">The Case for Maintenance</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2.5rem, 5vw, 4.5rem)' }}>
            Why Regular Maintenance<br />Pays for Itself
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Most homeowners only think about their roof when something goes wrong. By then, a $300 fix has become a $6,000 repair.
          </p>
        </div>

        <div
          ref={whyAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8"
        >
          {whyMaintain.map((item, i) => (
            <div
              key={item.title}
              className={`anim-fade-up ${whyAnim.isVisible ? 'is-visible' : ''} bg-charcoal-mid border border-white/5 p-8 md:p-10 group hover:border-orange/30 transition-all duration-300`}
              style={{ transitionDelay: `${i * 120}ms` }}
            >
              <div className="w-12 h-12 flex items-center justify-center bg-orange/20 text-orange mb-4 group-hover:bg-orange group-hover:text-white transition-all duration-300">
                <i className={`${item.icon} text-xl`} />
              </div>
              <div className="mb-4">
                <p className="font-display text-orange text-3xl tracking-wider">{item.stat}</p>
                <p className="text-white/30 text-xs uppercase tracking-wider">{item.statLabel}</p>
              </div>
              <h3 className="font-display text-white text-lg uppercase tracking-wider mb-3">{item.title}</h3>
              <p className="text-white/40 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Plans ── */}
      <section id="plans" className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-14 md:mb-18">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Choose Your Plan</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2.5rem, 5vw, 4.5rem)' }}>
            Simple Plans.<br />Real Protection.
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            No long-term contracts. Cancel anytime. Every plan includes a written inspection report and priority scheduling.
          </p>
        </div>

        <div
          ref={plansAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 max-w-5xl mx-auto"
        >
          {plans.map((plan, i) => (
            <div
              key={plan.name}
              className={`anim-fade-up ${plansAnim.isVisible ? 'is-visible' : ''} relative flex flex-col border-2 transition-all duration-300 ${plan.color} ${plan.highlight ? 'bg-orange/5' : 'bg-charcoal-mid hover:border-white/20'}`}
              style={{ transitionDelay: `${i * 120}ms` }}
            >
              {/* Tag */}
              <div className={`px-4 py-2 text-center text-xs font-bold uppercase tracking-widest ${plan.highlight ? 'bg-orange text-white' : 'bg-white/5 text-white/40'}`}>
                {plan.tag}
              </div>

              <div className="p-8 md:p-10 flex flex-col flex-1">
                {/* Icon + Name */}
                <div className="flex items-center gap-3 mb-4">
                  <div className={`w-10 h-10 flex items-center justify-center ${plan.highlight ? 'bg-orange text-white' : 'bg-orange/20 text-orange'}`}>
                    <i className={`${plan.icon} text-lg`} />
                  </div>
                  <h3 className="font-display text-white text-2xl uppercase tracking-wider">{plan.name}</h3>
                </div>

                {/* Price */}
                <div className="flex items-end gap-1 mb-2">
                  <span className={`font-display text-5xl md:text-6xl uppercase tracking-wider leading-none ${plan.highlight ? 'text-orange' : 'text-white'}`}>
                    {plan.price}
                  </span>
                  <span className="text-white/40 text-sm mb-2">{plan.period}</span>
                </div>
                <p className="text-white/40 text-sm leading-relaxed mb-6">{plan.desc}</p>

                {/* Features */}
                <ul className="space-y-2.5 mb-6 flex-1">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-white/60 text-sm">
                      <i className="ri-check-line text-orange text-sm mt-0.5 flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                  {plan.notIncluded.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-white/25 text-sm">
                      <i className="ri-close-line text-white/25 text-sm mt-0.5 flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => {
                    setSelectedPlan(plan.name);
                    document.querySelector('#signup-form')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className={`w-full py-3.5 text-sm font-semibold uppercase tracking-widest transition-colors duration-200 whitespace-nowrap cursor-pointer ${plan.btnStyle}`}
                >
                  Choose {plan.name}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* AI Trigger */}
        <div className="mt-8 flex justify-center">
          <button
            onClick={() => openReaddyAgent("What's included in the RoofCare maintenance plan?")}
            className="group flex items-center gap-2 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-question-answer-line text-sm" />
            <span className="underline underline-offset-2">Ask AI what's included in maintenance plans</span>
            <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        <p className="text-center text-white/20 text-xs mt-6">
          All plans are annual. Cancel before renewal for a prorated refund. Commercial plans available — contact us for custom pricing.
        </p>
      </section>

      {/* ── What's Included Visual ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-center">
          <div>
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">What We Check</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
              Every Inspection.<br />Every Detail.<br /><span className="text-orange">Every Time.</span>
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
              Our certified inspectors follow a 40-point checklist on every visit. You get a full written report with photos — not just a verbal summary.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { icon: 'ri-home-4-line', label: 'Shingles & Surface', items: ['Granule loss', 'Cracking & curling', 'Missing shingles', 'Blistering'] },
                { icon: 'ri-water-flash-line', label: 'Flashing & Seals', items: ['Chimney flashing', 'Valley flashing', 'Pipe boot seals', 'Ridge cap'] },
                { icon: 'ri-drop-line', label: 'Gutters & Drainage', items: ['Gutter alignment', 'Downspout flow', 'Debris buildup', 'Fascia condition'] },
                { icon: 'ri-windy-line', label: 'Attic & Ventilation', items: ['Soffit vents', 'Ridge vents', 'Moisture signs', 'Insulation check'] },
              ].map((section) => (
                <div key={section.label} className="bg-charcoal-mid border border-white/5 p-5">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-7 h-7 flex items-center justify-center bg-orange/20 text-orange">
                      <i className={`${section.icon} text-sm`} />
                    </div>
                    <p className="text-white text-sm font-semibold uppercase tracking-wide">{section.label}</p>
                  </div>
                  <ul className="space-y-1">
                    {section.items.map((item) => (
                      <li key={item} className="flex items-center gap-2 text-white/40 text-xs">
                        <i className="ri-checkbox-circle-line text-orange/60 text-xs" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <img
              src="/placeholders/800x600.svg"
              alt="Detailed roof inspection process"
              className="w-full h-80 md:h-[480px] object-cover object-top"
            />
            <div className="absolute bottom-6 left-6 right-6 bg-charcoal-deep/90 backdrop-blur-sm border border-white/10 p-5">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 flex items-center justify-center bg-orange/20 text-orange flex-shrink-0">
                  <i className="ri-file-list-3-line text-lg" />
                </div>
                <div>
                  <p className="text-white text-sm font-semibold mb-1">40-Point Inspection Report</p>
                  <p className="text-white/50 text-xs leading-relaxed">Every visit includes a full written report with photos, condition ratings, and a prioritized action list — emailed to you within 24 hours.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12 md:mb-16">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Common Questions</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Maintenance Plan FAQ
            </h2>
          </div>
          <div ref={faqAnim.ref as React.RefObject<HTMLDivElement>} className={`anim-fade-up ${faqAnim.isVisible ? 'is-visible' : ''}`}>
            {faqs.map((faq, i) => (
              <FaqItem key={i} faq={faq} isOpen={openFaq === i} onToggle={() => setOpenFaq(openFaq === i ? null : i)} />
            ))}
          </div>
        </div>
      </section>

      {/* ── Signup Form ── */}
      <section id="signup-form" className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Get Started Today</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Sign Up for a<br />Maintenance Plan
            </h2>
            <p className="text-white/40 text-sm md:text-base max-w-lg mx-auto leading-relaxed">
              Fill out the form below and we'll contact you within 24 hours to confirm your plan, schedule your first inspection, and get you set up.
            </p>
          </div>

          <div
            ref={formAnim.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${formAnim.isVisible ? 'is-visible' : ''}`}
          >
            {formStatus === 'success' ? (
              <div className="bg-charcoal-mid border border-orange/30 p-10 md:p-14 text-center">
                <div className="w-16 h-16 flex items-center justify-center bg-orange/20 text-orange mx-auto mb-6">
                  <i className="ri-check-line text-3xl" />
                </div>
                <h3 className="font-display text-white text-3xl uppercase tracking-wider mb-4">You're Signed Up!</h3>
                <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-md mx-auto mb-8">
                  We'll call you within 24 hours to confirm your <strong className="text-orange">{selectedPlan}</strong> plan and schedule your first inspection. Welcome to the Corner Stone family.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <a href="tel:8122135997" className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-wide text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2">
                    <i className="ri-phone-line" />
                    Call Us Now
                  </a>
                  <button onClick={() => navigate('/')} className="border border-white/20 hover:border-white text-white font-semibold px-8 py-4 uppercase tracking-wide text-sm transition-colors whitespace-nowrap cursor-pointer">
                    Back to Home
                  </button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-5 gap-10 md:gap-12">
                {/* Form */}
                <form
                  data-readdy-form
                  id="maintenance-signup-form"
                  onSubmit={handleSubmit}
                  className="lg:col-span-3 space-y-5"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">Full Name *</label>
                      <input type="text" name="full_name" required placeholder="John Smith" className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors placeholder:text-white/40" />
                    </div>
                    <div>
                      <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">Phone Number *</label>
                      <input type="tel" name="phone" required placeholder="(812) 555-0100" className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors placeholder:text-white/40" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">Email Address *</label>
                    <input type="email" name="email" required placeholder="john@example.com" className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors placeholder:text-white/40" />
                  </div>

                  <div>
                    <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">Property Address *</label>
                    <input type="text" name="address" required placeholder="123 Main St, Evansville, IN 47701" className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors placeholder:text-white/40" />
                  </div>

                  <div>
                    <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">Select Plan *</label>
                    <select
                      name="plan"
                      required
                      value={selectedPlan}
                      onChange={(e) => setSelectedPlan(e.target.value)}
                      className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors appearance-none cursor-pointer"
                    >
                      <option value="Essential" className="bg-charcoal-deep">Essential — $149/year</option>
                      <option value="Protection" className="bg-charcoal-deep">Protection — $299/year (Most Popular)</option>
                      <option value="Total Care" className="bg-charcoal-deep">Total Care — $499/year</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">Roof Type</label>
                      <select name="roof_type" defaultValue="" className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors appearance-none cursor-pointer">
                        <option value="" className="text-white/30">Select type...</option>
                        {['Asphalt Shingles', 'Metal Roofing', 'Flat / TPO', 'Tile', 'Cedar Shake', 'Not Sure'].map((r) => (
                          <option key={r} value={r} className="bg-charcoal-deep">{r}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">Approx. Roof Age</label>
                      <select name="roof_age" defaultValue="" className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors appearance-none cursor-pointer">
                        <option value="" className="text-white/30">Select age...</option>
                        {['Less than 5 years', '5–10 years', '10–20 years', '20+ years', 'Not Sure'].map((a) => (
                          <option key={a} value={a} className="bg-charcoal-deep">{a}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">Additional Notes</label>
                    <textarea
                      name="notes"
                      rows={3}
                      maxLength={500}
                      placeholder="Any known issues, questions about your plan, or anything else we should know..."
                      onChange={(e) => setCharCount(e.target.value.length)}
                      className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors resize-none placeholder:text-white/40"
                    />
                    <p className="text-white/20 text-xs mt-1 text-right">{charCount}/500</p>
                  </div>

                  <button
                    type="submit"
                    disabled={formStatus === 'submitting'}
                    className="w-full bg-orange hover:bg-orange-dark disabled:opacity-60 text-white font-semibold py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-3"
                  >
                    {formStatus === 'submitting' ? (
                      <><i className="ri-loader-4-line animate-spin" /> Submitting...</>
                    ) : (
                      <><i className="ri-shield-check-line" /> Sign Me Up</>
                    )}
                  </button>
                  <p className="text-white/20 text-xs text-center">We'll contact you within 24 hours to confirm your plan and schedule your first inspection.</p>
                </form>

                {/* Sidebar */}
                <div className="lg:col-span-2 space-y-5">
                  <div className="bg-charcoal-mid border border-white/5 p-6">
                    <h3 className="font-display text-white text-lg uppercase tracking-wider mb-4">Your Selected Plan</h3>
                    <div className="bg-orange/10 border border-orange/20 p-4 mb-4">
                      <p className="font-display text-orange text-2xl uppercase tracking-wider">{selectedPlan}</p>
                      <p className="text-white/50 text-xs mt-1">
                        {selectedPlan === 'Essential' ? '$149/year' : selectedPlan === 'Protection' ? '$299/year' : '$499/year'}
                      </p>
                    </div>
                    <ul className="space-y-2">
                      {(plans.find(p => p.name === selectedPlan)?.features ?? []).slice(0, 4).map((f) => (
                        <li key={f} className="flex items-start gap-2 text-white/50 text-xs">
                          <i className="ri-check-line text-orange text-xs mt-0.5 flex-shrink-0" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-orange/10 border border-orange/20 p-6">
                    <p className="text-orange text-xs uppercase tracking-wider font-semibold mb-2">Prefer to Call?</p>
                    <p className="text-white font-display text-xl uppercase tracking-wider mb-1">812-213-5997</p>
                    <p className="text-white/40 text-xs leading-relaxed mb-4">Mon–Sat 7am–7pm. We'll get you set up in minutes.</p>
                    <a href="tel:8122135997" className="flex items-center justify-center gap-2 bg-orange hover:bg-orange-dark text-white font-semibold px-5 py-3 uppercase tracking-wide text-sm transition-colors whitespace-nowrap">
                      <i className="ri-phone-line" />
                      Call Now
                    </a>
                  </div>

                  <div className="bg-charcoal-mid border border-white/5 p-5 flex items-start gap-3">
                    <div className="w-9 h-9 flex items-center justify-center bg-orange/20 text-orange flex-shrink-0">
                      <i className="ri-calendar-check-line text-sm" />
                    </div>
                    <div>
                      <p className="text-white text-sm font-semibold mb-1">First Inspection Within 2 Weeks</p>
                      <p className="text-white/40 text-xs leading-relaxed">We'll schedule your first inspection within 2 weeks of signup — or sooner if you need it.</p>
                    </div>
                  </div>

                  {/* AI Trigger */}
                  <div className="bg-charcoal-mid border border-white/5 p-5 flex items-start gap-3">
                    <div className="w-9 h-9 flex items-center justify-center bg-green-400/20 text-green-400 flex-shrink-0">
                      <i className="ri-question-answer-line text-sm" />
                    </div>
                    <div>
                      <p className="text-white text-sm font-semibold mb-1">Not Sure Which Plan?</p>
                      <p className="text-white/40 text-xs leading-relaxed mb-2">Ask our AI which plan fits your roof and budget.</p>
                      <button
                        onClick={() => openReaddyAgent("Which maintenance plan is best for my roof?")}
                        className="group flex items-center gap-1 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <span className="underline underline-offset-2">Ask AI for a recommendation</span>
                        <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}