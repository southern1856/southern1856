import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import PageSEO from '@/components/feature/PageSEO';

function openReaddyAgent(prefill?: string) {
  const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
  if (btn) btn.click();
  if (!prefill) return;
  setTimeout(() => {
    const input = document.querySelector('input[placeholder*="message" i], textarea[placeholder*="message" i], input[placeholder*="ask" i], textarea[placeholder*="ask" i], input[placeholder*="type" i], textarea[placeholder*="type" i]') as HTMLInputElement | HTMLTextAreaElement | null;
    if (input) {
      input.value = prefill;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      const form = input.closest('form');
      if (form) {
        const submitBtn = form.querySelector('button[type="submit"], button[aria-label*="send" i]') as HTMLElement | null;
        if (submitBtn) submitBtn.click();
      }
    }
  }, 900);
}

const plans = [
  {
    name: 'Same-As-Cash',
    tag: 'Most Popular',
    highlight: true,
    rate: '0%',
    rateLabel: 'Interest',
    term: '12 Months',
    minAmount: '$2,000',
    desc: 'Pay nothing extra if paid in full within 12 months. Perfect for smaller repairs or homeowners who want flexibility without long-term commitment.',
    features: [
      'No interest if paid in full',
      'Monthly payment as low as $167',
      'Same-day approval decision',
      'No prepayment penalty',
    ],
    icon: 'ri-percent-line',
  },
  {
    name: 'Low Monthly',
    tag: 'Best for Full Replacements',
    highlight: false,
    rate: 'From $89',
    rateLabel: '/ Month',
    term: 'Up to 120 Months',
    minAmount: '$3,000',
    desc: 'Spread your roof replacement over up to 10 years with predictable monthly payments. Great for full replacements where upfront cost is a concern.',
    features: [
      'Terms from 24 to 120 months',
      'Fixed monthly payments',
      'Covers full replacement cost',
      'Soft credit check to apply',
    ],
    icon: 'ri-calendar-line',
  },
  {
    name: 'Deferred Payment',
    tag: 'No Payments Now',
    highlight: false,
    rate: '90 Days',
    rateLabel: 'No Payment',
    term: 'Then Low Rate',
    minAmount: '$5,000',
    desc: 'Get your roof done today and make no payments for 90 days. Ideal after a storm when insurance is still processing your claim.',
    features: [
      '90-day payment deferral',
      'No payments while claim processes',
      'Competitive rate after deferral',
      'Works alongside insurance payout',
    ],
    icon: 'ri-time-line',
  },
];

const steps = [
  {
    num: '01',
    title: 'Get Your Free Estimate',
    desc: 'We inspect your roof and give you a detailed quote with exact costs — no surprises.',
    icon: 'ri-search-line',
  },
  {
    num: '02',
    title: 'Choose a Plan',
    desc: 'Pick the financing option that fits your budget. Our team walks you through every option.',
    icon: 'ri-bank-card-line',
  },
  {
    num: '03',
    title: 'Quick Approval',
    desc: 'Apply in minutes. Most customers get a same-day decision with a soft credit check.',
    icon: 'ri-checkbox-circle-line',
  },
  {
    num: '04',
    title: 'We Get to Work',
    desc: 'Financing approved, crew scheduled. Your new roof goes on — often within days.',
    icon: 'ri-hammer-line',
  },
];

const faqs = [
  {
    q: 'Will applying affect my credit score?',
    a: 'The initial application uses a soft credit pull, which does not affect your credit score. A hard pull is only done if you proceed with a loan offer.',
  },
  {
    q: 'What credit score do I need to qualify?',
    a: 'We work with multiple lenders to find options for a wide range of credit profiles. Many customers with scores as low as 580 have been approved. We encourage everyone to apply.',
  },
  {
    q: 'Can I finance storm damage repairs?',
    a: 'Absolutely. Our deferred payment plan is specifically designed for storm damage situations where insurance is still processing. You get the roof fixed now and pay when your claim settles.',
  },
  {
    q: 'How long does approval take?',
    a: 'Most applicants receive a decision within minutes. In some cases it may take up to 24 hours. We will walk you through the process during your free estimate.',
  },
  {
    q: 'Is there a minimum project size for financing?',
    a: 'Financing is available for projects starting at $2,000. This covers most repairs and all full replacements.',
  },
  {
    q: 'Can I pay off my loan early?',
    a: 'Yes — there are no prepayment penalties on any of our financing plans. Pay it off early and save on interest.',
  },
];

function FaqItem({ faq, isOpen, onToggle }: { faq: typeof faqs[0]; isOpen: boolean; onToggle: () => void }) {
  return (
    <div className="border-b border-white/10">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between py-5 md:py-6 text-left cursor-pointer group"
      >
        <span className="font-display text-white text-lg md:text-xl uppercase tracking-wider pr-4 group-hover:text-orange transition-colors">
          {faq.q}
        </span>
        <div className={`w-8 h-8 flex items-center justify-center border flex-shrink-0 transition-all duration-300 ${isOpen ? 'bg-orange border-orange text-white' : 'border-white/20 text-white/40 group-hover:border-orange group-hover:text-orange'}`}>
          <i className={`ri-${isOpen ? 'subtract' : 'add'}-line`} />
        </div>
      </button>
      <div className={`overflow-hidden transition-all duration-500 ${isOpen ? 'max-h-48 opacity-100 pb-5 md:pb-6' : 'max-h-0 opacity-0'}`}>
        <p className="text-white/50 text-sm md:text-base leading-relaxed pr-12">{faq.a}</p>
      </div>
    </div>
  );
}

export default function FinancingPage() {
  const navigate = useNavigate();
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const heroAnim = useScrollAnimation();
  const plansAnim = useScrollAnimation({ threshold: 0.05 });
  const stepsAnim = useScrollAnimation({ threshold: 0.05 });
  const faqAnim = useScrollAnimation({ threshold: 0.05 });
  const ctaAnim = useScrollAnimation({ threshold: 0.05 });

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roof Financing Evansville Indiana | 0% Interest & $89/Month Plans"
        description="Flexible roof financing options in Evansville Indiana. 0% interest plans, $89/month payments, and 90-day deferred options for storm damage claims. Corner Stone Construction & Roofing — same-day approval, no prepayment penalties. Call 812-213-5997."
        keywords="roof financing Evansville Indiana, 0% interest roofing loan Indiana, roof payment plan Evansville, affordable roofing financing, storm damage roof financing Indiana"
        canonical="/financing"
      />

      {/* ── Hero ── */}
      <section className="relative min-h-[75vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1600x900.svg"
            alt="Financing your new roof"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-charcoal-deep" />
        </div>
        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 text-center anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs md:text-sm font-semibold tracking-[0.25em] uppercase mb-5">
            Flexible Financing Options
          </p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 8vw, 7rem)' }}>
            New Roof.<br />Your Budget.<br /><span className="text-orange">Your Terms.</span>
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-2xl mx-auto leading-relaxed mb-10">
            Don't let cost stand between you and a safe, solid roof. We offer flexible payment plans so you can get the roof you need — starting at $89/month.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigate('/#contact')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap cursor-pointer"
            >
              Check My Options
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/30 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-phone-line" />
              812-213-5997
            </a>
          </div>

          {/* AI Assistant prompt */}
          <div
            className="mt-8 inline-flex items-center gap-3 bg-white/5 border border-white/10 hover:border-green-400/40 px-5 py-3 cursor-pointer transition-colors duration-200"
            onClick={() => openReaddyAgent("What are my roof financing options in Evansville?")}
            role="button"
          >
            <span className="relative w-2 h-2">
              <span className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-75" />
              <span className="relative w-2 h-2 rounded-full bg-green-400 block" />
            </span>
            <i className="ri-mic-line text-green-400 text-sm" />
            <span className="text-white/60 text-xs font-medium uppercase tracking-wider">Not sure which plan fits you? Ask our AI — it'll walk you through it</span>
            <i className="ri-arrow-right-line text-white/40 text-xs" />
          </div>
        </div>
      </section>

      {/* ── Quick Stats ── */}
      <section className="py-14 md:py-20 px-6 md:px-10 lg:px-16 border-b border-white/10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center">
          {[
            { value: '0%', label: 'Interest Available', sub: 'For qualified buyers' },
            { value: '$89', label: 'Starting / Month', sub: 'Full replacement' },
            { value: '90 Days', label: 'Deferred Option', sub: 'No payments upfront' },
            { value: '10 Min', label: 'Avg. Approval', sub: 'Same-day decision' },
          ].map((stat) => (
            <div key={stat.label}>
              <p className="font-display text-orange text-4xl md:text-5xl uppercase tracking-wider mb-1">{stat.value}</p>
              <p className="text-white text-sm font-semibold uppercase tracking-wider mb-0.5">{stat.label}</p>
              <p className="text-white/30 text-xs">{stat.sub}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Plans ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-16">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Payment Plans</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Three Ways to Pay.<br />Zero Excuses to Wait.
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Every plan is designed around real homeowner situations. Pick what works for you — we'll handle the rest.
          </p>
        </div>

        <div
          ref={plansAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8"
        >
          {plans.map((plan, i) => (
            <div
              key={plan.name}
              className={`anim-fade-up ${plansAnim.isVisible ? 'is-visible' : ''} relative flex flex-col border transition-all duration-300 ${
                plan.highlight
                  ? 'border-orange bg-orange/5'
                  : 'border-white/10 bg-charcoal-mid hover:border-white/30'
              }`}
              style={{ transitionDelay: `${i * 120}ms` }}
            >
              {plan.highlight && (
                <div className="bg-orange text-white text-xs font-bold uppercase tracking-widest px-4 py-2 text-center">
                  {plan.tag}
                </div>
              )}
              {!plan.highlight && (
                <div className="bg-white/5 text-white/40 text-xs font-semibold uppercase tracking-widest px-4 py-2 text-center">
                  {plan.tag}
                </div>
              )}

              <div className="p-8 md:p-10 flex flex-col flex-1">
                {/* Rate */}
                <div className="flex items-end gap-2 mb-2">
                  <span className={`font-display text-5xl md:text-6xl uppercase tracking-wider leading-none ${plan.highlight ? 'text-orange' : 'text-white'}`}>
                    {plan.rate}
                  </span>
                  <span className="text-white/40 text-sm mb-2">{plan.rateLabel}</span>
                </div>
                <p className="text-white/30 text-xs uppercase tracking-widest mb-1">{plan.term}</p>
                <p className="text-white/30 text-xs mb-6">Min. project: {plan.minAmount}</p>

                <div className="w-8 h-8 flex items-center justify-center bg-orange/20 text-orange mb-4">
                  <i className={`${plan.icon} text-base`} />
                </div>

                <h3 className="font-display text-white text-2xl uppercase tracking-wider mb-3">{plan.name}</h3>
                <p className="text-white/40 text-sm leading-relaxed mb-6 flex-1">{plan.desc}</p>

                <ul className="space-y-2.5 mb-8">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-white/50 text-sm">
                      <i className="ri-check-line text-orange text-sm mt-0.5 flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => navigate('/#contact')}
                  className={`w-full py-3.5 text-sm font-semibold uppercase tracking-widest transition-colors duration-200 whitespace-nowrap cursor-pointer ${
                    plan.highlight
                      ? 'bg-orange hover:bg-orange-dark text-white'
                      : 'border border-white/20 hover:border-orange text-white/70 hover:text-white'
                  }`}
                >
                  Apply for This Plan
                </button>
              </div>
            </div>
          ))}
        </div>

        <p className="text-center text-white/40 text-xs mt-8">
          Subject to credit approval. Rates and terms vary by lender and credit profile. Ask us for details during your free estimate.
        </p>
      </section>

      {/* ── How It Works ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-16">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">The Process</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            From Estimate<br />to Approved in Hours
          </h2>
        </div>

        <div
          ref={stepsAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8"
        >
          {steps.map((step, i) => (
            <div
              key={step.num}
              className={`anim-fade-up ${stepsAnim.isVisible ? 'is-visible' : ''} relative bg-charcoal-mid border border-white/5 p-8 md:p-10`}
              style={{ transitionDelay: `${i * 150}ms` }}
            >
              <span className="font-display text-white/8 text-6xl md:text-7xl absolute top-4 right-4 leading-none select-none">
                {step.num}
              </span>
              <div className="w-12 h-12 flex items-center justify-center bg-orange/20 text-orange mb-6">
                <i className={`${step.icon} text-xl`} />
              </div>
              <h3 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider mb-3">{step.title}</h3>
              <p className="text-white/40 text-sm leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Why Finance Banner ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-center">
          <div>
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Why Finance?</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              A Leaking Roof<br />Costs More<br />Every Day You Wait
            </h2>
            <p className="text-white/40 text-sm md:text-base leading-relaxed mb-8">
              Water damage compounds fast. A small leak ignored for 6 months can turn a $8,000 roof job into a $25,000 structural repair. Financing lets you fix it now — before the damage spreads — without draining your savings.
            </p>
            <div className="space-y-4">
              {[
                { icon: 'ri-shield-check-line', text: 'Protect your home\'s structural integrity now' },
                { icon: 'ri-money-dollar-circle-line', text: 'Avoid costly water damage repairs later' },
                { icon: 'ri-home-heart-line', text: 'Maintain your home\'s value and curb appeal' },
                { icon: 'ri-calendar-check-line', text: 'Lock in today\'s pricing before material costs rise' },
              ].map((item) => (
                <div key={item.text} className="flex items-start gap-3">
                  <div className="w-8 h-8 flex items-center justify-center bg-orange/20 text-orange flex-shrink-0 mt-0.5">
                    <i className={`${item.icon} text-sm`} />
                  </div>
                  <p className="text-white/60 text-sm leading-relaxed">{item.text}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <img
              src="/placeholders/800x600.svg"
              alt="Happy homeowner with new roof"
              className="w-full h-80 md:h-96 object-cover object-top"
            />
            <div className="absolute bottom-6 left-6 right-6 bg-charcoal-deep/90 backdrop-blur-sm border border-white/10 p-5">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 flex items-center justify-center bg-orange/20 text-orange flex-shrink-0">
                  <i className="ri-double-quotes-l text-lg" />
                </div>
                <div>
                  <p className="text-white/70 text-sm leading-relaxed italic mb-2">
                    "The financing made it possible. We got the roof done before the next storm season and paid it off in 8 months."
                  </p>
                  <p className="text-orange text-xs font-semibold uppercase tracking-wider">— Mike T., Evansville IN</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12 md:mb-16">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Common Questions</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Financing FAQ
            </h2>
          </div>
          <div ref={faqAnim.ref as React.RefObject<HTMLDivElement>} className={`anim-fade-up ${faqAnim.isVisible ? 'is-visible' : ''}`}>
            {faqs.map((faq, i) => (
              <FaqItem
                key={i}
                faq={faq}
                isOpen={openFaq === i}
                onToggle={() => setOpenFaq(openFaq === i ? null : i)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div
          ref={ctaAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${ctaAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="bg-charcoal-mid border border-white/5 p-10 md:p-16 lg:p-20 text-center">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Ready to Get Started?</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
              Get Your Free Estimate<br />&amp; Financing Options Today
            </h2>
            <p className="text-white/40 text-sm md:text-base max-w-lg mx-auto leading-relaxed mb-10">
              We'll inspect your roof, give you an honest quote, and walk you through every financing option — no pressure, no obligation.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => navigate('/#contact')}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap cursor-pointer"
              >
                Request Free Estimate
              </button>
              <a
                href="tel:8122135997"
                className="border border-white/20 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-phone-line text-orange" />
                Call 812-213-5997
              </a>
            </div>

            {/* AI prompt */}
            <div
              className="mt-8 inline-flex items-center gap-3 bg-white/5 border border-white/10 hover:border-green-400/40 px-5 py-3 cursor-pointer transition-colors duration-200"
              onClick={() => openReaddyAgent("How do I apply for roof financing with Corner Stone?")}
              role="button"
            >
              <i className="ri-mic-line text-green-400 text-sm" />
              <span className="text-white/60 text-xs font-medium uppercase tracking-wider">Ask AI about credit requirements, payment timelines, or plan details</span>
              <i className="ri-arrow-right-line text-white/40 text-xs" />
            </div>

            <p className="text-white/40 text-xs mt-6">Free inspections available Monday–Saturday, 7 AM – 6 PM</p>
          </div>
        </div>
      </section>
    </div>
  );
}