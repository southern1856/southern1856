import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import DealExpiringSoon from '@/pages/promotions/components/DealExpiringSoon';
import { OFFERS } from '@/mocks/promotions';

const servicesSchema = {
  '@context': 'https://schema.org',
  '@type': 'ItemList',
  name: 'Roofing & Exterior Services — Corner Stone Construction & Roofing Evansville Indiana',
  description: 'Complete roofing and exterior services in Evansville Indiana. Residential roofing, commercial roofing, storm damage, siding, gutters, inspections, and more.',
  url: 'https://cornerstoneroofing.com/services',
  numberOfItems: 10,
  itemListElement: [
    { '@type': 'ListItem', position: 1, name: 'Residential Roofing', url: '/residential-roofing' },
    { '@type': 'ListItem', position: 2, name: 'Commercial Roofing', url: '/commercial-roofing' },
    { '@type': 'ListItem', position: 3, name: 'Storm Damage & Insurance Claims', url: '/storm-damage' },
    { '@type': 'ListItem', position: 4, name: 'Siding & Exterior', url: '/siding-exterior' },
    { '@type': 'ListItem', position: 5, name: 'Gutters & Downspouts', url: '/gutters-downspouts' },
    { '@type': 'ListItem', position: 6, name: 'Complete Exterior Package', url: '/exterior-package' },
    { '@type': 'ListItem', position: 7, name: 'Insurance Claims Assistance', url: '/insurance-claims' },
    { '@type': 'ListItem', position: 8, name: 'Roof Financing', url: '/roof-financing' },
    { '@type': 'ListItem', position: 9, name: 'Maintenance Plans', url: '/maintenance-plans' },
    { '@type': 'ListItem', position: 10, name: 'Warranty', url: '/warranty' },
  ],
};

const localBusinessSchema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing',
  url: 'https://cornerstoneroofing.com',
  telephone: '+1-812-213-5997',
  email: 'themainstoneconstruction@gmail.com',
  address: {
    '@type': 'PostalAddress',
    streetAddress: '5800 Kansas Rd',
    addressLocality: 'Evansville',
    addressRegion: 'IN',
    postalCode: '47725',
    addressCountry: 'US',
  },
  areaServed: [
    { '@type': 'City', name: 'Evansville', containedInPlace: { '@type': 'State', name: 'Indiana' } },
    { '@type': 'City', name: 'Newburgh', containedInPlace: { '@type': 'State', name: 'Indiana' } },
    { '@type': 'City', name: 'Henderson', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
    { '@type': 'City', name: 'Boonville', containedInPlace: { '@type': 'State', name: 'Indiana' } },
    { '@type': 'City', name: 'Owensboro', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  ],
  hasOfferCatalog: {
    '@type': 'OfferCatalog',
    name: 'Roofing & Exterior Services',
    itemListElement: [
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Residential Roof Replacement', url: '/residential-roofing' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Commercial Roofing', url: '/commercial-roofing' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Storm Damage Restoration', url: '/storm-damage' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Siding Installation', url: '/siding-exterior' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Gutter Installation', url: '/gutters-downspouts' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Complete Exterior Package', url: '/exterior-package' } },
    ],
  },
};

const PRIMARY_SERVICES = [
  {
    id: 'residential-roofing',
    href: '/residential-roofing',
    icon: 'ri-home-4-line',
    category: 'Residential',
    title: 'Residential Roofing',
    tagline: 'Full replacement, repair & new construction',
    description: 'Asphalt shingles, metal panels, tile, and flat roofing for homes of all sizes. GAF & Owens Corning certified installer with 30–50 year manufacturer warranties.',
    features: ['Architectural Shingles', 'Metal Roofing', 'Tile & Slate', 'Flat Roof Systems'],
    badge: null,
    highlight: false,
    warranty: '10–50 Year Warranty',
    timeline: '1–3 Days',
    image: '/placeholders/600x380.svg',
  },
  {
    id: 'commercial-roofing',
    href: '/commercial-roofing',
    icon: 'ri-building-4-line',
    category: 'Commercial',
    title: 'Commercial Roofing',
    tagline: 'TPO, EPDM, metal & flat roofing systems',
    description: 'Large-scale roofing for offices, warehouses, retail, and industrial facilities up to 100,000 sq ft. Minimal business disruption — nights and weekends available.',
    features: ['TPO & EPDM Membranes', 'Standing Seam Metal', 'Modified Bitumen', 'Roof Coatings'],
    badge: null,
    highlight: false,
    warranty: '15–30 Year Warranty',
    timeline: '3–14 Days',
    image: '/placeholders/600x380.svg',
  },
  {
    id: 'storm-damage',
    href: '/storm-damage',
    icon: 'ri-thunderstorms-line',
    category: 'Storm & Insurance',
    title: 'Storm Damage',
    tagline: 'Hail, wind & insurance claim specialists',
    description: 'We document every dent and crack, meet your adjuster on-site, and advocate for full replacement. Most clients pay only their deductible.',
    features: ['Hail Damage Assessment', 'Adjuster Meeting', 'Supplement Filing', 'Full Replacement Advocacy'],
    badge: 'Insurance Covers',
    highlight: false,
    warranty: 'Lifetime Workmanship',
    timeline: 'Inspection in 24–48 Hrs',
    image: '/placeholders/600x380.svg',
  },
  {
    id: 'exterior-package',
    href: '/exterior-package',
    icon: 'ri-home-gear-line',
    category: 'Bundle',
    title: 'Complete Exterior Package',
    tagline: 'Roof + Siding + Gutters — one crew, one visit',
    description: 'Bundle all three exterior trades and save $800–$2,000. One crew, one visit, one warranty. The smartest way to renovate your entire exterior.',
    features: ['Full Roof Replacement', 'Siding Installation', 'Seamless Gutters', 'Single Warranty'],
    badge: 'Save $800–$2,000',
    highlight: true,
    warranty: 'Lifetime Single Warranty',
    timeline: '3–7 Days',
    image: '/placeholders/600x380.svg',
  },
  {
    id: 'siding-exterior',
    href: '/siding-exterior',
    icon: 'ri-layout-masonry-line',
    category: 'Exterior',
    title: 'Siding & Exterior',
    tagline: 'Vinyl, James Hardie & wood siding',
    description: 'Transform your home\'s curb appeal with premium siding. Certified James Hardie preferred contractor. Bundle with your roof for maximum savings.',
    features: ['Vinyl Siding', 'James Hardie Fiber Cement', 'Wood & Cedar', 'Exterior Trim & Fascia'],
    badge: null,
    highlight: false,
    warranty: 'Lifetime Workmanship',
    timeline: '2–5 Days',
    image: '/placeholders/600x380.svg',
  },
  {
    id: 'gutters-downspouts',
    href: '/gutters-downspouts',
    icon: 'ri-water-flash-line',
    category: 'Drainage',
    title: 'Gutters & Downspouts',
    tagline: 'Seamless aluminum, copper & leaf guard systems',
    description: 'Custom-fabricated seamless gutters protect your foundation and landscaping. Hidden hangers, 30+ colors, and optional leaf guard systems.',
    features: ['Seamless Aluminum', 'K-Style & Half-Round', 'Leaf Guard Systems', 'Copper Gutters'],
    badge: null,
    highlight: false,
    warranty: '20 Year Warranty',
    timeline: '1 Day',
    image: '/placeholders/600x380.svg',
  },
];

const SECONDARY_SERVICES = [
  {
    href: '/insurance-claims',
    icon: 'ri-file-shield-2-line',
    title: 'Insurance Claims Assistance',
    desc: 'We handle the entire claim process — inspection, adjuster meeting, documentation, and supplement filing. Most clients pay only their deductible.',
    tag: 'Free Service',
  },
  {
    href: '/roof-financing',
    icon: 'ri-bank-card-line',
    title: 'Roof Financing',
    desc: 'Flexible payment plans starting from $89/month. 0% interest options available for qualified buyers through GreenSky, Synchrony, and EnerBank.',
    tag: 'From $89/mo',
  },
  {
    href: '/maintenance-plans',
    icon: 'ri-shield-check-line',
    title: 'Maintenance Plans',
    desc: 'Annual inspection and maintenance plans starting at $149/year. Catch small problems before they become expensive emergencies.',
    tag: 'From $149/yr',
  },
  {
    href: '/warranty',
    icon: 'ri-award-line',
    title: 'Warranty Coverage',
    desc: 'Every installation is backed by a workmanship warranty plus full manufacturer material warranties. We register warranties on your behalf.',
    tag: 'Lifetime Available',
  },
];

const TRUST_STATS = [
  { value: '2,400+', label: 'Roofs Completed', icon: 'ri-home-4-line' },
  { value: '29 Yrs', label: 'In Business', icon: 'ri-calendar-line' },
  { value: '4.9★', label: 'Google Rating', icon: 'ri-star-fill' },
  { value: '100%', label: 'Licensed & Insured', icon: 'ri-shield-check-line' },
];

const SERVICE_AREAS = [
  { city: 'Evansville', state: 'IN', href: '/locations/evansville' },
  { city: 'Newburgh', state: 'IN', href: '/locations/newburgh' },
  { city: 'Boonville', state: 'IN', href: '/locations/boonville' },
  { city: 'Mount Vernon', state: 'IN', href: '/locations/mount-vernon' },
  { city: 'Princeton', state: 'IN', href: '/locations/princeton' },
  { city: 'Henderson', state: 'KY', href: '/locations/henderson-ky' },
  { city: 'Owensboro', state: 'KY', href: '/locations/owensboro-ky' },
];

function PrimaryServiceCard({ service, index }: { service: typeof PRIMARY_SERVICES[0]; index: number }) {
  const navigate = useNavigate();
  const anim = useScrollAnimation({ threshold: 0.08 });

  return (
    <div
      ref={anim.ref as React.RefObject<HTMLDivElement>}
      className={`anim-fade-up ${anim.isVisible ? 'is-visible' : ''}`}
      style={{ transitionDelay: `${(index % 3) * 100}ms` }}
    >
      <article
        onClick={() => navigate(service.href)}
        className={`group cursor-pointer h-full flex flex-col border transition-all duration-400 overflow-hidden ${
          service.highlight
            ? 'border-orange/50 bg-orange/5 hover:border-orange hover:bg-orange/10'
            : 'border-white/8 bg-charcoal-mid hover:border-orange/40'
        }`}
      >
        {/* Image */}
        <div className="relative overflow-hidden" style={{ height: '220px' }}>
          <img
            src={service.image}
            alt={`${service.title} — Corner Stone Evansville Indiana`}
            className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-charcoal-mid via-charcoal-mid/10 to-transparent" />

          {/* Category pill */}
          <div className="absolute top-4 left-4 flex items-center gap-2 flex-wrap">
            <span className={`text-xs font-bold uppercase tracking-widest px-3 py-1 ${service.highlight ? 'bg-orange text-white' : 'bg-white/10 backdrop-blur text-white/80'}`}>
              {service.category}
            </span>
            {service.badge && (
              <span className="bg-orange text-white text-xs font-bold px-3 py-1 uppercase tracking-widest">
                {service.badge}
              </span>
            )}
          </div>

          {/* Meta chips */}
          <div className="absolute bottom-4 left-4 right-4 flex items-center gap-2 flex-wrap">
            <span className="bg-black/50 backdrop-blur text-white/70 text-xs px-2.5 py-1 flex items-center gap-1">
              <i className="ri-shield-check-line text-orange text-xs" />
              {service.warranty}
            </span>
            <span className="bg-black/50 backdrop-blur text-white/70 text-xs px-2.5 py-1 flex items-center gap-1">
              <i className="ri-time-line text-orange text-xs" />
              {service.timeline}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 flex flex-col flex-1">
          {/* Icon + Title */}
          <div className="flex items-start gap-3 mb-3">
            <div className={`w-10 h-10 flex items-center justify-center flex-shrink-0 mt-0.5 ${service.highlight ? 'bg-orange/20 text-orange' : 'bg-white/8 text-orange group-hover:bg-orange/15 transition-colors'}`}>
              <i className={`${service.icon} text-lg`} />
            </div>
            <div>
              <h2 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider leading-tight group-hover:text-orange transition-colors duration-200">
                {service.title}
              </h2>
              <p className="text-orange/80 text-xs uppercase tracking-wider mt-0.5">{service.tagline}</p>
            </div>
          </div>

          {/* Description */}
          <p className="text-white/50 text-sm leading-relaxed mb-4 flex-1">
            {service.description}
          </p>

          {/* Feature chips */}
          <div className="flex flex-wrap gap-1.5 mb-5">
            {service.features.map((f) => (
              <span key={f} className="text-white/40 text-xs border border-white/10 px-2.5 py-1 flex items-center gap-1">
                <i className="ri-check-line text-orange text-xs" />
                {f}
              </span>
            ))}
          </div>

          {/* CTA */}
          <div className={`flex items-center justify-between pt-4 border-t ${service.highlight ? 'border-orange/20' : 'border-white/8'}`}>
            <span className="text-orange text-xs font-semibold uppercase tracking-widest flex items-center gap-1.5 group-hover:gap-2.5 transition-all duration-200">
              View Service
              <i className="ri-arrow-right-line" />
            </span>
            <a
              href={`tel:8122135997`}
              onClick={(e) => e.stopPropagation()}
              className="text-white/30 hover:text-orange text-xs transition-colors flex items-center gap-1"
            >
              <i className="ri-phone-line" />
              Call Now
            </a>
          </div>
        </div>
      </article>
    </div>
  );
}

function SecondaryServiceCard({ service, index }: { service: typeof SECONDARY_SERVICES[0]; index: number }) {
  const navigate = useNavigate();
  const anim = useScrollAnimation({ threshold: 0.1 });

  return (
    <div
      ref={anim.ref as React.RefObject<HTMLDivElement>}
      className={`anim-fade-up ${anim.isVisible ? 'is-visible' : ''}`}
      style={{ transitionDelay: `${index * 80}ms` }}
    >
      <article
        onClick={() => navigate(service.href)}
        className="group cursor-pointer border border-white/8 bg-charcoal-mid hover:border-orange/40 transition-all duration-300 p-6 h-full flex flex-col"
      >
        <div className="flex items-start justify-between gap-3 mb-4">
          <div className="w-11 h-11 flex items-center justify-center bg-orange/15 text-orange group-hover:bg-orange/25 transition-colors flex-shrink-0">
            <i className={`${service.icon} text-xl`} />
          </div>
          <span className="text-orange text-xs font-bold uppercase tracking-widest border border-orange/30 bg-orange/10 px-2.5 py-1 whitespace-nowrap">
            {service.tag}
          </span>
        </div>
        <h3 className="font-display text-white text-lg uppercase tracking-wider mb-2 group-hover:text-orange transition-colors duration-200">
          {service.title}
        </h3>
        <p className="text-white/45 text-sm leading-relaxed flex-1 mb-4">
          {service.desc}
        </p>
        <div className="flex items-center gap-1.5 text-orange text-xs font-semibold uppercase tracking-widest group-hover:gap-2.5 transition-all duration-200">
          Learn More
          <i className="ri-arrow-right-line" />
        </div>
      </article>
    </div>
  );
}

function ProcessSection() {
  const navigate = useNavigate();
  const header = useScrollAnimation({ threshold: 0.1 });
  const steps = useScrollAnimation({ threshold: 0.05 });

  const STEPS = [
    {
      number: '01',
      icon: 'ri-search-eye-line',
      title: 'Free Inspection',
      desc: 'Our certified inspector climbs your roof, documents every issue with photos, and delivers a detailed report — all at no cost.',
      detail: 'Same-day scheduling available. No obligation.',
    },
    {
      number: '02',
      icon: 'ri-file-list-3-line',
      title: 'Clear Quote',
      desc: 'You get a written, itemized estimate with zero hidden fees. We walk you through every line item and answer every question.',
      detail: 'Insurance claim filing included at no charge.',
    },
    {
      number: '03',
      icon: 'ri-hammer-line',
      title: 'Expert Installation',
      desc: 'Our crew shows up on time, works clean, and uses premium materials with manufacturer-certified installation methods.',
      detail: 'Average start time: 48 hours after approval.',
    },
    {
      number: '04',
      icon: 'ri-hand-heart-line',
      title: 'Final Walkthrough',
      desc: 'We review the finished work together, clean the site spotless, and register your warranty on your behalf before leaving.',
      detail: '100% satisfaction check before final payment.',
    },
  ];

  return (
    <div>
      <div
        ref={header.ref as React.RefObject<HTMLDivElement>}
        className={`flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16 md:mb-20 anim-fade-up ${header.isVisible ? 'is-visible' : ''}`}
      >
        <div>
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Our Process</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
            From Inspection<br />To Done Right
          </h2>
        </div>
        <p className="text-white/40 text-sm md:text-base max-w-xs leading-relaxed">
          Four straightforward steps. We keep you informed the whole way — no surprises, no pressure, just honest work.
        </p>
      </div>

      <div
        ref={steps.ref as React.RefObject<HTMLDivElement>}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {STEPS.map((step, i) => (
          <div
            key={step.number}
            className={`relative border border-white/10 bg-charcoal-mid p-8 md:p-10 group hover:border-orange/40 transition-all duration-300 anim-fade-up ${steps.isVisible ? 'is-visible' : ''}`}
            style={{ transitionDelay: `${i * 120}ms` }}
          >
            {i < STEPS.length - 1 && (
              <div className="hidden lg:flex absolute top-10 -right-6 w-12 h-px bg-white/10 z-10 items-center justify-end">
                <i className="ri-arrow-right-line text-white/10 text-xs -mr-2" />
              </div>
            )}

            <div className="flex items-center justify-between mb-8">
              <span className="font-display text-white/10 text-6xl leading-none tracking-wider group-hover:text-orange/20 transition-colors duration-300">
                {step.number}
              </span>
              <div className="w-12 h-12 flex items-center justify-center border border-white/10 group-hover:border-orange group-hover:bg-orange/10 transition-all duration-300">
                <i className={`${step.icon} text-white/40 group-hover:text-orange text-xl transition-colors duration-300`} />
              </div>
            </div>

            <h3 className="font-display text-white text-2xl uppercase tracking-wider mb-3 group-hover:text-orange transition-colors duration-300">
              {step.title}
            </h3>
            <p className="text-white/50 text-sm leading-relaxed mb-4">{step.desc}</p>
            <p className="text-orange/70 text-xs leading-relaxed border-t border-white/5 pt-4">
              <i className="ri-check-line mr-1" />
              {step.detail}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-12 flex flex-col sm:flex-row items-center justify-between gap-6 border border-white/10 bg-charcoal-mid px-8 py-6">
        <div>
          <p className="text-white font-semibold text-lg">Still researching? Step 1 takes 60 seconds.</p>
          <p className="text-white/40 text-sm mt-1">Free inspection · No pressure · Tri-State area</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 flex-shrink-0">
          <a
            href="/estimate"
            onClick={(e) => { e.preventDefault(); navigate('/estimate'); }}
            className="bg-orange hover:bg-orange-dark text-white text-sm font-bold px-8 py-4 uppercase tracking-widest transition-colors duration-200 whitespace-nowrap cursor-pointer"
          >
            Get Free Estimate
          </a>
          <a
            href="tel:8122135997"
            className="border border-white/20 hover:border-orange text-white/70 hover:text-white text-sm font-semibold px-8 py-4 uppercase tracking-widest transition-all duration-200 whitespace-nowrap flex items-center justify-center gap-2"
          >
            <i className="ri-phone-line text-orange" />
            812-213-5997
          </a>
        </div>
      </div>
    </div>
  );
}

export default function ServicesPage() {
  const navigate = useNavigate();
  const heroAnim = useScrollAnimation();
  const statsAnim = useScrollAnimation({ threshold: 0.1 });
  const bundleAnim = useScrollAnimation({ threshold: 0.1 });
  const areasAnim = useScrollAnimation({ threshold: 0.1 });
  const ctaAnim = useScrollAnimation({ threshold: 0.1 });

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roofing Services Evansville Indiana | Residential, Commercial, Storm & Exterior"
        description="Corner Stone Construction & Roofing offers residential roofing, commercial roofing, storm damage restoration, siding, gutters, and complete exterior packages in Evansville IN and the Tri-State area. Licensed & insured. Free inspections. Call 812-213-5997."
        keywords="roofing services Evansville Indiana, residential roofing Evansville, commercial roofing Indiana, storm damage roofing Evansville, siding installation Indiana, gutter installation Evansville, exterior renovation Indiana"
        canonical="/services"
        schema={[servicesSchema, localBusinessSchema]}
      />

      {/* ── Hero ── */}
      <section className="relative min-h-[72vh] flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1600x900.svg"
            alt="Professional roofing and exterior services in Evansville Indiana"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/30 to-charcoal-deep" />
          <div className="absolute inset-0 bg-gradient-to-r from-charcoal-deep/60 to-transparent" />
        </div>

        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 pb-16 md:pb-24 pt-32 anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="max-w-3xl">
            <div className="flex flex-wrap items-center gap-3 mb-6">
              <span className="text-orange text-xs font-bold uppercase tracking-[0.25em] border border-orange/40 bg-orange/10 px-4 py-1.5">
                Evansville Indiana's Trusted Roofer
              </span>
              <span className="text-white/50 text-xs uppercase tracking-widest">Since 1995</span>
            </div>
            <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 8vw, 7.5rem)' }}>
              Every Service.<br />One Crew.<br /><span className="text-orange">Done Right.</span>
            </h1>
            <p className="text-white/55 text-base md:text-lg max-w-xl leading-relaxed mb-6">
              From emergency repairs to complete exterior renovations — Corner Stone handles every roofing and exterior need for homes and businesses across Vanderburgh County and the Tri-State area.
            </p>
            <div className="mb-6">
              <CountdownTimer expiresAt="2026-07-31" variant="banner" />
            </div>
            <div className="mb-6">
              <SocialProofPulse />
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="/estimate"
                onClick={(e) => { e.preventDefault(); navigate('/estimate'); }}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-search-line" />
                Free Inspection
              </a>
              <a
                href="tel:8122135997"
                className="border border-white/30 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-phone-line text-orange" />
                812-213-5997
              </a>
            </div>
          </div>
        </div>
      </section>

      <TalkToAIExpert />

      {/* ── Trust Stats Bar ── */}
      <section className="bg-charcoal border-y border-white/10">
        <div
          ref={statsAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-2 lg:grid-cols-4"
        >
          {TRUST_STATS.map((stat, i) => (
            <div
              key={stat.label}
              className={`anim-fade-up ${statsAnim.isVisible ? 'is-visible' : ''} px-6 md:px-10 py-7 md:py-9 flex items-center gap-4 ${i < TRUST_STATS.length - 1 ? 'border-r border-white/10' : ''}`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="w-10 h-10 flex items-center justify-center bg-orange/15 text-orange flex-shrink-0">
                <i className={`${stat.icon} text-lg`} />
              </div>
              <div>
                <p className="font-display text-white text-2xl md:text-3xl tracking-wider leading-none">{stat.value}</p>
                <p className="text-white/35 text-xs uppercase tracking-wider mt-0.5">{stat.label}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Primary Services Grid ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="mb-14 md:mb-18">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <div>
              <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Core Services</p>
              <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
                What We Do
              </h2>
            </div>
            <p className="text-white/40 text-sm md:text-base max-w-sm leading-relaxed md:text-right">
              Six core services, one standard of excellence. Every job gets the same attention to detail — whether it's a small repair or a 50,000 sq ft commercial install.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
          {PRIMARY_SERVICES.map((service, index) => (
            <PrimaryServiceCard key={service.id} service={service} index={index} />
          ))}
        </div>
      </section>

      {/* ── Our Process ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal border-t border-white/8">
        <ProcessSection />
      </section>

      {/* ── Bundle CTA Banner ── */}
      <section className="px-6 md:px-10 lg:px-16 pb-20 md:pb-28">
        <div
          ref={bundleAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${bundleAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="relative overflow-hidden border border-orange/30 bg-orange/5">
            {/* Background image */}
            <div className="absolute inset-0">
              <img
                src="/placeholders/1400x500.svg"
                alt="Complete exterior renovation bundle"
                className="w-full h-full object-cover object-top opacity-10"
              />
            </div>
            {/* Decorative circles */}
            <div className="absolute -right-20 -top-20 w-80 h-80 rounded-full border border-orange/10" />
            <div className="absolute -right-10 -top-10 w-56 h-56 rounded-full border border-orange/10" />

            <div className="relative z-10 p-8 md:p-12 lg:p-16 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
              <div className="max-w-2xl">
                <div className="inline-flex items-center gap-2 bg-orange text-white text-xs font-bold uppercase tracking-widest px-4 py-1.5 mb-5">
                  <i className="ri-money-dollar-circle-line" />
                  Bundle & Save $800–$2,000
                </div>
                <h3 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
                  Roof + Siding + Gutters.<br /><span className="text-orange">One Crew. One Visit.</span>
                </h3>
                <p className="text-white/55 text-sm md:text-base leading-relaxed mb-6">
                  When you bundle all three exterior trades, you skip three separate mobilization fees, three cleanup costs, and three scheduling headaches. One coordinated project — and we pass the savings directly to you.
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { icon: 'ri-money-dollar-circle-line', label: 'Save $800–$2K' },
                    { icon: 'ri-calendar-check-line', label: 'One Visit' },
                    { icon: 'ri-shield-check-line', label: 'Single Warranty' },
                    { icon: 'ri-paint-brush-line', label: 'Matched Aesthetics' },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center gap-2 text-white/60 text-xs">
                      <i className={`${item.icon} text-orange text-sm flex-shrink-0`} />
                      <span>{item.label}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex flex-col gap-3 flex-shrink-0">
                <a
                  href="/exterior-package"
                  onClick={(e) => { e.preventDefault(); navigate('/exterior-package'); }}
                  className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
                >
                  <i className="ri-home-gear-line" />
                  See Complete Package
                </a>
                <a
                  href="tel:8122135997"
                  className="border border-white/25 hover:border-orange text-white/70 hover:text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2"
                >
                  <i className="ri-phone-line text-orange" />
                  Get Bundle Quote
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Secondary Services ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal border-t border-white/8">
        <div className="mb-12 md:mb-16">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Additional Services</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
            Everything Else<br />You Need
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {SECONDARY_SERVICES.map((service, index) => (
            <SecondaryServiceCard key={service.href} service={service} index={index} />
          ))}
        </div>
      </section>

      {/* ── Why Corner Stone ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-center">
          <div>
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Why Choose Us</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              Evansville's Most<br />Trusted Roofer<br /><span className="text-orange">Since 1995.</span>
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
              We have been protecting homes and businesses across Vanderburgh County for nearly three decades. Our reputation is built on honest assessments, quality materials, and crews that treat your property like their own.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {[
                { icon: 'ri-shield-check-line', title: 'Licensed & Insured', desc: 'Full liability and workers comp. Every crew member is OSHA-certified.' },
                { icon: 'ri-award-line', title: 'Manufacturer Certified', desc: 'GAF, Owens Corning, CertainTeed & Atlas certified — unlocking enhanced warranties.' },
                { icon: 'ri-customer-service-2-line', title: '24/7 Emergency Line', desc: 'Storm damage doesn\'t wait. Our emergency line is always open.' },
                { icon: 'ri-file-shield-2-line', title: 'Insurance Experts', desc: 'We meet your adjuster on-site and advocate for full replacement coverage.' },
              ].map((item) => (
                <div key={item.title} className="flex items-start gap-3">
                  <div className="w-10 h-10 flex items-center justify-center bg-orange/15 text-orange flex-shrink-0 mt-0.5">
                    <i className={`${item.icon} text-lg`} />
                  </div>
                  <div>
                    <h4 className="font-display text-white text-base uppercase tracking-wider mb-1">{item.title}</h4>
                    <p className="text-white/40 text-xs leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <img
              src="/placeholders/800x600.svg"
              alt="Corner Stone roofing crew — Evansville Indiana"
              className="w-full h-80 md:h-[480px] object-cover object-top"
            />
            {/* Floating review card */}
            <div className="absolute bottom-6 left-6 right-6 bg-charcoal-deep/95 backdrop-blur border border-white/10 p-5">
              <div className="flex items-center gap-1 mb-2">
                {[1,2,3,4,5].map((s) => (
                  <i key={s} className="ri-star-fill text-orange text-sm" />
                ))}
                <span className="text-white/40 text-xs ml-2">4.9 · 340+ Google Reviews</span>
              </div>
              <p className="text-white/70 text-sm italic leading-relaxed">
                "Corner Stone replaced our entire roof, siding, and gutters in one week. The crew was professional, the price was fair, and the result is stunning."
              </p>
              <p className="text-white/30 text-xs mt-2 uppercase tracking-wider">— Sarah M., Newburgh IN</p>
            </div>
          </div>
        </div>
      </section>

      {/* ── Service Areas ── */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal border-t border-white/8">
        <div
          ref={areasAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${areasAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6 mb-8">
            <div>
              <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-3">Where We Work</p>
              <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(1.8rem, 4vw, 3.5rem)' }}>
                Serving Indiana &amp; Kentucky
              </h2>
            </div>
            <a
              href="/service-areas"
              onClick={(e) => { e.preventDefault(); navigate('/service-areas'); }}
              className="flex items-center gap-2 text-orange text-sm font-semibold uppercase tracking-widest hover:gap-3 transition-all whitespace-nowrap"
            >
              View All Areas
              <i className="ri-arrow-right-line" />
            </a>
          </div>

          <div className="flex flex-wrap gap-3">
            {SERVICE_AREAS.map((area) => (
              <a
                key={area.href}
                href={area.href}
                onClick={(e) => { e.preventDefault(); navigate(area.href); }}
                className="group flex items-center gap-2 border border-white/10 bg-charcoal-mid hover:border-orange/40 hover:bg-orange/5 px-5 py-3 transition-all duration-200"
              >
                <i className="ri-map-pin-line text-orange text-sm" />
                <span className="text-white/60 group-hover:text-white text-sm transition-colors">
                  {area.city}, <span className="text-white/35">{area.state}</span>
                </span>
              </a>
            ))}
            <a
              href="/service-areas"
              onClick={(e) => { e.preventDefault(); navigate('/service-areas'); }}
              className="flex items-center gap-2 border border-white/10 bg-charcoal-mid hover:border-orange/40 px-5 py-3 transition-all duration-200 text-white/35 hover:text-orange text-sm"
            >
              + More Areas
              <i className="ri-arrow-right-line text-xs" />
            </a>
          </div>
        </div>
      </section>

      {/* ── Final CTA ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div
          ref={ctaAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${ctaAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="relative overflow-hidden bg-charcoal-mid border border-white/8 p-10 md:p-16 lg:p-20 text-center">
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-orange/5 rounded-full blur-3xl" />
            </div>
            <div className="relative z-10">
              <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Ready to Get Started?</p>
              <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
                Free Inspection.<br />No Obligation.<br /><span className="text-orange">Just Honest Advice.</span>
              </h2>
              <p className="text-white/40 text-sm md:text-base max-w-lg mx-auto leading-relaxed mb-10">
                Schedule your free roof inspection today. We'll tell you exactly what you need — and what you don't. No pressure, no upselling, just straight talk from Evansville's most trusted roofing crew.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <a
                  href="/estimate"
                  onClick={(e) => { e.preventDefault(); navigate('/estimate'); }}
                  className="bg-orange hover:bg-orange-dark text-white font-semibold px-12 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
                >
                  <i className="ri-search-line" />
                  Schedule Free Inspection
                </a>
                <a
                  href="tel:8122135997"
                  className="border border-white/25 hover:border-white text-white font-semibold px-12 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
                >
                  <i className="ri-phone-line text-orange" />
                  812-213-5997
                </a>
              </div>
              <p className="text-white/20 text-xs mt-6">
                Free inspections available Monday–Saturday, 7 AM – 6 PM · Emergency line available 24/7
              </p>
            </div>
          </div>
        </div>
      </section>

      <DealExpiringSoon offers={OFFERS} linkToPage="/promotions" />
    </div>
  );
}
