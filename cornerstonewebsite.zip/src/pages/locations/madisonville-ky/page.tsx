import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Madisonville KY',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/madisonville-ky',
  address: { '@type': 'PostalAddress', addressLocality: 'Madisonville', addressRegion: 'KY', postalCode: '42431' },
  areaServed: { '@type': 'City', name: 'Madisonville', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  description: 'Roofing contractor serving Madisonville Kentucky. Free inspections, storm damage, residential & commercial roofing in Hopkins County. Fully licensed in KY.',
};

export default function MadisonvilleKYPage() {
  return (
    <CityPage
      city="Madisonville"
      state="Kentucky"
      stateAbbr="KY"
      county="Hopkins County"
      slug="madisonville-ky"
      population="19,000+"
      distance="50 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Madisonville Kentucky's trusted roofing contractor. Corner Stone is fully licensed in Kentucky and serves Hopkins County with expert residential and commercial roofing, storm damage repair, and 24/7 emergency response."
      longDesc="Corner Stone Construction & Roofing is fully licensed and insured in Kentucky, and we proudly serve Madisonville and all of Hopkins County. As one of Western Kentucky's larger communities, Madisonville has a diverse range of roofing needs — from historic homes near the downtown district to modern commercial properties, healthcare facilities, and educational buildings. Our Kentucky-licensed crews understand the specific weather challenges of this region, including the severe thunderstorms, hail, and occasional tornadoes that can cause significant roof damage. We are experienced in handling insurance claims for storm damage and work directly with Kentucky insurance adjusters to ensure our customers receive fair coverage. Whether you need emergency repairs, a complete roof replacement, or routine maintenance, we bring the same commitment to quality and customer service that has made us a trusted name in the Tri-State area for over 25 years."
      services={['Residential Roofing', 'Commercial Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Flat Roofing', 'Roof Maintenance Plans']}
      neighborhoods={['Madisonville Downtown', 'Hopkins County Courthouse Area', 'Madisonville Community College Area', 'North Madisonville', 'South Madisonville', 'East Madisonville', 'West Madisonville', 'Grapevine Area', 'Nebo Area', 'Dawson Springs Area', 'Rural Hopkins County Routes', 'Earlington Area']}
      faqs={[
        { q: 'Do you provide roofing services in Madisonville Kentucky?', a: 'Yes — we are fully licensed in Kentucky and regularly serve Madisonville and all of Hopkins County. Our KY-licensed crews deliver the same quality as our Indiana operations.' },
        { q: 'How much does a roof replacement cost in Madisonville KY?', a: 'Most residential roof replacements in Madisonville range from $8,500 to $23,000 depending on home size, roof complexity, and materials selected. Free estimates provided.' },
        { q: 'Can you help with Kentucky insurance claims for storm damage?', a: 'Absolutely — we are experienced with Kentucky insurance procedures. We document damage, meet KY adjusters on-site, and handle all claim paperwork to maximize your payout.' },
        { q: 'How quickly can you respond to emergencies in Madisonville?', a: 'Madisonville is approximately 50 miles from our Evansville base. We typically respond within 60 to 90 minutes for emergency calls and offer 24/7 emergency tarping.' },
        { q: 'Are you licensed to work in Kentucky?', a: 'Yes — Corner Stone Construction & Roofing is fully licensed and insured in both Indiana and Kentucky. We meet all Kentucky state and local requirements.' },
      ]}
      schema={schema}
    />
  );
}