import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Santa Claus IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/santa-claus',
  address: { '@type': 'PostalAddress', addressLocality: 'Santa Claus', addressRegion: 'IN', postalCode: '47579' },
  areaServed: { '@type': 'City', name: 'Santa Claus', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Santa Claus Indiana and Spencer County. Free inspections, storm damage repair, residential roofing for Santa Claus homeowners.',
};

export default function SantaClausPage() {
  return (
    <CityPage
      city="Santa Claus"
      state="Indiana"
      stateAbbr="IN"
      county="Spencer County"
      slug="santa-claus"
      population="2,500+"
      distance="40 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Santa Claus and Spencer County's trusted roofing contractor. Corner Stone brings 25+ years of Tri-State roofing expertise to Indiana's most famous small town — same quality, same honest pricing."
      longDesc="Santa Claus is one of Indiana's most iconic communities, drawing visitors year-round to Holiday World and the town's Christmas-themed charm. But behind the festive name is a real community of homeowners who need dependable roofing services. Corner Stone Construction & Roofing is proud to serve Santa Claus and all of Spencer County with the same premium workmanship and straightforward pricing we have built our reputation on since 1995."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims', 'Emergency Repairs']}
      neighborhoods={['Santa Claus Town Center', 'Holiday World Area', 'Christmas Lake Village', 'Frosty Heights', 'Spencer County Rural Routes']}
      faqs={[
        { q: 'Do you serve Santa Claus Indiana for roofing?', a: 'Yes — Santa Claus and Spencer County are within our extended service territory. We provide the same quality workmanship and honest pricing that the Tri-State area has trusted since 1995.' },
        { q: 'How much does a roof replacement cost in Santa Claus IN?', a: 'Residential roof replacements in Santa Claus typically range from $8,000 to $22,000 depending on home size, roof pitch, and materials selected. We provide free, no-obligation estimates for Spencer County homeowners.' },
        { q: 'How quickly can you respond to a roofing emergency in Santa Claus?', a: 'Santa Claus is about 40 miles from Evansville via I-64. We typically respond within 60-90 minutes for emergency calls, often faster if crews are already in the Spencer County area.' },
        { q: 'Do you handle insurance claims for storm damage?', a: 'Yes — our team specializes in storm damage insurance claims. We document all damage thoroughly, meet with your insurance adjuster on-site, and manage the entire claims process to maximize your payout.' },
      ]}
      schema={schema}
    />
  );
}