import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Vincennes IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/vincennes',
  address: { '@type': 'PostalAddress', addressLocality: 'Vincennes', addressRegion: 'IN', postalCode: '47591' },
  areaServed: { '@type': 'City', name: 'Vincennes', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Vincennes Indiana. Free inspections, storm damage, residential & commercial roofing in Knox County.',
};

export default function VincennesPage() {
  return (
    <CityPage
      city="Vincennes"
      state="Indiana"
      stateAbbr="IN"
      county="Knox County"
      slug="vincennes"
      population="17,000+"
      distance="60 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Vincennes' trusted roofing contractor. Corner Stone serves Indiana's oldest city and all of Knox County with expert residential and commercial roofing, historic home restoration, and storm damage repair."
      longDesc="Corner Stone Construction & Roofing is honored to serve Vincennes — Indiana's oldest city — and the greater Knox County area. Vincennes is home to a remarkable collection of historic properties, from colonial-era buildings near the George Rogers Clark National Historical Park to beautiful Victorian homes in the historic districts. Our crews are specially trained to work on historic roofs, carefully preserving architectural character while providing modern protection. Beyond historic restoration, we offer full residential and commercial roofing services throughout Knox County. We understand the local climate patterns that affect roofs in this part of Southwestern Indiana, including the strong winds that sweep across the Wabash River floodplain and the severe thunderstorms that are common during spring and summer. Whether you need emergency repairs, a complete replacement, or routine maintenance, we bring over 25 years of experience and a commitment to quality that Vincennes homeowners can depend on."
      services={['Residential Roofing', 'Commercial Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Historic Roof Restoration', 'Roof Maintenance Plans']}
      neighborhoods={['Vincennes Historic District', 'George Rogers Clark Park Area', 'Vincennes University Area', 'Downtown Vincennes', 'North Vincennes', 'South Vincennes', 'Emison Square Area', 'Bicknell Area', 'Decker Area', 'Rural Knox County Routes', 'Freelandville Area', 'Wheatland Area']}
      faqs={[
        { q: 'Do you provide roofing services in Vincennes Indiana?', a: 'Yes — we proudly serve Vincennes and all of Knox County. Our crews are experienced with both historic home restoration and modern roofing throughout the area.' },
        { q: 'How much does a roof replacement cost in Vincennes IN?', a: 'Most residential roof replacements in Vincennes range from $8,500 to $22,000 depending on home size, roof pitch, and materials. Historic restorations may vary. Free estimates provided.' },
        { q: 'Can you work on historic homes in Vincennes?', a: 'Absolutely — we specialize in historic roof restoration. We carefully match period-appropriate materials and preserve architectural character while ensuring modern weather protection.' },
        { q: 'How quickly can you respond to emergencies in Vincennes?', a: 'Vincennes is approximately 60 miles from our Evansville base. For emergencies, we typically respond within 90 minutes to 2 hours and offer 24/7 emergency services.' },
        { q: 'Do you help with insurance claims in Knox County?', a: 'Yes — we are insurance claim specialists. We document storm damage thoroughly, meet with adjusters, and handle all paperwork to help you receive maximum coverage.' },
      ]}
      schema={schema}
    />
  );
}