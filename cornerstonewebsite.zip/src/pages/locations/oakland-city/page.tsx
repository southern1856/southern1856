import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Oakland City IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/oakland-city',
  address: { '@type': 'PostalAddress', addressLocality: 'Oakland City', addressRegion: 'IN', postalCode: '47660' },
  areaServed: { '@type': 'City', name: 'Oakland City', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Oakland City Indiana. Free inspections, storm damage, residential & commercial roofing in Gibson County.',
};

export default function OaklandCityPage() {
  return (
    <CityPage
      city="Oakland City"
      state="Indiana"
      stateAbbr="IN"
      county="Gibson County"
      slug="oakland-city"
      population="2,400+"
      distance="35 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Oakland City's go-to roofing contractor. Corner Stone serves Gibson County homeowners and university properties with quality roofing, honest pricing, and rapid storm response."
      longDesc="Corner Stone Construction & Roofing proudly serves Oakland City and the surrounding Gibson County communities. As a college town home to Oakland City University, this community has a unique mix of historic faculty homes, student rental properties, family residences, and institutional buildings — each with different roofing needs. Our experienced crews understand the full spectrum, from historic home preservation to modern new construction. We know Gibson County's weather patterns, building codes, and permit processes inside and out. Whether you need emergency storm repairs, a complete roof replacement, routine maintenance, or help navigating an insurance claim, our local team delivers the trusted service that has built our reputation across the Tri-State for over 25 years."
      services={['Residential Roofing', 'Commercial Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Metal Roofing', 'Flat Roofing']}
      neighborhoods={['Oakland City University Area', 'Oakland City Downtown', 'Gibson County West Side', 'State Road 64 Corridor', 'Rural Gibson County South', 'Francisco Area', 'Arthur Area', 'Pike County Border Area']}
      faqs={[
        { q: 'Do you serve Oakland City Indiana for roofing?', a: 'Yes — we serve Oakland City and the entire Gibson County area. Our crews are familiar with the town and respond quickly to all calls.' },
        { q: 'How much does a roof replacement cost in Oakland City IN?', a: 'Most residential roof replacements in Oakland City range from $7,500 to $20,000 depending on home size, roof pitch, and materials. We offer free no-obligation estimates tailored to your specific home.' },
        { q: 'Can you handle insurance claims for storm damage in Oakland City?', a: 'Yes — we are insurance claim specialists. We thoroughly document all damage, meet your adjuster on-site, and manage the entire claim process to maximize your settlement.' },
        { q: 'How quickly can you respond to roofing emergencies in Oakland City?', a: 'Oakland City is approximately 35 miles from our Evansville headquarters. We typically respond within 60 to 90 minutes for emergencies and offer 24/7 tarping and temporary repair services.' },
      ]}
      schema={schema}
    />
  );
}