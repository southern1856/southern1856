import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Fort Branch IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/fort-branch',
  address: { '@type': 'PostalAddress', addressLocality: 'Fort Branch', addressRegion: 'IN', postalCode: '47648' },
  areaServed: { '@type': 'City', name: 'Fort Branch', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Fort Branch Indiana. Free inspections, storm damage, residential roofing in Gibson County.',
};

export default function FortBranchPage() {
  return (
    <CityPage
      city="Fort Branch"
      state="Indiana"
      stateAbbr="IN"
      county="Gibson County"
      slug="fort-branch"
      population="2,700+"
      distance="22 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Fort Branch's reliable roofing contractor. Corner Stone serves Gibson County homeowners with honest pricing, expert workmanship, and fast storm damage response."
      longDesc="Corner Stone Construction & Roofing has been a trusted name for Fort Branch homeowners for over two decades. Located conveniently along US Highway 41, Fort Branch is a growing community with a mix of established homes and new construction — and we serve them all. Our Gibson County crews are local, experienced, and ready to handle everything from routine roof maintenance and minor repairs to complete roof replacements after Indiana's notorious hail storms. We work directly with insurance adjusters to maximize your claim and minimize your stress. From the quiet neighborhoods around Fort Branch Community School to the rural routes extending into the countryside, we deliver the same quality and service that has made us the Tri-State's most recommended roofing contractor."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Roof Maintenance Plans', 'Metal Roofing', 'New Construction Roofing']}
      neighborhoods={['Fort Branch Downtown', 'US Highway 41 Corridor', 'Fort Branch Community School Area', 'East Gibson School District', 'Rural Gibson County North', 'Rural Gibson County South', 'Haubstadt Road Area', 'Princeton Road Corridor', 'Owensville Area']}
      faqs={[
        { q: 'Do you serve Fort Branch Indiana for roofing?', a: 'Yes — Fort Branch is right in our service territory and we serve homeowners throughout Gibson County with fast response times and quality workmanship.' },
        { q: 'How much does a roof replacement cost in Fort Branch IN?', a: 'Most residential roof replacements in Fort Branch range from $7,500 to $19,000 depending on home size, roof pitch, and material selection. We provide free detailed estimates with no obligation.' },
        { q: 'Can you help with hail damage insurance claims in Gibson County?', a: 'Yes — we are insurance claim specialists. We thoroughly document all hail and storm damage, meet your adjuster on-site, and handle the paperwork to maximize your claim payout.' },
        { q: 'How quickly can you respond to roofing emergencies in Fort Branch?', a: 'Fort Branch is approximately 22 miles from our Evansville headquarters. We typically respond within 45 to 60 minutes for emergency calls and provide 24/7 emergency tarping services.' },
      ]}
      schema={schema}
    />
  );
}