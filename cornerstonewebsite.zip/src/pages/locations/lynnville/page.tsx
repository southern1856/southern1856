import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Lynnville IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/lynnville',
  address: { '@type': 'PostalAddress', addressLocality: 'Lynnville', addressRegion: 'IN', postalCode: '47619' },
  areaServed: { '@type': 'City', name: 'Lynnville', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Lynnville Indiana and Warrick County. Free inspections, storm damage repair, residential roofing for Lynnville homeowners.',
};

export default function LynnvillePage() {
  return (
    <CityPage
      city="Lynnville"
      state="Indiana"
      stateAbbr="IN"
      county="Warrick County"
      slug="lynnville"
      population="900+"
      distance="25 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Lynnville's trusted roofing contractor in Warrick County. Corner Stone brings the same quality and fast response that Evansville homeowners have relied on for 25+ years — now serving Lynnville and surrounding Warrick County communities."
      longDesc="Lynnville may be small, but Warrick County homeowners here deserve the same professional roofing that larger cities get. Corner Stone Construction & Roofing brings fully licensed crews, premium materials, and honest pricing to Lynnville and the surrounding rural routes. Whether it is wind damage from a summer storm, hail repair, or a full roof replacement on an older farmhouse, we are the Warrick County roofing team you can count on."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Roof Repair', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims', 'Emergency Repairs']}
      neighborhoods={['Lynnville Town Center', 'SR 68 Corridor', 'Warrick County Rural Routes', 'Yankeetown Area', 'Lynnville School District']}
      faqs={[
        { q: 'Do you serve Lynnville Indiana for roofing?', a: 'Yes — Lynnville and all of Warrick County are part of our core service territory. We provide the exact same fast response and quality workmanship as our Evansville market.' },
        { q: 'How much does a roof replacement cost in Lynnville IN?', a: 'Residential roof replacements in Lynnville typically range from $7,000 to $18,500 depending on home size, roof pitch, and materials. We offer free estimates with no obligation.' },
        { q: 'How quickly can you respond to a roofing emergency in Lynnville?', a: 'Lynnville is about 25 miles from Evansville via SR 68. We typically respond within 45-60 minutes for emergency calls in Warrick County.' },
        { q: 'Do you handle storm damage insurance claims?', a: 'Yes, we are insurance claim specialists. We document every detail of the damage, meet with your adjuster on-site, and handle all the paperwork to make sure you receive the full payout your policy covers.' },
      ]}
      schema={schema}
    />
  );
}