import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Morganfield KY',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/morganfield-ky',
  address: { '@type': 'PostalAddress', addressLocality: 'Morganfield', addressRegion: 'KY', postalCode: '42437' },
  areaServed: { '@type': 'City', name: 'Morganfield', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  description: 'Roofing contractor serving Morganfield Kentucky. Free inspections, storm damage, residential & commercial roofing in Union County. Fully licensed in KY.',
};

export default function MorganfieldKYPage() {
  return (
    <CityPage
      city="Morganfield"
      state="Kentucky"
      stateAbbr="KY"
      county="Union County"
      slug="morganfield-ky"
      population="3,400+"
      distance="25 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Morganfield Kentucky's trusted roofing contractor. Corner Stone is fully licensed in Kentucky and serves Union County with expert roofing, storm damage repair, and 24/7 emergency services."
      longDesc="Corner Stone Construction & Roofing is proud to serve Morganfield and all of Union County. Located just 25 miles from our Evansville headquarters, Morganfield is one of our closest Kentucky communities and we provide the same fast response times Union County homeowners expect. We are fully licensed and insured in Kentucky, so you can trust that every project meets state and local requirements. Union County sees its share of severe weather — from spring thunderstorms with damaging winds to hail events that can destroy a roof in minutes. Our crews know how to spot storm damage that insurance adjusters might miss, and we handle the entire claims process from documentation to final payout. Whether you need emergency tarping after a storm, a complete roof replacement on a historic Morganfield home, or a new metal roof on an agricultural building, Corner Stone delivers quality workmanship backed by over 25 years of Tri-State experience."
      services={['Residential Roofing', 'Commercial Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Agricultural Roofing', 'Roof Maintenance']}
      neighborhoods={['Morganfield Downtown', 'Union County Courthouse Area', 'North Morganfield', 'South Morganfield', 'East Morganfield', 'West Morganfield', 'Sturgis Road Corridor', 'Breckinridge Area', 'Rural Union County Routes', 'Uniontown Area', 'Waverly Area', 'Morganfield Elementary Area']}
      faqs={[
        { q: 'Do you provide roofing services in Morganfield Kentucky?', a: 'Yes — we are fully licensed in Kentucky and proudly serve Morganfield and all of Union County. Morganfield is just 25 miles from our Evansville base, so we offer fast response times.' },
        { q: 'How much does a roof replacement cost in Morganfield KY?', a: 'Most residential roof replacements in Morganfield range from $8,000 to $22,000 depending on home size, roof pitch, and materials selected. We provide free, no-obligation estimates.' },
        { q: 'Can you help with Kentucky insurance claims for storm damage?', a: 'Yes — we are experienced with Kentucky insurance claim procedures. We document all damage thoroughly, meet KY adjusters on-site, and handle paperwork to maximize your coverage.' },
        { q: 'How quickly can you respond to roofing emergencies in Morganfield?', a: 'Morganfield is only 25 miles from our Evansville base. For emergency calls, we typically arrive within 45 to 60 minutes and offer 24/7 emergency tarping and board-up services.' },
        { q: 'Do you work on farm and agricultural buildings in Union County?', a: 'Yes — we specialize in agricultural roofing throughout Union County, including metal barn roofs, pole buildings, equipment sheds, and farmhouse roofing. Our metal roofing crews are experienced with all types of agricultural structures.' },
      ]}
      schema={schema}
    />
  );
}