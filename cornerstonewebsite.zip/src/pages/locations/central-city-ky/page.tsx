import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Central City KY',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/central-city-ky',
  address: { '@type': 'PostalAddress', addressLocality: 'Central City', addressRegion: 'KY', postalCode: '42330' },
  areaServed: { '@type': 'City', name: 'Central City', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  description: 'Roofing contractor serving Central City Kentucky. Free inspections, storm damage, residential & commercial roofing in Muhlenberg County. Fully licensed in KY.',
};

export default function CentralCityKYPage() {
  return (
    <CityPage
      city="Central City"
      state="Kentucky"
      stateAbbr="KY"
      county="Muhlenberg County"
      slug="central-city-ky"
      population="5,800+"
      distance="55 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Central City Kentucky's trusted roofing contractor. Corner Stone is fully licensed in Kentucky and serves Muhlenberg County with expert roofing, storm damage repair, and extended-range services."
      longDesc="Corner Stone Construction & Roofing proudly extends its roofing services to Central City — the largest town in Muhlenberg County and a true hub for the western Kentucky coal region. Central City has deep roots in the coal mining industry, and many of its homes reflect generations of Kentucky families who have lived and worked here. We are fully licensed and insured in Kentucky, bringing the same quality workmanship and honest pricing that Evansville homeowners have trusted for over 25 years. Central City sees the full force of Kentucky weather — tornado watches, spring hailstorms, ice accumulation, and brutal summer heat that can cook a poorly ventilated attic space. These conditions take a real toll on roofing, and our crews are trained to spot both obvious storm damage and the subtle signs of gradual wear that most contractors miss. We work with all major Kentucky insurance carriers and handle the entire claims process from documentation to adjuster meetings. For larger Muhlenberg County projects, we coordinate scheduling to make the trip efficient and seamless — you get the same Corner Stone quality without compromise."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Commercial Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Roof Maintenance', 'Flat Roof Systems']}
      neighborhoods={['Central City Downtown', 'Muhlenberg County High School Area', 'North Central City', 'South Central City', 'East Central City', 'West Central City', 'US 431 Corridor', 'SR 189 Corridor', 'Luzerne Lake Area', 'Rural Muhlenberg County Routes', 'Powderly Road Area', 'Cleaton Area']}
      faqs={[
        { q: 'Do you provide roofing services in Central City Kentucky?', a: 'Yes — we are fully licensed in Kentucky and serve Central City and all of Muhlenberg County with our extended-range crews. You get the same Corner Stone quality and warranty, even at 55 miles from our base.' },
        { q: 'How much does a roof replacement cost in Central City KY?', a: 'Residential roof replacements in Central City typically range from $7,500 to $20,000 depending on home size, roof pitch, and materials. We always provide free, no-obligation estimates with transparent pricing.' },
        { q: 'Can you help with Kentucky insurance claims for storm damage in Muhlenberg County?', a: 'Absolutely — we are experienced with Kentucky insurance procedures. We document all storm damage with photos and measurements, meet KY adjusters on-site, and handle claim paperwork to maximize your coverage.' },
        { q: 'How quickly can you respond to emergencies in Central City?', a: 'Central City is approximately 55 miles from our Evansville base. For emergencies, we typically respond within 60 to 90 minutes, with 24/7 emergency dispatch available year-round.' },
        { q: 'Do you handle commercial roofing in Central City?', a: 'Yes — we serve both residential and commercial properties throughout Muhlenberg County, including businesses along the US 431 corridor and Central City downtown. We handle flat roofs, metal roofs, TPO systems, and architectural shingles.' },
      ]}
      schema={schema}
    />
  );
}