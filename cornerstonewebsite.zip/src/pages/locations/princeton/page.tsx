import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Princeton IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/princeton',
  address: { '@type': 'PostalAddress', addressLocality: 'Princeton', addressRegion: 'IN', postalCode: '47670' },
  areaServed: { '@type': 'City', name: 'Princeton', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Princeton Indiana and Gibson County. Free inspections, storm damage, residential roofing in Gibson County.',
};

export default function PrincetonPage() {
  return (
    <CityPage
      city="Princeton"
      state="Indiana"
      stateAbbr="IN"
      county="Gibson County"
      slug="princeton"
      population="8,600+"
      distance="30 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Princeton and Gibson County's trusted roofing contractor. Corner Stone brings the same quality and fast response that Evansville homeowners have relied on for 25+ years — now fully serving all of Gibson County."
      longDesc="Princeton is one of our fastest-growing service areas, and for good reason — Gibson County homeowners deserve the same quality roofing that the Tri-State area has trusted since 1995. Corner Stone Construction & Roofing brings fully licensed crews, premium materials, and honest pricing to Princeton and surrounding Gibson County communities. Whether you need a routine inspection, storm damage repair, or a full roof replacement, we're just a call away."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims', 'Emergency Repairs']}
      neighborhoods={['Princeton Town Square', 'Gibson County Courthouse Area', 'Princeton Community High School Area', 'Oakland City', 'Fort Branch', 'Haubstadt', 'Owensville', 'Patoka']}
      faqs={[
        { q: 'Do you serve Princeton Indiana for roofing?', a: 'Yes — Princeton and Gibson County are part of our active service territory. We provide the same fast response and quality workmanship as our core Evansville market.' },
        { q: 'How much does a roof replacement cost in Princeton IN?', a: 'Residential roof replacements in Princeton typically range from $7,500 to $20,000 depending on home size, pitch, and materials chosen. We offer free, no-obligation estimates.' },
        { q: 'Do you handle storm damage insurance claims in Gibson County?', a: 'Yes. We are insurance claim specialists. We document damage, meet your adjuster, and handle all paperwork so you get the full payout your policy covers.' },
        { q: 'How quickly can you respond to a roofing emergency in Princeton?', a: 'Princeton is about 30 miles from our Evansville headquarters. We typically respond within 60-90 minutes for emergency calls in Gibson County.' },
      ]}
      schema={schema}
    />
  );
}
