import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Carmi IL',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/carmi-il',
  address: { '@type': 'PostalAddress', addressLocality: 'Carmi', addressRegion: 'IL', postalCode: '62821' },
  areaServed: { '@type': 'City', name: 'Carmi', containedInPlace: { '@type': 'State', name: 'Illinois' } },
  description: 'Roofing contractor serving Carmi Illinois. Free inspections, storm damage repair, residential & commercial roofing in White County. Licensed & insured. Call 812-213-5997.',
};

export default function CarmiILPage() {
  return (
    <CityPage
      city="Carmi"
      state="Illinois"
      stateAbbr="IL"
      county="White County"
      slug="carmi-il"
      population="5,200+"
      distance="50 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Carmi Illinois's trusted roofing contractor serving White County. Corner Stone delivers expert roofing, storm damage repair, and 24/7 emergency services — fully licensed and insured in Illinois, backed by GAF Master Elite certification."
      longDesc="Corner Stone Construction & Roofing is bringing our 25-plus years of roofing expertise to Carmi and White County, Illinois. As the county seat, Carmi is the heart of White County and home to a mix of historic properties, established neighborhoods, and rural agricultural estates — each with unique roofing needs. Located about 50 miles from our Evansville headquarters, Carmi sits right in the path of the same severe weather patterns that roll through the lower Wabash Valley. Spring and summer storms bring damaging winds, heavy rain, and occasional hail that can quietly compromise a roof's integrity long before leaks appear. Our experienced crews know exactly what to look for and provide thorough, honest assessments — never recommending a replacement when a repair will do. We handle everything from complete roof replacements using premium architectural shingles to metal roofing for farm buildings and rural properties. Every Carmi project comes with GAF Master Elite workmanship, full licensing and insurance in Illinois, and a commitment to treating White County homeowners like neighbors — because at 50 miles, you practically are."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Wind Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Agricultural Roofing', 'Roof Maintenance']}
      neighborhoods={['Carmi Downtown', 'White County Courthouse Area', 'North Carmi', 'South Carmi', 'East Carmi', 'West Carmi', 'Carmi Country Club Area', 'Rural White County', 'Crossville Area', 'Norris City Area', 'Enfield Area', 'Carmi High School Area']}
      faqs={[
        { q: 'Do you provide roofing services in Carmi Illinois?', a: 'Yes — we proudly serve Carmi and all of White County, Illinois. At about 50 miles from our Evansville headquarters, Carmi is within our standard service radius and we deliver the same quality workmanship White County homeowners deserve.' },
        { q: 'How much does a roof replacement cost in Carmi IL?', a: 'Most residential roof replacements in Carmi range from $8,500 to $22,000 depending on home size, roof pitch, and chosen materials. We provide free, thorough estimates with no obligation — just honest numbers from a local-focused company.' },
        { q: 'Can you help with Illinois insurance claims for storm damage?', a: 'Yes — we have extensive experience handling Illinois insurance claims. Our team documents all storm-related damage, meets your adjuster on-site, and manages the entire claims process to help maximize your coverage at no additional cost.' },
        { q: 'How quickly can you respond to roofing emergencies in Carmi?', a: 'Carmi is approximately 50 miles from our Evansville base. For emergency calls, we typically arrive within 60 to 75 minutes and provide 24/7 emergency tarping and board-up services for White County homeowners.' },
        { q: 'Do you work on farm and agricultural roofing in White County Illinois?', a: 'Yes — we are experienced with all types of agricultural roofing throughout White County, including metal barn roofs, pole buildings, equipment sheds, grain storage structures, and farmhouse roofing. Our crews understand the specific needs of rural Illinois properties.' },
      ]}
      schema={schema}
    />
  );
}