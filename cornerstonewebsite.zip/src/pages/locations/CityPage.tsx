import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import DealExpiringSoon from '@/pages/promotions/components/DealExpiringSoon';
import { OFFERS } from '@/mocks/promotions';

export interface CityPageProps {
  city: string;
  state: string;
  stateAbbr: string;
  county: string;
  slug: string;
  population: string;
  distance: string;
  heroImage: string;
  teamImage: string;
  description: string;
  longDesc: string;
  services: string[];
  neighborhoods: string[];
  faqs: { q: string; a: string }[];
  schema: object;
}

export default function CityPage({ city, state, stateAbbr, county, slug, heroImage, teamImage, description, longDesc, services, neighborhoods, faqs, schema }: CityPageProps) {
  const navigate = useNavigate();
  const hero = useScrollAnimation();
  const content = useScrollAnimation({ threshold: 0.1 });
  const faqAnim = useScrollAnimation({ threshold: 0.1 });

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title={`${city} ${stateAbbr} Roofing Contractor | Corner Stone Construction & Roofing`}
        description={`Corner Stone Construction & Roofing serves ${city}, ${stateAbbr}. Free roof inspections, storm damage repair, residential & commercial roofing in ${county}. Licensed & insured. Call 812-213-5997.`}
        keywords={`${city} roofing contractor, roof replacement ${city} ${stateAbbr}, roofing company ${county}, storm damage roofing ${city}, free roof inspection ${city} ${stateAbbr}`}
        canonical={`/locations/${slug}`}
        schema={schema}
      />

      {/* Hero */}
      <section className="relative min-h-[70vh] flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <img src={heroImage} alt={`Roofing contractor in ${city} ${stateAbbr}`} className="w-full h-full object-cover object-top opacity-40" />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/50 via-charcoal-deep/40 to-charcoal-deep" />
        </div>
        <div
          ref={hero.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 pb-16 md:pb-20 anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4 pt-32 md:pt-36">{county}, {state}</p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 9vw, 9rem)' }}>
            {city}<br /><span className="text-orange">Roofing</span>
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-xl leading-relaxed mb-6">{description}</p>
          <div className="mb-6">
            <CountdownTimer expiresAt="2026-07-31" variant="banner" />
          </div>
          <div className="mb-6">
            <SocialProofPulse />
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            <a href="tel:8122135997" className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2">
              <i className="ri-phone-line" />Call 812-213-5997
            </a>
            <button onClick={() => navigate('/estimate')} className="border border-white/30 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer">
              Free Estimate
            </button>
          </div>
        </div>
      </section>

      {/* Trust bar */}
      <div className="bg-charcoal border-y border-white/10 px-6 md:px-10 lg:px-16 py-5">
        <div className="flex flex-wrap items-center gap-6 md:gap-10">
          {[
            { icon: 'ri-shield-check-line', text: 'Licensed & Insured' },
            { icon: 'ri-award-line', text: 'GAF Master Elite' },
            { icon: 'ri-star-fill', text: '4.9★ Google Rating' },
            { icon: 'ri-timer-line', text: '24/7 Emergency' },
            { icon: 'ri-map-pin-line', text: `Serving ${city} & Surrounding Areas` },
          ].map((item) => (
            <div key={item.text} className="flex items-center gap-2 text-white/50 text-xs uppercase tracking-wider">
              <i className={`${item.icon} text-orange text-sm`} />
              {item.text}
            </div>
          ))}
        </div>
      </div>

      {/* Main content */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div
          ref={content.ref as React.RefObject<HTMLDivElement>}
          className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-start anim-fade-up ${content.isVisible ? 'is-visible' : ''}`}
        >
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Local Experts</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Your Trusted<br />{city} Roofer
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">{longDesc}</p>

            {/* Services */}
            <h3 className="text-white font-semibold text-sm uppercase tracking-widest mb-4">Services in {city}</h3>
            <div className="grid grid-cols-2 gap-2 mb-8">
              {services.map((s) => (
                <div key={s} className="flex items-center gap-2 text-white/60 text-sm">
                  <i className="ri-check-line text-orange text-xs" />
                  {s}
                </div>
              ))}
            </div>

            {/* Neighborhoods */}
            <h3 className="text-white font-semibold text-sm uppercase tracking-widest mb-4">Areas We Cover in {city}</h3>
            <div className="flex flex-wrap gap-2 mb-8">
              {neighborhoods.map((n) => (
                <span key={n} className="text-white/50 text-xs border border-white/10 bg-white/5 px-3 py-1.5">{n}</span>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <a href="tel:8122135997" className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2">
                <i className="ri-phone-line" />Call Now
              </a>
              <button onClick={() => navigate('/estimate')} className="border border-white/20 hover:border-orange text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer">
                Free Estimate
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <div className="w-full h-[360px] overflow-hidden">
              <img src={teamImage} alt={`Corner Stone roofing crew in ${city} ${stateAbbr}`} className="w-full h-full object-cover object-top" />
            </div>
            {/* Stats */}
            <div className="grid grid-cols-3 border border-white/10">
              {[
                { val: '25+', label: 'Years Serving Area' },
                { val: '4.9★', label: 'Google Rating' },
                { val: '24/7', label: 'Emergency Line' },
              ].map((s, i) => (
                <div key={s.label} className={`px-4 py-5 text-center ${i < 2 ? 'border-r border-white/10' : ''}`}>
                  <p className="font-display text-orange text-2xl tracking-wider">{s.val}</p>
                  <p className="text-white/40 text-xs uppercase tracking-widest mt-1">{s.label}</p>
                </div>
              ))}
            </div>
            {/* Map */}
            <div className="w-full h-[220px] overflow-hidden border border-white/10">
              <iframe
                title={`Map of ${city} ${stateAbbr}`}
                src={`https://www.google.com/maps/embed/v1/place?key=AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY&q=${encodeURIComponent(city + ', ' + stateAbbr)}&zoom=12`}
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div
          ref={faqAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${faqAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="text-center mb-12">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Common Questions</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              {city} Roofing FAQ
            </h2>
          </div>
          <div className="max-w-3xl mx-auto space-y-3">
            {faqs.map((faq, i) => (
              <details
                key={i}
                className="group border border-white/10 bg-charcoal-mid"
              >
                <summary className="flex items-center justify-between px-6 py-5 cursor-pointer list-none">
                  <span className="text-white font-semibold text-sm pr-4">{faq.q}</span>
                  <i className="ri-add-line text-orange text-lg flex-shrink-0 group-open:hidden" />
                  <i className="ri-subtract-line text-orange text-lg flex-shrink-0 hidden group-open:block" />
                </summary>
                <div className="px-6 pb-5">
                  <p className="text-white/50 text-sm leading-relaxed">{faq.a}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="bg-charcoal-mid border border-white/10 p-10 md:p-16 text-center">
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Ready for a<br /><span className="text-orange">Free Inspection?</span>
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-lg mx-auto leading-relaxed mb-8">
            We serve {city} and all of {county}. Call or click — we'll be there fast.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="tel:8122135997" className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2">
              <i className="ri-phone-line" />812-213-5997
            </a>
            <button onClick={() => navigate('/estimate')} className="border border-white/20 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer">
              Get Free Estimate
            </button>
          </div>
        </div>
      </section>

      <DealExpiringSoon offers={OFFERS} linkToPage="/promotions" />
    </div>
  );
}
