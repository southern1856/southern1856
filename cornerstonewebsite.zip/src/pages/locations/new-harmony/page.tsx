import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — New Harmony IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/new-harmony',
  address: { '@type': 'PostalAddress', addressLocality: 'New Harmony', addressRegion: 'IN', postalCode: '47631' },
  areaServed: { '@type': 'City', name: 'New Harmony', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving New Harmony Indiana. Free inspections, storm damage, residential & historical roofing in Posey County.',
};

export default function NewHarmonyPage() {
  return (
    <CityPage
      city="New Harmony"
      state="Indiana"
      stateAbbr="IN"
      county="Posey County"
      slug="new-harmony"
      population="689"
      distance="28 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="New Harmony's trusted roofing contractor. Corner Stone serves this historic Posey County town with expert roofing that respects architectural heritage while providing modern protection."
      longDesc="Corner Stone Construction & Roofing is honored to serve New Harmony, one of Indiana's most treasured historic towns. We understand that roofing in a town with deep architectural heritage requires a special touch — matching materials, colors, and styles to preserve the town's unique character while providing modern durability. Our crews have experience working with historic preservation guidelines and can advise on appropriate roofing solutions for period homes, modern residences, and the town's distinctive buildings. We offer the same fast response times throughout Posey County and provide comprehensive storm damage assessment and insurance claim support for hail and wind events."
      services={['Residential Roofing', 'Historic Home Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Roof Maintenance Plans']}
      neighborhoods={['New Harmony Historic District', 'Wabash Riverfront Area', 'Main Street Corridor', 'Rappite Cemetery Area', 'Church Street Area', 'North Street Historic Homes', 'Rural Posey County East', 'Griffin Area', 'Stewartsville Area']}
      faqs={[
        { q: 'Do you provide roofing services in New Harmony Indiana?', a: 'Yes — we regularly serve New Harmony and all of Posey County. We understand the unique considerations of roofing historic homes and buildings in this treasured town.' },
        { q: 'How much does a roof replacement cost in New Harmony IN?', a: 'Most residential roof replacements in New Harmony range from $8,000 to $20,000 depending on home size, roof complexity, and materials. Historic homes may require specialty materials that affect pricing. We provide free estimates.' },
        { q: 'Can you roof historic homes in New Harmony?', a: 'Absolutely. We have experience working with historic properties and can recommend roofing solutions that respect architectural integrity while meeting modern performance standards. We will work with you to preserve your home\'s character.' },
        { q: 'How fast can you respond to roofing emergencies in New Harmony?', a: 'New Harmony is approximately 28 miles from our Evansville headquarters. We typically respond within 60 minutes for emergency calls and offer 24/7 emergency tarping and temporary repairs.' },
      ]}
      schema={schema}
    />
  );
}