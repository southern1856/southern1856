import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Powderly KY',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/powderly-ky',
  address: { '@type': 'PostalAddress', addressLocality: 'Powderly', addressRegion: 'KY', postalCode: '42367' },
  areaServed: { '@type': 'City', name: 'Powderly', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  description: 'Roofing contractor serving Powderly Kentucky. Free inspections, storm damage, residential roofing in Muhlenberg County. Fully licensed in KY.',
};

export default function PowderlyKYPage() {
  return (
    <CityPage
      city="Powderly"
      state="Kentucky"
      stateAbbr="KY"
      county="Muhlenberg County"
      slug="powderly-ky"
      population="720+"
      distance="50 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Powderly Kentucky's trusted roofing contractor. Corner Stone is fully licensed in Kentucky and serves Muhlenberg County with expert roofing, storm damage repair, and extended-range services."
      longDesc="Corner Stone Construction & Roofing extends its trusted roofing services to Powderly — a small but proud Muhlenberg County community with deep Kentucky roots. Powderly sits just south of Central City along US 431, surrounded by the rolling countryside that defines western Kentucky. While small in population, Powderly homeowners deserve the same quality roofing protection as anyone else, and we deliver exactly that. We are fully licensed and insured in Kentucky, bringing over 25 years of roofing expertise to every Powderly project. The Muhlenberg County climate throws everything at a roof — from spring tornado threats and hail to humid summers that test attic ventilation and ice storms that stress flashing and shingles. Our crews are trained to spot both obvious storm damage and the more subtle signs of gradual deterioration that can lead to costly leaks if ignored. We work with all major Kentucky insurance carriers and handle the claims process from start to finish, including on-site adjuster meetings and comprehensive damage documentation. For Powderly projects, we bundle scheduling to make the drive efficient, so you get premium roofing at fair local pricing."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Roof Maintenance']}
      neighborhoods={['Powderly Town Center', 'US 431 Corridor', 'Powderly Elementary Area', 'North Powderly', 'South Powderly', 'East Powderly Rural Routes', 'West Powderly', 'Rural Muhlenberg County', 'Central City Connector', 'Cleaton Road Area', 'SR 189 Access', 'Greenville Area Routes']}
      faqs={[
        { q: 'Do you provide roofing services in Powderly Kentucky?', a: 'Yes — we are fully licensed in Kentucky and serve Powderly and Muhlenberg County with our extended-range crews. You get the same Corner Stone quality and workmanship warranty.' },
        { q: 'How much does a roof replacement cost in Powderly KY?', a: 'Residential roof replacements in Powderly typically range from $7,500 to $18,000 depending on home size, pitch, and materials. We always provide free, transparent estimates with no hidden fees.' },
        { q: 'Can you help with Kentucky insurance claims in Muhlenberg County?', a: 'Absolutely — we have extensive experience with Kentucky insurance procedures. We document all storm damage thoroughly, meet KY adjusters on-site, and handle claim paperwork to ensure you get maximum coverage.' },
        { q: 'How quickly can you respond to emergencies in Powderly?', a: 'Powderly is approximately 50 miles from our Evansville base. For emergencies, we typically respond within 60 to 75 minutes, with 24/7 emergency dispatch available.' },
        { q: 'Do you offer free inspections in Powderly?', a: 'Yes — we provide completely free roof inspections for Powderly homeowners. We will assess your roof condition, check for storm damage, and give you an honest recommendation with no obligation.' },
      ]}
      schema={schema}
    />
  );
}