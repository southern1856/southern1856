import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Jasper IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/jasper',
  address: { '@type': 'PostalAddress', addressLocality: 'Jasper', addressRegion: 'IN', postalCode: '47546' },
  areaServed: { '@type': 'City', name: 'Jasper', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Jasper Indiana. Free inspections, storm damage, residential & commercial roofing in Dubois County.',
};

export default function JasperPage() {
  return (
    <CityPage
      city="Jasper"
      state="Indiana"
      stateAbbr="IN"
      county="Dubois County"
      slug="jasper"
      population="15,000+"
      distance="45 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Jasper's trusted roofing contractor. Corner Stone serves Dubois County homeowners and businesses with expert residential and commercial roofing, storm damage repair, and insurance claim assistance."
      longDesc="Corner Stone Construction & Roofing proudly serves Jasper and all of Dubois County. We understand the unique roofing challenges of Southern Indiana's climate — from severe thunderstorms and hail to heavy winter snow loads. Whether you own a historic home near the town square, a modern property in a new subdivision, or a commercial building along the highway, our experienced crews deliver the same quality workmanship and attention to detail. We handle everything from emergency repairs after storm damage to complete roof replacements and new construction installations. Our team is familiar with Dubois County building codes and works directly with local inspectors to keep your project moving smoothly."
      services={['Residential Roofing', 'Commercial Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Flat Roofing', 'Roof Maintenance Plans']}
      neighborhoods={['Jasper Downtown', 'Dubois County Courthouse Area', 'Jasper High School Area', 'Riverwalk District', 'Vincennes Street Corridor', 'Ferdinand Road Area', 'North Jasper', 'Southside Jasper', 'Countryside Estates', 'Huntingburg Road Area']}
      faqs={[
        { q: 'Do you provide roofing services in Jasper Indiana?', a: 'Yes — we regularly travel to Jasper and serve all of Dubois County. Our crews are equipped to handle both residential and commercial roofing projects throughout the area.' },
        { q: 'How much does a roof replacement cost in Jasper IN?', a: 'Most residential roof replacements in Jasper range from $8,500 to $24,000 depending on home size, roof pitch, and materials selected. We provide free detailed estimates with no obligation.' },
        { q: 'Can you help with storm damage insurance claims in Dubois County?', a: 'Absolutely. We are insurance claim specialists. We document all storm damage with photos, meet your adjuster on-site, and handle the paperwork to maximize your claim payout.' },
        { q: 'How quickly can you respond to roofing emergencies in Jasper?', a: 'Jasper is approximately 45 miles from our Evansville headquarters. For emergencies, we typically respond within 90 minutes to 2 hours and offer 24/7 emergency tarping and temporary repairs.' },
        { q: 'Do you offer commercial roofing in Jasper Indiana?', a: 'Yes — we provide full commercial roofing services in Jasper including TPO, EPDM, metal standing seam, and modified bitumen systems for offices, warehouses, retail, and industrial buildings.' },
      ]}
      schema={schema}
    />
  );
}