import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Rockport IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/rockport',
  address: { '@type': 'PostalAddress', addressLocality: 'Rockport', addressRegion: 'IN', postalCode: '47635' },
  areaServed: { '@type': 'City', name: 'Rockport', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Rockport Indiana. Free inspections, storm damage, residential roofing in Spencer County.',
};

export default function RockportPage() {
  return (
    <CityPage
      city="Rockport"
      state="Indiana"
      stateAbbr="IN"
      county="Spencer County"
      slug="rockport"
      population="2,000+"
      distance="35 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Rockport's dependable roofing contractor. Corner Stone serves Spencer County homeowners with fast response times, honest pricing, and quality roofing that stands up to Ohio River weather."
      longDesc="Corner Stone Construction & Roofing is proud to serve Rockport and the surrounding Spencer County area. As one of Indiana's oldest towns along the Ohio River, Rockport has a mix of historic homes, rural properties, and modern residences — each with unique roofing needs. Our experienced crews understand the specific challenges of river-town roofing, including moisture management, wind resistance, and the seasonal storms that roll through the Ohio River Valley. Whether you need emergency repairs after severe weather, a full roof replacement on your family home, or routine maintenance to extend your roof's life, we deliver the same trusted service that has made us a household name in the Tri-State area for over 25 years. We also specialize in helping homeowners navigate insurance claims for storm damage, which is particularly common in this region during spring and summer."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Roof Maintenance', 'Metal Roofing']}
      neighborhoods={['Rockport Historic District', 'Lincoln Pioneer Village Area', 'Ohio Riverfront Area', 'South Rockport', 'Rural Spencer County Routes', 'Dale Area', 'Gentryville Area', 'Richland Township', 'Clay Township', 'Ohio Township']}
      faqs={[
        { q: 'Do you serve Rockport Indiana for roofing?', a: 'Yes — we proudly serve Rockport and all of Spencer County. Our crews are experienced with the unique roofing challenges of Ohio River communities.' },
        { q: 'How much does a roof replacement cost in Rockport IN?', a: 'Most residential roof replacements in Rockport range from $7,500 to $19,000 depending on home size, roof complexity, and materials. We provide free estimates with no obligation.' },
        { q: 'Can you help with insurance claims for storm damage in Rockport?', a: 'Yes — we are insurance claim specialists. We document all damage with detailed photos, meet your adjuster on-site, and handle the claim paperwork to maximize your payout.' },
        { q: 'How fast can you respond to roofing emergencies in Rockport?', a: 'Rockport is approximately 35 miles from our Evansville headquarters. We typically respond within 60 to 90 minutes for emergency calls and offer 24/7 emergency tarping.' },
      ]}
      schema={schema}
    />
  );
}