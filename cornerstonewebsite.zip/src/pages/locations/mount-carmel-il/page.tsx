import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Mount Carmel IL',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/mount-carmel-il',
  address: { '@type': 'PostalAddress', addressLocality: 'Mount Carmel', addressRegion: 'IL', postalCode: '62863' },
  areaServed: { '@type': 'City', name: 'Mount Carmel', containedInPlace: { '@type': 'State', name: 'Illinois' } },
  description: 'Roofing contractor serving Mount Carmel Illinois. Free inspections, storm damage repair, residential & commercial roofing in Wabash County. Licensed & insured. Call 812-213-5997.',
};

export default function MountCarmelILPage() {
  return (
    <CityPage
      city="Mount Carmel"
      state="Illinois"
      stateAbbr="IL"
      county="Wabash County"
      slug="mount-carmel-il"
      population="7,200+"
      distance="38 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Mount Carmel Illinois's trusted roofing contractor serving Wabash County. Corner Stone delivers expert roofing, storm damage repair, and 24/7 emergency services to homes and businesses across the Wabash Valley."
      longDesc="Corner Stone Construction &amp; Roofing is proud to extend our service area into Illinois, and Mount Carmel — just 38 miles from our Evansville headquarters — is one of our closest Illinois communities. We serve all of Wabash County with the same fast response times and quality workmanship that Indiana and Kentucky homeowners have trusted for over 25 years. Mount Carmel sits right on the Wabash River, and like the rest of the Tri-State area, it gets hit hard by spring thunderstorms, severe wind events, and occasional hailstorms that can compromise roofing integrity. The river valley humidity is a factor too — north-facing roofs here are especially prone to moss and algae buildup, which eats away at shingle life over time if left unchecked. Our crews know exactly what to look for on Illinois homes: from wind-lifted shingles on the rural routes outside town and moss-damaged roofs along the river bottoms, to hail damage on the historic homes near the courthouse square. With Wabash Valley College bringing a steady stream of new homeowners to the area, there's always demand for pre-purchase roof inspections and move-in ready replacements. We handle the full scope of roofing and exterior needs in Mount Carmel: complete tear-offs and replacements, storm damage insurance claims, emergency tarping after a storm rolls through, metal roofing for agricultural buildings, and siding and fascia repair for homes where wind has done double damage. Fully licensed and insured, and backed by a GAF Master Elite certification, Corner Stone brings the same honesty and craftsmanship to every Wabash County roof we touch."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Wind Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Commercial Roofing', 'Siding & Fascia Repair']}
      neighborhoods={['Mount Carmel Downtown', 'Wabash County Courthouse Area', 'Wabash Valley College Area', 'City Park &amp; Pool District', 'Wabash Riverfront Area', 'Busseron Creek Corridor', 'Golden Aces Territory', 'Rural Wabash County', 'Friendsville Area', 'Patton Area', 'Bellmont Area', 'Oak Grove Rural Routes']}
      faqs={[
        { q: 'Do you provide roofing services in Mount Carmel Illinois?', a: 'Yes — we proudly serve Mount Carmel and all of Wabash County. Located just 38 miles from our Evansville base, we offer fast response times and are fully licensed and insured in Illinois.' },
        { q: 'How much does a roof replacement cost in Mount Carmel IL?', a: 'Most residential roof replacements in Mount Carmel range from $8,500 to $23,000 depending on home size, roof pitch, and material selection. We provide free, no-obligation estimates with no pressure.' },
        { q: 'Can you help with Illinois insurance claims for storm damage?', a: 'Absolutely. We are experienced with Illinois insurance claim procedures and document all damage thoroughly. We will meet your adjuster on-site and handle paperwork to maximize your coverage at no extra cost.' },
        { q: 'How quickly can you respond to roofing emergencies in Mount Carmel?', a: 'Mount Carmel is only about 38 miles from our Evansville base. If you are near downtown on Cherry Street or Market Street, we typically arrive within 50 minutes. For homes out on the rural routes toward Friendsville or Bellmont, figure closer to 60 to 65 minutes. We offer 24/7 emergency tarping and board-up throughout Wabash County.' },
        { q: 'Does river humidity cause roof problems in Mount Carmel?', a: 'Yes — the Wabash River valley creates persistent humidity that fuels moss and algae growth, especially on north-facing roof slopes and shaded lots near the riverfront. Over time, moss traps moisture against shingles and degrades the asphalt, shortening roof life by years. We offer moss treatment, preventative zinc strip installation, and full replacements when the damage is too far gone.' },
      ]}
      schema={schema}
    />
  );
}