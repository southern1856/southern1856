import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Boonville IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/boonville',
  address: { '@type': 'PostalAddress', addressLocality: 'Boonville', addressRegion: 'IN', postalCode: '47601' },
  areaServed: { '@type': 'City', name: 'Boonville', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Boonville Indiana. Free inspections, storm damage, residential roofing in Warrick County.',
};

export default function BoonvillePage() {
  return (
    <CityPage
      city="Boonville"
      state="Indiana"
      stateAbbr="IN"
      county="Warrick County"
      slug="boonville"
      population="6,200+"
      distance="22 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Boonville's trusted roofing contractor since 1995. Corner Stone serves all of Warrick County with expert residential roofing, storm damage repair, and insurance claim assistance."
      longDesc="Boonville homeowners have trusted Corner Stone Construction & Roofing for over 25 years. We know Warrick County's building codes and work closely with local permit offices to keep your project on schedule. Whether it's a storm-damaged roof after a severe Indiana thunderstorm or a planned full replacement, our experienced crews deliver quality work at fair prices — every time."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims', 'Emergency Repairs', 'Roof Maintenance']}
      neighborhoods={['Boonville Historic Square', 'Warrick County Courthouse Area', 'Boonville High School Area', 'Lynnville', 'Tennyson', 'Hatfield', 'Chandler', 'Elberfeld']}
      faqs={[
        { q: 'Do you serve Boonville Indiana for roofing?', a: 'Yes — we regularly serve Boonville and all of Warrick County. Our crews are familiar with local building codes and permit requirements.' },
        { q: 'How much does a new roof cost in Boonville IN?', a: 'Most residential roofs in Boonville range from $7,500 to $20,000 depending on size and materials. We provide free, no-obligation estimates.' },
        { q: 'Can you help with storm damage insurance claims in Boonville?', a: 'Yes. We document all damage, meet your insurance adjuster on-site, and handle the paperwork to ensure you get the full payout you deserve.' },
        { q: 'How fast do you respond to roofing emergencies in Boonville?', a: 'Boonville is about 22 miles from our Evansville base. We typically respond within 60-90 minutes for emergency calls.' },
      ]}
      schema={schema}
    />
  );
}
