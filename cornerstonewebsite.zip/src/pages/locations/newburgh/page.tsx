import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Newburgh IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/newburgh',
  address: { '@type': 'PostalAddress', addressLocality: 'Newburgh', addressRegion: 'IN', postalCode: '47630' },
  areaServed: { '@type': 'City', name: 'Newburgh', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Newburgh Indiana. Free inspections, storm damage, residential & commercial roofing in Warrick County.',
};

export default function NewburghPage() {
  return (
    <CityPage
      city="Newburgh"
      state="Indiana"
      stateAbbr="IN"
      county="Warrick County"
      slug="newburgh"
      population="3,400+"
      distance="12 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Newburgh's most trusted roofing contractor. Corner Stone has completed hundreds of roofing projects in Warrick County — from historic homes near the Ohio River to new construction subdivisions."
      longDesc="Corner Stone Construction & Roofing has been serving Newburgh homeowners since 1995. We know Warrick County's building codes, permit offices, and weather patterns inside and out. Whether you need a full roof replacement after a hail storm or a quick repair before the next rain, our local crew is ready to respond fast. We're not a national chain — we're your neighbors."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims', 'Emergency Repairs', 'Roof Maintenance']}
      neighborhoods={['Newburgh Historic District', 'Ohio River Greenway Area', 'Castle High School Area', 'Newburgh Elementary Area', 'Chandler', 'Boonville Road Corridor', 'Yankeetown', 'Elberfeld']}
      faqs={[
        { q: 'Do you serve Newburgh Indiana for roofing?', a: 'Yes — Newburgh is one of our most active service areas. We have completed hundreds of roofing projects in Warrick County and respond quickly to all Newburgh calls.' },
        { q: 'How much does a roof replacement cost in Newburgh IN?', a: 'Most residential roof replacements in Newburgh range from $8,000 to $22,000 depending on home size, pitch, and materials. We offer free estimates with no obligation.' },
        { q: 'Do you handle insurance claims for storm damage in Newburgh?', a: 'Absolutely. We are insurance claim specialists. We document damage, meet your adjuster, and handle all paperwork to maximize your payout.' },
        { q: 'How fast can you respond to an emergency in Newburgh?', a: 'We typically respond within 60 minutes for emergencies in Newburgh. We offer 24/7 emergency tarping and repair services.' },
      ]}
      schema={schema}
    />
  );
}
