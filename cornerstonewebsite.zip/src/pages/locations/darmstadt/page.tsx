import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Darmstadt IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/darmstadt',
  address: { '@type': 'PostalAddress', addressLocality: 'Darmstadt', addressRegion: 'IN', postalCode: '47725' },
  areaServed: { '@type': 'City', name: 'Darmstadt', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Darmstadt Indiana. Free inspections, storm damage, residential roofing in Vanderburgh County.',
};

export default function DarmstadtPage() {
  return (
    <CityPage
      city="Darmstadt"
      state="Indiana"
      stateAbbr="IN"
      county="Vanderburgh County"
      slug="darmstadt"
      population="1,400+"
      distance="10 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Darmstadt's premier roofing contractor. Corner Stone serves this growing Vanderburgh County community just north of Evansville with expert roofing and lightning-fast response times."
      longDesc="Corner Stone Construction & Roofing considers Darmstadt practically our backyard. Located just 10 minutes north of our Evansville headquarters, this growing Vanderburgh County community gets our fastest response times and most frequent service. Darmstadt has expanded significantly in recent years with beautiful new subdivisions and custom homes — and we have been there for every phase of that growth, roofing new construction and maintaining existing homes alike. Our proximity means we can offer same-day inspections, emergency response within 20 minutes, and the kind of personal service that only a truly local contractor can provide. From routine maintenance and minor repairs to complete roof replacements and storm damage restoration, Darmstadt homeowners get our absolute best every single time."
      services={['Residential Roofing', 'Roof Replacement', 'New Construction Roofing', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Roof Maintenance Plans', 'Metal Roofing']}
      neighborhoods={['Darmstadt Town Center', 'Vanderburgh County North', 'North Green River Road Corridor', 'Kansas Road Area', 'Darmstadt Elementary School Area', 'New Subdivisions North', 'Melrose Area', 'McCullough Park Area']}
      faqs={[
        { q: 'Do you serve Darmstadt Indiana for roofing?', a: 'Yes — Darmstadt is literally in our backyard. We are based just minutes away on Kansas Road and serve this community with the fastest response times in our entire service area.' },
        { q: 'How much does a roof replacement cost in Darmstadt IN?', a: 'Most residential roof replacements in Darmstadt range from $8,000 to $22,000 depending on home size, roof complexity, and material choices. We provide free comprehensive estimates with same-day scheduling available.' },
        { q: 'How fast is emergency response in Darmstadt?', a: 'Darmstadt is only about 10 miles from our headquarters. We can typically have a crew on-site within 20 to 30 minutes for emergency calls. 24/7 emergency service is always available.' },
        { q: 'Do you roof new construction homes in Darmstadt?', a: 'Yes — we partner with several Darmstadt-area builders and can provide full roofing for new construction homes. We also work directly with homeowners building custom homes.' },
      ]}
      schema={schema}
    />
  );
}