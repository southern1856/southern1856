import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Petersburg IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/petersburg',
  address: { '@type': 'PostalAddress', addressLocality: 'Petersburg', addressRegion: 'IN', postalCode: '47567' },
  areaServed: { '@type': 'City', name: 'Petersburg', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Petersburg Indiana. Free inspections, storm damage, residential & commercial roofing in Pike County.',
};

export default function PetersburgPage() {
  return (
    <CityPage
      city="Petersburg"
      state="Indiana"
      stateAbbr="IN"
      county="Pike County"
      slug="petersburg"
      population="2,300+"
      distance="45 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Petersburg's trusted roofing contractor. Corner Stone serves Pike County homeowners with expert roofing, storm damage restoration, and insurance claim support."
      longDesc="Corner Stone Construction & Roofing is expanding service to Petersburg and Pike County, bringing over 25 years of Tri-State roofing expertise to this community. As the Pike County seat, Petersburg is home to a mix of historic properties near the courthouse square and newer developments spreading outward — and we are equipped to handle them all. Our crew brings experience with the full range of Indiana roofing challenges: hail damage, wind uplift, ice damming in winter, and the powerful thunderstorms that sweep through southwestern Indiana each spring and summer. We provide comprehensive storm damage assessments, work directly with insurance adjusters to maximize claim payouts, and deliver quality installations backed by manufacturer warranties. Whether you need a roof inspection on an older home or a complete replacement with modern architectural shingles, our team treats every Petersburg project with the same quality standards that built our reputation across the Tri-State."
      services={['Residential Roofing', 'Commercial Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Wind Damage Repair', 'Roof Repair', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Metal Roofing']}
      neighborhoods={['Petersburg Downtown', 'Pike County Courthouse Area', 'Petersburg Schools Area', 'State Road 57 Corridor', 'State Road 61 Corridor', 'Rural Pike County North', 'Rural Pike County South', 'Winslow Area', 'Spurgeon Area']}
      faqs={[
        { q: 'Do you serve Petersburg Indiana for roofing?', a: 'Yes — we serve Petersburg and all of Pike County. While we are expanding in this area, our commitment to quality and service is the same as in our core markets.' },
        { q: 'How much does a roof replacement cost in Petersburg IN?', a: 'Most residential roof replacements in Petersburg range from $7,500 to $19,000 depending on home size, roof pitch, and materials selected. We provide free estimates with transparent pricing and no hidden fees.' },
        { q: 'Can you help with storm damage insurance claims in Pike County?', a: 'Absolutely. We are insurance claim specialists. We document all storm and hail damage thoroughly, meet your adjuster at the property, and handle the complete claims process to maximize your settlement.' },
        { q: 'How quickly can you respond to roofing emergencies in Petersburg?', a: 'Petersburg is approximately 45 miles from our Evansville headquarters. We typically respond within 90 minutes to 2 hours for emergencies and offer 24/7 emergency tarping and temporary repair services.' },
        { q: 'What types of roofing do you install in Petersburg?', a: 'We install architectural asphalt shingles, designer luxury shingles, standing seam metal roofing, flat roofing systems (TPO and EPDM for commercial), and can match existing materials on repairs. Free consultations help you choose the best option.' },
      ]}
      schema={schema}
    />
  );
}