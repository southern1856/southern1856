import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Washington IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/washington',
  address: { '@type': 'PostalAddress', addressLocality: 'Washington', addressRegion: 'IN', postalCode: '47501' },
  areaServed: { '@type': 'City', name: 'Washington', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Washington Indiana. Free inspections, storm damage, residential & commercial roofing in Daviess County.',
};

export default function WashingtonPage() {
  return (
    <CityPage
      city="Washington"
      state="Indiana"
      stateAbbr="IN"
      county="Daviess County"
      slug="washington"
      population="12,000+"
      distance="65 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Washington Indiana's trusted roofing contractor. Corner Stone serves Daviess County with expert residential and commercial roofing, fast emergency response, and insurance claim assistance."
      longDesc="Corner Stone Construction & Roofing proudly serves Washington and all of Daviess County in Northwest Indiana. Washington is a thriving community with a diverse mix of housing — from historic homes near the downtown square to newer subdivisions and rural properties throughout the county. Our experienced crews are equipped to handle every type of roofing project, whether it's a small repair on a residential home, a full replacement after storm damage, or a large commercial installation. We understand the unique weather challenges of this region, including the severe thunderstorms and occasional tornadoes that can cause significant roof damage. Our team is fully licensed and insured, and we maintain strong relationships with Daviess County building officials to ensure smooth permitting and inspections. When you choose Corner Stone, you are choosing a company that treats Washington homeowners with the same care and respect as our neighbors back in Evansville."
      services={['Residential Roofing', 'Commercial Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Flat Roofing', 'Roof Maintenance']}
      neighborhoods={['Washington Downtown Square', 'Daviess County Courthouse Area', 'Washington High School Area', 'North Washington', 'South Washington', 'East Side Washington', 'West Side Washington', 'Montgomery Area', 'Elnora Area', 'Odon Area', 'Rural Daviess County Routes']}
      faqs={[
        { q: 'Do you provide roofing services in Washington Indiana?', a: 'Yes — we serve Washington and all of Daviess County. Our crews travel throughout Northwest Indiana to deliver the same quality roofing services our Evansville customers trust.' },
        { q: 'How much does a roof replacement cost in Washington IN?', a: 'Most residential roof replacements in Washington range from $8,000 to $21,000 depending on home size, roof pitch, and material selection. We always provide free, no-obligation estimates.' },
        { q: 'Can you help with storm damage insurance claims in Daviess County?', a: 'Yes — we are experienced insurance claim specialists. We document all damage with photos and reports, meet with adjusters, and handle the paperwork to maximize your claim.' },
        { q: 'How quickly can you respond to roofing emergencies in Washington?', a: 'Washington is approximately 65 miles from our Evansville headquarters. For emergencies, we typically respond within 90 minutes to 2 hours and offer 24/7 emergency tarping services.' },
        { q: 'Do you offer commercial roofing in Washington Indiana?', a: 'Yes — we provide full commercial roofing services in Washington including TPO, EPDM, metal, and modified bitumen systems for offices, retail, warehouses, and agricultural buildings.' },
      ]}
      schema={schema}
    />
  );
}