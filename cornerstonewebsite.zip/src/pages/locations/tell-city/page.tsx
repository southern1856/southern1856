import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Tell City IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/tell-city',
  address: { '@type': 'PostalAddress', addressLocality: 'Tell City', addressRegion: 'IN', postalCode: '47586' },
  areaServed: { '@type': 'City', name: 'Tell City', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Tell City Indiana. Free inspections, storm damage, residential & commercial roofing in Perry County.',
};

export default function TellCityPage() {
  return (
    <CityPage
      city="Tell City"
      state="Indiana"
      stateAbbr="IN"
      county="Perry County"
      slug="tell-city"
      population="7,300+"
      distance="55 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Tell City's trusted roofing contractor. Corner Stone serves Perry County with expert residential and commercial roofing, storm damage repair, and emergency services along the Ohio River corridor."
      longDesc="Corner Stone Construction & Roofing proudly extends our services to Tell City and all of Perry County. Located along the beautiful Ohio River, Tell City presents unique roofing challenges including moisture exposure from river humidity, strong winds off the water, and seasonal storm patterns that can cause significant damage. Our experienced crews are equipped to handle everything from historic home restorations in the downtown district to modern residential and commercial roofing throughout the county. We understand Perry County building requirements and maintain strong working relationships with local officials. Whether you need a routine inspection, emergency repair after severe weather, or a complete roof replacement, we bring the same quality and professionalism that Evansville homeowners have trusted for over 25 years."
      services={['Residential Roofing', 'Commercial Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Historic Roof Restoration', 'Roof Maintenance']}
      neighborhoods={['Tell City Downtown Historic District', 'Ohio River Greenway Area', 'Tell City High School Area', 'Perry County Courthouse Area', 'William Tell Elementary Area', 'Troy Road Corridor', 'Cannelton Road Area', 'Rural Perry County Routes', 'Derby Area', 'Leopold Area']}
      faqs={[
        { q: 'Do you provide roofing services in Tell City Indiana?', a: 'Yes — we serve Tell City and all of Perry County. Our crews travel throughout Southern Indiana to deliver quality roofing services to river communities like Tell City.' },
        { q: 'How much does a roof replacement cost in Tell City IN?', a: 'Most residential roof replacements in Tell City range from $8,000 to $21,000 depending on home size, roof pitch, and material selection. We provide free detailed estimates.' },
        { q: 'Can you help with storm damage claims in Perry County?', a: 'Yes — we are experienced insurance claim specialists. We document storm damage, meet with adjusters, and handle all paperwork to help you get maximum coverage for repairs or replacement.' },
        { q: 'How quickly can you respond to emergencies in Tell City?', a: 'Tell City is approximately 55 miles from our Evansville base. For emergencies, we typically respond within 90 minutes to 2 hours and offer 24/7 emergency services.' },
        { q: 'Do you work on historic homes in Tell City?', a: 'Absolutely. We have experience restoring and re-roofing historic properties in Tell City downtown district, carefully matching materials and preserving architectural character.' },
      ]}
      schema={schema}
    />
  );
}
