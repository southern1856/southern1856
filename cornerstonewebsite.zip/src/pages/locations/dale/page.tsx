import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Dale IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/dale',
  address: { '@type': 'PostalAddress', addressLocality: 'Dale', addressRegion: 'IN', postalCode: '47523' },
  areaServed: { '@type': 'City', name: 'Dale', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Dale Indiana and Spencer County. Free inspections, storm damage repair, residential roofing for Dale homeowners.',
};

export default function DalePage() {
  return (
    <CityPage
      city="Dale"
      state="Indiana"
      stateAbbr="IN"
      county="Spencer County"
      slug="dale"
      population="1,500+"
      distance="40 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Dale and Spencer County's trusted roofing contractor. Corner Stone brings 25+ years of Tri-State roofing expertise to the I-64 corridor — same quality, same honest pricing, now serving all of Spencer County."
      longDesc="Dale sits at the crossroads of I-64 and US 231, making it a natural gateway community in Spencer County. Corner Stone Construction & Roofing provides Dale homeowners with the full range of residential roofing services — from routine maintenance and storm damage assessments to complete tear-offs and replacements. We are fully licensed and insured in Indiana, and our crews know Spencer County's building requirements and weather patterns firsthand."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims', 'Emergency Repairs']}
      neighborhoods={['Dale Town Center', 'I-64 Corridor', 'US 231 Corridor', 'Spencer County Rural Routes', 'Dale Community Park Area']}
      faqs={[
        { q: 'Do you serve Dale Indiana for roofing?', a: 'Yes — Dale and all of Spencer County are within our extended service territory. We provide the same quality workmanship and honest pricing as our core Evansville market.' },
        { q: 'How much does a roof replacement cost in Dale IN?', a: 'Residential roof replacements in Dale typically range from $7,500 to $21,000 depending on home size, pitch, and material choice. We offer free, no-obligation estimates for Spencer County homeowners.' },
        { q: 'How quickly can you respond to a roofing emergency in Dale?', a: 'Dale is about 40 miles from Evansville via I-64. We typically respond within 60-90 minutes for emergency calls in Spencer County, often faster depending on crew availability.' },
        { q: 'Do you handle storm damage insurance claims in Spencer County?', a: 'Absolutely — we are insurance claim specialists. Our team documents every detail of the storm damage, meets with your adjuster, and handles the full claims process so you get the maximum payout.' },
      ]}
      schema={schema}
    />
  );
}