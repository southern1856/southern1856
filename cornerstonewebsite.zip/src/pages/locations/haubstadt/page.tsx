import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Haubstadt IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/haubstadt',
  address: { '@type': 'PostalAddress', addressLocality: 'Haubstadt', addressRegion: 'IN', postalCode: '47660' },
  areaServed: { '@type': 'City', name: 'Haubstadt', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Haubstadt Indiana. Free inspections, storm damage, residential roofing in Gibson County.',
};

export default function HaubstadtPage() {
  return (
    <CityPage
      city="Haubstadt"
      state="Indiana"
      stateAbbr="IN"
      county="Gibson County"
      slug="haubstadt"
      population="1,500+"
      distance="15 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Haubstadt's trusted roofing contractor. Corner Stone serves this Gibson County community with fast response times, honest pricing, and durable roofing built for Indiana weather."
      longDesc="Corner Stone Construction & Roofing has been serving Haubstadt homeowners since we first expanded into Gibson County. This tight-knit German heritage community just minutes from Interstate 64 deserves roofing contractors who treat every home like their own — and that is exactly what we deliver. Our Haubstadt-area crews are local, experienced, and committed to quality. We handle everything from routine inspections and preventive maintenance to emergency storm repairs and full roof replacements. Haubstadt's location makes it susceptible to the same severe weather patterns that roll through the Ohio River Valley, and our team is always on standby for the next storm. We also specialize in insurance claim navigation, helping Haubstadt homeowners get every dollar they deserve from their policies after hail, wind, or storm damage."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Roof Maintenance Plans', 'New Construction Roofing']}
      neighborhoods={['Haubstadt Downtown', 'Gibson Southern High School Area', 'Interstate 64 Corridor', 'Fort Branch Road Area', 'Rural Gibson County Northeast', 'St. James Church Area', 'Elberfeld Road Area']}
      faqs={[
        { q: 'Do you serve Haubstadt Indiana for roofing?', a: 'Yes — Haubstadt is a core part of our Gibson County service area. We respond quickly and have completed numerous roofing projects throughout the community.' },
        { q: 'How much does a roof replacement cost in Haubstadt IN?', a: 'Most residential roof replacements in Haubstadt range from $8,000 to $21,000 depending on home size, roof complexity, and materials chosen. We provide free, detailed estimates with zero obligation.' },
        { q: 'Can you help with storm damage insurance claims in Haubstadt?', a: 'Absolutely. We are insurance claim specialists. We document all storm damage with photos, meet your adjuster at your home, and handle all paperwork to maximize your claim settlement.' },
        { q: 'How fast can you respond to roofing emergencies in Haubstadt?', a: 'Haubstadt is only about 15 miles from our Evansville headquarters. We typically respond within 30 to 45 minutes for emergencies and offer 24/7 emergency tarping and repair services.' },
      ]}
      schema={schema}
    />
  );
}