import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Sturgis KY',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/sturgis-ky',
  address: { '@type': 'PostalAddress', addressLocality: 'Sturgis', addressRegion: 'KY', postalCode: '42459' },
  areaServed: { '@type': 'City', name: 'Sturgis', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  description: 'Roofing contractor serving Sturgis Kentucky. Free inspections, storm damage, residential & commercial roofing in Union County. Fully licensed in KY.',
};

export default function SturgisKYPage() {
  return (
    <CityPage
      city="Sturgis"
      state="Kentucky"
      stateAbbr="KY"
      county="Union County"
      slug="sturgis-ky"
      population="1,900+"
      distance="35 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Sturgis Kentucky's trusted roofing contractor. Corner Stone is fully licensed in Kentucky and serves Union County with expert roofing, storm damage repair, and emergency services."
      longDesc="Corner Stone Construction & Roofing serves Sturgis and the southern portion of Union County with the same commitment to quality that has made us the Tri-State's most trusted roofer for over 25 years. Sturgis is a tight-knit community where word travels fast — that's why we make sure every job is done right the first time. We are fully licensed and insured in Kentucky, and our crews understand the specific challenges of roofing in a rural setting: agricultural buildings that need durable metal roofing, older homes that require careful matching, and properties that face full exposure to the elements. Union County's weather can be unforgiving — severe thunderstorms, straight-line winds, and hail are all common threats to your roof. We offer free inspections to catch damage early and work directly with Kentucky insurance adjusters when storms hit. From emergency tarping to full roof replacements, Sturgis homeowners get the Corner Stone standard every time."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Agricultural Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Roof Maintenance']}
      neighborhoods={['Sturgis Downtown', 'Sturgis Elementary Area', 'North Sturgis', 'South Sturgis', 'East Sturgis', 'West Sturgis', 'Rural Union County South', 'Sullivan KY Area', 'Blackford Area', 'Henshaw Area', 'SR 109 Corridor', 'Ohio River Bottom Area']}
      faqs={[
        { q: 'Do you provide roofing services in Sturgis Kentucky?', a: 'Yes — we are fully licensed in Kentucky and serve Sturgis and all of southern Union County. Our KY-licensed crews deliver the same trusted quality you expect from Corner Stone.' },
        { q: 'How much does a roof replacement cost in Sturgis KY?', a: 'Roof replacements in Sturgis typically range from $7,500 to $20,000 depending on home size, roof complexity, and materials. We offer free estimates with absolutely no obligation.' },
        { q: 'Do you handle agricultural roofing in Union County?', a: 'Yes — we have extensive experience with metal barn roofs, pole buildings, equipment sheds, and agricultural structures throughout Union County. Our metal roofing crews are some of the best in the region.' },
        { q: 'How quickly can you respond to emergencies in Sturgis?', a: 'Sturgis is approximately 35 miles from our Evansville base. We typically arrive within 60 to 75 minutes for emergency calls and offer 24/7 emergency service with tarping available.' },
        { q: 'Can you help with Kentucky insurance claims for storm damage?', a: 'Absolutely. We handle the full insurance claims process — thorough damage documentation, on-site meetings with KY adjusters, and all claim paperwork — to ensure you get the coverage you are entitled to.' },
      ]}
      schema={schema}
    />
  );
}