import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Chandler IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/chandler',
  address: { '@type': 'PostalAddress', addressLocality: 'Chandler', addressRegion: 'IN', postalCode: '47610' },
  areaServed: { '@type': 'City', name: 'Chandler', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Chandler Indiana. Free inspections, storm damage, residential roofing in Warrick County.',
};

export default function ChandlerPage() {
  return (
    <CityPage
      city="Chandler"
      state="Indiana"
      stateAbbr="IN"
      county="Warrick County"
      slug="chandler"
      population="3,000+"
      distance="15 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Chandler's reliable roofing contractor. Corner Stone serves this tight-knit Warrick County community with fast emergency response, quality repairs, and full roof replacements backed by decades of local experience."
      longDesc="Chandler homeowners have trusted Corner Stone Construction & Roofing for over 25 years. Just 15 miles from our Evansville headquarters, we can respond quickly to any roofing need in Chandler — from emergency leak repairs after a sudden storm to planned full roof replacements. We know Warrick County's building codes inside and out, and we maintain excellent relationships with local permit offices and inspectors. Whether you live in one of Chandler's established neighborhoods or on a rural route outside town, you get the same dedicated service, transparent pricing, and quality guarantee. We also specialize in helping homeowners navigate insurance claims after hail and wind damage, which is common in this part of Indiana during spring and summer storm season."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Roof Maintenance']}
      neighborhoods={['Chandler Main Street Area', 'Chandler Elementary School Area', 'Boonville Road Corridor', 'Yankeetown Road Area', 'Elberfeld Area', 'Rural Warrick County Routes', 'Lynnville Road Area', 'Tennyson Road Area']}
      faqs={[
        { q: 'Do you serve Chandler Indiana for roofing services?', a: 'Yes — Chandler is one of our core service areas in Warrick County. Our crews respond quickly and are very familiar with local building codes and requirements.' },
        { q: 'How much does a new roof cost in Chandler IN?', a: 'Most residential roof replacements in Chandler range from $7,000 to $18,000 depending on square footage, roof complexity, and material choice. We always provide free estimates.' },
        { q: 'Can you help with insurance claims for storm damage in Chandler?', a: 'Definitely. We are insurance claim specialists. We document damage thoroughly, meet adjusters on-site, and handle all paperwork to ensure you receive a fair payout.' },
        { q: 'How fast do you respond to roofing emergencies in Chandler?', a: 'Chandler is just 15 miles from our base. We typically respond within 30 to 60 minutes for emergency calls and offer 24/7 emergency tarping services.' },
      ]}
      schema={schema}
    />
  );
}