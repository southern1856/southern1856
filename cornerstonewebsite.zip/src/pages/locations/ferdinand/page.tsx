import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Ferdinand IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/ferdinand',
  address: { '@type': 'PostalAddress', addressLocality: 'Ferdinand', addressRegion: 'IN', postalCode: '47532' },
  areaServed: { '@type': 'City', name: 'Ferdinand', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Ferdinand Indiana and Dubois County. Free inspections, storm damage repair, residential roofing for Ferdinand homeowners.',
};

export default function FerdinandPage() {
  return (
    <CityPage
      city="Ferdinand"
      state="Indiana"
      stateAbbr="IN"
      county="Dubois County"
      slug="ferdinand"
      population="2,200+"
      distance="50 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Ferdinand and Dubois County's trusted roofing contractor. Corner Stone brings 25+ years of Tri-State roofing expertise to this historic German-heritage community — same quality, same honest pricing."
      longDesc="Ferdinand is one of Dubois County's most distinctive communities, known for its German Catholic heritage and the stunning Monastery Immaculate Conception. Ferdinand homeowners take pride in their properties — and they deserve a roofing contractor who treats every job with the same care and attention. Corner Stone Construction & Roofing provides Ferdinand with the full range of residential roofing services, from historic home roofing to modern new construction."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims', 'Emergency Repairs']}
      neighborhoods={['Ferdinand Town Center', 'Monastery Area', 'I-64 Corridor', 'Ferdinand State Forest Area', 'Dubois County Rural Routes']}
      faqs={[
        { q: 'Do you serve Ferdinand Indiana for roofing?', a: 'Yes — Ferdinand and all of Dubois County are within our extended service territory. We provide the same quality workmanship and honest pricing as our core Evansville market.' },
        { q: 'How much does a roof replacement cost in Ferdinand IN?', a: 'Residential roof replacements in Ferdinand typically range from $8,000 to $22,000 depending on home size, pitch, and materials selected. Free, no-obligation estimates available.' },
        { q: 'How quickly can you respond to a roofing emergency in Ferdinand?', a: 'Ferdinand is about 50 miles from Evansville via I-64. We typically respond within 75-90 minutes for emergency calls in Dubois County.' },
        { q: 'Do you handle insurance claims for storm damage?', a: 'Yes. Our team are insurance claim specialists — we document all damage, meet with your adjuster, and handle the full claims process to make sure you receive every dollar your policy covers.' },
      ]}
      schema={schema}
    />
  );
}