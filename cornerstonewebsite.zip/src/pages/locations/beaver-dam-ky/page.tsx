import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Beaver Dam KY',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/beaver-dam-ky',
  address: { '@type': 'PostalAddress', addressLocality: 'Beaver Dam', addressRegion: 'KY', postalCode: '42320' },
  areaServed: { '@type': 'City', name: 'Beaver Dam', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  description: 'Roofing contractor serving Beaver Dam Kentucky. Free inspections, storm damage, residential & commercial roofing in Ohio County. Fully licensed in KY.',
};

export default function BeaverDamKYPage() {
  return (
    <CityPage
      city="Beaver Dam"
      state="Kentucky"
      stateAbbr="KY"
      county="Ohio County"
      slug="beaver-dam-ky"
      population="3,500+"
      distance="65 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Beaver Dam Kentucky's trusted roofing contractor. Corner Stone is fully licensed in Kentucky and serves Ohio County with expert roofing, storm damage repair, and extended-range emergency services."
      longDesc="Corner Stone Construction & Roofing extends its trusted roofing services to Beaver Dam and Ohio County — one of our furthest Kentucky service areas, but a community we are proud to serve. Beaver Dam is one of Ohio County's largest towns and a regional hub for the surrounding rural communities. We are fully licensed and insured in Kentucky, and while Beaver Dam sits at the edge of our standard service radius, we bring the same quality workmanship and attention to detail that Evansville homeowners have trusted for over 25 years. Ohio County sees the full spectrum of Kentucky weather — from ice storms in winter to severe thunderstorms and hail in spring and summer. These conditions take a real toll on roofing, and our crews are trained to identify both obvious storm damage and the more subtle signs of gradual deterioration. We work with all major Kentucky insurance carriers and handle the claims process from start to finish. For larger projects in Ohio County, we coordinate scheduling to ensure efficient crew deployment, making the extra distance seamless for our customers."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Commercial Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Roof Maintenance']}
      neighborhoods={['Beaver Dam Downtown', 'Beaver Dam Elementary Area', 'Ohio County High School Area', 'North Beaver Dam', 'South Beaver Dam', 'East Beaver Dam', 'West Beaver Dam', 'McHenry Area', 'Rockport KY Area', 'Rural Ohio County Routes', 'SR 231 Corridor', 'Cromwell Area']}
      faqs={[
        { q: 'Do you provide roofing services in Beaver Dam Kentucky?', a: 'Yes — we are fully licensed in Kentucky and serve Beaver Dam and Ohio County with our extended-range crews. You get the same Corner Stone quality, even at 65 miles from our base.' },
        { q: 'How much does a roof replacement cost in Beaver Dam KY?', a: 'Residential roof replacements in Beaver Dam typically range from $8,000 to $21,000 depending on home size, roof complexity, and materials. We always provide free estimates.' },
        { q: 'Can you help with Kentucky insurance claims for storm damage?', a: 'Absolutely — we are experienced with Kentucky insurance procedures. We document all storm damage, meet KY adjusters on-site, and handle claim paperwork to maximize your coverage.' },
        { q: 'How quickly can you respond to emergencies in Beaver Dam?', a: 'Beaver Dam is approximately 65 miles from our Evansville base. For emergencies, we typically respond within 90 minutes to 2 hours, with 24/7 emergency dispatch available.' },
        { q: 'Do you handle commercial roofing in Ohio County?', a: 'Yes — we serve both residential and commercial properties in Ohio County, including businesses along the main commercial corridors in Beaver Dam. We handle flat roofs, metal roofs, and architectural shingle systems.' },
      ]}
      schema={schema}
    />
  );
}