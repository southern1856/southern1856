import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Lawrenceville IL',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/lawrenceville-il',
  address: { '@type': 'PostalAddress', addressLocality: 'Lawrenceville', addressRegion: 'IL', postalCode: '62439' },
  areaServed: { '@type': 'City', name: 'Lawrenceville', containedInPlace: { '@type': 'State', name: 'Illinois' } },
  description: 'Roofing contractor serving Lawrenceville Illinois. Free inspections, storm damage repair, residential & commercial roofing in Lawrence County. Licensed & insured. Call 812-213-5997.',
};

export default function LawrencevilleILPage() {
  return (
    <CityPage
      city="Lawrenceville"
      state="Illinois"
      stateAbbr="IL"
      county="Lawrence County"
      slug="lawrenceville-il"
      population="4,300+"
      distance="48 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Lawrenceville Illinois's trusted roofing contractor serving Lawrence County. Corner Stone delivers expert roofing, storm damage repair, and 24/7 emergency services to homes and businesses across southeastern Illinois."
      longDesc="Corner Stone Construction &amp; Roofing is proud to serve Lawrenceville and all of Lawrence County — just 48 miles from our Evansville headquarters via US 50. Lawrenceville sits along the Embarras River in southeastern Illinois and is the county seat of Lawrence County, with a proud agricultural heritage and a tight-knit community of longtime homeowners. Like much of the lower Wabash Valley, Lawrenceville endures severe spring thunderstorms, straight-line winds, and the occasional hailstorm that can tear through roofs without warning. The Embarras River bottoms create humid microclimates that accelerate moss and algae buildup on north-facing roof slopes — a problem we see on homes all along the river corridor. Our crews know the local landscape: from the historic homes near the Lawrence County Courthouse and the tree-lined streets of the older neighborhoods to the farmhouses and agricultural buildings scattered across the rural routes. We handle the full scope of roofing and exterior needs in Lawrenceville: complete tear-offs and replacements, storm damage insurance claims, emergency tarping, metal roofing for barns and ag structures, siding and fascia repair, and gutter systems. Fully licensed and insured in Illinois, backed by a GAF Master Elite certification — Corner Stone delivers the same honest pricing and quality workmanship that the Tri-State has trusted for over 25 years."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Wind Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Commercial Roofing', 'Siding & Fascia Repair']}
      neighborhoods={['Lawrenceville Downtown', 'Lawrence County Courthouse Area', 'Embarras River Corridor', 'Lawrenceville High School Area', 'North Lawrenceville', 'South Lawrenceville', 'US 50 Business Corridor', 'Rural Lawrence County', 'Bridgeport Area', 'Sumner Area', 'St. Francisville Area', 'Red Hills State Park Vicinity']}
      faqs={[
        { q: 'Do you provide roofing services in Lawrenceville Illinois?', a: 'Yes — we proudly serve Lawrenceville and all of Lawrence County. Located about 48 miles from our Evansville base via US 50, we offer fast response times and are fully licensed and insured in Illinois.' },
        { q: 'How much does a roof replacement cost in Lawrenceville IL?', a: 'Most residential roof replacements in Lawrenceville range from $8,000 to $22,000 depending on home size, roof pitch, and material selection. We provide free, no-obligation estimates with no pressure.' },
        { q: 'Can you help with Illinois insurance claims for storm damage?', a: 'Absolutely. We are experienced with Illinois insurance claim procedures and document all damage thoroughly with photos and measurements. We will meet your adjuster on-site and handle the paperwork to maximize your coverage.' },
        { q: 'How quickly can you respond to roofing emergencies in Lawrenceville?', a: 'Lawrenceville is about 48 miles from our Evansville base via US 50. For emergencies in town near the courthouse square or along State Street, we typically arrive within 55 to 65 minutes. For homes out on the rural routes toward Bridgeport or Sumner, figure closer to 70 minutes. We offer 24/7 emergency tarping throughout Lawrence County.' },
        { q: 'Does river humidity from the Embarras River cause roof problems in Lawrenceville?', a: 'Yes — the Embarras River valley creates persistent humidity that fuels moss and algae growth, especially on north-facing roof slopes and shaded lots near the river corridor. Over time, trapped moisture degrades shingles and shortens roof life. We offer moss treatment, preventative zinc strip installation, and full replacements when the damage has progressed too far.' },
      ]}
      schema={schema}
    />
  );
}