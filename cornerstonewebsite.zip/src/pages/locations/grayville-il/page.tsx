import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Grayville IL',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/grayville-il',
  address: { '@type': 'PostalAddress', addressLocality: 'Grayville', addressRegion: 'IL', postalCode: '62844' },
  areaServed: { '@type': 'City', name: 'Grayville', containedInPlace: { '@type': 'State', name: 'Illinois' } },
  description: 'Roofing contractor serving Grayville Illinois. Free inspections, storm damage repair, residential & commercial roofing in Edwards County. Licensed & insured. Call 812-213-5997.',
};

export default function GrayvilleILPage() {
  return (
    <CityPage
      city="Grayville"
      state="Illinois"
      stateAbbr="IL"
      county="Edwards County"
      slug="grayville-il"
      population="1,600+"
      distance="40 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Grayville Illinois's trusted roofing contractor. Corner Stone serves Edwards County with expert residential and commercial roofing, storm damage repair, and 24/7 emergency services — fully licensed and insured in Illinois."
      longDesc="Corner Stone Construction & Roofing is excited to bring our 25-plus years of Tri-State roofing experience to Grayville and Edwards County, Illinois. Grayville sits right on the Wabash River at the I-64 crossing — making it one of the most accessible Illinois communities from our Evansville headquarters at just 40 miles away. This historic river town has seen plenty of severe weather roll through over the years, and many homes carry roofs that have weathered decades of Midwestern storms. Our crews specialize in spotting the subtle signs of aging and storm damage that Illinois homeowners might miss — curling shingles, granule loss, wind lift, and hail bruising. We handle the full spectrum of roofing services in Grayville: complete tear-offs with architectural shingle upgrades, metal roofing for homes and agricultural buildings, emergency storm tarping, gutter replacement, and comprehensive insurance claims support. Whether your Grayville home needs a minor repair or a full replacement, you get the same GAF Master Elite workmanship and honest pricing that homeowners across Indiana and Kentucky have relied on for over two decades."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Commercial Roofing', 'Roof Maintenance']}
      neighborhoods={['Grayville Downtown', 'Wabash Riverfront Area', 'North Grayville', 'South Grayville', 'East Grayville', 'West Grayville', 'I-64 Corridor', 'Rural Edwards County', 'Albion Road Area', 'Bone Gap Area', 'West Salem Area', 'Grayville School Area']}
      faqs={[
        { q: 'Do you provide roofing services in Grayville Illinois?', a: 'Yes — we are fully licensed in Illinois and serve Grayville and all of Edwards County. Grayville is just 40 miles from our Evansville base with easy access via I-64, so we provide fast response times for all roofing needs.' },
        { q: 'How much does a roof replacement cost in Grayville IL?', a: 'Most residential roof replacements in Grayville range from $8,000 to $21,000 depending on home size, roof complexity, and material selection. We offer free, no-obligation estimates for every project.' },
        { q: 'Can you help with Illinois insurance claims for storm damage?', a: 'Yes — we handle Illinois insurance claims from start to finish. Our team documents all storm damage thoroughly, meets adjusters on-site, and manages all paperwork to help you get the maximum payout from your policy.' },
        { q: 'How quickly can you respond to roofing emergencies in Grayville?', a: 'Grayville is about 40 miles from our Evansville base, with easy I-64 access. For emergency calls, we typically arrive within 50 to 65 minutes and offer 24/7 emergency tarping and board-up services throughout Edwards County.' },
        { q: 'Do you work on farm buildings and agricultural roofing in Edwards County?', a: 'Yes — we have extensive experience with agricultural roofing throughout the area, including metal barn roofs, pole buildings, equipment storage sheds, and farmhouse roofing. Our metal roofing crews are fully equipped for rural Illinois properties.' },
      ]}
      schema={schema}
    />
  );
}