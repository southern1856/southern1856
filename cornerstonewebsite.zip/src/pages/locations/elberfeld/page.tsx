import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Elberfeld IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/elberfeld',
  address: { '@type': 'PostalAddress', addressLocality: 'Elberfeld', addressRegion: 'IN', postalCode: '47613' },
  areaServed: { '@type': 'City', name: 'Elberfeld', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Elberfeld Indiana and Warrick County. Free inspections, storm damage repair, residential roofing for Elberfeld homeowners.',
};

export default function ElberfeldPage() {
  return (
    <CityPage
      city="Elberfeld"
      state="Indiana"
      stateAbbr="IN"
      county="Warrick County"
      slug="elberfeld"
      population="650+"
      distance="18 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Elberfeld's local roofing contractor in Warrick County. Corner Stone brings 25+ years of Tri-State roofing expertise to one of Warrick County's fastest-growing communities — just minutes from Evansville."
      longDesc="Elberfeld is practically in our backyard — just a short drive up I-64 from Evansville. This small but growing Warrick County community trusts Corner Stone Construction & Roofing for all their roofing needs, from new construction roof installations to storm damage repairs and full replacements. We are fully licensed in Indiana and know Warrick County building codes inside and out, which means faster permitting and fewer headaches for Elberfeld homeowners."
      services={['Residential Roofing', 'New Construction Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Roof Repair', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims', 'Emergency Repairs']}
      neighborhoods={['Elberfeld Town Center', 'I-64 Corridor', 'Warrick County Rural Routes', 'Elberfeld School District', 'German Ridge Road Area']}
      faqs={[
        { q: 'Do you serve Elberfeld Indiana for roofing?', a: 'Absolutely — Elberfeld is one of our closest Warrick County communities, just 18 miles from our Evansville headquarters. We respond faster to Elberfeld than almost any other outlying town.' },
        { q: 'How much does a roof replacement cost in Elberfeld IN?', a: 'Residential roof replacements in Elberfeld typically range from $7,000 to $19,000 depending on home size, pitch, and materials. We provide free, no-obligation estimates.' },
        { q: 'How quickly can you respond to a roofing emergency in Elberfeld?', a: 'Elberfeld is roughly 18 miles from Evansville via I-64. We can typically have a crew on-site within 30-45 minutes for emergency calls.' },
        { q: 'Do you handle insurance claims for storm damage?', a: 'Yes — we are insurance claim specialists. We thoroughly document all damage, meet your adjuster at your property, and handle every bit of paperwork so your claim gets approved at full value.' },
      ]}
      schema={schema}
    />
  );
}