import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Henderson KY',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/henderson-ky',
  address: { '@type': 'PostalAddress', addressLocality: 'Henderson', addressRegion: 'KY', postalCode: '42420' },
  areaServed: { '@type': 'City', name: 'Henderson', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  description: 'Roofing contractor serving Henderson Kentucky. Fully licensed in KY. Free inspections, storm damage, residential & commercial roofing in Henderson County.',
};

export default function HendersonKYPage() {
  return (
    <CityPage
      city="Henderson"
      state="Kentucky"
      stateAbbr="KY"
      county="Henderson County"
      slug="henderson-ky"
      population="28,000+"
      distance="15 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Henderson KY's go-to roofing contractor. Fully licensed in Kentucky, Corner Stone has served Henderson County homeowners and businesses for over 25 years — just across the Ohio River."
      longDesc="Just 15 miles from our Evansville headquarters, Henderson Kentucky is a major part of our service territory. We are fully licensed and insured in Kentucky, and we know Henderson's local building codes and permit requirements. From the historic downtown homes to new subdivisions in Wolf Hills, our crews deliver the same quality and speed that Evansville homeowners have trusted since 1995."
      services={['Residential Roofing', 'Commercial Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims', 'Emergency Repairs']}
      neighborhoods={['Henderson Downtown', 'Audubon State Park Area', 'Henderson Community College Area', 'Wolf Hills', 'South Henderson', 'Atkinson Park Area', 'Robards', 'Corydon']}
      faqs={[
        { q: 'Are you licensed to do roofing in Kentucky?', a: 'Yes — Corner Stone is fully licensed and insured in both Indiana and Kentucky. We regularly serve Henderson County and surrounding KY communities.' },
        { q: 'How much does a roof replacement cost in Henderson KY?', a: 'Roof replacements in Henderson typically range from $8,500 to $24,000 depending on size, pitch, and materials. We offer free estimates with no obligation.' },
        { q: 'Do you handle Kentucky insurance claims for storm damage?', a: 'Yes. We work with all major insurance carriers in Kentucky and handle the full claims process — documentation, adjuster meetings, and paperwork.' },
        { q: 'How quickly can you get to Henderson KY for an emergency?', a: 'Henderson is only 15 miles from our Evansville base. We typically arrive within 45-60 minutes for emergency calls in Henderson County.' },
      ]}
      schema={schema}
    />
  );
}
