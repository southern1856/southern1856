import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Livermore KY',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/livermore-ky',
  address: { '@type': 'PostalAddress', addressLocality: 'Livermore', addressRegion: 'KY', postalCode: '42352' },
  areaServed: { '@type': 'City', name: 'Livermore', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  description: 'Roofing contractor serving Livermore Kentucky. Free inspections, storm damage, residential & commercial roofing in McLean County. Fully licensed in KY.',
};

export default function LivermoreKYPage() {
  return (
    <CityPage
      city="Livermore"
      state="Kentucky"
      stateAbbr="KY"
      county="McLean County"
      slug="livermore-ky"
      population="1,300+"
      distance="45 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Livermore Kentucky's trusted roofing contractor. Corner Stone is fully licensed in Kentucky and serves McLean County with expert roofing, storm damage repair, and 24/7 emergency services."
      longDesc="Corner Stone Construction & Roofing is proud to serve Livermore, a historic Green River community in McLean County. Livermore's location along the Green River gives it a unique character — and unique roofing challenges. River valley humidity can accelerate wear on asphalt shingles, and the open exposure along the river corridor means homes face stronger wind gusts during storms. We are fully licensed and insured in Kentucky, and our crews have the local knowledge to assess these specific conditions and recommend the right roofing solutions for Livermore properties. From wind-resistant architectural shingles to long-lasting metal roofing systems, we help homeowners choose materials that will stand up to McLean County's weather. We are also experienced in insurance claims — when storms cause damage, we document everything, meet with Kentucky adjusters, and fight for fair coverage. Whether you need emergency repairs after a storm or are planning a complete roof replacement, Corner Stone brings over 25 years of Tri-State roofing experience to every Livermore project."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Agricultural Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Roof Maintenance']}
      neighborhoods={['Livermore Downtown', 'Green River Front', 'Livermore Landing', 'Livermore Elementary Area', 'North Livermore', 'South Livermore', 'Rural McLean County Routes', 'Island KY Area', 'Nuckols Area', 'Glenville Area', 'Rumsey Area', 'SR 136 Corridor']}
      faqs={[
        { q: 'Do you provide roofing services in Livermore Kentucky?', a: 'Yes — we are fully licensed in Kentucky and serve Livermore and all of McLean County. Our extended-range crews deliver the same quality workmanship we are known for.' },
        { q: 'How much does a roof replacement cost in Livermore KY?', a: 'Roof replacements in Livermore generally range from $7,500 to $20,000 based on home size, roof pitch, and material selection. Free estimates are always available with no obligation.' },
        { q: 'Can you help with Kentucky insurance claims for wind and storm damage?', a: 'Yes — we specialize in storm damage claims. We document every detail, meet KY adjusters at your property, and manage the full claims process to ensure you receive fair coverage.' },
        { q: 'How quickly can you respond to roofing emergencies in Livermore?', a: 'Livermore is approximately 45 miles from our Evansville base. We typically arrive within 60 to 75 minutes for emergency calls, with 24/7 dispatch and emergency tarping available.' },
        { q: 'Are you licensed and insured to work in Kentucky?', a: 'Yes — Corner Stone Construction & Roofing is fully licensed and insured in both Indiana and Kentucky. All our KY projects meet state and local building code requirements.' },
      ]}
      schema={schema}
    />
  );
}