import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Providence KY',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/providence-ky',
  address: { '@type': 'PostalAddress', addressLocality: 'Providence', addressRegion: 'KY', postalCode: '42450' },
  areaServed: { '@type': 'City', name: 'Providence', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  description: 'Roofing contractor serving Providence Kentucky. Free inspections, storm damage, residential & commercial roofing in Webster County. Fully licensed in KY.',
};

export default function ProvidenceKYPage() {
  return (
    <CityPage
      city="Providence"
      state="Kentucky"
      stateAbbr="KY"
      county="Webster County"
      slug="providence-ky"
      population="3,100+"
      distance="45 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Providence Kentucky's trusted roofing contractor. Corner Stone is fully licensed in Kentucky and serves Webster County with expert roofing, storm damage repair, and emergency services."
      longDesc="Corner Stone Construction & Roofing brings over 25 years of roofing expertise to Providence and Webster County. We are fully licensed and insured in Kentucky, giving Providence homeowners confidence that their roofing project meets all state requirements. Webster County sits in the heart of Western Kentucky's coal and agricultural region, where homes and buildings face constant exposure to shifting weather patterns — from hot humid summers that accelerate shingle aging to severe spring storms that can tear roofing materials apart. Our experienced crews know how to identify damage that might not be obvious from the ground, and we specialize in helping property owners navigate the insurance claims process after storm events. Whether you need a few shingles replaced after wind damage or a complete roof replacement with modern architectural shingles, Corner Stone delivers quality you can count on. We also serve the area's agricultural community with durable metal roofing for barns, sheds, and farm structures."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Agricultural Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Roof Maintenance']}
      neighborhoods={['Providence Downtown', 'Providence Elementary Area', 'North Providence', 'South Providence', 'East Providence', 'West Providence', 'Clay Area', 'Wheatcroft Area', 'Dixon Area', 'Rural Webster County Routes', 'SR 120 Corridor', 'Slaughters Area']}
      faqs={[
        { q: 'Do you provide roofing services in Providence Kentucky?', a: 'Yes — we are fully licensed in Kentucky and serve Providence and all of Webster County. Our extended-range crews bring the same quality as our core Evansville market.' },
        { q: 'How much does a roof replacement cost in Providence KY?', a: 'Most residential roof replacements in Providence range from $7,500 to $20,000 depending on home size, pitch, and materials. We always provide free estimates with no pressure.' },
        { q: 'Do you handle storm damage and insurance claims in Webster County?', a: 'Yes — we are experienced with Kentucky insurance procedures. We document damage, meet KY adjusters on-site, and manage all paperwork to help you get fair coverage.' },
        { q: 'How quickly can you respond to emergencies in Providence?', a: 'Providence is approximately 45 miles from our Evansville base. We typically respond within 75 to 90 minutes for emergency calls and offer 24/7 emergency tarping services.' },
        { q: 'Are you licensed to work in Kentucky?', a: 'Yes — Corner Stone Construction & Roofing is fully licensed and insured in both Indiana and Kentucky. We meet all Kentucky state requirements.' },
      ]}
      schema={schema}
    />
  );
}