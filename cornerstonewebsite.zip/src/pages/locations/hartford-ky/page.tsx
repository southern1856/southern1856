import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Hartford KY',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/hartford-ky',
  address: { '@type': 'PostalAddress', addressLocality: 'Hartford', addressRegion: 'KY', postalCode: '42347' },
  areaServed: { '@type': 'City', name: 'Hartford', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  description: 'Roofing contractor serving Hartford Kentucky. Free inspections, storm damage, residential & commercial roofing in Ohio County. Fully licensed in KY.',
};

export default function HartfordKYPage() {
  return (
    <CityPage
      city="Hartford"
      state="Kentucky"
      stateAbbr="KY"
      county="Ohio County"
      slug="hartford-ky"
      population="2,700+"
      distance="70 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Hartford Kentucky's trusted roofing contractor. Corner Stone is fully licensed in Kentucky and serves Ohio County with expert roofing, storm damage repair, and extended-range emergency services."
      longDesc="Corner Stone Construction & Roofing is honored to serve Hartford, the county seat of Ohio County and one of Western Kentucky's historic communities. Hartford is known for its charming courthouse square and deep roots in Kentucky history — and its homes deserve roofing that honors that heritage while providing modern protection. We are fully licensed and insured in Kentucky, and while Hartford sits at the outer edge of our service radius at 70 miles, we make the trip because Ohio County homeowners deserve the same quality roofing that has made Corner Stone the Tri-State's most trusted name. Hartford experiences all the weather extremes of Western Kentucky — from freezing winter precipitation to intense summer thunderstorms with hail and damaging winds. Our experienced crews know how to identify storm damage, recommend appropriate materials for Kentucky's climate, and handle the insurance claims process from documentation through final settlement. For larger roofing projects in the Hartford area, we coordinate scheduling to ensure efficient use of our crews and materials, making the extra distance seamless for our Ohio County customers."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Commercial Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs']}
      neighborhoods={['Hartford Downtown', 'Ohio County Courthouse Square', 'Hartford Elementary Area', 'Ohio County High School Area', 'North Hartford', 'South Hartford', 'East Hartford', 'West Hartford', 'Rural Ohio County Routes', 'Fordsville Area', 'Centertown Area', 'Beaver Dam Area']}
      faqs={[
        { q: 'Do you provide roofing services in Hartford Kentucky?', a: 'Yes — we are fully licensed in Kentucky and serve Hartford and Ohio County with our extended-range crews. Even at 70 miles, we deliver the same trusted Corner Stone quality.' },
        { q: 'How much does a roof replacement cost in Hartford KY?', a: 'Residential roof replacements in Hartford generally range from $8,000 to $21,000 depending on home size, roof pitch, and materials selected. Free estimates are always available.' },
        { q: 'Do you handle Kentucky insurance claims for hail and storm damage?', a: 'Yes — we have extensive experience with Kentucky insurance procedures. We document damage thoroughly, meet KY adjusters on-site, and manage all claim paperwork to maximize your coverage.' },
        { q: 'How quickly can you respond to roofing emergencies in Hartford?', a: 'Hartford is approximately 70 miles from our Evansville base. We typically respond within 90 minutes to 2 hours for emergency calls, with 24/7 dispatch and emergency tarping when needed.' },
        { q: 'Do you work on historic homes in downtown Hartford?', a: 'Yes — we have experience working on historic and older homes and can match roofing materials and styles to preserve your home\'s character while providing modern protection and energy efficiency.' },
      ]}
      schema={schema}
    />
  );
}