import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Calhoun KY',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/calhoun-ky',
  address: { '@type': 'PostalAddress', addressLocality: 'Calhoun', addressRegion: 'KY', postalCode: '42327' },
  areaServed: { '@type': 'City', name: 'Calhoun', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  description: 'Roofing contractor serving Calhoun Kentucky. Free inspections, storm damage, residential & commercial roofing in McLean County. Fully licensed in KY.',
};

export default function CalhounKYPage() {
  return (
    <CityPage
      city="Calhoun"
      state="Kentucky"
      stateAbbr="KY"
      county="McLean County"
      slug="calhoun-ky"
      population="800+"
      distance="50 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Calhoun Kentucky's trusted roofing contractor. Corner Stone is fully licensed in Kentucky and serves McLean County with expert roofing, storm damage repair, and emergency services."
      longDesc="Corner Stone Construction & Roofing extends its trusted roofing services to Calhoun, the seat of McLean County. Nestled along the Green River, Calhoun is a picturesque small town where homes face unique environmental challenges — from river valley moisture that can accelerate roof aging to severe storms that sweep through the Green River corridor. We are fully licensed and insured in Kentucky, and our crews understand the specific needs of Calhoun homes, from historic properties near the courthouse square to newer construction on the outskirts of town. McLean County's rural character means we also serve the area's agricultural community with durable metal roofing for barns, equipment sheds, and farm structures. When storms roll through, our emergency response team mobilizes quickly to provide tarping and immediate damage assessments. We also work directly with Kentucky insurance adjusters to help Calhoun homeowners navigate the claims process and secure fair settlements. With over 25 years of experience across the Tri-State, Corner Stone is the roofing partner Calhoun can count on."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Agricultural Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Roof Maintenance']}
      neighborhoods={['Calhoun Downtown', 'McLean County Courthouse Area', 'Green River Front Area', 'Calhoun Elementary Area', 'North Calhoun', 'South Calhoun', 'Rural McLean County Routes', 'Island KY Area', 'Rumsey Area', 'Sacramento Area', 'Beech Grove Area', 'Guiffrie Area']}
      faqs={[
        { q: 'Do you provide roofing services in Calhoun Kentucky?', a: 'Yes — we are fully licensed in Kentucky and serve Calhoun and all of McLean County. Our extended-range crews bring the same quality and professionalism to every job.' },
        { q: 'How much does a roof replacement cost in Calhoun KY?', a: 'Roof replacements in Calhoun typically range from $7,500 to $19,000 depending on home size, complexity, and materials chosen. We provide free estimates with absolutely no obligation.' },
        { q: 'Can you help with Kentucky insurance claims for storm damage?', a: 'Absolutely. We have extensive experience with Kentucky insurance claim procedures. We document all damage, meet KY adjusters on-site, and handle the paperwork to maximize your settlement.' },
        { q: 'How quickly can you respond to emergencies in Calhoun?', a: 'Calhoun is approximately 50 miles from our Evansville base. We typically respond within 75 to 90 minutes for emergency calls, with 24/7 dispatch and emergency tarping available.' },
        { q: 'Do you handle agricultural and farm roofing in McLean County?', a: 'Yes — we specialize in metal roofing for barns, farm buildings, equipment sheds, and agricultural structures throughout McLean County. Our metal roofing crews are among the most experienced in the region.' },
      ]}
      schema={schema}
    />
  );
}