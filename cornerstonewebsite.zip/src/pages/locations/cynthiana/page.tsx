import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Cynthiana IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/cynthiana',
  address: { '@type': 'PostalAddress', addressLocality: 'Cynthiana', addressRegion: 'IN', postalCode: '47612' },
  areaServed: { '@type': 'City', name: 'Cynthiana', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Cynthiana Indiana and Posey County. Free inspections, storm damage repair, residential roofing for Cynthiana homeowners.',
};

export default function CynthianaPage() {
  return (
    <CityPage
      city="Cynthiana"
      state="Indiana"
      stateAbbr="IN"
      county="Posey County"
      slug="cynthiana"
      population="550+"
      distance="25 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Cynthiana and Posey County's trusted roofing contractor. Corner Stone brings 25+ years of Tri-State roofing expertise to one of Posey County's historic small towns — same quality, same honest pricing."
      longDesc="Cynthiana is one of Posey County's oldest communities, with a history stretching back to the early 1800s. Today's Cynthiana homeowners need a roofing contractor who treats their properties with the respect they deserve — whether it is a century-old farmhouse or a newer subdivision home. Corner Stone Construction & Roofing delivers that care with premium materials, skilled crews, and the straightforward pricing that has made us the Tri-State's trusted roofer since 1995."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims', 'Emergency Repairs']}
      neighborhoods={['Cynthiana Town Center', 'SR 68 Corridor', 'Posey County Rural Routes', 'Cynthiana Historic District', 'Wabash River Lowlands']}
      faqs={[
        { q: 'Do you serve Cynthiana Indiana for roofing?', a: 'Yes — Cynthiana and all of Posey County are within our active service territory. We provide the same fast response and quality workmanship as our Evansville headquarters.' },
        { q: 'How much does a roof replacement cost in Cynthiana IN?', a: 'Residential roof replacements in Cynthiana typically range from $7,000 to $18,500 depending on home size, pitch, and materials selected. Free estimates available with no obligation.' },
        { q: 'How quickly can you respond to a roofing emergency in Cynthiana?', a: 'Cynthiana is about 25 miles from Evansville via SR 68. We typically respond within 45-60 minutes for emergency calls in Posey County.' },
        { q: 'Do you handle storm damage insurance claims?', a: 'Yes. We are insurance claim specialists. Our team documents every detail of the damage, meets your adjuster on-site, and handles all the paperwork so you receive the full payout your policy covers.' },
      ]}
      schema={schema}
    />
  );
}