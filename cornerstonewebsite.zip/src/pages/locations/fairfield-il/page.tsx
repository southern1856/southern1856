import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Fairfield IL',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/fairfield-il',
  address: { '@type': 'PostalAddress', addressLocality: 'Fairfield', addressRegion: 'IL', postalCode: '62837' },
  areaServed: { '@type': 'City', name: 'Fairfield', containedInPlace: { '@type': 'State', name: 'Illinois' } },
  description: 'Roofing contractor serving Fairfield Illinois. Free inspections, storm damage repair, residential & commercial roofing in Wayne County. Licensed & insured. Call 812-213-5997.',
};

export default function FairfieldILPage() {
  return (
    <CityPage
      city="Fairfield"
      state="Illinois"
      stateAbbr="IL"
      county="Wayne County"
      slug="fairfield-il"
      population="5,100+"
      distance="55 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Fairfield Illinois's trusted roofing contractor serving Wayne County. Corner Stone delivers expert roofing, storm damage repair, and 24/7 emergency services to homes and businesses across southeastern Illinois."
      longDesc="Corner Stone Construction &amp; Roofing serves Fairfield and all of Wayne County from our Evansville headquarters — about 55 miles away via IL-15 and US 45. Fairfield is the county seat of Wayne County and sits at the crossroads of several state highways, making it a natural hub for southeastern Illinois. The town has a proud agricultural backbone, with many multi-generational farm families who depend on their homes, barns, and outbuildings to keep operations running. Wayne County weather does not hold back — spring and summer bring intense thunderstorms with damaging straight-line winds, and the county has seen its share of tornado-warned storms that leave roofs shredded in their wake. The older homes around the Wayne County Courthouse and in Fairfield's historic neighborhoods were built with craftsmanship but often have aging roof systems overdue for replacement. Our crews know the rhythm of this community: the farmhouse that has been in the family for 80 years, the rental property near Frontier Community College, the metal pole barn that needs to stay dry for harvest season. We provide everything Fairfield homeowners and farmers need: full roof replacements, storm damage repair with insurance claims support, metal roofing for agricultural buildings, siding and fascia repair, seamless gutters, and 24/7 emergency tarping. Licensed and insured in Illinois with GAF Master Elite certification — Corner Stone brings the same honest, no-pressure approach that homeowners across three states have trusted for over 25 years."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Wind Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Commercial Roofing', 'Siding & Fascia Repair']}
      neighborhoods={['Fairfield Downtown', 'Wayne County Courthouse Area', 'Frontier Community College Area', 'North Fairfield Residential', 'South Fairfield Neighborhoods', 'Fairfield Memorial Hospital Area', 'IL-15 Business Corridor', 'Rural Wayne County', 'Wayne City Area', 'Cisne Area', 'Albion Area', 'Skillet Fork River Vicinity']}
      faqs={[
        { q: 'Do you provide roofing services in Fairfield Illinois?', a: 'Yes — we proudly serve Fairfield and all of Wayne County. Located about 55 miles from our Evansville base via IL-15 and US 45, we offer reliable response times and are fully licensed and insured in Illinois.' },
        { q: 'How much does a roof replacement cost in Fairfield IL?', a: 'Most residential roof replacements in Fairfield range from $8,500 to $22,000 depending on home size, roof pitch, and material. Historic homes near the courthouse or farmhouses on rural routes may fall at the higher end due to roof complexity. We provide free, no-obligation estimates.' },
        { q: 'Can you help with Illinois insurance claims for storm damage?', a: 'Absolutely. We are experienced with Illinois insurance claim procedures and document all storm damage thoroughly. We will meet your adjuster on-site and handle the paperwork to maximize your coverage — at no extra cost to you.' },
        { q: 'How quickly can you respond to roofing emergencies in Fairfield?', a: 'Fairfield is about 55 miles from our Evansville base. For emergencies in town near the courthouse or along Main Street, we typically arrive within 65 to 75 minutes. For homes out on the rural routes toward Wayne City or Cisne, figure closer to 80 to 85 minutes. We offer 24/7 emergency tarping throughout Wayne County.' },
        { q: 'Do you work on agricultural buildings and barn roofs in Wayne County?', a: 'Yes — Wayne County is farm country, and we specialize in agricultural roofing. Metal barn roofs, pole buildings, equipment sheds, grain bin roof repairs, and farmhouse roofing are all regular parts of our work in the area. Our metal roofing crews understand the unique demands of agricultural structures and get the job done right.' },
      ]}
      schema={schema}
    />
  );
}