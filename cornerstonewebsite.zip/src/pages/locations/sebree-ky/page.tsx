import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Sebree KY',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/sebree-ky',
  address: { '@type': 'PostalAddress', addressLocality: 'Sebree', addressRegion: 'KY', postalCode: '42455' },
  areaServed: { '@type': 'City', name: 'Sebree', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  description: 'Roofing contractor serving Sebree Kentucky. Free inspections, storm damage, residential & commercial roofing in Webster County. Fully licensed in KY.',
};

export default function SebreeKYPage() {
  return (
    <CityPage
      city="Sebree"
      state="Kentucky"
      stateAbbr="KY"
      county="Webster County"
      slug="sebree-ky"
      population="1,600+"
      distance="40 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Sebree Kentucky's trusted roofing contractor. Corner Stone is fully licensed in Kentucky and serves Webster County with expert roofing, storm damage repair, and 24/7 emergency response."
      longDesc="Corner Stone Construction & Roofing proudly serves Sebree and the northern portion of Webster County with the same dedication to quality that has built our reputation across the Tri-State. Sebree sits along a major highway corridor, which means many homes are exposed to wind-driven rain and debris that can cause hidden roof damage over time. We are fully licensed and insured in Kentucky, and our crews are trained to spot the subtle signs of roof deterioration before they become expensive problems. Webster County experiences the full range of Kentucky weather extremes — from ice storms in winter to severe thunderstorms and occasional tornado conditions in spring. When storms hit, we are one of the first roofing contractors on the ground, offering emergency tarping and comprehensive damage assessments. We also work extensively with Kentucky insurance providers to help Sebree homeowners get fair settlements for storm-related roof damage. From routine maintenance to complete replacements, Corner Stone is the roofing partner Sebree residents can rely on."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Agricultural Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Roof Maintenance']}
      neighborhoods={['Sebree Downtown', 'Sebree Elementary Area', 'North Sebree', 'South Sebree', 'East Sebree', 'West Sebree', 'SR 41 Corridor', 'Poole Area', 'Ontario Area', 'Rural Webster County North', 'I-69 Area', 'Robards Area']}
      faqs={[
        { q: 'Do you provide roofing services in Sebree Kentucky?', a: 'Yes — we are fully licensed in Kentucky and serve Sebree and all of Webster County. Our extended-range crews deliver the same quality that Evansville homeowners have trusted for over 25 years.' },
        { q: 'How much does a roof replacement cost in Sebree KY?', a: 'Roof replacements in Sebree typically range from $7,500 to $19,000 depending on home size, roof complexity, and materials selected. Free estimates are always available with no obligation.' },
        { q: 'Can you help with Kentucky insurance claims for storm damage?', a: 'Absolutely — we handle the full insurance claim process. From thorough damage documentation to on-site adjuster meetings and claim paperwork, we make sure you get the coverage you deserve.' },
        { q: 'How quickly can you respond to emergencies in Sebree?', a: 'Sebree is approximately 40 miles from our Evansville base. We typically respond within 60 to 75 minutes for emergency calls and offer 24/7 emergency tarping service.' },
        { q: 'Do you do agricultural and commercial roofing in Webster County?', a: 'Yes — we provide metal roofing for barns, pole buildings, and agricultural structures, plus commercial flat roofing for businesses throughout Webster County.' },
      ]}
      schema={schema}
    />
  );
}