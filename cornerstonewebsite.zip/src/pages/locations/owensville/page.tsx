import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Owensville IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/owensville',
  address: { '@type': 'PostalAddress', addressLocality: 'Owensville', addressRegion: 'IN', postalCode: '47665' },
  areaServed: { '@type': 'City', name: 'Owensville', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Owensville Indiana and Gibson County. Free inspections, storm damage repair, residential roofing for Owensville homeowners.',
};

export default function OwensvillePage() {
  return (
    <CityPage
      city="Owensville"
      state="Indiana"
      stateAbbr="IN"
      county="Gibson County"
      slug="owensville"
      population="1,300+"
      distance="25 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Owensville's trusted local roofing contractor. Corner Stone brings 25+ years of Tri-State roofing expertise to Gibson County's second-largest community — same fast response, same honest pricing."
      longDesc="Owensville sits right along SR 65, making it one of the most accessible Gibson County communities from our Evansville headquarters. Corner Stone Construction & Roofing provides Owensville homeowners with the full range of residential roofing services — from routine inspections and minor repairs to complete storm damage replacements. We know Gibson County building codes inside and out, and our crews are just a short drive down the highway."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims', 'Emergency Repairs']}
      neighborhoods={['Owensville Town Center', 'Gibson Southern School District', 'SR 65 Corridor', 'Owensville Community Park Area', 'Rural Gibson County Routes']}
      faqs={[
        { q: 'Do you serve Owensville Indiana for roofing?', a: 'Yes — Owensville and all of Gibson County are part of our active service territory. We provide the same fast response and quality workmanship as our core Evansville market.' },
        { q: 'How much does a roof replacement cost in Owensville IN?', a: 'Residential roof replacements in Owensville typically range from $7,500 to $20,000 depending on home size, pitch, and materials chosen. We offer free, no-obligation estimates.' },
        { q: 'How quickly can you respond to a roofing emergency in Owensville?', a: 'Owensville is about 25 miles from our Evansville headquarters via SR 65. We typically respond within 45-60 minutes for emergency calls in Gibson County.' },
        { q: 'Do you handle storm damage insurance claims in Gibson County?', a: 'Absolutely. We are insurance claim specialists — we document damage, meet with your adjuster, and handle all the paperwork so you get the full payout your policy covers.' },
      ]}
      schema={schema}
    />
  );
}