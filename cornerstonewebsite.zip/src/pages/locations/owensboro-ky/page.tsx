import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Owensboro KY',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/owensboro-ky',
  address: { '@type': 'PostalAddress', addressLocality: 'Owensboro', addressRegion: 'KY', postalCode: '42301' },
  areaServed: { '@type': 'City', name: 'Owensboro', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  description: 'Roofing contractor serving Owensboro Kentucky. Fully licensed in KY. Free inspections, storm damage, residential & commercial roofing in Daviess County.',
};

export default function OwensboroKYPage() {
  return (
    <CityPage
      city="Owensboro"
      state="Kentucky"
      stateAbbr="KY"
      county="Daviess County"
      slug="owensboro-ky"
      population="60,000+"
      distance="35 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Owensboro's trusted roofing contractor. Fully licensed in Kentucky, Corner Stone serves Daviess County with expert residential and commercial roofing, storm damage repair, and insurance claims."
      longDesc="Owensboro is our largest Kentucky market, and we're proud to serve Daviess County homeowners and businesses with the same quality that Evansville has trusted for 25+ years. We're fully licensed in Kentucky, know the local building codes, and have dedicated crews for the Owensboro area. From downtown historic homes to large commercial properties, Corner Stone delivers premium roofing at honest prices."
      services={['Residential Roofing', 'Commercial Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Flat Roofing / TPO', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims']}
      neighborhoods={['Owensboro Downtown', 'Smothers Park Area', 'East Owensboro', 'Wesleyan Park', 'Owensboro Medical Area', 'Frederica Street Corridor', 'Whitesville', 'Philpot']}
      faqs={[
        { q: 'Do you do roofing in Owensboro Kentucky?', a: 'Yes — Owensboro is one of our primary Kentucky markets. We have dedicated crews serving Daviess County and are fully licensed in Kentucky.' },
        { q: 'How much does a roof replacement cost in Owensboro KY?', a: 'Residential roof replacements in Owensboro typically range from $9,000 to $26,000 depending on size, pitch, and materials. Commercial projects vary. Free estimates available.' },
        { q: 'Do you handle commercial roofing in Owensboro?', a: 'Yes. We handle both residential and commercial roofing in Owensboro, including flat roofs, TPO membranes, and metal roofing for commercial properties.' },
        { q: 'Can you help with storm damage insurance claims in Owensboro?', a: 'Absolutely. We work with all major insurance carriers in Kentucky and handle the full claims process from documentation to final payout.' },
      ]}
      schema={schema}
    />
  );
}
