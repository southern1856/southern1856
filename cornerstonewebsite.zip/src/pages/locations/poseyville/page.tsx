import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Poseyville IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/poseyville',
  address: { '@type': 'PostalAddress', addressLocality: 'Poseyville', addressRegion: 'IN', postalCode: '47633' },
  areaServed: { '@type': 'City', name: 'Poseyville', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Poseyville Indiana. Free inspections, storm damage, residential & agricultural roofing in Posey County.',
};

export default function PoseyvillePage() {
  return (
    <CityPage
      city="Poseyville"
      state="Indiana"
      stateAbbr="IN"
      county="Posey County"
      slug="poseyville"
      population="1,000+"
      distance="25 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Poseyville's dependable roofing contractor. Corner Stone serves Posey County homeowners and farm properties with trusted roofing, storm repair, and metal roofing expertise."
      longDesc="Corner Stone Construction & Roofing is proud to serve Poseyville and the agricultural heart of Posey County. This rural community has a diverse mix of housing — from century-old farmhouses to modern family homes and everything in between. We understand the unique roofing needs of rural properties, including metal roofing for barns and outbuildings, wind-resistant shingles for exposed farmland locations, and comprehensive storm damage assessment for properties that take the full force of Indiana weather. Our crews are equally comfortable working on historic farmhouses, modern subdivisions, or large agricultural structures. We provide the same quality, transparency, and warranty protection to every Poseyville customer that has made us the most trusted name in Tri-State roofing."
      services={['Residential Roofing', 'Agricultural Roofing', 'Metal Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Barn & Shed Roofing']}
      neighborhoods={['Poseyville Downtown', 'Posey County North', 'Indiana 68 Corridor', 'Rural Posey County East', 'Rural Posey County West', 'Cynthiana Area', 'Wadesville Area', 'Savah Area']}
      faqs={[
        { q: 'Do you serve Poseyville Indiana for roofing?', a: 'Yes — we serve Poseyville and all of Posey County including rural and agricultural properties. Our crews are experienced with both residential and farm building roofing.' },
        { q: 'How much does a roof replacement cost in Poseyville IN?', a: 'Most residential roof replacements in Poseyville range from $7,500 to $18,000 depending on home size, roof pitch, and materials selected. Agricultural building roofing costs vary by structure size. We provide free estimates.' },
        { q: 'Do you install metal roofing on barns and farm buildings?', a: 'Yes — metal roofing is one of our specialties, and we regularly install standing seam and exposed fastener metal roofs on barns, sheds, shops, and agricultural buildings throughout Posey County.' },
        { q: 'How fast can you respond to emergencies in Poseyville?', a: 'Poseyville is approximately 25 miles from our Evansville headquarters. We typically respond within 45 to 75 minutes for emergency calls and offer 24/7 emergency tarping and repair services.' },
      ]}
      schema={schema}
    />
  );
}