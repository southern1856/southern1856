import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Mount Vernon IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/mount-vernon',
  address: { '@type': 'PostalAddress', addressLocality: 'Mount Vernon', addressRegion: 'IN', postalCode: '47620' },
  areaServed: { '@type': 'City', name: 'Mount Vernon', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Mount Vernon Indiana and Posey County. Free inspections, storm damage, residential & agricultural roofing.',
};

export default function MountVernonPage() {
  return (
    <CityPage
      city="Mount Vernon"
      state="Indiana"
      stateAbbr="IN"
      county="Posey County"
      slug="mount-vernon"
      population="6,900+"
      distance="25 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Mount Vernon and Posey County's trusted roofing contractor. Corner Stone serves residential homes, agricultural properties, and commercial buildings across all of Posey County — fast, honest, and backed by 25+ years of experience."
      longDesc="Corner Stone Construction & Roofing has been serving Mount Vernon and Posey County homeowners since 1995. We understand the unique roofing needs of this area — from historic homes in the Mount Vernon district to large agricultural properties and rural estates along the Ohio River. Our crews know the local building codes, work directly with Posey County permit offices, and deliver the same quality and reliability that Evansville has trusted for over two decades."
      services={['Residential Roofing', 'Roof Replacement', 'Agricultural Roofing', 'Metal Roofing', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims']}
      neighborhoods={['Mount Vernon Historic District', 'Hovey Lake Area', 'Posey County Courthouse Area', 'New Harmony', 'Poseyville', 'Wadesville', 'Griffin', 'Cynthiana']}
      faqs={[
        { q: 'Do you serve Mount Vernon Indiana for roofing?', a: 'Yes — we regularly serve Mount Vernon and all of Posey County. Our crews are familiar with local building codes and the Posey County permit office.' },
        { q: 'Do you do agricultural or barn roofing near Mount Vernon?', a: 'Absolutely. We handle agricultural roofing including metal barn roofs, large property estates, and rural outbuildings throughout Posey County.' },
        { q: 'How much does a roof replacement cost in Mount Vernon IN?', a: 'Most residential roofs in Mount Vernon range from $7,500 to $21,000 depending on size, pitch, and materials. Agricultural and metal roofing varies. Free estimates available.' },
        { q: 'Can you help with storm damage insurance claims in Posey County?', a: 'Yes. We document all damage, meet your insurance adjuster on-site, and handle all paperwork to maximize your payout — at no extra cost to you.' },
      ]}
      schema={schema}
    />
  );
}
