import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Huntingburg IN',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/huntingburg',
  address: { '@type': 'PostalAddress', addressLocality: 'Huntingburg', addressRegion: 'IN', postalCode: '47542' },
  areaServed: { '@type': 'City', name: 'Huntingburg', containedInPlace: { '@type': 'State', name: 'Indiana' } },
  description: 'Roofing contractor serving Huntingburg Indiana and Dubois County. Free inspections, storm damage repair, residential and commercial roofing for Huntingburg homeowners.',
};

export default function HuntingburgPage() {
  return (
    <CityPage
      city="Huntingburg"
      state="Indiana"
      stateAbbr="IN"
      county="Dubois County"
      slug="huntingburg"
      population="6,300+"
      distance="50 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Huntingburg and Dubois County's trusted roofing contractor. Corner Stone brings 25+ years of Tri-State roofing expertise to one of Dubois County's largest communities — same quality, same honest pricing."
      longDesc="Huntingburg is a thriving Dubois County city with a rich German heritage, a vibrant downtown historic district, and a growing residential base. Known for its film-famous League Stadium and annual events, Huntingburg homeowners need a roofing contractor who understands both historic preservation and modern building standards. Corner Stone Construction & Roofing delivers both — protecting Huntingburg homes with premium materials and workmanship backed by 25+ years of experience."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Roof Repair', 'Metal Roofing', 'Commercial Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims', 'Emergency Repairs']}
      neighborhoods={['Huntingburg Downtown Historic District', '4th Street Corridor', 'League Stadium Area', 'South Huntingburg', 'Old Town Huntingburg', 'Dubois County Rural Routes']}
      faqs={[
        { q: 'Do you serve Huntingburg Indiana for roofing?', a: 'Yes — Huntingburg and all of Dubois County are within our extended service territory. We provide the same quality workmanship and honest pricing that the Tri-State area has relied on since 1995.' },
        { q: 'How much does a roof replacement cost in Huntingburg IN?', a: 'Residential roof replacements in Huntingburg typically range from $8,500 to $24,000 depending on home size, roof complexity, and materials selected. Free, no-obligation estimates for all Dubois County homeowners.' },
        { q: 'How quickly can you respond to a roofing emergency in Huntingburg?', a: 'Huntingburg is about 50 miles from Evansville via I-64 and US 231. We typically respond within 75-90 minutes for emergency calls, and often faster when crews are already working in the Dubois County area.' },
        { q: 'Do you handle insurance claims for storm damage?', a: 'Absolutely. Our team handles the entire insurance claims process — from initial damage documentation and adjuster meetings to making sure you receive the complete payout your policy entitles you to.' },
        { q: 'Do you offer commercial roofing in Huntingburg?', a: 'Yes — we provide commercial roofing services for Huntingburg businesses, including the downtown historic district. Flat roofs, metal roofs, TPO, and full commercial replacements are all within our capabilities.' },
      ]}
      schema={schema}
    />
  );
}