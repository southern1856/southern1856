import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Greenville KY',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/greenville-ky',
  address: { '@type': 'PostalAddress', addressLocality: 'Greenville', addressRegion: 'KY', postalCode: '42345' },
  areaServed: { '@type': 'City', name: 'Greenville', containedInPlace: { '@type': 'State', name: 'Kentucky' } },
  description: 'Roofing contractor serving Greenville Kentucky. Free inspections, storm damage, residential & commercial roofing in Muhlenberg County. Fully licensed in KY.',
};

export default function GreenvilleKYPage() {
  return (
    <CityPage
      city="Greenville"
      state="Kentucky"
      stateAbbr="KY"
      county="Muhlenberg County"
      slug="greenville-ky"
      population="4,300+"
      distance="70 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Greenville Kentucky's trusted roofing contractor. Corner Stone is fully licensed in Kentucky and serves Muhlenberg County with expert roofing, storm damage repair, and emergency services."
      longDesc="Corner Stone Construction & Roofing is proud to serve Greenville and all of Muhlenberg County in Western Kentucky. We are fully licensed and insured in Kentucky, giving Greenville homeowners the confidence that their roofing project meets all state and local requirements. Muhlenberg County experiences a full range of weather conditions that test any roof — from severe spring thunderstorms and hail to heavy winter precipitation and strong winds across the rolling hills. Our experienced crews are equipped to handle everything from emergency leak repairs to complete roof replacements on homes, farms, and commercial properties. We also specialize in helping property owners navigate insurance claims after storm damage, working directly with Kentucky insurance adjusters to ensure fair coverage. When you choose Corner Stone, you get a contractor that combines small-town care with big-city expertise — backed by over 25 years of experience serving the Tri-State area."
      services={['Residential Roofing', 'Commercial Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Agricultural Roofing', 'Roof Maintenance']}
      neighborhoods={['Greenville Downtown', 'Muhlenberg County Courthouse Area', 'North Greenville', 'South Greenville', 'East Greenville', 'West Greenville', 'Central City Area', 'Drakesboro Area', 'Powderly Area', 'Rural Muhlenberg County Routes', 'Graham Area', 'South Carrollton Area']}
      faqs={[
        { q: 'Do you provide roofing services in Greenville Kentucky?', a: 'Yes — we are fully licensed in Kentucky and proudly serve Greenville and all of Muhlenberg County. Our KY crews deliver the same trusted quality as our Indiana operations.' },
        { q: 'How much does a roof replacement cost in Greenville KY?', a: 'Most residential roof replacements in Greenville range from $7,500 to $20,000 depending on home size, roof pitch, and materials selected. We always provide free estimates.' },
        { q: 'Can you help with Kentucky insurance claims for storm damage?', a: 'Yes — we are experienced with Kentucky insurance claim procedures. We document damage thoroughly, meet KY adjusters, and handle all paperwork to maximize your coverage.' },
        { q: 'How quickly can you respond to roofing emergencies in Greenville?', a: 'Greenville is approximately 70 miles from our Evansville base. For emergencies, we typically respond within 90 minutes to 2 hours and offer 24/7 emergency services.' },
        { q: 'Do you work on farm and agricultural buildings in Muhlenberg County?', a: 'Yes — we provide agricultural roofing services including metal barn roofs, pole building roofing, and farm structure repairs throughout Muhlenberg County.' },
      ]}
      schema={schema}
    />
  );
}