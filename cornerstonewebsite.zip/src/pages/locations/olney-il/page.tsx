import CityPage from '../CityPage';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'RoofingContractor',
  name: 'Corner Stone Construction & Roofing — Olney IL',
  telephone: '+1-812-213-5997',
  url: 'https://cornerstoneconstructionevansville.com/locations/olney-il',
  address: { '@type': 'PostalAddress', addressLocality: 'Olney', addressRegion: 'IL', postalCode: '62450' },
  areaServed: { '@type': 'City', name: 'Olney', containedInPlace: { '@type': 'State', name: 'Illinois' } },
  description: 'Roofing contractor serving Olney Illinois. Free inspections, storm damage repair, residential & commercial roofing in Richland County. Licensed & insured. Call 812-213-5997.',
};

export default function OlneyILPage() {
  return (
    <CityPage
      city="Olney"
      state="Illinois"
      stateAbbr="IL"
      county="Richland County"
      slug="olney-il"
      population="8,700+"
      distance="60 miles from Evansville"
      heroImage="/placeholders/1400x900.svg"
      teamImage="/placeholders/700x400.svg"
      description="Olney Illinois's trusted roofing contractor serving Richland County. Corner Stone delivers expert roofing, storm damage repair, and 24/7 emergency services to homes and businesses — including the white squirrel capital of the Midwest."
      longDesc="Corner Stone Construction &amp; Roofing brings 25+ years of Tri-State roofing expertise to Olney, the largest city in Richland County and a regional hub for southeastern Illinois. At about 60 miles from our Evansville headquarters, Olney is right at the edge of our extended service range — and we make the drive because Olney homeowners deserve the same quality workmanship as our core market. As a college town with Olney Central College, the city sees steady housing turnover — new buyers consistently need pre-purchase roof inspections, and aging rental properties near campus frequently require roof replacements. Olney also sits squarely in Illinois tornado alley, and Richland County has seen its share of severe weather events that leave roofs battered by wind and hail. From the historic homes encircling the courthouse square to the newer subdivisions on the south and east sides, and from the college-area rentals to the sprawling farmhouses on the county roads, our crews handle it all. We offer comprehensive roofing and exterior services: full tear-offs, architectural shingle upgrades, storm damage repair, metal roofing for agricultural buildings, siding and fascia replacement, seamless gutters, and 24/7 emergency tarping. Fully licensed and insured in Illinois with GAF Master Elite certification — Corner Stone brings the same honest pricing and craftsmanship that has made us the Tri-State's most trusted roofer."
      services={['Residential Roofing', 'Roof Replacement', 'Storm Damage Repair', 'Hail Damage', 'Wind Damage', 'Metal Roofing', 'Gutter Installation', 'Free Roof Inspection', 'Insurance Claims Assistance', 'Emergency Roof Repairs', 'Commercial Roofing', 'Siding & Fascia Repair']}
      neighborhoods={['Olney Downtown Courthouse Square', 'Olney Central College Area', 'Richland County Memorial Hospital Area', 'East Olney Subdivisions', 'South Olney Neighborhoods', 'West Olney Historic District', 'North Olney Residential', 'East Fork Fox River Corridor', 'Rural Richland County', 'Noble Area', 'Claremont Area', 'Calhoun Area']}
      faqs={[
        { q: 'Do you provide roofing services in Olney Illinois?', a: 'Yes — we proudly serve Olney and all of Richland County. Located about 60 miles from our Evansville base, we are at the edge of our extended range and make the drive regularly for both emergency calls and scheduled projects. We are fully licensed and insured in Illinois.' },
        { q: 'How much does a roof replacement cost in Olney IL?', a: 'Most residential roof replacements in Olney range from $9,000 to $25,000 depending on home size, roof pitch, and material selection. Larger homes near the college area or historic homes around the courthouse square tend toward the higher end. We provide free, no-obligation estimates.' },
        { q: 'Can you help with Illinois insurance claims for storm damage?', a: 'Absolutely. We have extensive experience with Illinois insurance claim procedures and will document all storm damage with detailed photos and measurements. We will meet your adjuster on-site and walk through every finding to maximize your coverage — at no extra cost to you.' },
        { q: 'How quickly can you respond to roofing emergencies in Olney?', a: 'Olney is about 60 miles from our Evansville base. For emergencies near downtown or the college area, we typically arrive within 70 to 80 minutes. For homes out on the rural routes toward Noble or Claremont, figure closer to 85 to 90 minutes. We offer 24/7 emergency tarping and board-up throughout Richland County.' },
        { q: 'Do you work on rental properties and multi-unit housing near Olney Central College?', a: 'Yes — we have significant experience with rental property roofing near Olney Central College and throughout Richland County. We understand the unique timeline pressures of tenant-occupied units and work efficiently to minimize disruption. We also handle pre-purchase roof inspections for investment properties.' },
      ]}
      schema={schema}
    />
  );
}