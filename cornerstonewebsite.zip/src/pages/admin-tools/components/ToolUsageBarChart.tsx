import { useMemo } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

interface ToolStat {
  tool_id: string;
  tool_name: string;
  usage_count: number;
}

const COLORS = ["#059669", "#0ea5e9", "#f59e0b", "#8b5cf6", "#ef4444"];

export default function ToolUsageBarChart({ stats, onToolClick }: { stats: ToolStat[]; onToolClick?: (toolId: string) => void }) {
  const sorted = useMemo(() => [...stats].sort((a, b) => b.usage_count - a.usage_count), [stats]);

  const data = useMemo(
    () =>
      sorted.map((s, i) => ({
        name: s.tool_name,
        uses: s.usage_count,
        toolId: s.tool_id,
        color: COLORS[i % COLORS.length],
      })),
    [sorted]
  );

  const handleBarClick = (entry: { toolId: string }) => {
    onToolClick?.(entry.toolId);
  };

  return (
    <div className="bg-white rounded-lg border border-gray-100 p-5">
      <h3 className="text-sm font-semibold text-gray-900 mb-4 flex items-center gap-2">
        <i className="ri-bar-chart-box-line text-gray-500" />
        Total Usage by Tool
      </h3>
      <div className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
            <XAxis
              dataKey="name"
              tick={{ fontSize: 12, fill: "#6b7280" }}
              axisLine={{ stroke: "#e5e7eb" }}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 12, fill: "#6b7280" }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#fff",
                border: "1px solid #e5e7eb",
                borderRadius: "8px",
                fontSize: "13px",
                color: "#111827",
              }}
              formatter={(value: number) => [value.toLocaleString(), "Uses"]}
            />
            <Bar dataKey="uses" radius={[6, 6, 0, 0]} onClick={handleBarClick}>
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} cursor={onToolClick ? "pointer" : "default"} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      {onToolClick && (
        <div className="mt-4 flex flex-wrap gap-2">
          {sorted.map((s) => (
            <button
              key={s.tool_id}
              onClick={() => onToolClick(s.tool_id)}
              className="text-xs font-medium text-sky-600 hover:text-sky-800 bg-sky-50 hover:bg-sky-100 px-2.5 py-1.5 rounded-md transition-colors"
            >
              {s.tool_name} detail →
            </button>
          ))}
        </div>
      )}
    </div>
  );
}