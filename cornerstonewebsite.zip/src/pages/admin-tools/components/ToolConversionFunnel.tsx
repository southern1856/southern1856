import { useMemo } from "react";

interface ConversionData {
  tool_id: string;
  tool_name: string;
  conversion_count: number;
  conversion_type: string;
}

interface ToolStat {
  tool_id: string;
  tool_name: string;
  usage_count: number;
}

interface Props {
  conversions: ConversionData[];
  stats: ToolStat[];
}

const TOOL_COLORS: Record<string, string> = {
  "roof-estimator": "bg-emerald-500",
  "ai-inspector": "bg-violet-500",
  "quote-comparison": "bg-amber-500",
  "financing-calculator": "bg-rose-500",
  "instant-scheduler": "bg-sky-500",
};

const TOOL_TEXT_COLORS: Record<string, string> = {
  "roof-estimator": "text-emerald-600",
  "ai-inspector": "text-violet-600",
  "quote-comparison": "text-amber-600",
  "financing-calculator": "text-rose-600",
  "instant-scheduler": "text-sky-600",
};

export default function ToolConversionFunnel({ conversions, stats }: Props) {
  // Aggregate conversions by tool
  const byTool = useMemo(() => {
    const map: Record<string, { tool_id: string; tool_name: string; conversions: number; types: Record<string, number> }> = {};
    conversions.forEach((c) => {
      if (!map[c.tool_id]) {
        map[c.tool_id] = {
          tool_id: c.tool_id,
          tool_name: c.tool_name,
          conversions: 0,
          types: {},
        };
      }
      map[c.tool_id].conversions += c.conversion_count;
      map[c.tool_id].types[c.conversion_type] = (map[c.tool_id].types[c.conversion_type] || 0) + c.conversion_count;
    });
    return map;
  }, [conversions]);

  // Build rows with usage + conversion data
  const rows = useMemo(() => {
    return stats
      .map((s) => {
        const conv = byTool[s.tool_id];
        const convCount = conv?.conversions || 0;
        const rate = s.usage_count > 0 ? Math.round((convCount / s.usage_count) * 1000) / 10 : 0;
        return {
          tool_id: s.tool_id,
          tool_name: s.tool_name,
          usage: s.usage_count,
          conversions: convCount,
          rate,
          types: conv?.types || {},
        };
      })
      .sort((a, b) => b.rate - a.rate);
  }, [stats, byTool]);

  const totalUsage = rows.reduce((a, b) => a + b.usage, 0);
  const totalConversions = rows.reduce((a, b) => a + b.conversions, 0);
  const avgRate = totalUsage > 0 ? Math.round((totalConversions / totalUsage) * 1000) / 10 : 0;

  const maxConversions = Math.max(...rows.map((r) => r.conversions), 1);

  return (
    <div className="bg-white rounded-lg border border-gray-100 p-5">
      <div className="flex items-start justify-between mb-5">
        <div>
          <h3 className="text-sm font-semibold text-gray-900 flex items-center gap-2">
            <i className="ri-filter-3-line text-gray-500" />
            Conversion Funnel
          </h3>
          <p className="text-xs text-gray-500 mt-0.5">
            % of tool users who convert (book inspection, submit form, request quote) within 30 min
          </p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-gray-900">{avgRate}%</p>
          <p className="text-xs text-gray-500">avg conversion rate</p>
        </div>
      </div>

      <div className="space-y-4">
        {rows.map((row) => {
          const barColor = TOOL_COLORS[row.tool_id] || "bg-gray-400";
          const textColor = TOOL_TEXT_COLORS[row.tool_id] || "text-gray-600";
          const usagePct = totalUsage > 0 ? (row.usage / totalUsage) * 100 : 0;
          const convPctOfMax = maxConversions > 0 ? (row.conversions / maxConversions) * 100 : 0;

          return (
            <div key={row.tool_id} className="group">
              <div className="flex items-center justify-between text-sm mb-1.5">
                <span className={`font-medium ${textColor}`}>{row.tool_name}</span>
                <div className="flex items-center gap-3">
                  <span className="text-xs text-gray-500">{row.usage.toLocaleString()} uses</span>
                  <span className="text-xs font-semibold text-gray-900 bg-gray-100 px-2 py-0.5 rounded-full">
                    {row.rate}%
                  </span>
                </div>
              </div>

              {/* Funnel visualization */}
              <div className="relative h-8 bg-gray-50 rounded-md overflow-hidden">
                {/* Usage bar (wider, lighter) */}
                <div
                  className="absolute top-0 left-0 h-full bg-gray-200 rounded-md"
                  style={{ width: `${usagePct}%` }}
                />
                {/* Conversion bar (narrower, colored) */}
                <div
                  className={`absolute top-0 left-0 h-full ${barColor} rounded-md opacity-80`}
                  style={{ width: `${(usagePct * row.rate) / 100}%` }}
                />
                {/* Conversion count label */}
                <div className="absolute inset-0 flex items-center justify-end pr-2">
                  <span className="text-xs font-medium text-gray-700">
                    {row.conversions} conversion{row.conversions !== 1 ? "s" : ""}
                  </span>
                </div>
              </div>

              {/* Conversion type breakdown */}
              {Object.keys(row.types).length > 0 && (
                <div className="flex items-center gap-2 mt-1 ml-0.5">
                  {Object.entries(row.types).map(([type, count]) => (
                    <span key={type} className="text-[10px] text-gray-400 capitalize">
                      {type.replace(/_/g, " ")}: {count}
                    </span>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Legend */}
      <div className="mt-5 pt-4 border-t border-gray-100 flex items-center gap-4 text-xs text-gray-500">
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 bg-gray-200 rounded-sm" />
          <span>Total tool uses</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 bg-gray-400 rounded-sm" />
          <span>Attributed conversions</span>
        </div>
      </div>
    </div>
  );
}