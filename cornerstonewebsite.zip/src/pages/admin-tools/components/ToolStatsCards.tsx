import { useMemo } from "react";

interface ToolStat {
  tool_id: string;
  tool_name: string;
  usage_count: number;
  last_used_at: string | null;
}

interface ToolStatsCardsProps {
  stats: ToolStat[];
  todayCount: number;
}

export default function ToolStatsCards({ stats, todayCount }: ToolStatsCardsProps) {
  const total = useMemo(() => stats.reduce((s, t) => s + t.usage_count, 0), [stats]);
  const top = useMemo(() => (stats.length > 0 ? stats[0] : null), [stats]);

  const activeTools = stats.filter((s) => s.usage_count > 0).length;

  const cards = [
    {
      label: "Total Tool Uses",
      value: total.toLocaleString(),
      icon: "ri-bar-chart-grouped-line",
      color: "bg-emerald-50 text-emerald-700",
      trend: "All time",
    },
    {
      label: "Top Tool",
      value: top?.tool_name ?? "—",
      icon: "ri-trophy-line",
      color: "bg-amber-50 text-amber-700",
      trend: top ? `${top.usage_count.toLocaleString()} uses` : "",
    },
    {
      label: "Uses Today",
      value: todayCount.toLocaleString(),
      icon: "ri-calendar-check-line",
      color: "bg-sky-50 text-sky-700",
      trend: "Last 24 hours",
    },
    {
      label: "Active Tools",
      value: `${activeTools} / ${stats.length}`,
      icon: "ri-tools-line",
      color: "bg-violet-50 text-violet-700",
      trend: "With recorded usage",
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {cards.map((card) => (
        <div key={card.label} className="bg-white rounded-lg border border-gray-100 p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className={`w-8 h-8 rounded-md flex items-center justify-center ${card.color}`}>
              <i className={`${card.icon} text-lg`} />
            </div>
          </div>
          <div className="text-2xl font-bold text-gray-900">{card.value}</div>
          <div className="text-xs text-gray-500 mt-0.5">{card.label}</div>
          {card.trend && <div className="text-xs text-gray-400 mt-0.5">{card.trend}</div>}
        </div>
      ))}
    </div>
  );
}