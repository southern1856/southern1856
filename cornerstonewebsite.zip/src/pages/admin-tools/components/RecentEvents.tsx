interface EventRow {
  id: number;
  tool_name: string;
  used_at: string;
}

export default function RecentEvents({ events, loading }: { events: EventRow[]; loading: boolean }) {
  const formatTime = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
    });
  };

  return (
    <div className="bg-white rounded-lg border border-gray-100 p-5">
      <h3 className="text-sm font-semibold text-gray-900 mb-4 flex items-center gap-2">
        <i className="ri-history-line text-gray-500" />
        Recent Activity
      </h3>
      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="flex items-center gap-3 animate-pulse">
              <div className="w-8 h-8 rounded-full bg-gray-100" />
              <div className="flex-1 space-y-1">
                <div className="h-3 bg-gray-100 rounded w-3/4" />
                <div className="h-2 bg-gray-100 rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      ) : events.length === 0 ? (
        <p className="text-sm text-gray-500">No recent activity recorded.</p>
      ) : (
        <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
          {events.map((e) => (
            <div key={e.id} className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 mt-0.5">
                <i className="ri-tools-fill text-sm" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">{e.tool_name}</p>
                <p className="text-xs text-gray-500">{formatTime(e.used_at)}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}