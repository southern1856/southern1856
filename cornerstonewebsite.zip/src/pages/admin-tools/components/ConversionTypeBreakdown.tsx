import { useMemo } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

interface ConversionData {
  conversion_type: string;
  conversion_count: number;
}

interface Props {
  conversions: ConversionData[];
}

const TYPE_LABELS: Record<string, string> = {
  inspection_booking: "Inspection Booking",
  contact_form: "Contact Form",
  quote_request: "Quote Request",
  financing_application: "Financing App",
};

const TYPE_COLORS: Record<string, string> = {
  inspection_booking: "#0ea5e9",
  contact_form: "#10b981",
  quote_request: "#f59e0b",
  financing_application: "#f43f5e",
};

export default function ConversionTypeBreakdown({ conversions }: Props) {
  const data = useMemo(() => {
    return conversions.map((c) => ({
      type: TYPE_LABELS[c.conversion_type] || c.conversion_type.replace(/_/g, " "),
      count: c.conversion_count,
      color: TYPE_COLORS[c.conversion_type] || "#9ca3af",
    }));
  }, [conversions]);

  const total = useMemo(
    () => conversions.reduce((a, b) => a + b.conversion_count, 0),
    [conversions]
  );

  if (data.length === 0) {
    return (
      <div className="bg-white rounded-lg border border-gray-100 p-5">
        <h3 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
          <i className="ri-pie-chart-line text-gray-500" />
          Conversion Types
        </h3>
        <p className="text-sm text-gray-500">No conversion data yet.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-gray-100 p-5">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-sm font-semibold text-gray-900 flex items-center gap-2">
            <i className="ri-pie-chart-line text-gray-500" />
            Conversion Types
          </h3>
          <p className="text-xs text-gray-500 mt-0.5">What actions users take after using tools</p>
        </div>
        <p className="text-xl font-bold text-gray-900">{total}</p>
      </div>

      <div className="h-48">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical" margin={{ top: 0, right: 20, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f3f4f6" />
            <XAxis type="number" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis
              type="category"
              dataKey="type"
              tick={{ fontSize: 12 }}
              width={120}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip
              contentStyle={{
                borderRadius: "8px",
                border: "1px solid #e5e7eb",
                fontSize: "13px",
              }}
              formatter={(value: number) => [`${value} conversions`, ""]}
            />
            <Bar dataKey="count" radius={[0, 4, 4, 0]} fill="#0ea5e9" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}