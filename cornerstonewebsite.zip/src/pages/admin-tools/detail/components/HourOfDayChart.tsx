import { useMemo } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

interface HourData {
  hour: string;
  count: number;
  label: string;
}

export default function HourOfDayChart({ events }: { events: { used_at: string }[] }) {
  const data: HourData[] = useMemo(() => {
    const counts = new Array(24).fill(0);
    events.forEach((e) => {
      const h = new Date(e.used_at).getHours();
      counts[h]++;
    });
    return counts.map((count, i) => ({
      hour: String(i).padStart(2, "0"),
      count,
      label: i === 0 ? "12am" : i < 12 ? `${i}am` : i === 12 ? "12pm" : `${i - 12}pm`,
    }));
  }, [events]);

  const maxCount = useMemo(() => Math.max(...data.map((d) => d.count), 1), [data]);

  return (
    <div className="bg-white rounded-lg border border-gray-100 p-5">
      <h3 className="text-sm font-semibold text-gray-900 mb-1 flex items-center gap-2">
        <i className="ri-time-line text-gray-500" />
        Usage by Hour of Day
      </h3>
      <p className="text-xs text-gray-500 mb-4">When during the day this tool gets the most engagement</p>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
            <XAxis
              dataKey="label"
              tick={{ fontSize: 10, fill: "#9ca3af" }}
              axisLine={{ stroke: "#e5e7eb" }}
              tickLine={false}
              interval={2}
            />
            <YAxis
              tick={{ fontSize: 11, fill: "#6b7280" }}
              axisLine={false}
              tickLine={false}
              allowDecimals={false}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#fff",
                border: "1px solid #e5e7eb",
                borderRadius: "8px",
                fontSize: "13px",
                color: "#111827",
              }}
              formatter={(value: number) => [`${value} uses`, "Count"]}
              labelFormatter={(label: string) => `${label}`}
            />
            <Bar
              dataKey="count"
              fill="#0ea5e9"
              radius={[4, 4, 0, 0]}
              maxBarSize={28}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-3 flex items-center justify-between text-xs text-gray-500">
        <span>Peak hour: {data.reduce((a, b) => (b.count > a.count ? b : a), data[0])?.label}</span>
        <span>{events.length} events analyzed</span>
      </div>
    </div>
  );
}