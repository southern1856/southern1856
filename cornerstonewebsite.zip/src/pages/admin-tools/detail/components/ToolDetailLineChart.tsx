import { useMemo } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

interface TrendPoint {
  date: string;
  count: number;
  displayDate: string;
}

export default function ToolDetailLineChart({
  events,
  toolName,
}: {
  events: { used_at: string }[];
  toolName: string;
}) {
  const data: TrendPoint[] = useMemo(() => {
    if (events.length === 0) return [];

    // Build daily buckets
    const byDay: Record<string, number> = {};
    const dates: string[] = [];

    // Find min and max dates
    let minDate = new Date(events[0].used_at);
    let maxDate = new Date(events[0].used_at);
    events.forEach((e) => {
      const d = new Date(e.used_at);
      if (d < minDate) minDate = d;
      if (d > maxDate) maxDate = d;
    });

    // Initialize all days in range
    const curr = new Date(minDate);
    while (curr <= maxDate) {
      const key = curr.toISOString().split("T")[0];
      byDay[key] = 0;
      dates.push(key);
      curr.setDate(curr.getDate() + 1);
    }

    events.forEach((e) => {
      const day = e.used_at.split("T")[0];
      byDay[day] = (byDay[day] || 0) + 1;
    });

    return dates.map((date) => {
      const d = new Date(date);
      return {
        date,
        count: byDay[date] || 0,
        displayDate: `${d.getMonth() + 1}/${d.getDate()}`,
      };
    });
  }, [events]);

  const avgDaily = useMemo(() => {
    if (data.length === 0) return 0;
    return Math.round(data.reduce((a, b) => a + b.count, 0) / data.length);
  }, [data]);

  return (
    <div className="bg-white rounded-lg border border-gray-100 p-5">
      <div className="flex items-center justify-between mb-1">
        <h3 className="text-sm font-semibold text-gray-900 flex items-center gap-2">
          <i className="ri-line-chart-line text-gray-500" />
          Daily Usage Trend — {toolName}
        </h3>
        <span className="text-xs text-gray-400">
          Avg {avgDaily}/day
        </span>
      </div>
      <p className="text-xs text-gray-500 mb-4">Day-by-day activity for this tool over the selected period</p>
      <div className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
            <XAxis
              dataKey="displayDate"
              tick={{ fontSize: 11, fill: "#6b7280" }}
              axisLine={{ stroke: "#e5e7eb" }}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 12, fill: "#6b7280" }}
              axisLine={false}
              tickLine={false}
              allowDecimals={false}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#fff",
                border: "1px solid #e5e7eb",
                borderRadius: "8px",
                fontSize: "13px",
                color: "#111827",
              }}
              formatter={(value: number) => [`${value} uses`, toolName]}
              labelFormatter={(label: string) => `Date: ${label}`}
            />
            <Area
              type="monotone"
              dataKey="count"
              stroke="#0ea5e9"
              fill="#0ea5e9"
              fillOpacity={0.12}
              strokeWidth={2}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}