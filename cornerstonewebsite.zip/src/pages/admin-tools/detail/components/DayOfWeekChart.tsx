import { useMemo } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const DAY_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

interface DayData {
  day: string;
  count: number;
  full: string;
}

export default function DayOfWeekChart({ events }: { events: { used_at: string }[] }) {
  const data: DayData[] = useMemo(() => {
    const counts = new Array(7).fill(0);
    events.forEach((e) => {
      const d = new Date(e.used_at).getDay();
      counts[d]++;
    });
    const fullNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    return counts.map((count, i) => ({
      day: DAY_LABELS[i],
      count,
      full: fullNames[i],
    }));
  }, [events]);

  const maxCount = useMemo(() => Math.max(...data.map((d) => d.count), 1), [data]);

  return (
    <div className="bg-white rounded-lg border border-gray-100 p-5">
      <h3 className="text-sm font-semibold text-gray-900 mb-1 flex items-center gap-2">
        <i className="ri-calendar-line text-gray-500" />
        Usage by Day of Week
      </h3>
      <p className="text-xs text-gray-500 mb-4">Which days see the most activity for this tool</p>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" vertical={false} />
            <XAxis
              dataKey="day"
              tick={{ fontSize: 12, fill: "#6b7280" }}
              axisLine={{ stroke: "#e5e7eb" }}
              tickLine={false}
            />
            <YAxis
              tick={{ fontSize: 11, fill: "#6b7280" }}
              axisLine={false}
              tickLine={false}
              allowDecimals={false}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#fff",
                border: "1px solid #e5e7eb",
                borderRadius: "8px",
                fontSize: "13px",
                color: "#111827",
              }}
              formatter={(value: number, _name: string, props: { payload: DayData }) => [`${value} uses`, props.payload.full]}
            />
            <Bar
              dataKey="count"
              fill="#059669"
              radius={[4, 4, 0, 0]}
              maxBarSize={40}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-3 flex items-center justify-between text-xs text-gray-500">
        <span>Busiest day: {data.reduce((a, b) => (b.count > a.count ? b : a), data[0])?.full}</span>
        <span>{events.length} events analyzed</span>
      </div>
    </div>
  );
}