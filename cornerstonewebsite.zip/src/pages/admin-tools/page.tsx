import { useState, useEffect, useMemo, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabase";
import AdminWatermark from "@/components/feature/AdminWatermark";
import ToolStatsCards from "./components/ToolStatsCards";
import ToolUsageBarChart from "./components/ToolUsageBarChart";
import ToolDailyTrendChart from "./components/ToolDailyTrendChart";
import RecentEvents from "./components/RecentEvents";
import ToolConversionFunnel from "./components/ToolConversionFunnel";
import ConversionTypeBreakdown from "./components/ConversionTypeBreakdown";

interface ToolStat {
  tool_id: string;
  tool_name: string;
  usage_count: number;
  last_used_at: string | null;
}

interface ToolEvent {
  id: number;
  tool_id: string;
  tool_name: string;
  used_at: string;
}

interface ConversionRow {
  tool_id: string;
  tool_name: string;
  conversion_type: string;
  conversion_count: number;
}

type Period = "7d" | "30d" | "all";

export default function AdminTools() {
  const [stats, setStats] = useState<ToolStat[]>([]);
  const [events, setEvents] = useState<ToolEvent[]>([]);
  const [conversions, setConversions] = useState<ConversionRow[]>([]);
  const [dailyTrend, setDailyTrend] = useState<Record<string, Record<string, number>>>();
  const [todayCount, setTodayCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [period, setPeriod] = useState<Period>("30d");
  const navigate = useNavigate();

  const fetchData = useCallback(async (selectedPeriod: Period = period) => {
    try {
      setRefreshing(true);

      // Fetch cumulative stats
      const { data: statsData, error: statsError } = await supabase
        .from("tool_usage_stats")
        .select("tool_id, tool_name, usage_count, last_used_at")
        .order("usage_count", { ascending: false });

      if (statsError) throw statsError;
      setStats(statsData || []);

      // Fetch recent events for activity feed
      const { data: recentEvents, error: eventsError } = await supabase
        .from("tool_usage_events")
        .select("id, tool_id, tool_name, used_at")
        .order("used_at", { ascending: false })
        .limit(50);

      if (eventsError) throw eventsError;
      setEvents(recentEvents || []);

      // Fetch conversions by tool and type
      const { data: convData, error: convError } = await supabase
        .from("tool_conversions")
        .select("tool_id, tool_name, conversion_type");

      if (convError) throw convError;
      // Aggregate conversions
      const convAgg: Record<string, ConversionRow> = {};
      (convData || []).forEach((c) => {
        const key = `${c.tool_id || 'organic'}-${c.conversion_type}`;
        if (!convAgg[key]) {
          convAgg[key] = {
            tool_id: c.tool_id || 'organic',
            tool_name: c.tool_name || 'Organic',
            conversion_type: c.conversion_type,
            conversion_count: 0,
          };
        }
        convAgg[key].conversion_count += 1;
      });
      setConversions(Object.values(convAgg));

      // Determine date range based on period
      let query = supabase
        .from("tool_usage_events")
        .select("tool_name, used_at")
        .order("used_at", { ascending: true });

      let daysBack = 30;
      if (selectedPeriod === "7d") daysBack = 7;
      else if (selectedPeriod === "all") daysBack = 0; // no limit

      if (daysBack > 0) {
        const cutoff = new Date();
        cutoff.setDate(cutoff.getDate() - daysBack);
        query = query.gte("used_at", cutoff.toISOString());
      }

      const { data: trendEvents, error: trendError } = await query;
      if (trendError) throw trendError;

      // Build date bucket index
      const byDay: Record<string, Record<string, number>> = {};
      const todayIso = new Date().toISOString().split("T")[0];
      let today = 0;

      if (daysBack > 0) {
        // Initialize all days in range with zeros
        for (let i = daysBack - 1; i >= 0; i--) {
          const d = new Date();
          d.setDate(d.getDate() - i);
          const key = d.toISOString().split("T")[0];
          byDay[key] = {};
        }
      }

      (trendEvents || []).forEach((e) => {
        const day = e.used_at.split("T")[0];
        if (!byDay[day]) byDay[day] = {};
        byDay[day][e.tool_name] = (byDay[day][e.tool_name] || 0) + 1;
        if (day === todayIso) today++;
      });

      setDailyTrend(byDay);
      setTodayCount(today);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load tool analytics");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [period]);

  useEffect(() => {
    fetchData("30d");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Re-fetch when period changes
  useEffect(() => {
    if (!loading) {
      fetchData(period);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [period]);

  // Build daily trend chart data
  const dailyChartData = useMemo(() => {
    const toolNames = Array.from(new Set(stats.map((s) => s.tool_name)));
    const days = Object.keys(dailyTrend || {}).sort();
    return days.map((day) => {
      const row: Record<string, string | number> = { date: day };
      toolNames.forEach((name) => {
        row[name] = dailyTrend?.[day]?.[name] || 0;
      });
      return row;
    });
  }, [dailyTrend, stats]);

  const toolNames = useMemo(
    () => Array.from(new Set(stats.map((s) => s.tool_name))),
    [stats]
  );

  const handleExport = () => {
    const csv = [
      ["Tool ID", "Tool Name", "Usage Count", "Last Used At"].join(","),
      ...stats.map((s) =>
        [s.tool_id, `"${s.tool_name}"`, s.usage_count, s.last_used_at ?? ""].join(",")
      ),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `tool-usage-stats-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const periodOptions: { key: Period; label: string }[] = [
    { key: "7d", label: "Last 7 Days" },
    { key: "30d", label: "Last 30 Days" },
    { key: "all", label: "All Time" },
  ];

  const handleToolClick = (toolId: string) => {
    navigate(`/admin/tools/${toolId}`);
  };

  // Compute aggregate conversion metrics for top stats
  const totalConversions = useMemo(
    () => conversions.reduce((a, b) => a + b.conversion_count, 0),
    [conversions]
  );
  const attributedConversions = useMemo(
    () => conversions.filter((c) => c.tool_id !== "organic").reduce((a, b) => a + b.conversion_count, 0),
    [conversions]
  );
  const totalUsage = useMemo(
    () => stats.reduce((a, b) => a + b.usage_count, 0),
    [stats]
  );
  const overallRate = useMemo(
    () => (totalUsage > 0 ? Math.round((attributedConversions / totalUsage) * 1000) / 10 : 0),
    [totalUsage, attributedConversions]
  );
  const topConvertingTool = useMemo(() => {
    let best: { tool_name: string; rate: number } | null = null;
    stats.forEach((s) => {
      const conv = conversions
        .filter((c) => c.tool_id === s.tool_id)
        .reduce((a, b) => a + b.conversion_count, 0);
      const rate = s.usage_count > 0 ? (conv / s.usage_count) * 100 : 0;
      if (!best || rate > best.rate) {
        best = { tool_name: s.tool_name, rate: Math.round(rate * 10) / 10 };
      }
    });
    return best;
  }, [stats, conversions]);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-sky-600 text-white flex items-center justify-center">
              <i className="ri-bar-chart-grouped-line text-xl" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900">Tool Usage Analytics</h1>
              <p className="text-xs text-gray-500">Track engagement and conversion attribution across all 5 interactive tools</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigate("/admin/alex-conversations")}
              className="hidden md:flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-600 bg-gray-50 border border-gray-200 rounded-md hover:bg-gray-100 transition-colors"
            >
              <i className="ri-chat-3-line" />
              Alex Conversations
            </button>
            <button
              onClick={() => fetchData(period)}
              disabled={refreshing}
              className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-200 rounded-md hover:bg-gray-50 transition-colors disabled:opacity-50"
            >
              <i className={`ri-refresh-line ${refreshing ? "animate-spin" : ""}`} />
              Refresh
            </button>
            <button
              onClick={handleExport}
              className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-white bg-sky-600 rounded-md hover:bg-sky-700 transition-colors"
            >
              <i className="ri-download-2-line" />
              Export CSV
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-6 space-y-6">
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-sm text-red-700 flex items-center gap-2">
            <i className="ri-error-warning-line" />
            {error}
          </div>
        )}

        {loading ? (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 animate-pulse">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="bg-white rounded-lg border border-gray-100 p-4 h-28" />
              ))}
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-white rounded-lg border border-gray-100 p-5 h-80 animate-pulse" />
              <div className="bg-white rounded-lg border border-gray-100 p-5 h-80 animate-pulse" />
            </div>
            <div className="bg-white rounded-lg border border-gray-100 p-5 h-96 animate-pulse" />
          </div>
        ) : (
          <>
            <ToolStatsCards stats={stats} todayCount={todayCount} />

            {/* Conversion summary row */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                {
                  label: "Total Conversions",
                  value: totalConversions.toLocaleString(),
                  icon: "ri-hand-coin-line",
                  accent: "bg-emerald-50 text-emerald-600",
                  desc: "All attributed + organic",
                },
                {
                  label: "Tool-Attributed",
                  value: attributedConversions.toLocaleString(),
                  icon: "ri-link-m",
                  accent: "bg-sky-50 text-sky-600",
                  desc: "Within 30 min of tool use",
                },
                {
                  label: "Overall Conv. Rate",
                  value: `${overallRate}%`,
                  icon: "ri-percent-line",
                  accent: "bg-amber-50 text-amber-600",
                  desc: "Attributed / total uses",
                },
                {
                  label: "Top Converter",
                  value: topConvertingTool?.tool_name ?? "—",
                  icon: "ri-trophy-line",
                  accent: "bg-violet-50 text-violet-600",
                  desc: topConvertingTool ? `${topConvertingTool.rate}% rate` : "No data",
                  small: true,
                },
              ].map((card) => (
                <div key={card.label} className="bg-white rounded-lg border border-gray-100 p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`w-7 h-7 rounded-md ${card.accent} flex items-center justify-center`}>
                      <i className={`${card.icon} text-sm`} />
                    </div>
                    <span className="text-xs font-medium text-gray-500">{card.label}</span>
                  </div>
                  <p className={`text-lg font-bold text-gray-900 ${card.small ? "text-sm" : ""}`}>{card.value}</p>
                  <p className="text-[10px] text-gray-400 mt-0.5">{card.desc}</p>
                </div>
              ))}
            </div>

            {/* Quick-link tool cards */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {stats.map((s) => (
                <button
                  key={s.tool_id}
                  onClick={() => handleToolClick(s.tool_id)}
                  className="text-left bg-white rounded-lg border border-gray-100 p-3 hover:border-sky-300 hover:shadow-sm transition-all group"
                >
                  <p className="text-xs font-medium text-gray-500 group-hover:text-sky-600 transition-colors">{s.tool_name}</p>
                  <p className="text-lg font-bold text-gray-900 mt-0.5">{s.usage_count.toLocaleString()}</p>
                  <p className="text-xs text-gray-400 mt-0.5">View detail →</p>
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <ToolUsageBarChart stats={stats} onToolClick={handleToolClick} />
              </div>
              <RecentEvents events={events} loading={false} />
            </div>

            {/* Conversion Funnel Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <ToolConversionFunnel conversions={conversions} stats={stats} />
              </div>
              <ConversionTypeBreakdown
                conversions={conversions.filter((c) => c.tool_id !== "organic")}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-4">
                {/* Period Toggle */}
                <div className="bg-white rounded-lg border border-gray-100 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-semibold text-gray-900">Trend Period</h3>
                    <p className="text-xs text-gray-500">Switch the date range for the daily usage trend</p>
                  </div>
                  <div className="flex items-center bg-gray-100 rounded-full p-1 gap-0.5">
                    {periodOptions.map((opt) => (
                      <button
                        key={opt.key}
                        onClick={() => setPeriod(opt.key)}
                        className={`px-3 py-1.5 text-xs font-medium rounded-full transition-all ${
                          period === opt.key
                            ? "bg-white text-gray-900 shadow-sm"
                            : "text-gray-500 hover:text-gray-700"
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {dailyChartData.length > 0 && (
                  <ToolDailyTrendChart data={dailyChartData} toolNames={toolNames} period={period} />
                )}
              </div>
              <div className="bg-white rounded-lg border border-gray-100 p-5">
                <h3 className="text-sm font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <i className="ri-list-check-2 text-gray-500" />
                  Tool Breakdown
                </h3>
                <div className="space-y-3">
                  {stats.map((s, i) => {
                    const total = stats.reduce((a, b) => a + b.usage_count, 0);
                    const pct = total > 0 ? Math.round((s.usage_count / total) * 100) : 0;
                    const colors = ["bg-emerald-500", "bg-sky-500", "bg-amber-500", "bg-violet-500", "bg-rose-500"];
                    return (
                      <button
                        key={s.tool_id}
                        onClick={() => handleToolClick(s.tool_id)}
                        className="w-full text-left group"
                      >
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span className="font-medium text-gray-900 group-hover:text-sky-600 transition-colors">{s.tool_name}</span>
                          <span className="text-gray-500">{s.usage_count.toLocaleString()} ({pct}%)</span>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${colors[i % colors.length]} group-hover:opacity-80 transition-opacity`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </button>
                    );
                  })}
                </div>
                <div className="mt-5 pt-4 border-t border-gray-100">
                  <p className="text-xs text-gray-500">
                    Data updates in real-time as visitors interact with tools across your site. Click any tool name above for a detailed drill-down.
                  </p>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
      <AdminWatermark />
    </div>
  );
}