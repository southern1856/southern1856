import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import MostUsedToolBadge from '@/components/feature/MostUsedToolBadge';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { useToolUsage } from '@/hooks/useToolUsage';

/* ─── Types ─── */
interface ToolDef {
  id: string;
  label: string;
  shortLabel: string;
  icon: string;
  route: string;
  badge: string;
  headline: string;
  description: string;
  features: string[];
  statLabel: string;
  statValue: string;
  previewImage: string;
  bgClass: string;
}

/* ─── Tool Data ─── */
const TOOLS: ToolDef[] = [
  {
    id: 'roof-estimator',
    label: 'Roof Cost Estimator',
    shortLabel: 'Cost Estimator',
    icon: 'ri-calculator-line',
    route: '/roof-estimator',
    badge: 'Most Popular',
    headline: 'Know Your Roof Replacement Cost in 60 Seconds',
    description:
      'Enter your home size, roof pitch, stories, material choice, and features. Get a personalized Evansville-area price range backed by real 2026 local invoices — not vague national averages.',
    features: [
      '6 cost factors: size, pitch, stories, material, tear-off, features',
      'Based on real Tri-State 2026 pricing data',
      'Compare asphalt, metal, tile, and slate side-by-side',
      'No email or phone required — 100% anonymous',
    ],
    statLabel: 'Avg. Time to Complete',
    statValue: '45 sec',
    previewImage:
      '/placeholders/700x450.svg',
    bgClass: 'bg-warm-beige',
  },
  {
    id: 'ai-inspector',
    label: 'AI Roof Inspector',
    shortLabel: 'AI Inspector',
    icon: 'ri-robot-2-line',
    route: '/ai-inspector',
    badge: 'AI-Powered',
    headline: 'Upload a Photo. Get an Instant Damage Report.',
    description:
      'Snap a photo of your roof from the ground and our AI analyzes shingle condition, flashing, hail damage, granule loss, and more. Free, anonymous, and available 24/7.',
    features: [
      'Detects hail impact, granule loss, curling, and flashing issues',
      'Works with ground-level smartphone photos',
      'Severity ratings and actionable next steps',
      'No account or contact info required',
    ],
    statLabel: 'Analysis Time',
    statValue: '< 30 sec',
    previewImage:
      '/placeholders/700x450.svg',
    bgClass: 'bg-white',
  },
  {
    id: 'quote-comparison',
    label: 'Quote Comparison',
    shortLabel: 'Compare Quotes',
    icon: 'ri-scales-3-line',
    route: '/quote-comparison',
    badge: 'AI Scoring',
    headline: 'Compare Up to 4 Quotes. Let AI Pick the Winner.',
    description:
      'Paste in roofing estimates from different contractors and our AI engine scores each on price, materials, warranty coverage, scope completeness, and contractor credibility. Red flags auto-detected.',
    features: [
      '5-dimension AI scoring (0–100 per quote)',
      'Auto-detects illegal deposits, missing insurance, bait-and-switch',
      'Side-by-side comparison matrix',
      '100% private — no data leaves your browser',
    ],
    statLabel: 'Red Flags Caught',
    statValue: '12 types',
    previewImage:
      '/placeholders/700x450.svg',
    bgClass: 'bg-warm-beige',
  },
  {
    id: 'financing-calculator',
    label: 'Financing Calculator',
    shortLabel: 'Financing Calc',
    icon: 'ri-bank-card-line',
    route: '/financing-calculator',
    badge: '3-in-1 Suite',
    headline: 'Monthly Payment, Affordability & Cash vs. Finance',
    description:
      'Three powerful calculators in one: estimate your monthly payment, work backwards from your budget to find your max project size, and see the exact dollar difference between paying cash and financing.',
    features: [
      'Monthly payment calculator with credit tiers and terms',
      'Reverse affordability: enter budget → get max project size',
      'Cash vs. financing comparison with AI recommendation',
      'No credit check, no personal info required',
    ],
    statLabel: 'Calculator Tools',
    statValue: '3-in-1',
    previewImage:
      '/placeholders/700x450.svg',
    bgClass: 'bg-white',
  },
  {
    id: 'instant-scheduler',
    label: 'Instant Scheduler',
    shortLabel: 'Scheduler',
    icon: 'ri-calendar-check-line',
    route: '/instant-scheduler',
    badge: 'Book Now',
    headline: 'Book Your Appointment in Under 60 Seconds',
    description:
      'Skip the phone tag. Pick your service, choose a date and time from our live calendar, and lock in your appointment. Our crew calls 30 minutes before arrival.',
    features: [
      '6 service types: inspection, repair, replacement, gutters, siding, emergency',
      '3-week calendar with real-time availability',
      'Weather-aware booking tips',
      'Instant confirmation text and email',
    ],
    statLabel: 'Booking Time',
    statValue: '< 60 sec',
    previewImage:
      '/placeholders/700x450.svg',
    bgClass: 'bg-warm-beige',
  },
];

/* ─── Side Nav ─── */
function SideNav({ activeId, onNavigate }: { activeId: string; onNavigate: (id: string) => void }) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      {/* Mobile toggle */}
      <button
        onClick={() => setMobileOpen(!mobileOpen)}
        className="lg:hidden fixed top-24 right-4 z-50 w-12 h-12 bg-charcoal-deep border border-white/10 flex items-center justify-center text-white cursor-pointer"
        aria-label="Toggle tools navigation"
      >
        <i className={`${mobileOpen ? 'ri-close-line' : 'ri-menu-4-line'} text-lg`} />
      </button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Nav panel */}
      <nav
        className={`fixed lg:sticky lg:top-28 z-40 lg:z-0 transition-transform duration-300 ${
          mobileOpen ? 'translate-x-0' : 'translate-x-full'
        } lg:translate-x-0 right-0 lg:right-auto w-72 lg:w-full h-[calc(100vh-6rem)] lg:h-auto bg-charcoal-deep lg:bg-transparent border-l lg:border-0 border-white/10 overflow-y-auto`}
      >
        <div className="p-5 lg:p-0">
          <p className="text-charcoal-mid/30 text-[10px] font-semibold uppercase tracking-[0.2em] mb-3 hidden lg:block">
            Jump to Tool
          </p>
          <ul className="space-y-1">
            {TOOLS.map((tool) => (
              <li key={tool.id}>
                <button
                  onClick={() => {
                    onNavigate(tool.id);
                    setMobileOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 text-left text-xs font-medium uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                    activeId === tool.id
                      ? 'bg-orange/10 border-l-2 border-orange text-orange'
                      : 'text-white/40 hover:text-white/70 hover:bg-white/5 border-l-2 border-transparent'
                  }`}
                >
                  <span className="w-6 h-6 flex items-center justify-center flex-shrink-0">
                    <i className={tool.icon} />
                  </span>
                  <span className="hidden lg:inline">{tool.shortLabel}</span>
                  <span className="lg:hidden">{tool.label}</span>
                </button>
              </li>
            ))}
          </ul>

          {/* Mobile CTA */}
          <div className="lg:hidden mt-6 pt-6 border-t border-white/10 px-3">
            <p className="text-white/30 text-xs mb-3">Need help choosing?</p>
            <button
              onClick={() => {
                window.dispatchEvent(new CustomEvent('open-chat'));
                setMobileOpen(false);
              }}
              className="w-full bg-orange text-white text-xs font-semibold uppercase tracking-widest py-3 flex items-center justify-center gap-2 cursor-pointer"
            >
              <i className="ri-robot-2-line" />
              Ask Alex
            </button>
          </div>
        </div>
      </nav>
    </>
  );
}

function formatCount(n: number): string {
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
  return String(n);
}

/* ─── Tool Section ─── */
function ToolSection({
  tool,
  isReversed,
  index,
  usageStats,
  isMostUsed,
}: {
  tool: ToolDef;
  isReversed: boolean;
  index: number;
  usageStats: { tool_id: string; usage_count: number }[];
  isMostUsed: boolean;
}) {
  const navigate = useNavigate();
  const anim = useScrollAnimation({ threshold: 0.08 });
  const sectionRef = useRef<HTMLDivElement>(null);
  const toolStat = usageStats.find((s) => s.tool_id === tool.id);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            // dispatch event for parent to pick up active section
            window.dispatchEvent(
              new CustomEvent('tools-section-visible', { detail: { id: tool.id } })
            );
          }
        });
      },
      { threshold: 0.4 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [tool.id]);

  return (
    <div
      ref={sectionRef}
      id={tool.id}
      className={`scroll-mt-28 ${tool.bgClass}`}
    >
      <div
        ref={anim.ref as React.RefObject<HTMLDivElement>}
        className={`anim-fade-up ${anim.isVisible ? 'is-visible' : ''} max-w-6xl mx-auto px-6 md:px-10 lg:px-16 py-16 md:py-24`}
      >
        {/* Badge + Label */}
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <span className="text-orange text-xs font-semibold uppercase tracking-[0.2em] border border-orange/30 bg-orange/5 px-3 py-1">
            {isMostUsed ? 'Most Popular' : tool.badge}
          </span>
          <span className="text-charcoal-mid/30 text-xs uppercase tracking-widest font-medium">
            Tool {String(index + 1).padStart(2, '0')} of 05
          </span>
          {toolStat && toolStat.usage_count > 0 && (
            <span className="text-charcoal-mid/40 text-[10px] font-medium uppercase tracking-wider flex items-center gap-1">
              <i className="ri-fire-line text-orange text-[10px]" />
              {formatCount(toolStat.usage_count)} uses
            </span>
          )}
        </div>

        {/* Headline */}
        <h2 className="font-display text-charcoal-deep text-2xl md:text-3xl lg:text-4xl uppercase tracking-wider leading-tight mb-4 max-w-2xl">
          {tool.headline}
        </h2>
        <p className="text-charcoal-mid/50 text-sm md:text-base leading-relaxed mb-8 max-w-xl">
          {tool.description}
        </p>

        <div
          className={`grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center ${
            isReversed ? 'lg:[direction:rtl]' : ''
          }`}
        >
          {/* Content */}
          <div className={`${isReversed ? 'lg:[direction:ltr]' : ''}`}>
            <div className="space-y-4 mb-8">
              {tool.features.map((feat) => (
                <div key={feat} className="flex items-start gap-3">
                  <div className="w-5 h-5 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <i className="ri-check-line text-orange text-sm" />
                  </div>
                  <p className="text-charcoal-mid/60 text-sm leading-relaxed">{feat}</p>
                </div>
              ))}
            </div>

            {/* Stat + CTA */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <div className="border border-charcoal/10 bg-white/50 px-5 py-3 text-center sm:text-left">
                <p className="font-display text-charcoal-deep text-xl uppercase tracking-wider">
                  {tool.statValue}
                </p>
                <p className="text-charcoal-mid/30 text-[10px] uppercase tracking-widest font-semibold">
                  {tool.statLabel}
                </p>
              </div>
              <button
                onClick={() => navigate(tool.route)}
                className="flex-1 bg-charcoal-deep hover:bg-charcoal-mid text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
              >
                <i className={tool.icon} />
                Launch {tool.label}
                <i className="ri-arrow-right-line" />
              </button>
            </div>
          </div>

          {/* Preview Image */}
          <div className={`${isReversed ? 'lg:[direction:ltr]' : ''}`}>
            <div className="relative border border-charcoal/10 overflow-hidden group cursor-pointer" onClick={() => navigate(tool.route)}>
              <div className="w-full" style={{ paddingBottom: '64%' }}>
                <img
                  src={tool.previewImage}
                  alt={`${tool.label} preview`}
                  className="absolute inset-0 w-full h-full object-cover object-top group-hover:scale-[1.02] transition-transform duration-500"
                />
              </div>
              <div className="absolute inset-0 bg-charcoal-deep/0 group-hover:bg-charcoal-deep/20 transition-colors duration-300 flex items-center justify-center">
                <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-orange text-white px-5 py-2.5 text-xs font-semibold uppercase tracking-widest flex items-center gap-2">
                  <i className="ri-external-link-line" />
                  Open Tool
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── Main Page ─── */
export default function ToolsLandingPage() {
  const navigate = useNavigate();
  const heroAnim = useScrollAnimation({ threshold: 0.08 });
  const [activeSection, setActiveSection] = useState('roof-estimator');
  const { stats, mostUsed } = useToolUsage();

  const handleNav = useCallback((id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, []);

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail?.id) setActiveSection(detail.id);
    };
    window.addEventListener('tools-section-visible', handler);
    return () => window.removeEventListener('tools-section-visible', handler);
  }, []);

  const schema = [
    {
      '@context': 'https://schema.org',
      '@type': 'WebPage',
      name: 'Free Roofing Tools & Calculators | Corner Stone Roofing Evansville',
      description:
        'Free interactive roofing tools for Evansville homeowners: roof cost estimator, AI roof inspector, quote comparison, financing calculator, and instant appointment scheduler. No signup required.',
    },
    {
      '@context': 'https://schema.org',
      '@type': 'ItemList',
      itemListElement: TOOLS.map((tool, i) => ({
        '@type': 'ListItem',
        position: i + 1,
        name: tool.label,
        url: `https://cornerstoneconstructionevansville.com${tool.route}`,
      })),
    },
  ];

  return (
    <>
      <PageSEO
        title="Free Roofing Tools & Calculators | Roof Estimator, AI Inspector, Financing | Corner Stone"
        description="5 free interactive tools for Evansville homeowners: roof cost estimator, AI damage inspector, quote comparison, financing calculator, and instant scheduler. No signup, no spam — just honest answers."
        keywords="free roof cost calculator, roofing quote comparison tool, roof financing calculator, AI roof inspection, schedule roof inspection online, Evansville roofing tools"
        canonical="/tools"
        schema={schema}
      />

      {/* ── Hero ── */}
      <section className="bg-charcoal-deep pt-28 pb-16 md:pt-36 md:pb-24 px-6 md:px-10 lg:px-16">
        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''} max-w-5xl mx-auto text-center`}
        >
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">
            5 Free Interactive Tools
          </p>
          <h1
            className="font-display text-white uppercase tracking-wider leading-none mb-6"
            style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}
          >
            Roofing Tools That
            <br />
            <span className="text-orange">Actually Help</span>
          </h1>
          <p className="text-white/50 text-sm md:text-base max-w-2xl mx-auto leading-relaxed mb-10">
            No gimmicks, no lead-capture walls, no "enter your email to see results." Just five
            powerful tools that give you real answers — whether you are budgeting, comparing
            contractors, or ready to book.
          </p>

          <div className="flex items-center justify-center mb-8">
            <MostUsedToolBadge />
          </div>

          {/* Quick stat strip */}
          <div className="flex flex-wrap items-center justify-center gap-6 md:gap-10">
            {[
              { value: '5', label: 'Free Tools' },
              { value: '0', label: 'Cost to Use' },
              { value: '$0', label: 'Spam Sent' },
              { value: '24/7', label: 'Available' },
            ].map((s) => (
              <div key={s.label} className="text-center">
                <p className="font-display text-white text-2xl md:text-3xl uppercase tracking-wider">
                  {s.value}
                </p>
                <p className="text-white/30 text-[10px] uppercase tracking-widest font-semibold mt-1">
                  {s.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Main Layout: Side Nav + Content ── */}
      <div className="max-w-7xl mx-auto px-6 md:px-10 lg:px-16">
        <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
          {/* Left: Content */}
          <div className="flex-1 min-w-0">
            {TOOLS.map((tool, i) => (
              <ToolSection
                key={tool.id}
                tool={tool}
                isReversed={i % 2 === 1}
                index={i}
                usageStats={stats}
                isMostUsed={mostUsed?.tool_id === tool.id}
              />
            ))}
          </div>

          {/* Right: Sticky Side Nav */}
          <aside className="lg:w-56 xl:w-64 flex-shrink-0 hidden lg:block">
            <div className="sticky top-28">
              <SideNav activeId={activeSection} onNavigate={handleNav} />

              {/* Mini CTA card */}
              <div className="mt-6 border border-white/10 bg-charcoal-mid p-5">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 flex items-center justify-center bg-orange/15 flex-shrink-0">
                    <i className="ri-robot-2-line text-orange text-sm" />
                  </div>
                  <span className="text-white text-xs font-semibold uppercase tracking-wider">
                    Not Sure Which Tool?
                  </span>
                </div>
                <p className="text-white/30 text-xs leading-relaxed mb-4">
                  Tell Alex what you need — he will point you to the right tool and walk you through it.
                </p>
                <button
                  onClick={() => window.dispatchEvent(new CustomEvent('open-chat'))}
                  className="w-full border border-orange/30 text-orange text-xs font-semibold uppercase tracking-widest py-2.5 hover:bg-orange hover:text-white transition-colors cursor-pointer flex items-center justify-center gap-2"
                >
                  <i className="ri-chat-1-line" />
                  Ask Alex
                </button>
              </div>
            </div>
          </aside>
        </div>
      </div>

      {/* ── Mobile: floating side nav (visible on small screens only) ── */}
      <div className="lg:hidden">
        <SideNav activeId={activeSection} onNavigate={handleNav} />
      </div>

      {/* ── Bottom CTA ── */}
      <section className="bg-charcoal-deep py-16 md:py-24 px-6 md:px-10 lg:px-16 border-t border-white/5">
        <div className="max-w-3xl mx-auto text-center">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">
            Ready for a Real Quote?
          </p>
          <h2 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wider mb-4">
            Tools Give Estimates. We Give Exact Numbers.
          </h2>
          <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8 max-w-xl mx-auto">
            Our free 45-minute inspection includes a written, line-item quote. No pressure, no obligation, no surprise fees. Serving Evansville, Newburgh, Henderson KY, and the entire Tri-State.
          </p>
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3">
            <button
              onClick={() => navigate('/free-inspection')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
            >
              <i className="ri-calendar-check-line" />
              Book Free Inspection
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/20 hover:border-orange text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              Call 812-213-5997
            </a>
          </div>
        </div>
      </section>

      {/* ── Alex AI Strip ── */}
      <TalkToAIExpert />
    </>
  );
}