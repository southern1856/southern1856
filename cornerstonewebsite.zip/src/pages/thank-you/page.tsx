import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function ThankYou() {
  const navigate = useNavigate();

  useEffect(() => {
    // Fire GA4 conversion event
    if (typeof window !== 'undefined' && (window as unknown as Record<string, unknown>).gtag) {
      (window as unknown as Record<string, (...args: unknown[]) => void>).gtag('event', 'conversion', {
        event_category: 'form',
        event_label: 'thank_you_page',
      });
    }
  }, []);

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <main className="flex-1 flex items-center justify-center px-6 py-32">
        <div className="max-w-2xl w-full text-center">
          {/* Icon */}
          <div className="w-20 h-20 flex items-center justify-center bg-orange/10 rounded-full mx-auto mb-8">
            <i className="ri-checkbox-circle-line text-orange text-4xl" />
          </div>

          {/* Heading */}
          <h1 className="font-display text-charcoal-deep uppercase tracking-wider text-4xl md:text-5xl mb-4">
            Thank You!
          </h1>
          <p className="text-gray-500 text-lg mb-2 font-medium">
            We received your message.
          </p>
          <p className="text-gray-400 text-base leading-relaxed mb-10 max-w-md mx-auto">
            A member of our Evansville roofing team will be in touch within <strong className="text-charcoal-deep">1 business day</strong>. For urgent needs, call us directly.
          </p>

          {/* Call CTA */}
          <a
            href="tel:8122135997"
            className="inline-flex items-center gap-3 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap mb-4"
          >
            <i className="ri-phone-line text-lg" />
            Call 812-213-5997
          </a>

          <div className="mt-6">
            <button
              onClick={() => navigate('/')}
              className="text-gray-400 text-sm hover:text-orange transition-colors cursor-pointer underline underline-offset-4"
            >
              Back to Homepage
            </button>
          </div>

          {/* Trust signals */}
          <div className="mt-14 grid grid-cols-1 sm:grid-cols-3 gap-6 border-t border-gray-100 pt-10">
            {[
              { icon: 'ri-shield-check-line', label: 'Licensed & Insured', sub: 'Indiana & Kentucky' },
              { icon: 'ri-star-fill', label: '4.9 Star Rating', sub: '287+ Google Reviews' },
              { icon: 'ri-time-line', label: 'Fast Response', sub: 'Within 1 Business Day' },
            ].map((item) => (
              <div key={item.label} className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 flex items-center justify-center">
                  <i className={`${item.icon} text-orange text-2xl`} />
                </div>
                <p className="text-charcoal-deep font-semibold text-sm">{item.label}</p>
                <p className="text-gray-400 text-xs">{item.sub}</p>
              </div>
            ))}
          </div>

          {/* Email signature-style branded block */}
          <div className="mt-14 border-t border-gray-100 pt-10">
            <div className="inline-flex flex-col sm:flex-row items-center gap-4 sm:gap-6 bg-gray-50 border border-gray-100 rounded-xl px-6 py-5">
              <div className="flex items-center justify-center h-14 w-14 bg-charcoal-deep rounded-lg shrink-0">
                <img
                  src="/logo.svg"
                  alt="Corner Stone Construction & Roofing"
                  className="h-10 w-10 object-contain rounded"
                />
              </div>
              <div className="text-center sm:text-left leading-tight">
                <p className="font-display text-charcoal-deep text-lg tracking-wider uppercase">
                  Corner Stone
                </p>
                <p className="text-gray-400 text-[0.65rem] tracking-[0.2em] uppercase font-medium">
                  Construction & Roofing — Evansville, IN
                </p>
                <div className="flex items-center justify-center sm:justify-start gap-3 mt-2">
                  <a href="tel:8122135997" className="text-gray-500 hover:text-orange text-xs transition-colors flex items-center gap-1">
                    <i className="ri-phone-line text-orange text-xs" />
                    812-213-5997
                  </a>
                  <span className="text-gray-300">|</span>
                  <a href="mailto:themainstoneconstruction@gmail.com" className="text-gray-500 hover:text-orange text-xs transition-colors flex items-center gap-1">
                    <i className="ri-mail-line text-orange text-xs" />
                    Email Us
                  </a>
                </div>
              </div>
              <div className="hidden sm:block w-px h-10 bg-gray-200" />
              <div className="hidden sm:flex flex-col items-center gap-1 text-center">
                <div className="flex items-center gap-1">
                  {[1,2,3,4,5].map((s) => (
                    <i key={s} className="ri-star-fill text-orange text-xs" />
                  ))}
                </div>
                <p className="text-gray-400 text-[0.6rem] uppercase tracking-wider">287+ Reviews</p>
              </div>
            </div>
          </div>

          {/* ── CONFIRMATION EMAIL TEMPLATE PREVIEW ── */}
          <div className="mt-14 border-t border-gray-100 pt-10 text-left">
            <p className="text-center text-gray-400 text-xs uppercase tracking-[0.2em] font-semibold mb-6">
              Here's What Your Confirmation Email Looks Like
            </p>

            <div className="mx-auto max-w-lg bg-white border border-gray-200 shadow-lg rounded-lg overflow-hidden">
              {/* Email header */}
              <div className="bg-charcoal-deep px-5 py-4 flex items-center gap-3">
                <div className="w-8 h-8 flex items-center justify-center bg-white rounded-md shrink-0">
                  <img
                    src="/logo.svg"
                    alt="Corner Stone"
                    className="h-5 w-5 object-contain rounded"
                  />
                </div>
                <div>
                  <p className="font-display text-white text-sm tracking-wider uppercase leading-tight">
                    Corner Stone
                  </p>
                  <p className="text-white/40 text-[10px] uppercase tracking-widest">
                    Construction & Roofing
                  </p>
                </div>
                <div className="ml-auto text-right">
                  <p className="text-white/30 text-[10px] uppercase tracking-wider">
                    Evansville, IN
                  </p>
                </div>
              </div>

              {/* Email body */}
              <div className="px-5 py-6">
                <p className="text-charcoal-deep text-base font-semibold mb-1">
                  Hi there,
                </p>
                <p className="text-gray-500 text-sm leading-relaxed mb-4">
                  Thanks for reaching out to <strong className="text-charcoal-deep">Corner Stone Construction & Roofing</strong>. We've received your message and a member of our Evansville team will contact you within <strong className="text-charcoal-deep">1 business day</strong>.
                </p>

                <div className="bg-orange/5 border-l-4 border-orange rounded-r-lg p-4 mb-4">
                  <p className="text-orange text-xs uppercase tracking-widest font-semibold mb-2">
                    What Happens Next
                  </p>
                  <ul className="space-y-2">
                    {[
                      'Our team reviews your request within 2 hours',
                      'A project manager calls to schedule your free inspection',
                      'You receive a detailed photo report within 24 hours',
                    ].map((step, i) => (
                      <li key={i} className="flex items-start gap-2 text-gray-600 text-xs">
                        <span className="text-orange font-bold shrink-0">{i + 1}.</span>
                        {step}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-gray-50 rounded-lg p-4 mb-4">
                  <p className="text-gray-400 text-[10px] uppercase tracking-widest font-semibold mb-2">
                    Your Contact Info
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-gray-600">
                    <p><span className="text-gray-400">Name:</span> <strong>[Submitted Name]</strong></p>
                    <p><span className="text-gray-400">Email:</span> <strong>[Submitted Email]</strong></p>
                    <p><span className="text-gray-400">Phone:</span> <strong>[Submitted Phone]</strong></p>
                    <p><span className="text-gray-400">Service:</span> <strong>[Selected Service]</strong></p>
                  </div>
                </div>

                <div className="flex items-center gap-3 border-t border-gray-100 pt-4">
                  <a
                    href="tel:8122135997"
                    className="inline-flex items-center gap-2 bg-orange hover:bg-orange-dark text-white text-xs font-semibold px-5 py-2.5 uppercase tracking-widest transition-colors whitespace-nowrap"
                  >
                    <i className="ri-phone-line" />
                    Call 812-213-5997
                  </a>
                  <p className="text-gray-400 text-xs">
                    For urgent roofing emergencies, call us directly.
                  </p>
                </div>
              </div>

              {/* Email footer */}
              <div className="bg-gray-50 px-5 py-4 border-t border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 flex items-center justify-center bg-orange">
                    <i className="ri-shield-check-line text-white text-[10px]" />
                  </div>
                  <p className="text-charcoal-deep text-[10px] font-semibold uppercase tracking-wider">
                    Licensed & Insured — IN & KY
                  </p>
                </div>
                <div className="flex items-center gap-1">
                  {[1,2,3,4,5].map((s) => (
                    <i key={s} className="ri-star-fill text-orange text-[10px]" />
                  ))}
                  <span className="text-charcoal-deep text-[10px] font-semibold ml-1">4.9 — 287+ Reviews</span>
                </div>
              </div>
            </div>

            <p className="text-center text-gray-300 text-xs mt-4">
              This is a preview of the branded confirmation email sent automatically after form submission.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}