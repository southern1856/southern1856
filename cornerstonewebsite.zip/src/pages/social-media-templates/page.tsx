import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import PageSEO from '@/components/feature/PageSEO';

interface Template {
  id: string;
  title: string;
  category: string;
  body: string;
  hashtags: string;
  cta: string;
}

const templates: Template[] = [
  {
    id: 'project-spotlight-1',
    title: 'Project Spotlight — Architectural Shingle Replacement',
    category: 'Project Spotlight',
    body: 'Just wrapped a full architectural shingle replacement on Oak Street in Evansville. 2,400 sq ft, GAF Timberline HDZ in Pewter Gray. Homeowner loves the curb appeal upgrade.',
    hashtags: '#EvansvilleRoofing #NewRoof #GAF #BeforeAndAfter',
    cta: 'Swipe for the before →',
  },
  {
    id: 'project-spotlight-2',
    title: 'Project Spotlight — Metal Roof Install',
    category: 'Project Spotlight',
    body: 'Standing seam metal roof complete in Newburgh. This homeowner wanted 50+ years of protection and a modern look. Mission accomplished.',
    hashtags: '#MetalRoofing #NewburghIN #StandingSeam #RoofingContractor',
    cta: 'DM us for a free metal roofing estimate',
  },
  {
    id: 'storm-alert-1',
    title: 'Storm Alert — Hail Damage Response',
    category: 'Storm Alert',
    body: 'Severe hail reported in Henderson County tonight. If your roof took a hit, we offer free damage inspections with same-day photo reports. No obligation, no pressure.',
    hashtags: '#StormDamage #HailDamage #FreeInspection #HendersonKY',
    cta: 'Call 812-213-5997 or tap the link in bio',
  },
  {
    id: 'storm-alert-2',
    title: 'Storm Alert — Wind Damage Checklist',
    category: 'Storm Alert',
    body: '60 mph winds just rolled through the Tri-State. Here are the 5 signs your roof may have taken damage — even if everything looks fine from the ground.',
    hashtags: '#WindDamage #RoofInspection #Evansville #StormPrep',
    cta: 'Save this post and check your roof tomorrow',
  },
  {
    id: 'limited-offer-1',
    title: 'Limited Offer — Free Gutter Cleaning',
    category: 'Limited Offer',
    body: 'Book your roof replacement in May and get a free gutter cleaning ($450 value). Valid for Evansville and Newburgh residents. 6 spots available.',
    hashtags: '#RoofReplacement #FreeGutterCleaning #EvansvilleDeals #LimitedTime',
    cta: 'Call 812-213-5997 to reserve your spot',
  },
  {
    id: 'limited-offer-2',
    title: 'Limited Offer — Storm Season Prep',
    category: 'Limited Offer',
    body: 'Storm season is here. Schedule a free roof health check and we will throw in a gutter inspection at no charge. Catch small problems before they become expensive ones.',
    hashtags: '#StormPrep #FreeInspection #RoofMaintenance #Evansville',
    cta: 'Link in bio to book online',
  },
  {
    id: 'testimonial-1',
    title: 'Customer Testimonial — Quick Turnaround',
    category: 'Customer Testimonial',
    body: '"Corner Stone replaced our entire roof in two days. The crew was professional, cleaned everything, and the new roof looks incredible." — Jennifer M., Newburgh',
    hashtags: '#CustomerReview #NewburghIN #RoofReplacement #FiveStars',
    cta: 'See more reviews on Google',
  },
  {
    id: 'testimonial-2',
    title: 'Customer Testimonial — Insurance Claim Help',
    category: 'Customer Testimonial',
    body: '"After the hail storm, Corner Stone handled everything — the inspection, the insurance paperwork, and the full replacement. We did not lift a finger." — David R., Evansville',
    hashtags: '#InsuranceClaim #HailDamage #Evansville #StressFree',
    cta: 'We work with ALL insurance companies',
  },
  {
    id: 'educational-1',
    title: 'Educational — Ice Dam Prevention',
    category: 'Educational Tip',
    body: 'Ice dams are forming across the Tri-State. Here is what causes them and how proper attic ventilation prevents thousands in damage.',
    hashtags: '#IceDams #RoofTips #HomeMaintenance #WinterPrep',
    cta: 'Tag a homeowner who needs to see this',
  },
  {
    id: 'educational-2',
    title: 'Educational — Roof Lifespan by Material',
    category: 'Educational Tip',
    body: 'How long does a roof actually last in Indiana? Here is the real breakdown by material — not the marketing numbers, the actual numbers we see in the field.',
    hashtags: '#RoofLifespan #IndianaWeather #RoofingFacts #HomeownerTips',
    cta: 'Read the full guide on our blog',
  },
  {
    id: 'community-1',
    title: 'Community — Little League Sponsor',
    category: 'Community Involvement',
    body: 'Proud to sponsor the Evansville Little League opening day. Supporting the community that supports us. Go Knights!',
    hashtags: '#CommunityFirst #Evansville #LittleLeague #LocalBusiness',
    cta: 'We are always looking for new community partnerships',
  },
  {
    id: 'community-2',
    title: 'Community — Habitat for Humanity',
    category: 'Community Involvement',
    body: 'Our crew spent Saturday roofing the latest Habitat for Humanity build in Vanderburgh County. Every family deserves a dry, safe home.',
    hashtags: '#HabitatForHumanity #GiveBack #VanderburghCounty #RoofingWithPurpose',
    cta: 'Want to volunteer? DM us',
  },
  {
    id: 'behind-scenes-1',
    title: 'Behind the Scenes — Morning Huddle',
    category: 'Behind the Scenes',
    body: '6:30 AM crew huddle. Safety briefing, weather check, job assignments, and one bad coffee joke. This is how we start every day.',
    hashtags: '#RoofingCrew #SafetyFirst #BehindTheScenes #TeamWork',
    cta: 'We are hiring experienced roofers — apply online',
  },
  {
    id: 'behind-scenes-2',
    title: 'Behind the Scenes — Material Delivery',
    category: 'Behind the Scenes',
    body: '3,200 sq ft of GAF Timberline HDZ shingles just hit the job site. Color: Charcoal. Location: Henderson, KY. Installation starts at 7 AM.',
    hashtags: '#GAF #TimberlineHDZ #HendersonKY #RoofingLife',
    cta: 'Follow for daily job site updates',
  },
];

const categories = ['All', 'Project Spotlight', 'Storm Alert', 'Limited Offer', 'Customer Testimonial', 'Educational Tip', 'Community Involvement', 'Behind the Scenes'];

export default function SocialMediaTemplatesPage() {
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState('All');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const heroAnim = useScrollAnimation();
  const contentAnim = useScrollAnimation();

  const filtered = activeCategory === 'All'
    ? templates
    : templates.filter((t) => t.category === activeCategory);

  const handleCopy = (template: Template) => {
    const fullText = `${template.body}\n\n${template.hashtags}\n\n${template.cta}`;
    navigator.clipboard.writeText(fullText).then(() => {
      setCopiedId(template.id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  const schema = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: 'Social Media Post Templates for Roofing Contractors',
    description: 'Ready-to-post social media templates for roofing contractors. Copy, paste, and publish on Google Business Profile, Facebook, and Instagram.',
    url: 'https://cornerstoneconstructionevansville.com/social-media-templates',
    mainEntity: {
      '@type': 'ItemList',
      itemListElement: templates.map((t, i) => ({
        '@type': 'ListItem',
        position: i + 1,
        name: t.title,
      })),
    },
  };

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Social Media Post Templates for Roofing Contractors | Corner Stone"
        description="14 ready-to-post social media templates for roofing contractors. Project spotlights, storm alerts, testimonials, offers, and community posts. Copy and publish in seconds."
        keywords="roofing social media templates, contractor social media, GBP post templates, roofing marketing, Facebook posts for roofers, Instagram captions roofing"
        canonical="/social-media-templates"
        schema={schema}
      />

      {/* Hero */}
      <section className="relative min-h-[50vh] flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1200x500.svg"
            alt="Social media marketing for roofing contractors"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-charcoal-deep via-black/70 to-black/40" />
        </div>
        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 pb-14 md:pb-20 anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-wrap items-center gap-3 mb-5">
            <span className="bg-orange text-white text-xs font-semibold px-3 py-1.5 uppercase tracking-wider">
              Free Resource
            </span>
            <span className="text-white/30 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <i className="ri-time-line" />
              14 Templates
            </span>
          </div>
          <h1 className="font-display text-white uppercase tracking-wider leading-tight max-w-4xl" style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}>
            Social Media Post Templates for Roofing Contractors
          </h1>
          <p className="text-white/50 text-base md:text-lg mt-5 max-w-2xl leading-relaxed">
            Copy, paste, and publish. 14 ready-made posts for Google Business Profile, Facebook, and Instagram. No writer's block, no guessing — just consistent content that drives calls.
          </p>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-8 md:py-10 px-6 md:px-10 lg:px-16 border-b border-white/5">
        <div className="flex flex-wrap gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 text-xs uppercase tracking-wider font-semibold transition-all cursor-pointer whitespace-nowrap ${
                activeCategory === cat
                  ? 'bg-orange text-white'
                  : 'bg-charcoal-mid text-white/40 hover:text-white hover:bg-charcoal-mid/80 border border-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </section>

      {/* Templates Grid */}
      <section className="py-12 md:py-16 px-6 md:px-10 lg:px-16">
        <div
          ref={contentAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${contentAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filtered.map((template) => (
              <div
                key={template.id}
                className="bg-charcoal-mid border border-white/5 p-6 md:p-7 group hover:border-orange/20 transition-all duration-300"
              >
                <div className="flex items-center gap-2 mb-4">
                  <span className="bg-orange/15 text-orange text-[10px] uppercase tracking-wider font-semibold px-2.5 py-1">
                    {template.category}
                  </span>
                </div>

                <h3 className="font-display text-white text-sm md:text-base uppercase tracking-wider mb-5">
                  {template.title}
                </h3>

                <div className="space-y-4 mb-6">
                  <div>
                    <p className="text-white/30 text-[10px] uppercase tracking-wider font-semibold mb-1.5">Post Body</p>
                    <p className="text-white/70 text-sm leading-relaxed bg-black/20 p-3 rounded">
                      {template.body}
                    </p>
                  </div>
                  <div>
                    <p className="text-white/30 text-[10px] uppercase tracking-wider font-semibold mb-1.5">Hashtags</p>
                    <p className="text-orange/70 text-xs">{template.hashtags}</p>
                  </div>
                  <div>
                    <p className="text-white/30 text-[10px] uppercase tracking-wider font-semibold mb-1.5">Call to Action</p>
                    <p className="text-white/50 text-sm italic">{template.cta}</p>
                  </div>
                </div>

                <button
                  onClick={() => handleCopy(template)}
                  className={`w-full flex items-center justify-center gap-2 font-semibold px-5 py-3 uppercase tracking-wide text-xs transition-all cursor-pointer ${
                    copiedId === template.id
                      ? 'bg-green-600/20 text-green-400 border border-green-600/30'
                      : 'bg-orange hover:bg-orange-dark text-white'
                  }`}
                >
                  {copiedId === template.id ? (
                    <>
                      <i className="ri-check-line" />
                      Copied to Clipboard
                    </>
                  ) : (
                    <>
                      <i className="ri-file-copy-line" />
                      Copy Full Post
                    </>
                  )}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tips Section */}
      <section className="py-12 md:py-16 px-6 md:px-10 lg:px-16 border-t border-white/5">
        <div className="max-w-3xl">
          <h2 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider mb-8">
            How to Use These Templates
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 flex items-center justify-center bg-orange/15 flex-shrink-0">
                <span className="text-orange text-sm font-bold">1</span>
              </div>
              <div>
                <p className="text-white text-sm font-semibold mb-1">Copy and Customize</p>
                <p className="text-white/40 text-xs leading-relaxed">Replace street names, customer names, and details with your actual jobs. The structure stays the same.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 flex items-center justify-center bg-orange/15 flex-shrink-0">
                <span className="text-orange text-sm font-bold">2</span>
              </div>
              <div>
                <p className="text-white text-sm font-semibold mb-1">Pair with Real Photos</p>
                <p className="text-white/40 text-xs leading-relaxed">Every post needs a before/after, job site photo, or team shot. Never post text-only on GBP.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 flex items-center justify-center bg-orange/15 flex-shrink-0">
                <span className="text-orange text-sm font-bold">3</span>
              </div>
              <div>
                <p className="text-white text-sm font-semibold mb-1">Post Weekly on GBP</p>
                <p className="text-white/40 text-xs leading-relaxed">Google Business Profile posts expire in 7 days. Set a recurring calendar reminder to post every Monday.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 flex items-center justify-center bg-orange/15 flex-shrink-0">
                <span className="text-orange text-sm font-bold">4</span>
              </div>
              <div>
                <p className="text-white text-sm font-semibold mb-1">Cross-Post to Facebook & Instagram</p>
                <p className="text-white/40 text-xs leading-relaxed">Use the same content across platforms. Add Instagram-specific hashtags and Facebook location tags.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Weekly Schedule */}
      <section className="py-12 md:py-16 px-6 md:px-10 lg:px-16 border-t border-white/5">
        <div className="max-w-4xl">
          <h2 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider mb-8">
            Suggested Weekly Posting Schedule
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 md:grid-cols-5 gap-4">
            {[
              { day: 'Monday', type: 'Project Spotlight', why: 'Start the week with proof of work' },
              { day: 'Wednesday', type: 'Educational Tip', why: 'Mid-week value builds trust' },
              { day: 'Friday', type: 'Testimonial or Community', why: 'End the week with social proof' },
              { day: 'Storm Day', type: 'Storm Alert', why: 'Real-time relevance drives calls' },
              { day: 'Anytime', type: 'Limited Offer', why: 'Urgency converts browsers to callers' },
            ].map((item) => (
              <div key={item.day} className="bg-charcoal-mid border border-white/5 p-5">
                <p className="text-orange text-xs uppercase tracking-wider font-semibold mb-2">{item.day}</p>
                <p className="text-white text-sm font-semibold mb-2">{item.type}</p>
                <p className="text-white/40 text-xs leading-relaxed">{item.why}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16">
        <div className="bg-orange/10 border border-orange/20 p-8 md:p-12 max-w-4xl">
          <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
            <div className="flex-1">
              <h3 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider mb-3">
                Want the Full GBP Optimization Playbook?
              </h3>
              <p className="text-white/40 text-sm leading-relaxed">
                These templates are just one piece. Our complete guide covers profile setup, review generation, photo strategy, Q&A management, and the KPIs that actually move the needle.
              </p>
            </div>
            <div className="flex flex-col gap-3 flex-shrink-0">
              <button
                onClick={() => navigate('/google-business-profile-optimization')}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-7 py-3 uppercase tracking-wide text-sm transition-colors whitespace-nowrap cursor-pointer"
              >
                View Full Playbook
              </button>
              <button
                onClick={() => navigate('/blog/google-business-profile-optimization-roofing-contractors')}
                className="border border-white/20 hover:border-orange text-white/40 hover:text-orange text-xs uppercase tracking-widest py-3 transition-all duration-200 whitespace-nowrap cursor-pointer"
              >
                Read the Blog Post
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}