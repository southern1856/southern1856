import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import PageSEO from '@/components/feature/PageSEO';

const warrantySchema = [
  {
    '@context': 'https://schema.org',
    '@type': 'Service',
    name: 'Roofing Warranty — GAF, Owens Corning & Workmanship',
    description: 'Corner Stone Construction & Roofing offers industry-leading roofing warranties including GAF Golden Pledge Lifetime, Owens Corning Platinum, CertainTeed SureStart PLUS, and our own workmanship warranty. Serving Evansville Indiana and the Tri-State area.',
    provider: {
      '@type': 'RoofingContractor',
      name: 'Corner Stone Construction & Roofing',
      telephone: '+1-812-213-5997',
      address: {
        '@type': 'PostalAddress',
        streetAddress: '5800 Kansas Rd',
        addressLocality: 'Evansville',
        addressRegion: 'IN',
        postalCode: '47725',
        addressCountry: 'US',
      },
    },
    hasOfferCatalog: {
      '@type': 'OfferCatalog',
      name: 'Roofing Warranty Options',
      itemListElement: [
        { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'GAF Golden Pledge Lifetime Warranty' } },
        { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Owens Corning Platinum Protection Warranty' } },
        { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'CertainTeed SureStart PLUS Warranty' } },
        { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Corner Stone Workmanship Warranty' } },
      ],
    },
  },
  {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: [
      {
        '@type': 'Question',
        name: "What's the difference between a material warranty and a workmanship warranty?",
        acceptedAnswer: { '@type': 'Answer', text: 'A material warranty covers defects in the shingles themselves. A workmanship warranty covers defects in how the roof was installed. You need both for complete protection.' },
      },
      {
        '@type': 'Question',
        name: 'Can I transfer my roofing warranty when I sell my home?',
        acceptedAnswer: { '@type': 'Answer', text: 'Yes — GAF, Owens Corning, and CertainTeed warranties are all transferable to a new homeowner, typically within 60 days of the sale. This is a significant selling point and can add real value to your home.' },
      },
      {
        '@type': 'Question',
        name: 'Does my roofing warranty cover storm damage?',
        acceptedAnswer: { '@type': 'Answer', text: 'No — warranties cover manufacturing defects and installation errors, not storm damage. Storm damage is covered by your homeowner insurance. As a warranty holder, you get priority scheduling for our free storm damage inspection.' },
      },
      {
        '@type': 'Question',
        name: 'What voids a roofing warranty?',
        acceptedAnswer: { '@type': 'Answer', text: 'Common warranty voiders include improper ventilation, installing solar panels without proper flashing, using non-approved materials for repairs, and failure to maintain gutters and drainage.' },
      },
    ],
  },
];

const warranties = [
  {
    id: 'gaf',
    name: 'GAF Golden Pledge',
    subtitle: 'Lifetime Limited Warranty',
    tag: 'Strongest Available',
    tagColor: 'bg-amber-500',
    highlight: true,
    logo: 'ri-award-line',
    logoColor: 'text-amber-500',
    border: 'border-amber-500/30',
    bg: 'bg-amber-500/5',
    coverage: 'Lifetime',
    laborCoverage: '25 Years',
    transferable: true,
    desc: 'The GAF Golden Pledge is the most comprehensive roofing warranty available in the US. It covers both materials AND labor — meaning if anything goes wrong, GAF pays for the fix, not just the shingles. Only Master Elite contractors like Corner Stone can offer this warranty.',
    highlights: [
      'Lifetime coverage on GAF shingles',
      '25-year non-prorated labor warranty',
      'Covers installation defects — not just materials',
      'Transferable to new homeowner (one time)',
      'Backed by GAF — a $3B company',
      'Requires Master Elite contractor installation',
    ],
    finePrint: 'Available on qualifying GAF shingle systems installed by GAF Master Elite contractors. Requires proper ventilation and underlayment. See GAF warranty document for full terms.',
    bestFor: 'Homeowners who want the absolute best protection and plan to stay in their home long-term.',
  },
  {
    id: 'owens',
    name: 'Owens Corning Platinum',
    subtitle: 'Total Protection Roofing System',
    tag: 'Top 1% Contractor',
    tagColor: 'bg-orange',
    highlight: false,
    logo: 'ri-medal-line',
    logoColor: 'text-orange',
    border: 'border-orange/20',
    bg: 'bg-orange/5',
    coverage: 'Lifetime',
    laborCoverage: '25 Years',
    transferable: true,
    desc: 'The Owens Corning Platinum Protection warranty is available exclusively through Platinum Preferred Contractors — the top 1% of roofers nationally. It covers the full roofing system, not just individual components, for a truly comprehensive protection package.',
    highlights: [
      'Lifetime limited warranty on Duration shingles',
      '25-year SureStart PLUS labor coverage',
      'Full system warranty (shingles + underlayment + accessories)',
      'Transferable to new owner within 60 days of sale',
      'Wind resistance up to 130 mph',
      'Algae resistance warranty included',
    ],
    finePrint: 'Available on qualifying Owens Corning Duration shingle systems. Requires Platinum Preferred Contractor installation. Full terms in Owens Corning warranty document.',
    bestFor: 'Homeowners who want full-system coverage and the flexibility to transfer the warranty when selling.',
  },
  {
    id: 'certainteed',
    name: 'CertainTeed SureStart PLUS',
    subtitle: 'Enhanced Warranty Program',
    tag: 'SELECT ShingleMaster',
    tagColor: 'bg-green-600',
    highlight: false,
    logo: 'ri-shield-star-line',
    logoColor: 'text-green-500',
    border: 'border-green-500/20',
    bg: 'bg-green-500/5',
    coverage: 'Lifetime',
    laborCoverage: '25 Years',
    transferable: true,
    desc: 'CertainTeed\'s SureStart PLUS warranty provides enhanced coverage through their SELECT ShingleMaster program. It covers both materials and labor for 25 years with no dollar limit — meaning CertainTeed pays the full cost of any covered repair.',
    highlights: [
      'Lifetime limited warranty on qualifying shingles',
      '25-year SureStart PLUS labor coverage',
      'No dollar limit on covered repairs',
      'Transferable to new homeowner',
      'Covers wind damage up to 130 mph',
      'Algae resistance warranty on qualifying products',
    ],
    finePrint: 'Available on qualifying CertainTeed shingle systems installed by SELECT ShingleMaster contractors. See CertainTeed warranty document for full terms.',
    bestFor: 'Homeowners who want no-dollar-limit labor coverage and a trusted national brand.',
  },
  {
    id: 'workmanship',
    name: 'Corner Stone Workmanship',
    subtitle: 'Our Personal Guarantee',
    tag: 'Always Included',
    tagColor: 'bg-charcoal border border-white/20',
    highlight: false,
    logo: 'ri-tools-line',
    logoColor: 'text-white',
    border: 'border-white/10',
    bg: 'bg-white/5',
    coverage: 'Up to Lifetime',
    laborCoverage: 'Included',
    transferable: false,
    desc: 'Every job we do — from a $500 repair to a $25,000 full replacement — is backed by our personal workmanship warranty. This covers any defect in our installation work, separate from the manufacturer\'s material warranty. If we made a mistake, we fix it. Period.',
    highlights: [
      '10-year workmanship warranty on all installations',
      'Lifetime workmanship on qualifying full replacements',
      '2-year warranty on all repairs',
      'Covers installation errors and defects',
      'No deductible, no hassle',
      'Backed by Corner Stone directly — not a third party',
    ],
    finePrint: 'Workmanship warranty covers defects in installation only, not material failures (covered by manufacturer warranty) or damage from storms, accidents, or improper maintenance.',
    bestFor: 'Every customer — this warranty is included on every job at no extra cost.',
  },
];

const warrantyFaqs = [
  {
    q: 'What\'s the difference between a material warranty and a workmanship warranty?',
    a: 'A material warranty (from the manufacturer like GAF or Owens Corning) covers defects in the shingles themselves — if they crack, blister, or fail prematurely. A workmanship warranty (from us) covers defects in how the roof was installed — if a leak develops because of improper flashing or nailing. You need both for complete protection.',
  },
  {
    q: 'Do I need to do anything to keep my warranty valid?',
    a: 'Most manufacturer warranties require annual inspections and proper ventilation to remain valid. Our maintenance plans are specifically designed to keep your warranty compliant and your documentation current. We provide a written inspection report after every visit.',
  },
  {
    q: 'Can I transfer my warranty when I sell my home?',
    a: 'Yes — GAF, Owens Corning, and CertainTeed warranties are all transferable to a new homeowner (typically within 60 days of the sale). This is a significant selling point and can add real value to your home. Contact us and we\'ll handle the transfer paperwork.',
  },
  {
    q: 'What voids a roofing warranty?',
    a: 'Common warranty voiders include: improper ventilation, walking on the roof without care, installing solar panels or other equipment without proper flashing, using non-approved materials for repairs, and failure to maintain gutters and drainage. Our maintenance plans help you avoid all of these.',
  },
  {
    q: 'How do I file a warranty claim?',
    a: 'For workmanship issues, call us directly at 812-213-5997. For manufacturer warranty claims, we handle the process on your behalf — you don\'t need to deal with the manufacturer directly. We document the issue, submit the claim, and coordinate the repair.',
  },
  {
    q: 'Does my warranty cover storm damage?',
    a: 'No — warranties cover manufacturing defects and installation errors, not storm damage. Storm damage is covered by your homeowner\'s insurance. However, as a warranty holder, you get priority scheduling for our free storm damage inspection and insurance claim assistance.',
  },
];

function WarrantyCard({ warranty, index }: { warranty: typeof warranties[0]; index: number }) {
  const [expanded, setExpanded] = useState(false);
  const anim = useScrollAnimation({ threshold: 0.1 });

  return (
    <div
      ref={anim.ref as React.RefObject<HTMLDivElement>}
      className={`anim-fade-up ${anim.isVisible ? 'is-visible' : ''} border-2 ${warranty.border} ${warranty.bg} overflow-hidden transition-all duration-300`}
      style={{ transitionDelay: `${index * 120}ms` }}
    >
      {/* Tag */}
      <div className={`px-4 py-2 text-center text-xs font-bold uppercase tracking-widest text-white ${warranty.tagColor}`}>
        {warranty.tag}
      </div>

      <div className="p-7 md:p-9">
        {/* Header */}
        <div className="flex items-start gap-4 mb-5">
          <div className={`w-12 h-12 flex items-center justify-center bg-white/10 flex-shrink-0 ${warranty.logoColor}`}>
            <i className={`${warranty.logo} text-2xl`} />
          </div>
          <div>
            <h3 className={`font-display text-xl md:text-2xl uppercase tracking-wider ${warranty.highlight ? 'text-amber-400' : 'text-white'}`}>
              {warranty.name}
            </h3>
            <p className="text-white/40 text-xs uppercase tracking-widest mt-0.5">{warranty.subtitle}</p>
          </div>
        </div>

        {/* Coverage pills */}
        <div className="flex flex-wrap gap-2 mb-5">
          <div className="flex items-center gap-1.5 bg-white/5 border border-white/10 px-3 py-1.5">
            <i className="ri-shield-check-line text-orange text-xs" />
            <span className="text-white/60 text-xs">Materials: <strong className="text-white">{warranty.coverage}</strong></span>
          </div>
          <div className="flex items-center gap-1.5 bg-white/5 border border-white/10 px-3 py-1.5">
            <i className="ri-tools-line text-orange text-xs" />
            <span className="text-white/60 text-xs">Labor: <strong className="text-white">{warranty.laborCoverage}</strong></span>
          </div>
          <div className={`flex items-center gap-1.5 border px-3 py-1.5 ${warranty.transferable ? 'bg-green-500/10 border-green-500/20' : 'bg-white/5 border-white/10'}`}>
            <i className={`${warranty.transferable ? 'ri-arrow-left-right-line text-green-400' : 'ri-close-line text-white/30'} text-xs`} />
            <span className={`text-xs ${warranty.transferable ? 'text-green-400' : 'text-white/30'}`}>
              {warranty.transferable ? 'Transferable' : 'Non-transferable'}
            </span>
          </div>
        </div>

        <p className="text-white/50 text-sm leading-relaxed mb-5">{warranty.desc}</p>

        {/* Highlights */}
        <ul className="space-y-2 mb-5">
          {warranty.highlights.map((h) => (
            <li key={h} className="flex items-start gap-2.5 text-white/60 text-sm">
              <i className="ri-check-line text-orange text-sm mt-0.5 flex-shrink-0" />
              {h}
            </li>
          ))}
        </ul>

        {/* Best for */}
        <div className="bg-white/5 border border-white/10 p-4 mb-4">
          <p className="text-white/30 text-xs uppercase tracking-wider mb-1">Best For</p>
          <p className="text-white/70 text-sm">{warranty.bestFor}</p>
        </div>

        {/* Fine print toggle */}
        <button
          onClick={() => setExpanded(!expanded)}
          className="flex items-center gap-1.5 text-white/30 hover:text-white/60 text-xs uppercase tracking-wider transition-colors cursor-pointer"
        >
          <i className={`${expanded ? 'ri-arrow-up-s-line' : 'ri-arrow-down-s-line'} text-sm`} />
          {expanded ? 'Hide' : 'View'} Fine Print
        </button>
        <div className={`overflow-hidden transition-all duration-300 ${expanded ? 'max-h-32 opacity-100 mt-3' : 'max-h-0 opacity-0'}`}>
          <p className="text-white/25 text-xs leading-relaxed">{warranty.finePrint}</p>
        </div>
      </div>
    </div>
  );
}

function FaqItem({ faq, isOpen, onToggle }: { faq: typeof warrantyFaqs[0]; isOpen: boolean; onToggle: () => void }) {
  return (
    <div className="border-b border-white/10">
      <button onClick={onToggle} className="w-full flex items-center justify-between py-5 md:py-6 text-left cursor-pointer group">
        <span className="font-display text-white text-lg md:text-xl uppercase tracking-wider pr-4 group-hover:text-orange transition-colors">{faq.q}</span>
        <div className={`w-8 h-8 flex items-center justify-center border flex-shrink-0 transition-all duration-300 ${isOpen ? 'bg-orange border-orange text-white' : 'border-white/20 text-white/40 group-hover:border-orange group-hover:text-orange'}`}>
          <i className={`ri-${isOpen ? 'subtract' : 'add'}-line`} />
        </div>
      </button>
      <div className={`overflow-hidden transition-all duration-500 ${isOpen ? 'max-h-48 opacity-100 pb-5 md:pb-6' : 'max-h-0 opacity-0'}`}>
        <p className="text-white/50 text-sm md:text-base leading-relaxed pr-12">{faq.a}</p>
      </div>
    </div>
  );
}

export default function WarrantyPage() {
  const navigate = useNavigate();
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const heroAnim = useScrollAnimation();
  const compareAnim = useScrollAnimation({ threshold: 0.05 });
  const faqAnim = useScrollAnimation({ threshold: 0.05 });
  const ctaAnim = useScrollAnimation({ threshold: 0.1 });

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roofing Warranty Evansville Indiana | GAF Lifetime, Owens Corning & Workmanship"
        description="Corner Stone Construction & Roofing offers the strongest roofing warranties in Evansville Indiana — GAF Golden Pledge Lifetime, Owens Corning Platinum, CertainTeed SureStart PLUS, and our own workmanship guarantee. Covers materials AND labor. Transferable. Call 812-213-5997."
        keywords="roofing warranty Evansville Indiana, GAF Golden Pledge warranty Indiana, Owens Corning Platinum warranty, lifetime roofing warranty Evansville, workmanship warranty roofing Indiana, transferable roof warranty"
        canonical="/warranty"
        schema={warrantySchema}
      />

      {/* ── Hero ── */}
      <section className="relative min-h-[72vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1600x900.svg"
            alt="Corner Stone warranty-backed roofing installation"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/65 via-black/50 to-charcoal-deep" />
        </div>
        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 text-center anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs md:text-sm font-semibold tracking-[0.25em] uppercase mb-5">
            Industry-Leading Coverage
          </p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 8vw, 7rem)' }}>
            Warranties That<br />Actually Mean<br /><span className="text-orange">Something.</span>
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-2xl mx-auto leading-relaxed mb-10">
            As a GAF Master Elite and Owens Corning Platinum Preferred contractor, we offer the strongest roofing warranties available — covering both materials and labor for up to a lifetime.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="#warranties"
              onClick={(e) => { e.preventDefault(); document.querySelector('#warranties')?.scrollIntoView({ behavior: 'smooth' }); }}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap"
            >
              See All Warranties
            </a>
            <a
              href="tel:8122135997"
              className="border border-white/30 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>
      </section>

      {/* ── Why Warranty Matters ── */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal border-y border-white/10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12 text-center">
          {[
            { icon: 'ri-shield-check-line', title: 'Materials + Labor', desc: 'Most warranties only cover materials. Ours cover the full cost of any covered repair — parts AND labor.' },
            { icon: 'ri-arrow-left-right-line', title: 'Transferable', desc: 'Selling your home? Our manufacturer warranties transfer to the new owner, adding real value to your sale.' },
            { icon: 'ri-building-4-line', title: 'Backed by Billions', desc: 'GAF and Owens Corning are multi-billion dollar companies. Your warranty is backed by their financial strength.' },
          ].map((item, i) => (
            <div key={item.title} className={`anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`} style={{ transitionDelay: `${i * 120}ms` }}>
              <div className="w-12 h-12 mx-auto mb-4 flex items-center justify-center bg-orange/20 text-orange">
                <i className={`${item.icon} text-xl`} />
              </div>
              <h3 className="font-display text-white text-lg uppercase tracking-wider mb-2">{item.title}</h3>
              <p className="text-white/40 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Warranty Cards ── */}
      <section id="warranties" className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14 md:mb-18">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Our Warranty Options</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2.5rem, 5vw, 4.5rem)' }}>
            Four Levels of Protection.<br />All Best-in-Class.
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Every roof we install comes with our workmanship warranty. Manufacturer warranties depend on the product you choose — we'll help you pick the right one.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
          {warranties.map((w, i) => (
            <WarrantyCard key={w.id} warranty={w} index={i} />
          ))}
        </div>
      </section>

      {/* ── Comparison Table ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-12 md:mb-16">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Side by Side</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Warranty Comparison
          </h2>
        </div>

        <div
          ref={compareAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${compareAnim.isVisible ? 'is-visible' : ''} overflow-x-auto`}
        >
          <table className="w-full min-w-[640px] border-collapse">
            <thead>
              <tr>
                <th className="text-left px-5 py-4 text-white/30 text-xs uppercase tracking-widest font-semibold border-b border-white/10 w-1/3">Coverage</th>
                {warranties.map((w) => (
                  <th key={w.id} className={`px-4 py-4 text-center border-b border-white/10 ${w.highlight ? 'bg-amber-500/10' : ''}`}>
                    <p className={`font-display text-sm uppercase tracking-wider ${w.highlight ? 'text-amber-400' : 'text-white'}`}>{w.name}</p>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                { label: 'Material Coverage', values: ['Lifetime', 'Lifetime', 'Lifetime', 'N/A'] },
                { label: 'Labor Coverage', values: ['25 Years', '25 Years', '25 Years', '10–Lifetime'] },
                { label: 'Transferable', values: ['✓', '✓', '✓', '✗'] },
                { label: 'No Dollar Limit', values: ['✓', '✓', '✓', '✓'] },
                { label: 'Wind Coverage', values: ['130 mph', '130 mph', '130 mph', 'N/A'] },
                { label: 'Algae Resistance', values: ['✓', '✓', '✓', 'N/A'] },
                { label: 'Always Included', values: ['Upgrade', 'Upgrade', 'Upgrade', '✓'] },
              ].map((row, i) => (
                <tr key={row.label} className={i % 2 === 0 ? 'bg-white/[0.015]' : ''}>
                  <td className="px-5 py-4 text-white/60 text-sm border-b border-white/5">{row.label}</td>
                  {row.values.map((val, j) => (
                    <td key={j} className={`px-4 py-4 text-center text-sm border-b border-white/5 ${warranties[j].highlight ? 'bg-amber-500/5' : ''} ${val === '✓' ? 'text-green-400' : val === '✗' ? 'text-white/20' : 'text-white/70'}`}>
                      {val}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12 md:mb-16">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Common Questions</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Warranty FAQ
            </h2>
          </div>
          <div ref={faqAnim.ref as React.RefObject<HTMLDivElement>} className={`anim-fade-up ${faqAnim.isVisible ? 'is-visible' : ''}`}>
            {warrantyFaqs.map((faq, i) => (
              <FaqItem key={i} faq={faq} isOpen={openFaq === i} onToggle={() => setOpenFaq(openFaq === i ? null : i)} />
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div
          ref={ctaAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${ctaAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="relative overflow-hidden bg-charcoal-mid border border-white/5 p-10 md:p-16 lg:p-20 text-center">
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute -top-20 -right-20 w-80 h-80 bg-orange/5 rounded-full blur-3xl" />
              <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-orange/5 rounded-full blur-3xl" />
            </div>
            <div className="relative z-10">
              <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Get the Best Warranty Available</p>
              <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
                Your Roof. Protected.<br /><span className="text-orange">For Life.</span>
              </h2>
              <p className="text-white/40 text-sm md:text-base max-w-lg mx-auto leading-relaxed mb-10">
                Get a free estimate and we'll walk you through every warranty option — so you know exactly what's covered before we start a single nail.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <button
                  onClick={() => navigate('/estimate')}
                  className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
                >
                  Get a Free Estimate
                </button>
                <a
                  href="tel:8122135997"
                  className="border border-white/20 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
                >
                  <i className="ri-phone-line text-orange" />
                  812-213-5997
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
