import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import GutterCostEstimator from '@/components/feature/GutterCostEstimator';
import PageSEO from '@/components/feature/PageSEO';
import RelatedServicesStrip from '@/components/feature/RelatedServicesStrip';
import ServiceProcessStrip from '@/components/feature/ServiceProcessStrip';
import CompetitorComparisonTool from '@/components/feature/CompetitorComparisonTool';
import PriceMatchBanner from '@/components/feature/PriceMatchBanner';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { trackOfferView } from '@/pages/promotions/components/RecentlyViewedOffers';
import { OFFERS } from '@/mocks/promotions';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const gutterSchema = {
  '@context': 'https://schema.org',
  '@type': 'Service',
  name: 'Gutter Replacement & Installation Evansville Indiana',
  provider: {
    '@type': 'RoofingContractor',
    name: 'Corner Stone Construction & Roofing',
    telephone: '+1-812-213-5997',
    address: {
      '@type': 'PostalAddress',
      streetAddress: '5800 Kansas Rd',
      addressLocality: 'Evansville',
      addressRegion: 'IN',
      postalCode: '47725',
    },
  },
  areaServed: ['Evansville IN', 'Henderson KY', 'Newburgh IN', 'Owensboro KY', 'Tri-State Area'],
  description: 'Professional gutter installation, replacement, and repair in Evansville Indiana and Henderson KY. Seamless aluminum gutters, copper gutters, gutter guards, and downspout installation. Protect your home from water damage.',
  hasOfferCatalog: {
    '@type': 'OfferCatalog',
    name: 'Gutter Services',
    itemListElement: [
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Seamless Gutter Installation' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Gutter Replacement' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Gutter Guards' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Downspout Installation' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Gutter Repair' } },
    ],
  },
};

const GUTTER_TYPES = [
  {
    id: 'seamless-aluminum',
    name: 'Seamless Aluminum',
    badge: 'Most Popular',
    badgeColor: 'bg-orange text-white',
    lifespan: '20–30 Years',
    bestFor: 'Most Homes — Best Value',
    desc: 'The gold standard for residential gutters. Seamless aluminum gutters are custom-fabricated on-site to the exact length of your roofline — no seams means no leaks. Lightweight, rust-proof, and available in 30+ colors to match any home.',
    features: ['No Seams = No Leaks', 'Custom Fabricated On-Site', '30+ Color Options', 'Rust & Corrosion Proof', 'Lightweight & Strong', 'Low Maintenance'],
    image: '/placeholders/800x500.svg',
  },
  {
    id: 'copper',
    name: 'Copper Gutters',
    badge: 'Premium Choice',
    badgeColor: 'bg-white/10 text-white',
    lifespan: '50–100 Years',
    bestFor: 'Historic Homes, Premium Properties',
    desc: 'The ultimate in gutter craftsmanship. Copper gutters develop a beautiful natural patina over time, are virtually maintenance-free, and will outlast the home itself. A premium investment that adds significant curb appeal and resale value.',
    features: ['50–100 Year Lifespan', 'Natural Patina Develops', 'Zero Rust or Corrosion', 'Adds Resale Value', 'Soldered Joints', 'Virtually Maintenance-Free'],
    image: '/placeholders/800x500.svg',
  },
  {
    id: 'gutter-guards',
    name: 'Gutter Guards',
    badge: 'Never Clean Again',
    badgeColor: 'bg-white/10 text-white',
    lifespan: '15–25 Years',
    bestFor: 'Homes with Heavy Tree Coverage',
    desc: 'Stop climbing ladders twice a year. Micro-mesh gutter guards keep leaves, pine needles, and debris out while letting water flow freely. Installed over your existing gutters or as part of a new system — the last gutter cleaning you\'ll ever need.',
    features: ['Micro-Mesh Technology', 'Keeps All Debris Out', 'Works in Heavy Rain', 'Installs Over Existing Gutters', 'Transferable Warranty', 'Eliminates Clogging'],
    image: '/placeholders/800x500.svg',
  },
  {
    id: 'downspouts',
    name: 'Downspout Systems',
    badge: 'Foundation Protection',
    badgeColor: 'bg-white/10 text-white',
    lifespan: '20–30 Years',
    bestFor: 'All Homes — Critical Component',
    desc: 'Gutters are only as good as their downspouts. We design and install complete downspout systems that move water away from your foundation — including underground drainage, splash blocks, and extensions — protecting your basement and landscaping.',
    features: ['Underground Drainage Options', 'Splash Block Installation', 'Downspout Extensions', 'Proper Slope & Placement', 'Foundation Protection', 'Landscaping-Friendly Routing'],
    image: '/placeholders/800x500.svg',
  },
];

const DAMAGE_SIGNS = [
  { icon: 'ri-water-flash-line', title: 'Water Pooling Near Foundation', desc: 'Standing water next to your home is a direct path to basement flooding and foundation cracks.' },
  { icon: 'ri-home-line', title: 'Fascia Board Rot', desc: 'Overflowing gutters saturate the wood fascia behind them, causing rot that spreads to your roof deck.' },
  { icon: 'ri-bug-line', title: 'Pest Infestations', desc: 'Clogged gutters full of debris are prime nesting spots for mosquitoes, birds, and rodents.' },
  { icon: 'ri-landscape-line', title: 'Eroded Landscaping', desc: 'Water cascading off a clogged gutter destroys mulch beds, flower gardens, and lawn edges.' },
  { icon: 'ri-building-line', title: 'Stained Siding', desc: 'Overflowing water leaves ugly rust and dirt streaks down your siding that are hard to remove.' },
  { icon: 'ri-temp-cold-line', title: 'Ice Dams in Winter', desc: 'Clogged gutters trap water that freezes, creating ice dams that force water under your shingles.' },
];

const ADVANTAGES = [
  {
    icon: 'ri-tools-line',
    title: 'Custom Fabricated On-Site',
    desc: 'Our seamless gutter machine comes to your home and fabricates gutters to the exact length of your roofline — no joints, no leaks.',
  },
  {
    icon: 'ri-home-gear-line',
    title: 'Bundled with Roofing',
    desc: 'Getting a new roof? Bundle gutters and save. We coordinate both installs in one visit — no second crew, no second mess.',
  },
  {
    icon: 'ri-palette-line',
    title: '30+ Color Options',
    desc: 'Match your gutters to your trim, siding, or roofing. We carry 30+ aluminum colors and can custom-order copper or steel.',
  },
  {
    icon: 'ri-shield-check-line',
    title: 'Lifetime Workmanship Warranty',
    desc: 'Every gutter installation comes with our lifetime workmanship warranty. If it leaks, we fix it — no questions asked.',
  },
  {
    icon: 'ri-map-pin-line',
    title: 'Local Tri-State Experts',
    desc: 'We know Indiana and Kentucky weather — heavy spring rains, ice storms, and summer downpours. We size gutters for local conditions.',
  },
  {
    icon: 'ri-calendar-check-line',
    title: 'Same-Week Installation',
    desc: 'Most gutter jobs are completed in a single day. We\'ll have your new gutters up and working before the next rain.',
  },
];



const FAQS = [
  {
    q: 'How much does gutter replacement cost in Evansville Indiana?',
    a: 'Seamless aluminum gutter replacement in Evansville typically runs $8–$14 per linear foot installed, depending on gutter size (5" vs 6"), home height, and downspout count. A typical 2,000 sq ft home with 150 linear feet of gutters runs $1,200–$2,100. We provide free on-site quotes with no obligation.',
  },
  {
    q: 'What size gutters do I need for my home?',
    a: '5-inch gutters handle most standard homes. 6-inch gutters are recommended for homes with steep roof pitches, large roof areas, or in areas with heavy rainfall — which describes most of the Evansville and Henderson KY area. We\'ll measure your roof pitch and square footage to recommend the right size.',
  },
  {
    q: 'Should I replace gutters when I replace my roof?',
    a: 'Absolutely — and it saves money. When we\'re already on your roof replacing shingles, adding gutters is far more efficient. We can bundle both jobs, coordinate the install in one visit, and you avoid paying for two separate mobilizations. Most homeowners save $300–$600 by bundling.',
  },
  {
    q: 'Are gutter guards worth it in Indiana?',
    a: 'Yes, especially in the Evansville area where mature oak and maple trees drop heavy leaf loads every fall. Micro-mesh gutter guards pay for themselves in 3–5 years by eliminating professional cleaning costs ($150–$250/year) and preventing the water damage that comes from clogged gutters.',
  },
  {
    q: 'How long does gutter installation take?',
    a: 'Most residential gutter installations are completed in a single day — typically 4–8 hours depending on home size and complexity. Our seamless gutter machine fabricates on-site, so there\'s no waiting for materials. We schedule, show up, and finish same day.',
  },
  {
    q: 'Do you repair gutters or only replace them?',
    a: 'Both. If your gutters are structurally sound but have isolated leaks, sagging sections, or damaged downspouts, repair is often the right call. We\'ll give you an honest assessment — if repair makes sense, we\'ll say so. If replacement is more cost-effective long-term, we\'ll explain why.',
  },
  {
    q: 'What causes gutters to pull away from the house?',
    a: 'The most common cause is rotted fascia boards behind the gutters — the wood can no longer hold the spikes or screws. We replace the fascia, then re-hang the gutters with hidden hanger brackets (much stronger than old-style spikes). We also check for improper slope that causes water to pool and add weight.',
  },
];

const COLORS = [
  { name: 'White', hex: '#F5F5F5', border: true },
  { name: 'Almond', hex: '#E8D5B0' },
  { name: 'Clay', hex: '#C4A882' },
  { name: 'Musket Brown', hex: '#6B4C2A' },
  { name: 'Charcoal', hex: '#3D3D3D' },
  { name: 'Black', hex: '#1A1A1A' },
  { name: 'Patina Green', hex: '#5B7B6F' },
  { name: 'Copper', hex: '#B87333' },
];

const nearestExpiry = OFFERS
  .filter((o) => o.expires)
  .map((o) => o.expires!)
  .sort()[0] || '2026-12-31';

export default function GuttersDownspoutsPage() {
  const navigate = useNavigate();
  const [activeType, setActiveType] = useState(GUTTER_TYPES[0]);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [selectedColor, setSelectedColor] = useState('White');
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [charCount, setCharCount] = useState(0);
  const formRef = useRef<HTMLFormElement>(null);

  const hero = useScrollAnimation();
  const types = useScrollAnimation({ threshold: 0.05 });
  const damage = useScrollAnimation({ threshold: 0.1 });
  const compareAnim = useScrollAnimation({ threshold: 0.1 });
  const advantages = useScrollAnimation({ threshold: 0.1 });
  const faqAnim = useScrollAnimation({ threshold: 0.1 });
  const formAnim = useScrollAnimation({ threshold: 0.1 });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;
    const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
    const notes = formData.get('notes') as string;
    if (notes && notes.length > 500) return;
    setFormStatus('submitting');
    try {
      const res = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      if (res.ok) { setFormStatus('success'); formRef.current.reset(); setCharCount(0); }
      else setFormStatus('error');
    } catch { setFormStatus('error'); }
  };

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Gutter Replacement Evansville Indiana | Seamless Gutters & Gutter Guards | Corner Stone"
        description="Professional gutter installation and replacement in Evansville IN and Henderson KY. Seamless aluminum gutters, copper gutters, micro-mesh gutter guards, and downspout systems. Protect your home from water damage. Free estimates — call 812-213-5997."
        keywords="gutter replacement Evansville Indiana, seamless gutters Evansville, gutter installation Henderson KY, gutter guards Evansville, downspout installation Indiana, gutters Tri-State area, gutter repair Evansville"
        canonical="/gutters-downspouts"
        schema={gutterSchema}
      />

      {/* ── Hero ── */}
      <section className="relative min-h-screen flex flex-col overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1400x900.svg"
            alt="Gutter replacement and installation Evansville Indiana"
            className="w-full h-full object-cover object-top opacity-35"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/60 via-charcoal-deep/40 to-charcoal-deep" />
          <div className="absolute inset-0 opacity-[0.025]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '80px 80px' }} />
        </div>

        <div
          ref={hero.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 flex-1 flex flex-col justify-center px-6 md:px-10 lg:px-16 pt-32 md:pt-36 pb-16 anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-wrap items-center gap-3 mb-8">
            <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange" />
              Seamless — No Joints, No Leaks
            </div>
            <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange" />
              30+ Color Options
            </div>
            <div className="flex items-center gap-2 border border-orange/40 bg-orange/10 backdrop-blur-sm px-4 py-2 text-orange text-xs uppercase tracking-widest">
              <i className="ri-shield-check-line text-sm" />
              Lifetime Workmanship Warranty
            </div>
          </div>

          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 9vw, 10rem)' }}>
            Gutters &amp;<br />Downspouts<br /><span className="text-orange">Done Right.</span>
          </h1>

          <div className="mb-8">
            <CountdownTimer expiresAt={nearestExpiry} variant="banner" />
            <div className="mt-3">
              <SocialProofPulse />
            </div>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-end gap-8 lg:gap-16">
            <p className="text-white/50 text-base md:text-lg max-w-xl leading-relaxed">
              Evansville and Henderson KY's trusted gutter contractor. Seamless aluminum, copper, gutter guards, and complete downspout systems — protecting your home from water damage since day one.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 flex-shrink-0">
              <button
                onClick={() => document.getElementById('gutter-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <i className="ri-file-list-3-line" />
                Get Free Gutter Quote
              </button>
              <a
                href="tel:8122135997"
                className="border border-white/30 hover:border-orange text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-phone-line text-orange" />
                812-213-5997
              </a>
            </div>
          </div>
        </div>

        {/* Bottom stats */}
        <div className="relative z-10 border-t border-white/10 grid grid-cols-2 md:grid-cols-4">
          {[
            { val: '2,000+', label: 'Homes Served' },
            { val: '1 Day', label: 'Typical Install' },
            { val: '30+', label: 'Color Options' },
            { val: 'Lifetime', label: 'Workmanship Warranty' },
          ].map((s, i) => (
            <div key={s.label} className={`px-6 md:px-10 py-6 md:py-8 ${i < 3 ? 'border-r border-white/10' : ''}`}>
              <p className="font-display text-white text-3xl md:text-4xl tracking-wider">{s.val}</p>
              <p className="text-white/40 text-xs uppercase tracking-widest mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      <TalkToAIExpert />

      {/* ── Why Gutters Matter ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Don't Ignore Your Gutters</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              Bad Gutters = Big<br />Water Damage Bills
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-6">
              Gutters are the most overlooked part of a home's water management system. When they fail — whether from age, clogs, or improper installation — the damage cascades fast. Foundation repairs in Evansville average $5,000–$15,000. New gutters cost a fraction of that.
            </p>
            <div className="bg-orange/10 border border-orange/30 p-5 mb-8">
              <div className="flex items-start gap-3">
                <i className="ri-alert-line text-orange text-xl mt-0.5" />
                <div>
                  <p className="text-white font-semibold text-sm mb-1">Indiana's Heavy Rain Season</p>
                  <p className="text-white/50 text-sm leading-relaxed">
                    Evansville averages 44 inches of rain per year — well above the national average. Properly sized and installed gutters aren't optional here. They're essential.
                  </p>
                </div>
              </div>
            </div>
            <button
              onClick={() => document.getElementById('gutter-form')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap"
            >
              Schedule Free Inspection
              <i className="ri-arrow-right-line" />
            </button>
          </div>

          <div
            ref={damage.ref as React.RefObject<HTMLDivElement>}
            className="grid grid-cols-1 sm:grid-cols-2 gap-4"
          >
            {DAMAGE_SIGNS.map((sign, i) => (
              <div
                key={sign.title}
                className={`border border-white/10 bg-charcoal-mid p-5 hover:border-orange/30 transition-all duration-300 group anim-fade-up ${damage.isVisible ? 'is-visible' : ''}`}
                style={{ transitionDelay: `${i * 70}ms` }}
              >
                <div className="w-10 h-10 flex items-center justify-center bg-orange/15 group-hover:bg-orange/25 transition-colors mb-3">
                  <i className={`${sign.icon} text-orange text-lg`} />
                </div>
                <h3 className="text-white font-semibold text-sm mb-1.5">{sign.title}</h3>
                <p className="text-white/40 text-xs leading-relaxed">{sign.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Gutter Types Selector ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14 md:mb-18">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Gutter Systems</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
            The Right Gutter<br />For Your Home
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            From seamless aluminum to premium copper, we install every gutter system and help you choose the best fit for your home, budget, and tree coverage.
          </p>
        </div>

        <div
          ref={types.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 lg:grid-cols-5 gap-6"
        >
          {/* Type selector */}
          <div className="lg:col-span-2 flex flex-col gap-3">
            {GUTTER_TYPES.map((type, i) => (
              <button
                key={type.id}
                onClick={() => setActiveType(type)}
                className={`text-left border p-5 transition-all duration-300 cursor-pointer group anim-fade-up ${types.isVisible ? 'is-visible' : ''} ${activeType.id === type.id ? 'border-orange bg-orange/10' : 'border-white/10 bg-charcoal-mid hover:border-white/30'}`}
                style={{ transitionDelay: `${i * 80}ms` }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-xs font-bold px-2 py-0.5 uppercase tracking-wider ${type.badgeColor}`}>{type.badge}</span>
                  <span className="text-white/30 text-xs">{type.lifespan}</span>
                </div>
                <h3 className={`font-display text-xl uppercase tracking-wider transition-colors ${activeType.id === type.id ? 'text-orange' : 'text-white group-hover:text-orange'}`}>
                  {type.name}
                </h3>
                <p className="text-white/40 text-xs mt-2">
                  <i className="ri-home-line mr-1 text-orange" />
                  {type.bestFor}
                </p>
              </button>
            ))}
          </div>

          {/* Type detail */}
          <div className="lg:col-span-3 flex flex-col gap-4">
            <div className="relative w-full overflow-hidden" style={{ height: '300px' }}>
              <img
                key={activeType.id}
                src={activeType.image}
                alt={activeType.name}
                className="w-full h-full object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-deep/80 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="flex items-center gap-3">
                  <span className={`text-xs font-bold px-3 py-1 uppercase tracking-wider ${activeType.badgeColor}`}>{activeType.badge}</span>
                  <span className="text-white/50 text-xs">{activeType.lifespan} lifespan</span>
                </div>
                <h3 className="font-display text-white text-3xl uppercase tracking-wider mt-2">{activeType.name}</h3>
              </div>
            </div>

            <div className="border border-white/10 bg-charcoal-mid p-6 md:p-8 flex-1">
              <p className="text-white/60 text-sm leading-relaxed mb-6">{activeType.desc}</p>
              <div className="grid grid-cols-2 gap-2 mb-6">
                {activeType.features.map((f) => (
                  <div key={f} className="flex items-center gap-2 text-white/50 text-xs">
                    <i className="ri-check-line text-orange text-sm" />
                    {f}
                  </div>
                ))}
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => document.getElementById('gutter-form')?.scrollIntoView({ behavior: 'smooth' })}
                  className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-6 py-3 uppercase tracking-wide transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                >
                  Get {activeType.name} Quote
                  <i className="ri-arrow-right-line" />
                </button>
                <a
                  href="tel:8122135997"
                  className="border border-white/20 hover:border-orange text-white/70 hover:text-white text-sm font-semibold px-6 py-3 uppercase tracking-wide transition-all whitespace-nowrap flex items-center justify-center gap-2"
                >
                  <i className="ri-phone-line text-orange" />
                  Call Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Color Selector ── */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal border-y border-white/10">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">Match Your Home</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(1.8rem, 4vw, 3.5rem)' }}>
              30+ Color Options
            </h2>
            <p className="text-white/40 text-sm mt-3 max-w-md mx-auto">
              Our seamless gutters are available in over 30 colors. Here are the most popular choices for Evansville and Henderson area homes.
            </p>
          </div>
          <div className="flex flex-wrap justify-center gap-5">
            {COLORS.map((color) => (
              <button
                key={color.name}
                onClick={() => setSelectedColor(color.name)}
                className="flex flex-col items-center gap-2 cursor-pointer group"
              >
                <div
                  className={`w-12 h-12 rounded-full transition-all duration-200 ${selectedColor === color.name ? 'ring-2 ring-orange ring-offset-2 ring-offset-charcoal scale-110' : 'group-hover:scale-105'} ${color.border ? 'border border-white/20' : ''}`}
                  style={{ backgroundColor: color.hex }}
                />
                <span className={`text-xs uppercase tracking-wider transition-colors ${selectedColor === color.name ? 'text-orange' : 'text-white/40 group-hover:text-white/70'}`}>
                  {color.name}
                </span>
              </button>
            ))}
          </div>
          <p className="text-center text-white/30 text-xs mt-8">
            <i className="ri-information-line mr-1" />
            Selected: <span className="text-orange">{selectedColor}</span> — Ask about our full color catalog during your free estimate
          </p>
        </div>
      </section>

      {/* ── Aluminum vs. Copper Comparison ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Head-to-Head</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Aluminum vs.<br />Copper Gutters
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed mt-4">
            The two best gutter materials for Evansville homes — compared across every factor that matters. Real numbers, real facts, no fluff.
          </p>
        </div>

        <div
          ref={compareAnim.ref as React.RefObject<HTMLDivElement>}
          className={`max-w-5xl mx-auto anim-fade-up ${compareAnim.isVisible ? 'is-visible' : ''}`}
        >
          {/* Header row */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="hidden md:block" />
            <div className="text-center border border-white/10 bg-charcoal-mid p-6">
              <h3 className="font-display text-white text-2xl uppercase tracking-wider mb-1">Seamless Aluminum</h3>
              <span className="bg-orange text-white text-xs font-bold uppercase tracking-widest px-3 py-1">Most Popular</span>
            </div>
            <div className="text-center border border-orange/30 bg-orange/5 p-6">
              <h3 className="font-display text-white text-2xl uppercase tracking-wider mb-1">Copper Gutters</h3>
              <span className="bg-white/10 text-white text-xs font-bold uppercase tracking-widest px-3 py-1">Premium Choice</span>
            </div>
          </div>

          {/* Comparison rows */}
          {[
            {
              label: 'Price (installed)',
              alum: '$8–$14 / linear ft',
              alumDesc: 'Best value for most homeowners',
              copper: '$25–$40 / linear ft',
              copperDesc: 'Premium investment, heirloom quality',
              winner: 'aluminum' as const,
            },
            {
              label: 'Typical 150 Linear Ft Home',
              alum: '$1,200–$2,100',
              alumDesc: 'Complete tear-off & seamless install',
              copper: '$3,750–$6,000',
              copperDesc: 'Complete tear-off & soldered install',
              winner: 'aluminum' as const,
            },
            {
              label: 'Lifespan',
              alum: '20–30 Years',
              alumDesc: 'Thicker .032" gauge lasts longest',
              copper: '50–100+ Years',
              copperDesc: 'Outlasts the house itself',
              winner: 'copper' as const,
            },
            {
              label: 'Maintenance',
              alum: 'Minimal — clean twice a year',
              alumDesc: 'Add gutter guards = zero cleaning',
              copper: 'Virtually zero after patina forms',
              copperDesc: 'Never needs paint or sealant',
              winner: 'copper' as const,
            },
            {
              label: 'Rust / Corrosion',
              alum: 'Zero — rust-proof aluminum',
              alumDesc: 'Won\'t corrode in Indiana rain',
              copper: 'Zero — naturally corrosion-resistant',
              copperDesc: 'Patina actually protects the metal',
              winner: 'tie' as const,
            },
            {
              label: 'Aesthetic Appeal',
              alum: 'Clean, modern, versatile',
              alumDesc: '30+ colors to match any trim',
              copper: 'Stunning — develops natural patina',
              copperDesc: 'Starts gold, ages to elegant green/brown',
              winner: 'copper' as const,
            },
            {
              label: 'Color Options',
              alum: '30+ baked-on enamel colors',
              alumDesc: 'Match siding, trim, or roof exactly',
              copper: 'One — natural copper (ages to patina)',
              copperDesc: 'The color is the material itself',
              winner: 'aluminum' as const,
            },
            {
              label: 'Weight',
              alum: 'Lightweight — easy on fascia',
              alumDesc: 'No extra structural support needed',
              copper: 'Heavy — requires reinforced hangers',
              copperDesc: 'We upgrade brackets at no extra charge',
              winner: 'aluminum' as const,
            },
            {
              label: 'Installation Speed',
              alum: 'Same day — machine fabricates on-site',
              alumDesc: 'Lightweight, interlocking sections',
              copper: '1–2 days — hand-soldered joints',
              copperDesc: 'Each joint is soldered for permanence',
              winner: 'aluminum' as const,
            },
            {
              label: 'Impact / Hail Resistance',
              alum: 'Good — may dent in severe hail',
              alumDesc: 'Dents can usually be pushed out',
              copper: 'Excellent — malleable but tough',
              copperDesc: 'Hail bounces off, rarely damages',
              winner: 'copper' as const,
            },
            {
              label: 'Adds Resale Value',
              alum: 'Good — functional improvement',
              alumDesc: 'Buyers expect good gutters',
              copper: 'Excellent — luxury curb appeal',
              copperDesc: 'Buyers pay premium for copper details',
              winner: 'copper' as const,
            },
            {
              label: 'Eco-Friendly',
              alum: 'Good — 100% recyclable',
              alumDesc: 'Recycled content available',
              copper: 'Excellent — fully recyclable',
              copperDesc: 'Natural material, no chemical finish',
              winner: 'copper' as const,
            },
            {
              label: 'Seamless Fabrication',
              alum: 'Yes — custom machine on-site',
              alumDesc: 'No seams = no leak points',
              copper: 'Sections are soldered together',
              copperDesc: 'Soldered joints are stronger than the metal',
              winner: 'tie' as const,
            },
            {
              label: 'Best For',
              alum: 'Most homes, budget-conscious owners',
              alumDesc: 'The smart choice for 90% of homeowners',
              copper: 'Historic homes, luxury properties',
              copperDesc: 'Owners planning to stay 30+ years',
              winner: 'tie' as const,
            },
            {
              label: 'Warranty',
              alum: 'Lifetime workmanship + 20-year finish',
              alumDesc: 'Covers peeling, fading, chalking',
              copper: 'Lifetime workmanship + material guarantee',
              copperDesc: 'The metal itself is the warranty',
              winner: 'tie' as const,
            },
          ].map((row) => (
            <div
              key={row.label}
              className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3"
            >
              {/* Label */}
              <div className="flex items-center border border-white/10 bg-charcoal-mid px-5 py-4">
                <span className="text-white font-semibold text-sm">{row.label}</span>
              </div>

              {/* Aluminum */}
              <div className={`border px-5 py-4 ${row.winner === 'aluminum' ? 'border-orange/40 bg-orange/5' : 'border-white/10 bg-charcoal-mid'}`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-white font-semibold text-sm">{row.alum}</span>
                  {row.winner === 'aluminum' && (
                    <span className="bg-orange text-white text-[10px] font-bold uppercase tracking-wider px-2 py-0.5">Winner</span>
                  )}
                </div>
                <p className="text-white/40 text-xs">{row.alumDesc}</p>
              </div>

              {/* Copper */}
              <div className={`border px-5 py-4 ${row.winner === 'copper' ? 'border-orange/40 bg-orange/5' : 'border-white/10 bg-charcoal-mid'}`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-white font-semibold text-sm">{row.copper}</span>
                  {row.winner === 'copper' && (
                    <span className="bg-orange text-white text-[10px] font-bold uppercase tracking-wider px-2 py-0.5">Winner</span>
                  )}
                </div>
                <p className="text-white/40 text-xs">{row.copperDesc}</p>
              </div>
            </div>
          ))}

          {/* Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10">
            <div className="border border-orange/30 bg-orange/5 p-8">
              <h4 className="font-display text-orange text-xl uppercase tracking-wider mb-4">Choose Aluminum If...</h4>
              <ul className="space-y-3">
                {[
                  'You want the best value and fastest install',
                  'You want to match a specific trim or siding color',
                  'You plan to add gutter guards (best combo)',
                  'You want a same-day or next-day installation',
                  'You\'re replacing gutters on a standard suburban home',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2 text-white/60 text-sm">
                    <i className="ri-check-line text-orange text-sm mt-0.5 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => document.getElementById('gutter-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="mt-6 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-3 uppercase tracking-widest text-sm transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap"
              >
                Get Aluminum Quote
                <i className="ri-arrow-right-line" />
              </button>
            </div>

            <div className="border border-white/10 bg-charcoal-mid p-8">
              <h4 className="font-display text-white text-xl uppercase tracking-wider mb-4">Choose Copper If...</h4>
              <ul className="space-y-3">
                {[
                  'You own a historic or high-end home',
                  'You want gutters that last 50–100+ years',
                  'You love the natural patina aesthetic',
                  'You plan to stay in your home indefinitely',
                  'You want maximum curb appeal and resale value',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2 text-white/60 text-sm">
                    <i className="ri-check-line text-orange text-sm mt-0.5 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => document.getElementById('gutter-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="mt-6 border border-orange/40 hover:bg-orange/10 text-orange font-semibold px-8 py-3 uppercase tracking-widest text-sm transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap"
              >
                Get Copper Quote
                <i className="ri-arrow-right-line" />
              </button>
            </div>
          </div>

          <p className="text-center text-white/30 text-sm mt-8">
            <i className="ri-information-line mr-1" />
            Most Evansville homeowners choose seamless aluminum with gutter guards — the best balance of cost, performance, and longevity. We&apos;ll help you decide during your free inspection.
          </p>
        </div>
      </section>

      {/* ── Gutter Cost Estimator ── */}
      <GutterCostEstimator />

      {/* ── Why Corner Stone ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Why Choose Us</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            The Corner Stone<br />Difference
          </h2>
        </div>

        <div
          ref={advantages.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {ADVANTAGES.map((adv, i) => (
            <div
              key={adv.title}
              className={`border border-white/10 bg-charcoal-mid p-8 hover:border-orange/30 transition-all duration-300 group anim-fade-up ${advantages.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="w-12 h-12 flex items-center justify-center bg-orange/15 group-hover:bg-orange/25 transition-colors mb-5">
                <i className={`${adv.icon} text-orange text-xl`} />
              </div>
              <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">{adv.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{adv.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Bundle & Save CTA ── */}
      <section className="py-14 px-6 md:px-10 lg:px-16">
        <div className="relative overflow-hidden border border-white/10 bg-charcoal-mid">
          <div className="absolute inset-y-0 right-0 w-1/3 bg-orange/5 pointer-events-none" />
          <div className="absolute right-12 top-1/2 -translate-y-1/2 hidden lg:flex flex-col items-center gap-2 opacity-15 pointer-events-none select-none">
            <i className="ri-home-2-line text-orange text-6xl" />
            <i className="ri-add-line text-white text-3xl" />
            <i className="ri-building-line text-orange text-5xl" />
            <i className="ri-add-line text-white text-3xl" />
            <i className="ri-drop-line text-orange text-5xl" />
          </div>
          <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8 p-8 md:p-12">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-5">
                <div className="bg-orange text-white text-xs font-bold uppercase tracking-widest px-4 py-2 flex items-center gap-2">
                  <i className="ri-price-tag-3-line" />
                  Bundle &amp; Save
                </div>
                <span className="text-white/40 text-xs uppercase tracking-widest">Save $800–$2,000 Total</span>
              </div>
              <h3 className="font-display text-white uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(1.8rem, 3.5vw, 3rem)' }}>
                Roof + Siding + Gutters.<br />The Complete Exterior Package.
              </h3>
              <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-xl">
                Why schedule three separate contractors when one crew can handle everything? Bundle your gutters with a new roof and siding for maximum savings and zero scheduling headaches. This is the smartest exterior investment a homeowner can make.
              </p>
              <div className="flex flex-wrap gap-x-6 gap-y-2 mt-5">
                {['One crew, one visit', 'Save $800–$2,000', 'Matched colors & materials', 'One warranty covers all'].map((item) => (
                  <div key={item} className="flex items-center gap-2 text-white/50 text-xs">
                    <i className="ri-check-line text-orange text-sm" />
                    {item}
                  </div>
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-3 flex-shrink-0">
              <button
                onClick={() => {
                  trackOfferView({
                    id: 'exterior-complete',
                    title: 'Complete Exterior Package',
                    savings: 'Save $800–$2,000',
                    icon: 'ri-home-gear-line',
                  });
                  navigate('/exterior-package');
                }}
                className="bg-orange hover:bg-orange-dark text-white font-bold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <i className="ri-home-gear-line" />
                See Complete Exterior Package
              </button>
              <button
                onClick={() => document.getElementById('gutter-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
              >
                Get Bundle Quote
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ── Process ── */}
      <ServiceProcessStrip
        heading="How It Works"
        subheading="New Gutters in\n4 Simple Steps"
        steps={[
          { num: '01', icon: 'ri-search-eye-line', title: 'Free Inspection', desc: 'We inspect your existing gutters, fascia boards, and drainage patterns. We measure every linear foot and identify any wood rot or damage.', detail: 'Fascia rot check included' },
          { num: '02', icon: 'ri-file-list-3-line', title: 'Same-Day Quote', desc: 'You get a written quote on the spot — material, color, gutter guard options, and downspout routing. No surprises.', detail: 'Color swatches brought to you' },
          { num: '03', icon: 'ri-truck-line', title: 'On-Site Fabrication', desc: 'Our seamless gutter machine arrives and fabricates your gutters to exact length. No seams, no joints, no future leak points.', detail: 'Custom fabricated in your driveway' },
          { num: '04', icon: 'ri-checkbox-circle-line', title: 'Installed & Tested', desc: 'Gutters are hung, downspouts routed, and we run water through the entire system to verify proper flow and zero leaks.', detail: 'Lifetime workmanship warranty' },
        ]}
        ctaText="Ready for new gutters? Get your free estimate today."
        ctaSubtext="Free inspection · Same-week install · Tri-State area"
        buttonText="Get Free Gutter Quote"
        buttonHref="#gutter-form"
      />

      {/* ── Compare Quotes — Bundle vs. Separate Contractors ── */}
      <CompetitorComparisonTool />

      {/* ── Price Match Guarantee ── */}
      <PriceMatchBanner serviceName="gutter replacement" highlightSavings="Seamless custom-fabricated gutters at the best price — guaranteed" />

      {/* ── Service Area ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Where We Work</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Serving Evansville,<br />Henderson &amp; the<br />Tri-State Area
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-6">
              From Evansville to Henderson KY, Newburgh to Owensboro — we install gutters across the entire Tri-State area. One call, one crew, one company you can trust.
            </p>
            <div className="space-y-3 mb-8">
              {[
                { city: 'Evansville, IN', note: 'Primary Market — Headquarters' },
                { city: 'Henderson, KY', note: 'Primary KY Market' },
                { city: 'Newburgh, IN', note: 'Warrick County' },
                { city: 'Owensboro, KY', note: 'Daviess County' },
                { city: 'Boonville, IN', note: 'Warrick County' },
                { city: 'Mount Vernon, IN', note: 'Posey County' },
              ].map((loc) => (
                <div key={loc.city} className="flex items-center justify-between py-2 border-b border-white/5">
                  <div className="flex items-center gap-3">
                    <i className="ri-map-pin-2-line text-orange text-sm" />
                    <span className="text-white text-sm font-medium">{loc.city}</span>
                  </div>
                  <span className="text-white/30 text-xs">{loc.note}</span>
                </div>
              ))}
            </div>
            <button
              onClick={() => navigate('/service-areas')}
              className="border border-white/20 hover:border-orange text-white/70 hover:text-white text-sm font-semibold px-8 py-3.5 uppercase tracking-widest transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap"
            >
              <i className="ri-map-2-line text-orange" />
              View Full Service Area
            </button>
          </div>

          <div className="w-full overflow-hidden border border-white/10" style={{ height: '420px' }}>
            <iframe
              title="Corner Stone Gutters Service Area Evansville Indiana"
              src="https://www.google.com/maps/embed/v1/place?key=AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY&q=Evansville,+Indiana&zoom=9"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Common Questions</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Gutter FAQ
            </h2>
          </div>
          <div
            ref={faqAnim.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${faqAnim.isVisible ? 'is-visible' : ''}`}
          >
            {FAQS.map((faq, i) => (
              <div key={i} className="border-b border-white/10">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between py-5 text-left cursor-pointer group"
                >
                  <span className="font-display text-white text-lg uppercase tracking-wider pr-4 group-hover:text-orange transition-colors">{faq.q}</span>
                  <div className={`w-8 h-8 flex items-center justify-center border flex-shrink-0 transition-all duration-300 ${openFaq === i ? 'bg-orange border-orange text-white' : 'border-white/20 text-white/40 group-hover:border-orange group-hover:text-orange'}`}>
                    <i className={`ri-${openFaq === i ? 'subtract' : 'add'}-line`} />
                  </div>
                </button>
                <div className={`overflow-hidden transition-all duration-500 ${openFaq === i ? 'max-h-48 opacity-100 pb-5' : 'max-h-0 opacity-0'}`}>
                  <p className="text-white/50 text-sm leading-relaxed pr-12">{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Quote Form ── */}
      <section id="gutter-form" className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div
          ref={formAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${formAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {/* Left copy */}
            <div>
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Free Estimate</p>
              <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 5vw, 5rem)' }}>
                Get Your Free<br />Gutter Quote<br /><span className="text-orange">Today.</span>
              </h2>
              <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
                Fill out the form and we'll contact you within 2 hours to schedule your free on-site estimate. Most gutter jobs are quoted and installed within the same week.
              </p>
              <div className="space-y-4">
                {[
                  { icon: 'ri-timer-line', text: 'Response within 2 hours' },
                  { icon: 'ri-search-eye-line', text: 'Free on-site measurement & inspection' },
                  { icon: 'ri-file-list-3-line', text: 'Written quote with color options' },
                  { icon: 'ri-calendar-check-line', text: 'Same-week installation available' },
                ].map((item) => (
                  <div key={item.text} className="flex items-center gap-3 text-white/50 text-sm">
                    <i className={`${item.icon} text-orange text-base`} />
                    {item.text}
                  </div>
                ))}
              </div>
              <div className="mt-8 pt-8 border-t border-white/10">
                <p className="text-white/30 text-xs uppercase tracking-widest mb-3">Or call us directly</p>
                <a href="tel:8122135997" className="flex items-center gap-3 text-white hover:text-orange transition-colors">
                  <i className="ri-phone-fill text-orange text-xl" />
                  <span className="font-display text-2xl tracking-wider">812-213-5997</span>
                </a>
              </div>
            </div>

            {/* Right form */}
            <div className="bg-white rounded-2xl overflow-hidden">
              <div className="bg-charcoal-deep px-8 py-6 border-b border-white/10">
                <h3 className="font-display text-white text-2xl uppercase tracking-wider">Gutter Quote Request</h3>
                <p className="text-white/50 text-sm mt-1">Seamless gutters, guards &amp; downspouts</p>
              </div>

              {formStatus === 'success' ? (
                <div className="px-8 py-14 flex flex-col items-center text-center">
                  <div className="w-16 h-16 flex items-center justify-center bg-green-100 rounded-full mb-4">
                    <i className="ri-checkbox-circle-fill text-green-600 text-3xl" />
                  </div>
                  <h4 className="font-display text-charcoal text-2xl uppercase tracking-wider mb-2">Request Received!</h4>
                  <p className="text-gray-500 text-sm leading-relaxed max-w-xs">
                    We'll contact you within 2 hours to schedule your free on-site gutter estimate.
                  </p>
                  <button onClick={() => setFormStatus('idle')} className="mt-6 text-orange text-sm font-semibold underline underline-offset-4 cursor-pointer">
                    Submit another request
                  </button>
                </div>
              ) : (
                <form
                  ref={formRef}
                  data-readdy-form
                  onSubmit={handleSubmit}
                  className="px-8 py-7 space-y-4"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Full Name</label>
                      <input type="text" name="name" required placeholder="Jane Smith" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Phone</label>
                      <input type="tel" name="phone" required placeholder="812-000-0000" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Email</label>
                    <input type="email" name="email" required placeholder="you@email.com" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Property Address</label>
                    <input type="text" name="address" required placeholder="123 Main St, Evansville, IN" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Service Needed</label>
                      <select name="service_needed" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                        <option value="">Select service</option>
                        <option value="full-replacement">Full Gutter Replacement</option>
                        <option value="new-install">New Installation</option>
                        <option value="gutter-guards">Gutter Guards Only</option>
                        <option value="repair">Gutter Repair</option>
                        <option value="downspouts">Downspout Work</option>
                        <option value="bundle-roof">Bundle with Roof Replacement</option>
                        <option value="inspection">Inspection / Not Sure</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Gutter Material</label>
                      <select name="material_preference" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                        <option value="">Select material</option>
                        <option value="seamless-aluminum">Seamless Aluminum</option>
                        <option value="copper">Copper</option>
                        <option value="steel">Steel</option>
                        <option value="not-sure">Not Sure — Need Advice</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Interested in Gutter Guards?</label>
                    <select name="gutter_guards" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                      <option value="">Select option</option>
                      <option value="yes">Yes — I want to stop cleaning gutters</option>
                      <option value="maybe">Maybe — Tell me more</option>
                      <option value="no">No — Just gutters for now</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                      Additional Details <span className="text-gray-400 font-normal normal-case">(optional)</span>
                    </label>
                    <textarea
                      name="notes"
                      rows={3}
                      maxLength={500}
                      onChange={(e) => setCharCount(e.target.value.length)}
                      placeholder="Current gutter condition, tree coverage, color preferences, timeline..."
                      className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
                    />
                    <p className={`text-xs mt-1 text-right ${charCount > 500 ? 'text-red-500' : 'text-gray-400'}`}>{charCount}/500</p>
                  </div>
                  <button
                    type="submit"
                    disabled={formStatus === 'submitting'}
                    className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-300 text-white font-bold text-sm uppercase tracking-widest py-4 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  >
                    {formStatus === 'submitting' ? (
                      <><i className="ri-loader-4-line animate-spin" />Sending...</>
                    ) : (
                      <><i className="ri-send-plane-line" />Get My Free Gutter Quote</>
                    )}
                  </button>
                  {formStatus === 'error' && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2">
                      <i className="ri-alert-line text-red-500" />
                      <p className="text-red-600 text-xs">Something went wrong. Please call 812-213-5997 directly.</p>
                    </div>
                  )}
                  <p className="text-gray-400 text-xs text-center">
                    <i className="ri-lock-line mr-1" />Your information is private and secure.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ── You Might Also Need ── */}
      <RelatedServicesStrip
        heading="You Might Also Need"
        subheading="Gutters work best as part of a complete exterior system — protect every surface at once."
        services={[
          {
            icon: 'ri-home-smile-line',
            label: 'Residential Roofing',
            description: 'Replace your roof and gutters together — saves $300–$600 and ensures perfect integration between systems.',
            href: '/residential-roofing',
            badge: 'Best Combo',
          },
          {
            icon: 'ri-home-2-line',
            label: 'Siding & Exterior',
            description: 'New gutters + new siding = complete exterior protection. Matched colors, one crew, zero scheduling headaches.',
            href: '/siding-exterior',
          },
          {
            icon: 'ri-home-gear-line',
            label: 'Complete Exterior Package',
            description: 'Roof + Siding + Gutters all at once. The smartest exterior investment — save $800–$2,000 total.',
            href: '/exterior-package',
            badge: 'Save $800–$2,000',
            highlight: true,
            trackOffer: { id: 'exterior-complete', title: 'Complete Exterior Package', savings: 'Save $800–$2,000', icon: 'ri-home-gear-line' },
          },
        ]}
      />
    </div>
  );
}
