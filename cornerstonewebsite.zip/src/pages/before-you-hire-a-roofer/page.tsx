import { useState, useRef } from 'react';
import PageSEO from '@/components/feature/PageSEO';

interface ChecklistItem {
  id: string;
  section: string;
  label: string;
  description: string;
  redFlag: string;
  points: number;
}

const checklistItems: ChecklistItem[] = [
  // SECTION 1: CREDENTIALS & INSURANCE
  {
    id: 'c1',
    section: 'Credentials',
    label: 'Verified active state contractor license',
    description: 'Ask for the license number and verify it on your state\'s licensing board website. Do not accept "we are licensed" without proof.',
    redFlag: 'Contractor refuses to give license number or says licensing is "not required for small jobs."',
    points: 5,
  },
  {
    id: 'c2',
    section: 'Credentials',
    label: 'Proof of general liability insurance ($1M+ coverage)',
    description: 'Request a Certificate of Insurance (COI) directly from their insurance agent, not a photocopy from the contractor.',
    redFlag: 'Gives you a photocopied card, cannot name their insurance company, or coverage is under $500K.',
    points: 5,
  },
  {
    id: 'c3',
    section: 'Credentials',
    label: 'Proof of workers compensation insurance',
    description: 'If a worker gets hurt on your property and the contractor has no workers comp, YOU could be liable for medical bills.',
    redFlag: 'Says everyone is an "independent contractor" so no workers comp is needed.',
    points: 5,
  },
  {
    id: 'c4',
    section: 'Credentials',
    label: 'Physical business address (not a PO box)',
    description: 'A local address means they are accountable and have a real presence. Drive by their office if you are unsure.',
    redFlag: 'Only has a PO box, home address, or no address on their website at all.',
    points: 3,
  },
  {
    id: 'c5',
    section: 'Credentials',
    label: 'Years in business under the same name',
    description: 'Look them up on the Secretary of State website. Longevity under the same name means stability. Frequent name changes suggest they are hiding from past problems.',
    redFlag: 'Company is "new" but the owner has "20 years of experience" — likely a shell company after a previous failure.',
    points: 3,
  },

  // SECTION 2: ESTIMATES & CONTRACTS
  {
    id: 'e1',
    section: 'Estimates',
    label: 'Received a detailed written estimate (not a verbal quote)',
    description: 'The estimate should include materials, labor, timeline, payment schedule, and cleanup. If it is a napkin or text message, walk away.',
    redFlag: '"I will email it tonight" that never arrives, or a one-line text with a round number.',
    points: 5,
  },
  {
    id: 'e2',
    section: 'Estimates',
    label: 'Got at least 3 estimates from different companies',
    description: 'Three estimates help you spot outliers. One quote that is half the others is either missing something critical or a scam.',
    redFlag: 'Pushes you to sign today without getting other quotes, or claims other roofers are "rip-offs."',
    points: 4,
  },
  {
    id: 'e3',
    section: 'Estimates',
    label: 'Estimate specifies exact shingle brand, style, and color',
    description: '"Architectural shingles" is not enough. The estimate should name the manufacturer (GAF, Owens Corning, CertainTeed) and the exact product line.',
    redFlag: 'Uses vague terms like "30-year shingles" or "premium grade" without naming the product.',
    points: 3,
  },
  {
    id: 'e4',
    section: 'Estimates',
    label: 'Payment schedule is reasonable (not 100% upfront)',
    description: 'Standard is 1/3 upfront, 1/3 at delivery, 1/3 upon completion. Never pay 100% before work begins.',
    redFlag: 'Requires full payment, a large deposit "to order materials," or only accepts cash.',
    points: 5,
  },
  {
    id: 'e5',
    section: 'Estimates',
    label: 'Contract includes a clear start and completion date',
    description: 'Weather happens, but the contract should state a target timeline and what happens if it goes over.',
    redFlag: 'No timeline in writing, or says "we will get to it when we can."',
    points: 3,
  },
  {
    id: 'e6',
    section: 'Estimates',
    label: 'Change order process is defined in writing',
    description: 'If they find rotted decking, who pays and how much per sheet? This should be pre-negotiated, not sprung on you mid-job.',
    redFlag: 'Says "we will figure it out if we find anything" or charges per-sheet rates that seem arbitrary.',
    points: 3,
  },

  // SECTION 3: REPUTATION & REFERENCES
  {
    id: 'r1',
    section: 'Reputation',
    label: 'Checked Google reviews (20+ with 4.5+ average)',
    description: 'Read the 1-star and 2-star reviews, not just the 5-stars. Look for patterns — communication issues, cleanup problems, or warranty disputes.',
    redFlag: 'Fewer than 10 reviews, all posted within the same month, or no reviews at all.',
    points: 4,
  },
  {
    id: 'r2',
    section: 'Reputation',
    label: 'Checked Better Business Bureau rating',
    description: 'A BBB A+ rating is good. Even better is seeing how they handle complaints. A company with resolved complaints shows accountability.',
    redFlag: 'BBB profile does not exist, has an F rating, or multiple unresolved complaints.',
    points: 3,
  },
  {
    id: 'r3',
    section: 'Reputation',
    label: 'Contacted at least 2 recent local references',
    description: 'Ask for references from jobs completed in the last 6 months, ideally in your neighborhood. Call them and ask about cleanup, timeliness, and communication.',
    redFlag: 'References are from 3+ years ago, out of state, or will not provide any at all.',
    points: 4,
  },
  {
    id: 'r4',
    section: 'Reputation',
    label: 'Verified manufacturer certifications (GAF, Owens Corning, etc.)',
    description: 'Factory-certified contractors can offer enhanced warranties. Verify certification on the manufacturer\'s website, not the contractor\'s word.',
    redFlag: 'Claims to be "certified" but the manufacturer\'s directory does not list them.',
    points: 3,
  },
  {
    id: 'r5',
    section: 'Reputation',
    label: 'No signs of recent name changes or shell companies',
    description: 'Search the owner\'s name on your state\'s business registry. Storm chasers and scam roofers often create new LLCs after complaints pile up.',
    redFlag: 'Business was registered within the last year but claims "25 years of experience."',
    points: 3,
  },

  // SECTION 4: WARRANTY & PROTECTION
  {
    id: 'w1',
    section: 'Warranty',
    label: 'Workmanship warranty is in writing (5+ years minimum)',
    description: 'Labor warranties cover installation errors that manufacturer warranties do not. 1-year warranties are standard for reason — most leaks show up after year two.',
    redFlag: 'Only offers a 1-year workmanship warranty, or warranty is "verbal" and not in the contract.',
    points: 5,
  },
  {
    id: 'w2',
    section: 'Warranty',
    label: 'Manufacturer warranty is registered and transferable',
    description: 'Some warranties must be registered within 30 days of installation. Ask if it transfers to the next homeowner — this adds resale value.',
    redFlag: 'No mention of manufacturer warranty registration, or says "the shingles have a 30-year warranty" without clarifying coverage type.',
    points: 4,
  },
  {
    id: 'w3',
    section: 'Warranty',
    label: 'Warranty does not require you to use them for future repairs',
    description: 'Some roofers void their labor warranty if you hire someone else for maintenance. Read the fine print.',
    redFlag: 'Warranty is voided if another contractor touches the roof, or requires annual "inspections" at cost.',
    points: 3,
  },

  // SECTION 5: JOB SITE & CLEANUP
  {
    id: 'j1',
    section: 'Job Site',
    label: 'Cleanup and debris removal included in writing',
    description: 'Magnetic nail sweep, disposal of old shingles, protection of landscaping. If it is not in the contract, assume you are doing it.',
    redFlag: 'Says "we clean up" but nothing is in writing. Adds a disposal fee later.',
    points: 3,
  },
  {
    id: 'j2',
    section: 'Job Site',
    label: 'Protection plan for landscaping, siding, and gutters',
    description: 'Ask specifically how they protect your flower beds, patio furniture, and gutters during tear-off. Good roofers have a protocol.',
    redFlag: 'Dismisses your concerns with "we have done this a thousand times" without specifics.',
    points: 3,
  },
  {
    id: 'j3',
    section: 'Job Site',
    label: 'Permit handling is clearly stated (who pulls it, who pays)',
    description: 'Most reputable roofers pull permits as part of the job. If they ask YOU to pull the permit, that is a red flag.',
    redFlag: 'Tells you to pull your own permit, or says permits are "not needed for re-roofs."',
    points: 4,
  },

  // SECTION 6: INSURANCE CLAIMS
  {
    id: 'i1',
    section: 'Insurance',
    label: 'Contractor does NOT ask you to sign over insurance checks',
    description: 'Signing over an insurance check (Assignment of Benefits) gives the contractor complete control over your claim. This is illegal in some states and risky everywhere.',
    redFlag: 'Presents an "AOB" document or says "it is standard procedure" to sign checks to them.',
    points: 5,
  },
  {
    id: 'i2',
    section: 'Insurance',
    label: 'Contractor handles insurance paperwork as a service, not a requirement',
    description: 'Good roofers help with claims. Scammers use claims as a wedge to control your money. Ask if you can handle the claim yourself if you prefer.',
    redFlag: 'Says they "must" handle the insurance claim, or refuses to work with you if you handle it yourself.',
    points: 4,
  },
  {
    id: 'i3',
    section: 'Insurance',
    label: 'Estimate matches the insurance scope of work (no hidden supplements)',
    description: 'If their estimate is thousands higher than the adjuster\'s scope, ask why in writing before signing. Some inflate supplements to pocket the difference.',
    redFlag: 'Estimate is significantly higher with no clear justification, or pressures you to "trust the process."',
    points: 3,
  },

  // SECTION 7: RED FLAGS
  {
    id: 'f1',
    section: 'Red Flags',
    label: 'No high-pressure tactics ("sign today for discount")',
    description: 'Legitimate contractors do not need to pressure you. Storm chasers use urgency to stop you from doing due diligence.',
    redFlag: '"This price is only good if you sign today," or shows up unannounced after a storm.',
    points: 5,
  },
  {
    id: 'f2',
    section: 'Red Flags',
    label: 'No out-of-state plates or temporary office setup',
    description: 'Storm chasers often roll into town with out-of-state trucks, rent a temporary office, and leave when complaints catch up.',
    redFlag: 'Truck has out-of-state plates, no local branding, or office looks like it was set up last week.',
    points: 4,
  },
  {
    id: 'f3',
    section: 'Red Flags',
    label: 'Contractor did NOT knock on your door unsolicited',
    description: 'Reputable roofers do not canvas neighborhoods after storms. They get calls from homeowners who found them online or were referred.',
    redFlag: 'Knocked on your door uninvited, especially after a storm, and claimed to "see damage from the street."',
    points: 4,
  },
  {
    id: 'f4',
    section: 'Red Flags',
    label: 'Contract is reviewed (not rushed) before signing',
    description: 'A good contractor wants you to understand the contract. If they rush you, they are hiding something.',
    redFlag: 'Rushes you to sign, says "it is just standard language," or discourages you from reading it.',
    points: 3,
  },
];

const maxPoints = checklistItems.reduce((sum, i) => sum + i.points, 0);

const sections = ['Credentials', 'Estimates', 'Reputation', 'Warranty', 'Job Site', 'Insurance', 'Red Flags'];

function getGrade(score: number, total: number): { grade: string; color: string; risk: string } {
  const pct = score / total;
  if (pct >= 0.9) return { grade: 'A+', color: 'text-green-600', risk: 'Low Risk — You did your homework.' };
  if (pct >= 0.85) return { grade: 'A', color: 'text-green-600', risk: 'Low Risk — Solid due diligence.' };
  if (pct >= 0.8) return { grade: 'A-', color: 'text-green-500', risk: 'Low Risk — Minor gaps.' };
  if (pct >= 0.75) return { grade: 'B+', color: 'text-orange', risk: 'Moderate Risk — Verify the unchecked items.' };
  if (pct >= 0.7) return { grade: 'B', color: 'text-orange', risk: 'Moderate Risk — A few warning signs.' };
  if (pct >= 0.65) return { grade: 'B-', color: 'text-orange', risk: 'Moderate Risk — Proceed with caution.' };
  if (pct >= 0.6) return { grade: 'C+', color: 'text-yellow-600', risk: 'Elevated Risk — Do more homework before signing.' };
  if (pct >= 0.55) return { grade: 'C', color: 'text-yellow-600', risk: 'Elevated Risk — Multiple concerns.' };
  if (pct >= 0.5) return { grade: 'C-', color: 'text-yellow-600', risk: 'High Risk — Consider other contractors.' };
  if (pct >= 0.4) return { grade: 'D', color: 'text-red-500', risk: 'High Risk — Strongly consider walking away.' };
  return { grade: 'F', color: 'text-red-600', risk: 'CRITICAL RISK — Do not sign. Find another contractor.' };
}

export default function BeforeYouHireRooferPage() {
  const [checked, setChecked] = useState<Set<string>>(new Set());
  const [activeSection, setActiveSection] = useState<string>('All');
  const [printMode, setPrintMode] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  const toggleItem = (id: string) => {
    const next = new Set(checked);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setChecked(next);
  };

  const handlePrint = () => {
    setPrintMode(true);
    setTimeout(() => {
      window.print();
      setPrintMode(false);
    }, 100);
  };

  const filteredItems = activeSection === 'All'
    ? checklistItems
    : checklistItems.filter((i) => i.section === activeSection);

  const score = checklistItems.reduce((s, i) => s + (checked.has(i.id) ? i.points : 0), 0);
  const completedCount = checked.size;
  const totalCount = checklistItems.length;

  const gradeInfo = getGrade(score, maxPoints);

  const schema = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: 'Before You Hire a Roofer Checklist',
    description:
      'A 28-point checklist for homeowners hiring a roofing contractor. Verify license, insurance, warranties, and spot red flags before you sign.',
    url: 'https://cornerstoneconstructionevansville.com/before-you-hire-a-roofer',
  };

  return (
    <div className="min-h-screen bg-white print:bg-white" ref={printRef}>
      <PageSEO
        title="Before You Hire a Roofer: 28-Point Homeowner Checklist | Corner Stone"
        description="Free printable checklist for homeowners hiring a roofing contractor. Verify license, insurance, warranties, references, and spot red flags before signing."
        keywords="hire a roofer checklist, roofing contractor red flags, how to choose a roofer, roof replacement checklist, hire roofing contractor tips"
        canonical="/before-you-hire-a-roofer"
        schema={schema}
      />

      {/* Print Header */}
      <div className="hidden print:block print:p-8">
        <div className="flex items-center justify-between border-b-2 border-gray-300 pb-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 uppercase tracking-wider">
              Before You Hire a Roofer
            </h1>
            <p className="text-sm text-gray-600 mt-1">
              28-Point Homeowner Protection Checklist
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600">Corner Stone Construction & Roofing</p>
            <p className="text-sm text-gray-600">812-213-5997</p>
            <p className="text-sm text-gray-600">cornerstoneconstructionevansville.com</p>
          </div>
        </div>
        <p className="text-xs text-gray-500 mb-4">
          Instructions: Check each box as you verify it. Add your score at the bottom to see your risk level.
        </p>
      </div>

      {/* Screen Header */}
      <div className={`${printMode ? 'hidden' : 'block'} bg-charcoal-deep`}>
        <div className="px-6 md:px-10 lg:px-16 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <h1 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wider">
                Before You Hire a Roofer
              </h1>
              <p className="text-white/40 text-sm mt-2">
                28 items every homeowner should verify before signing a roofing contract.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setChecked(new Set())}
                className="border border-white/20 hover:border-orange text-white/40 hover:text-orange text-xs uppercase tracking-widest py-2.5 px-5 transition-all duration-200 whitespace-nowrap cursor-pointer"
              >
                Reset
              </button>
              <button
                onClick={handlePrint}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-5 py-2.5 uppercase tracking-wide text-xs transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <i className="ri-printer-line" />
                Print Checklist
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Score Bar */}
      <div className={`${printMode ? 'hidden' : 'block'} bg-charcoal-mid border-y border-white/5`}>
        <div className="px-6 md:px-10 lg:px-16 py-5">
          <div className="flex flex-wrap items-center gap-4 md:gap-8">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 flex items-center justify-center border-2 border-orange/30 bg-orange/10">
                <span className={`text-xl font-bold ${gradeInfo.color}`}>{gradeInfo.grade}</span>
              </div>
              <div>
                <p className="text-white text-sm font-semibold">Risk Grade</p>
                <p className="text-white/40 text-xs">{score} / {maxPoints} points</p>
              </div>
            </div>
            <div className="h-8 w-px bg-white/10 hidden md:block" />
            <div>
              <p className="text-white/60 text-xs uppercase tracking-wider">Status</p>
              <p className="text-white text-sm font-semibold">{completedCount} / {totalCount} checked</p>
            </div>
            <div className="flex-1 min-w-[200px]">
              <div className="h-2 bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-orange transition-all duration-500"
                  style={{ width: `${(completedCount / totalCount) * 100}%` }}
                />
              </div>
            </div>
            <div>
              <p className={`text-sm font-semibold ${gradeInfo.color}`}>{gradeInfo.risk}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Print Score */}
      <div className="hidden print:block print:px-8 print:mb-6">
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="border border-gray-300 p-3 text-center">
            <p className="text-[10px] uppercase tracking-wider text-gray-500">Risk Grade</p>
            <p className="text-2xl font-bold text-gray-900 mt-1">{gradeInfo.grade}</p>
            <p className="text-xs text-gray-500">{score} / {maxPoints} pts</p>
          </div>
          <div className="border border-gray-300 p-3 text-center">
            <p className="text-[10px] uppercase tracking-wider text-gray-500">Items Checked</p>
            <p className="text-2xl font-bold text-gray-900 mt-1">{completedCount}</p>
            <p className="text-xs text-gray-500">out of {totalCount}</p>
          </div>
          <div className="border border-gray-300 p-3 text-center">
            <p className="text-[10px] uppercase tracking-wider text-gray-500">Risk Level</p>
            <p className="text-sm font-bold text-gray-900 mt-1">{gradeInfo.risk}</p>
          </div>
        </div>
      </div>

      {/* Section Filter */}
      <div className={`${printMode ? 'hidden' : 'block'} py-6 px-6 md:px-10 lg:px-16 border-b border-white/5`}>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveSection('All')}
            className={`px-4 py-2 text-xs uppercase tracking-wider font-semibold transition-all cursor-pointer whitespace-nowrap ${
              activeSection === 'All'
                ? 'bg-orange text-white'
                : 'bg-charcoal-mid text-white/40 hover:text-white border border-white/10'
            }`}
          >
            All Sections
          </button>
          {sections.map((s) => (
            <button
              key={s}
              onClick={() => setActiveSection(s)}
              className={`px-4 py-2 text-xs uppercase tracking-wider font-semibold transition-all cursor-pointer whitespace-nowrap ${
                activeSection === s
                  ? 'bg-orange text-white'
                  : 'bg-charcoal-mid text-white/40 hover:text-white border border-white/10'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 md:px-8 lg:px-12 py-6 md:py-10 print:px-8 print:py-4">
        {activeSection === 'All' ? (
          sections.map((section) => {
            const items = checklistItems.filter((i) => i.section === section);
            const sectionScore = items.reduce((s, i) => s + (checked.has(i.id) ? i.points : 0), 0);
            const sectionMax = items.reduce((s, i) => s + i.points, 0);
            return (
              <div key={section} className="mb-10 print:mb-6 print:break-inside-avoid">
                <div className="flex items-center gap-3 mb-5 print:mb-3">
                  <h2 className="font-display text-gray-900 text-lg md:text-xl uppercase tracking-wider print:text-gray-900">
                    {section}
                  </h2>
                  <span className="text-[10px] font-bold text-orange uppercase tracking-wider">
                    {sectionScore} / {sectionMax} pts
                  </span>
                </div>
                <div className="space-y-3 print:space-y-2">
                  {items.map((item) => (
                    <ChecklistRow
                      key={item.id}
                      item={item}
                      checked={checked.has(item.id)}
                      onToggle={() => toggleItem(item.id)}
                    />
                  ))}
                </div>
              </div>
            );
          })
        ) : (
          <div className="space-y-3 print:space-y-2">
            {filteredItems.map((item) => (
              <ChecklistRow
                key={item.id}
                item={item}
                checked={checked.has(item.id)}
                onToggle={() => toggleItem(item.id)}
              />
            ))}
          </div>
        )}

        {/* Risk Summary (screen) */}
        <div className={`${printMode ? 'hidden' : 'block'} border border-gray-200 p-6 md:p-8 mb-10 mt-8`}>
          <h3 className="font-display text-gray-900 text-lg uppercase tracking-wider mb-6">
            Your Risk Assessment
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="text-center p-5 border border-gray-200">
              <p className="text-xs uppercase tracking-wider text-gray-400 mb-2">Grade</p>
              <p className={`text-4xl font-bold ${gradeInfo.color}`}>{gradeInfo.grade}</p>
              <p className="text-sm text-gray-500 mt-1">{score} of {maxPoints} points</p>
            </div>
            <div className="text-center p-5 border border-gray-200">
              <p className="text-xs uppercase tracking-wider text-gray-400 mb-2">Risk Level</p>
              <p className={`text-lg font-bold ${gradeInfo.color}`}>{gradeInfo.risk}</p>
              <p className="text-sm text-gray-500 mt-1">{completedCount} of {totalCount} verified</p>
            </div>
          </div>

          <div className="border-t border-gray-200 pt-6">
            <h4 className="text-sm font-semibold text-gray-900 mb-4">What Your Grade Means</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2 text-xs text-gray-600">
              <p><strong className="text-green-600">A (80%+):</strong> You did thorough homework. This contractor checks out.</p>
              <p><strong className="text-orange">B (70-79%):</strong> Solid due diligence. Verify the remaining items before signing.</p>
              <p><strong className="text-yellow-600">C (50-69%):</strong> Multiple gaps. Pause and get more information.</p>
              <p><strong className="text-red-500">D/F (&lt;50%):</strong> Too many red flags. Consider other contractors.</p>
            </div>
          </div>
        </div>

        {/* Print Risk Summary */}
        <div className="hidden print:block print:mt-6 print:border-t-2 print:border-gray-300 print:pt-6 print:break-inside-avoid">
          <h3 className="font-display text-gray-900 text-base uppercase tracking-wider mb-4 print:text-gray-900">
            Risk Assessment
          </h3>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="border border-gray-300 p-3 text-center">
              <p className="text-[10px] uppercase tracking-wider text-gray-500">Grade</p>
              <p className="text-xl font-bold text-gray-900">{gradeInfo.grade}</p>
              <p className="text-xs text-gray-500">{score}/{maxPoints}</p>
            </div>
            <div className="border border-gray-300 p-3 text-center">
              <p className="text-[10px] uppercase tracking-wider text-gray-500">Items Verified</p>
              <p className="text-xl font-bold text-gray-900">{completedCount}</p>
              <p className="text-xs text-gray-500">of {totalCount}</p>
            </div>
            <div className="border border-gray-300 p-3 text-center">
              <p className="text-[10px] uppercase tracking-wider text-gray-500">Risk</p>
              <p className="text-sm font-bold text-gray-900">{gradeInfo.risk}</p>
            </div>
          </div>
          <div className="text-xs text-gray-600 space-y-1">
            <p><strong>A (80%+):</strong> Thorough homework. Contractor checks out.</p>
            <p><strong>B (70-79%):</strong> Solid due diligence. Verify remaining items.</p>
            <p><strong>C (50-69%):</strong> Multiple gaps. Get more info before signing.</p>
            <p><strong>D/F (&lt;50%):</strong> Too many red flags. Find another contractor.</p>
          </div>
        </div>

        {/* Action Priority List */}
        <div className={`${printMode ? 'hidden' : 'block'} mb-10`}>
          <h3 className="font-display text-gray-900 text-lg uppercase tracking-wider mb-5">
            Still Need to Verify
          </h3>
          {completedCount === totalCount ? (
            <div className="bg-green-50 border border-green-200 p-6 text-center">
              <i className="ri-shield-check-line text-green-600 text-3xl mb-3" />
              <p className="text-green-800 font-semibold">Everything verified! You are well-protected.</p>
              <p className="text-green-600 text-sm mt-1">Print this checklist and keep it with your contract.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {checklistItems
                .filter((i) => !checked.has(i.id))
                .sort((a, b) => b.points - a.points)
                .map((item, idx) => (
                  <div
                    key={item.id}
                    className="flex items-start gap-4 p-4 border border-gray-200 bg-white"
                  >
                    <span className="w-6 h-6 flex items-center justify-center bg-orange/10 text-orange text-xs font-bold flex-shrink-0">
                      {idx + 1}
                    </span>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-gray-900">{item.label}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{item.description}</p>
                      <p className="text-xs text-red-500 mt-1 italic">Red flag: {item.redFlag}</p>
                    </div>
                    <span className="text-[10px] font-bold text-orange uppercase tracking-wider flex-shrink-0">
                      +{item.points} pts
                    </span>
                  </div>
                ))}
            </div>
          )}
        </div>

        {/* Print Footer */}
        <div className="hidden print:block mt-8 pt-4 border-t border-gray-300">
          <div className="flex items-center justify-between text-xs text-gray-500">
            <p>Generated from cornerstoneconstructionevansville.com/before-you-hire-a-roofer</p>
            <p>Share this checklist with anyone buying or selling a home.</p>
          </div>
        </div>
      </div>

      {/* Screen Footer CTA */}
      <div className={`${printMode ? 'hidden' : 'block'} bg-charcoal-deep border-t border-white/5`}>
        <div className="px-6 md:px-10 lg:px-16 py-12">
          <div className="bg-orange/10 border border-orange/20 p-8 max-w-4xl">
            <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">
              Ready to Get Your Own Estimate?
            </h3>
            <p className="text-white/40 text-sm leading-relaxed mb-6">
              We built this checklist because we believe homeowners deserve transparency. Every item on this list is something we are proud to answer "yes" to. Get a free inspection and see for yourself.
            </p>
            <div className="flex flex-wrap gap-3">
              <a
                href="/free-inspection"
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-6 py-2.5 uppercase tracking-wide text-xs transition-colors whitespace-nowrap"
              >
                Free Roof Inspection
              </a>
              <a
                href="/estimate"
                className="border border-white/20 hover:border-orange text-white/40 hover:text-orange text-xs uppercase tracking-widest py-2.5 px-6 transition-all duration-200"
              >
                Request an Estimate
              </a>
              <a
                href="/testimonials"
                className="border border-white/20 hover:border-orange text-white/40 hover:text-orange text-xs uppercase tracking-widest py-2.5 px-6 transition-all duration-200"
              >
                Read Homeowner Reviews
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ChecklistRow({
  item,
  checked,
  onToggle,
}: {
  item: ChecklistItem;
  checked: boolean;
  onToggle: () => void;
}) {
  return (
    <div
      className={`border p-4 md:p-5 print:p-3 print:bg-white print:border-gray-300 flex gap-4 items-start transition-all ${
        checked
          ? 'border-orange/30 bg-orange/[0.03] print:border-gray-300 print:bg-white'
          : 'border-gray-200 bg-white print:border-gray-300'
      }`}
    >
      <div className="flex-shrink-0 mt-0.5">
        <div
          onClick={onToggle}
          className={`w-6 h-6 border-2 flex items-center justify-center cursor-pointer print:border-gray-400 transition-all ${
            checked
              ? 'bg-orange border-orange'
              : 'bg-white border-gray-300 hover:border-orange'
          }`}
        >
          {checked && (
            <i className="ri-check-line text-white text-sm print:text-gray-800" />
          )}
        </div>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-3">
          <p
            className={`text-sm font-semibold leading-snug ${
              checked ? 'text-gray-900 line-through print:no-underline print:text-gray-400' : 'text-gray-900'
            }`}
          >
            {item.label}
          </p>
          <span
            className={`text-[10px] font-bold uppercase tracking-wider flex-shrink-0 whitespace-nowrap ${
              checked ? 'text-orange/50 print:text-gray-400' : 'text-orange'
            }`}
          >
            +{item.points} pts
          </span>
        </div>
        <p
          className={`text-xs leading-relaxed mt-1.5 ${
            checked ? 'text-gray-400' : 'text-gray-500'
          } print:text-gray-600`}
        >
          {item.description}
        </p>
        <p className={`text-xs italic mt-1.5 ${checked ? 'text-red-300' : 'text-red-500'} print:text-red-600`}>
          <span className="font-semibold not-italic">Red flag:</span> {item.redFlag}
        </p>
      </div>
    </div>
  );
}