import { useNavigate } from 'react-router-dom';

export default function NotFound() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-charcoal-deep flex flex-col items-center justify-center px-6 relative overflow-hidden">
      {/* Subtle background texture */}
      <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '60px 60px' }} />

      {/* Large faded 404 */}
      <p className="absolute font-display text-white/[0.04] text-[12rem] md:text-[20rem] leading-none tracking-wider uppercase select-none pointer-events-none">
        404
      </p>

      <div className="relative z-10 flex flex-col items-center text-center max-w-lg">
        {/* Logo */}
        <div className="flex items-center gap-3 mb-8">
          <div className="flex items-center justify-center h-16 w-16 bg-white rounded-xl shadow-lg">
            <img
              src="/logo.svg"
              alt="Corner Stone Construction & Roofing"
              className="h-12 w-12 object-contain rounded"
            />
          </div>
          <div className="flex flex-col leading-none text-left">
            <span className="font-display text-white text-2xl tracking-wider uppercase">Corner Stone</span>
            <span className="text-white/40 text-[0.65rem] tracking-[0.25em] uppercase font-medium mt-0.5">
              Construction & Roofing
            </span>
          </div>
        </div>

        {/* Message */}
        <h1 className="font-display text-white uppercase tracking-wider text-3xl md:text-5xl mb-3">
          Page Not Found
        </h1>
        <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8 max-w-sm">
          Looks like this roof doesn't exist. Let's get you back to solid ground.
        </p>

        {/* CTA */}
        <button
          onClick={() => navigate('/')}
          className="group bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap cursor-pointer flex items-center gap-3"
        >
          <i className="ri-home-4-line text-lg" />
          Back to Homepage
        </button>

        {/* Quick links */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
          {[
            { label: 'Services', path: '/services' },
            { label: 'Free Estimate', path: '/estimate' },
            { label: 'Free Inspection', path: '/free-inspection' },
            { label: 'Contact', path: '/#contact' },
          ].map((link) => (
            <button
              key={link.path}
              onClick={() => navigate(link.path)}
              className="text-white/40 hover:text-orange text-xs uppercase tracking-widest transition-colors cursor-pointer whitespace-nowrap"
            >
              {link.label}
            </button>
          ))}
        </div>

        {/* Phone */}
        <a
          href="tel:8122135997"
          className="mt-8 inline-flex items-center gap-2 text-white/30 hover:text-orange text-xs uppercase tracking-widest transition-colors"
        >
          <i className="ri-phone-line text-orange" />
          812-213-5997
        </a>
      </div>
    </div>
  );
}