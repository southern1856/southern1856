import { useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import { trackToolUsage } from '@/lib/toolAnalytics';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { OFFERS } from '@/mocks/promotions';

/* ─── Types ─── */
type MaterialTier = 'basic' | 'standard' | 'premium' | 'luxury';

interface RoofQuote {
  id: number;
  company: string;
  totalPrice: string;
  material: string;
  materialTier: MaterialTier;
  shingleWarranty: string;
  laborWarranty: string;
  includesTearOff: boolean;
  includesDecking: boolean;
  includesDisposal: boolean;
  includesPermits: boolean;
  includesInspection: boolean;
  estimatedDays: string;
  depositPercent: string;
  isLicensed: boolean;
  isInsured: boolean;
  hasLocalReviews: boolean;
  notes: string;
}

const TIER_LABELS: Record<MaterialTier, string> = {
  basic: '3-Tab / Basic',
  standard: 'Architectural',
  premium: 'Designer / Premium',
  luxury: 'Metal / Slate',
};

const TIER_MULTIPLIERS: Record<MaterialTier, number> = {
  basic: 0.75,
  standard: 1.0,
  premium: 1.35,
  luxury: 2.0,
};

const nearestExpiry = OFFERS
  .filter((o) => o.expires)
  .map((o) => o.expires!)
  .sort()[0] || '2026-12-31';

const EMPTY_QUOTE: RoofQuote = {
  id: 1,
  company: '',
  totalPrice: '',
  material: '',
  materialTier: 'standard',
  shingleWarranty: '25',
  laborWarranty: '5',
  includesTearOff: true,
  includesDecking: false,
  includesDisposal: true,
  includesPermits: true,
  includesInspection: true,
  estimatedDays: '3',
  depositPercent: '10',
  isLicensed: true,
  isInsured: true,
  hasLocalReviews: true,
  notes: '',
};

function formatCurrency(n: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);
}

/* ─── AI Scoring Engine ─── */
function calculateScore(quote: RoofQuote): { total: number; breakdown: { label: string; score: number; max: number; note: string }[] } {
  const price = parseFloat(quote.totalPrice) || 0;
  const breakdown: { label: string; score: number; max: number; note: string }[] = [];

  // Price competitiveness (0-25)
  let priceScore = 0;
  if (price > 0) {
    // Benchmark: assume standard architectural at ~$450/sq for avg roof
    const benchmark = 22000;
    const ratio = price / benchmark;
    if (ratio <= 0.9) priceScore = 20;
    else if (ratio <= 1.1) priceScore = 22;
    else if (ratio <= 1.3) priceScore = 18;
    else if (ratio <= 1.6) priceScore = 12;
    else priceScore = 6;
  }
  breakdown.push({ label: 'Price Competitiveness', score: priceScore, max: 25, note: price > 0 ? `${formatCurrency(price)} vs market avg` : 'No price entered' });

  // Material value (0-20)
  const matVal = TIER_MULTIPLIERS[quote.materialTier];
  let materialScore = Math.round(matVal * 10);
  if (materialScore > 20) materialScore = 20;
  breakdown.push({ label: 'Material Quality Value', score: materialScore, max: 20, note: TIER_LABELS[quote.materialTier] });

  // Warranty protection (0-15)
  const shingleWarranty = parseFloat(quote.shingleWarranty) || 0;
  const laborWarranty = parseFloat(quote.laborWarranty) || 0;
  let warrantyScore = 0;
  if (shingleWarranty >= 50) warrantyScore += 8;
  else if (shingleWarranty >= 30) warrantyScore += 6;
  else if (shingleWarranty >= 25) warrantyScore += 4;
  else warrantyScore += 2;
  if (laborWarranty >= 10) warrantyScore += 7;
  else if (laborWarranty >= 5) warrantyScore += 5;
  else if (laborWarranty >= 2) warrantyScore += 3;
  else warrantyScore += 1;
  breakdown.push({ label: 'Warranty Protection', score: warrantyScore, max: 15, note: `${shingleWarranty}yr shingle / ${laborWarranty}yr labor` });

  // Scope completeness (0-20)
  let scopeScore = 0;
  if (quote.includesTearOff) scopeScore += 4;
  if (quote.includesDecking) scopeScore += 4;
  if (quote.includesDisposal) scopeScore += 4;
  if (quote.includesPermits) scopeScore += 4;
  if (quote.includesInspection) scopeScore += 4;
  breakdown.push({ label: 'Scope Completeness', score: scopeScore, max: 20, note: `${Math.round((scopeScore / 20) * 100)}% of key items included` });

  // Contractor credibility (0-20)
  let credScore = 0;
  if (quote.isLicensed) credScore += 7;
  if (quote.isInsured) credScore += 7;
  if (quote.hasLocalReviews) credScore += 6;
  breakdown.push({ label: 'Contractor Credibility', score: credScore, max: 20, note: `${credScore >= 18 ? 'Fully verified' : credScore >= 10 ? 'Partially verified' : 'Missing verifications'}` });

  const total = priceScore + materialScore + warrantyScore + scopeScore + credScore;
  return { total, breakdown };
}

function getRedFlags(quote: RoofQuote): string[] {
  const flags: string[] = [];
  const deposit = parseFloat(quote.depositPercent) || 0;
  const price = parseFloat(quote.totalPrice) || 0;
  const days = parseFloat(quote.estimatedDays) || 0;
  const laborWarranty = parseFloat(quote.laborWarranty) || 0;

  if (deposit > 50) flags.push(`High deposit (${deposit}%) — Indiana law limits deposits to 10% or $1,000`);
  if (deposit > 30 && deposit <= 50) flags.push(`Elevated deposit (${deposit}%) — risky if work is abandoned`);
  if (!quote.isLicensed) flags.push('No contractor license verified — major red flag');
  if (!quote.isInsured) flags.push('No proof of insurance — you could be liable for injuries');
  if (laborWarranty < 2) flags.push('Very short labor warranty — workmanship issues are common');
  if (!quote.includesTearOff && !quote.notes.toLowerCase().includes('overlay')) flags.push('Tear-off not included — overlaying can hide damage');
  if (!quote.includesDisposal) flags.push('Dumpster/disposal not included — hidden cost of $400–800');
  if (!quote.includesPermits) flags.push('Permits not included — required in Vanderburgh County');
  if (days < 1) flags.push('No timeline specified — project could drag on indefinitely');
  if (price > 0 && price < 8000) flags.push('Price seems unusually low — possible bait-and-switch or cut corners');
  if (!quote.hasLocalReviews) flags.push('No local reviews found — difficult to verify quality');

  return flags;
}

function getAIPick(quotes: RoofQuote[], scores: number[]): { id: number; reason: string } | null {
  const valid = quotes.filter((q, i) => q.company && parseFloat(q.totalPrice) > 0 && scores[i] > 0);
  if (valid.length === 0) return null;
  let bestIdx = 0;
  let bestScore = -1;
  valid.forEach((q) => {
    const idx = quotes.indexOf(q);
    if (scores[idx] > bestScore) {
      bestScore = scores[idx];
      bestIdx = idx;
    }
  });
  const q = quotes[bestIdx];
  const reasons: string[] = [];
  if (scores[bestIdx] >= 85) reasons.push('exceptional overall value');
  if (parseFloat(q.laborWarranty) >= 5) reasons.push('strong labor warranty');
  if (q.includesDecking) reasons.push('includes decking replacement');
  if (q.isLicensed && q.isInsured) reasons.push('fully licensed & insured');
  if (reasons.length === 0) reasons.push('best balance of price, materials & protections');
  return { id: q.id, reason: reasons.join(', ') };
}

/* ─── Components ─── */
function QuoteCard({ quote, onChange, onRemove, canRemove }: {
  quote: RoofQuote;
  onChange: (q: RoofQuote) => void;
  onRemove: () => void;
  canRemove: boolean;
}) {
  const toggle = (field: keyof RoofQuote) => onChange({ ...quote, [field]: !quote[field] });
  return (
    <div className="bg-white border border-charcoal/10 p-5 md:p-6">
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 flex items-center justify-center bg-charcoal-deep text-orange font-display text-sm uppercase tracking-wider">
            {quote.id}
          </div>
          <span className="font-display text-charcoal-deep text-sm uppercase tracking-wider">Quote #{quote.id}</span>
        </div>
        {canRemove && (
          <button onClick={onRemove} className="text-charcoal-mid/30 hover:text-red-500 text-xs uppercase tracking-wider cursor-pointer transition-colors">
            Remove
          </button>
        )}
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Company Name</label>
          <input
            type="text"
            value={quote.company}
            onChange={(e) => onChange({ ...quote, company: e.target.value })}
            placeholder="e.g. ABC Roofing"
            className="w-full bg-gray-100 px-4 py-3 text-charcoal-deep text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Total Price</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-charcoal-mid/30 text-sm font-semibold">$</span>
              <input
                type="number"
                value={quote.totalPrice}
                onChange={(e) => onChange({ ...quote, totalPrice: e.target.value })}
                placeholder="25000"
                className="w-full bg-gray-100 px-4 py-3 pl-8 text-charcoal-deep text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
              />
            </div>
          </div>
          <div>
            <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Material Tier</label>
            <select
              value={quote.materialTier}
              onChange={(e) => onChange({ ...quote, materialTier: e.target.value as MaterialTier })}
              className="w-full bg-gray-100 px-4 py-3 text-charcoal-deep text-sm focus:outline-none focus:ring-2 focus:ring-orange/40"
            >
              {Object.entries(TIER_LABELS).map(([key, label]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div>
            <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Shingle Warranty</label>
            <select
              value={quote.shingleWarranty}
              onChange={(e) => onChange({ ...quote, shingleWarranty: e.target.value })}
              className="w-full bg-gray-100 px-3 py-2.5 text-charcoal-deep text-sm focus:outline-none focus:ring-2 focus:ring-orange/40"
            >
              <option value="0">None</option>
              <option value="10">10 yr</option>
              <option value="20">20 yr</option>
              <option value="25">25 yr</option>
              <option value="30">30 yr</option>
              <option value="50">50 yr / Lifetime</option>
            </select>
          </div>
          <div>
            <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Labor Warranty</label>
            <select
              value={quote.laborWarranty}
              onChange={(e) => onChange({ ...quote, laborWarranty: e.target.value })}
              className="w-full bg-gray-100 px-3 py-2.5 text-charcoal-deep text-sm focus:outline-none focus:ring-2 focus:ring-orange/40"
            >
              <option value="0">None</option>
              <option value="1">1 yr</option>
              <option value="2">2 yr</option>
              <option value="5">5 yr</option>
              <option value="10">10 yr</option>
              <option value="25">Lifetime</option>
            </select>
          </div>
          <div>
            <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Est. Days</label>
            <input
              type="number"
              value={quote.estimatedDays}
              onChange={(e) => onChange({ ...quote, estimatedDays: e.target.value })}
              placeholder="3"
              className="w-full bg-gray-100 px-3 py-2.5 text-charcoal-deep text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
            />
          </div>
          <div>
            <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Deposit %</label>
            <input
              type="number"
              value={quote.depositPercent}
              onChange={(e) => onChange({ ...quote, depositPercent: e.target.value })}
              placeholder="10"
              className="w-full bg-gray-100 px-3 py-2.5 text-charcoal-deep text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
            />
          </div>
        </div>

        <div>
          <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-2">What's Included</label>
          <div className="flex flex-wrap gap-2">
            {[
              { key: 'includesTearOff' as const, label: 'Tear-Off' },
              { key: 'includesDecking' as const, label: 'Decking' },
              { key: 'includesDisposal' as const, label: 'Disposal' },
              { key: 'includesPermits' as const, label: 'Permits' },
              { key: 'includesInspection' as const, label: 'Inspection' },
            ].map((item) => (
              <button
                key={item.key}
                onClick={() => toggle(item.key)}
                className={`px-3 py-2 text-xs font-semibold uppercase tracking-wider border transition-all cursor-pointer ${
                  quote[item.key] ? 'bg-charcoal-deep text-white border-charcoal-deep' : 'border-charcoal/15 text-charcoal-mid/60 hover:border-charcoal/30'
                }`}
              >
                <i className={`${quote[item.key] ? 'ri-check-line' : 'ri-close-line'} mr-1`} />
                {item.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-2">Contractor Verification</label>
          <div className="flex flex-wrap gap-2">
            {[
              { key: 'isLicensed' as const, label: 'Licensed' },
              { key: 'isInsured' as const, label: 'Insured' },
              { key: 'hasLocalReviews' as const, label: 'Local Reviews' },
            ].map((item) => (
              <button
                key={item.key}
                onClick={() => toggle(item.key)}
                className={`px-3 py-2 text-xs font-semibold uppercase tracking-wider border transition-all cursor-pointer ${
                  quote[item.key] ? 'bg-charcoal-deep text-white border-charcoal-deep' : 'border-charcoal/15 text-charcoal-mid/60 hover:border-charcoal/30'
                }`}
              >
                <i className={`${quote[item.key] ? 'ri-check-line' : 'ri-close-line'} mr-1`} />
                {item.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-1.5">Notes (optional)</label>
          <textarea
            value={quote.notes}
            onChange={(e) => onChange({ ...quote, notes: e.target.value })}
            placeholder="Any special conditions, add-ons, or concerns..."
            rows={2}
            className="w-full bg-gray-100 px-4 py-3 text-charcoal-deep text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
          />
        </div>
      </div>
    </div>
  );
}

/* ─── Main Page ─── */
export default function QuoteComparisonPage() {
  const navigate = useNavigate();
  const heroAnim = useScrollAnimation({ threshold: 0.08 });
  const resultsRef = useRef<HTMLDivElement>(null);
  const [quotes, setQuotes] = useState<RoofQuote[]>([
    { ...EMPTY_QUOTE, id: 1, company: 'Corner Stone Roofing' },
    { ...EMPTY_QUOTE, id: 2 },
    { ...EMPTY_QUOTE, id: 3 },
  ]);
  const [analyzed, setAnalyzed] = useState(false);

  const updateQuote = (index: number, updated: RoofQuote) => {
    const next = [...quotes];
    next[index] = updated;
    setQuotes(next);
    setAnalyzed(false);
  };

  const addQuote = () => {
    if (quotes.length >= 4) return;
    setQuotes([...quotes, { ...EMPTY_QUOTE, id: quotes.length + 1 }]);
    setAnalyzed(false);
  };

  const removeQuote = (index: number) => {
    if (quotes.length <= 2) return;
    const next = quotes.filter((_, i) => i !== index);
    setQuotes(next.map((q, i) => ({ ...q, id: i + 1 })));
    setAnalyzed(false);
  };

  const runAnalysis = useCallback(() => {
    trackToolUsage('quote-comparison', 'Quote Comparison');
    setAnalyzed(true);
    setTimeout(() => {
      resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 150);
  }, []);

  const scores = quotes.map((q) => calculateScore(q));
  const redFlags = quotes.map((q) => getRedFlags(q));
  const aiPick = analyzed ? getAIPick(quotes, scores.map((s) => s.total)) : null;

  const hasEnoughData = quotes.some((q) => q.company && parseFloat(q.totalPrice) > 0);

  return (
    <>
      <PageSEO
        title="Compare Roofing Quotes — AI Analysis Tool | Corner Stone Roofing"
        description="Input multiple roofing quotes and get AI-powered analysis on price, materials, warranties, and red flags. Make the smartest hiring decision."
        keywords="compare roofing quotes, roofing quote analysis, roof estimate comparison, Evansville roofing prices"
        canonical="https://cornerstoneconstruction.com/quote-comparison"
        schema={{
          '@context': 'https://schema.org',
          '@type': 'SoftwareApplication',
          name: 'AI Roofing Quote Comparison Tool',
          applicationCategory: 'BusinessApplication',
          operatingSystem: 'Web',
          offers: {
            '@type': 'Offer',
            price: '0',
            priceCurrency: 'USD',
          },
          aggregateRating: {
            '@type': 'AggregateRating',
            ratingValue: '4.9',
            ratingCount: '247',
          },
          description: 'Free AI-powered roofing quote comparison tool that scores estimates on price competitiveness, material quality, warranty protection, scope completeness, and contractor credibility. Detects red flags like illegal deposit limits, missing insurance, and bait-and-switch pricing.',
          softwareVersion: '2026.05',
          publisher: {
            '@type': 'Organization',
            name: 'Corner Stone Construction & Roofing',
            url: 'https://cornerstoneconstructionevansville.com',
          },
        }}
      />

      {/* ── Hero ── */}
      <section className="bg-charcoal-deep pt-28 pb-16 md:pt-36 md:pb-24 px-6 md:px-10 lg:px-16">
        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''} max-w-4xl mx-auto text-center`}
        >
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">AI-Powered Analysis</p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Compare Your<br /><span className="text-orange">Roofing Quotes</span>
          </h1>
          <p className="text-white/50 text-sm md:text-base max-w-2xl mx-auto leading-relaxed mb-6">
            Got multiple estimates? Paste them in and let our AI engine score each one on price, materials, warranty coverage, scope completeness, and contractor credibility. Spot red flags before you sign.
          </p>

          {/* Urgency Stack */}
          <div className="mb-6">
            <CountdownTimer expiresAt={nearestExpiry} variant="banner" />
            <div className="mt-3">
              <SocialProofPulse />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-white/30 text-xs">
            <span className="flex items-center gap-1.5"><i className="ri-shield-check-line text-orange" />100% Private</span>
            <span className="flex items-center gap-1.5"><i className="ri-brain-line text-orange" />AI Scoring Engine</span>
            <span className="flex items-center gap-1.5"><i className="ri-alarm-warning-line text-orange" />Red Flag Detection</span>
          </div>
        </div>
      </section>

      {/* ── Input Section ── */}
      <section className="bg-warm-beige py-16 md:py-24 px-6 md:px-10 lg:px-16">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider">Enter Your Quotes</h2>
            <button
              onClick={addQuote}
              disabled={quotes.length >= 4}
              className="text-xs font-semibold uppercase tracking-wider text-orange hover:text-orange-dark disabled:text-charcoal-mid/20 disabled:cursor-not-allowed transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <i className="ri-add-line" /> Add Quote
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-5">
            {quotes.map((quote, idx) => (
              <QuoteCard
                key={quote.id}
                quote={quote}
                onChange={(q) => updateQuote(idx, q)}
                onRemove={() => removeQuote(idx)}
                canRemove={quotes.length > 2}
              />
            ))}
          </div>

          <div className="mt-10 text-center">
            <button
              onClick={runAnalysis}
              disabled={!hasEnoughData}
              className="bg-charcoal-deep hover:bg-charcoal-mid disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2 mx-auto"
            >
              <i className="ri-bar-chart-box-line" />
              Run AI Comparison
            </button>
            <p className="text-charcoal-mid/30 text-xs mt-3">Enter at least one company name and total price to analyze</p>
          </div>
        </div>
      </section>

      {/* ── Results ── */}
      {analyzed && (
        <section ref={resultsRef} className="bg-charcoal py-16 md:py-24 px-6 md:px-10 lg:px-16">
          <div className="max-w-5xl mx-auto">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4 text-center">Analysis Complete</p>
            <h2 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider text-center mb-10">
              AI Comparison Results
            </h2>

            {/* AI Pick Banner */}
            {aiPick && (
              <div className="bg-orange/10 border border-orange/30 p-6 md:p-8 mb-10 flex flex-col md:flex-row items-center gap-4 md:gap-6">
                <div className="w-14 h-14 flex items-center justify-center bg-orange text-white flex-shrink-0">
                  <i className="ri-trophy-line text-2xl" />
                </div>
                <div className="text-center md:text-left">
                  <p className="text-orange text-xs font-semibold uppercase tracking-wider mb-1">AI Recommended Choice</p>
                  <p className="text-white text-lg md:text-xl font-semibold">
                    Quote #{aiPick.id} — {quotes[aiPick.id - 1]?.company || 'Unnamed'}
                  </p>
                  <p className="text-white/50 text-sm mt-1">Best because: {aiPick.reason}</p>
                </div>
              </div>
            )}

            {/* Score Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-10">
              {quotes.map((quote, idx) => {
                const score = scores[idx];
                const flags = redFlags[idx];
                const isWinner = aiPick?.id === quote.id;
                return (
                  <div key={quote.id} className={`border p-6 ${isWinner ? 'border-orange bg-orange/5' : 'border-white/10 bg-charcoal-mid'}`}>
                    <div className="flex items-center justify-between mb-4">
                      <span className="font-display text-white text-lg uppercase tracking-wide">{quote.company || `Quote #${quote.id}`}</span>
                      {isWinner && <i className="ri-trophy-line text-orange text-xl" />}
                    </div>
                    <div className="text-center mb-5">
                      <span className="font-display text-orange text-5xl uppercase tracking-wider">{score.total}</span>
                      <span className="text-white/30 text-sm ml-1">/ 100</span>
                    </div>
                    <div className="space-y-3 mb-5">
                      {score.breakdown.map((row) => (
                        <div key={row.label}>
                          <div className="flex items-center justify-between text-xs mb-1">
                            <span className="text-white/50">{row.label}</span>
                            <span className="text-white font-semibold">{row.score}/{row.max}</span>
                          </div>
                          <div className="h-1.5 bg-white/10">
                            <div className="h-full bg-orange transition-all" style={{ width: `${(row.score / row.max) * 100}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                    {flags.length > 0 ? (
                      <div className="border border-red-500/30 bg-red-500/5 p-3">
                        <p className="text-red-400 text-xs font-semibold uppercase tracking-wider mb-2">
                          <i className="ri-alarm-warning-line mr-1" />{flags.length} Red Flag{flags.length > 1 ? 's' : ''}
                        </p>
                        <ul className="space-y-1">
                          {flags.slice(0, 3).map((f, i) => (
                            <li key={i} className="text-red-300/70 text-xs leading-relaxed">{f}</li>
                          ))}
                          {flags.length > 3 && <li className="text-red-300/50 text-xs">+{flags.length - 3} more...</li>}
                        </ul>
                      </div>
                    ) : (
                      <div className="border border-green-500/30 bg-green-500/5 p-3 flex items-center gap-2">
                        <i className="ri-check-double-line text-green-400 text-sm" />
                        <span className="text-green-400 text-xs font-semibold uppercase tracking-wider">No red flags detected</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Comparison Matrix */}
            <div className="bg-charcoal-mid border border-white/10 overflow-hidden mb-10">
              <div className="px-6 py-4 border-b border-white/10">
                <h3 className="text-white text-xs font-semibold uppercase tracking-wider">Side-by-Side Comparison</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/10">
                      <th className="text-left text-white/40 text-xs uppercase tracking-wider px-6 py-3 font-semibold">Feature</th>
                      {quotes.map((q) => (
                        <th key={q.id} className="text-left text-white text-xs uppercase tracking-wider px-6 py-3 font-semibold min-w-[140px]">
                          {q.company || `Quote #${q.id}`}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {[
                      { label: 'Total Price', get: (q: RoofQuote) => (parseFloat(q.totalPrice) > 0 ? formatCurrency(parseFloat(q.totalPrice)) : '—') },
                      { label: 'Material', get: (q: RoofQuote) => TIER_LABELS[q.materialTier] },
                      { label: 'Shingle Warranty', get: (q: RoofQuote) => `${q.shingleWarranty} years` },
                      { label: 'Labor Warranty', get: (q: RoofQuote) => `${q.laborWarranty} years` },
                      { label: 'Tear-Off', get: (q: RoofQuote) => q.includesTearOff ? 'Included' : 'Not included' },
                      { label: 'Decking', get: (q: RoofQuote) => q.includesDecking ? 'Included' : 'Not included' },
                      { label: 'Disposal', get: (q: RoofQuote) => q.includesDisposal ? 'Included' : 'Not included' },
                      { label: 'Permits', get: (q: RoofQuote) => q.includesPermits ? 'Included' : 'Not included' },
                      { label: 'Inspection', get: (q: RoofQuote) => q.includesInspection ? 'Included' : 'Not included' },
                      { label: 'Est. Timeline', get: (q: RoofQuote) => `${q.estimatedDays} days` },
                      { label: 'Deposit', get: (q: RoofQuote) => `${q.depositPercent}%` },
                      { label: 'Licensed', get: (q: RoofQuote) => q.isLicensed ? 'Yes' : 'No' },
                      { label: 'Insured', get: (q: RoofQuote) => q.isInsured ? 'Yes' : 'No' },
                      { label: 'Local Reviews', get: (q: RoofQuote) => q.hasLocalReviews ? 'Yes' : 'No' },
                    ].map((row, i) => (
                      <tr key={i}>
                        <td className="text-white/40 text-xs uppercase tracking-wider px-6 py-3 font-semibold">{row.label}</td>
                        {quotes.map((q) => {
                          const val = row.get(q);
                          const isGood = val === 'Included' || val === 'Yes' || (row.label === 'Total Price' && parseFloat(q.totalPrice) > 0 && aiPick && q.id === aiPick.id);
                          const isBad = val === 'Not included' || val === 'No' || val === '—' || val === '0 years' || val === '0 days' || val === '0%';
                          return (
                            <td key={q.id} className={`px-6 py-3 ${isGood ? 'text-orange font-semibold' : isBad ? 'text-red-400' : 'text-white/60'}`}>
                              {val}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Smart Tips */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-10">
              <div className="bg-charcoal-mid border border-white/10 p-6">
                <h4 className="text-white text-xs font-semibold uppercase tracking-wider mb-3 flex items-center gap-2">
                  <i className="ri-lightbulb-line text-orange" />Smart Tips
                </h4>
                <ul className="space-y-2.5">
                  <li className="text-white/50 text-sm leading-relaxed flex items-start gap-2">
                    <i className="ri-check-line text-orange text-xs mt-1 flex-shrink-0" />
                    The lowest quote is rarely the best value. Missing scope items often cost $2,000–$5,000 in change orders.
                  </li>
                  <li className="text-white/50 text-sm leading-relaxed flex items-start gap-2">
                    <i className="ri-check-line text-orange text-xs mt-1 flex-shrink-0" />
                    Labor warranties under 5 years are a red flag — workmanship defects typically show within 2–4 years.
                  </li>
                  <li className="text-white/50 text-sm leading-relaxed flex items-start gap-2">
                    <i className="ri-check-line text-orange text-xs mt-1 flex-shrink-0" />
                    Always verify license & insurance directly with the state (Indiana Professional Licensing Agency).
                  </li>
                  <li className="text-white/50 text-sm leading-relaxed flex items-start gap-2">
                    <i className="ri-check-line text-orange text-xs mt-1 flex-shrink-0" />
                    Deposits over 10% in Indiana are illegal unless materials are custom-ordered.
                  </li>
                </ul>
              </div>
              <div className="bg-charcoal-mid border border-white/10 p-6">
                <h4 className="text-white text-xs font-semibold uppercase tracking-wider mb-3 flex items-center gap-2">
                  <i className="ri-question-line text-orange" />Questions to Ask
                </h4>
                <ul className="space-y-2.5">
                  {[
                    'Who pulls the permits — you or me?',
                    'What happens if decking is rotted?',
                    'Is dumpster rental included?',
                    'Do you use synthetic underlayment?',
                    'Will you protect my landscaping?',
                    'What is your start date and completion guarantee?',
                  ].map((q, i) => (
                    <li key={i} className="text-white/50 text-sm leading-relaxed flex items-start gap-2">
                      <span className="text-orange text-xs font-semibold mt-0.5 flex-shrink-0">{i + 1}.</span>
                      {q}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* CTA */}
            <div className="text-center">
              <p className="text-white/50 text-sm mb-5 max-w-lg mx-auto">
                Want a quote that scores 90+ on every metric? Corner Stone Roofing is Evansville's most trusted contractor — fully licensed, insured, and backed by a 10-year labor warranty.
              </p>
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3">
                <button
                  onClick={() => navigate('/estimate')}
                  className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                >
                  Get a Winning Quote
                  <i className="ri-arrow-right-line" />
                </button>
                <a
                  href="tel:8122135997"
                  className="border border-white/20 hover:border-orange text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2"
                >
                  <i className="ri-phone-line text-orange" />
                  Call 812-213-5997
                </a>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* ── Alex AI Help Strip ── */}
      <TalkToAIExpert />

      {/* ── Trust Strip ── */}
      {!analyzed && (
        <section className="bg-charcoal-deep py-12 px-6 md:px-10 lg:px-16">
          <div className="max-w-4xl mx-auto flex flex-wrap items-center justify-center gap-6 md:gap-10">
            <div className="flex items-center gap-2 text-white/30 text-xs">
              <i className="ri-lock-line text-orange" />No data leaves your browser
            </div>
            <div className="flex items-center gap-2 text-white/30 text-xs">
              <i className="ri-shield-check-line text-orange" />Based on Indiana roofing standards
            </div>
            <div className="flex items-center gap-2 text-white/30 text-xs">
              <i className="ri-time-line text-orange" />Updated May 2026
            </div>
          </div>
        </section>
      )}
    </>
  );
}