import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const comparisonSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: [
    {
      '@type': 'Question',
      name: 'How long does an asphalt shingle roof last vs. metal roofing?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Architectural asphalt shingles last 25–30 years. Metal roofing (standing seam or metal shingles) lasts 40–70 years — roughly twice as long as asphalt.',
      },
    },
    {
      '@type': 'Question',
      name: 'What is the cost difference between asphalt, metal, tile, and slate roofing?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'In the Evansville Indiana area, asphalt shingles cost $4.50–$7.50/sq ft installed, metal roofing costs $8–$15/sq ft, clay/concrete tile costs $10–$18/sq ft, and natural slate costs $18–$35/sq ft.',
      },
    },
    {
      '@type': 'Question',
      name: 'Which roofing material is best for Indiana weather?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'For Evansville and Henderson KY, architectural asphalt shingles (GAF Timberline HDZ or Owens Corning Duration) rated to 130 mph winds offer excellent hail and wind resistance. Metal roofing provides the best long-term durability against hail, ice dams, and wind.',
      },
    },
  ],
};

interface MaterialData {
  id: string;
  name: string;
  fullName: string;
  icon: string;
  tagline: string;
  image: string;
  costRange: string;
  costPerSqFt: string;
  lifespan: string;
  warranty: string;
  laborWarranty: string;
  weight: string;
  fireRating: string;
  windRating: string;
  hailResistance: string;
  energyEfficiency: string;
  maintenanceLevel: string;
  curbAppeal: string;
  bestFor: string;
  evansvillePopularity: string;
  pros: string[];
  cons: string[];
  description: string;
  color: string;
  accentColor: string;
}

const MATERIALS: MaterialData[] = [
  {
    id: 'asphalt',
    name: 'Asphalt',
    fullName: 'Architectural Asphalt Shingles',
    icon: 'ri-home-2-line',
    tagline: 'Best Value for Most Homes',
    image: '/placeholders/900x500.svg',
    costRange: '$9,000 – $18,000',
    costPerSqFt: '$4.50 – $7.50 / sq ft',
    lifespan: '25 – 30 Years',
    warranty: 'Lifetime Limited (Manufacturer)',
    laborWarranty: '25 Years (Golden Pledge)',
    weight: 'Moderate (2.5–4 lbs/sq ft)',
    fireRating: 'Class A',
    windRating: 'Up to 130 mph',
    hailResistance: 'Good (3–4 Impact Rating)',
    energyEfficiency: 'Standard',
    maintenanceLevel: 'Low',
    curbAppeal: 'Very Good (dimensional look)',
    bestFor: 'Budget-conscious homeowners, most residential styles',
    evansvillePopularity: '85% of local installs',
    pros: [
      'Lowest upfront cost of any material',
      'Wide variety of colors and styles',
      'Fast installation — done in 1 day',
      'Easy to repair individual shingles',
      'Backed by strong manufacturer warranties',
      'Compatible with all roof pitches',
    ],
    cons: [
      'Shorter lifespan than premium materials',
      'Susceptible to granule loss over time',
      'Algae growth possible without treatment',
      'Not as energy-efficient as metal',
      'Requires replacement sooner (20–30 years)',
    ],
    description: 'Architectural asphalt shingles are the most popular roofing material in America — and for good reason. They offer an unbeatable combination of affordability, durability, and curb appeal. For Evansville and Henderson KY homes, GAF Timberline HDZ and Owens Corning Duration shingles are our top recommendations, offering 130 mph wind ratings and algae resistance.',
    color: 'orange',
    accentColor: 'text-orange',
  },
  {
    id: 'metal',
    name: 'Metal',
    fullName: 'Standing Seam & Metal Shingles',
    icon: 'ri-home-gear-line',
    tagline: 'The Last Roof You Will Ever Buy',
    image: '/placeholders/900x500.svg',
    costRange: '$16,000 – $35,000',
    costPerSqFt: '$8.00 – $15.00 / sq ft',
    lifespan: '40 – 70 Years',
    warranty: '40+ Years (Manufacturer)',
    laborWarranty: '30 Years (Golden Pledge)',
    weight: 'Light (1.5–3 lbs/sq ft)',
    fireRating: 'Class A',
    windRating: 'Up to 140+ mph',
    hailResistance: 'Excellent (Impact Resistant)',
    energyEfficiency: 'High (reflects heat)',
    maintenanceLevel: 'Very Low',
    curbAppeal: 'Premium (modern or classic)',
    bestFor: 'Long-term homeowners, premium builds, hail-prone areas',
    evansvillePopularity: '8% of local installs',
    pros: [
      '50+ year lifespan — often lasts a lifetime',
      'Best hail and wind resistance available',
      'Reflects heat, reduces cooling costs 10–25%',
      'No moss, algae, or rot issues',
      '100% recyclable at end of life',
      'Increases home resale value significantly',
    ],
    cons: [
      'Higher upfront cost vs. asphalt',
      'Expansion/contraction noise in extreme temp swings',
      'Requires experienced installer for best results',
      'Denting possible from very large hail',
      'Not all styles match traditional home aesthetics',
    ],
    description: 'Metal roofing is the gold standard for durability and longevity. In Indiana, where hail, ice dams, and high winds are common, metal roofs outperform every other material. Standing seam panels offer a sleek, modern look, while metal shingles mimic traditional materials with far superior durability. Expect 40–70 years of worry-free protection.',
    color: 'white',
    accentColor: 'text-white',
  },
  {
    id: 'tile',
    name: 'Tile',
    fullName: 'Clay & Concrete Tile Roofing',
    icon: 'ri-home-4-line',
    tagline: 'Mediterranean Elegance & Strength',
    image: '/placeholders/900x500.svg',
    costRange: '$20,000 – $40,000',
    costPerSqFt: '$10.00 – $18.00 / sq ft',
    lifespan: '50 – 100 Years',
    warranty: '50+ Years (Manufacturer)',
    laborWarranty: '25 Years (Golden Pledge)',
    weight: 'Heavy (6–10 lbs/sq ft)',
    fireRating: 'Class A',
    windRating: 'Up to 150 mph',
    hailResistance: 'Good (concrete) to Fair (clay)',
    energyEfficiency: 'High (natural thermal mass)',
    maintenanceLevel: 'Low',
    curbAppeal: 'Exceptional (unique look)',
    bestFor: 'Mediterranean/Spanish style homes, luxury builds',
    evansvillePopularity: '2% of local installs',
    pros: [
      'Unmatched lifespan — 50 to 100 years',
      'Exceptional fire and insect resistance',
      'Natural thermal insulation reduces energy costs',
      'Distinctive, high-end curb appeal',
      'Low maintenance once installed',
      'Available in clay, concrete, and synthetic',
    ],
    cons: [
      'Very heavy — may require structural reinforcement',
      'Significantly higher upfront cost',
      'Installation is slower and more specialized',
      'Clay tiles can crack under severe impact',
      'Limited color options vs. shingles',
      'Not suitable for low-slope roofs',
    ],
    description: 'Tile roofing brings timeless elegance and unmatched longevity. Clay and concrete tiles are especially popular for Mediterranean, Spanish, and luxury custom homes. While the upfront investment is higher and structural reinforcement may be needed, a tile roof can last a century with minimal maintenance. The natural thermal mass helps regulate indoor temperatures year-round.',
    color: 'white',
    accentColor: 'text-white',
  },
  {
    id: 'slate',
    name: 'Slate',
    fullName: 'Natural Stone Slate Roofing',
    icon: 'ri-vip-crown-line',
    tagline: 'The Ultimate Premium Roof',
    image: '/placeholders/900x500.svg',
    costRange: '$35,000 – $70,000+',
    costPerSqFt: '$18.00 – $35.00 / sq ft',
    lifespan: '75 – 150 Years',
    warranty: 'Limited Lifetime',
    laborWarranty: '30 Years (Golden Pledge)',
    weight: 'Very Heavy (8–15 lbs/sq ft)',
    fireRating: 'Class A',
    windRating: 'Up to 130 mph',
    hailResistance: 'Excellent (natural stone)',
    energyEfficiency: 'Excellent (thermal mass)',
    maintenanceLevel: 'Very Low',
    curbAppeal: 'Unmatched (prestige material)',
    bestFor: 'Historic homes, luxury estates, forever homes',
    evansvillePopularity: '<1% of local installs',
    pros: [
      '75 to 150 year lifespan — truly a lifetime roof',
      'Completely fireproof and insect-proof',
      'Unmatched natural beauty and prestige',
      'Exceptional hail and weather resistance',
      'Increases property value dramatically',
      'Environmentally friendly — 100% natural stone',
    ],
    cons: [
      'Highest upfront cost of any roofing material',
      'Requires reinforced roof structure',
      'Very few qualified installers available',
      'Sourcing and installation take longer',
      'Individual slate replacement is specialized work',
      'Weight requires structural engineering review',
    ],
    description: 'Natural slate is the pinnacle of roofing materials. Quarried from stone, each slate tile is unique, giving your roof a one-of-a-kind appearance that no synthetic material can replicate. With a lifespan of 75–150 years, a slate roof is a generational investment. It is the choice of historic landmarks and luxury estates — and it transforms any home into a statement of permanence and prestige.',
    color: 'white',
    accentColor: 'text-white',
  },
];

const COMPARISON_CATEGORIES = [
  {
    label: 'Cost',
    key: 'costRange' as keyof MaterialData,
    icon: 'ri-price-tag-3-line',
    color: 'text-orange',
  },
  {
    label: 'Cost Per Sq Ft',
    key: 'costPerSqFt' as keyof MaterialData,
    icon: 'ri-money-dollar-circle-line',
    color: 'text-white/50',
  },
  {
    label: 'Lifespan',
    key: 'lifespan' as keyof MaterialData,
    icon: 'ri-timer-line',
    color: 'text-green-400',
  },
  {
    label: 'Manufacturer Warranty',
    key: 'warranty' as keyof MaterialData,
    icon: 'ri-file-shield-2-line',
    color: 'text-white/50',
  },
  {
    label: 'Labor Warranty',
    key: 'laborWarranty' as keyof MaterialData,
    icon: 'ri-shield-check-line',
    color: 'text-white/50',
  },
  {
    label: 'Wind Rating',
    key: 'windRating' as keyof MaterialData,
    icon: 'ri-windy-line',
    color: 'text-white/50',
  },
  {
    label: 'Hail Resistance',
    key: 'hailResistance' as keyof MaterialData,
    icon: 'ri-cloud-windy-line',
    color: 'text-white/50',
  },
  {
    label: 'Fire Rating',
    key: 'fireRating' as keyof MaterialData,
    icon: 'ri-fire-line',
    color: 'text-white/50',
  },
  {
    label: 'Energy Efficiency',
    key: 'energyEfficiency' as keyof MaterialData,
    icon: 'ri-sun-line',
    color: 'text-white/50',
  },
  {
    label: 'Weight',
    key: 'weight' as keyof MaterialData,
    icon: 'ri-weight-line',
    color: 'text-white/50',
  },
  {
    label: 'Maintenance',
    key: 'maintenanceLevel' as keyof MaterialData,
    icon: 'ri-tools-line',
    color: 'text-white/50',
  },
  {
    label: 'Curb Appeal',
    key: 'curbAppeal' as keyof MaterialData,
    icon: 'ri-eye-line',
    color: 'text-white/50',
  },
];

function CostPerYearCalculator() {
  const [sqFt, setSqFt] = useState(2000);

  const getCostPerYear = (material: MaterialData) => {
    const costs: Record<string, { low: number; high: number; years: number }> = {
      asphalt: { low: 9000, high: 18000, years: 27 },
      metal: { low: 16000, high: 35000, years: 55 },
      tile: { low: 20000, high: 40000, years: 75 },
      slate: { low: 35000, high: 70000, years: 100 },
    };
    const c = costs[material.id];
    if (!c) return { low: 0, high: 0 };
    const scale = sqFt / 2000;
    return {
      low: Math.round((c.low * scale) / c.years),
      high: Math.round((c.high * scale) / c.years),
    };
  };

  return (
    <div className="bg-charcoal-mid border border-white/10 p-6 md:p-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 flex items-center justify-center bg-orange/15">
          <i className="ri-calculator-line text-orange text-lg" />
        </div>
        <div>
          <h3 className="font-display text-white text-lg uppercase tracking-wider">Cost Per Year</h3>
          <p className="text-white/40 text-xs">See the true lifetime cost of each material</p>
        </div>
      </div>

      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <label className="text-white/60 text-xs uppercase tracking-wider font-semibold">Your Home Size</label>
          <span className="font-display text-orange text-xl tracking-wider">{sqFt.toLocaleString()} sq ft</span>
        </div>
        <input
          type="range"
          min={1000}
          max={5000}
          step={100}
          value={sqFt}
          onChange={(e) => setSqFt(Number(e.target.value))}
          className="w-full h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-orange"
        />
        <div className="flex justify-between text-white/20 text-xs mt-1">
          <span>1,000 sq ft</span>
          <span>5,000 sq ft</span>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {MATERIALS.map((mat) => {
          const perYear = getCostPerYear(mat);
          return (
            <div key={mat.id} className="border border-white/10 bg-charcoal p-4 text-center">
              <p className="font-display text-white text-sm uppercase tracking-wider mb-1">{mat.name}</p>
              <p className="font-display text-orange text-2xl tracking-wider">${perYear.low}–${perYear.high}</p>
              <p className="text-white/30 text-xs">per year</p>
            </div>
          );
        })}
      </div>

      <p className="text-white/20 text-xs text-center mt-4">
        Calculated as total cost ÷ average lifespan. Does not include maintenance or inflation.
      </p>
    </div>
  );
}

export default function RoofComparisonPage() {
  const navigate = useNavigate();
  const [activeMaterial, setActiveMaterial] = useState<MaterialData>(MATERIALS[0]);
  const [compareMode, setCompareMode] = useState(false);

  const hero = useScrollAnimation();
  const detail = useScrollAnimation({ threshold: 0.05 });
  const table = useScrollAnimation({ threshold: 0.05 });

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roof Material Comparison Evansville Indiana | Asphalt vs Metal vs Tile vs Slate | Corner Stone"
        description="Compare asphalt shingles, metal roofing, tile, and slate side-by-side. See cost per sq ft, lifespan, warranty, wind rating, and energy efficiency for Evansville Indiana homes. Free inspection available. Call 812-213-5997."
        keywords="roof material comparison, asphalt vs metal roofing, tile vs slate roof, roofing material cost Evansville, best roof material Indiana, metal roofing vs shingles, roof lifespan comparison, roof warranty comparison, roofing material guide Evansville"
        canonical="/roof-comparison"
        schema={comparisonSchema}
      />

      {/* ── Hero ── */}
      <section className="relative min-h-[80vh] flex flex-col overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1400x700.svg"
            alt="Roof material comparison Evansville Indiana"
            className="w-full h-full object-cover object-top opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/70 via-charcoal-deep/50 to-charcoal-deep" />
          <div className="absolute inset-0 opacity-[0.025]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '80px 80px' }} />
        </div>

        <div
          ref={hero.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 flex-1 flex flex-col justify-center px-6 md:px-10 lg:px-16 pt-32 md:pt-36 pb-16 anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-wrap items-center gap-3 mb-8">
            <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
              <i className="ri-bar-chart-line text-orange text-sm" />
              Side-by-Side Comparison
            </div>
            <div className="flex items-center gap-2 border border-orange/40 bg-orange/10 backdrop-blur-sm px-4 py-2 text-orange text-xs uppercase tracking-widest">
              <i className="ri-price-tag-3-line text-sm" />
              Evansville Local Pricing
            </div>
          </div>

          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 9vw, 10rem)' }}>
            Find Your<br />Perfect<br /><span className="text-orange">Roof.</span>
          </h1>

          <div className="flex flex-col lg:flex-row lg:items-end gap-8 lg:gap-16">
            <p className="text-white/50 text-base md:text-lg max-w-xl leading-relaxed">
              Compare asphalt shingles, metal, tile, and slate side-by-side. See real costs, lifespans, warranties, and performance ratings tailored for Evansville and Henderson KY homes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 flex-shrink-0">
              <button
                onClick={() => navigate('/free-inspection')}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <i className="ri-search-eye-line" />
                Get Free Inspection
              </button>
              <a
                href="tel:8122135997"
                className="border border-white/30 hover:border-orange text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-phone-line text-orange" />
                812-213-5997
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ── Material Toggles ── */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-10">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">Compare Materials</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Select a Material to Explore
          </h2>
        </div>

        <div className="flex flex-wrap justify-center gap-3 mb-8">
          {MATERIALS.map((mat) => (
            <button
              key={mat.id}
              onClick={() => {
                setActiveMaterial(mat);
                setCompareMode(false);
              }}
              className={`flex items-center gap-2.5 px-5 py-3 border transition-all duration-300 cursor-pointer whitespace-nowrap ${
                activeMaterial.id === mat.id && !compareMode
                  ? 'border-orange bg-orange/10 text-orange'
                  : 'border-white/10 bg-charcoal-mid text-white/50 hover:border-white/30 hover:text-white/80'
              }`}
            >
              <i className={`${mat.icon} text-base`} />
              <span className="text-sm font-semibold uppercase tracking-wider">{mat.name}</span>
            </button>
          ))}
          <button
            onClick={() => setCompareMode(true)}
            className={`flex items-center gap-2.5 px-5 py-3 border transition-all duration-300 cursor-pointer whitespace-nowrap ${
              compareMode
                ? 'border-orange bg-orange/10 text-orange'
                : 'border-white/10 bg-charcoal-mid text-white/50 hover:border-white/30 hover:text-white/80'
            }`}
          >
            <i className="ri-table-line text-base" />
            <span className="text-sm font-semibold uppercase tracking-wider">Full Comparison</span>
          </button>
        </div>

        {/* ── Individual Material Detail ── */}
        {!compareMode && (
          <div
            ref={detail.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${detail.isVisible ? 'is-visible' : ''}`}
          >
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
              {/* Left: Image + Quick Stats */}
              <div>
                <div className="relative w-full overflow-hidden mb-6" style={{ height: '320px' }}>
                  <img
                    src={activeMaterial.image}
                    alt={activeMaterial.fullName}
                    className="w-full h-full object-cover object-top"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-charcoal-deep/80 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-xs font-bold uppercase tracking-widest bg-orange text-white px-3 py-1">
                        {activeMaterial.tagline}
                      </span>
                    </div>
                    <h3 className="font-display text-white text-3xl uppercase tracking-wider">{activeMaterial.fullName}</h3>
                  </div>
                </div>

                {/* Quick stat cards */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-charcoal-mid border border-white/10 p-4 text-center">
                    <p className="font-display text-orange text-2xl tracking-wider">{activeMaterial.lifespan.split('–')[0].trim()}</p>
                    <p className="text-white/30 text-xs uppercase tracking-wider mt-1">Min Lifespan</p>
                  </div>
                  <div className="bg-charcoal-mid border border-white/10 p-4 text-center">
                    <p className="font-display text-orange text-2xl tracking-wider">{activeMaterial.lifespan.split('–')[1]?.trim() || activeMaterial.lifespan}</p>
                    <p className="text-white/30 text-xs uppercase tracking-wider mt-1">Max Lifespan</p>
                  </div>
                  <div className="bg-charcoal-mid border border-white/10 p-4 text-center">
                    <p className="font-display text-orange text-2xl tracking-wider">{activeMaterial.evensvillePopularity.replace(/[^0-9<>]/g, '') || '<1%'}</p>
                    <p className="text-white/30 text-xs uppercase tracking-wider mt-1">Local Share</p>
                  </div>
                </div>
              </div>

              {/* Right: Details */}
              <div className="flex flex-col gap-5">
                <div className="bg-charcoal-mid border border-white/10 p-6">
                  <h4 className="font-display text-white text-lg uppercase tracking-wider mb-3">Overview</h4>
                  <p className="text-white/50 text-sm leading-relaxed">{activeMaterial.description}</p>
                </div>

                <div className="bg-charcoal-mid border border-white/10 p-6">
                  <h4 className="font-display text-white text-lg uppercase tracking-wider mb-3">Cost Breakdown</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-white/50 text-sm">Total Project Range</span>
                      <span className="font-display text-white text-xl tracking-wider">{activeMaterial.costRange}</span>
                    </div>
                    <div className="w-full h-px bg-white/10" />
                    <div className="flex items-center justify-between">
                      <span className="text-white/50 text-sm">Per Square Foot</span>
                      <span className="font-display text-orange text-lg tracking-wider">{activeMaterial.costPerSqFt}</span>
                    </div>
                    <div className="w-full h-px bg-white/10" />
                    <div className="flex items-center justify-between">
                      <span className="text-white/50 text-sm">Warranty</span>
                      <span className="text-white text-sm">{activeMaterial.warranty}</span>
                    </div>
                    <div className="w-full h-px bg-white/10" />
                    <div className="flex items-center justify-between">
                      <span className="text-white/50 text-sm">Labor Warranty</span>
                      <span className="text-white text-sm">{activeMaterial.laborWarranty}</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-charcoal-mid border border-white/10 p-5">
                    <div className="flex items-center gap-2 mb-3">
                      <i className="ri-thumb-up-line text-green-400 text-lg" />
                      <h4 className="font-display text-white text-sm uppercase tracking-wider">Pros</h4>
                    </div>
                    <ul className="space-y-2">
                      {activeMaterial.pros.map((pro) => (
                        <li key={pro} className="flex items-start gap-2 text-white/50 text-xs leading-relaxed">
                          <i className="ri-check-line text-green-400 text-sm mt-0.5 flex-shrink-0" />
                          {pro}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="bg-charcoal-mid border border-white/10 p-5">
                    <div className="flex items-center gap-2 mb-3">
                      <i className="ri-thumb-down-line text-red-400 text-lg" />
                      <h4 className="font-display text-white text-sm uppercase tracking-wider">Cons</h4>
                    </div>
                    <ul className="space-y-2">
                      {activeMaterial.cons.map((con) => (
                        <li key={con} className="flex items-start gap-2 text-white/50 text-xs leading-relaxed">
                          <i className="ri-close-line text-red-400 text-sm mt-0.5 flex-shrink-0" />
                          {con}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="bg-charcoal-mid border border-white/10 p-5">
                  <h4 className="font-display text-white text-sm uppercase tracking-wider mb-3">Performance Ratings</h4>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { label: 'Wind Resistance', value: activeMaterial.windRating, icon: 'ri-windy-line' },
                      { label: 'Hail Resistance', value: activeMaterial.hailResistance, icon: 'ri-cloud-windy-line' },
                      { label: 'Fire Rating', value: activeMaterial.fireRating, icon: 'ri-fire-line' },
                      { label: 'Energy Efficiency', value: activeMaterial.energyEfficiency, icon: 'ri-sun-line' },
                      { label: 'Maintenance', value: activeMaterial.maintenanceLevel, icon: 'ri-tools-line' },
                      { label: 'Weight', value: activeMaterial.weight, icon: 'ri-weight-line' },
                    ].map((item) => (
                      <div key={item.label} className="flex items-center gap-2.5">
                        <div className="w-7 h-7 flex items-center justify-center bg-orange/10 flex-shrink-0">
                          <i className={`${item.icon} text-orange text-xs`} />
                        </div>
                        <div>
                          <p className="text-white/30 text-xs">{item.label}</p>
                          <p className="text-white text-xs font-medium">{item.value}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-3">
                  <button
                    onClick={() => navigate('/free-inspection')}
                    className="flex-1 bg-orange hover:bg-orange-dark text-white font-semibold py-3.5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                  >
                    <i className="ri-calendar-line" />
                    Book Free Inspection
                  </button>
                  <a
                    href="tel:8122135997"
                    className="flex-1 border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold py-3.5 uppercase tracking-widest text-sm transition-all whitespace-nowrap flex items-center justify-center gap-2"
                  >
                    <i className="ri-phone-line text-orange" />
                    Call for Quote
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── Full Comparison Table ── */}
        {compareMode && (
          <div
            ref={table.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${table.isVisible ? 'is-visible' : ''}`}
          >
            <div className="overflow-x-auto -mx-4 px-4">
              <div className="min-w-[800px]">
                {/* Header row */}
                <div className="grid grid-cols-[200px_1fr_1fr_1fr_1fr] gap-0 mb-2">
                  <div className="px-4 py-3" />
                  {MATERIALS.map((mat) => (
                    <div key={mat.id} className="px-4 py-3 text-center border border-white/10 bg-charcoal-mid">
                      <div className="flex items-center justify-center gap-2 mb-1">
                        <i className={`${mat.icon} text-orange text-base`} />
                        <span className="font-display text-white text-sm uppercase tracking-wider">{mat.name}</span>
                      </div>
                      <p className="text-white/30 text-xs">{mat.tagline}</p>
                    </div>
                  ))}
                </div>

                {/* Comparison rows */}
                <div className="border border-white/10">
                  {COMPARISON_CATEGORIES.map((cat, i) => (
                    <div
                      key={cat.label}
                      className={`grid grid-cols-[200px_1fr_1fr_1fr_1fr] gap-0 border-b border-white/10 last:border-0 transition-colors duration-200 hover:bg-white/[0.02] ${
                        i % 2 === 0 ? 'bg-transparent' : 'bg-white/[0.015]'
                      }`}
                    >
                      <div className="px-4 py-4 flex items-center gap-2.5 border-r border-white/5">
                        <div className="w-6 h-6 flex items-center justify-center">
                          <i className={`${cat.icon} text-orange text-xs`} />
                        </div>
                        <span className="text-white/70 text-sm font-medium">{cat.label}</span>
                      </div>
                      {MATERIALS.map((mat) => (
                        <div key={mat.id} className="px-4 py-4 text-center border-l border-white/10">
                          <span className={`text-sm ${cat.label === 'Cost' || cat.label === 'Lifespan' ? 'font-display text-lg tracking-wider' : ''} ${cat.label === 'Cost' ? 'text-orange' : 'text-white/70'}`}>
                            {mat[cat.key] as string}
                          </span>
                        </div>
                      ))}
                    </div>
                  ))}
                </div>

                {/* Best for row */}
                <div className="grid grid-cols-[200px_1fr_1fr_1fr_1fr] gap-0 border border-white/10 border-t-0 bg-charcoal-mid">
                  <div className="px-4 py-4 flex items-center gap-2.5 border-r border-white/5">
                    <div className="w-6 h-6 flex items-center justify-center">
                      <i className="ri-home-smile-line text-orange text-xs" />
                    </div>
                    <span className="text-white/70 text-sm font-medium">Best For</span>
                  </div>
                  {MATERIALS.map((mat) => (
                    <div key={mat.id} className="px-4 py-4 text-center border-l border-white/10">
                      <span className="text-white/50 text-xs leading-relaxed">{mat.bestFor}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <p className="text-white/20 text-xs text-center mt-4">
              Pricing reflects Evansville Indiana and Henderson KY area installation costs as of 2026. Actual quotes vary by home size, pitch, and complexity.
            </p>
          </div>
        )}
      </section>

      {/* ── Cost Per Year Calculator ── */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">True Lifetime Value</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Cost Per Year of Ownership
            </h2>
            <p className="text-white/40 text-sm mt-3 max-w-lg mx-auto">
              A slate roof costs more upfront, but over 75 years it's the cheapest per year. See how each material stacks up for your home size.
            </p>
          </div>
          <CostPerYearCalculator />
        </div>
      </section>

      {/* ── Quick Decision Guide ── */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-12">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">Quick Guide</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Which Roof Is Right for You?
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 max-w-5xl mx-auto">
          {[
            {
              material: 'Asphalt Shingles',
              icon: 'ri-home-2-line',
              scenario: 'Budget-Conscious Homeowner',
              answer: 'You want the best value for your dollar. Architectural shingles look great, last 25–30 years, and cost the least upfront. This is what 85% of Evansville homes have.',
              cta: 'Get Asphalt Quote',
            },
            {
              material: 'Metal Roofing',
              icon: 'ri-home-gear-line',
              scenario: 'Long-Term Thinker',
              answer: 'You plan to stay in your home 15+ years and want to never worry about your roof again. Metal costs more now but saves you a full replacement later.',
              cta: 'Get Metal Quote',
            },
            {
              material: 'Clay or Concrete Tile',
              icon: 'ri-home-4-line',
              scenario: 'Style-First Owner',
              answer: 'You want a distinctive, luxury look that sets your home apart. Tile lasts 50–100 years and brings Mediterranean elegance to any property.',
              cta: 'Get Tile Quote',
            },
            {
              material: 'Natural Slate',
              icon: 'ri-vip-crown-line',
              scenario: 'Forever Home Builder',
              answer: 'This is your forever home and you want the absolute best. Slate lasts a century, increases property value, and is unmatched in prestige.',
              cta: 'Get Slate Quote',
            },
          ].map((card) => (
            <div key={card.material} className="border border-white/10 bg-charcoal-mid p-6 hover:border-orange/30 transition-all duration-300 flex flex-col">
              <div className="w-12 h-12 flex items-center justify-center bg-orange/15 mb-4">
                <i className={`${card.icon} text-orange text-xl`} />
              </div>
              <p className="text-white/30 text-xs uppercase tracking-widest mb-1">{card.scenario}</p>
              <h4 className="font-display text-white text-lg uppercase tracking-wider mb-3">{card.material}</h4>
              <p className="text-white/50 text-sm leading-relaxed mb-5 flex-1">{card.answer}</p>
              <button
                onClick={() => navigate('/estimate')}
                className="w-full border border-white/20 hover:border-orange text-white/60 hover:text-orange text-xs font-semibold py-2.5 uppercase tracking-widest transition-all whitespace-nowrap cursor-pointer"
              >
                {card.cta}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* ── Indiana Weather Context ── */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <div>
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Built for Indiana</p>
              <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 4vw, 3rem)' }}>
                Which Material<br />Handles Our<br />Weather Best?
              </h2>
              <p className="text-white/50 text-sm leading-relaxed mb-6">
                Evansville and Henderson KY get everything — hail, high winds, ice dams, extreme heat, and heavy rain. Here's how each material performs against our biggest weather threats:
              </p>
              <div className="space-y-4">
                {[
                  { threat: 'Hail Damage', best: 'Metal & Slate', good: 'Architectural Shingles', poor: '3-Tab Shingles' },
                  { threat: 'High Winds (70+ mph)', best: 'Metal & Tile', good: 'GAF Timberline HDZ', poor: 'Standard Shingles' },
                  { threat: 'Ice Dams', best: 'Metal (sheds snow)', good: 'Properly installed shingles', poor: 'Low-quality installs' },
                  { threat: 'Heat & UV Exposure', best: 'Metal (reflective)', good: 'Algae-resistant shingles', poor: 'Basic 3-tab shingles' },
                ].map((row) => (
                  <div key={row.threat} className="border border-white/10 bg-charcoal-mid p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-white text-sm font-semibold">{row.threat}</span>
                      <span className="text-orange text-xs font-bold uppercase tracking-wider">Best: {row.best}</span>
                    </div>
                    <div className="flex items-center gap-4 text-white/40 text-xs">
                      <span>Good: {row.good}</span>
                      <span className="text-white/10">|</span>
                      <span className="text-white/25">Avoid: {row.poor}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-charcoal-mid border border-white/10 p-8">
              <h4 className="font-display text-white text-lg uppercase tracking-wider mb-4">Our Recommendation</h4>
              <p className="text-white/50 text-sm leading-relaxed mb-5">
                For <strong className="text-white/70">90% of Evansville and Henderson KY homeowners</strong>, we recommend <strong className="text-orange">GAF Timberline HDZ architectural shingles</strong>. Here's why:
              </p>
              <ul className="space-y-3 mb-6">
                {[
                  '130 mph wind rating — handles Indiana storms',
                  'Hail impact resistance (Class 4 option available)',
                  'Algae-resistant — no ugly black streaks',
                  'Lifetime Limited Warranty from GAF',
                  'Golden Pledge labor warranty available',
                  'Best bang for your buck in the Tri-State',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2 text-white/50 text-sm">
                    <i className="ri-check-line text-orange text-sm mt-0.5 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => navigate('/free-inspection')}
                className="w-full bg-orange hover:bg-orange-dark text-white font-semibold py-3.5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
              >
                <i className="ri-search-eye-line" />
                Get Free Shingle Inspection
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ── Bottom CTA ── */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16">
        <div className="border border-white/10 bg-charcoal-mid p-10 md:p-14 text-center">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Still Unsure?</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            We'll Inspect Your Roof<br />and Recommend the Best Material
          </h2>
          <p className="text-white/40 text-sm max-w-lg mx-auto leading-relaxed mb-8">
            Every home is different — roof pitch, structure, sun exposure, and neighborhood style all matter. Our free inspection includes a personalized material recommendation based on your specific situation.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigate('/free-inspection')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-calendar-check-line" />
              Book Free Inspection
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>
      </section>

    </div>
  );
}