import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';

const sections = [
  {
    title: 'Information We Collect',
    content: [
      'When you request a free estimate, contact us, or submit a form on our website, we collect information you provide directly — including your name, email address, phone number, home address, and details about your roofing project.',
      'We also automatically collect certain technical information when you visit our site, including your IP address, browser type, pages visited, and time spent on pages. This is collected through Google Analytics (GA4) to help us understand how visitors use our site.',
      'We do not collect payment information directly. Any payment processing is handled by secure third-party processors.',
    ],
  },
  {
    title: 'How We Use Your Information',
    content: [
      'To respond to your estimate requests, service inquiries, and contact form submissions.',
      'To schedule inspections, appointments, and follow-up communications related to your roofing project.',
      'To send you relevant updates, storm alerts, and roofing tips if you have subscribed to our newsletter. You may unsubscribe at any time.',
      'To improve our website and services using aggregated, anonymized analytics data.',
      'We do not sell, rent, or trade your personal information to third parties for marketing purposes.',
    ],
  },
  {
    title: 'Cookies & Tracking',
    content: [
      'Our website uses cookies to enhance your browsing experience and collect analytics data. Cookies are small text files stored on your device.',
      'We use Google Analytics cookies to understand site traffic and user behavior. This data is aggregated and anonymized.',
      'You can control cookie settings through your browser preferences. Disabling cookies may affect some website functionality.',
      'We also use Google Tag Manager to manage tracking scripts on our site.',
    ],
  },
  {
    title: 'Information Sharing',
    content: [
      'We may share your information with trusted service providers who assist us in operating our website and conducting our business — such as email service providers and scheduling software — under strict confidentiality agreements.',
      'We may disclose your information if required by law, court order, or governmental authority.',
      'In the event of a business merger or acquisition, your information may be transferred as part of that transaction.',
      'We never sell your personal data to advertisers or data brokers.',
    ],
  },
  {
    title: 'Data Security',
    content: [
      'We implement industry-standard security measures to protect your personal information from unauthorized access, alteration, disclosure, or destruction.',
      'All form submissions on our website are transmitted over encrypted HTTPS connections.',
      'While we take reasonable precautions, no method of transmission over the internet is 100% secure. We cannot guarantee absolute security.',
    ],
  },
  {
    title: 'Your Rights',
    content: [
      'You have the right to request access to the personal information we hold about you.',
      'You may request correction of inaccurate information or deletion of your data, subject to certain legal obligations.',
      'You may opt out of marketing communications at any time by clicking "unsubscribe" in any email or contacting us directly.',
      'To exercise any of these rights, contact us at themainstoneconstruction@gmail.com.',
    ],
  },
  {
    title: 'Third-Party Links',
    content: [
      'Our website may contain links to third-party websites, including Google Maps, Google Business Profile, and manufacturer websites. We are not responsible for the privacy practices of those sites.',
      'We encourage you to review the privacy policies of any third-party sites you visit.',
    ],
  },
  {
    title: 'Children\'s Privacy',
    content: [
      'Our website is not directed to children under the age of 13. We do not knowingly collect personal information from children.',
      'If you believe we have inadvertently collected information from a child, please contact us immediately.',
    ],
  },
  {
    title: 'Changes to This Policy',
    content: [
      'We may update this Privacy Policy from time to time. The "Last Updated" date at the top of this page will reflect any changes.',
      'We encourage you to review this policy periodically. Continued use of our website after changes constitutes acceptance of the updated policy.',
    ],
  },
  {
    title: 'Contact Us',
    content: [
      'If you have questions or concerns about this Privacy Policy or how we handle your data, please contact us:',
      'Corner Stone Construction & Roofing\n5800 Kansas Rd, Evansville, IN 47725\nPhone: 812-213-5997\nEmail: themainstoneconstruction@gmail.com',
    ],
  },
];

export default function PrivacyPolicyPage() {
  const navigate = useNavigate();

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, []);

  return (
    <div className="min-h-screen bg-charcoal-deep">

      {/* Hero */}
      <section className="pt-32 pb-16 px-6 md:px-10 lg:px-16 border-b border-white/10">
        <div className="max-w-4xl">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Legal</p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Privacy Policy
          </h1>
          <p className="text-white/40 text-sm md:text-base leading-relaxed max-w-2xl">
            Corner Stone Construction &amp; Roofing is committed to protecting your privacy. This policy explains how we collect, use, and safeguard your personal information.
          </p>
          <p className="text-white/25 text-xs mt-5 uppercase tracking-widest">Last Updated: April 29, 2026</p>
        </div>
      </section>

      {/* Content */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16">
        <div className="max-w-4xl space-y-12">
          {sections.map((section, i) => (
            <div key={section.title} className="border-b border-white/5 pb-12 last:border-0">
              <div className="flex items-start gap-5 mb-5">
                <span className="font-display text-orange/40 text-2xl tracking-wider leading-none mt-1 flex-shrink-0">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <h2 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider">{section.title}</h2>
              </div>
              <div className="pl-12 space-y-4">
                {section.content.map((para, j) => (
                  <p key={j} className="text-white/50 text-sm md:text-base leading-relaxed whitespace-pre-line">{para}</p>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-6 md:px-10 lg:px-16 bg-charcoal border-t border-white/10">
        <div className="max-w-4xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div>
            <p className="text-white font-semibold mb-1">Questions about your data?</p>
            <p className="text-white/40 text-sm">We're happy to help. Reach out anytime.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3">
            <a
              href="mailto:themainstoneconstruction@gmail.com"
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-7 py-3 uppercase tracking-widest text-xs transition-colors whitespace-nowrap text-center"
            >
              Email Us
            </a>
            <button
              onClick={() => navigate('/')}
              className="border border-white/20 hover:border-white text-white font-semibold px-7 py-3 uppercase tracking-widest text-xs transition-colors whitespace-nowrap cursor-pointer"
            >
              Back to Home
            </button>
          </div>
        </div>
      </section>

    </div>
  );
}
