import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { OFFERS } from '@/mocks/promotions';
import CompleteExteriorEstimator from '@/components/feature/CompleteExteriorEstimator';
import ExteriorFinancingCalculator from '@/components/feature/ExteriorFinancingCalculator';
import CompetitorComparisonTool from '@/components/feature/CompetitorComparisonTool';
import PriceMatchBanner from '@/components/feature/PriceMatchBanner';
import { trackOfferView } from '@/pages/promotions/components/RecentlyViewedOffers';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const packageSchema = {
  '@context': 'https://schema.org',
  '@type': 'Service',
  name: 'Complete Exterior Renovation Package Evansville Indiana',
  provider: {
    '@type': 'RoofingContractor',
    name: 'Corner Stone Construction & Roofing',
    telephone: '+1-812-213-5997',
    address: {
      '@type': 'PostalAddress',
      streetAddress: '5800 Kansas Rd',
      addressLocality: 'Evansville',
      addressRegion: 'IN',
      postalCode: '47725',
    },
  },
  areaServed: ['Evansville IN', 'Henderson KY', 'Newburgh IN', 'Owensboro KY', 'Tri-State Area'],
  description: 'Complete exterior renovation packages in Evansville Indiana. Roof replacement, siding installation, and gutter systems bundled together for maximum savings. One crew, one visit, one warranty. Free estimates — call 812-213-5997.',
};

const PACKAGE_TIERS = [
  {
    id: 'essential',
    name: 'Essential Package',
    tagline: 'Roof + Gutters',
    price: 'From $12,000',
    savings: 'Save $400–$700',
    color: 'border-white/20',
    highlight: false,
    includes: [
      { icon: 'ri-home-4-line', item: 'Full Roof Replacement', detail: 'Architectural shingles, 30-yr warranty' },
      { icon: 'ri-water-flash-line', item: 'Seamless Gutter System', detail: 'Custom-fabricated aluminum, 30+ colors' },
      { icon: 'ri-shield-check-line', item: 'Lifetime Workmanship Warranty', detail: 'On all labor' },
      { icon: 'ri-search-eye-line', item: 'Free Storm Damage Inspection', detail: 'Insurance claim assistance included' },
    ],
    notIncluded: ['Siding Replacement', 'Exterior Trim Work'],
  },
  {
    id: 'complete',
    name: 'Complete Package',
    tagline: 'Roof + Siding + Gutters',
    price: 'From $22,000',
    savings: 'Save $800–$2,000',
    color: 'border-orange',
    highlight: true,
    includes: [
      { icon: 'ri-home-4-line', item: 'Full Roof Replacement', detail: 'Architectural shingles or metal, full warranty' },
      { icon: 'ri-layout-masonry-line', item: 'Full Siding Replacement', detail: 'Vinyl or James Hardie fiber cement' },
      { icon: 'ri-water-flash-line', item: 'Seamless Gutter System', detail: 'Custom-fabricated with gutter guards option' },
      { icon: 'ri-scissors-cut-line', item: 'Exterior Trim & Fascia', detail: 'Matching trim throughout' },
      { icon: 'ri-shield-check-line', item: 'Lifetime Workmanship Warranty', detail: 'On all labor, all trades' },
      { icon: 'ri-file-shield-2-line', item: 'Full Insurance Claim Handling', detail: 'We manage the entire process' },
    ],
    notIncluded: [],
  },
  {
    id: 'premium',
    name: 'Premium Package',
    tagline: 'Metal Roof + Hardie + Copper Gutters',
    price: 'From $45,000',
    savings: 'Save $2,000–$4,000',
    color: 'border-white/20',
    highlight: false,
    includes: [
      { icon: 'ri-home-4-line', item: 'Standing Seam Metal Roof', detail: '50-year warranty, lifetime performance' },
      { icon: 'ri-layout-masonry-line', item: 'James Hardie Fiber Cement Siding', detail: '30-year warranty, ColorPlus finish' },
      { icon: 'ri-water-flash-line', item: 'Copper Gutter System', detail: 'Soldered joints, 50–100 year lifespan' },
      { icon: 'ri-scissors-cut-line', item: 'Premium Exterior Trim Package', detail: 'Full fascia, soffit, and trim replacement' },
      { icon: 'ri-shield-check-line', item: 'Lifetime Workmanship Warranty', detail: 'On all labor, all trades' },
      { icon: 'ri-file-shield-2-line', item: 'Dedicated Project Manager', detail: 'Single point of contact throughout' },
    ],
    notIncluded: [],
  },
];

const SAVINGS_BREAKDOWN = [
  { label: 'Roof Replacement (standalone)', cost: '$14,500', note: 'Typical 2,000 sq ft home' },
  { label: 'Siding Replacement (standalone)', cost: '$11,000', note: 'Vinyl, typical home' },
  { label: 'Gutter Replacement (standalone)', cost: '$1,800', note: 'Seamless aluminum, 150 LF' },
  { label: 'Separate Mobilizations (×3)', cost: '$1,200', note: 'Setup, cleanup, scheduling' },
  { label: 'Total if Done Separately', cost: '$28,500', note: '', highlight: true },
  { label: 'Complete Package Price', cost: '$22,000–$26,000', note: 'One crew, one visit', highlight: true, orange: true },
];

const WHY_BUNDLE = [
  {
    icon: 'ri-money-dollar-circle-line',
    title: 'Save $800–$2,000',
    desc: 'One mobilization, one crew, one cleanup. You avoid paying three separate setup fees and get a bundled discount on materials ordered together.',
  },
  {
    icon: 'ri-calendar-check-line',
    title: 'One Visit, Done',
    desc: 'No scheduling three separate contractors over three separate weeks. We coordinate everything — roof, siding, and gutters — in a single project window.',
  },
  {
    icon: 'ri-shield-check-line',
    title: 'Single Warranty',
    desc: 'One company, one warranty, one phone number. No finger-pointing between contractors if something needs attention down the road.',
  },
  {
    icon: 'ri-home-gear-line',
    title: 'Perfect Coordination',
    desc: 'Roof, siding, and gutters are installed in the right sequence by the same crew — no gaps, no mismatched trim, no rework.',
  },
  {
    icon: 'ri-file-shield-2-line',
    title: 'One Insurance Claim',
    desc: 'Storm damage often hits roof, siding, and gutters simultaneously. We file one comprehensive claim covering all three — maximizing your payout.',
  },
  {
    icon: 'ri-paint-brush-line',
    title: 'Perfectly Matched Aesthetics',
    desc: 'Roof color, siding profile, gutter color — all chosen together for a cohesive look. No mismatched materials from different contractors.',
  },
];

const PROCESS_STEPS = [
  {
    num: '01',
    icon: 'ri-search-eye-line',
    title: 'Free Full Exterior Inspection',
    desc: 'We inspect roof, siding, gutters, fascia, and trim in one visit. We document everything — including storm damage for insurance purposes.',
  },
  {
    num: '02',
    icon: 'ri-file-list-3-line',
    title: 'Single Bundled Quote',
    desc: 'One written quote covering all three trades. You see exactly what each component costs and the total bundle savings clearly itemized.',
  },
  {
    num: '03',
    icon: 'ri-file-shield-2-line',
    title: 'Insurance Handled (If Applicable)',
    desc: 'If storm damage is involved, we file a single comprehensive claim for roof, siding, and gutters — maximizing your insurance payout.',
  },
  {
    num: '04',
    icon: 'ri-tools-line',
    title: 'One Crew, One Visit',
    desc: 'Our coordinated crew handles roof first, then siding, then gutters — in the right sequence. Most complete packages finish in 3–7 days.',
  },
  {
    num: '05',
    icon: 'ri-checkbox-circle-line',
    title: 'Final Walkthrough & Warranty',
    desc: 'We walk every inch of your exterior with you. You get a single warranty document covering all work. One call if anything ever needs attention.',
  },
];

const FAQS = [
  {
    q: 'How much does a complete exterior renovation cost in Evansville Indiana?',
    a: 'A complete exterior package (roof + siding + gutters) for a typical 2,000 sq ft Evansville home runs $22,000–$32,000 depending on materials chosen. Vinyl siding with architectural shingles is at the lower end; James Hardie with metal roofing is at the higher end. We provide free itemized quotes with no obligation.',
  },
  {
    q: 'How long does a complete exterior renovation take?',
    a: 'Most complete packages take 3–7 days depending on home size and material complexity. We work in the correct sequence — roof first, then siding, then gutters — so each trade is done right without rework. We clean up daily and never leave your home exposed overnight.',
  },
  {
    q: 'Can I use insurance to pay for a complete exterior package?',
    a: 'If your home sustained storm damage, yes — often significantly. Hail and wind events in Indiana frequently damage roof, siding, and gutters simultaneously. We file one comprehensive claim covering all three trades, which often results in a much larger payout than filing separately. Many homeowners get the entire package covered minus their deductible.',
  },
  {
    q: 'Do I have to do all three at once, or can I phase it?',
    a: 'You can absolutely phase it — but you\'ll save more by doing it together. If your roof is urgent but siding can wait, we\'ll tell you honestly. If all three are near end of life or storm-damaged, bundling is almost always the smarter financial decision. We\'ll give you a straight comparison in your quote.',
  },
  {
    q: 'What siding and roofing materials are included in the packages?',
    a: 'Our Essential and Complete packages use premium architectural asphalt shingles (GAF or Owens Corning) and vinyl siding as the base. You can upgrade to metal roofing, James Hardie fiber cement siding, or copper gutters at any tier. We\'ll walk you through all options and their cost differences during your free estimate.',
  },
  {
    q: 'Do you offer financing on complete exterior packages?',
    a: 'Yes. We offer financing through GreenSky, Synchrony, and EnerBank — including 0% interest options for qualified buyers. Monthly payments on a $25,000 package can be as low as $180/month. Ask about financing options during your free estimate.',
  },
];

const now = new Date();
const nearestExpiry = [...OFFERS]
  .filter((o) => o.expires && new Date(o.expires) > now)
  .sort((a, b) => new Date(a.expires).getTime() - new Date(b.expires).getTime())[0];

export default function ExteriorPackagePage() {
  const navigate = useNavigate();
  const [activePackage, setActivePackage] = useState('complete');
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [charCount, setCharCount] = useState(0);
  const formRef = useRef<HTMLFormElement>(null);

  const hero = useScrollAnimation();
  const packages = useScrollAnimation({ threshold: 0.05 });
  const savings = useScrollAnimation({ threshold: 0.1 });
  const why = useScrollAnimation({ threshold: 0.1 });
  const process = useScrollAnimation({ threshold: 0.1 });
  const faqAnim = useScrollAnimation({ threshold: 0.1 });
  const formAnim = useScrollAnimation({ threshold: 0.1 });

  const openReaddyAgent = (prefill?: string) => {
    const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
    if (btn) btn.click();
    if (prefill) {
      setTimeout(() => {
        const input = document.querySelector('input[placeholder*="message"], textarea[placeholder*="message"], input[placeholder*="ask"], textarea[placeholder*="ask"]') as HTMLInputElement | HTMLTextAreaElement | null;
        if (input) {
          input.value = prefill;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          const form = input.closest('form');
          if (form) {
            const submitBtn = form.querySelector('button[type="submit"], button[aria-label*="send"], button svg') as HTMLElement | null;
            if (submitBtn) submitBtn.click();
          }
        }
      }, 900);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;
    const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
    const notes = formData.get('notes') as string;
    if (notes && notes.length > 500) return;
    setFormStatus('submitting');
    try {
      const res = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      if (res.ok) { setFormStatus('success'); formRef.current.reset(); setCharCount(0); }
      else setFormStatus('error');
    } catch { setFormStatus('error'); }
  };

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Complete Exterior Renovation Evansville Indiana | Roof + Siding + Gutters | Corner Stone"
        description="Bundle your roof replacement, siding installation, and gutter system in one visit and save $800–$2,000. Complete exterior renovation packages in Evansville IN and Henderson KY. One crew, one warranty. Free estimates — call 812-213-5997."
        keywords="full exterior renovation Evansville Indiana, roof siding gutters bundle Evansville, complete exterior package Indiana, exterior renovation contractor Evansville, roof replacement siding gutters Henderson KY"
        canonical="/exterior-package"
        schema={packageSchema}
      />

      {/* ── Hero ── */}
      <section className="relative min-h-screen flex flex-col overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1400x900.svg"
            alt="Complete exterior renovation Evansville Indiana"
            className="w-full h-full object-cover object-top opacity-35"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/60 via-charcoal-deep/40 to-charcoal-deep" />
          <div className="absolute inset-0 opacity-[0.025]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '80px 80px' }} />
        </div>

        <div
          ref={hero.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 flex-1 flex flex-col justify-center px-6 md:px-10 lg:px-16 pt-32 md:pt-36 pb-16 anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-wrap items-center gap-3 mb-8">
            <div className="flex items-center gap-2 border border-orange/40 bg-orange/10 backdrop-blur-sm px-4 py-2 text-orange text-xs uppercase tracking-widest">
              <i className="ri-money-dollar-circle-line text-sm" />
              Save $800–$2,000 vs. Separate Contractors
            </div>
            <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange" />
              One Crew. One Visit. One Warranty.
            </div>
          </div>

          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 8vw, 9rem)' }}>
            Roof. Siding.<br />Gutters.<br /><span className="text-orange">All at Once.</span>
          </h1>

          <div className="flex flex-col lg:flex-row lg:items-end gap-8 lg:gap-16">
            <p className="text-white/50 text-base md:text-lg max-w-xl leading-relaxed">
              Evansville's complete exterior renovation specialists. Bundle your roof, siding, and gutters into one coordinated project — save thousands, skip the scheduling headaches, and get a perfectly matched exterior in one visit.
            </p>
            <div className="flex flex-col gap-4 flex-shrink-0">
              {/* Urgency Stack */}
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-shrink-0">
                  <CountdownTimer
                    expiresAt={nearestExpiry ? nearestExpiry.expires : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()}
                    variant="card"
                  />
                </div>
                <SocialProofPulse />
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => document.getElementById('package-form')?.scrollIntoView({ behavior: 'smooth' })}
                  className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
                >
                  <i className="ri-file-list-3-line" />
                  Get Bundle Quote
                </button>
                <a
                  href="tel:8122135997"
                  className="border border-white/30 hover:border-orange text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap flex items-center gap-2"
                >
                  <i className="ri-phone-line text-orange" />
                  812-213-5997
                </a>
              </div>
            </div>
          </div>
          {/* AI Trigger */}
          <div className="mt-6 flex items-center gap-3">
            <button
              onClick={() => openReaddyAgent("How much do I save by bundling roof, siding, and gutters?")}
              className="group flex items-center gap-2 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-question-answer-line text-sm" />
              <span className="underline underline-offset-2">Ask AI about bundle savings</span>
              <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        </div>

        {/* Bottom stats */}
        <div className="relative z-10 border-t border-white/10 grid grid-cols-2 md:grid-cols-4">
          {[
            { val: '$800–$2K', label: 'Average Bundle Savings' },
            { val: '3–7 Days', label: 'Complete Install' },
            { val: '1 Crew', label: 'All 3 Trades' },
            { val: 'Lifetime', label: 'Single Warranty' },
          ].map((s, i) => (
            <div key={s.label} className={`px-6 md:px-10 py-6 md:py-8 ${i < 3 ? 'border-r border-white/10' : ''}`}>
              <p className="font-display text-white text-3xl md:text-4xl tracking-wider">{s.val}</p>
              <p className="text-white/40 text-xs uppercase tracking-widest mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Package Tiers ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Choose Your Package</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
            Three Tiers.<br />Every Budget.
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            From a practical roof-and-gutters combo to a full premium exterior transformation — we have a package for every home and budget.
          </p>
        </div>

        <div
          ref={packages.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {PACKAGE_TIERS.map((pkg, i) => (
            <div
              key={pkg.id}
              onClick={() => {
                setActivePackage(pkg.id);
                trackOfferView({
                  id: `exterior-${pkg.id}`,
                  title: pkg.name,
                  savings: pkg.savings,
                  icon: pkg.id === 'premium' ? 'ri-vip-crown-line' : 'ri-home-4-line',
                });
              }}
              className={`relative border-2 p-8 cursor-pointer transition-all duration-300 anim-fade-up ${packages.isVisible ? 'is-visible' : ''} ${pkg.color} ${activePackage === pkg.id ? 'bg-orange/10' : 'bg-charcoal-mid hover:bg-white/5'}`}
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              {pkg.highlight && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-orange text-white text-xs font-bold px-4 py-1.5 uppercase tracking-widest whitespace-nowrap">
                  Most Popular
                </div>
              )}
              <div className="mb-6">
                <p className="text-orange text-xs uppercase tracking-widest font-semibold mb-1">{pkg.tagline}</p>
                <h3 className="font-display text-white text-2xl uppercase tracking-wider">{pkg.name}</h3>
                <div className="flex items-baseline gap-3 mt-3">
                  <span className="font-display text-white text-3xl tracking-wider">{pkg.price}</span>
                  <span className="text-orange text-sm font-semibold">{pkg.savings}</span>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                {pkg.includes.map((item) => (
                  <div key={item.item} className="flex items-start gap-3">
                    <div className="w-7 h-7 flex items-center justify-center bg-orange/15 flex-shrink-0 mt-0.5">
                      <i className={`${item.icon} text-orange text-xs`} />
                    </div>
                    <div>
                      <p className="text-white text-sm font-semibold">{item.item}</p>
                      <p className="text-white/40 text-xs">{item.detail}</p>
                    </div>
                  </div>
                ))}
                {pkg.notIncluded.map((item) => (
                  <div key={item} className="flex items-center gap-3 opacity-30">
                    <div className="w-7 h-7 flex items-center justify-center border border-white/10 flex-shrink-0">
                      <i className="ri-close-line text-white/40 text-xs" />
                    </div>
                    <p className="text-white/40 text-sm line-through">{item}</p>
                  </div>
                ))}
              </div>

              <button
                onClick={(e) => { e.stopPropagation(); document.getElementById('package-form')?.scrollIntoView({ behavior: 'smooth' }); }}
                className={`w-full py-3.5 text-sm font-bold uppercase tracking-widest transition-colors whitespace-nowrap flex items-center justify-center gap-2 ${pkg.highlight ? 'bg-orange hover:bg-orange-dark text-white' : 'border border-white/20 hover:border-orange text-white hover:text-orange'}`}
              >
                Get {pkg.name} Quote
                <i className="ri-arrow-right-line" />
              </button>
            </div>
          ))}
        </div>
        {/* AI Trigger */}
        <div className="mt-8 flex justify-center">
          <button
            onClick={() => openReaddyAgent("Can I do roof, siding, and gutters in phases or do they all need to be done together?")}
            className="group flex items-center gap-2 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-question-answer-line text-sm" />
            <span className="underline underline-offset-2">Ask AI about phasing vs bundling</span>
            <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>
      </section>

      {/* ── Savings Breakdown ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">The Math</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              Why Bundling<br />Just Makes Sense
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-6">
              When you hire three separate contractors, you pay three mobilization fees, three cleanup costs, and three markups. When we do it all, you pay once — and we pass the savings directly to you.
            </p>
            <p className="text-white/50 text-sm leading-relaxed">
              Here's a real-world cost comparison for a typical 2,000 sq ft Evansville home:
            </p>
          </div>

          <div
            ref={savings.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${savings.isVisible ? 'is-visible' : ''}`}
          >
            <div className="border border-white/10 bg-charcoal-mid overflow-hidden">
              {SAVINGS_BREAKDOWN.map((row, i) => (
                <div
                  key={row.label}
                  className={`flex items-center justify-between px-6 py-4 ${i < SAVINGS_BREAKDOWN.length - 1 ? 'border-b border-white/10' : ''} ${row.highlight ? 'bg-white/5' : ''}`}
                >
                  <div>
                    <p className={`text-sm font-semibold ${row.orange ? 'text-orange' : 'text-white'}`}>{row.label}</p>
                    {row.note && <p className="text-white/30 text-xs mt-0.5">{row.note}</p>}
                  </div>
                  <span className={`font-display text-xl tracking-wider ${row.orange ? 'text-orange' : row.highlight ? 'text-white' : 'text-white/60'}`}>
                    {row.cost}
                  </span>
                </div>
              ))}
              <div className="bg-orange/10 border-t border-orange/30 px-6 py-4 flex items-center justify-between">
                <p className="text-orange font-bold text-sm uppercase tracking-wider">Your Savings</p>
                <span className="font-display text-orange text-2xl tracking-wider">$2,500–$6,500</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Complete Exterior Cost Estimator ── */}
      <CompleteExteriorEstimator />

      {/* ── Financing Calculator ── */}
      <ExteriorFinancingCalculator />

      {/* ── Competitor Quote Comparison ── */}
      <CompetitorComparisonTool />

      {/* ── Price Match Guarantee ── */}
      <PriceMatchBanner serviceName="exterior package" highlightSavings="Bundle savings already applied — we still match on top" />

      {/* ── Why Bundle ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">6 Reasons to Bundle</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            One Project.<br />Zero Headaches.
          </h2>
        </div>

        <div
          ref={why.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {WHY_BUNDLE.map((item, i) => (
            <div
              key={item.title}
              className={`border border-white/10 bg-charcoal-mid p-8 hover:border-orange/30 transition-all duration-300 group anim-fade-up ${why.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="w-12 h-12 flex items-center justify-center bg-orange/15 group-hover:bg-orange/25 transition-colors mb-5">
                <i className={`${item.icon} text-orange text-xl`} />
              </div>
              <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">{item.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Before / After Visual ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-12">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Real Results</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Complete Exterior<br />Transformations
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              img: '/placeholders/600x400.svg',
              label: 'Evansville, IN',
              detail: 'Roof + Vinyl Siding + Gutters',
              savings: 'Saved $1,400',
            },
            {
              img: '/placeholders/600x400.svg',
              label: 'Henderson, KY',
              detail: 'Metal Roof + James Hardie + Copper Gutters',
              savings: 'Saved $3,200',
            },
            {
              img: '/placeholders/600x400.svg',
              label: 'Newburgh, IN',
              detail: 'Roof + Siding + Gutters + Trim',
              savings: 'Saved $1,900',
            },
          ].map((item) => (
            <div key={item.label} className="group overflow-hidden border border-white/10 hover:border-orange/30 transition-all duration-300">
              <div className="relative w-full overflow-hidden" style={{ height: '240px' }}>
                <img src={item.img} alt={item.detail} className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105" />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal-deep/80 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-5">
                  <p className="text-white font-semibold text-sm">{item.detail}</p>
                  <p className="text-white/50 text-xs mt-0.5">{item.label}</p>
                </div>
              </div>
              <div className="bg-charcoal-mid px-5 py-3 flex items-center justify-between">
                <span className="text-white/50 text-xs uppercase tracking-wider">Bundle Savings</span>
                <span className="text-orange font-bold text-sm">{item.savings}</span>
              </div>
            </div>
          ))}
        </div>
        <div className="text-center mt-8">
          <button
            onClick={() => navigate('/before-after')}
            className="border border-white/20 hover:border-orange text-white/70 hover:text-white text-sm font-semibold px-8 py-3.5 uppercase tracking-widest transition-all cursor-pointer flex items-center gap-2 mx-auto whitespace-nowrap"
          >
            <i className="ri-image-2-line text-orange" />
            View Full Before &amp; After Gallery
          </button>
        </div>
      </section>

      {/* ── Process ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">How It Works</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            From Inspection<br />to Complete in 5 Steps
          </h2>
        </div>

        <div
          ref={process.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4"
        >
          {PROCESS_STEPS.map((step, i) => (
            <div
              key={step.num}
              className={`relative border border-white/10 bg-charcoal-mid p-6 anim-fade-up ${process.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="font-display text-white/10 text-6xl leading-none absolute top-3 right-4 select-none">{step.num}</div>
              <div className="w-10 h-10 flex items-center justify-center bg-orange/15 mb-4 relative z-10">
                <i className={`${step.icon} text-orange text-lg`} />
              </div>
              <h3 className="font-display text-white text-lg uppercase tracking-wider mb-2 relative z-10">{step.title}</h3>
              <p className="text-white/50 text-xs leading-relaxed relative z-10">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Financing Strip ── */}
      <section className="py-12 px-6 md:px-10 lg:px-16 bg-orange">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <p className="text-white/80 text-xs uppercase tracking-widest font-semibold mb-1">Don't Let Budget Stop You</p>
            <h3 className="font-display text-white text-3xl md:text-4xl uppercase tracking-wider">Finance Your Complete Package — From $180/Month</h3>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 flex-shrink-0">
            <button
              onClick={() => navigate('/roof-financing')}
              className="bg-white hover:bg-gray-100 text-orange font-bold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
            >
              <i className="ri-bank-card-line" />
              See Financing Options
            </button>
            <a href="tel:8122135997" className="border-2 border-white/60 hover:border-white text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap flex items-center gap-2">
              <i className="ri-phone-line" />
              812-213-5997
            </a>
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Common Questions</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Package FAQ
            </h2>
          </div>
          <div
            ref={faqAnim.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${faqAnim.isVisible ? 'is-visible' : ''}`}
          >
            {FAQS.map((faq, i) => (
              <div key={i} className="border-b border-white/10">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between py-5 text-left cursor-pointer group"
                >
                  <span className="font-display text-white text-lg uppercase tracking-wider pr-4 group-hover:text-orange transition-colors">{faq.q}</span>
                  <div className={`w-8 h-8 flex items-center justify-center border flex-shrink-0 transition-all duration-300 ${openFaq === i ? 'bg-orange border-orange text-white' : 'border-white/20 text-white/40 group-hover:border-orange group-hover:text-orange'}`}>
                    <i className={`ri-${openFaq === i ? 'subtract' : 'add'}-line`} />
                  </div>
                </button>
                <div className={`overflow-hidden transition-all duration-500 ${openFaq === i ? 'max-h-56 opacity-100 pb-5' : 'max-h-0 opacity-0'}`}>
                  <p className="text-white/50 text-sm leading-relaxed pr-12">{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Quote Form ── */}
      <section id="package-form" className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div
          ref={formAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${formAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            <div>
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Free Bundle Estimate</p>
              <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 5vw, 5rem)' }}>
                Get Your Free<br />Package Quote<br /><span className="text-orange">Today.</span>
              </h2>
              <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
                Tell us what you need and we'll schedule a free full exterior inspection. You'll get one itemized quote covering all three trades — with the bundle savings clearly shown.
              </p>
              <div className="space-y-4">
                {[
                  { icon: 'ri-timer-line', text: 'Response within 2 hours' },
                  { icon: 'ri-search-eye-line', text: 'Free full exterior inspection' },
                  { icon: 'ri-file-list-3-line', text: 'Single itemized quote — all 3 trades' },
                  { icon: 'ri-money-dollar-circle-line', text: 'Bundle savings clearly itemized' },
                  { icon: 'ri-file-shield-2-line', text: 'Insurance claim assistance included' },
                ].map((item) => (
                  <div key={item.text} className="flex items-center gap-3 text-white/50 text-sm">
                    <i className={`${item.icon} text-orange text-base`} />
                    {item.text}
                  </div>
                ))}
              </div>
              <div className="mt-8 pt-8 border-t border-white/10">
                <p className="text-white/30 text-xs uppercase tracking-widest mb-3">Or call us directly</p>
                <a href="tel:8122135997" className="flex items-center gap-3 text-white hover:text-orange transition-colors">
                  <i className="ri-phone-fill text-orange text-xl" />
                  <span className="font-display text-2xl tracking-wider">812-213-5997</span>
                </a>
              </div>
              {/* AI Trigger */}
              <div className="mt-6">
                <button
                  onClick={() => openReaddyAgent("What's the total cost for a complete exterior package in Evansville?")}
                  className="group flex items-center gap-2 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-question-answer-line text-sm" />
                  <span className="underline underline-offset-2">Ask AI about complete exterior package costs</span>
                  <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>
            </div>

            <div className="bg-white rounded-2xl overflow-hidden">
              <div className="bg-charcoal-deep px-8 py-6 border-b border-white/10">
                <h3 className="font-display text-white text-2xl uppercase tracking-wider">Bundle Quote Request</h3>
                <p className="text-white/50 text-sm mt-1">Roof + Siding + Gutters — one visit, one price</p>
              </div>

              {formStatus === 'success' ? (
                <div className="px-8 py-14 flex flex-col items-center text-center">
                  <div className="w-16 h-16 flex items-center justify-center bg-green-100 rounded-full mb-4">
                    <i className="ri-checkbox-circle-fill text-green-600 text-3xl" />
                  </div>
                  <h4 className="font-display text-charcoal text-2xl uppercase tracking-wider mb-2">Request Received!</h4>
                  <p className="text-gray-500 text-sm leading-relaxed max-w-xs">
                    We'll contact you within 2 hours to schedule your free full exterior inspection and bundle quote.
                  </p>
                  <button onClick={() => setFormStatus('idle')} className="mt-6 text-orange text-sm font-semibold underline underline-offset-4 cursor-pointer">
                    Submit another request
                  </button>
                </div>
              ) : (
                <form
                  ref={formRef}
                  data-readdy-form
                  onSubmit={handleSubmit}
                  className="px-8 py-7 space-y-4"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Full Name</label>
                      <input type="text" name="name" required placeholder="Jane Smith" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Phone</label>
                      <input type="tel" name="phone" required placeholder="812-000-0000" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Email</label>
                    <input type="email" name="email" required placeholder="you@email.com" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Property Address</label>
                    <input type="text" name="address" required placeholder="123 Main St, Evansville, IN" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Package Interest</label>
                    <select name="package_tier" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                      <option value="">Select package</option>
                      <option value="essential">Essential — Roof + Gutters</option>
                      <option value="complete">Complete — Roof + Siding + Gutters</option>
                      <option value="premium">Premium — Metal + Hardie + Copper</option>
                      <option value="custom">Custom — Tell me what I need</option>
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Roof Material</label>
                      <select name="roof_material" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                        <option value="">Select</option>
                        <option value="architectural-shingles">Architectural Shingles</option>
                        <option value="metal">Metal Roofing</option>
                        <option value="not-sure">Not Sure</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Siding Material</label>
                      <select name="siding_material" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                        <option value="">Select</option>
                        <option value="vinyl">Vinyl Siding</option>
                        <option value="james-hardie">James Hardie</option>
                        <option value="not-sure">Not Sure</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Storm Damage / Insurance Claim?</label>
                    <select name="insurance_claim" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                      <option value="">Select option</option>
                      <option value="yes-filing">Yes — Already filing a claim</option>
                      <option value="yes-check">Yes — Need damage inspection first</option>
                      <option value="no">No — Not storm related</option>
                      <option value="not-sure">Not Sure</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                      Additional Details <span className="text-gray-400 font-normal normal-case">(optional)</span>
                    </label>
                    <textarea
                      name="notes"
                      rows={3}
                      maxLength={500}
                      onChange={(e) => setCharCount(e.target.value.length)}
                      placeholder="Home size, current condition, timeline, color preferences..."
                      className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
                    />
                    <p className={`text-xs mt-1 text-right ${charCount > 500 ? 'text-red-500' : 'text-gray-400'}`}>{charCount}/500</p>
                  </div>
                  <button
                    type="submit"
                    disabled={formStatus === 'submitting'}
                    className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-300 text-white font-bold text-sm uppercase tracking-widest py-4 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  >
                    {formStatus === 'submitting' ? (
                      <><i className="ri-loader-4-line animate-spin" />Sending...</>
                    ) : (
                      <><i className="ri-send-plane-line" />Get My Free Bundle Quote</>
                    )}
                  </button>
                  {formStatus === 'error' && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2">
                      <i className="ri-alert-line text-red-500" />
                      <p className="text-red-600 text-xs">Something went wrong. Please call 812-213-5997 directly.</p>
                    </div>
                  )}
                  <p className="text-gray-400 text-xs text-center">
                    <i className="ri-lock-line mr-1" />Your information is private and secure.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}