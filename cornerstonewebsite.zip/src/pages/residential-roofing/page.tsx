import { useState, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import BundleSaveBadge from '@/components/feature/BundleSaveBadge';
import RelatedServicesStrip from '@/components/feature/RelatedServicesStrip';
import ServiceProcessStrip from '@/components/feature/ServiceProcessStrip';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import CompetitorComparisonTool from '@/components/feature/CompetitorComparisonTool';
import PriceMatchBanner from '@/components/feature/PriceMatchBanner';
import { OFFERS } from '@/mocks/promotions';
import { trackOfferView } from '@/pages/promotions/components/RecentlyViewedOffers';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const residentialSchema = {
  '@context': 'https://schema.org',
  '@type': 'Service',
  name: 'Residential Roofing Evansville Indiana',
  provider: {
    '@type': 'RoofingContractor',
    name: 'Corner Stone Construction & Roofing',
    telephone: '+1-812-213-5997',
    address: {
      '@type': 'PostalAddress',
      streetAddress: '5800 Kansas Rd',
      addressLocality: 'Evansville',
      addressRegion: 'IN',
      postalCode: '47725',
    },
  },
  areaServed: ['Evansville IN', 'Henderson KY', 'Newburgh IN', 'Owensboro KY', 'Tri-State Area'],
  description: 'Residential roofing contractor serving Evansville Indiana and Henderson KY. Asphalt shingles, metal roofing, roof repair, storm damage, and full replacements for homeowners across the Tri-State area.',
  hasOfferCatalog: {
    '@type': 'OfferCatalog',
    name: 'Residential Roofing Services',
    itemListElement: [
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Asphalt Shingle Roofing' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Metal Roofing' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Roof Repair' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Storm Damage Roofing' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Roof Inspection' } },
    ],
  },
};

const SYSTEMS = [
  {
    id: 'architectural',
    name: 'Architectural Shingles',
    full: 'Dimensional Asphalt Shingles',
    icon: 'ri-home-2-line',
    badge: 'Most Popular',
    badgeColor: 'bg-orange text-white',
    lifespan: '25–30 Years',
    bestFor: 'Most Homes — Best Value',
    desc: 'The #1 choice for Evansville homeowners. Architectural shingles offer a rich, dimensional look that mimics wood shake or slate at a fraction of the cost. GAF Timberline HDZ and Owens Corning Duration are our top picks — both carry a Lifetime Limited Warranty.',
    features: ['Lifetime Limited Warranty', 'Wind Rated to 130 mph', 'Algae Resistant', 'Wide Color Selection', 'Class A Fire Rated', 'Affordable & Proven'],
    image: '/placeholders/800x500.svg',
  },
  {
    id: 'metal',
    name: 'Metal Roofing',
    full: 'Standing Seam & Metal Shingles',
    icon: 'ri-home-gear-line',
    badge: 'Longest Lifespan',
    badgeColor: 'bg-white/10 text-white',
    lifespan: '40–70 Years',
    bestFor: 'Premium Homes & Long-Term Value',
    desc: 'The last roof you\'ll ever put on your home. Metal roofing handles Indiana hail, ice dams, and high winds better than any other material. Standing seam panels and metal shingles are both available — choose the look that fits your home\'s style.',
    features: ['50+ Year Lifespan', 'Hail & Wind Resistant', 'No Moss or Algae', 'Energy Efficient', 'Fire Rated Class A', 'Increases Home Value'],
    image: '/placeholders/800x500.svg',
  },
  {
    id: 'designer',
    name: 'Designer Shingles',
    full: 'Premium Luxury Shingles',
    icon: 'ri-star-line',
    badge: 'Premium Look',
    badgeColor: 'bg-white/10 text-white',
    lifespan: '30–50 Years',
    bestFor: 'High-End Homes & Curb Appeal',
    desc: 'For homeowners who want the look of slate or cedar shake without the maintenance headaches. GAF Camelot II and Owens Corning Berkshire deliver stunning curb appeal with the durability of modern asphalt technology — and they\'re a fraction of the cost of real slate.',
    features: ['Slate & Shake Appearance', 'Impact Resistant Options', 'Superior Curb Appeal', 'Increases Resale Value', 'Lifetime Warranty', 'Low Maintenance'],
    image: '/placeholders/800x500.svg',
  },
  {
    id: 'repair',
    name: 'Roof Repair',
    full: 'Targeted Repair & Restoration',
    icon: 'ri-tools-line',
    badge: 'Fast Response',
    badgeColor: 'bg-white/10 text-white',
    lifespan: 'Extends Existing Roof Life',
    bestFor: 'Leaks, Storm Damage, Missing Shingles',
    desc: 'Not every roof needs full replacement. Our repair specialists diagnose the exact source of leaks, missing shingles, flashing failures, and storm damage — and fix only what needs fixing. We\'ll give you an honest assessment and never upsell you on a replacement you don\'t need.',
    features: ['Same-Day Emergency Response', 'Leak Detection & Repair', 'Storm Damage Repair', 'Flashing Replacement', 'Honest Assessment', 'No Unnecessary Upsells'],
    image: '/placeholders/800x500.svg',
  },
];

const HOMEOWNER_BENEFITS = [
  {
    icon: 'ri-search-eye-line',
    title: 'Free Roof Inspection',
    desc: 'We come to you, inspect your roof top-to-bottom, and give you a straight answer — no pressure, no upsell. Most inspections take under an hour.',
  },
  {
    icon: 'ri-shield-check-line',
    title: 'Insurance Claim Experts',
    desc: 'We work directly with your insurance adjuster and handle all the paperwork. Most storm damage replacements cost homeowners $0 out of pocket.',
  },
  {
    icon: 'ri-calendar-check-line',
    title: 'Completed in 1–2 Days',
    desc: 'Most residential replacements are done in a single day. We clean up completely — including a magnetic sweep for nails — before we leave.',
  },
  {
    icon: 'ri-award-line',
    title: 'GAF Master Elite Certified',
    desc: 'Only 3% of roofers earn GAF Master Elite status. This unlocks the Golden Pledge warranty — the strongest residential roofing warranty available.',
  },
  {
    icon: 'ri-money-dollar-circle-line',
    title: 'Financing Available',
    desc: 'Don\'t let budget hold you back. We offer flexible financing options with approved credit — get your roof done now and pay over time.',
  },
  {
    icon: 'ri-map-pin-line',
    title: 'Local Tri-State Experts',
    desc: 'We know Indiana and Kentucky weather — hail, ice dams, high winds. We build roofs specifically for what this region throws at them.',
  },
];



const FAQS = [
  {
    q: 'How do I know if I need a full replacement or just a repair?',
    a: 'Our free inspection will tell you exactly. Generally, if your roof is under 15 years old with isolated damage, repair is the right call. If it\'s 20+ years old, has widespread granule loss, or has had multiple leaks, replacement is more cost-effective. We give you an honest answer — not just the most expensive option.',
  },
  {
    q: 'Will my homeowner\'s insurance cover a new roof?',
    a: 'If your roof was damaged by hail, wind, or another covered storm event, your insurance should cover most or all of the replacement cost. We work directly with your adjuster, document all damage, and handle the claim process. Most of our storm damage customers pay only their deductible.',
  },
  {
    q: 'How long does a residential roof replacement take?',
    a: 'Most residential replacements are completed in a single day — typically 6–8 hours for an average-sized home. Larger or more complex roofs may take 2 days. We\'ll give you a specific timeline before we start.',
  },
  {
    q: 'What roofing materials do you recommend for Indiana weather?',
    a: 'For most Evansville homeowners, we recommend GAF Timberline HDZ architectural shingles — they\'re rated for 130 mph winds, algae resistant, and carry a Lifetime Limited Warranty. For maximum durability against Indiana hail and ice, standing seam metal is the gold standard.',
  },
  {
    q: 'Do you offer financing for roof replacements?',
    a: 'Yes. We offer flexible financing options with approved credit. You can get your roof replaced now and pay over time with manageable monthly payments. Ask us about current financing promotions when you request your free estimate.',
  },
  {
    q: 'What is the GAF Golden Pledge warranty and do I qualify?',
    a: 'The GAF Golden Pledge is the strongest residential roofing warranty available — it covers both materials AND labor for up to 25 years with no dollar limit. Only GAF Master Elite contractors (the top 3% of roofers) can offer it. Corner Stone is Master Elite certified, so yes — you qualify.',
  },
];

const SHINGLE_COLORS = [
  { name: 'Charcoal', hex: '#3a3a3a' },
  { name: 'Weathered Wood', hex: '#7a6a52' },
  { name: 'Pewter Gray', hex: '#8a8a8a' },
  { name: 'Barkwood', hex: '#5c4a32' },
  { name: 'Shakewood', hex: '#6b5a42' },
  { name: 'Slate', hex: '#5a6070' },
  { name: 'Oyster Gray', hex: '#b0a898' },
  { name: 'Hickory', hex: '#6a5040' },
];

export default function ResidentialRoofingPage() {
  const navigate = useNavigate();
  const [activeSystem, setActiveSystem] = useState(SYSTEMS[0]);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [charCount, setCharCount] = useState(0);
  const formRef = useRef<HTMLFormElement>(null);

  const hero = useScrollAnimation();
  const systems = useScrollAnimation({ threshold: 0.05 });
  const benefits = useScrollAnimation({ threshold: 0.1 });
  const faqAnim = useScrollAnimation({ threshold: 0.1 });
  const formAnim = useScrollAnimation({ threshold: 0.1 });

  const nearestExpiry = useMemo(() => {
    const expiring = OFFERS.filter((o) => o.expires).sort((a, b) => new Date(a.expires!).getTime() - new Date(b.expires!).getTime());
    return expiring[0]?.expires ?? null;
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;
    const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
    const notes = formData.get('notes') as string;
    if (notes && notes.length > 500) return;
    setFormStatus('submitting');
    try {
      const res = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      if (res.ok) { setFormStatus('success'); formRef.current.reset(); setCharCount(0); }
      else setFormStatus('error');
    } catch { setFormStatus('error'); }
  };

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Residential Roofing Evansville Indiana | Roof Replacement & Repair | Corner Stone"
        description="Residential roofing contractor serving Evansville IN and Henderson KY. Asphalt shingles, metal roofing, storm damage repair, and full replacements. GAF Master Elite certified. Free inspection. Call 812-213-5997."
        keywords="residential roofing Evansville Indiana, roof replacement Evansville IN, residential roofer Henderson KY, asphalt shingles Evansville, metal roofing Indiana, storm damage roof repair Evansville, GAF Master Elite Evansville"
        canonical="/residential-roofing"
        schema={residentialSchema}
      />

      {/* ── Hero ── */}
      <section className="relative min-h-screen flex flex-col overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1400x900.svg"
            alt="Residential roofing contractor Evansville Indiana"
            className="w-full h-full object-cover object-top opacity-35"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/60 via-charcoal-deep/40 to-charcoal-deep" />
          <div className="absolute inset-0 opacity-[0.025]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '80px 80px' }} />
        </div>

        <div
          ref={hero.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 flex-1 flex flex-col justify-center px-6 md:px-10 lg:px-16 pt-32 md:pt-36 pb-16 anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-wrap items-center gap-3 mb-8">
            <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange" />
              GAF Master Elite Certified
            </div>
            <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange" />
              Most Jobs Done in 1 Day
            </div>
            <div className="flex items-center gap-2 border border-orange/40 bg-orange/10 backdrop-blur-sm px-4 py-2 text-orange text-xs uppercase tracking-widest">
              <i className="ri-shield-check-line text-sm" />
              Golden Pledge Warranty Available
            </div>
          </div>

          <div className="mb-3 space-y-2">
            <CountdownTimer expiresAt={nearestExpiry ?? new Date(Date.now() + 86400000 * 3).toISOString()} variant="banner" />
            <SocialProofPulse />
          </div>

          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 9vw, 10rem)' }}>
            Your Home.<br />Protected<br /><span className="text-orange">For Life.</span>
          </h1>

          <div className="flex flex-col lg:flex-row lg:items-end gap-8 lg:gap-16">
            <p className="text-white/50 text-base md:text-lg max-w-xl leading-relaxed">
              Evansville and Henderson KY's trusted residential roofing contractor. We protect your home with quality materials, honest pricing, and workmanship that stands behind every nail we drive.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 flex-shrink-0">
              <button
                onClick={() => document.getElementById('res-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <i className="ri-home-smile-line" />
                Get Free Estimate
              </button>
              <a
                href="tel:8122135997"
                className="border border-white/30 hover:border-orange text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-phone-line text-orange" />
                812-213-5997
              </a>
            </div>
          </div>
        </div>

        {/* Bottom stats */}
        <div className="relative z-10 border-t border-white/10 grid grid-cols-2 md:grid-cols-4">
          {[
            { val: '1,200+', label: 'Homes Roofed' },
            { val: '1 Day', label: 'Average Install' },
            { val: '25yr', label: 'Golden Pledge Warranty' },
            { val: '$0', label: 'Out-of-Pocket (Storm Claims)' },
          ].map((s, i) => (
            <div key={s.label} className={`px-6 md:px-10 py-6 md:py-8 ${i < 3 ? 'border-r border-white/10' : ''}`}>
              <p className="font-display text-white text-3xl md:text-4xl tracking-wider">{s.val}</p>
              <p className="text-white/40 text-xs uppercase tracking-widest mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      <TalkToAIExpert />

      {/* ── Roofing Systems ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 border-t border-white/5">
        <div className="text-center mb-14 md:mb-18">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Roofing Systems</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
            The Right Roof<br />For Your Home
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            We install all major residential roofing systems and help you choose the best fit for your home, budget, and long-term goals.
          </p>
        </div>

        <div
          ref={systems.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 lg:grid-cols-5 gap-6"
        >
          {/* System selector */}
          <div className="lg:col-span-2 flex flex-col gap-3">
            {SYSTEMS.map((sys, i) => (
              <button
                key={sys.id}
                onClick={() => setActiveSystem(sys)}
                className={`text-left border p-5 transition-all duration-300 cursor-pointer group anim-fade-up ${systems.isVisible ? 'is-visible' : ''} ${activeSystem.id === sys.id ? 'border-orange bg-orange/10' : 'border-white/10 bg-charcoal-mid hover:border-white/30'}`}
                style={{ transitionDelay: `${i * 80}ms` }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-xs font-bold px-2 py-0.5 uppercase tracking-wider ${sys.badgeColor}`}>{sys.badge}</span>
                  <span className="text-white/30 text-xs">{sys.lifespan}</span>
                </div>
                <h3 className={`font-display text-xl uppercase tracking-wider transition-colors ${activeSystem.id === sys.id ? 'text-orange' : 'text-white group-hover:text-orange'}`}>
                  {sys.name}
                </h3>
                <p className="text-white/30 text-xs mt-1">{sys.full}</p>
                <p className="text-white/40 text-xs mt-2">
                  <i className="ri-home-line mr-1 text-orange" />
                  {sys.bestFor}
                </p>
              </button>
            ))}
          </div>

          {/* System detail */}
          <div className="lg:col-span-3 flex flex-col gap-4">
            <div className="relative w-full overflow-hidden" style={{ height: '300px' }}>
              <img
                key={activeSystem.id}
                src={activeSystem.image}
                alt={activeSystem.name}
                className="w-full h-full object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-deep/80 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="flex items-center gap-3">
                  <span className={`text-xs font-bold px-3 py-1 uppercase tracking-wider ${activeSystem.badgeColor}`}>{activeSystem.badge}</span>
                  <span className="text-white/50 text-xs">{activeSystem.lifespan}</span>
                </div>
                <h3 className="font-display text-white text-3xl uppercase tracking-wider mt-2">{activeSystem.name}</h3>
              </div>
            </div>

            <div className="border border-white/10 bg-charcoal-mid p-6 md:p-8 flex-1">
              <p className="text-white/60 text-sm leading-relaxed mb-6">{activeSystem.desc}</p>
              <div className="grid grid-cols-2 gap-2 mb-6">
                {activeSystem.features.map((f) => (
                  <div key={f} className="flex items-center gap-2 text-white/50 text-xs">
                    <i className="ri-check-line text-orange text-sm" />
                    {f}
                  </div>
                ))}
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => document.getElementById('res-form')?.scrollIntoView({ behavior: 'smooth' })}
                  className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-6 py-3 uppercase tracking-wide transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                >
                  Get {activeSystem.name} Quote
                  <i className="ri-arrow-right-line" />
                </button>
                <a
                  href="tel:8122135997"
                  className="border border-white/20 hover:border-orange text-white/70 hover:text-white text-sm font-semibold px-6 py-3 uppercase tracking-wide transition-all whitespace-nowrap flex items-center justify-center gap-2"
                >
                  <i className="ri-phone-line text-orange" />
                  Call Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Shingle Color Selector ── */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal border-y border-white/10">
        <div className="text-center mb-10">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-3">Popular Colors</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(1.8rem, 4vw, 3.5rem)' }}>
            Find Your Perfect Shingle Color
          </h2>
          <p className="text-white/40 text-sm mt-3 max-w-lg mx-auto">
            We carry the full GAF and Owens Corning color lines. These are the most popular choices for Evansville and Henderson KY homes.
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-4 max-w-3xl mx-auto">
          {SHINGLE_COLORS.map((color) => (
            <div key={color.name} className="flex flex-col items-center gap-2 cursor-pointer group">
              <div
                className="w-14 h-14 rounded-full border-2 border-white/10 group-hover:border-orange transition-all duration-200 shadow-inner"
                style={{ backgroundColor: color.hex }}
              />
              <span className="text-white/40 text-xs group-hover:text-white/70 transition-colors">{color.name}</span>
            </div>
          ))}
        </div>
        <p className="text-center text-white/25 text-xs mt-8">
          Want to see samples in person? We bring physical samples to your free inspection.
        </p>
      </section>

      {/* ── Why Corner Stone for Residential ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal border-t border-white/5">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Why Choose Us</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Built for<br />Homeowners
          </h2>
        </div>

        <div
          ref={benefits.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {HOMEOWNER_BENEFITS.map((b, i) => (
            <div
              key={b.title}
              className={`border border-white/10 bg-charcoal-mid p-8 hover:border-orange/30 transition-all duration-300 group anim-fade-up ${benefits.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="w-12 h-12 flex items-center justify-center bg-orange/15 group-hover:bg-orange/25 transition-colors mb-5">
                <i className={`${b.icon} text-orange text-xl`} />
              </div>
              <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">{b.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{b.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Our Process ── */}
      <ServiceProcessStrip
        heading="How It Works"
        subheading="Simple. Honest. Done Right."
        steps={[
          { num: '01', icon: 'ri-search-eye-line', title: 'Free Inspection', desc: 'We inspect your roof, attic, gutters, and flashing. You get a full written report with photos — no charge, no obligation.', detail: 'Most inspections take under an hour' },
          { num: '02', icon: 'ri-file-list-3-line', title: 'Clear Quote', desc: 'We present your options clearly — repair vs. replace, material choices, and pricing. We tell you what we\'d do if it were our own home.', detail: 'Written, itemized, zero hidden fees' },
          { num: '03', icon: 'ri-hammer-line', title: 'Expert Installation', desc: 'Our crew arrives on time, works clean, and finishes strong. Premium materials, certified methods, and magnetic nail sweep before we leave.', detail: 'Most jobs done in 1 day' },
          { num: '04', icon: 'ri-home-smile-line', title: 'Final Walkthrough', desc: 'We walk the finished roof with you, explain your warranty, and register your Golden Pledge. You pay only when you\'re 100% satisfied.', detail: 'Golden Pledge warranty registration included' },
        ]}
        ctaText="Ready to start? Step 1 takes 60 seconds."
        ctaSubtext="Free inspection · No pressure · Tri-State area"
        buttonText="Get Free Estimate"
        buttonHref="#res-form"
      />

      {/* ── Compare Quotes — Bundle vs. Separate Contractors ── */}
      <CompetitorComparisonTool />

      {/* ── Price Match Guarantee ── */}
      <PriceMatchBanner serviceName="roof replacement" highlightSavings="GAF Master Elite quality at the best price — guaranteed" />

      {/* ── Insurance Claims CTA ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 border-t border-white/5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <div className="w-full overflow-hidden" style={{ height: '460px' }}>
              <img
                src="/placeholders/700x460.svg"
                alt="Insurance claim roofing Evansville Indiana"
                className="w-full h-full object-cover object-top"
              />
            </div>
            <div className="absolute bottom-6 left-6 right-6 bg-charcoal-deep/90 border border-white/10 p-5">
              <div className="flex items-center gap-3 mb-2">
                <i className="ri-money-dollar-circle-line text-orange text-xl" />
                <p className="text-white font-semibold text-sm">Most Storm Claims = $0 Out of Pocket</p>
              </div>
              <p className="text-white/40 text-xs leading-relaxed">
                We handle the entire insurance process. You pay your deductible — we handle the rest.
              </p>
            </div>
          </div>

          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Storm Damage?</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              We Handle<br />Your Insurance<br />Claim.
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
              Indiana and Kentucky storms cause millions in roof damage every year. If your home was hit by hail or high winds, you may be entitled to a full roof replacement at no cost beyond your deductible. We are insurance claim experts — we document every bit of damage and work directly with your adjuster.
            </p>
            <div className="space-y-4 mb-8">
              {[
                { icon: 'ri-search-eye-line', text: 'Free storm damage inspection — same day available' },
                { icon: 'ri-file-list-3-line', text: 'Full damage documentation with photos' },
                { icon: 'ri-user-voice-line', text: 'We meet with your adjuster on your behalf' },
                { icon: 'ri-check-double-line', text: 'Full replacement if approved — you pay only your deductible' },
              ].map((item) => (
                <div key={item.text} className="flex items-center gap-3 text-white/50 text-sm">
                  <i className={`${item.icon} text-orange text-base flex-shrink-0`} />
                  {item.text}
                </div>
              ))}
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={() => navigate('/insurance-claims')}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap"
              >
                <i className="ri-shield-check-line" />
                Insurance Claims Info
              </button>
              <button
                onClick={() => document.getElementById('res-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap"
              >
                Schedule Free Inspection
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ── Service Area Map ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Residential Coverage</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Serving Evansville,<br />Henderson &amp; Beyond
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-6">
              We roof homes across the entire Tri-State area. From Newburgh to Owensboro, Henderson to Princeton — if you're in our service area, we'll be there.
            </p>
            <div className="space-y-3 mb-8">
              {[
                { city: 'Evansville, IN', note: 'Primary Market — Headquarters' },
                { city: 'Newburgh, IN', note: 'Warrick County' },
                { city: 'Boonville, IN', note: 'Warrick County' },
                { city: 'Mount Vernon, IN', note: 'Posey County' },
                { city: 'Princeton, IN', note: 'Gibson County' },
                { city: 'Henderson, KY', note: 'Primary KY Market' },
                { city: 'Owensboro, KY', note: 'Daviess County' },
              ].map((loc) => (
                <div key={loc.city} className="flex items-center justify-between py-2 border-b border-white/5">
                  <div className="flex items-center gap-3">
                    <i className="ri-map-pin-2-line text-orange text-sm" />
                    <span className="text-white text-sm font-medium">{loc.city}</span>
                  </div>
                  <span className="text-white/30 text-xs">{loc.note}</span>
                </div>
              ))}
            </div>
            <button
              onClick={() => navigate('/service-areas')}
              className="border border-white/20 hover:border-orange text-white/70 hover:text-white text-sm font-semibold px-8 py-3.5 uppercase tracking-widest transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap"
            >
              <i className="ri-map-2-line text-orange" />
              View Full Service Area
            </button>
          </div>

          <div className="w-full overflow-hidden border border-white/10" style={{ height: '420px' }}>
            <iframe
              title="Corner Stone Residential Roofing Service Area"
              src="https://www.google.com/maps/embed/v1/place?key=AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY&q=Evansville,+Indiana&zoom=9"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>

      {/* ── Bundle & Save CTA ── */}
      <section className="py-14 px-6 md:px-10 lg:px-16 border-t border-white/5">
        <div className="relative overflow-hidden border border-white/10 bg-charcoal-mid">
          <div className="absolute inset-0 opacity-10">
            <img
              src="/placeholders/1200x400.svg"
              alt=""
              className="w-full h-full object-cover object-top"
            />
          </div>
          <div className="absolute inset-0 bg-gradient-to-r from-charcoal-mid via-charcoal-mid/95 to-charcoal-mid/80" />
          <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-8 p-8 md:p-12">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-orange text-white text-xs font-bold uppercase tracking-widest px-4 py-2 flex items-center gap-2">
                  <i className="ri-price-tag-3-line" />
                  Bundle &amp; Save
                </div>
                <span className="text-white/40 text-xs uppercase tracking-widest">Save $800–$2,000</span>
              </div>
              <h3 className="font-display text-white uppercase tracking-wider leading-none mb-3" style={{ fontSize: 'clamp(1.8rem, 3.5vw, 3rem)' }}>
                Add Siding &amp; Gutters<br />While We're Already There.
              </h3>
              <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-xl">
                The smartest time to replace your siding and gutters is when your roof is being done. One crew, one visit, one cleanup — and you save significantly on mobilization costs. Our Complete Exterior Package bundles all three into one seamless project.
              </p>
              <div className="flex flex-wrap gap-x-6 gap-y-2 mt-5">
                {['Save $800–$2,000 vs. separate jobs', 'One crew handles everything', 'Matched materials & aesthetics', 'Single insurance claim'].map((item) => (
                  <div key={item} className="flex items-center gap-2 text-white/50 text-xs">
                    <i className="ri-check-line text-orange text-sm" />
                    {item}
                  </div>
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-3 flex-shrink-0">
              <button
                onClick={() => {
                  trackOfferView({
                    id: 'exterior-complete',
                    title: 'Complete Exterior Package',
                    savings: 'Save $800–$2,000',
                    icon: 'ri-home-gear-line',
                  });
                  navigate('/exterior-package');
                }}
                className="bg-orange hover:bg-orange-dark text-white font-bold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <i className="ri-home-gear-line" />
                See Complete Exterior Package
              </button>
              <button
                onClick={() => document.getElementById('res-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
              >
                Get Bundle Quote
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 border-t border-white/5">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Common Questions</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Residential Roofing FAQ
            </h2>
          </div>
          <div
            ref={faqAnim.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${faqAnim.isVisible ? 'is-visible' : ''}`}
          >
            {FAQS.map((faq, i) => (
              <div key={i} className="border-b border-white/10">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between py-5 text-left cursor-pointer group"
                >
                  <span className="font-display text-white text-lg uppercase tracking-wider pr-4 group-hover:text-orange transition-colors">{faq.q}</span>
                  <div className={`w-8 h-8 flex items-center justify-center border flex-shrink-0 transition-all duration-300 ${openFaq === i ? 'bg-orange border-orange text-white' : 'border-white/20 text-white/40 group-hover:border-orange group-hover:text-orange'}`}>
                    <i className={`ri-${openFaq === i ? 'subtract' : 'add'}-line`} />
                  </div>
                </button>
                <div className={`overflow-hidden transition-all duration-500 ${openFaq === i ? 'max-h-48 opacity-100 pb-5' : 'max-h-0 opacity-0'}`}>
                  <p className="text-white/50 text-sm leading-relaxed pr-12">{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Quote Form ── */}
      <section id="res-form" className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal border-t border-white/5">
        <div
          ref={formAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${formAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {/* Left copy */}
            <div>
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Get a Free Estimate</p>
              <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 5vw, 5rem)' }}>
                Let's Talk<br />About Your<br /><span className="text-orange">Roof.</span>
              </h2>
              <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
                Fill out the form and we'll contact you within 2 hours to schedule your free inspection. No pressure, no obligation — just an honest assessment from a local expert.
              </p>
              <div className="space-y-4">
                {[
                  { icon: 'ri-timer-line', text: 'Response within 2 hours' },
                  { icon: 'ri-search-eye-line', text: 'Free on-site roof inspection' },
                  { icon: 'ri-file-list-3-line', text: 'Written estimate with no surprises' },
                  { icon: 'ri-shield-check-line', text: 'No obligation, no pressure' },
                ].map((item) => (
                  <div key={item.text} className="flex items-center gap-3 text-white/50 text-sm">
                    <i className={`${item.icon} text-orange text-base`} />
                    {item.text}
                  </div>
                ))}
              </div>
              <div className="mt-8 pt-8 border-t border-white/10">
                <p className="text-white/30 text-xs uppercase tracking-widest mb-3">Or call us directly</p>
                <a href="tel:8122135997" className="flex items-center gap-3 text-white hover:text-orange transition-colors">
                  <i className="ri-phone-fill text-orange text-xl" />
                  <span className="font-display text-2xl tracking-wider">812-213-5997</span>
                </a>
              </div>
            </div>

            {/* Right form */}
            <div className="bg-white rounded-2xl overflow-hidden">
              <div className="bg-charcoal-deep px-8 py-6 border-b border-white/10">
                <h3 className="font-display text-white text-2xl uppercase tracking-wider">Free Residential Estimate</h3>
                <p className="text-white/50 text-sm mt-1">For homeowners in Evansville, Henderson &amp; Tri-State</p>
              </div>

              {formStatus === 'success' ? (
                <div className="px-8 py-14 flex flex-col items-center text-center">
                  <div className="w-16 h-16 flex items-center justify-center bg-green-100 rounded-full mb-4">
                    <i className="ri-checkbox-circle-fill text-green-600 text-3xl" />
                  </div>
                  <h4 className="font-display text-charcoal text-2xl uppercase tracking-wider mb-2">Request Received!</h4>
                  <p className="text-gray-500 text-sm leading-relaxed max-w-xs">
                    We'll contact you within 2 hours to schedule your free roof inspection. Talk soon!
                  </p>
                  <button onClick={() => setFormStatus('idle')} className="mt-6 text-orange text-sm font-semibold underline underline-offset-4 cursor-pointer">
                    Submit another request
                  </button>
                </div>
              ) : (
                <form
                  ref={formRef}
                  data-readdy-form
                  onSubmit={handleSubmit}
                  className="px-8 py-7 space-y-4"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">First Name</label>
                      <input type="text" name="first_name" required placeholder="John" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Last Name</label>
                      <input type="text" name="last_name" required placeholder="Smith" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Phone</label>
                    <input type="tel" name="phone" required placeholder="812-000-0000" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Email</label>
                    <input type="email" name="email" required placeholder="you@email.com" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Home Address</label>
                    <input type="text" name="address" required placeholder="123 Main St, Evansville, IN" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Service Needed</label>
                      <select name="service_needed" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                        <option value="">Select service</option>
                        <option value="replacement">Full Roof Replacement</option>
                        <option value="repair">Roof Repair</option>
                        <option value="storm_damage">Storm Damage Claim</option>
                        <option value="inspection">Free Inspection</option>
                        <option value="gutters">Gutters</option>
                        <option value="unsure">Not Sure — Need Assessment</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Roof Material</label>
                      <select name="roof_material" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                        <option value="">Select material</option>
                        <option value="asphalt">Asphalt Shingles</option>
                        <option value="metal">Metal Roofing</option>
                        <option value="designer">Designer / Luxury Shingles</option>
                        <option value="unsure">Not Sure</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                      How Can We Help? <span className="text-gray-400 font-normal normal-case">(optional)</span>
                    </label>
                    <textarea
                      name="notes"
                      rows={3}
                      maxLength={500}
                      onChange={(e) => setCharCount(e.target.value.length)}
                      placeholder="Describe your roof issue, storm damage, or what you're looking for..."
                      className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
                    />
                    <p className={`text-xs mt-1 text-right ${charCount > 500 ? 'text-red-500' : 'text-gray-400'}`}>{charCount}/500</p>
                  </div>
                  <button
                    type="submit"
                    disabled={formStatus === 'submitting'}
                    className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-300 text-white font-bold text-sm uppercase tracking-widest py-4 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  >
                    {formStatus === 'submitting' ? (
                      <><i className="ri-loader-4-line animate-spin" />Sending...</>
                    ) : (
                      <><i className="ri-home-smile-line" />Get My Free Estimate</>
                    )}
                  </button>
                  {formStatus === 'error' && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2">
                      <i className="ri-alert-line text-red-500" />
                      <p className="text-red-600 text-xs">Something went wrong. Please call 812-213-5997 directly.</p>
                    </div>
                  )}
                  <p className="text-gray-400 text-xs text-center">
                    <i className="ri-lock-line mr-1" />Your information is private and secure.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ── You Might Also Need ── */}
      <div className="border-t border-white/5">
        <RelatedServicesStrip
          heading="You Might Also Need"
          subheading="Most homeowners bundle these services together — one crew, one visit, maximum savings."
          services={[
            {
              icon: 'ri-drop-line',
              label: 'Gutters & Downspouts',
              description: 'Protect your new roof investment with seamless gutters. Best installed at the same time — saves $300–$600 on mobilization.',
              href: '/gutters-downspouts',
              badge: 'Bundle & Save',
              trackOffer: { id: 'gutters-bundle', title: 'Gutters & Downspouts Bundle', savings: 'Save $300–$600', icon: 'ri-drop-line' },
            },
            {
              icon: 'ri-home-2-line',
              label: 'Siding & Exterior',
              description: 'New roof + new siding = complete exterior transformation. James Hardie and premium vinyl available.',
              href: '/siding-exterior',
            },
            {
              icon: 'ri-home-gear-line',
              label: 'Complete Exterior Package',
              description: 'Roof + Siding + Gutters in one bundled project. Save $800–$2,000 vs. scheduling separately.',
              href: '/exterior-package',
              badge: 'Save $800–$2,000',
              highlight: true,
              trackOffer: { id: 'exterior-complete', title: 'Complete Exterior Package', savings: 'Save $800–$2,000', icon: 'ri-home-gear-line' },
            },
            {
              icon: 'ri-file-shield-2-line',
              label: 'Insurance Claims',
              description: 'Storm damage? We handle the entire insurance claim process — most homeowners pay only their deductible.',
              href: '/insurance-claims',
            },
          ]}
        />
      </div>

      <BundleSaveBadge />
    </div>
  );
}
