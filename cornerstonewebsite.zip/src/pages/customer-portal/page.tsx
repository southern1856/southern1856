import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import PageSEO from '@/components/feature/PageSEO';

interface Project {
  id: number;
  customer_id: string;
  project_name: string;
  address: string;
  service_type: string;
  current_phase: string;
  phase_updated_at: string;
  estimated_completion: string | null;
  notes: string | null;
  created_at: string;
  photo_count?: number;
}

const PHASES = [
  { key: 'inspection_scheduled', label: 'Inspection Scheduled', icon: 'ri-calendar-check-line', order: 1 },
  { key: 'inspection_complete', label: 'Inspection Complete', icon: 'ri-search-eye-line', order: 2 },
  { key: 'estimate_sent', label: 'Estimate Sent', icon: 'ri-file-list-3-line', order: 3 },
  { key: 'estimate_approved', label: 'Estimate Approved', icon: 'ri-check-double-line', order: 4 },
  { key: 'materials_ordered', label: 'Materials Ordered', icon: 'ri-truck-line', order: 5 },
  { key: 'installation_scheduled', label: 'Installation Scheduled', icon: 'ri-calendar-event-line', order: 6 },
  { key: 'tear_off', label: 'Tear-Off In Progress', icon: 'ri-hammer-line', order: 7 },
  { key: 'installation_in_progress', label: 'Installation In Progress', icon: 'ri-building-line', order: 8 },
  { key: 'final_walkthrough', label: 'Final Walkthrough', icon: 'ri-walk-line', order: 9 },
  { key: 'completed', label: 'Completed', icon: 'ri-checkbox-circle-line', order: 10 },
];

const SERVICE_LABELS: Record<string, string> = {
  roof_replacement: 'Roof Replacement',
  storm_repair: 'Storm Damage Repair',
  gutter_install: 'Gutter Installation',
  siding_install: 'Siding Installation',
  commercial_roofing: 'Commercial Roofing',
  exterior_package: 'Complete Exterior Package',
};

function getPhaseInfo(phaseKey: string) {
  return PHASES.find((p) => p.key === phaseKey) || { label: phaseKey, icon: 'ri-information-line', order: 0 };
}

function getProgress(phaseKey: string): number {
  const phase = PHASES.find((p) => p.key === phaseKey);
  if (!phase) return 0;
  return Math.round((phase.order / PHASES.length) * 100);
}

export default function CustomerPortalDashboard() {
  const navigate = useNavigate();
  const { user, loading: authLoading, signOut } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const headerAnim = useScrollAnimation();
  const cardsAnim = useScrollAnimation({ threshold: 0.05 });

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      navigate('/customer-portal/auth', { replace: true });
      return;
    }

    const fetchProjects = async () => {
      setLoading(true);
      setError(false);
      try {
        const { data, error: fetchError } = await supabase
          .from('customer_projects')
          .select('*')
          .eq('customer_id', user.id)
          .order('created_at', { ascending: false });

        if (fetchError) throw fetchError;

        const withPhotos: Project[] = (data || []).map((p: any) => ({
          ...p,
          photo_count: 0,
        }));
        setProjects(withPhotos);
      } catch {
        setError(true);
      } finally {
        setLoading(false);
      }
    };

    fetchProjects();
  }, [user, authLoading, navigate]);

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-charcoal-deep flex items-center justify-center">
        <div className="text-white/40 text-sm flex items-center gap-2">
          <i className="ri-loader-4-line animate-spin" />
          Loading your projects...
        </div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="My Projects | Customer Portal | Corner Stone Roofing"
        description="Track your roofing project progress, view photos, and stay updated on your Corner Stone Construction project in Evansville Indiana."
        canonical="/customer-portal"
      />

      {/* Header bar */}
      <div className="pt-28 md:pt-32 pb-0 px-6 md:px-10 lg:px-16">
        <div
          ref={headerAnim.ref as React.RefObject<HTMLDivElement>}
          className={`max-w-5xl mx-auto anim-fade-up ${headerAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-10">
            <div>
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-2">Customer Portal</p>
              <h1 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}>
                My Projects
              </h1>
              <p className="text-white/40 text-sm mt-2 max-w-md">
                Welcome back — here's the real-time status of your projects with Corner Stone.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-white/30 text-xs hidden sm:inline">{user.email}</span>
              <button
                onClick={() => signOut().then(() => navigate('/'))}
                className="border border-white/10 hover:border-orange/50 text-white/40 hover:text-orange text-xs px-4 py-2 uppercase tracking-wider transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-logout-box-line mr-1.5" />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Projects grid */}
      <div className="px-6 md:px-10 lg:px-16 pb-20 md:pb-28">
        <div
          ref={cardsAnim.ref as React.RefObject<HTMLDivElement>}
          className={`max-w-5xl mx-auto anim-fade-up ${cardsAnim.isVisible ? 'is-visible' : ''}`}
        >
          {error ? (
            <div className="border border-red-500/20 bg-red-500/5 p-8 text-center">
              <div className="w-12 h-12 flex items-center justify-center bg-red-500/10 text-red-400 mx-auto mb-4">
                <i className="ri-error-warning-line text-2xl" />
              </div>
              <p className="text-white text-sm font-semibold mb-2">Couldn't load your projects</p>
              <p className="text-white/40 text-xs mb-4">Something went wrong fetching your data. Please try again.</p>
              <button
                onClick={() => window.location.reload()}
                className="border border-white/10 hover:border-orange/50 text-white/60 hover:text-orange text-xs px-5 py-2.5 uppercase tracking-wider transition-colors cursor-pointer"
              >
                <i className="ri-refresh-line mr-1.5" />
                Retry
              </button>
            </div>
          ) : projects.length === 0 ? (
            <div className="border border-white/10 bg-charcoal-mid p-10 md:p-14 text-center">
              <div className="w-16 h-16 flex items-center justify-center bg-white/5 text-white/20 mx-auto mb-5">
                <i className="ri-folder-open-line text-3xl" />
              </div>
              <h2 className="font-display text-white text-xl uppercase tracking-wider mb-3">No Projects Yet</h2>
              <p className="text-white/40 text-sm max-w-sm mx-auto leading-relaxed mb-6">
                Your active roofing projects will appear here once work begins. Your project manager can set up access for you — give us a call if you expected to see a project here.
              </p>
              <a
                href="tel:8122135997"
                className="inline-flex items-center gap-2 bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-6 py-3 uppercase tracking-wider transition-colors whitespace-nowrap"
              >
                <i className="ri-phone-line" />
                Call 812-213-5997
              </a>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {projects.map((project, i) => {
                const phase = getPhaseInfo(project.current_phase);
                const progress = getProgress(project.current_phase);
                const isComplete = project.current_phase === 'completed';

                return (
                  <button
                    key={project.id}
                    onClick={() => navigate(`/customer-portal/project/${project.id}`)}
                    className="text-left border border-white/10 bg-charcoal-mid hover:border-orange/40 transition-all duration-300 p-6 md:p-7 group cursor-pointer w-full"
                    style={{ transitionDelay: `${i * 60}ms` }}
                  >
                    {/* Project name + badge */}
                    <div className="flex items-start justify-between gap-3 mb-4">
                      <div>
                        <h3 className="font-display text-white text-lg uppercase tracking-wider group-hover:text-orange transition-colors">
                          {project.project_name}
                        </h3>
                        <p className="text-white/35 text-xs mt-1">{project.address}</p>
                      </div>
                      <span className={`text-xs font-bold uppercase tracking-widest px-2.5 py-1 flex-shrink-0 ${isComplete ? 'bg-green-500/15 text-green-400 border border-green-500/20' : 'bg-orange/15 text-orange border border-orange/20'}`}>
                        {SERVICE_LABELS[project.service_type] || project.service_type}
                      </span>
                    </div>

                    {/* Progress bar */}
                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className="w-5 h-5 flex items-center justify-center text-orange">
                            <i className={`${phase.icon} text-sm`} />
                          </div>
                          <span className="text-white/60 text-xs font-semibold uppercase tracking-wide">{phase.label}</span>
                        </div>
                        <span className="text-white/25 text-xs">{progress}%</span>
                      </div>
                      <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-700 ${isComplete ? 'bg-green-500' : 'bg-orange'}`}
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                    </div>

                    {/* Meta row */}
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-white/25">
                        Updated {new Date(project.phase_updated_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      </span>
                      <div className="flex items-center gap-1.5 text-orange text-xs font-semibold uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity">
                        View Details
                        <i className="ri-arrow-right-line" />
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}