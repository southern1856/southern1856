import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import PageSEO from '@/components/feature/PageSEO';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

export default function PortalAuthPage() {
  const navigate = useNavigate();
  const { user, loading, signIn, signUp, error, clearError } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');

  const hero = useScrollAnimation();

  useEffect(() => {
    if (!loading && user) {
      navigate('/customer-portal', { replace: true });
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    clearError();
    setSuccessMsg('');
  }, [mode, clearError]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setSuccessMsg('');

    if (mode === 'login') {
      const ok = await signIn(email, password);
      if (ok) navigate('/customer-portal', { replace: true });
    } else {
      const ok = await signUp(email, password);
      if (ok) {
        setSuccessMsg('Account created! Check your email for a confirmation link, then sign in.');
      }
    }
    setSubmitting(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-charcoal-deep flex items-center justify-center">
        <div className="text-white/40 text-sm flex items-center gap-2">
          <i className="ri-loader-4-line animate-spin" />
          Loading...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Customer Portal Login | Track Your Roof Project | Corner Stone Roofing"
        description="Log in to your Corner Stone customer portal to track your roofing project progress, view photos, and communicate with your project team in Evansville Indiana."
        keywords="roofing project tracker, customer portal, track roof project, construction project tracking Evansville"
        canonical="/customer-portal/auth"
      />

      <section className="relative min-h-screen flex items-center justify-center px-6 py-20">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/80 via-charcoal-deep/95 to-charcoal-deep" />
          <div className="absolute inset-0 opacity-[0.015]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '60px 60px' }} />
        </div>

        <div
          ref={hero.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full max-w-md anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
        >
          {/* Branding */}
          <div className="text-center mb-10">
            <a href="/" className="inline-block">
              <div className="flex items-center justify-center gap-3 mb-4">
                <div className="w-11 h-11 flex items-center justify-center bg-white rounded-lg">
                  <img
                    src="/logo.svg"
                    alt="Corner Stone"
                    className="h-9 w-9 object-contain rounded-md"
                  />
                </div>
                <span className="font-display text-white text-xl uppercase tracking-wider">Corner Stone</span>
              </div>
            </a>
            <h1 className="font-display text-white text-3xl uppercase tracking-wider mb-2">Customer Portal</h1>
            <p className="text-white/40 text-sm">Track your project progress in real time</p>
          </div>

          {/* Form card */}
          <div className="bg-charcoal-mid border border-white/10 p-8">
            {/* Tabs */}
            <div className="flex border border-white/10 mb-7">
              <button
                onClick={() => setMode('login')}
                className={`flex-1 py-3 text-sm font-semibold uppercase tracking-wider transition-colors cursor-pointer ${mode === 'login' ? 'bg-orange text-white' : 'bg-transparent text-white/40 hover:text-white/70'}`}
              >
                Sign In
              </button>
              <button
                onClick={() => setMode('signup')}
                className={`flex-1 py-3 text-sm font-semibold uppercase tracking-wider transition-colors cursor-pointer ${mode === 'signup' ? 'bg-orange text-white' : 'bg-transparent text-white/40 hover:text-white/70'}`}
              >
                Create Account
              </button>
            </div>

            {successMsg ? (
              <div className="text-center py-6">
                <div className="w-14 h-14 flex items-center justify-center bg-green-500/10 text-green-500 mx-auto mb-4">
                  <i className="ri-check-double-line text-2xl" />
                </div>
                <p className="text-white text-sm leading-relaxed mb-6">{successMsg}</p>
                <button
                  onClick={() => { setMode('login'); setSuccessMsg(''); }}
                  className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-8 py-3 uppercase tracking-wider transition-colors cursor-pointer whitespace-nowrap"
                >
                  Go to Sign In
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-white/60 text-xs font-semibold uppercase tracking-wider mb-2">Email Address</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-charcoal-deep border border-white/10 focus:border-orange/50 text-white text-sm px-4 py-3 outline-none placeholder:text-white/25 transition-colors"
                    placeholder="you@email.com"
                  />
                </div>
                <div>
                  <label className="block text-white/60 text-xs font-semibold uppercase tracking-wider mb-2">Password</label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-charcoal-deep border border-white/10 focus:border-orange/50 text-white text-sm px-4 py-3 outline-none placeholder:text-white/25 transition-colors"
                    placeholder="Min 6 characters"
                  />
                </div>

                {error && (
                  <div className="bg-red-500/10 border border-red-500/20 p-3 flex items-start gap-2.5">
                    <i className="ri-error-warning-line text-red-400 text-sm flex-shrink-0 mt-0.5" />
                    <p className="text-red-300 text-xs leading-relaxed">{error}</p>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-orange hover:bg-orange-dark disabled:bg-stone-600 text-white text-sm font-semibold py-3.5 uppercase tracking-widest transition-colors cursor-pointer whitespace-nowrap flex items-center justify-center gap-2"
                >
                  {submitting ? (
                    <><i className="ri-loader-4-line animate-spin" />Please wait...</>
                  ) : mode === 'login' ? (
                    'Sign In'
                  ) : (
                    'Create Account'
                  )}
                </button>

                {mode === 'login' && (
                  <p className="text-white/25 text-xs text-center">
                    Don't have an account? Your project manager can create one for you.
                  </p>
                )}
              </form>
            )}
          </div>

          {/* Help link */}
          <div className="text-center mt-6">
            <a
              href="tel:8122135997"
              className="text-white/30 hover:text-orange text-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <i className="ri-phone-line" />
              Need help? Call 812-213-5997
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}