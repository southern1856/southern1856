import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import PageSEO from '@/components/feature/PageSEO';

interface Project {
  id: number;
  customer_id: string;
  project_name: string;
  address: string;
  service_type: string;
  current_phase: string;
  phase_updated_at: string;
  estimated_completion: string | null;
  notes: string | null;
  created_at: string;
}

interface ProjectPhoto {
  id: number;
  project_id: number;
  phase: string;
  url: string;
  caption: string;
  uploaded_at: string;
}

interface ProjectMessage {
  id: number;
  project_id: number;
  sender: string;
  sender_name: string;
  message: string;
  created_at: string;
}

type TabKey = 'timeline' | 'messages' | 'warranty';

const TABS: { key: TabKey; label: string; icon: string }[] = [
  { key: 'timeline', label: 'Timeline', icon: 'ri-timeline-view' },
  { key: 'messages', label: 'Messages', icon: 'ri-chat-3-line' },
  { key: 'warranty', label: 'Docs & Warranty', icon: 'ri-shield-check-line' },
];

const ALL_PHASES = [
  { key: 'inspection_scheduled', label: 'Inspection Scheduled', icon: 'ri-calendar-check-line', desc: 'Your free inspection has been booked' },
  { key: 'inspection_complete', label: 'Inspection Complete', icon: 'ri-search-eye-line', desc: 'We\'ve inspected your roof and documented everything' },
  { key: 'estimate_sent', label: 'Estimate Sent', icon: 'ri-file-list-3-line', desc: 'Your detailed written estimate is ready' },
  { key: 'estimate_approved', label: 'Estimate Approved', icon: 'ri-check-double-line', desc: 'You\'ve approved the estimate — we\'re moving forward' },
  { key: 'materials_ordered', label: 'Materials Ordered', icon: 'ri-truck-line', desc: 'Premium materials are on the way' },
  { key: 'installation_scheduled', label: 'Installation Scheduled', icon: 'ri-calendar-event-line', desc: 'Your install date is locked in' },
  { key: 'tear_off', label: 'Tear-Off In Progress', icon: 'ri-hammer-line', desc: 'Old materials being removed' },
  { key: 'installation_in_progress', label: 'Installation In Progress', icon: 'ri-building-line', desc: 'New materials going up — looking great' },
  { key: 'final_walkthrough', label: 'Final Walkthrough', icon: 'ri-walk-line', desc: 'We\'ll walk the finished job with you' },
  { key: 'completed', label: 'Completed', icon: 'ri-checkbox-circle-line', desc: 'Job complete — your warranty is active' },
];

const SERVICE_LABELS: Record<string, string> = {
  roof_replacement: 'Roof Replacement',
  storm_repair: 'Storm Damage Repair',
  gutter_install: 'Gutter Installation',
  siding_install: 'Siding Installation',
  commercial_roofing: 'Commercial Roofing',
  exterior_package: 'Complete Exterior Package',
};

const WARRANTY_INFO: Record<string, { title: string; years: string; coverage: string; details: string[] }> = {
  roof_replacement: {
    title: 'Owens Corning Lifetime Warranty',
    years: '50 Years',
    coverage: 'Full material replacement + 25-year workmanship guarantee',
    details: [
      'Owens Corning Platinum Preferred Contractor warranty — non-prorated',
      '25-year Corner Stone workmanship guarantee against leaks',
      'Wind resistance up to 130 mph covered',
      'Transferable to next homeowner (one-time)',
    ],
  },
  storm_repair: {
    title: 'Storm Repair Workmanship Warranty',
    years: '10 Years',
    coverage: 'Full workmanship + manufacturer material warranty',
    details: [
      '10-year Corner Stone workmanship guarantee on all repairs',
      'Manufacturer shingle warranty applies to replaced sections',
      'Free annual inspection for 3 years post-repair',
      'Priority emergency service for warranty customers',
    ],
  },
  gutter_install: {
    title: 'Gutter Protection Warranty',
    years: '20 Years',
    coverage: 'Seamless gutter material + 5-year installation guarantee',
    details: [
      '20-year manufacturer warranty on seamless aluminum gutters',
      '5-year Corner Stone installation guarantee',
      'Free gutter cleaning for first year',
      'Clog-free performance guarantee on gutter guards',
    ],
  },
  siding_install: { title: 'Siding Installation Warranty', years: '30 Years', coverage: 'Material + 10-year workmanship', details: ['30-year manufacturer warranty on siding materials', '10-year Corner Stone installation guarantee', 'Fade and hail resistance coverage included', 'Transferable warranty'] },
  commercial_roofing: { title: 'Commercial Roof Warranty', years: '20 Years', coverage: 'TPO/EPDM material + 10-year labor', details: ['20-year manufacturer material warranty', '10-year Corner Stone labor and workmanship', 'Annual inspection included for warranty period', '24/7 emergency leak response for warranty customers'] },
  exterior_package: { title: 'Complete Exterior Warranty Package', years: 'Varies by System', coverage: 'Multi-system warranty coordination', details: ['Roof: 50-year Owens Corning warranty', 'Siding: 30-year manufacturer warranty', 'Gutters: 20-year material warranty', 'All workmanship guaranteed by Corner Stone for 10+ years'] },
};

const WARRANTY_DOCS = [
  { name: 'Certificate of Completion', icon: 'ri-file-check-line', desc: 'Official project completion document' },
  { name: 'Warranty Registration', icon: 'ri-shield-check-line', desc: 'Manufacturer warranty registration' },
  { name: 'Material Specifications', icon: 'ri-file-list-3-line', desc: 'Full materials list and specs' },
  { name: 'Final Inspection Report', icon: 'ri-search-eye-line', desc: 'Post-installation inspection findings' },
  { name: 'Care & Maintenance Guide', icon: 'ri-book-open-line', desc: 'How to care for your new roof' },
];

function getCurrentPhaseIndex(phaseKey: string): number {
  return ALL_PHASES.findIndex((p) => p.key === phaseKey);
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit',
  });
}

function formatDateShort(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export default function ProjectDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [project, setProject] = useState<Project | null>(null);
  const [photos, setPhotos] = useState<ProjectPhoto[]>([]);
  const [messages, setMessages] = useState<ProjectMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState<ProjectPhoto | null>(null);
  const [activeTab, setActiveTab] = useState<TabKey>('timeline');

  const headerAnim = useScrollAnimation();

  useEffect(() => {
    if (authLoading) return;
    if (!user) { navigate('/customer-portal/auth', { replace: true }); return; }
    if (!id) return;

    const fetchData = async () => {
      setLoading(true);
      setError(false);
      try {
        const { data: projData, error: projError } = await supabase
          .from('customer_projects').select('*').eq('id', id).eq('customer_id', user.id).maybeSingle();
        if (projError || !projData) throw new Error('Project not found');
        setProject(projData as Project);

        const [{ data: photoData }, { data: msgData }] = await Promise.all([
          supabase.from('project_photos').select('*').eq('project_id', id).order('uploaded_at', { ascending: true }),
          supabase.from('project_messages').select('*').eq('project_id', id).order('created_at', { ascending: false }),
        ]);
        setPhotos((photoData || []) as ProjectPhoto[]);
        setMessages((msgData || []) as ProjectMessage[]);
      } catch { setError(true); }
      finally { setLoading(false); }
    };
    fetchData();
  }, [user, authLoading, id, navigate]);

  useEffect(() => {
    if (selectedPhoto) { document.body.style.overflow = 'hidden'; }
    else { document.body.style.overflow = ''; }
    return () => { document.body.style.overflow = ''; };
  }, [selectedPhoto]);

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-charcoal-deep flex items-center justify-center">
        <div className="text-white/40 text-sm flex items-center gap-2"><i className="ri-loader-4-line animate-spin" />Loading project...</div>
      </div>
    );
  }

  if (error || !project) {
    return (
      <div className="min-h-screen bg-charcoal-deep flex items-center justify-center px-6">
        <div className="text-center max-w-sm">
          <div className="w-14 h-14 flex items-center justify-center bg-red-500/10 text-red-400 mx-auto mb-4"><i className="ri-error-warning-line text-2xl" /></div>
          <p className="text-white text-sm font-semibold mb-2">Project Not Found</p>
          <p className="text-white/40 text-xs mb-5">We couldn't find this project. It may have been removed or you may not have access.</p>
          <button onClick={() => navigate('/customer-portal')} className="border border-white/10 hover:border-orange/50 text-white/60 hover:text-orange text-xs px-5 py-2.5 uppercase tracking-wider transition-colors cursor-pointer"><i className="ri-arrow-left-line mr-1.5" />Back to Projects</button>
        </div>
      </div>
    );
  }

  const currentIdx = getCurrentPhaseIndex(project.current_phase);
  const isComplete = project.current_phase === 'completed';
  const warranty = WARRANTY_INFO[project.service_type] || WARRANTY_INFO.roof_replacement;

  const photosByPhase: Record<string, ProjectPhoto[]> = {};
  photos.forEach((p) => {
    if (!photosByPhase[p.phase]) photosByPhase[p.phase] = [];
    photosByPhase[p.phase].push(p);
  });

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO title={`${project.project_name} | Project Tracker | Corner Stone Roofing`} description={`Track your ${project.project_name} progress at ${project.address}. View timeline, crew messages, warranty & documents.`} canonical={`/customer-portal/project/${id}`} />

      {/* Header */}
      <div className="pt-28 md:pt-32 pb-0 px-6 md:px-10 lg:px-16">
        <div ref={headerAnim.ref as React.RefObject<HTMLDivElement>} className={`max-w-4xl mx-auto anim-fade-up ${headerAnim.isVisible ? 'is-visible' : ''}`}>
          <button onClick={() => navigate('/customer-portal')} className="text-white/30 hover:text-orange text-xs uppercase tracking-wider transition-colors mb-5 cursor-pointer flex items-center gap-1.5"><i className="ri-arrow-left-line" />My Projects</button>
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-8">
            <div>
              <h1 className="font-display text-white uppercase tracking-wider leading-none mb-2" style={{ fontSize: 'clamp(1.8rem, 4vw, 3rem)' }}>{project.project_name}</h1>
              <p className="text-white/35 text-sm">{project.address}</p>
            </div>
            <div className="flex items-center gap-3">
              <span className={`text-xs font-bold uppercase tracking-widest px-3 py-1.5 border ${isComplete ? 'bg-green-500/10 text-green-400 border-green-500/20' : 'bg-orange/10 text-orange border-orange/20'}`}>{SERVICE_LABELS[project.service_type] || project.service_type}</span>
              {project.estimated_completion && !isComplete && <span className="text-white/25 text-xs">Est: {new Date(project.estimated_completion).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>}
            </div>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-white/10 mb-0">
            {TABS.map((tab) => (
              <button key={tab.key} onClick={() => setActiveTab(tab.key)} className={`flex items-center gap-2 px-5 py-3 text-sm font-semibold uppercase tracking-wider transition-all cursor-pointer border-b-2 -mb-px whitespace-nowrap ${activeTab === tab.key ? 'text-orange border-orange' : 'text-white/40 border-transparent hover:text-white/70'}`}>
                <i className={`${tab.icon} text-sm`} />{tab.label}
                {tab.key === 'messages' && messages.length > 0 && <span className="bg-orange/20 text-orange text-xs px-1.5 py-0.5 rounded-full">{messages.length}</span>}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 md:px-10 lg:px-16 pb-20 md:pb-28">
        <div className="max-w-4xl mx-auto pt-8">

          {/* === TIMELINE TAB === */}
          {activeTab === 'timeline' && (
            <div>
              <div className="relative">
                <div className="absolute left-5 top-3 bottom-3 w-px bg-white/10" />
                <div className="space-y-0">
                  {ALL_PHASES.map((phase, i) => {
                    const isDone = i <= currentIdx;
                    const isCurrent = i === currentIdx;
                    return (
                      <div key={phase.key} className="relative flex items-start gap-5 py-3.5">
                        <div className={`relative z-10 w-10 h-10 flex items-center justify-center border flex-shrink-0 transition-colors ${isDone ? 'bg-orange border-orange text-white' : isCurrent ? 'border-orange/50 bg-orange/10 text-orange' : 'border-white/10 bg-charcoal-mid text-white/20'}`}>
                          <i className={`${phase.icon} text-sm`} />
                        </div>
                        <div className="min-w-0 pt-1">
                          <p className={`font-semibold text-sm uppercase tracking-wide ${isDone ? 'text-white' : isCurrent ? 'text-orange' : 'text-white/25'}`}>
                            {phase.label}
                            {isCurrent && !isDone && <span className="ml-2 inline-flex items-center gap-1 text-orange text-xs font-normal normal-case"><span className="w-1.5 h-1.5 rounded-full bg-orange animate-pulse" />Current</span>}
                          </p>
                          <p className={`text-xs mt-0.5 ${isDone ? 'text-white/35' : 'text-white/15'}`}>{phase.desc}</p>
                          {photosByPhase[phase.key] && (
                            <div className="flex gap-2 mt-2 flex-wrap">
                              {photosByPhase[phase.key].map((photo) => (
                                <button key={photo.id} onClick={() => setSelectedPhoto(photo)} className="relative overflow-hidden cursor-pointer group flex-shrink-0" style={{ width: '80px', height: '56px' }}>
                                  <img src={photo.url} alt={photo.caption || phase.label} className="w-full h-full object-cover object-top transition-transform duration-300 group-hover:scale-105" />
                                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Notes */}
              {project.notes && (
                <div className="border border-white/10 bg-charcoal-mid p-6 mt-10">
                  <h3 className="text-white text-sm font-semibold uppercase tracking-wider mb-3 flex items-center gap-2"><i className="ri-sticky-note-line text-orange" />Notes from Your Team</h3>
                  <p className="text-white/50 text-sm leading-relaxed">{project.notes}</p>
                </div>
              )}
            </div>
          )}

          {/* === MESSAGES TAB === */}
          {activeTab === 'messages' && (
            <div>
              {messages.length === 0 ? (
                <div className="border border-white/10 bg-charcoal-mid p-10 text-center">
                  <div className="w-14 h-14 flex items-center justify-center bg-white/5 text-white/20 mx-auto mb-4"><i className="ri-chat-off-line text-2xl" /></div>
                  <p className="text-white text-sm font-semibold mb-2">No Messages Yet</p>
                  <p className="text-white/40 text-xs max-w-sm mx-auto">Your project team will send updates here as work progresses. You can also call your project manager anytime.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {messages.map((msg) => (
                    <div key={msg.id} className="border border-white/10 bg-charcoal-mid p-5 md:p-6 hover:border-orange/20 transition-colors">
                      <div className="flex items-start gap-4">
                        <div className={`w-9 h-9 flex items-center justify-center flex-shrink-0 ${msg.sender === 'crew' ? 'bg-orange/15 text-orange' : 'bg-white/10 text-white/40'}`}>
                          <i className={`${msg.sender === 'crew' ? 'ri-team-line' : 'ri-user-line'} text-sm`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-3 mb-2 flex-wrap">
                            <span className="text-white text-sm font-semibold">{msg.sender_name}</span>
                            <span className="bg-orange/10 text-orange text-[10px] font-bold uppercase tracking-wider px-2 py-0.5">Crew</span>
                          </div>
                          <p className="text-white/60 text-sm leading-relaxed">{msg.message}</p>
                          <p className="text-white/25 text-xs mt-2">{formatDate(msg.created_at)}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Quick contact */}
              <div className="mt-8 p-5 border border-white/10 bg-charcoal-mid flex flex-col sm:flex-row items-center justify-between gap-4">
                <p className="text-white/50 text-xs">Need to reach your project manager?</p>
                <a href="tel:8122135997" className="flex items-center gap-2 border border-white/20 hover:border-orange text-white/60 hover:text-orange text-sm font-semibold px-5 py-2.5 uppercase tracking-wider transition-colors whitespace-nowrap"><i className="ri-phone-line" />Call 812-213-5997</a>
              </div>
            </div>
          )}

          {/* === WARRANTY TAB === */}
          {activeTab === 'warranty' && (
            <div className="space-y-8">
              {/* Warranty Card */}
              <div className="border border-orange/30 bg-gradient-to-br from-orange/5 to-transparent p-6 md:p-8">
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-12 h-12 flex items-center justify-center bg-orange/15 text-orange flex-shrink-0"><i className="ri-shield-check-line text-xl" /></div>
                  <div>
                    <h3 className="font-display text-white text-xl uppercase tracking-wider mb-1">{warranty.title}</h3>
                    <p className="text-orange font-bold text-lg">{warranty.years}</p>
                  </div>
                </div>
                <p className="text-white/50 text-sm leading-relaxed mb-6">{warranty.coverage}</p>
                <ul className="space-y-3">
                  {warranty.details.map((d, i) => (
                    <li key={i} className="flex items-start gap-3 text-white/60 text-sm">
                      <i className="ri-check-fill text-green-500 text-sm mt-0.5 flex-shrink-0" />
                      {d}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Documents */}
              <div>
                <h3 className="font-display text-white text-lg uppercase tracking-wider mb-5 flex items-center gap-2"><i className="ri-folder-3-line text-orange" />Your Documents</h3>
                <div className="space-y-2">
                  {WARRANTY_DOCS.map((doc, i) => (
                    <div key={doc.name} className="border border-white/10 bg-charcoal-mid p-4 flex items-center gap-4 hover:border-orange/30 transition-colors group">
                      <div className="w-9 h-9 flex items-center justify-center bg-white/5 text-white/30 group-hover:text-orange group-hover:bg-orange/10 transition-colors flex-shrink-0"><i className={`${doc.icon} text-sm`} /></div>
                      <div className="flex-1 min-w-0">
                        <p className="text-white text-sm font-semibold">{doc.name}</p>
                        <p className="text-white/40 text-xs">{doc.desc}</p>
                      </div>
                      {isComplete || i < 2 ? (
                        <span className="text-green-500 text-xs flex items-center gap-1 flex-shrink-0"><i className="ri-check-line" />Available</span>
                      ) : (
                        <span className="text-white/25 text-xs flex items-center gap-1 flex-shrink-0"><i className="ri-time-line" />After completion</span>
                      )}
                    </div>
                  ))}
                </div>
                <p className="text-white/25 text-xs mt-4">Documents are uploaded as your project progresses. Physical copies are also mailed upon completion.</p>
              </div>
            </div>
          )}

          {/* Bottom CTA */}
          <div className="mt-10 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-white/30 text-xs">Have a question about your project? We're here to help.</p>
            <div className="flex items-center gap-3">
              <a href="tel:8122135997" className="border border-white/20 hover:border-orange text-white/60 hover:text-orange text-sm font-semibold px-5 py-2.5 uppercase tracking-wider transition-colors whitespace-nowrap flex items-center gap-2"><i className="ri-phone-line" />Call 812-213-5997</a>
              <button onClick={() => navigate('/customer-portal')} className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-5 py-2.5 uppercase tracking-wider transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"><i className="ri-arrow-left-line" />Back to Projects</button>
            </div>
          </div>
        </div>
      </div>

      {/* Photo lightbox */}
      {selectedPhoto && (
        <div className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-4" onClick={() => setSelectedPhoto(null)}>
          <button onClick={() => setSelectedPhoto(null)} className="absolute top-4 right-4 w-10 h-10 flex items-center justify-center bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer z-10" aria-label="Close"><i className="ri-close-line text-xl" /></button>
          <div className="relative max-w-4xl max-h-[85vh] w-full" onClick={(e) => e.stopPropagation()}>
            <img src={selectedPhoto.url} alt={selectedPhoto.caption || 'Project photo'} className="w-full h-full object-contain max-h-[80vh]" />
            {selectedPhoto.caption && (
              <div className="absolute bottom-0 left-0 right-0 bg-black/70 p-4">
                <p className="text-white text-sm">{selectedPhoto.caption}</p>
                <p className="text-white/40 text-xs mt-1">{new Date(selectedPhoto.uploaded_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' })}</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}