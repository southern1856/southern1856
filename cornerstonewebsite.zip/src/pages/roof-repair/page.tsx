import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import ContactSection from '@/components/feature/ContactSection';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { OFFERS } from '@/mocks/promotions';

const PROBLEMS = [
  {
    icon: 'ri-drop-line',
    title: 'Roof Leaks',
    desc: 'Water stains on ceilings, dripping during rain, or wet insulation — we track the source and seal it fast before mold sets in.',
  },
  {
    icon: 'ri-windy-line',
    title: 'Wind & Storm Damage',
    desc: 'Missing shingles, lifted flashing, or debris impact from Indiana storms. We tarp and repair same-day when needed.',
  },
  {
    icon: 'ri-hail-line',
    title: 'Hail Damage',
    desc: 'Dented shingles, cracked vents, bruised flashing. We inspect for hidden damage and help document everything for insurance.',
  },
  {
    icon: 'ri-home-smile-line',
    title: 'Sagging or Soft Spots',
    desc: 'Dips in the roofline or spongy decking signal structural issues. We diagnose rot, reinforce framing, and restore integrity.',
  },
  {
    icon: 'ri-flashlight-line',
    title: 'Flashing Failures',
    desc: 'Leaks around chimneys, skylights, vents, and valleys. We reseal and replace worn flashing with code-compliant materials.',
  },
  {
    icon: 'ri-stack-line',
    title: 'Shingle Granule Loss',
    desc: 'Bald patches mean your shingles are aging out. We patch affected areas or advise when a full replacement makes more sense.',
  },
];

const REPAIR_VS_REPLACE = [
  {
    label: 'Repair',
    when: [
      'Damage is localized to a small area',
      'Roof is less than 15 years old',
      'Underlayment and decking are still solid',
      'Missing or cracked shingles only',
      'Budget needs a short-term fix now',
    ],
  },
  {
    label: 'Replace',
    when: [
      'Damage covers more than 30% of roof',
      'Roof is 20+ years old',
      'Multiple layers of old shingles exist',
      'Widespread granule loss or curling',
      'Frequent leaks in different areas',
    ],
  },
];

const FAQS = [
  {
    q: 'How fast can you respond to a roof leak?',
    a: 'We offer same-day emergency tarping and temporary sealing for active leaks. Most non-emergency repairs are scheduled within 24–48 hours.',
  },
  {
    q: 'Will my homeowner insurance cover roof repairs?',
    a: 'If the damage is from a covered peril like wind, hail, or falling debris, insurance usually pays. We meet your adjuster on-site and document everything so you get the full payout.',
  },
  {
    q: 'How much does a typical roof repair cost in Evansville?',
    a: 'Minor repairs like sealing a leak or replacing a few shingles usually run $300–$800. Larger repairs involving decking or flashing replacement can be $1,200–$3,000. We give exact quotes after a free inspection.',
  },
  {
    q: 'Can you repair just part of my roof?',
    a: 'Absolutely. If the damage is isolated, we can patch the affected area and blend new materials to match your existing roof. We will always be honest if a partial repair is not the best long-term solution.',
  },
  {
    q: 'Do you offer emergency roof repair at night or on weekends?',
    a: 'Yes. Our 24/7 emergency line is 812-213-5997. We dispatch crews for tarping, temporary sealing, and storm damage anytime.',
  },
];

const schema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: FAQS.map((f) => ({
    '@type': 'Question',
    name: f.q,
    acceptedAnswer: { '@type': 'Answer', text: f.a },
  })),
};

const nearestExpiry = OFFERS
  .filter((o) => o.expires)
  .map((o) => o.expires!)
  .sort()[0] || '2026-12-31';

export default function RoofRepairPage() {
  const navigate = useNavigate();
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const openReaddyAgent = (prefill?: string) => {
    const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
    if (btn) btn.click();
    if (prefill) {
      setTimeout(() => {
        const input = document.querySelector('input[placeholder*="message"], textarea[placeholder*="message"], input[placeholder*="ask"], textarea[placeholder*="ask"]') as HTMLInputElement | HTMLTextAreaElement | null;
        if (input) {
          input.value = prefill;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          const form = input.closest('form');
          if (form) {
            const submitBtn = form.querySelector('button[type="submit"], button[aria-label*="send"], button svg') as HTMLElement | null;
            if (submitBtn) submitBtn.click();
          }
        }
      }, 900);
    }
  };

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roof Repair Evansville IN | Emergency Leak & Storm Damage Fixes"
        description="Fast, reliable roof repair in Evansville, Newburgh, and the Tri-State area. Same-day emergency tarping, leak repairs, storm damage, hail damage, and more. Free inspections. Call 812-213-5997."
        keywords="roof repair Evansville, roof leak repair Indiana, emergency roof repair Evansville, storm damage roof repair, hail damage roof repair, roof patching Evansville, roof tarping service"
        canonical="/roof-repair"
        schema={schema}
      />

      {/* Hero */}
      <section className="relative min-h-[70dvh] md:min-h-[80dvh] flex flex-col justify-center overflow-hidden">
        <div className="absolute inset-0 overflow-hidden">
          <img
            src="/placeholders/1200x800.svg"
            alt="Roof repair in Evansville Indiana"
            className="w-full h-full object-cover object-top opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/70 via-charcoal-deep/50 to-charcoal-deep" />
        </div>

        <div className="relative z-10 px-4 md:px-10 lg:px-16 pt-28 md:pt-32 pb-16">
          <div className="flex flex-wrap items-center gap-2 md:gap-3 mb-6">
            <span className="flex items-center gap-1.5 border border-white/15 bg-white/5 backdrop-blur-sm px-3 md:px-4 py-1.5 text-white/60 text-[10px] md:text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange inline-block" />
              24/7 Emergency Service
            </span>
            <span className="flex items-center gap-1.5 border border-white/15 bg-white/5 backdrop-blur-sm px-3 md:px-4 py-1.5 text-white/60 text-[10px] md:text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-green-400 inline-block" />
              Same-Day Tarping
            </span>
          </div>

          <h1
            className="font-display text-white leading-none tracking-wider uppercase text-5xl md:text-7xl lg:text-8xl max-w-5xl"
            style={{ fontSize: 'clamp(2.8rem, 7vw, 6.5rem)' }}
          >
            Roof Repair
            <br />
            <span className="text-orange">Done Right</span>
            <br />
            <span className="text-white/90">The First Time</span>
          </h1>

          <p className="text-white/60 text-sm md:text-base max-w-lg mt-6 md:mt-8 leading-relaxed">
            Leaks, storm damage, missing shingles, and sagging spots — we fix them all across Evansville, Newburgh, and the Tri-State area. Free inspection, honest quote, fast turnaround.
          </p>

          <div className="mt-6 md:mt-8">
            <CountdownTimer expiresAt={nearestExpiry} variant="banner" />
            <div className="mt-3">
              <SocialProofPulse />
            </div>
          </div>

          <div className="mt-8 md:mt-10 flex flex-col sm:flex-row gap-3 md:gap-4">
            <button
              onClick={() => navigate('/free-inspection')}
              className="group bg-orange hover:bg-orange-dark text-white font-semibold px-6 md:px-8 py-3.5 md:py-4 uppercase tracking-widest text-xs md:text-sm transition-all duration-300 whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
            >
              Free Inspection
              <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform duration-200" />
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-6 md:px-8 py-3.5 md:py-4 uppercase tracking-widest text-xs md:text-sm transition-all duration-300 whitespace-nowrap flex items-center justify-center gap-3"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>

          {/* AI Trigger */}
          <div className="mt-6 flex items-center gap-3">
            <button
              onClick={() => openReaddyAgent("I have a roof leak. How fast can you fix it?")}
              className="group flex items-center gap-2 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-question-answer-line text-sm" />
              <span className="underline underline-offset-2">Ask AI how fast we can fix your leak</span>
              <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* Problems We Fix */}
      <section className="py-20 md:py-28 px-4 md:px-10 lg:px-16">
        <div className="mb-14 md:mb-20">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Common Issues</p>
          <h2
            className="font-display text-white uppercase tracking-wider leading-none"
            style={{ fontSize: 'clamp(2.2rem, 5vw, 4.5rem)' }}
          >
            Problems We Fix
            <br />
            <span className="text-white/50">Every Single Day</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-white/10">
          {PROBLEMS.map((p) => (
            <div
              key={p.title}
              className="bg-charcoal-deep p-8 md:p-10 group hover:bg-charcoal-mid transition-colors duration-300"
            >
              <div className="w-12 h-12 flex items-center justify-center border border-orange/40 mb-6 group-hover:bg-orange group-hover:border-orange transition-all duration-300">
                <i className={`${p.icon} text-orange group-hover:text-white text-xl transition-colors duration-300`} />
              </div>
              <h3 className="font-serif font-bold text-white text-lg md:text-xl mb-3 leading-snug">{p.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Repair vs Replace */}
      <section className="py-20 md:py-28 px-4 md:px-10 lg:px-16 bg-charcoal-mid">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Honest Guidance</p>
            <h2
              className="font-display text-white uppercase tracking-wider leading-none mb-6"
              style={{ fontSize: 'clamp(2rem, 4.5vw, 4rem)' }}
            >
              Repair or Replace?
              <br />
              <span className="text-white/50">We Will Tell You Straight</span>
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-md">
              Not every damaged roof needs a full replacement. We inspect the decking, underlayment, and shingle condition to give you an honest recommendation — never a sales pitch.
            </p>
            <button
              onClick={() => navigate('/free-inspection')}
              className="mt-8 group bg-orange hover:bg-orange-dark text-white font-semibold px-6 py-3.5 uppercase tracking-widest text-xs transition-all duration-300 whitespace-nowrap cursor-pointer flex items-center gap-2"
            >
              Get Free Inspection
              <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform duration-200" />
            </button>
            {/* AI Trigger */}
            <div className="mt-4">
              <button
                onClick={() => openReaddyAgent("Should I repair my roof or replace it?")}
                className="group flex items-center gap-2 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-question-answer-line text-sm" />
                <span className="underline underline-offset-2">Ask AI: repair or replace?</span>
                <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
              </button>
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-6">
            {REPAIR_VS_REPLACE.map((col) => (
              <div key={col.label} className="flex-1 border border-white/10 p-6 md:p-8">
                <h3 className={`font-display uppercase tracking-wider text-xl md:text-2xl mb-6 ${col.label === 'Repair' ? 'text-green-400' : 'text-orange'}`}>
                  {col.label}
                </h3>
                <ul className="space-y-4">
                  {col.when.map((item) => (
                    <li key={item} className="flex items-start gap-3 text-white/60 text-sm leading-relaxed">
                      <i className={`${col.label === 'Repair' ? 'ri-check-line text-green-400' : 'ri-close-line text-orange'} mt-0.5`} />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Emergency CTA */}
      <section className="relative py-20 md:py-28 px-4 md:px-10 lg:px-16 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1200x600.svg"
            alt="Emergency roof repair during storm"
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-charcoal-deep via-charcoal-deep/90 to-charcoal-deep/70" />
        </div>

        <div className="relative z-10 max-w-3xl">
          <div className="flex items-center gap-2 mb-6">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-red-400 text-xs uppercase tracking-[0.25em] font-semibold">Active Storm Season</span>
          </div>
          <h2
            className="font-display text-white uppercase tracking-wider leading-none mb-6"
            style={{ fontSize: 'clamp(2.2rem, 5vw, 4.5rem)' }}
          >
            Emergency?
            <br />
            <span className="text-orange">We Are On It Now</span>
          </h2>
          <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-lg mb-8">
            Active leak? Tree on your roof? Hail just rolled through? Call our 24/7 emergency line and we will get a crew out for tarping and temporary sealing — usually within the hour.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4">
            <a
              href="tel:8122135997"
              className="bg-red-600 hover:bg-red-500 text-white font-semibold px-6 md:px-8 py-3.5 md:py-4 uppercase tracking-widest text-xs md:text-sm transition-all duration-300 whitespace-nowrap flex items-center justify-center gap-2 cursor-pointer"
            >
              <i className="ri-phone-line" />
              Call 812-213-5997
            </a>
            <button
              onClick={() => navigate('/emergency-services')}
              className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-6 md:px-8 py-3.5 md:py-4 uppercase tracking-widest text-xs md:text-sm transition-all duration-300 whitespace-nowrap flex items-center justify-center gap-2 cursor-pointer"
            >
              Emergency Services
              <i className="ri-arrow-right-line" />
            </button>
          </div>
          {/* AI Trigger */}
          <div className="mt-5">
            <button
              onClick={() => openReaddyAgent("My roof is leaking right now. What should I do?")}
              className="group flex items-center gap-2 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-question-answer-line text-sm" />
              <span className="underline underline-offset-2">Ask AI what to do for an active leak</span>
              <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-20 md:py-28 px-4 md:px-10 lg:px-16 bg-charcoal-mid">
        <div className="text-center mb-14 md:mb-20">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">How It Works</p>
          <h2
            className="font-display text-white uppercase tracking-wider leading-none"
            style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}
          >
            From Call to Fixed
            <br />
            <span className="text-white/50">In as Little as 24 Hours</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 md:gap-6">
          {[
            { num: '01', title: 'Call or Book Online', desc: 'Reach us 24/7 by phone or schedule a free inspection through our site.' },
            { num: '02', title: 'Free On-Site Diagnosis', desc: 'We inspect the damage, photograph everything, and explain exactly what needs fixing.' },
            { num: '03', title: 'Honest Quote & Plan', desc: 'You get a clear, itemized quote with no pressure. We will tell you if a repair or replacement makes more sense.' },
            { num: '04', title: 'Fast, Clean Repair', desc: 'Our crew fixes the damage, cleans the site, and you get photos of the completed work.' },
          ].map((step, i) => (
            <div key={step.num} className="relative">
              {i < 3 && (
                <div className="hidden md:block absolute top-8 left-full w-full h-px bg-white/10" />
              )}
              <span className="font-display text-white/10 text-5xl md:text-6xl leading-none block mb-4">{step.num}</span>
              <h3 className="font-serif font-bold text-white text-lg md:text-xl mb-3">{step.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-20 md:py-28 px-4 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Service Area</p>
            <h2
              className="font-display text-white uppercase tracking-wider leading-none mb-6"
              style={{ fontSize: 'clamp(2rem, 4.5vw, 4rem)' }}
            >
              Roof Repair
              <br />
              <span className="text-white/50">Across the Tri-State</span>
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-md mb-8">
              We cover Evansville and every surrounding community within about an hour drive. If you are in our service area, the inspection is always free.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {[
                'Evansville, IN',
                'Newburgh, IN',
                'Henderson, KY',
                'Boonville, IN',
                'Owensboro, KY',
                'Mount Vernon, IN',
                'Princeton, IN',
                'Jasper, IN',
                'Madisonville, KY',
                'Vincennes, IN',
                'Washington, IN',
                'Tell City, IN',
              ].map((city) => (
                <div key={city} className="flex items-center gap-2 text-white/60 text-sm">
                  <i className="ri-map-pin-line text-orange text-xs" />
                  {city}
                </div>
              ))}
            </div>
          </div>
          <div className="relative h-72 md:h-96 overflow-hidden border border-white/10">
            <img
              src="/placeholders/800x600.svg"
              alt="Evansville Indiana service area map view"
              className="w-full h-full object-cover opacity-60"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-charcoal-deep/80 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6">
              <p className="text-white/70 text-sm">Free roof repair estimates anywhere in the shaded service area.</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 md:py-28 px-4 md:px-10 lg:px-16 bg-charcoal-mid">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-14 md:mb-20">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">FAQ</p>
            <h2
              className="font-display text-white uppercase tracking-wider leading-none"
              style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}
            >
              Common Roof Repair
              <br />
              <span className="text-white/50">Questions</span>
            </h2>
          </div>

          <div className="border-t border-white/10">
            {FAQS.map((faq, i) => (
              <div key={i} className="border-b border-white/10">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between py-5 md:py-6 text-left cursor-pointer group"
                >
                  <span className="font-serif font-bold text-white text-base md:text-lg pr-4 group-hover:text-orange transition-colors duration-200">
                    {faq.q}
                  </span>
                  <i
                    className={`ri-${openFaq === i ? 'subtract-line' : 'add-line'} text-orange flex-shrink-0 text-lg transition-transform duration-200`}
                  />
                </button>
                <div
                  className="overflow-hidden transition-all duration-300"
                  style={{ maxHeight: openFaq === i ? 300 : 0, opacity: openFaq === i ? 1 : 0 }}
                >
                  <p className="text-white/50 text-sm md:text-base leading-relaxed pb-5 md:pb-6 pr-8">
                    {faq.a}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 md:py-28 px-4 md:px-10 lg:px-16 text-center">
        <h2
          className="font-display text-white uppercase tracking-wider leading-none mb-6"
          style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}
        >
          Stop the Leak
          <br />
          <span className="text-orange">Today</span>
        </h2>
        <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-lg mx-auto mb-8">
          Every day you wait, water damage spreads. Book your free inspection now and get an honest repair quote with no pressure.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center">
          <button
            onClick={() => navigate('/free-inspection')}
            className="group bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-all duration-300 whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
          >
            Book Free Inspection
            <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform duration-200" />
          </button>
          <a
            href="tel:8122135997"
            className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-all duration-300 whitespace-nowrap flex items-center justify-center gap-3"
          >
            <i className="ri-phone-line text-orange" />
            812-213-5997
          </a>
        </div>
        {/* AI Trigger */}
        <div className="mt-6 flex justify-center">
          <button
            onClick={() => openReaddyAgent("How much does a typical roof repair cost in Evansville?")}
            className="group flex items-center gap-2 text-green-400 text-xs hover:text-green-300 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-question-answer-line text-sm" />
            <span className="underline underline-offset-2">Ask AI about repair costs</span>
            <i className="ri-arrow-right-line text-xs group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>
      </section>

      <ContactSection />
    </div>
  );
}