import AIRoofInspector from '@/components/feature/AIRoofInspector';
import PageSEO from '@/components/feature/PageSEO';
import { trackToolUsage } from '@/lib/toolAnalytics';

export default function AIInspector() {
  return (
    <div className="min-h-screen">
      <PageSEO
        title="AI Roof Inspector | Free Roof Damage Assessment | Corner Stone Evansville"
        description="Upload a photo of your roof and get an instant AI-powered damage assessment. Free, anonymous, and available 24/7. Based in Evansville, serving the Tri-State area."
        keywords="AI roof inspection, free roof damage assessment, roof photo analysis, hail damage detection, shingle condition check, Evansville roof inspection"
        canonical="/ai-inspector"
      />

      {/* Page header */}
      <div className="bg-charcoal-deep pt-24 md:pt-32 pb-8 md:pb-12 px-6 md:px-10 lg:px-16">
        <div className="max-w-3xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 border border-orange/30 bg-orange/5 px-4 py-2 mb-5">
            <i className="ri-robot-2-line text-orange text-sm" />
            <span className="text-orange text-xs font-semibold uppercase tracking-[0.25em]">AI-Powered</span>
          </div>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            AI Roof<br /><span className="text-orange">Inspector</span>
          </h1>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Upload a photo of your roof from the ground or driveway and our AI will analyze shingle condition, flashing, hail damage, and more — instantly and for free.
          </p>
        </div>
      </div>

      <AIRoofInspector onAnalysisComplete={() => trackToolUsage('ai-inspector', 'AI Roof Inspector')} />

      {/* How it works */}
      <div className="bg-warm-beige border-t border-charcoal/5 py-16 md:py-20 px-6 md:px-10 lg:px-16">
        <div className="max-w-4xl mx-auto">
          <h2 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider text-center mb-12">
            How the <span className="text-orange">AI Inspector</span> Works
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                icon: 'ri-camera-line',
                title: 'Snap a Photo',
                desc: 'Take a clear photo of your roof from your driveway or yard. No ladder needed — the AI works with ground-level shots.',
              },
              {
                step: '02',
                icon: 'ri-upload-cloud-2-line',
                title: 'Upload & Analyze',
                desc: 'Our AI scans shingles, flashing, valleys, and vents for wear, damage, and hail impact indicators in under 30 seconds.',
              },
              {
                step: '03',
                icon: 'ri-file-list-3-line',
                title: 'Get Your Report',
                desc: 'Receive a detailed damage breakdown, severity ratings, and actionable recommendations — no email or phone required.',
              },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="w-14 h-14 flex items-center justify-center bg-charcoal-deep text-orange mx-auto mb-5">
                  <i className={`${item.icon} text-xl`} />
                </div>
                <span className="font-display text-charcoal-deep/20 text-3xl tracking-wider">{item.step}</span>
                <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-widest mt-2 mb-3">{item.title}</h3>
                <p className="text-charcoal-mid/40 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Disclaimer + CTA */}
      <div className="bg-charcoal-deep py-16 md:py-20 px-6 md:px-10 lg:px-16">
        <div className="max-w-3xl mx-auto text-center">
          <div className="w-12 h-12 flex items-center justify-center border border-white/10 mx-auto mb-6">
            <i className="ri-information-line text-white/40 text-xl" />
          </div>
          <h2 className="font-display text-white text-xl uppercase tracking-wider mb-4">
            AI Is Helpful — But Nothing Beats a Real Inspector
          </h2>
          <p className="text-white/40 text-sm md:text-base leading-relaxed mb-8 max-w-xl mx-auto">
            Our AI inspector is a powerful first step, but hidden damage, leaks, and structural issues can only be detected by a licensed professional on your roof. That's why every AI report ends with an offer for a free, no-obligation physical inspection from a Corner Stone expert.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => {
                const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
                if (btn) btn.click();
              }}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
            >
              <i className="ri-calendar-check-line" />
              Book Free Inspection
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}