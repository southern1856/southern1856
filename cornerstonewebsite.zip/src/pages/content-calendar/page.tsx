import { useState } from 'react';
import PageSEO from '@/components/feature/PageSEO';

interface WeekDay {
  day: string;
  short: string;
  suggestedType: string;
  templateIds: string[];
  notes: string;
}

const weekDays: WeekDay[] = [
  { day: 'Monday', short: 'MON', suggestedType: 'Project Spotlight', templateIds: ['project-spotlight-1', 'project-spotlight-2'], notes: 'Post a completed job from the previous week. Include before/after photos and location tag.' },
  { day: 'Tuesday', short: 'TUE', suggestedType: 'Behind the Scenes', templateIds: ['behind-scenes-1', 'behind-scenes-2'], notes: 'Crew huddle, material delivery, or tool prep. Humanizes your brand.' },
  { day: 'Wednesday', short: 'WED', suggestedType: 'Educational Tip', templateIds: ['educational-1', 'educational-2'], notes: 'Value-first content builds trust. No sales pitch — just helpful info.' },
  { day: 'Thursday', short: 'THU', suggestedType: 'Customer Testimonial', templateIds: ['testimonial-1', 'testimonial-2'], notes: 'Screenshot a recent Google review and turn it into a post. Tag the customer if they are on social media.' },
  { day: 'Friday', short: 'FRI', suggestedType: 'Community Involvement', templateIds: ['community-1', 'community-2'], notes: 'End the week with goodwill. Sponsorships, donations, team events.' },
  { day: 'Saturday', short: 'SAT', suggestedType: 'Storm Alert (if applicable)', templateIds: ['storm-alert-1', 'storm-alert-2'], notes: 'Only post if weather event occurred. Otherwise skip or do a light BTS post.' },
  { day: 'Sunday', short: 'SUN', suggestedType: 'Plan & Schedule', templateIds: [], notes: 'Review upcoming jobs. Schedule next week\'s posts. Batch-create content.' },
];

const months = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

const weeklyFocus = [
  { month: 'January', theme: 'Winter Roof Damage', content: 'Ice dams, frozen gutters, attic inspections. Offer free winter roof health checks.' },
  { month: 'February', theme: 'Pre-Spring Prep', content: 'Schedule spring inspections. Early booking discounts. Tax refund season messaging.' },
  { month: 'March', theme: 'Storm Season Begins', content: 'Hail and wind prep. Emergency services highlight. Storm damage response content.' },
  { month: 'April', theme: 'Spring Replacements', content: 'New roof showcases. Financing options. Before/after galleries from spring jobs.' },
  { month: 'May', theme: 'Peak Season Launch', content: 'Limited-time offers. Gutter cleaning bundles. Memorial Day community posts.' },
  { month: 'June', theme: 'Summer Projects', content: 'Metal roofing (heat reflection). Commercial roofing. Independence Day prep sponsorships.' },
  { month: 'July', theme: 'Mid-Year Maintenance', content: 'Gutter and siding maintenance. Half-year checkup offers. Summer storm alerts.' },
  { month: 'August', theme: 'Back to School / Prep', content: 'Exterior package deals. Siding + roof bundles. Before winter inspection reminders.' },
  { month: 'September', theme: 'Fall Rush', content: 'Hurry-before-winter urgency. Leaf guard gutter specials. Football season community tie-ins.' },
  { month: 'October', theme: 'Last Chance Before Winter', content: 'Final call for replacements. Winterization tips. Halloween community event posts.' },
  { month: 'November', theme: 'Holiday Gratitude', content: 'Thanksgiving thank-you posts. Year-in-review content. Black Friday special offers.' },
  { month: 'December', theme: 'Year-End Wrap-Up', content: 'Top 10 projects of the year. Holiday wishes. Schedule January inspections early.' },
];

const keyDates = [
  { date: 'Jan 15', event: 'Tax season begins — refund messaging' },
  { date: 'Mar 20', event: 'Spring equinox — spring inspection push' },
  { date: 'May 1', event: 'Peak season starts — capacity urgency' },
  { date: 'May 27', event: 'Memorial Day — community/sale post' },
  { date: 'Jul 4', event: 'Independence Day — sponsor local events' },
  { date: 'Sep 2', event: 'Labor Day — last summer project push' },
  { date: 'Oct 15', event: 'Final call for pre-winter replacements' },
  { date: 'Nov 28', event: 'Thanksgiving — gratitude content' },
  { date: 'Dec 25', event: 'Holiday break — schedule Jan early' },
];

export default function ContentCalendarPage() {
  const [selectedMonth, setSelectedMonth] = useState(4); // May
  const [printMode, setPrintMode] = useState(false);

  const currentFocus = weeklyFocus[selectedMonth];

  const handlePrint = () => {
    setPrintMode(true);
    setTimeout(() => {
      window.print();
      setPrintMode(false);
    }, 100);
  };

  return (
    <div className="min-h-screen bg-white print:bg-white">
      <PageSEO
        title="Printable Weekly Content Calendar for Roofing Contractors | Corner Stone"
        description="Free printable weekly content calendar for roofing contractors. Plan your Google Business Profile, Facebook, and Instagram posts week by week. Pin it in your office."
        keywords="content calendar roofing, social media calendar contractor, roofing marketing calendar, weekly posting schedule, printable content planner"
        canonical="/content-calendar"
      />

      {/* Print Header - Hidden on screen, shown when printing */}
      <div className="hidden print:block print:p-8">
        <div className="flex items-center justify-between border-b-2 border-gray-300 pb-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 uppercase tracking-wider">Weekly Content Calendar</h1>
            <p className="text-sm text-gray-600 mt-1">Corner Stone Construction & Roofing — Evansville, IN</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600">Phone: 812-213-5997</p>
            <p className="text-sm text-gray-600">cornerstoneconstructionevansville.com</p>
          </div>
        </div>
      </div>

      {/* Screen Controls */}
      <div className={`${printMode ? 'hidden' : 'block'} bg-charcoal-deep`}>
        <div className="px-6 md:px-10 lg:px-16 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <h1 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wider">
                Weekly Content Calendar
              </h1>
              <p className="text-white/40 text-sm mt-2">
                Plan your posts week by week. Print and pin it in your office.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(Number(e.target.value))}
                className="bg-charcoal-mid border border-white/10 text-white text-sm px-4 py-2.5 uppercase tracking-wider cursor-pointer"
              >
                {months.map((m, i) => (
                  <option key={m} value={i} className="bg-charcoal-mid text-white">{m}</option>
                ))}
              </select>
              <button
                onClick={handlePrint}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-5 py-2.5 uppercase tracking-wide text-xs transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <i className="ri-printer-line" />
                Print Calendar
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Monthly Theme Banner */}
      <div className={`${printMode ? 'hidden' : 'block'} bg-orange/10 border-y border-orange/20`}>
        <div className="px-6 md:px-10 lg:px-16 py-5">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <span className="bg-orange text-white text-xs font-semibold px-3 py-1.5 uppercase tracking-wider whitespace-nowrap">
              {currentFocus.month} Focus
            </span>
            <span className="text-white font-semibold text-sm">{currentFocus.theme}</span>
            <span className="text-white/50 text-sm">— {currentFocus.content}</span>
          </div>
        </div>
      </div>

      {/* Main Calendar Grid */}
      <div className="px-4 md:px-8 lg:px-12 py-6 md:py-10 print:px-8 print:py-6">
        {/* Weekly Grid */}
        <div className="mb-8">
          <h2 className="font-display text-gray-900 text-lg md:text-xl uppercase tracking-wider mb-4 print:text-gray-900">
            Weekly Posting Schedule — {currentFocus.month}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-7 gap-3 print:grid-cols-7 print:gap-2">
            {weekDays.map((d) => (
              <div
                key={d.day}
                className="bg-gray-50 border border-gray-200 p-4 print:p-3 print:bg-white print:border-gray-300 flex flex-col min-h-[220px] print:min-h-[180px]"
              >
                <div className="border-b border-gray-200 pb-2 mb-3 print:border-gray-300">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">{d.short}</p>
                  <p className="text-sm font-semibold text-gray-900">{d.day}</p>
                </div>
                <div className="flex-1">
                  <p className="text-xs font-semibold text-orange uppercase tracking-wider mb-2">{d.suggestedType}</p>
                  <p className="text-xs text-gray-600 leading-relaxed mb-3">{d.notes}</p>
                </div>
                <div className="border-t border-gray-100 pt-2 print:border-gray-200">
                  <p className="text-[10px] uppercase tracking-wider text-gray-400 mb-1.5">Write your post here:</p>
                  <div className="h-16 border border-dashed border-gray-300 bg-white print:bg-white" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Template Quick Reference */}
        <div className="mb-8 print:break-inside-avoid">
          <h2 className="font-display text-gray-900 text-lg md:text-xl uppercase tracking-wider mb-4 print:text-gray-900">
            Template Quick Reference
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 print:grid-cols-4 print:gap-2">
            {[
              { type: 'Project Spotlight', count: 2, tip: 'Use real job photos. Tag location.' },
              { type: 'Storm Alert', count: 2, tip: 'Only post when storms hit. Include phone number.' },
              { type: 'Limited Offer', count: 2, tip: 'Set expiration dates. Create urgency.' },
              { type: 'Testimonial', count: 2, tip: 'Screenshot Google reviews. Ask permission.' },
              { type: 'Educational', count: 2, tip: 'No sales pitch. Pure value.' },
              { type: 'Community', count: 2, tip: 'Tag partner organizations. Use event hashtags.' },
              { type: 'Behind Scenes', count: 2, tip: 'Show real crew. Builds trust and helps hiring.' },
              { type: 'Seasonal', count: '∞', tip: 'Adapt monthly focus theme above.' },
            ].map((item) => (
              <div key={item.type} className="bg-gray-50 border border-gray-200 p-3 print:p-2 print:bg-white print:border-gray-300">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-semibold text-gray-900">{item.type}</span>
                  <span className="text-[10px] bg-orange/10 text-orange px-1.5 py-0.5 font-semibold">{item.count} templates</span>
                </div>
                <p className="text-[11px] text-gray-500 leading-snug">{item.tip}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Monthly Goals & Key Dates */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 print:grid-cols-2 print:gap-4">
          {/* Goals Tracker */}
          <div className="border border-gray-200 p-5 print:p-4 print:border-gray-300 print:break-inside-avoid">
            <h3 className="font-display text-gray-900 text-sm uppercase tracking-wider mb-4">Monthly Goals</h3>
            <div className="space-y-3">
              {[
                { label: 'GBP Posts Published', target: '4', actual: '' },
                { label: 'New Photos Uploaded', target: '12', actual: '' },
                { label: 'Review Requests Sent', target: '20', actual: '' },
                { label: 'New Reviews Earned', target: '8', actual: '' },
                { label: 'Q&A Responses', target: 'All', actual: '' },
                { label: 'Facebook/Instagram Posts', target: '8', actual: '' },
              ].map((goal) => (
                <div key={goal.label} className="flex items-center gap-3">
                  <div className="w-5 h-5 border border-gray-300 flex-shrink-0" />
                  <span className="text-sm text-gray-700 flex-1">{goal.label}</span>
                  <span className="text-xs text-gray-400">Target: {goal.target}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Key Dates */}
          <div className="border border-gray-200 p-5 print:p-4 print:border-gray-300 print:break-inside-avoid">
            <h3 className="font-display text-gray-900 text-sm uppercase tracking-wider mb-4">Key Dates This Year</h3>
            <div className="space-y-2.5">
              {keyDates.map((kd) => (
                <div key={kd.date} className="flex items-start gap-3">
                  <span className="text-xs font-bold text-orange whitespace-nowrap">{kd.date}</span>
                  <span className="text-xs text-gray-600 leading-relaxed">{kd.event}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Yearly Overview */}
        <div className="border border-gray-200 p-5 print:p-4 print:border-gray-300 print:break-inside-avoid">
          <h3 className="font-display text-gray-900 text-sm uppercase tracking-wider mb-4">Yearly Content Themes at a Glance</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 print:grid-cols-6 print:gap-1.5">
            {weeklyFocus.map((wf, i) => (
              <div
                key={wf.month}
                className={`p-2.5 print:p-2 border ${
                  i === selectedMonth
                    ? 'border-orange bg-orange/5'
                    : 'border-gray-200 bg-gray-50 print:bg-white print:border-gray-300'
                }`}
              >
                <p className={`text-[10px] font-bold uppercase tracking-wider mb-1 ${i === selectedMonth ? 'text-orange' : 'text-gray-400'}`}>
                  {wf.month}
                </p>
                <p className="text-xs font-semibold text-gray-900 leading-tight">{wf.theme}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Print Footer */}
        <div className="hidden print:block mt-8 pt-4 border-t border-gray-300">
          <div className="flex items-center justify-between text-xs text-gray-500">
            <p>Generated from cornerstoneconstructionevansville.com/content-calendar</p>
            <p>For more templates and the full GBP playbook, visit our website.</p>
          </div>
        </div>
      </div>

      {/* Screen Footer CTA */}
      <div className={`${printMode ? 'hidden' : 'block'} bg-charcoal-deep border-t border-white/5`}>
        <div className="px-6 md:px-10 lg:px-16 py-12">
          <div className="bg-orange/10 border border-orange/20 p-8 max-w-3xl">
            <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">
              Need the Ready-to-Post Templates?
            </h3>
            <p className="text-white/40 text-sm leading-relaxed mb-6">
              This calendar tells you WHAT and WHEN to post. Our Social Templates page gives you the exact copy to paste. Use them together for a complete system.
            </p>
            <div className="flex flex-wrap gap-3">
              <a
                href="/social-media-templates"
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-6 py-2.5 uppercase tracking-wide text-xs transition-colors whitespace-nowrap"
              >
                Get 14 Copy-and-Paste Templates
              </a>
              <a
                href="/google-business-profile-optimization"
                className="border border-white/20 hover:border-orange text-white/40 hover:text-orange text-xs uppercase tracking-widest py-2.5 px-6 transition-all duration-200"
              >
                GBP Optimization Guide
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}