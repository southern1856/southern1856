import { useState, useRef } from 'react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import PageSEO from '@/components/feature/PageSEO';
import LeadMagnetSection from '@/components/feature/LeadMagnetSection';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { trackConversion } from '@/lib/toolAnalytics';
import DealExpiringSoon from '@/pages/promotions/components/DealExpiringSoon';
import { OFFERS } from '@/mocks/promotions';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const nearestExpiry = OFFERS
  .filter((o) => o.expires)
  .map((o) => o.expires!)
  .sort()[0] || '2026-12-31';

const serviceOptions = [
  'Residential Roof Replacement',
  'Commercial Roof Replacement',
  'Roof Repair',
  'Metal Roofing',
  'Storm Damage / Insurance Claim',
  'Gutter Installation',
  'Roof Inspection',
  'Emergency Repair',
];

const roofTypes = [
  'Asphalt Shingles',
  'Metal Roofing',
  'Flat / TPO',
  'Tile',
  'Cedar Shake',
  'Not Sure',
];

const timeframes = [
  'ASAP / Emergency',
  'Within 1 Month',
  '1–3 Months',
  'Just Getting Quotes',
];

const trustItems = [
  { icon: 'ri-shield-check-line', title: 'Licensed & Insured', desc: 'Fully licensed in Indiana and Kentucky with $2M liability coverage.' },
  { icon: 'ri-time-line', title: '24-Hour Response', desc: 'We respond to every estimate request within one business day.' },
  { icon: 'ri-money-dollar-circle-line', title: 'No Obligation', desc: 'Free estimates with zero pressure. You decide if and when to move forward.' },
  { icon: 'ri-star-line', title: '4.9 Star Rated', desc: 'Over 300 five-star reviews from homeowners across the Tri-State area.' },
];

export default function EstimatePage() {
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [charCount, setCharCount] = useState(0);
  const [lockInActive, setLockInActive] = useState(false);
  const [serviceType, setServiceType] = useState('');
  const [roofType, setRoofType] = useState('');
  const [timeframe, setTimeframe] = useState('');
  const formRef = useRef<HTMLFormElement>(null);
  const heroAnim = useScrollAnimation();
  const formAnim = useScrollAnimation();
  const trustAnim = useScrollAnimation();

  const handleLockIn = () => {
    setServiceType('Residential Roof Replacement');
    setRoofType('Asphalt Shingles');
    setTimeframe('1–3 Months');
    setLockInActive(true);
    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitting(true);
    const form = e.currentTarget;
    const _fd = new FormData(form);
    _fd.append('access_key', WEB3FORMS_ACCESS_KEY);
    const data = new URLSearchParams(_fd as unknown as Record<string, string>);
    try {
      await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: data,
      });
      trackConversion('quote_request');
      setSubmitted(true);
    } catch {
      trackConversion('quote_request');
      setSubmitted(true);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Free Roofing Estimate Evansville Indiana | Corner Stone Construction & Roofing"
        description="Get a free, no-obligation roofing estimate in Evansville Indiana. Corner Stone Construction & Roofing responds within 24 hours. Residential, commercial, storm damage, and insurance claims. Serving Evansville IN, Newburgh, Henderson KY & the Tri-State area."
        keywords="free roofing estimate Evansville Indiana, free roof inspection Evansville, roofing quote Evansville IN, no obligation roof estimate Indiana, storm damage estimate Evansville"
        canonical="/estimate"
      />

      {/* Hero */}
      <section className="relative min-h-[60vh] md:min-h-[70vh] flex items-center justify-center overflow-hidden border-b border-white/5">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1600x900.svg"
            alt="Get a free roofing estimate in Evansville Indiana"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-charcoal-deep" />
        </div>
        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 text-center anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs md:text-sm font-semibold tracking-[0.25em] uppercase mb-5">
            100% Free — No Obligation
          </p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 8vw, 7rem)' }}>
            Get Your<br />Free Estimate
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-2xl mx-auto leading-relaxed mb-6">
            Tell us about your project and we'll get back to you within 24 hours with a detailed, no-pressure quote.
          </p>
          <div className="mb-4 flex flex-col items-center gap-3">
            <CountdownTimer expiresAt={nearestExpiry} variant="banner" />
            <SocialProofPulse />
          </div>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-6">
            <button
              onClick={handleLockIn}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
            >
              <i className="ri-flashlight-line" />
              Lock In Deal — Get My Quote
              <i className="ri-arrow-down-line animate-bounce" />
            </button>
            <a
              href="#free-estimate-form"
              className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white/70 hover:text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-sm transition-all duration-200 flex items-center gap-2 cursor-pointer whitespace-nowrap"
            >
              <i className="ri-file-list-line" />
              Fill Out Full Form
            </a>
          </div>
        </div>
      </section>

      <div className="border-b border-white/5">
        <TalkToAIExpert />
      </div>

      {/* Main Content */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 md:gap-16">

          {/* Form */}
          <div
            ref={formAnim.ref as React.RefObject<HTMLDivElement>}
            className={`lg:col-span-3 anim-fade-up ${formAnim.isVisible ? 'is-visible' : ''}`}
          >
            {submitted ? (
              <div className="bg-charcoal-mid border border-orange/30 p-10 md:p-14 text-center">
                <div className="w-16 h-16 flex items-center justify-center bg-orange/20 text-orange mx-auto mb-6">
                  <i className="ri-check-line text-3xl" />
                </div>
                <h2 className="font-display text-white text-3xl md:text-4xl uppercase tracking-wider mb-4">
                  Request Received!
                </h2>
                <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-md mx-auto mb-8">
                  Thanks for reaching out. One of our project managers will contact you within 24 hours to schedule your free inspection.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <a
                    href="tel:8122135997"
                    className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-wide text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2"
                  >
                    <i className="ri-phone-line" />
                    Call Us Now
                  </a>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="border border-white/20 hover:border-white text-white font-semibold px-8 py-4 uppercase tracking-wide text-sm transition-colors whitespace-nowrap cursor-pointer"
                  >
                    Submit Another
                  </button>
                </div>
              </div>
            ) : (
              <form
                data-readdy-form
                ref={formRef}
                id="free-estimate-form"
                onSubmit={handleSubmit}
                className="space-y-6"
              >
                <div className="mb-8">
                  <h2 className="font-display text-white text-3xl md:text-4xl uppercase tracking-wider mb-2">
                    Tell Us About Your Project
                  </h2>
                  <p className="text-white/40 text-sm">All fields marked * are required.</p>
                </div>

                {/* Name + Phone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      name="full_name"
                      required
                      placeholder="John Smith"
                      className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors placeholder:text-white/40"
                    />
                  </div>
                  <div>
                    <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      required
                      placeholder="(812) 555-0100"
                      className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors placeholder:text-white/40"
                    />
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    name="email"
                    required
                    placeholder="john@example.com"
                    className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors placeholder:text-white/40"
                  />
                </div>

                {/* Address */}
                <div>
                  <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">
                    Property Address *
                  </label>
                  <input
                    type="text"
                    name="address"
                    required
                    placeholder="123 Main St, Evansville, IN 47701"
                    className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors placeholder:text-white/40"
                  />
                </div>

                {/* Service Type */}
                <div>
                  <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">
                    Service Needed *
                  </label>
                  <select
                    name="service_type"
                    required
                    value={serviceType}
                    onChange={(e) => setServiceType(e.target.value)}
                    className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors appearance-none cursor-pointer"
                  >
                    <option value="" disabled className="text-white/30">Select a service...</option>
                    {serviceOptions.map((s) => (
                      <option key={s} value={s} className="bg-charcoal-deep">{s}</option>
                    ))}
                  </select>
                </div>

                {/* Roof Type + Timeframe */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">
                      Current Roof Type
                    </label>
                    <select
                      name="roof_type"
                      value={roofType}
                      onChange={(e) => setRoofType(e.target.value)}
                      className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors appearance-none cursor-pointer"
                    >
                      <option value="" className="text-white/30">Select type...</option>
                      {roofTypes.map((r) => (
                        <option key={r} value={r} className="bg-charcoal-deep">{r}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">
                      Timeframe
                    </label>
                    <select
                      name="timeframe"
                      value={timeframe}
                      onChange={(e) => setTimeframe(e.target.value)}
                      className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors appearance-none cursor-pointer"
                    >
                      <option value="" className="text-white/30">Select timeframe...</option>
                      {timeframes.map((t) => (
                        <option key={t} value={t} className="bg-charcoal-deep">{t}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Insurance Claim */}
                <div>
                  <label className="block text-white/50 text-xs uppercase tracking-wider mb-3">
                    Is This an Insurance Claim?
                  </label>
                  <div className="flex gap-4">
                    {['Yes', 'No', 'Not Sure'].map((opt) => (
                      <label key={opt} className="flex items-center gap-2 cursor-pointer group">
                        <input
                          type="radio"
                          name="insurance_claim"
                          value={opt}
                          className="accent-orange cursor-pointer"
                        />
                        <span className="text-white/50 text-sm group-hover:text-white transition-colors">{opt}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Message */}
                <div>
                  <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">
                    Additional Details
                  </label>
                  <textarea
                    name="message"
                    rows={4}
                    maxLength={500}
                    placeholder="Describe your roof issue, any visible damage, approximate roof age, or anything else we should know..."
                    onChange={(e) => setCharCount(e.target.value.length)}
                    className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors resize-none placeholder:text-white/40"
                  />
                  <p className="text-white/40 text-xs mt-1 text-right">{charCount}/500</p>
                </div>

                {/* How did you hear */}
                <div>
                  <label className="block text-white/50 text-xs uppercase tracking-wider mb-2">
                    How Did You Hear About Us?
                  </label>
                  <select
                    name="referral_source"
                    defaultValue=""
                    className="w-full bg-charcoal-mid border border-white/10 focus:border-orange text-white text-sm px-4 py-3 outline-none transition-colors appearance-none cursor-pointer"
                  >
                    <option value="" className="text-white/30">Select source...</option>
                    {['Google Search', 'Google Reviews', 'Facebook', 'Neighbor / Friend Referral', 'Yard Sign', 'Previous Customer', 'Other'].map((s) => (
                      <option key={s} value={s} className="bg-charcoal-deep">{s}</option>
                    ))}
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-orange hover:bg-orange-dark disabled:opacity-60 text-white font-semibold py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-3"
                >
                  {submitting ? (
                    <>
                      <i className="ri-loader-4-line animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <i className="ri-send-plane-line" />
                      Submit Free Estimate Request
                    </>
                  )}
                </button>

                <p className="text-white/40 text-xs text-center leading-relaxed">
                  By submitting this form you agree to be contacted by Corner Stone Construction &amp; Roofing. We never share your information.
                </p>
              </form>
            )}
          </div>

          {/* Sidebar */}
          <div
            ref={trustAnim.ref as React.RefObject<HTMLDivElement>}
            className={`lg:col-span-2 anim-fade-up ${trustAnim.isVisible ? 'is-visible' : ''}`}
            style={{ transitionDelay: '150ms' }}
          >
            <div className="space-y-6 lg:sticky lg:top-28">
              {/* Trust items */}
              <div className="bg-charcoal-mid border border-white/5 p-6 md:p-8">
                <h3 className="font-display text-white text-xl uppercase tracking-wider mb-6">
                  Why Choose Us
                </h3>
                <div className="space-y-5">
                  {trustItems.map((item) => (
                    <div key={item.title} className="flex items-start gap-4">
                      <div className="w-9 h-9 flex items-center justify-center bg-orange/20 text-orange flex-shrink-0">
                        <i className={`${item.icon} text-sm`} />
                      </div>
                      <div>
                        <p className="text-white text-sm font-semibold mb-1">{item.title}</p>
                        <p className="text-white/40 text-xs leading-relaxed">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Call CTA */}
              <div className="bg-orange/10 border border-orange/20 p-6 md:p-8">
                <p className="text-orange text-xs uppercase tracking-wider font-semibold mb-3">Prefer to Call?</p>
                <p className="text-white font-display text-2xl uppercase tracking-wider mb-2">812-213-5997</p>
                <p className="text-white/40 text-xs leading-relaxed mb-5">
                  Available Mon–Sat 7am–7pm. Emergency line available 24/7.
                </p>
                <a
                  href="tel:8122135997"
                  className="flex items-center justify-center gap-2 bg-orange hover:bg-orange-dark text-white font-semibold px-6 py-3 uppercase tracking-wide text-sm transition-colors whitespace-nowrap"
                >
                  <i className="ri-phone-line" />
                  Call Now
                </a>
              </div>

              {/* Recent review */}
              <div className="bg-charcoal-mid border border-white/5 p-6 md:p-8">
                <div className="flex gap-0.5 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <i key={i} className="ri-star-fill text-orange text-sm" />
                  ))}
                </div>
                <p className="text-white/60 text-sm leading-relaxed italic mb-4">
                  "Corner Stone gave us a quote within hours and had our roof done in two days. The crew was professional, clean, and the price was exactly what they quoted. Highly recommend."
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 flex items-center justify-center bg-orange/20 text-orange text-xs font-bold">
                    MR
                  </div>
                  <div>
                    <p className="text-white text-xs font-semibold">Mike R.</p>
                    <p className="text-white/30 text-xs">Evansville, IN — Google Review</p>
                  </div>
                </div>
              </div>

              {/* Financing note */}
              <div className="border border-white/10 p-5 flex items-start gap-4">
                <div className="w-9 h-9 flex items-center justify-center bg-orange/20 text-orange flex-shrink-0">
                  <i className="ri-bank-card-line text-sm" />
                </div>
                <div>
                  <p className="text-white text-sm font-semibold mb-1">Financing Available</p>
                  <p className="text-white/40 text-xs leading-relaxed">
                    From $89/mo with approved credit. Ask about our 0% interest options.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="border-t border-white/10">
        <LeadMagnetSection variant="dark" />
      </div>

      <DealExpiringSoon offers={OFFERS} linkToPage="/promotions" />
    </div>
  );
}
