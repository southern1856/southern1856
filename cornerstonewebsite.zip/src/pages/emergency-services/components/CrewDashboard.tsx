import { useState } from 'react';
import { CREW_MEMBERS } from '@/mocks/crewAvailability';

const STATUS_STYLES = {
  dispatched: { bg: 'bg-green-500/10 border-green-500/30 text-green-400', dot: 'bg-green-400' },
  'on-call': { bg: 'bg-orange/10 border-orange/30 text-orange', dot: 'bg-orange' },
  'off-duty': { bg: 'bg-white/5 border-white/10 text-white/30', dot: 'bg-white/20' },
};

export default function CrewDashboard() {
  const [selectedCrew, setSelectedCrew] = useState<string | null>(null);
  const available = CREW_MEMBERS.filter((c) => c.status === 'dispatched' || c.status === 'on-call');
  const dispatched = CREW_MEMBERS.filter((c) => c.status === 'dispatched');
  const onCall = CREW_MEMBERS.filter((c) => c.status === 'on-call');

  return (
    <div className="space-y-6">
      {/* Live stats row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Crews Available', value: available.length.toString(), icon: 'ri-team-line', color: 'text-green-400' },
          { label: 'Currently Dispatched', value: dispatched.length.toString(), icon: 'ri-truck-line', color: 'text-orange' },
          { label: 'On Standby', value: onCall.length.toString(), icon: 'ri-time-line', color: 'text-white/60' },
          { label: 'Avg Response', value: '18 min', icon: 'ri-timer-line', color: 'text-orange' },
        ].map((s) => (
          <div key={s.label} className="border border-white/10 bg-charcoal-deep p-4 flex items-center gap-3">
            <div className="w-10 h-10 flex items-center justify-center bg-white/5 flex-shrink-0">
              <i className={`${s.icon} ${s.color} text-lg`} />
            </div>
            <div>
              <p className="font-display text-white text-xl tracking-wider">{s.value}</p>
              <p className="text-white/40 text-[10px] uppercase tracking-widest">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Crew cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {CREW_MEMBERS.map((crew) => {
          const style = STATUS_STYLES[crew.status];
          const isSelected = selectedCrew === crew.id;
          return (
            <button
              key={crew.id}
              onClick={() => setSelectedCrew(isSelected ? null : crew.id)}
              className={`text-left border transition-all duration-200 cursor-pointer ${
                isSelected ? 'border-orange/40 bg-orange/5' : style.bg
              }`}
            >
              <div className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <span className={`w-2.5 h-2.5 rounded-full ${style.dot} ${crew.status !== 'off-duty' ? 'animate-pulse' : ''}`} />
                    <span className="font-display text-white text-sm uppercase tracking-wider">{crew.name}</span>
                  </div>
                  <span className={`text-[10px] font-semibold uppercase tracking-widest px-2 py-0.5 border ${style.bg}`}>
                    {crew.status === 'dispatched' ? 'On Route' : crew.status === 'on-call' ? 'Standby' : 'Off Duty'}
                  </span>
                </div>
                <p className="text-white/50 text-xs mb-1">
                  Lead: <span className="text-white/70">{crew.lead}</span>
                </p>
                <p className="text-white/50 text-xs mb-1">
                  Location: <span className="text-white/70">{crew.location}</span>
                </p>
                <p className="text-white/50 text-xs mb-2.5">
                  Current: <span className="text-white/70">{crew.currentJob}</span>
                </p>
                <div className="flex items-center gap-4 text-[10px] text-white/30 uppercase tracking-wider">
                  <span><i className="ri-group-line mr-1" />{crew.members} workers</span>
                  <span><i className="ri-truck-line mr-1" />{crew.vehicles} vehicles</span>
                  <span><i className="ri-timer-line mr-1" />{crew.eta}</span>
                </div>
                {/* Expanded detail */}
                <div
                  className={`overflow-hidden transition-all duration-300 ${isSelected ? 'max-h-32 opacity-100 mt-3 pt-3 border-t border-white/10' : 'max-h-0 opacity-0'}`}
                >
                  <p className="text-white/40 text-xs mb-2">Specialty: <span className="text-white/60">{crew.specialty}</span></p>
                  <p className="text-white/40 text-xs mb-2">Dispatch: <span className="text-white/60">{crew.phone}</span></p>
                  <p className="text-orange/60 text-[10px] uppercase tracking-wider">{crew.badge}</p>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}