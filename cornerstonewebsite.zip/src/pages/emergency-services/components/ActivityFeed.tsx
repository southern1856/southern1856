import { useState } from 'react';
import { LAST_24_HOURS_ACTIVITY } from '@/mocks/crewAvailability';

const TYPE_CONFIG: Record<string, { icon: string; color: string; bg: string; border: string }> = {
  dispatch: { icon: 'ri-truck-line', color: 'text-orange', bg: 'bg-orange/5', border: 'border-orange/20' },
  arrival: { icon: 'ri-map-pin-user-line', color: 'text-green-400', bg: 'bg-green-500/5', border: 'border-green-500/20' },
  complete: { icon: 'ri-checkbox-circle-line', color: 'text-white/50', bg: 'bg-white/5', border: 'border-white/10' },
  weather: { icon: 'ri-thunderstorms-line', color: 'text-amber-400', bg: 'bg-amber-400/5', border: 'border-amber-400/20' },
  shift: { icon: 'ri-time-line', color: 'text-blue-400', bg: 'bg-blue-400/5', border: 'border-blue-400/20' },
};

export default function ActivityFeed() {
  const [filter, setFilter] = useState<'all' | 'dispatch' | 'arrival' | 'complete' | 'weather' | 'shift'>('all');
  const [expanded, setExpanded] = useState(false);

  const filtered = LAST_24_HOURS_ACTIVITY.filter((a) =>
    filter === 'all' ? true : a.type === filter
  );

  const displayed = expanded ? filtered : filtered.slice(0, 8);
  const hasMore = filtered.length > 8;

  const stats = {
    total: LAST_24_HOURS_ACTIVITY.length,
    dispatches: LAST_24_HOURS_ACTIVITY.filter((a) => a.type === 'dispatch').length,
    completions: LAST_24_HOURS_ACTIVITY.filter((a) => a.type === 'complete').length,
    avgResponse: '18 min',
  };

  return (
    <div className="space-y-5">
      {/* Stats bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        {[
          { label: 'Total Events', value: stats.total.toString(), icon: 'ri-bar-chart-line' },
          { label: 'Dispatches', value: stats.dispatches.toString(), icon: 'ri-truck-line' },
          { label: 'Completed', value: stats.completions.toString(), icon: 'ri-checkbox-circle-line' },
          { label: 'Avg Response', value: stats.avgResponse, icon: 'ri-timer-line' },
        ].map((s) => (
          <div key={s.label} className="border border-white/10 bg-charcoal-deep p-3 flex items-center gap-2.5">
            <div className="w-8 h-8 flex items-center justify-center bg-white/5 flex-shrink-0">
              <i className={`${s.icon} text-orange text-sm`} />
            </div>
            <div>
              <p className="font-display text-white text-lg tracking-wider">{s.value}</p>
              <p className="text-white/30 text-[9px] uppercase tracking-widest">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filter tabs */}
      <div className="flex flex-wrap items-center gap-2">
        {([
          { key: 'all', label: 'All Activity' },
          { key: 'dispatch', label: 'Dispatches' },
          { key: 'arrival', label: 'Arrivals' },
          { key: 'complete', label: 'Completed' },
          { key: 'weather', label: 'Weather' },
          { key: 'shift', label: 'Shift Changes' },
        ] as const).map((tab) => (
          <button
            key={tab.key}
            onClick={() => { setFilter(tab.key); setExpanded(false); }}
            className={`px-3 py-1.5 text-xs uppercase tracking-widest font-semibold border transition-all duration-200 cursor-pointer whitespace-nowrap ${
              filter === tab.key
                ? 'bg-orange text-white border-orange'
                : 'bg-transparent text-white/40 border-white/10 hover:border-white/30 hover:text-white/60'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Timeline */}
      <div className="border border-white/10">
        {displayed.map((entry, i) => {
          const config = TYPE_CONFIG[entry.type] || TYPE_CONFIG.complete;
          const isLast = i === displayed.length - 1;
          return (
            <div
              key={i}
              className={`flex items-start gap-4 px-4 py-3.5 hover:bg-white/[0.02] transition-colors ${!isLast ? 'border-b border-white/5' : ''}`}
            >
              {/* Time column */}
              <div className="w-16 flex-shrink-0 pt-0.5">
                <span className="text-white/25 text-xs font-mono">{entry.time}</span>
              </div>

              {/* Icon + line */}
              <div className="flex flex-col items-center flex-shrink-0">
                <div className={`w-7 h-7 flex items-center justify-center border ${config.bg} ${config.border}`}>
                  <i className={`${config.icon} ${config.color} text-xs`} />
                </div>
                {!isLast && (
                  <div className="w-px flex-1 bg-white/5 mt-1" style={{ minHeight: '20px' }} />
                )}
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0 pb-2">
                <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                  <span className={`text-xs font-semibold uppercase tracking-wider ${config.color}`}>
                    {entry.title}
                  </span>
                  <span className="text-white/15 text-[10px]">·</span>
                  <span className="text-white/30 text-[10px] uppercase tracking-wider">
                    {entry.zone}
                  </span>
                </div>
                <p className="text-white/50 text-xs leading-relaxed">{entry.detail}</p>
                {entry.crew !== '—' && (
                  <p className="text-white/20 text-[10px] mt-1 uppercase tracking-wider">
                    Crew: <span className="text-white/40">{entry.crew}</span>
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Show more */}
      {hasMore && !expanded && (
        <button
          onClick={() => setExpanded(true)}
          className="w-full py-3 border border-white/10 bg-charcoal-deep hover:border-orange/30 text-white/40 hover:text-orange text-xs uppercase tracking-widest transition-all duration-200 cursor-pointer"
        >
          Show {filtered.length - 8} More Events <i className="ri-arrow-down-line ml-1" />
        </button>
      )}
      {expanded && hasMore && (
        <button
          onClick={() => setExpanded(false)}
          className="w-full py-3 border border-white/10 bg-charcoal-deep hover:border-orange/30 text-white/40 hover:text-orange text-xs uppercase tracking-widest transition-all duration-200 cursor-pointer"
        >
          Show Less <i className="ri-arrow-up-line ml-1" />
        </button>
      )}
    </div>
  );
}