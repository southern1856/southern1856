import { useState } from 'react';
import { EMERGENCY_DISPATCH_LOG } from '@/mocks/crewAvailability';

const STATUS_COLORS: Record<string, string> = {
  Dispatched: 'text-orange border-orange/30 bg-orange/5',
  'On Scene': 'text-green-400 border-green-500/30 bg-green-500/5',
  Complete: 'text-white/40 border-white/10 bg-white/5',
};

export default function DispatchLog() {
  const [filter, setFilter] = useState<'all' | 'active' | 'complete'>('all');
  const filtered = EMERGENCY_DISPATCH_LOG.filter((d) => {
    if (filter === 'active') return d.status === 'Dispatched' || d.status === 'On Scene';
    if (filter === 'complete') return d.status === 'Complete';
    return true;
  });

  return (
    <div className="space-y-4">
      {/* Filter tabs */}
      <div className="flex items-center gap-2">
        {([
          { key: 'all', label: 'All Calls' },
          { key: 'active', label: 'Active' },
          { key: 'complete', label: 'Complete' },
        ] as const).map((tab) => (
          <button
            key={tab.key}
            onClick={() => setFilter(tab.key)}
            className={`px-3 py-1.5 text-xs uppercase tracking-widest font-semibold border transition-all duration-200 cursor-pointer whitespace-nowrap ${
              filter === tab.key
                ? 'bg-orange text-white border-orange'
                : 'bg-transparent text-white/40 border-white/10 hover:border-white/30 hover:text-white/60'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Log entries */}
      <div className="border border-white/10 divide-y divide-white/5">
        {filtered.map((entry, i) => (
          <div key={i} className="flex items-center gap-4 px-4 py-3.5 hover:bg-white/[0.02] transition-colors">
            <span className="text-white/20 text-xs font-mono w-16 flex-shrink-0">{entry.time}</span>
            <span className="text-white/60 text-xs flex-1 min-w-0">{entry.location}</span>
            <span className="text-white/80 text-xs font-medium flex-shrink-0 hidden sm:block w-28">{entry.type}</span>
            <span className="text-white/40 text-xs hidden md:block w-24">{entry.crew}</span>
            <span className={`text-[10px] font-semibold uppercase tracking-widest px-2 py-0.5 border flex-shrink-0 ${STATUS_COLORS[entry.status] || 'text-white/40 border-white/10'}`}>
              {entry.status}
            </span>
            {entry.eta !== '—' && (
              <span className="text-orange/60 text-[10px] uppercase tracking-wider flex-shrink-0 hidden lg:block">
                ETA {entry.eta}
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}