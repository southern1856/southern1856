import { useState } from 'react';
import { DISPATCH_ZONES } from '@/mocks/crewAvailability';

export default function DispatchZones() {
  const [activeZone, setActiveZone] = useState<string | null>(null);

  return (
    <div className="space-y-5">
      {/* Zone list */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
        {DISPATCH_ZONES.map((zone) => {
          const isActive = activeZone === zone.id;
          return (
            <button
              key={zone.id}
              onClick={() => setActiveZone(isActive ? null : zone.id)}
              className={`text-left border transition-all duration-200 cursor-pointer ${
                isActive
                  ? 'border-orange/40 bg-orange/5'
                  : 'border-white/10 bg-charcoal-deep hover:border-white/20'
              }`}
            >
              <div className="p-3.5">
                <div className="flex items-center gap-2 mb-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                    style={{ backgroundColor: zone.color }}
                  />
                  <span className="font-display text-white text-xs uppercase tracking-wider">
                    {zone.name}
                  </span>
                </div>
                <p className="text-white/30 text-[10px] uppercase tracking-wider mb-1.5">
                  {zone.coverage}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-orange/60 text-[10px] uppercase tracking-widest">
                    {zone.responseTime}
                  </span>
                  <span className="text-white/20 text-[10px]">
                    {zone.crews} crew{zone.crews > 1 ? 's' : ''}
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Simulated Map Area */}
      <div className="relative w-full h-[340px] md:h-[420px] bg-charcoal-deep border border-white/10 overflow-hidden">
        {/* Abstract zone overlays */}
        <div className="absolute inset-0">
          {/* Evansville Core — center-ish */}
          <div className="absolute left-[42%] top-[35%] w-[22%] h-[24%] border-2 border-orange/30 bg-orange/[0.04] rounded-lg" />
          {/* Newburgh — southeast */}
          <div className="absolute left-[55%] top-[55%] w-[20%] h-[22%] border-2 border-[#D4551E]/25 bg-[#D4551E]/[0.03] rounded-lg" />
          {/* Henderson — southwest */}
          <div className="absolute left-[25%] top-[50%] w-[18%] h-[20%] border-2 border-[#C94E1A]/25 bg-[#C94E1A]/[0.03] rounded-lg" />
          {/* Owensboro — far southwest */}
          <div className="absolute left-[15%] top-[65%] w-[16%] h-[18%] border-2 border-[#A84418]/25 bg-[#A84418]/[0.03] rounded-lg" />
          {/* Mount Vernon — northeast-ish */}
          <div className="absolute left-[65%] top-[30%] w-[15%] h-[17%] border-2 border-[#943D16]/25 bg-[#943D16]/[0.03] rounded-lg" />
        </div>

        {/* Zone labels */}
        <div className="absolute left-[45%] top-[42%] text-orange/70 text-[10px] uppercase tracking-widest font-bold whitespace-nowrap pointer-events-none">
          Evansville Core
        </div>
        <div className="absolute left-[58%] top-[62%] text-[#D4551E]/60 text-[10px] uppercase tracking-widest font-bold whitespace-nowrap pointer-events-none">
          Newburgh
        </div>
        <div className="absolute left-[28%] top-[57%] text-[#C94E1A]/60 text-[10px] uppercase tracking-widest font-bold whitespace-nowrap pointer-events-none">
          Henderson
        </div>
        <div className="absolute left-[17%] top-[71%] text-[#A84418]/60 text-[10px] uppercase tracking-widest font-bold whitespace-nowrap pointer-events-none">
          Owensboro
        </div>
        <div className="absolute left-[67%] top-[35%] text-[#943D16]/60 text-[10px] uppercase tracking-widest font-bold whitespace-nowrap pointer-events-none">
          Mt Vernon
        </div>

        {/* Crew dots */}
        {[
          { top: '38%', left: '46%', label: 'Alpha', color: 'bg-green-400' },
          { top: '58%', left: '62%', label: 'Bravo', color: 'bg-orange' },
          { top: '53%', left: '33%', label: 'Charlie', color: 'bg-orange' },
          { top: '33%', left: '72%', label: 'Echo', color: 'bg-orange' },
          { top: '68%', left: '23%', label: 'Night', color: 'bg-orange' },
        ].map((dot) => (
          <div
            key={dot.label}
            className="absolute group cursor-pointer"
            style={{ top: dot.top, left: dot.left }}
          >
            <span className={`relative w-3 h-3 rounded-full ${dot.color} block animate-pulse`}>
              <span className={`absolute inset-0 rounded-full ${dot.color} opacity-40 animate-ping`} />
            </span>
            <span className="absolute -top-5 left-1/2 -translate-x-1/2 text-white/50 text-[9px] uppercase tracking-wider opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap bg-charcoal-deep px-1.5 py-0.5 border border-white/10">
              {dot.label}
            </span>
          </div>
        ))}

        {/* Map footer */}
        <div className="absolute bottom-0 left-0 right-0 bg-charcoal-deep/80 border-t border-white/5 px-4 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 text-white/30 text-[10px] uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-green-400" />Dispatched
            </span>
            <span className="flex items-center gap-1.5 text-white/30 text-[10px] uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-orange" />Standby
            </span>
            <span className="flex items-center gap-1.5 text-white/30 text-[10px] uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-white/20" />Off Duty
            </span>
          </div>
          <span className="text-white/20 text-[10px] uppercase tracking-wider hidden sm:block">
            Tri-State Dispatch Network
          </span>
        </div>
      </div>
    </div>
  );
}