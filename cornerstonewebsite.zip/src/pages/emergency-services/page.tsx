import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { OFFERS } from '@/mocks/promotions';
import CrewDashboard from './components/CrewDashboard';
import DispatchZones from './components/DispatchZones';
import DispatchLog from './components/DispatchLog';
import ActivityFeed from './components/ActivityFeed';
import { EMERGENCY_TYPES, RESPONSE_GUARANTEES } from '@/mocks/crewAvailability';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const emergencySchema = {
  '@context': 'https://schema.org',
  '@type': 'Service',
  name: '24/7 Emergency Roof Repair & Tarping',
  provider: {
    '@type': 'RoofingContractor',
    name: 'Corner Stone Construction & Roofing',
    telephone: '+1-812-213-5997',
    address: { '@type': 'PostalAddress', addressLocality: 'Evansville', addressRegion: 'IN' },
  },
  areaServed: ['Evansville IN', 'Newburgh IN', 'Henderson KY', 'Owensboro KY', 'Mount Vernon IN', 'Tri-State Area'],
  description: '24/7 emergency roofing services in Evansville Indiana. Active leaks, tree on roof, missing shingles, fire damage. Crew dispatched within 60 minutes. Full dispatch dashboard with live crew tracking.',
  offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD', description: 'Free emergency dispatch assessment' },
};

const DISPATCH_STEPS = [
  { num: '01', title: 'Call or Submit', desc: 'Call 812-213-5997 or fill the emergency form below. Live dispatchers answer 24/7.' },
  { num: '02', title: 'Dispatch Team', desc: 'Nearest available crew is routed to your location with GPS tracking and ETA updates.' },
  { num: '03', title: 'Arrive & Secure', desc: 'Crew arrives with tarp, plywood, tools. Water intrusion is stopped immediately.' },
  { num: '04', title: 'Document & Plan', desc: 'Photos, drone scans, and inspection report compiled for insurance within 24 hours.' },
  { num: '05', title: 'Permanent Repair', desc: 'Full repair or replacement scheduled. Most jobs completed in 1–2 days.' },
];

const nearestExpiry = OFFERS
  .filter((o) => o.expires)
  .map((o) => o.expires!)
  .sort()[0] || '2026-12-31';

export default function EmergencyServicesPage() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [charCount, setCharCount] = useState(0);
  const [formType, setFormType] = useState('unknown');
  const formRef = useRef<HTMLFormElement>(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(interval);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;
    const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
    const notes = formData.get('notes') as string;
    if (notes && notes.length > 500) return;
    setStatus('submitting');
    try {
      const res = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      if (res.ok) {
        setStatus('success');
        formRef.current.reset();
        setCharCount(0);
        setFormType('unknown');
      } else setStatus('error');
    } catch { setStatus('error'); }
  };

  const formatTime = (date: Date) =>
    date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="24/7 Emergency Roof Repair Evansville IN | Live Dispatch & Crew Tracking"
        description="24/7 emergency roofing services in Evansville Indiana. Active leaks, tree on roof, missing shingles, fire damage. Live crew dashboard, dispatch map, and real-time availability. Call 812-213-5997 any time."
        keywords="emergency roof repair Evansville, 24/7 roofing Indiana, roof tarping emergency, tree on roof emergency, roof leak repair Evansville, emergency roofing contractor Tri-State"
        canonical="/emergency-services"
        schema={emergencySchema}
      />

      {/* ── HERO ── */}
      <section className="relative min-h-[85vh] flex flex-col overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1400x900.svg"
            alt="24/7 Emergency roofing crew Evansville Indiana"
            className="w-full h-full object-cover object-top opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/70 via-charcoal-deep/50 to-charcoal-deep" />
        </div>

        <div className="relative z-10 flex-1 flex flex-col lg:flex-row items-start gap-12 px-6 md:px-10 lg:px-16 pt-32 md:pt-36 pb-16">
          {/* Left */}
          <div className="flex-1 max-w-2xl">
            <div className="flex items-center gap-3 mb-6">
              <span className="relative flex items-center w-3 h-3">
                <span className="absolute inset-0 rounded-full bg-red-500 animate-ping opacity-60" />
                <span className="relative w-3 h-3 rounded-full bg-red-500" />
              </span>
              <span className="text-red-400 text-xs font-bold uppercase tracking-[0.3em]">Live Dispatch Center</span>
              <span className="text-white/20 text-xs font-mono">{formatTime(currentTime)}</span>
            </div>
            <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 8vw, 7rem)' }}>
              Roof Emergency?<br /><span className="text-red-400">We're Already Moving.</span>
            </h1>
            <p className="text-white/50 text-base md:text-lg leading-relaxed mb-6 max-w-md">
              6 crews. 5 dispatch zones. 24/7 live tracking. When you call, the nearest crew is already en route. No voicemails. No delays.
            </p>

            <div className="mb-8">
              <CountdownTimer expiresAt={nearestExpiry} variant="banner" />
              <div className="mt-3">
                <SocialProofPulse />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 mb-10">
              <a href="tel:8122135997" className="flex items-center justify-center gap-2 bg-red-600 hover:bg-red-500 text-white font-bold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer">
                <i className="ri-phone-fill text-lg" />
                Call 812-213-5997
              </a>
              <button
                onClick={() => document.getElementById('dispatch-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="flex items-center justify-center gap-2 border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-all duration-200 whitespace-nowrap cursor-pointer"
              >
                <i className="ri-alarm-warning-line text-orange" />
                Submit Emergency Request
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { icon: 'ri-timer-line', text: '< 15 Min Callback' },
                { icon: 'ri-truck-line', text: '< 60 Min On Scene' },
                { icon: 'ri-shield-check-line', text: 'Fully Insured' },
                { icon: 'ri-phone-line', text: 'Live Dispatchers' },
              ].map((item) => (
                <div key={item.text} className="flex items-center gap-2 text-white/40 text-xs uppercase tracking-wider">
                  <i className={`${item.icon} text-orange text-sm`} />
                  {item.text}
                </div>
              ))}
            </div>
          </div>

          {/* Right — Dispatch status card */}
          <div className="w-full lg:w-[400px] flex-shrink-0">
            <div className="border border-white/10 bg-charcoal-deep p-6">
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-white/60 text-xs uppercase tracking-widest font-semibold">Dispatch Live</span>
                </div>
                <span className="text-white/20 text-xs font-mono">{formatTime(currentTime)}</span>
              </div>
              <div className="space-y-3">
                {[
                  { label: 'Alpha Crew', status: 'En Route', eta: '12 min', color: 'text-green-400', location: 'Oak Hill Dr, Evansville' },
                  { label: 'Bravo Crew', status: 'On Scene', eta: '—', color: 'text-green-400', location: 'Spring Valley Rd, Newburgh' },
                  { label: 'Charlie Crew', status: 'Standby', eta: '25 min', color: 'text-orange', location: 'Henderson, KY' },
                  { label: 'Echo Crew', status: 'Standby', eta: '35 min', color: 'text-orange', location: 'Mount Vernon, IN' },
                  { label: 'Night Watch', status: 'Standby', eta: '45 min', color: 'text-orange', location: 'Owensboro, KY' },
                  { label: 'Delta Crew', status: 'Off Duty', eta: '6:00 PM', color: 'text-white/30', location: 'Boonville, IN' },
                ].map((crew) => (
                  <div key={crew.label} className="flex items-center justify-between py-2 border-b border-white/5 last:border-b-0">
                    <div>
                      <p className="text-white/70 text-xs font-semibold">{crew.label}</p>
                      <p className="text-white/25 text-[10px] mt-0.5">{crew.location}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-xs font-semibold ${crew.color}`}>{crew.status}</p>
                      <p className="text-white/20 text-[10px] mt-0.5">{crew.eta !== '—' ? `ETA ${crew.eta}` : 'Active'}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between">
                <span className="text-white/30 text-[10px] uppercase tracking-wider">4 of 6 crews available</span>
                <button
                  onClick={() => document.getElementById('crew-dashboard')?.scrollIntoView({ behavior: 'smooth' })}
                  className="text-orange/60 hover:text-orange text-[10px] uppercase tracking-widest transition-colors cursor-pointer"
                >
                  Full Dashboard <i className="ri-arrow-right-line ml-1" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── 5-STEP DISPATCH FLOW ── */}
      <section className="bg-warm-beige py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 border border-orange/30 bg-orange/5 px-4 py-2 mb-5">
              <i className="ri-route-line text-orange text-sm" />
              <span className="text-orange text-xs font-semibold uppercase tracking-[0.25em]">The Process</span>
            </div>
            <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}>
              How Emergency<br />Dispatch Works
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {DISPATCH_STEPS.map((step, i) => (
              <div key={step.num} className="relative">
                <div className="border border-charcoal/10 bg-white p-5 h-full">
                  <div className="font-display text-charcoal-deep/10 text-4xl tracking-wider mb-2">{step.num}</div>
                  <div className="w-8 h-8 flex items-center justify-center bg-orange/10 mb-3">
                    <i className={
                      i === 0 ? 'ri-phone-line text-orange text-sm' :
                      i === 1 ? 'ri-truck-line text-orange text-sm' :
                      i === 2 ? 'ri-shield-flash-line text-orange text-sm' :
                      i === 3 ? 'ri-camera-3-line text-orange text-sm' :
                      'ri-hammer-line text-orange text-sm'
                    } />
                  </div>
                  <h3 className="font-display text-charcoal-deep text-sm uppercase tracking-widest mb-2">{step.title}</h3>
                  <p className="text-charcoal-mid/50 text-xs leading-relaxed">{step.desc}</p>
                </div>
                {i < 4 && (
                  <div className="hidden md:block absolute top-1/2 -right-2 w-4 h-px bg-charcoal/10" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── EMERGENCY TYPES ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal-deep">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 border border-red-500/30 bg-red-500/5 px-4 py-2 mb-5">
              <i className="ri-error-warning-line text-red-400 text-sm" />
              <span className="text-red-400 text-xs font-semibold uppercase tracking-[0.25em]">What We Handle</span>
            </div>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}>
              Every Emergency.<br />One Number.
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {EMERGENCY_TYPES.map((type) => (
              <div key={type.title} className="border border-white/10 bg-charcoal p-5 hover:border-orange/30 transition-colors">
                <div className="w-10 h-10 flex items-center justify-center bg-orange/10 mb-4">
                  <i className={`${type.icon} text-orange text-lg`} />
                </div>
                <h3 className="font-display text-white text-sm uppercase tracking-widest mb-2">{type.title}</h3>
                <p className="text-white/40 text-xs leading-relaxed">{type.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CREW DASHBOARD + DISPATCH MAP ── */}
      <section id="crew-dashboard" className="bg-warm-beige py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="max-w-6xl mx-auto space-y-16">
          {/* Crew Dashboard */}
          <div>
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
              <div>
                <div className="inline-flex items-center gap-2 border border-orange/30 bg-orange/5 px-4 py-2 mb-4">
                  <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-orange text-xs font-semibold uppercase tracking-[0.25em]">Live Crew Status</span>
                </div>
                <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 3rem)' }}>
                  Who's Ready Right Now
                </h2>
              </div>
              <span className="text-charcoal-mid/40 text-xs uppercase tracking-wider">Click any crew for details</span>
            </div>
            <CrewDashboard />
          </div>

          {/* Dispatch Zones + Map */}
          <div>
            <div className="mb-8">
              <div className="inline-flex items-center gap-2 border border-orange/30 bg-orange/5 px-4 py-2 mb-4">
                <i className="ri-map-pin-line text-orange text-sm" />
                <span className="text-orange text-xs font-semibold uppercase tracking-[0.25em]">Dispatch Zones</span>
              </div>
              <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 3rem)' }}>
                Coverage Map & Response Times
              </h2>
            </div>
            <DispatchZones />
          </div>

          {/* Dispatch Log */}
          <div>
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
              <div>
                <div className="inline-flex items-center gap-2 border border-orange/30 bg-orange/5 px-4 py-2 mb-4">
                  <i className="ri-history-line text-orange text-sm" />
                  <span className="text-orange text-xs font-semibold uppercase tracking-[0.25em]">Call Log</span>
                </div>
                <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 3rem)' }}>
                  Recent Emergency Calls
                </h2>
              </div>
            </div>
            <DispatchLog />
          </div>

          {/* Last 24 Hours Activity Feed */}
          <div>
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
              <div>
                <div className="inline-flex items-center gap-2 border border-red-500/30 bg-red-500/5 px-4 py-2 mb-4">
                  <span className="relative w-2 h-2">
                    <span className="absolute inset-0 rounded-full bg-red-500 animate-ping opacity-60" />
                    <span className="relative w-2 h-2 rounded-full bg-red-500 block" />
                  </span>
                  <span className="text-red-400 text-xs font-semibold uppercase tracking-[0.25em]">Live Feed</span>
                </div>
                <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 3rem)' }}>
                  Last 24 Hours of Activity
                </h2>
              </div>
            </div>
            <ActivityFeed />
          </div>
        </div>
      </section>

      {/* ── RESPONSE GUARANTEES ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal-deep">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 border border-orange/30 bg-orange/5 px-4 py-2 mb-5">
              <i className="ri-shield-star-line text-orange text-sm" />
              <span className="text-orange text-xs font-semibold uppercase tracking-[0.25em]">Our Promise</span>
            </div>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}>
              Response Guarantees
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {RESPONSE_GUARANTEES.map((g) => (
              <div key={g.label} className="border border-white/10 bg-charcoal p-6 text-center hover:border-orange/30 transition-colors">
                <div className="w-12 h-12 flex items-center justify-center bg-orange/10 mx-auto mb-4">
                  <i className={`${g.icon} text-orange text-xl`} />
                </div>
                <p className="font-display text-orange text-2xl tracking-wider mb-1">{g.time}</p>
                <p className="text-white font-semibold text-sm uppercase tracking-widest mb-2">{g.label}</p>
                <p className="text-white/40 text-xs leading-relaxed">{g.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── EMERGENCY FORM ── */}
      <section id="dispatch-form" className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="max-w-3xl mx-auto">
          <div className="bg-white overflow-hidden">
            <div className="bg-red-600 px-6 md:px-10 py-5 flex items-center justify-between">
              <div>
                <h2 className="font-display text-white text-xl uppercase tracking-wider">Emergency Dispatch Request</h2>
                <p className="text-white/80 text-xs mt-0.5">All fields are required. A dispatcher will call within 15 minutes.</p>
              </div>
              <div className="w-10 h-10 flex items-center justify-center bg-white/15">
                <i className="ri-alarm-warning-line text-white text-lg" />
              </div>
            </div>

            {status === 'success' ? (
              <div className="px-6 md:px-10 py-14 flex flex-col items-center text-center">
                <div className="w-16 h-16 flex items-center justify-center bg-green-500/15 mb-5">
                  <i className="ri-checkbox-circle-fill text-green-400 text-3xl" />
                </div>
                <h3 className="font-display text-charcoal-deep text-2xl uppercase tracking-wider mb-2">Dispatched!</h3>
                <p className="text-charcoal-mid/50 text-sm max-w-sm leading-relaxed mb-2">
                  Your request is live in our dispatch center. A crew coordinator will call you within 15 minutes with an ETA.
                </p>
                <p className="text-charcoal-mid/30 text-xs mb-6">If this is life-threatening, call 911 first.</p>
                <a href="tel:8122135997" className="bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-3 uppercase tracking-widest text-sm transition-colors whitespace-nowrap">
                  Call 812-213-5997
                </a>
              </div>
            ) : (
              <form ref={formRef} data-readdy-form onSubmit={handleSubmit} className="px-6 md:px-10 py-7 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-charcoal-mid/60 text-[10px] font-semibold uppercase tracking-wider mb-1.5">Full Name</label>
                    <input type="text" name="name" required placeholder="John Smith" className="w-full bg-warm-beige border border-charcoal/10 px-3.5 py-3 text-charcoal-deep text-sm placeholder:text-charcoal-mid/50 focus:outline-none focus:border-orange/40" />
                  </div>
                  <div>
                    <label className="block text-charcoal-mid/60 text-[10px] font-semibold uppercase tracking-wider mb-1.5">Phone</label>
                    <input type="tel" name="phone" required placeholder="812-000-0000" className="w-full bg-warm-beige border border-charcoal/10 px-3.5 py-3 text-charcoal-deep text-sm placeholder:text-charcoal-mid/50 focus:outline-none focus:border-orange/40" />
                  </div>
                </div>
                <div>
                  <label className="block text-charcoal-mid/60 text-[10px] font-semibold uppercase tracking-wider mb-1.5">Address</label>
                  <input type="text" name="address" required placeholder="123 Main St, Evansville, IN 47714" className="w-full bg-warm-beige border border-charcoal/10 px-3.5 py-3 text-charcoal-deep text-sm placeholder:text-charcoal-mid/50 focus:outline-none focus:border-orange/40" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-charcoal-mid/60 text-[10px] font-semibold uppercase tracking-wider mb-1.5">Emergency Type</label>
                    <select name="emergency_type" required value={formType} onChange={(e) => setFormType(e.target.value)} className="w-full bg-warm-beige border border-charcoal/10 px-3.5 py-3 text-charcoal-deep text-sm focus:outline-none focus:border-orange/40 appearance-none cursor-pointer">
                      <option value="unknown">Select emergency type</option>
                      <option value="active_leak">Active Roof Leak — Water entering home</option>
                      <option value="tree_debris">Tree or Debris on Roof</option>
                      <option value="missing_shingles">Missing / Blown-Off Shingles</option>
                      <option value="hole_puncture">Hole or Puncture in Roof</option>
                      <option value="fire_damage">Fire Damage to Roof</option>
                      <option value="commercial">Commercial Building Emergency</option>
                      <option value="other">Other — describe in notes</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-charcoal-mid/60 text-[10px] font-semibold uppercase tracking-wider mb-1.5">Is water entering?</label>
                    <select name="water_active" required className="w-full bg-warm-beige border border-charcoal/10 px-3.5 py-3 text-charcoal-deep text-sm focus:outline-none focus:border-orange/40 appearance-none cursor-pointer">
                      <option value="">Select</option>
                      <option value="yes_active">Yes — actively leaking now</option>
                      <option value="yes_stopped">Yes — but stopped / contained</option>
                      <option value="no">No — no water entering</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-charcoal-mid/60 text-[10px] font-semibold uppercase tracking-wider mb-1.5">Notes (describe the damage)</label>
                  <textarea name="notes" rows={3} maxLength={500} onChange={(e) => setCharCount(e.target.value.length)} placeholder="Tell us what happened, when, and how bad it looks..." className="w-full bg-warm-beige border border-charcoal/10 px-3.5 py-3 text-charcoal-deep text-sm placeholder:text-charcoal-mid/50 focus:outline-none focus:border-orange/40 resize-none" />
                  <p className={`text-[10px] mt-0.5 text-right ${charCount > 500 ? 'text-red-500' : 'text-charcoal-mid/20'}`}>{charCount}/500</p>
                </div>
                <button
                  type="submit"
                  disabled={status === 'submitting'}
                  className="w-full bg-red-600 hover:bg-red-700 disabled:bg-charcoal-mid/20 text-white font-bold text-sm uppercase tracking-widest py-4 transition-colors flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  {status === 'submitting' ? (
                    <><i className="ri-loader-4-line animate-spin" />Dispatching Crew...</>
                  ) : (
                    <><i className="ri-alarm-warning-line" />Dispatch Emergency Crew</>
                  )}
                </button>
                {status === 'error' && (
                  <div className="bg-red-500/10 border border-red-500/20 p-3 flex items-center gap-2">
                    <i className="ri-alert-line text-red-400 text-sm" />
                    <p className="text-red-400 text-xs">Failed to send. Please call 812-213-5997 directly.</p>
                  </div>
                )}
                <p className="text-charcoal-mid/20 text-[10px] text-center flex items-center justify-center gap-1">
                  <i className="ri-lock-line" />Your info is private and secure.
                </p>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* ── FINAL CTA ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal-deep">
        <div className="max-w-3xl mx-auto text-center">
          <div className="w-16 h-16 flex items-center justify-center bg-red-600/15 mx-auto mb-6">
            <i className="ri-phone-fill text-red-400 text-2xl" />
          </div>
          <h2 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wider mb-4">
            When Your Roof Fails,<br />We Don't.
          </h2>
          <p className="text-white/40 text-sm md:text-base leading-relaxed mb-8 max-w-lg mx-auto">
            Every minute counts during a roofing emergency. Our dispatch center is staffed 24/7 with live humans who route crews in real time. Call now — don't wait.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="tel:8122135997" className="bg-red-600 hover:bg-red-700 text-white font-bold px-10 py-5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-3">
              <i className="ri-phone-fill text-lg" />
              Call 812-213-5997
            </a>
            <button
              onClick={() => navigate('/storm-damage')}
              className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-10 py-5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              Storm Damage Guide
            </button>
          </div>
          <p className="text-white/20 text-xs mt-6">Corner Stone Construction & Roofing · Evansville IN · Licensed & Insured · 25+ Years</p>
        </div>
      </section>
    </div>
  );
}