import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { testimonials } from '@/mocks/testimonials';
import GoogleReviewsWidget from '@/components/feature/GoogleReviewsWidget';
import VideoTestimonialsSection from '@/components/feature/VideoTestimonialsSection';
import PageSEO from '@/components/feature/PageSEO';

const allReviews = [
  ...testimonials,
  {
    id: 8,
    name: 'Tom Becker',
    role: 'Homeowner',
    location: 'Newburgh, IN',
    rating: 5,
    headline: 'Best Decision We Made',
    text: 'We had three different roofers come out and Corner Stone was the only one who actually got on the roof and showed us photos of the damage. The others just eyeballed it from the driveway. That attention to detail is why we hired them and we are so glad we did.',
    avatar: '/placeholders/100x100.svg',
  },
  {
    id: 9,
    name: 'Angela Foster',
    role: 'Homeowner',
    location: 'Boonville, IN',
    rating: 5,
    headline: 'Financing Made It Possible',
    text: 'I was putting off replacing my roof for two years because of the cost. Corner Stone set me up with a payment plan that fit my budget and I wish I had done it sooner. The new roof looks incredible and I have not had a single leak since. The crew was respectful and cleaned up everything.',
    avatar: '/placeholders/100x100.svg',
  },
  {
    id: 10,
    name: 'Carlos Mendez',
    role: 'Business Owner',
    location: 'Evansville, IN',
    rating: 5,
    headline: 'Commercial Job Done Right',
    text: 'We needed our warehouse roof replaced without shutting down operations. Corner Stone phased the work over three weekends and we never missed a single day of production. The project manager communicated every step of the way. Absolutely professional from start to finish.',
    avatar: '/placeholders/100x100.svg',
  },
  {
    id: 11,
    name: 'Patricia Simmons',
    role: 'Homeowner',
    location: 'Henderson, KY',
    rating: 5,
    headline: 'They Caught What Others Missed',
    text: 'After the April storm I had two other companies tell me I only had minor damage. Corner Stone came out, got on the roof, and found significant hail damage that the others missed. They documented everything and my insurance approved a full replacement. I would have been out thousands without them.',
    avatar: '/placeholders/100x100.svg',
  },
  {
    id: 12,
    name: 'Derek Walsh',
    role: 'Homeowner',
    location: 'Mount Vernon, IN',
    rating: 5,
    headline: 'Fast, Clean, and Honest',
    text: 'Called on a Monday, had an inspection Tuesday, quote Wednesday, and the crew was on my roof by Friday. The whole replacement was done in one day. They cleaned up every single nail — I walked the yard with a magnet and found nothing. That is the kind of detail that earns a five-star review.',
    avatar: '/placeholders/100x100.svg',
  },
];

const stats = [
  { value: '4.9', label: 'Google Rating', sub: 'Based on 300+ reviews', icon: 'ri-star-fill' },
  { value: 'A+', label: 'BBB Rating', sub: 'Better Business Bureau', icon: 'ri-award-line' },
  { value: '300+', label: 'Five-Star Reviews', sub: 'Across all platforms', icon: 'ri-thumb-up-line' },
  { value: '25+', label: 'Years Trusted', sub: 'Serving the Tri-State area', icon: 'ri-calendar-check-line' },
];

function ReviewCard({ review, index }: { review: typeof allReviews[0]; index: number }) {
  const anim = useScrollAnimation({ threshold: 0.1 });
  return (
    <div
      ref={anim.ref as React.RefObject<HTMLDivElement>}
      className={`anim-fade-up ${anim.isVisible ? 'is-visible' : ''} bg-charcoal-mid border border-white/5 hover:border-orange/20 transition-all duration-300 p-6 md:p-8 flex flex-col`}
      style={{ transitionDelay: `${(index % 3) * 100}ms` }}
    >
      {/* Stars */}
      <div className="flex gap-0.5 mb-4">
        {Array.from({ length: review.rating }).map((_, i) => (
          <i key={i} className="ri-star-fill text-orange text-sm" />
        ))}
      </div>

      {/* Headline */}
      <p className="font-display text-white text-lg uppercase tracking-wide mb-3 leading-snug">
        "{review.headline}"
      </p>

      {/* Body */}
      <p className="text-white/50 text-sm leading-relaxed flex-grow mb-6">
        {review.text}
      </p>

      {/* Author */}
      <div className="flex items-center gap-3 pt-5 border-t border-white/10">
        <img
          src={review.avatar}
          alt={review.name}
          className="w-10 h-10 object-cover flex-shrink-0"
        />
        <div>
          <p className="text-white text-sm font-semibold">{review.name}</p>
          <p className="text-white/30 text-xs">{review.role} &bull; {review.location}</p>
        </div>
        <div className="ml-auto">
          <div className="flex items-center gap-1.5 text-white/20 text-xs">
            <svg className="w-3 h-3 flex-shrink-0" viewBox="0 0 24 24" fill="none">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
            </svg>
            Google
          </div>
        </div>
      </div>
    </div>
  );
}

export default function TestimonialsPage() {
  const navigate = useNavigate();
  const heroAnim = useScrollAnimation();
  const statsAnim = useScrollAnimation({ threshold: 0.1 });
  const featuredAnim = useScrollAnimation({ threshold: 0.1 });

  const featured = allReviews[0];

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roofing Reviews Evansville Indiana | 300+ Five-Star Google Reviews"
        description="Read 300+ five-star reviews from homeowners and businesses across Evansville IN, Newburgh, Henderson KY, and the Tri-State area. Corner Stone Construction & Roofing — 4.9 Google rating, A+ BBB. See why we're the most trusted roofer in Indiana."
        keywords="roofing reviews Evansville Indiana, Corner Stone roofing testimonials, best roofing contractor Evansville reviews, 5 star roofing company Indiana, roofing company reviews Tri-State"
        canonical="/testimonials"
      />

      {/* Hero */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1600x900.svg"
            alt="Happy Corner Stone customers in Evansville Indiana"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/65 via-black/55 to-charcoal-deep" />
        </div>
        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 text-center anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs md:text-sm font-semibold tracking-[0.25em] uppercase mb-5">
            Real Customers. Real Results.
          </p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 8vw, 7rem)' }}>
            What Our<br />Customers<br /><span className="text-orange">Are Saying</span>
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-2xl mx-auto leading-relaxed mb-10">
            Over 300 five-star reviews from homeowners and businesses across Evansville, Henderson, Newburgh, and the entire Tri-State area.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="https://share.google/ta8gqakRmfIlctL3K"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 bg-white/10 hover:bg-white/20 border border-white/20 hover:border-white/40 text-white font-semibold px-8 py-4 uppercase tracking-wide text-sm transition-all whitespace-nowrap"
            >
              <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 24 24" fill="none">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
              </svg>
              Leave Us a Review
            </a>
            <button
              onClick={() => navigate('/estimate')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              Get a Free Estimate
            </button>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="bg-charcoal border-y border-white/10 py-10 md:py-14 px-6 md:px-10 lg:px-16">
        <div
          ref={statsAnim.ref as React.RefObject<HTMLDivElement>}
          className={`grid grid-cols-2 lg:grid-cols-4 gap-8 anim-fade-up ${statsAnim.isVisible ? 'is-visible' : ''}`}
        >
          {stats.map((stat, i) => (
            <div
              key={stat.label}
              className={`text-center anim-fade-up ${statsAnim.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <div className="w-10 h-10 flex items-center justify-center bg-orange/20 text-orange mx-auto mb-3">
                <i className={`${stat.icon} text-lg`} />
              </div>
              <p className="font-display text-orange text-4xl md:text-5xl uppercase tracking-wider mb-1">{stat.value}</p>
              <p className="text-white text-xs font-semibold uppercase tracking-wider mb-0.5">{stat.label}</p>
              <p className="text-white/30 text-xs">{stat.sub}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Review */}
      <section className="py-16 md:py-24 px-6 md:px-10 lg:px-16">
        <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-8">Featured Review</p>
        <div
          ref={featuredAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${featuredAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-0 border border-white/10 hover:border-orange/30 transition-colors duration-300">
            {/* Image */}
            <div className="lg:col-span-2 relative min-h-[280px] overflow-hidden">
              <img
                src="/placeholders/600x500.svg"
                alt="Happy Corner Stone customer"
                className="absolute inset-0 w-full h-full object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent to-charcoal-deep/40 lg:bg-gradient-to-l" />
            </div>
            {/* Content */}
            <div className="lg:col-span-3 bg-charcoal-mid p-8 md:p-12 flex flex-col justify-center">
              <div className="flex gap-0.5 mb-5">
                {[1,2,3,4,5].map(i => <i key={i} className="ri-star-fill text-orange text-lg" />)}
              </div>
              <i className="ri-double-quotes-l text-orange text-4xl mb-4 block" />
              <p className="font-serif text-white text-xl md:text-2xl leading-relaxed mb-8">
                "{featured.text}"
              </p>
              <div className="flex items-center gap-4 pt-6 border-t border-white/10">
                <img
                  src={featured.avatar}
                  alt={featured.name}
                  className="w-14 h-14 object-cover flex-shrink-0"
                />
                <div>
                  <p className="text-white font-semibold text-base">{featured.name}</p>
                  <p className="text-white/40 text-sm">{featured.role} &bull; {featured.location}</p>
                </div>
                <div className="ml-auto hidden sm:flex items-center gap-2 text-white/20 text-xs">
                  <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 24 24" fill="none">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                  </svg>
                  Verified Google Review
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* All Reviews Grid */}
      <section className="pb-20 md:pb-28 px-6 md:px-10 lg:px-16">
        <div className="flex items-center justify-between mb-10 md:mb-14">
          <div>
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-2">All Reviews</p>
            <h2 className="font-display text-white text-3xl md:text-4xl uppercase tracking-wider leading-none">
              {allReviews.length} Happy Customers
            </h2>
          </div>
          <a
            href="https://share.google/ta8gqakRmfIlctL3K"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:flex items-center gap-2 border border-white/20 hover:border-orange px-5 py-3 text-white/50 hover:text-white text-xs uppercase tracking-wider transition-all whitespace-nowrap"
          >
            <i className="ri-add-line text-orange" />
            Add Your Review
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
          {allReviews.map((review, i) => (
            <ReviewCard key={review.id} review={review} index={i} />
          ))}
        </div>
      </section>

      {/* Live Google Reviews Widget */}
      <GoogleReviewsWidget />

      {/* Video Testimonials */}
      <VideoTestimonialsSection />

      {/* By the Numbers */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-14">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">By the Numbers</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
            The Results Speak<br />For Themselves
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          {[
            {
              icon: 'ri-home-4-line',
              stat: '2,500+',
              label: 'Roofs Completed',
              desc: 'From single-story homes to large commercial buildings across Indiana and Kentucky.',
              image: '/placeholders/600x400.svg',
            },
            {
              icon: 'ri-shield-check-line',
              stat: '94%',
              label: 'Insurance Claims Approved',
              desc: 'Of the insurance claims we handle get approved on the first submission — well above industry average.',
              image: '/placeholders/600x400.svg',
            },
            {
              icon: 'ri-star-fill',
              stat: '4.9★',
              label: 'Average Google Rating',
              desc: 'Maintained across 300+ verified Google reviews from real customers in the Tri-State area.',
              image: '/placeholders/600x400.svg',
            },
          ].map((item) => (
            <div key={item.label} className="group bg-charcoal-mid border border-white/5 hover:border-orange/20 transition-all duration-300 overflow-hidden">
              <div className="relative h-48 overflow-hidden">
                <img
                  src={item.image}
                  alt={item.label}
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal-mid via-charcoal-mid/30 to-transparent" />
              </div>
              <div className="p-6 md:p-8">
                <div className="w-10 h-10 flex items-center justify-center bg-orange/20 text-orange mb-4">
                  <i className={`${item.icon} text-base`} />
                </div>
                <p className="font-display text-orange text-4xl md:text-5xl uppercase tracking-wider mb-1">{item.stat}</p>
                <p className="text-white font-semibold text-sm uppercase tracking-wider mb-3">{item.label}</p>
                <p className="text-white/40 text-sm leading-relaxed">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="bg-charcoal-mid border border-white/5 p-10 md:p-16 lg:p-20 text-center">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Join Our Happy Customers</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Ready to Be Our<br /><span className="text-orange">Next Success Story?</span>
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-lg mx-auto leading-relaxed mb-10">
            Free inspections, honest quotes, and the same quality that earned us 300+ five-star reviews. Let's get started.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigate('/estimate')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              Get a Free Estimate
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/20 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>
      </section>

    </div>
  );
}
