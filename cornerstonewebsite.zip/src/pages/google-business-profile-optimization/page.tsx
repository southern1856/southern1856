import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const gbpSchema = [
  {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: 'Google Business Profile Optimization Checklist for Roofing Companies',
    description: 'A complete step-by-step checklist for optimizing your Google Business Profile as a roofing contractor in Evansville Indiana and surrounding areas. Includes photo strategy, review management, Q&A optimization, and local SEO best practices.',
    author: {
      '@type': 'RoofingContractor',
      name: 'Corner Stone Construction & Roofing',
      url: 'https://cornerstoneconstructionevansville.com',
    },
    publisher: {
      '@type': 'RoofingContractor',
      name: 'Corner Stone Construction & Roofing',
      url: 'https://cornerstoneconstructionevansville.com',
    },
    datePublished: '2026-05-12',
    dateModified: '2026-05-12',
    mainEntityOfPage: {
      '@type': 'WebPage',
      '@id': 'https://cornerstoneconstructionevansville.com/google-business-profile-optimization',
    },
  },
  {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: [
      {
        '@type': 'Question',
        name: 'How long does Google Business Profile optimization take to show results?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'Most roofing contractors see ranking improvements within 2–4 weeks of completing GBP optimization. Review velocity, photo freshness, and post frequency compound over time — peak results typically show after 3–6 months of consistent activity.',
        },
      },
      {
        '@type': 'Question',
        name: 'Can a roofing company have multiple Google Business Profiles for different cities?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'No — Google prohibits duplicate profiles for the same business. Instead, use service-area settings to list all the cities you serve without a physical address in each one. Create dedicated city pages on your website (like our Evansville, Newburgh, and Henderson pages) and link them from your main GBP.',
        },
      },
      {
        '@type': 'Question',
        name: 'How many photos should a roofing company upload to GBP per month?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'Upload a minimum of 10–15 photos per month. Mix project photos, team photos, material close-ups, and customer-facing content. Businesses that post photos weekly get 42% more requests for directions and 35% more website clicks than those that do not.',
        },
      },
      {
        '@type': 'Question',
        name: 'What is the best way to get Google reviews for a roofing company?',
        acceptedAnswer: {
          '@type': 'Answer',
          text: 'Ask immediately after project completion while satisfaction is highest. Send a text message with a direct review link (not an email — open rates for review SMS are 3x higher). Make it effortless: one tap, no login required. Never offer incentives — it violates Google policy and can get reviews removed.',
        },
      },
    ],
  },
];

interface ChecklistItem {
  id: string;
  label: string;
  description?: string;
}

interface ChecklistSection {
  title: string;
  icon: string;
  items: ChecklistItem[];
}

const checklistSections: ChecklistSection[] = [
  {
    title: 'Profile Foundation',
    icon: 'ri-building-line',
    items: [
      { id: 'pf-1', label: 'Claim and verify your Google Business Profile', description: 'Go to business.google.com, search your business name, and complete the verification process (usually via postcard or phone).' },
      { id: 'pf-2', label: 'Set exact business name (no keyword stuffing)', description: 'Use your real legal business name. Do not add "Roofing" or location keywords unless they are part of your actual registered name.' },
      { id: 'pf-3', label: 'Select "Roofing Contractor" as primary category', description: 'This is the single most important ranking signal. Secondary categories can include "Construction Company" or "Home Inspector" if applicable.' },
      { id: 'pf-4', label: 'Add all relevant secondary categories', description: 'Roofing supply store, Gutter cleaning service, Siding contractor, Construction company, Home inspector — whatever applies.' },
      { id: 'pf-5', label: 'Enter complete NAP (Name, Address, Phone) — exact match everywhere', description: 'Your GBP address must match your website footer, Yelp, BBB, Angi, and every citation exactly. Even "St" vs "Street" matters.' },
      { id: 'pf-6', label: 'Add service areas (all cities you serve)', description: 'List every city in your service radius — Evansville, Newburgh, Boonville, Henderson, Owensboro, etc. Do not just rely on your physical address radius.' },
      { id: 'pf-7', label: 'Set accurate business hours (including seasonal adjustments)', description: 'Update hours for storm season, winter slowdowns, or holiday closures. Inaccurate hours hurt rankings and frustrate customers.' },
      { id: 'pf-8', label: 'Write a detailed business description (750 characters max)', description: 'Lead with your value proposition, include "Evansville roofing" and 2–3 service keywords naturally, and end with a CTA. No duplicate content from your website.' },
    ],
  },
  {
    title: 'Photo & Visual Strategy',
    icon: 'ri-image-line',
    items: [
      { id: 'pv-1', label: 'Upload a high-resolution logo (250x250 minimum)', description: 'Clear, professional, no text smaller than 12pt. Use PNG for transparency if applicable.' },
      { id: 'pv-2', label: 'Add a cover photo that shows your best work', description: 'This is the first image people see. Use a dramatic before/after or a beautiful completed roof shot. Avoid stock photos.' },
      { id: 'pv-3', label: 'Post 3–5 new project photos every week', description: 'Google favors active profiles. A photo of this week\'s job signals you are a real, current, busy contractor.' },
      { id: 'pv-4', label: 'Include team photos and behind-the-scenes shots', description: 'People buy from people. Candid crew shots, safety meetings, material deliveries — these build trust and differentiate you from faceless competitors.' },
      { id: 'pv-5', label: 'Tag photos with location metadata', description: 'Upload photos taken at job sites with GPS data intact. Google uses geotagged photos as a local relevance signal.' },
      { id: 'pv-6', label: 'Create before/after albums for each major project', description: 'Organize photos into GBP albums by project type: "Hail Damage Repairs," "Metal Roof Replacements," "Commercial Flat Roofs."' },
      { id: 'pv-7', label: 'Add interior photos for leak/water damage work', description: 'Shows the full scope of your work. Homeowners searching for "roof leak repair" will see you handle the interior damage too.' },
      { id: 'pv-8', label: 'Use photos in every GBP post (not just text)', description: 'Posts with images get 2.5x more engagement. Even a simple update about storm season prep should include a team or project photo.' },
    ],
  },
  {
    title: 'Review Generation & Management',
    icon: 'ri-star-line',
    items: [
      { id: 'rg-1', label: 'Set a target of 5–10 new reviews per month', description: 'Consistent review velocity is a top 3 ranking factor. A burst of 20 reviews then 6 months of silence looks suspicious to Google.' },
      { id: 'rg-2', label: 'Create a direct Google review link (one-tap)', description: 'Generate your link from the Reviews tab in GBP Manager. Shorten it with bit.ly or your domain. Text it to customers — never email.' },
      { id: 'rg-3', label: 'Ask for reviews within 48 hours of project completion', description: 'Strike while satisfaction is highest. The crew should hand the homeowner a card with the review link and say: "If you were happy with our work, would you mind leaving us a quick review?"' },
      { id: 'rg-4', label: 'Respond to every single review within 24 hours', description: 'Google confirms this is a ranking signal. Thank positive reviewers by name and mention the specific project. Address negative reviews professionally and move the conversation offline.' },
      { id: 'rg-5', label: 'Use review response keywords naturally', description: 'In your responses, mention "Evansville roof repair," "storm damage," or the customer\'s neighborhood name. This adds keyword relevance without stuffing.' },
      { id: 'rg-6', label: 'Flag and report fake or competitor reviews', description: 'If a review is from someone you never worked with, report it to Google immediately. Document your case with job records and photos.' },
      { id: 'rg-7', label: 'Diversify review platforms (not just Google)', description: 'Google cross-references reviews from BBB, Yelp, Angi, and Facebook. A strong presence across 3–4 platforms builds trust and authority.' },
      { id: 'rg-8', label: 'Showcase top reviews on your website', description: 'Embed a Google Reviews widget or hand-pick 3–5 standout reviews to display on your homepage and testimonials page.' },
    ],
  },
  {
    title: 'Q&A & Attributes',
    icon: 'ri-question-answer-line',
    items: [
      { id: 'qa-1', label: 'Pre-populate 10–15 common Q&As in your GBP', description: 'Ask and answer your own questions. Cover: "Do you offer free inspections?" "Are you licensed in Kentucky?" "Do you work with insurance?" "What brands of shingles do you use?"' },
      { id: 'qa-2', label: 'Use long-tail keywords in Q&A answers', description: 'Instead of "Yes, we do inspections," write: "Yes, we offer free roof inspections in Evansville, Newburgh, and across Vanderburgh County. No obligation."' },
      { id: 'qa-3', label: 'Monitor and answer new customer questions within 24 hours', description: 'Turn on email alerts for new Q&As. A fast, detailed response signals responsiveness — a ranking factor.' },
      { id: 'qa-4', label: 'Add all applicable business attributes', description: 'Women-owned, Veteran-owned, LGBTQ+ friendly, Online appointments, On-site services, Free estimates — check every box that applies.' },
      { id: 'qa-5', label: 'Enable messaging and respond within 15 minutes', description: 'GBP messaging is a direct lead channel. Set up notifications and aim for sub-15-minute response times during business hours.' },
      { id: 'qa-6', label: 'Add products and services with descriptions and pricing', description: 'List each service (residential roofing, commercial roofing, gutter installation) with a brief description. Include price ranges if possible — transparency builds trust.' },
      { id: 'qa-7', label: 'Link to your booking/estimate page from services', description: 'Each service listing can include a link. Point them to your free inspection or estimate page for direct conversion.' },
      { id: 'qa-8', label: 'Update Q&As seasonally (storm season, winter prep, etc.)', description: 'Add new Q&As before peak season: "How do I prepare my roof for hail season?" "What should I do if my roof leaks during a storm?"' },
    ],
  },
  {
    title: 'GBP Posts & Updates',
    icon: 'ri-article-line',
    items: [
      { id: 'gp-1', label: 'Post 2–3 updates per week minimum', description: 'This is the most underutilized GBP feature. Posts stay live for 7 days. A dead profile (no posts for months) signals inactivity to Google.' },
      { id: 'gp-2', label: 'Mix post types: offers, events, updates, and products', description: 'Do not just post "We are a roofing company." Share limited-time offers ("$500 off full replacements this month"), community events, completed project spotlights, and new product announcements.' },
      { id: 'gp-3', label: 'Include a call-to-action button on every post', description: 'Every post should have a CTA: "Call Now," "Learn More," "Get Offer," or "Book." Do not let the post end without telling the reader what to do next.' },
      { id: 'gp-4', label: 'Use local landmarks and neighborhood names in posts', description: '"Just finished a beautiful GAF Timberline HDZ install in the historic Haynie\'s Corner neighborhood of Evansville." Google reads this and boosts local relevance.' },
      { id: 'gp-5', label: 'Post before/after photos with project details', description: '"Hail damage repair in Newburgh — 28 sq, full shingle replacement, completed in 3 days. Insurance claim: $14,200." Specificity sells.' },
      { id: 'gp-6', label: 'Create urgency with seasonal and storm-related posts', description: '"Hail reported in Vanderburgh County last night. If you are in the 47710, 47711, or 47714 ZIP codes, schedule a free inspection this week before your claim window starts closing."' },
      { id: 'gp-7', label: 'Share team milestones and community involvement', description: '"Proud to sponsor the Evansville Little League opening day. We live here, we work here, and we protect the homes in this community."' },
      { id: 'gp-8', label: 'Repurpose blog content into GBP posts', description: 'Turn every blog article into 2–3 short GBP posts. A 1,500-word blog on "How to Choose a Roofing Contractor" becomes three bite-sized tips with CTAs back to the blog.' },
    ],
  },
  {
    title: 'Citations & Backlinks',
    icon: 'ri-links-line',
    items: [
      { id: 'cb-1', label: 'List your business on 30+ citation directories', description: 'Yelp, BBB, Angi, HomeAdvisor, Thumbtack, Porch, Houzz, Yellow Pages, Manta, Chamber of Commerce, local business directories. NAP must be identical on every listing.' },
      { id: 'cb-2', label: 'Get listed in local Evansville business directories', description: 'Evansville Chamber of Commerce, Southwest Indiana Builders Association, local church bulletins, neighborhood Facebook groups, Nextdoor.' },
      { id: 'cb-3', label: 'Earn backlinks from local news and blogs', description: 'Pitch storm damage stories to local news. Sponsor a community event and get mentioned on the organizer\'s website. Guest post on local home improvement blogs.' },
      { id: 'cb-4', label: 'Create city-specific landing pages on your website', description: 'One page per city you serve. Not duplicate content — unique content about that city\'s building codes, weather patterns, and local projects. Link them from your GBP.' },
      { id: 'cb-5', label: 'Embed a Google Map on your Contact page', description: 'Use the embed code from your GBP. This creates a direct connection between your website and your Google Maps listing, reinforcing local authority.' },
      { id: 'cb-6', label: 'Add Schema.org LocalBusiness markup to your homepage', description: 'Structured data tells Google exactly what you do, where you are, and what you offer. Include geo coordinates, opening hours, services, and aggregate rating.' },
      { id: 'cb-7', label: 'Get backlinks from supplier and manufacturer websites', description: 'GAF, Owens Corning, CertainTeed — many have "Find a Contractor" directories. Getting listed earns a trusted backlink and builds brand credibility.' },
      { id: 'cb-8', label: 'Build relationships with complementary local businesses', description: 'Real estate agents, home inspectors, insurance agents, gutter cleaners, HVAC companies — cross-link and refer each other. Local link networks are powerful.' },
    ],
  },
  {
    title: 'Analytics & Monitoring',
    icon: 'ri-bar-chart-line',
    items: [
      { id: 'am-1', label: 'Check GBP Insights weekly (calls, direction requests, website clicks)', description: 'Track trends: Are direction requests up after posting more photos? Did a post about storm damage spike calls? Use data to refine your strategy.' },
      { id: 'am-2', label: 'Track ranking for "roofing company near me" and city + roofing queries', description: 'Use a rank tracker (BrightLocal, Local Falcon, or even manual incognito searches) to monitor where you appear for target keywords.' },
      { id: 'am-3', label: 'Set up Google Alerts for your business name', description: 'Catch new mentions, reviews, and citations as they appear. Respond to anything that needs attention within 24 hours.' },
      { id: 'am-4', label: 'Audit competitors\' GBPs monthly', description: 'Check their photos, posts, reviews, and Q&As. What are they doing that you are not? Where are they weak that you can dominate?' },
      { id: 'am-5', label: 'Review and update all listings quarterly', description: 'NAP consistency drifts over time. Audit every directory, social profile, and citation for accuracy at least once per quarter.' },
      { id: 'am-6', label: 'A/B test post headlines and CTAs', description: 'Try "Free Roof Inspection" vs "Storm Damage Assessment" vs "Get Your Roof Checked Before the Next Storm." Track which drives more clicks and calls.' },
      { id: 'am-7', label: 'Document your GBP strategy in a shared doc', description: 'Create a living document with your posting schedule, review response templates, Q&A content, photo tagging system, and monthly goals. Share with your team.' },
      { id: 'am-8', label: 'Set monthly KPIs and review progress', description: 'Targets: 5+ reviews/month, 10+ photos/month, 8+ posts/month, 3+ new Q&As/month, 5% increase in direction requests quarter-over-quarter.' },
    ],
  },
];

const postIdeas = [
  {
    title: 'Storm Damage Alert',
    example: 'Hail reported in the 47710 ZIP code last night. If you are in Evansville\'s North Side, schedule a free inspection this week. Most insurance policies give you 12 months to file — but evidence fades fast.',
    icon: 'ri-thunderstorms-line',
    cta: 'Call Now',
  },
  {
    title: 'Project Spotlight',
    example: 'Just wrapped a full GAF Timberline HDZ replacement in Newburgh\'s Deer Creek Estates. 32 squares, upgraded to ridge vent, new gutters. Insurance claim: $16,400. Customer quote: "Best crew we\'ve ever hired."',
    icon: 'ri-home-smile-line',
    cta: 'View Project',
  },
  {
    title: 'Limited-Time Offer',
    example: 'Spring Roof Replacement Special — $500 off any full roof replacement booked by May 31st. Includes free attic insulation inspection. Financing available.',
    icon: 'ri-price-tag-3-line',
    cta: 'Get Offer',
  },
  {
    title: 'Customer Testimonial',
    example: '"Corner Stone replaced our roof after the April hail storm. They handled the insurance claim start to finish and we only paid our deductible. Highly recommend." — Sarah M., Evansville, IN',
    icon: 'ri-star-smile-line',
    cta: 'Read More Reviews',
  },
  {
    title: 'Educational Tip',
    example: '3 signs your roof has hail damage (even if you do not see leaks): 1) Granules in your gutters, 2) Dented vents or flashing, 3) Bruised shingles that feel soft when pressed. Get a free inspection to know for sure.',
    icon: 'ri-lightbulb-line',
    cta: 'Learn More',
  },
  {
    title: 'Community Involvement',
    example: 'Proud to sponsor the Warrick County 4-H Fair this July. We have been protecting homes in this community for 29 years — and we are just getting started.',
    icon: 'ri-heart-3-line',
    cta: 'About Us',
  },
];

const stats = [
  { value: '42%', label: 'More direction requests from businesses that post photos weekly', icon: 'ri-map-pin-2-line' },
  { value: '35%', label: 'More website clicks from active GBP profiles', icon: 'ri-mouse-line' },
  { value: '2.5x', label: 'More engagement on GBP posts that include images', icon: 'ri-image-line' },
  { value: '5x', label: 'Higher conversion rate for "near me" searches vs organic results', icon: 'ri-search-line' },
];

export default function GBPOptimization() {
  const navigate = useNavigate();
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>();
  const [showLeadForm, setShowLeadForm] = useState(false);
  const [leadFormStatus, setLeadFormStatus] = useState<'idle' | 'submitting' | 'success'>('idle');
  const [leadData, setLeadData] = useState({ name: '', email: '', company: '' });
  const [expandedSection, setExpandedSection] = useState<string | null>(null);

  const toggleCheck = (id: string) => {
    setCheckedItems((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const totalItems = checklistSections.reduce((acc, s) => acc + s.items.length, 0);
  const checkedCount = Object.values(checkedItems).filter(Boolean).length;
  const progressPct = totalItems > 0 ? Math.round((checkedCount / totalItems) * 100) : 0;

  const handleLeadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLeadFormStatus('submitting');
    try {
      const params = new URLSearchParams();
      params.append('name', leadData.name);
      params.append('email', leadData.email);
      params.append('company', leadData.company);
      params.append('source', 'GBP Optimization Checklist Lead Magnet');
      params.append('access_key', WEB3FORMS_ACCESS_KEY);
      await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: params,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      setLeadFormStatus('success');
    } catch {
      setLeadFormStatus('success');
    }
  };

  const toggleSection = (title: string) => {
    setExpandedSection((prev) => (prev === title ? null : title));
  };

  return (
    <div className="min-h-screen bg-white">
      <PageSEO
        title="Google Business Profile Optimization Checklist | Roofing Local SEO"
        description="The complete Google Business Profile optimization checklist for roofing companies. 56 actionable items covering photos, reviews, Q&A, posts, citations, and analytics. Boost your local rankings in Evansville and beyond."
        keywords="Google Business Profile optimization, GBP checklist, local SEO roofing, Google My Business roofing, roofing company local SEO, Evansville roofing SEO, roofing contractor marketing"
        canonical="/google-business-profile-optimization"
        schema={gbpSchema}
      />

      {/* ── Hero ── */}
      <section className="relative min-h-[480px] md:min-h-[580px] flex items-center overflow-hidden bg-charcoal-deep">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-orange/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 left-1/4 w-64 h-64 bg-orange/5 rounded-full blur-3xl" />
        </div>
        <div className="relative z-10 w-full px-6 md:px-10 lg:px-16 pt-24 md:pt-28">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 bg-orange/15 border border-orange/25 text-orange px-4 py-1.5 text-xs font-semibold uppercase tracking-wider mb-6">
              <i className="ri-google-fill" />
              Local SEO Guide
            </div>
            <h1 className="font-display text-3xl md:text-5xl lg:text-6xl text-white uppercase tracking-wide leading-tight mb-6">
              Google Business Profile<br />
              <span className="text-orange">Optimization Checklist</span>
            </h1>
            <p className="text-white/70 text-base md:text-lg leading-relaxed max-w-2xl mb-8">
              The #1 local SEO driver for roofing companies. 56 actionable items across 7 categories — from profile setup to review generation to post strategy. Use this checklist to dominate "roofing company near me" searches in Evansville and every city you serve.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="#checklist"
                className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-8 py-3.5 transition-colors duration-200 text-center uppercase tracking-wide whitespace-nowrap"
              >
                Start the Checklist
              </a>
              <button
                type="button"
                onClick={() => setShowLeadForm(true)}
                className="border border-white/25 hover:border-white/50 text-white text-sm font-semibold px-8 py-3.5 transition-colors duration-200 text-center uppercase tracking-wide whitespace-nowrap flex items-center justify-center gap-2 cursor-pointer"
              >
                <i className="ri-download-line" />
                Download as PDF
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ── Why GBP Matters ── */}
      <section className="py-16 md:py-24 bg-white border-b border-stone-100">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <div>
              <span className="text-orange text-xs font-semibold uppercase tracking-widest">Why This Matters</span>
              <h2 className="font-display text-2xl md:text-4xl text-charcoal uppercase tracking-wide mt-3 mb-6">
                GBP Is the #1 Local SEO Ranking Signal
              </h2>
              <p className="text-stone-500 text-sm md:text-base leading-relaxed mb-6">
                When someone in Evansville searches "roofing company near me" or "roof repair Evansville," Google does not show them a random website. It shows them the 3 best Google Business Profiles in the Local Pack — the map results that appear above every organic result.
              </p>
              <p className="text-stone-500 text-sm md:text-base leading-relaxed mb-8">
                46% of all Google searches have local intent. For service businesses like roofing, that number is even higher. If your GBP is not optimized, you are invisible to the exact people who need you most — right when they are actively looking to hire.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {stats.map((stat) => (
                  <div key={stat.label} className="bg-stone-50 border border-stone-100 p-4 md:p-5">
                    <div className="w-8 h-8 mb-3 flex items-center justify-center text-orange">
                      <i className={`${stat.icon} text-xl`} />
                    </div>
                    <p className="font-display text-2xl text-charcoal mb-1">{stat.value}</p>
                    <p className="text-stone-500 text-xs leading-snug">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <img
                src="/placeholders/700x500.svg"
                alt="Google Local Pack showing roofing company search results"
                className="w-full h-[360px] md:h-[480px] object-cover object-top"
              />
              <div className="absolute bottom-6 left-6 right-6 bg-white p-4 border-l-4 border-orange">
                <p className="text-charcoal text-sm font-medium">
                  Businesses in the top 3 Local Pack positions get <strong className="text-orange">70% of all local search clicks</strong>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Progress Bar ── */}
      <section id="checklist" className="bg-stone-50 border-b border-stone-100 py-8 md:py-10 sticky top-0 z-40">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="max-w-5xl mx-auto">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 flex items-center justify-center bg-orange/10 text-orange">
                  <i className="ri-task-line text-lg" />
                </div>
                <div>
                  <p className="text-charcoal text-sm font-semibold uppercase tracking-wide">Your Checklist Progress</p>
                  <p className="text-stone-500 text-xs">{checkedCount} of {totalItems} items completed</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-display text-2xl text-charcoal">{progressPct}%</p>
                <p className="text-stone-400 text-xs">complete</p>
              </div>
            </div>
            <div className="w-full bg-stone-200 h-3">
              <div
                className="bg-orange h-3 transition-all duration-500"
                style={{ width: `${progressPct}%` }}
              />
            </div>
            {progressPct === 100 && (
              <p className="text-green-600 text-xs font-semibold mt-2 flex items-center gap-1">
                <i className="ri-check-double-line" /> All done! Your GBP is fully optimized.
              </p>
            )}
          </div>
        </div>
      </section>

      {/* ── Interactive Checklist ── */}
      <section className="py-10 md:py-16 bg-white">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-12">
              <span className="text-orange text-xs font-semibold uppercase tracking-widest">The Checklist</span>
              <h2 className="font-display text-2xl md:text-4xl text-charcoal uppercase tracking-wide mt-3">
                56 Items to Optimize Your GBP
              </h2>
              <p className="text-stone-500 mt-3 max-w-xl mx-auto text-sm md:text-base">
                Click each item to mark it complete. Use the section headers to expand or collapse categories.
              </p>
            </div>

            <div className="space-y-4">
              {checklistSections.map((section) => {
                const sectionChecked = section.items.filter((item) => checkedItems[item.id]).length;
                const sectionTotal = section.items.length;
                const sectionPct = Math.round((sectionChecked / sectionTotal) * 100);
                const isExpanded = expandedSection === section.title;

                return (
                  <div
                    key={section.title}
                    className={`border transition-colors duration-200 ${isExpanded ? 'border-orange/30' : 'border-stone-200 hover:border-stone-300'}`}
                  >
                    {/* Section header */}
                    <button
                      type="button"
                      onClick={() => toggleSection(section.title)}
                      className="w-full flex items-center gap-4 p-5 md:p-6 text-left cursor-pointer group"
                    >
                      <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center bg-orange/10 text-orange">
                        <i className={`${section.icon} text-lg`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-1">
                          <h3 className="font-display text-base md:text-lg text-charcoal uppercase tracking-wide">{section.title}</h3>
                          <span className="text-stone-400 text-xs font-semibold">
                            {sectionChecked}/{sectionTotal}
                          </span>
                        </div>
                        <div className="w-full bg-stone-100 h-1.5 max-w-[200px]">
                          <div
                            className="bg-orange h-1.5 transition-all duration-300"
                            style={{ width: `${sectionPct}%` }}
                          />
                        </div>
                      </div>
                      <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center border border-stone-200 text-stone-400 group-hover:text-orange group-hover:border-orange/30 transition-colors">
                        <i className={`${isExpanded ? 'ri-subtract-line' : 'ri-add-line'} text-sm`} />
                      </div>
                    </button>

                    {/* Section items */}
                    {isExpanded && (
                      <div className="border-t border-stone-100 p-5 md:p-6 pt-4 space-y-3">
                        {section.items.map((item) => {
                          const checked = !!checkedItems[item.id];
                          return (
                            <button
                              key={item.id}
                              type="button"
                              onClick={() => toggleCheck(item.id)}
                              className="w-full flex items-start gap-3.5 text-left group cursor-pointer"
                            >
                              <div
                                className={`w-5 h-5 flex-shrink-0 flex items-center justify-center border mt-0.5 transition-colors ${
                                  checked
                                    ? 'bg-orange border-orange text-white'
                                    : 'border-stone-300 bg-white text-transparent group-hover:border-orange/50'
                                }`}
                              >
                                <i className="ri-check-line text-xs" />
                              </div>
                              <div className="flex-1">
                                <span
                                  className={`text-sm leading-relaxed transition-colors block ${
                                    checked ? 'text-stone-400 line-through' : 'text-stone-700 group-hover:text-charcoal'
                                  }`}
                                >
                                  {item.label}
                                </span>
                                {item.description && (
                                  <span
                                    className={`text-xs leading-relaxed mt-1 block transition-colors ${
                                      checked ? 'text-stone-300' : 'text-stone-400'
                                    }`}
                                  >
                                    {item.description}
                                  </span>
                                )}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* ── GBP Post Ideas ── */}
      <section className="py-16 md:py-24 bg-stone-50">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="text-center mb-14">
            <span className="text-orange text-xs font-semibold uppercase tracking-widest">Content Strategy</span>
            <h2 className="font-display text-2xl md:text-4xl text-charcoal uppercase tracking-wide mt-3">
              6 GBP Post Templates That Work
            </h2>
            <p className="text-stone-500 mt-3 max-w-xl mx-auto text-sm md:text-base">
              Copy these templates and adapt them for your roofing business. Each one includes a proven CTA.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {postIdeas.map((idea) => (
              <div key={idea.title} className="bg-white border border-stone-200 p-6 group hover:border-orange/30 transition-colors">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-9 h-9 flex items-center justify-center bg-orange/10 text-orange">
                    <i className={`${idea.icon} text-lg`} />
                  </div>
                  <h3 className="font-display text-sm text-charcoal uppercase tracking-wide">{idea.title}</h3>
                </div>
                <p className="text-stone-500 text-sm leading-relaxed mb-4 italic">"{idea.example}"</p>
                <div className="flex items-center justify-between">
                  <span className="text-orange text-xs font-semibold uppercase tracking-wide">CTA: {idea.cta}</span>
                  <span className="text-stone-300 text-xs"><i className="ri-time-line mr-1" />7-day lifespan</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── NAP Consistency Warning ── */}
      <section className="py-16 md:py-20 bg-charcoal-deep">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6 mb-8">
              <div className="w-14 h-14 flex-shrink-0 flex items-center justify-center bg-red-500/15 text-red-500">
                <i className="ri-error-warning-line text-2xl" />
              </div>
              <div>
                <h2 className="font-display text-xl md:text-2xl text-white uppercase tracking-wide mb-2">
                  The #1 Mistake That Kills Local Rankings
                </h2>
                <p className="text-white/60 text-sm md:text-base leading-relaxed">
                  Inconsistent NAP (Name, Address, Phone) across the web is the silent killer of local SEO. If your GBP says "Corner Stone Construction" but Yelp says "Cornerstone Construction & Roofing LLC" and Angi has your old phone number — Google gets confused and drops you from the Local Pack.
                </p>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 p-6 md:p-8">
              <h3 className="text-white text-sm font-semibold uppercase tracking-wide mb-4">NAP Audit — Check These 15 Sources</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                {[
                  'Google Business Profile',
                  'Your Website Footer',
                  'Facebook Business Page',
                  'Yelp',
                  'BBB',
                  'Angi (Angie\'s List)',
                  'HomeAdvisor',
                  'Thumbtack',
                  'Porch',
                  'Houzz',
                  'Yellow Pages',
                  'Manta',
                  'Chamber of Commerce',
                  'Nextdoor',
                  'LinkedIn Company Page',
                ].map((source) => (
                  <div key={source} className="flex items-center gap-2 text-white/60 text-xs">
                    <i className="ri-checkbox-blank-circle-line text-orange text-[10px]" />
                    {source}
                  </div>
                ))}
              </div>
              <p className="text-white/40 text-xs mt-5 leading-relaxed">
                <i className="ri-information-line mr-1" />
                Even small differences matter: "St" vs "Street", "Suite 100" vs "Ste 100", "(812) 213-5997" vs "812-213-5997" vs "812.213.5997". Pick one format and use it everywhere.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-16 md:py-24 bg-white">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <span className="text-orange text-xs font-semibold uppercase tracking-widest">Common Questions</span>
              <h2 className="font-display text-2xl md:text-4xl text-charcoal uppercase tracking-wide mt-3">
                GBP Optimization FAQs
              </h2>
            </div>
            <div className="space-y-4">
              {[
                {
                  q: 'How long does Google Business Profile optimization take to show results?',
                  a: 'Most roofing contractors see ranking improvements within 2–4 weeks of completing GBP optimization. Review velocity, photo freshness, and post frequency compound over time — peak results typically show after 3–6 months of consistent activity.',
                },
                {
                  q: 'Can a roofing company have multiple Google Business Profiles for different cities?',
                  a: 'No — Google prohibits duplicate profiles for the same business. Instead, use service-area settings to list all the cities you serve without a physical address in each one. Create dedicated city pages on your website and link them from your main GBP.',
                },
                {
                  q: 'How many photos should a roofing company upload to GBP per month?',
                  a: 'Upload a minimum of 10–15 photos per month. Mix project photos, team photos, material close-ups, and customer-facing content. Businesses that post photos weekly get 42% more requests for directions and 35% more website clicks than those that do not.',
                },
                {
                  q: 'What is the best way to get Google reviews for a roofing company?',
                  a: 'Ask immediately after project completion while satisfaction is highest. Send a text message with a direct review link (not an email — open rates for review SMS are 3x higher). Make it effortless: one tap, no login required. Never offer incentives — it violates Google policy and can get reviews removed.',
                },
                {
                  q: 'Should I hire someone to manage my GBP, or do it myself?',
                  a: 'If you have 2–3 hours per week, you can manage it yourself using this checklist. If you are too busy running jobs, hire a local SEO specialist or marketing agency. Expect to pay $300–$800/month for full GBP management including posts, review responses, and photo uploads.',
                },
              ].map((faq, i) => (
                <details key={i} className="group bg-stone-50 border border-stone-200 open:border-orange/30 transition-colors">
                  <summary className="flex items-center justify-between p-5 cursor-pointer list-none">
                    <span className="font-display text-sm text-charcoal uppercase tracking-wide pr-4">{faq.q}</span>
                    <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center bg-white border border-stone-200 text-stone-400 group-open:text-orange group-open:border-orange/30 transition-colors">
                      <i className="ri-add-line group-open:hidden" />
                      <i className="ri-subtract-line hidden group-open:block" />
                    </div>
                  </summary>
                  <div className="px-5 pb-5 text-stone-500 text-sm leading-relaxed">
                    {faq.a}
                  </div>
                </details>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── Lead Magnet / CTA ── */}
      <section className="py-16 md:py-24 bg-stone-50">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-start">
              {/* Left: Value prop */}
              <div>
                <span className="text-orange text-xs font-semibold uppercase tracking-widest">Free Download</span>
                <h2 className="font-display text-2xl md:text-4xl text-charcoal uppercase tracking-wide mt-3 mb-4">
                  Download the Complete GBP Checklist
                </h2>
                <p className="text-stone-500 text-sm md:text-base leading-relaxed mb-6">
                  Get a printable PDF version of this checklist with space for notes, a monthly tracking sheet, and a NAP audit template. Perfect for sharing with your team or reviewing during monthly marketing meetings.
                </p>
                <div className="space-y-3 mb-6">
                  {[
                    { icon: 'ri-file-list-3-line', text: '56-item checklist with checkboxes' },
                    { icon: 'ri-calendar-line', text: 'Monthly KPI tracking sheet' },
                    { icon: 'ri-search-line', text: 'NAP consistency audit template' },
                    { icon: 'ri-lightbulb-line', text: '12 GBP post idea templates' },
                  ].map((item) => (
                    <div key={item.text} className="flex items-center gap-3 text-stone-600 text-sm">
                      <i className={`${item.icon} text-orange text-sm`} />
                      {item.text}
                    </div>
                  ))}
                </div>
                <p className="text-stone-400 text-xs">
                  <i className="ri-lock-line mr-1" />
                  No spam. We email you the checklist and occasionally share local SEO tips. Unsubscribe anytime.
                </p>
              </div>

              {/* Right: Form */}
              <div>
                {leadFormStatus === 'success' ? (
                  <div className="bg-white border border-stone-200 p-8 md:p-10 text-center">
                    <div className="w-16 h-16 mx-auto mb-5 flex items-center justify-center bg-green-50 text-green-600">
                      <i className="ri-check-double-line text-3xl" />
                    </div>
                    <h3 className="font-display text-xl text-charcoal uppercase tracking-wide mb-3">Checklist Sent!</h3>
                    <p className="text-stone-500 text-sm leading-relaxed">
                      Check your inbox at <strong className="text-charcoal">{leadData.email}</strong> for the download link. If you do not see it within 5 minutes, check your spam folder.
                    </p>
                  </div>
                ) : (
                  <div className="bg-white border border-stone-200 p-6 md:p-8">
                    <h3 className="font-display text-lg text-charcoal uppercase tracking-wide mb-2">Get Instant Access</h3>
                    <p className="text-stone-500 text-sm mb-6">Enter your details below and we will email you the checklist immediately.</p>
                    <form onSubmit={handleLeadSubmit} className="space-y-4">
                      <div>
                        <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Your Name *</label>
                        <input
                          type="text"
                          required
                          value={leadData.name}
                          onChange={(e) => setLeadData((prev) => ({ ...prev, name: e.target.value }))}
                          className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                          placeholder="John Smith"
                        />
                      </div>
                      <div>
                        <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Email Address *</label>
                        <input
                          type="email"
                          required
                          value={leadData.email}
                          onChange={(e) => setLeadData((prev) => ({ ...prev, email: e.target.value }))}
                          className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                          placeholder="john@email.com"
                        />
                      </div>
                      <div>
                        <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Company Name</label>
                        <input
                          type="text"
                          value={leadData.company}
                          onChange={(e) => setLeadData((prev) => ({ ...prev, company: e.target.value }))}
                          className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                          placeholder="Acme Roofing LLC"
                        />
                      </div>
                      <button
                        type="submit"
                        disabled={leadFormStatus === 'submitting'}
                        className="w-full bg-orange hover:bg-orange-dark disabled:bg-stone-300 text-white text-sm font-semibold px-8 py-4 transition-colors duration-200 uppercase tracking-wide whitespace-nowrap flex items-center justify-center gap-2 cursor-pointer"
                      >
                        {leadFormStatus === 'submitting' ? (
                          <><i className="ri-loader-4-line animate-spin" /> Sending...</>
                        ) : (
                          <><i className="ri-download-line" /> Download Free Checklist</>
                        )}
                      </button>
                    </form>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Corner Stone CTA ── */}
      <section className="py-16 md:py-20 bg-charcoal-deep">
        <div className="w-full px-6 md:px-10 lg:px-16">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-orange/15 border border-orange/25 text-orange px-4 py-1.5 text-xs font-semibold uppercase tracking-wider mb-6">
              <i className="ri-building-4-line" />
              Evansville Roofing Experts
            </div>
            <h2 className="font-display text-2xl md:text-4xl text-white uppercase tracking-wide mb-4">
              We Do the Roofing. You Focus on Your GBP.
            </h2>
            <p className="text-white/60 text-sm md:text-base max-w-2xl mx-auto mb-8 leading-relaxed">
              Corner Stone Construction & Roofing has dominated local search in Evansville, Newburgh, and the Tri-State area for years. If you are a homeowner looking for the best roofer in town — or a fellow contractor who wants to learn from someone who has figured it out — we are here to help.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/free-inspection"
                onClick={(e) => { e.preventDefault(); navigate('/free-inspection'); }}
                className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-8 py-3.5 transition-colors duration-200 text-center uppercase tracking-wide whitespace-nowrap"
              >
                Schedule Free Roof Inspection
              </a>
              <a
                href="tel:8122135997"
                className="border border-white/25 hover:border-white/50 text-white text-sm font-semibold px-8 py-3.5 transition-colors duration-200 text-center uppercase tracking-wide whitespace-nowrap flex items-center justify-center gap-2"
              >
                <i className="ri-phone-line" />
                Call 812-213-5997
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ── Lead Form Modal ── */}
      {showLeadForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60" onClick={() => setShowLeadForm(false)}>
          <div className="bg-white w-full max-w-md p-6 md:p-8" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-display text-lg text-charcoal uppercase tracking-wide">Download PDF Checklist</h3>
              <button
                type="button"
                onClick={() => setShowLeadForm(false)}
                className="w-8 h-8 flex items-center justify-center text-stone-400 hover:text-charcoal transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-lg" />
              </button>
            </div>
            {leadFormStatus === 'success' ? (
              <div className="text-center py-6">
                <div className="w-14 h-14 mx-auto mb-4 flex items-center justify-center bg-green-50 text-green-600">
                  <i className="ri-check-double-line text-2xl" />
                </div>
                <p className="text-charcoal text-sm font-semibold mb-2">Checklist sent to your email!</p>
                <p className="text-stone-500 text-xs">Check your inbox (and spam folder) for the download link.</p>
              </div>
            ) : (
              <form onSubmit={handleLeadSubmit} className="space-y-4">
                <div>
                  <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Your Name *</label>
                  <input
                    type="text"
                    required
                    value={leadData.name}
                    onChange={(e) => setLeadData((prev) => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                    placeholder="John Smith"
                  />
                </div>
                <div>
                  <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={leadData.email}
                    onChange={(e) => setLeadData((prev) => ({ ...prev, email: e.target.value }))}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                    placeholder="john@email.com"
                  />
                </div>
                <div>
                  <label className="block text-charcoal text-xs font-semibold uppercase tracking-wide mb-2">Company Name</label>
                  <input
                    type="text"
                    value={leadData.company}
                    onChange={(e) => setLeadData((prev) => ({ ...prev, company: e.target.value }))}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-200 text-charcoal text-sm focus:outline-none focus:border-orange transition-colors"
                    placeholder="Acme Roofing LLC"
                  />
                </div>
                <button
                  type="submit"
                  disabled={leadFormStatus === 'submitting'}
                  className="w-full bg-orange hover:bg-orange-dark disabled:bg-stone-300 text-white text-sm font-semibold px-8 py-4 transition-colors duration-200 uppercase tracking-wide whitespace-nowrap flex items-center justify-center gap-2 cursor-pointer"
                >
                  {leadFormStatus === 'submitting' ? (
                    <><i className="ri-loader-4-line animate-spin" /> Sending...</>
                  ) : (
                    <><i className="ri-download-line" /> Send Me the PDF</>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}