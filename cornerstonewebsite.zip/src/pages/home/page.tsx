import HeroSection from '@/components/feature/HeroSection';
import SocialProofTicker from '@/components/feature/SocialProofTicker';
import TrustSignals from '@/components/feature/TrustSignals';
import ServicesSection from '@/components/feature/ServicesSection';
import InteractiveToolsPromo from '@/components/feature/InteractiveToolsPromo';
import WhyNumberOne from '@/components/feature/WhyNumberOne';
import HowItWorks from '@/components/feature/HowItWorks';
import RoofCostEstimator from '@/components/feature/RoofCostEstimator';
import LeadMagnetSection from '@/components/feature/LeadMagnetSection';
import AIRoofInspector from '@/components/feature/AIRoofInspector';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import AsphaltRoofingSection from '@/components/feature/AsphaltRoofingSection';
import MetalRoofingSection from '@/components/feature/MetalRoofingSection';
import AboutSection from '@/components/feature/AboutSection';
import ProjectsSection from '@/components/feature/ProjectsSection';
import BeforeAfterGallery from '@/components/feature/BeforeAfterGallery';
import TestimonialsSection from '@/components/feature/TestimonialsSection';
import VideoTestimonialsSection from '@/components/feature/VideoTestimonialsSection';
import InspectionCTASection from '@/components/feature/InspectionCTASection';
import BlogSection from '@/components/feature/BlogSection';
import FAQSection from '@/components/feature/FAQSection';
import RemoteEstimateSection from '@/components/feature/RemoteEstimateSection';
import AdjusterSection from '@/components/feature/AdjusterSection';
import FinancingSection from '@/components/feature/FinancingSection';
import ContactSection from '@/components/feature/ContactSection';
import PageSEO from '@/components/feature/PageSEO';
import GoogleReviewsWidget from '@/components/feature/GoogleReviewsWidget';
import DealExpiringSoon from '@/pages/promotions/components/DealExpiringSoon';
import { OFFERS } from '@/mocks/promotions';
import { trackToolUsage } from '@/lib/toolAnalytics';

const homeSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: [
    {
      '@type': 'Question',
      name: 'How much does a roof replacement cost in Evansville Indiana?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'The average cost of a new roof in Evansville ranges from $8,000 to $25,000 depending on home size, roofing material, and complexity. Corner Stone offers free estimates with no obligation.',
      },
    },
    {
      '@type': 'Question',
      name: 'Do you offer free roof inspections in Evansville?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Yes — Corner Stone Construction & Roofing offers 100% free roof inspections with no obligation. We serve Evansville, Newburgh, Henderson KY, and the entire Tri-State area.',
      },
    },
    {
      '@type': 'Question',
      name: 'Do you help with insurance claims for storm damage?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Yes. We are insurance claim specialists. We document damage, meet your adjuster on-site, and handle all paperwork so you get the full payout your policy covers.',
      },
    },
  ],
};

export default function Home() {
  return (
    <div className="min-h-screen">
      <PageSEO
        title="Evansville Indiana Roofing Contractor | Corner Stone Construction & Roofing"
        description="Evansville's most trusted roofing contractor since 1995. Free roof inspections, residential & commercial roofing, storm damage restoration, and insurance claims in Evansville IN, Newburgh, Henderson KY & the Tri-State area. Call 812-213-5997."
        keywords="Evansville roofing contractor, roof replacement Evansville IN, free roof inspection Evansville, storm damage roofing Indiana, insurance claim roofing Evansville, residential roofing Evansville, commercial roofing Indiana"
        canonical="/"
        schema={homeSchema}
      />
      <HeroSection />
      <TalkToAIExpert />
      <AIRoofInspector onAnalysisComplete={() => trackToolUsage('ai-inspector', 'AI Roof Inspector')} />
      <SocialProofTicker />
      <TrustSignals />
      <ServicesSection />
      <InteractiveToolsPromo />
      <WhyNumberOne />
      <HowItWorks />
      <RoofCostEstimator onResultShown={() => trackToolUsage('roof-estimator', 'Roof Cost Estimator')} />
      <LeadMagnetSection />
      <AsphaltRoofingSection />
      <MetalRoofingSection />
      <AboutSection />
      <ProjectsSection />
      <BeforeAfterGallery />
      <FinancingSection />
      <TestimonialsSection />
      <VideoTestimonialsSection />
      <InspectionCTASection />
      <GoogleReviewsWidget />
      <BlogSection />
      <FAQSection />
      <RemoteEstimateSection />
      <AdjusterSection />
      <ContactSection />

      <DealExpiringSoon offers={OFFERS} linkToPage="/promotions" />
    </div>
  );
}