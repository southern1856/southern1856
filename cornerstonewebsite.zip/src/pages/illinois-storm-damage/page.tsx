import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { OFFERS } from '@/mocks/promotions';

const nearestExpiry = OFFERS
  .filter((o) => o.expires)
  .map((o) => o.expires!)
  .sort()[0] || '2026-12-31';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'WebPage',
  name: 'Illinois Storm Damage Roofing | Tri-State Storm Repair',
  description: 'Illinois storm damage roofing repair across southeastern Illinois. Expert hail, wind, and tornado damage roof repair. Insurance claims assistance. Licensed IL contractor serving Mount Carmel, Carmi, Lawrenceville, Olney, Fairfield.',
  url: 'https://cornerstoneconstructionevansville.com/illinois-storm-damage',
};

const faqSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: [
    {
      '@type': 'Question',
      name: 'Does Illinois get enough hail to damage roofs?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Yes — southeastern Illinois averages 2-3 significant hail events per year, with wind-driven hail causing widespread roof damage across counties like Wabash, Lawrence, Richland, and Wayne.',
      },
    },
    {
      '@type': 'Question',
      name: 'How do Illinois insurance claims differ from Indiana for storm damage?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Illinois insurance regulations require insurers to provide a detailed damage assessment within 15 days of a claim filing. We are experienced with Illinois-specific claim procedures and meet adjusters on-site to ensure complete damage documentation.',
      },
    },
  ],
};

export default function IllinoisStormDamagePage() {
  const navigate = useNavigate();
  const hero = useScrollAnimation();
  const damage = useScrollAnimation();
  const process = useScrollAnimation();
  const cta = useScrollAnimation();

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Illinois Storm Damage Roofing | Hail, Wind & Tornado Repair | Corner Stone"
        description="Illinois storm damage roofing repair. Hail, wind, and tornado roof damage experts serving southeastern Illinois. Insurance claims assistance. Licensed IL contractor. Fast emergency response. Call 812-213-5997."
        keywords="Illinois storm damage roofing, Illinois hail damage roof repair, Illinois wind damage roofing, tornado roof damage Illinois, storm damage repair southeastern Illinois, Mount Carmel storm roof repair"
        canonical="/illinois-storm-damage"
        schema={[schema, faqSchema]}
      />

      {/* Hero */}
      <section className="relative min-h-[65vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1400x900.svg"
            alt="Illinois storm damage roofing"
            className="w-full h-full object-cover object-top opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/70 via-charcoal-deep/50 to-charcoal-deep" />
        </div>

        <div
          ref={hero.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 pt-24 pb-16 anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-wrap items-center gap-3 mb-8">
            <span className="border border-orange/40 bg-orange/10 text-orange text-xs font-semibold px-4 py-2 uppercase tracking-widest">24/7 Emergency Response</span>
            <span className="border border-white/15 bg-white/5 text-white/60 text-xs font-semibold px-4 py-2 uppercase tracking-widest">Licensed in Illinois</span>
          </div>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 7vw, 6.5rem)' }}>
            Illinois Storm<br />Damage?<br /><span className="text-orange">We're On It.</span>
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-2xl leading-relaxed mb-8">
            Southeastern Illinois gets hit hard — spring thunderstorms, hail swaths across Wabash and Lawrence counties, and tornado-warned cells that shred roofing. Our crews are 24/7 ready for emergency response across Illinois. Tarping within hours, full repair within days.
          </p>

          <div className="flex justify-start mb-5">
            <CountdownTimer expiresAt={nearestExpiry} variant="banner" />
          </div>

          <div className="flex justify-start mb-6">
            <SocialProofPulse />
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <a href="tel:8122135997" className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2">
              <i className="ri-phone-line" />
              Emergency: 812-213-5997
            </a>
            <button onClick={() => navigate('/insurance-claims')} className="border border-white/30 hover:border-orange text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap cursor-pointer flex items-center gap-2">
              <i className="ri-file-text-line text-orange" />
              Insurance Claims Help
            </button>
          </div>
        </div>
      </section>

      {/* Illinois Weather Reality */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Weather Reality</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
            Why Illinois Roofs<br /><span className="text-orange">Take a Beating.</span>
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Southeastern Illinois sits in a storm corridor that produces some of the most roof-damaging weather in the Tri-State region.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            {
              icon: 'ri-thunderstorms-line',
              title: 'Spring Hail Swaths',
              desc: 'Southeastern Illinois — from Wabash County to Wayne County — averages 2 to 3 hail events per year with stones large enough to compromise shingle integrity. Hail damage is not always visible from the ground — it bruises the shingle mat, shortening roof life by years.',
            },
            {
              icon: 'ri-windy-line',
              title: 'Straight-Line Winds',
              desc: 'Derecho events and severe thunderstorm downbursts can produce 70 to 90 mph wind gusts that lift shingles, tear off flashing, and leave homes exposed. Illinois\u2019s flat terrain offers no natural windbreaks, so roofs absorb the full force.',
            },
            {
              icon: 'ri-tornado-line',
              title: 'Tornado Alley Overlap',
              desc: 'Southeastern Illinois overlaps with the western edge of the Midwest tornado belt. Even near-misses from tornado-warned storms can cause debris impact damage, lifted shingle edges, and compromised roof decking.',
            },
            {
              icon: 'ri-contrast-drop-2-line',
              title: 'River Valley Humidity',
              desc: 'The Wabash and Embarras river valleys create persistent humidity that accelerates moss and algae growth on north-facing roof slopes. Over time, trapped moisture degrades shingles and invites leaks.',
            },
            {
              icon: 'ri-snowy-line',
              title: 'Freeze-Thaw Cycling',
              desc: 'Illinois winters produce repeated freeze-thaw cycles that expand and contract tiny cracks in shingles. By spring, those hairline cracks are entry points for water — and Illinois spring brings plenty of rain to find them.',
            },
            {
              icon: 'ri-flashlight-line',
              title: 'Hidden Damage',
              desc: 'Post-storm roof damage is often invisible from the ground. The real damage — bruised shingle mats, lifted seals, nail pops, cracked flashing — requires a professional on-roof inspection to identify. Delaying that inspection is the costliest mistake Illinois homeowners make.',
            },
          ].map((item, i) => (
            <div key={item.title} className="border border-white/10 bg-charcoal-mid p-8 hover:border-orange/30 transition-all duration-300 group">
              <div className="w-12 h-12 flex items-center justify-center bg-orange/15 group-hover:bg-orange/25 transition-colors mb-5">
                <i className={`${item.icon} text-orange text-xl`} />
              </div>
              <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">{item.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Damage Types Visual */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div ref={damage.ref as React.RefObject<HTMLDivElement>} className={`anim-fade-up ${damage.isVisible ? 'is-visible' : ''}`}>
          <div className="text-center mb-14">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">What to Look For</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              Storm Damage Signs<br /><span className="text-orange">After Any Illinois Storm.</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              { icon: 'ri-close-circle-line', title: 'Missing or Lifted Shingles', desc: 'Even a few lifted shingles expose the underlayment and decking to water. Wind catches the lifted edge and peels more shingles with each storm. This is the most common storm damage we see in Illinois.' },
              { icon: 'ri-contrast-drop-line', title: 'Granule Loss', desc: 'Hail impact knocks protective granules off shingles. Check your gutters and downspouts for granule accumulation. Bare asphalt patches on shingles mean accelerated UV degradation and reduced remaining life.' },
              { icon: 'ri-indeterminate-circle-line', title: 'Bruised Shingle Mats', desc: 'Hail can bruise the fiberglass mat beneath the asphalt layer without leaving visible surface marks. A bruised shingle loses its structural integrity and will fail prematurely. This requires a professional inspection to identify.' },
              { icon: 'ri-brackets-line', title: 'Damaged Flashing', desc: 'High winds can bend or tear metal flashing around chimneys, vents, and valleys. Damaged flashing is the #1 source of non-obvious leaks that slowly rot roof decking from underneath.' },
              { icon: 'ri-window-2-line', title: 'Ceiling Stains Inside', desc: 'If you see water stains on ceilings or walls after a storm, you have active leaks. Do not wait — water continues migrating through insulation and drywall, expanding the damage zone every hour.' },
              { icon: 'ri-dashboard-line', title: 'Dented Gutters &amp; Downspouts', desc: 'Dented or dimpled metal gutters are a telltale sign of hail impact. If gutters look like a golf ball, your roof shingles almost certainly took the same beating — even if they look fine from the ground.' },
            ].map((item) => (
              <div key={item.title} className="flex items-start gap-5 p-6 border border-white/10 bg-charcoal-mid">
                <div className="w-10 h-10 flex items-center justify-center bg-orange/15 flex-shrink-0 mt-1">
                  <i className={`${item.icon} text-orange text-lg`} />
                </div>
                <div>
                  <h3 className="font-display text-white text-lg uppercase tracking-wider mb-2">{item.title}</h3>
                  <p className="text-white/50 text-sm leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Illinois Insurance Claims */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Insurance Claims</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Illinois Insurance<br />Claims — We<br /><span className="text-orange">Handle It All.</span>
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-6">
              Filing a storm damage claim in Illinois has its own rules and timelines. Illinois insurers must provide a detailed damage assessment within 15 days of claim filing. We know the Illinois insurance landscape and will be on-site when your adjuster arrives to make sure nothing gets missed.
            </p>
            <div className="space-y-4 mb-8">
              {[
                { icon: 'ri-camera-line', text: 'Full storm damage documentation with photos and measurements' },
                { icon: 'ri-team-line', text: 'We meet your adjuster on-site — no solo adjuster walkthroughs' },
                { icon: 'ri-file-list-3-line', text: 'Complete claim paperwork handled at no extra cost' },
                { icon: 'ri-shield-check-line', text: 'We verify the adjuster\u2019s scope matches actual damage — and fight supplements if needed' },
              ].map((item) => (
                <div key={item.text} className="flex items-start gap-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-orange/20 text-orange flex-shrink-0 mt-0.5">
                    <i className={`${item.icon} text-sm`} />
                  </div>
                  <p className="text-white/60 text-sm leading-relaxed">{item.text}</p>
                </div>
              ))}
            </div>
            <button onClick={() => navigate('/insurance-claims')} className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors cursor-pointer whitespace-nowrap inline-flex items-center gap-2">
              <i className="ri-file-text-line" />
              Learn About Claims Process
            </button>
          </div>

          <div ref={process.ref as React.RefObject<HTMLDivElement>} className={`anim-fade-up ${process.isVisible ? 'is-visible' : ''}`}>
            <div className="w-full overflow-hidden" style={{ height: '460px' }}>
              <img
                src="/placeholders/700x460.svg"
                alt="Professional Illinois roof storm damage inspection"
                className="w-full h-full object-cover object-top"
              />
            </div>
            <div className="bg-charcoal-mid border border-white/10 p-5 mt-4">
              <p className="text-white/50 text-xs leading-relaxed italic">
                "Illinois insurance adjusters appreciate working with contractors who document everything. Our inspection reports include timestamped photos, hail-impact mapping, and wind-damage notation on every roof face. Nothing gets overlooked."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* IL Counties We Cover for Storm */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-12">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Storm Response Coverage</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Illinois Counties<br /><span className="text-orange">We Cover.</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            { county: 'Wabash County', city: 'Mount Carmel', route: '/locations/mount-carmel-il' },
            { county: 'Edwards County', city: 'Grayville', route: '/locations/grayville-il' },
            { county: 'White County', city: 'Carmi', route: '/locations/carmi-il' },
            { county: 'Lawrence County', city: 'Lawrenceville', route: '/locations/lawrenceville-il' },
            { county: 'Richland County', city: 'Olney', route: '/locations/olney-il' },
            { county: 'Wayne County', city: 'Fairfield', route: '/locations/fairfield-il' },
          ].map((item) => (
            <button
              key={item.county}
              onClick={() => navigate(item.route)}
              className="border border-white/10 bg-charcoal-mid p-5 text-left hover:border-orange/40 transition-all cursor-pointer group"
            >
              <p className="font-display text-white text-lg uppercase tracking-wider group-hover:text-orange transition-colors">{item.county}</p>
              <p className="text-white/40 text-sm mt-1">County Seat: {item.city}</p>
              <div className="flex items-center gap-2 mt-3">
                <span className="text-orange text-xs flex items-center gap-1">
                  <i className="ri-map-pin-line text-xs" />
                  View Storm Coverage
                </span>
                <i className="ri-arrow-right-line text-orange text-xs" />
              </div>
            </button>
          ))}
        </div>

        <div className="mt-8 p-6 border border-orange/20 bg-orange/5 text-center">
          <div className="flex items-center justify-center gap-3 mb-2">
            <i className="ri-alarm-warning-line text-orange text-xl" />
            <p className="text-white font-semibold text-sm uppercase tracking-wider">Active Storm? Call Now.</p>
          </div>
          <p className="text-white/40 text-sm mb-3">Emergency tarping and board-up available 24/7 across all Illinois counties.</p>
          <a href="tel:8122135997" className="inline-flex items-center gap-2 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-3 uppercase tracking-widest text-sm transition-colors whitespace-nowrap">
            <i className="ri-phone-fill" />
            812-213-5997
          </a>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16">
        <div ref={cta.ref as React.RefObject<HTMLDivElement>} className={`anim-fade-up border border-white/10 bg-charcoal-mid p-10 md:p-14 text-center ${cta.isVisible ? 'is-visible' : ''}`}>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Storm Just Passed?<br /><span className="text-orange">Get Inspected.</span>
          </h2>
          <p className="text-white/40 text-sm max-w-lg mx-auto leading-relaxed mb-8">
            Free post-storm roof inspections across all six Illinois counties we serve. We will identify every bit of damage, document it for your insurance, and tarp anything that needs immediate protection. No obligation, no pressure.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="tel:8122135997" className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2">
              <i className="ri-phone-fill" />
              Call 812-213-5997
            </a>
            <button onClick={() => navigate('/illinois-roofing-license-guide')} className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all cursor-pointer whitespace-nowrap flex items-center gap-2">
              <i className="ri-shield-check-line text-orange" />
              Illinois License Guide
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}