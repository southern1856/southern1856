import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import TalkToAIExpert from '@/components/feature/TalkToAIExpert';
import RelatedServicesStrip from '@/components/feature/RelatedServicesStrip';
import ServiceProcessStrip from '@/components/feature/ServiceProcessStrip';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { OFFERS } from '@/mocks/promotions';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const nearestExpiry = OFFERS
  .filter((o) => o.expires)
  .map((o) => o.expires!)
  .sort()[0] || '2026-12-31';

const commercialSchema = {
  '@context': 'https://schema.org',
  '@type': 'Service',
  name: 'Commercial Roofing Evansville Indiana',
  provider: {
    '@type': 'RoofingContractor',
    name: 'Corner Stone Construction & Roofing',
    telephone: '+1-812-213-5997',
    address: {
      '@type': 'PostalAddress',
      streetAddress: '5800 Kansas Rd',
      addressLocality: 'Evansville',
      addressRegion: 'IN',
      postalCode: '47725',
    },
  },
  areaServed: ['Evansville IN', 'Henderson KY', 'Newburgh IN', 'Owensboro KY', 'Tri-State Area'],
  description: 'Commercial roofing contractor serving Evansville Indiana and Henderson KY. TPO, EPDM, metal roofing, flat roofs, and preventive maintenance for offices, warehouses, retail, and industrial facilities.',
  hasOfferCatalog: {
    '@type': 'OfferCatalog',
    name: 'Commercial Roofing Services',
    itemListElement: [
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'TPO Roofing' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'EPDM Roofing' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Metal Roofing' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Roof Coatings' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Service', name: 'Preventive Maintenance' } },
    ],
  },
};

const SYSTEMS = [
  {
    id: 'tpo',
    name: 'TPO Roofing',
    full: 'Thermoplastic Polyolefin',
    icon: 'ri-building-2-line',
    badge: 'Most Popular',
    badgeColor: 'bg-orange text-white',
    lifespan: '20–30 Years',
    bestFor: 'Offices, Retail, Warehouses',
    desc: 'The #1 choice for commercial flat roofs. TPO membranes are heat-welded at the seams for a watertight bond, highly reflective to reduce cooling costs, and resistant to UV, ozone, and chemical exposure.',
    features: ['Energy Star Reflective', 'Heat-Welded Seams', 'Puncture Resistant', 'Low Maintenance', 'Recyclable Material', 'Fast Installation'],
    image: '/placeholders/800x500.svg',
  },
  {
    id: 'epdm',
    name: 'EPDM Roofing',
    full: 'Ethylene Propylene Diene Monomer',
    icon: 'ri-building-3-line',
    badge: 'Best Durability',
    badgeColor: 'bg-white/10 text-white',
    lifespan: '25–35 Years',
    bestFor: 'Industrial, Large Facilities',
    desc: 'The rubber roofing standard for industrial and large commercial buildings. EPDM handles extreme temperature swings — perfect for Indiana winters and summers — and is proven to last 30+ years with minimal maintenance.',
    features: ['Extreme Temp Resistance', 'Proven 30+ Year Track Record', 'Flexible in Cold Weather', 'Low Life-Cycle Cost', 'Easy to Repair', 'Excellent Waterproofing'],
    image: '/placeholders/800x500.svg',
  },
  {
    id: 'metal',
    name: 'Standing Seam Metal',
    full: 'Concealed Fastener Metal Roofing',
    icon: 'ri-home-gear-line',
    badge: 'Longest Lifespan',
    badgeColor: 'bg-white/10 text-white',
    lifespan: '40–60 Years',
    bestFor: 'Manufacturing, Agriculture, Premium Commercial',
    desc: 'The premium choice for commercial and industrial buildings that want a roof they will never replace again. Standing seam metal handles Indiana hail, wind, and snow loads with zero penetrations through the roof surface.',
    features: ['50+ Year Lifespan', 'No Exposed Fasteners', 'Hail & Wind Resistant', 'Fire Rated Class A', 'Energy Efficient', 'Minimal Maintenance'],
    image: '/placeholders/800x500.svg',
  },
  {
    id: 'coating',
    name: 'Roof Coatings',
    full: 'Silicone & Acrylic Restoration',
    icon: 'ri-paint-brush-line',
    badge: 'Best Value',
    badgeColor: 'bg-white/10 text-white',
    lifespan: '10–15 Year Extension',
    bestFor: 'Existing Roofs in Good Condition',
    desc: 'Extend your existing roof\'s life by 10–15 years at a fraction of replacement cost. Silicone and acrylic coatings seal minor cracks, reflect UV rays, and restore waterproofing — often qualifying for tax incentives as a maintenance expense.',
    features: ['Fraction of Replacement Cost', 'No Tear-Off Required', 'Tax Deductible (Maintenance)', 'Reflective — Reduces Cooling', 'Applied Over Existing Roof', 'Minimal Business Disruption'],
    image: '/placeholders/800x500.svg',
  },
];

const INDUSTRIES = [
  { icon: 'ri-store-2-line', name: 'Retail & Strip Malls' },
  { icon: 'ri-building-4-line', name: 'Office Buildings' },
  { icon: 'ri-truck-line', name: 'Warehouses & Distribution' },
  { icon: 'ri-hospital-line', name: 'Medical Facilities' },
  { icon: 'ri-restaurant-line', name: 'Restaurants & Food Service' },
  { icon: 'ri-school-line', name: 'Schools & Churches' },
  { icon: 'ri-building-line', name: 'Manufacturing & Industrial' },
  { icon: 'ri-home-office-line', name: 'Multi-Family / Apartments' },
];

const ADVANTAGES = [
  {
    icon: 'ri-calendar-check-line',
    title: 'Work Around Your Schedule',
    desc: 'Night shifts, weekends, phased installations — we minimize disruption to your operations and tenants.',
  },
  {
    icon: 'ri-file-list-3-line',
    title: 'Full Documentation Package',
    desc: 'Detailed scope of work, material specs, warranty certificates, and as-built drawings for your records.',
  },
  {
    icon: 'ri-shield-check-line',
    title: 'Fully Bonded & Insured',
    desc: 'Commercial-grade liability coverage, workers comp, and bonding. We meet all requirements for property managers and REITs.',
  },
  {
    icon: 'ri-tools-line',
    title: 'Preventive Maintenance Plans',
    desc: 'Annual inspection and maintenance programs that extend roof life and protect your warranty — starting at $299/year.',
  },
  {
    icon: 'ri-award-line',
    title: 'Manufacturer Certified',
    desc: 'Certified installer for GAF, Carlisle, Firestone, and Versico — unlocking NDL (No Dollar Limit) warranties.',
  },
  {
    icon: 'ri-map-pin-line',
    title: 'Serving IN & KY',
    desc: 'Fully licensed in both Indiana and Kentucky. One contractor for all your Tri-State commercial properties.',
  },
];

const FAQS = [
  {
    q: 'How long does a commercial roof replacement take?',
    a: 'Most commercial projects take 3–14 days depending on building size, system type, and weather. We provide a detailed project schedule before work begins and work around your business hours to minimize disruption.',
  },
  {
    q: 'What is the best roofing system for a flat commercial roof in Indiana?',
    a: 'TPO is our most popular recommendation for Indiana commercial buildings — it handles temperature extremes well, is highly reflective (reducing cooling costs), and offers excellent value. For industrial facilities, EPDM or standing seam metal may be better suited.',
  },
  {
    q: 'Do you offer preventive maintenance contracts for commercial properties?',
    a: 'Yes. We offer annual maintenance plans starting at $299/year that include bi-annual inspections, minor repairs, drain clearing, and a detailed condition report. Preventive maintenance is the single best way to extend roof life and protect your warranty.',
  },
  {
    q: 'Can you handle multiple properties across the Tri-State area?',
    a: 'Absolutely. We are fully licensed in both Indiana and Kentucky and regularly manage multi-property portfolios for property management companies and REITs across the Tri-State area.',
  },
  {
    q: 'Do you provide NDL (No Dollar Limit) warranties?',
    a: 'Yes. As a certified installer for major manufacturers including GAF, Carlisle, and Firestone, we can offer NDL warranties that cover both materials and labor with no dollar cap — the gold standard for commercial roofing.',
  },
  {
    q: 'How do I know if my commercial roof needs replacement vs. repair?',
    a: 'Our free commercial inspection will tell you exactly. Generally, if a roof is under 15 years old with isolated damage, repair or coating is the right call. If it is older with widespread issues, replacement is more cost-effective long-term. We give you an honest assessment — not just the most expensive option.',
  },
];

export default function CommercialRoofingPage() {
  const navigate = useNavigate();
  const [activeSystem, setActiveSystem] = useState(SYSTEMS[0]);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [charCount, setCharCount] = useState(0);
  const formRef = useRef<HTMLFormElement>(null);

  const hero = useScrollAnimation();
  const systems = useScrollAnimation({ threshold: 0.05 });
  const industries = useScrollAnimation({ threshold: 0.1 });
  const process = useScrollAnimation({ threshold: 0.1 });
  const advantages = useScrollAnimation({ threshold: 0.1 });
  const faqAnim = useScrollAnimation({ threshold: 0.1 });
  const formAnim = useScrollAnimation({ threshold: 0.1 });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;
    const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
    const notes = formData.get('notes') as string;
    if (notes && notes.length > 500) return;
    setFormStatus('submitting');
    try {
      const res = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      if (res.ok) { setFormStatus('success'); formRef.current.reset(); setCharCount(0); }
      else setFormStatus('error');
    } catch { setFormStatus('error'); }
  };

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Commercial Roofing Evansville Indiana | TPO, EPDM, Metal | Corner Stone"
        description="Commercial roofing contractor serving Evansville IN and Henderson KY. TPO, EPDM, standing seam metal, roof coatings, and preventive maintenance for offices, warehouses, retail, and industrial facilities. Licensed in IN & KY. Call 812-213-5997."
        keywords="commercial roofing Evansville Indiana, commercial roofer Henderson KY, TPO roofing Evansville, EPDM roofing Indiana, flat roof contractor Evansville, commercial roof replacement Indiana, property manager roofing Tri-State"
        canonical="/commercial-roofing"
        schema={commercialSchema}
      />

      {/* ── Hero ── */}
      <section className="relative min-h-screen flex flex-col overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1400x900.svg"
            alt="Commercial roofing contractor Evansville Indiana"
            className="w-full h-full object-cover object-top opacity-35"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/60 via-charcoal-deep/40 to-charcoal-deep" />
          <div className="absolute inset-0 opacity-[0.025]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '80px 80px' }} />
        </div>

        <div
          ref={hero.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 flex-1 flex flex-col justify-center px-6 md:px-10 lg:px-16 pt-32 md:pt-36 pb-16 anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-wrap items-center gap-3 mb-8">
            <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange" />
              Licensed in Indiana &amp; Kentucky
            </div>
            <div className="flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
              <span className="w-1.5 h-1.5 rounded-full bg-orange" />
              Up to 100,000 sq ft
            </div>
            <div className="flex items-center gap-2 border border-orange/40 bg-orange/10 backdrop-blur-sm px-4 py-2 text-orange text-xs uppercase tracking-widest">
              <i className="ri-award-line text-sm" />
              NDL Warranty Available
            </div>
          </div>

          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 9vw, 10rem)' }}>
            Commercial<br />Roofing<br /><span className="text-orange">Done Right.</span>
          </h1>

          <div className="mb-8">
            <CountdownTimer expiresAt={nearestExpiry} variant="banner" />
            <div className="mt-3">
              <SocialProofPulse />
            </div>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-end gap-8 lg:gap-16">
            <p className="text-white/50 text-base md:text-lg max-w-xl leading-relaxed">
              Evansville and Henderson KY's trusted commercial roofing contractor. We protect offices, warehouses, retail centers, and industrial facilities — with zero business disruption and manufacturer-backed warranties.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 flex-shrink-0">
              <button
                onClick={() => document.getElementById('comm-form')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <i className="ri-file-list-3-line" />
                Get Commercial Quote
              </button>
              <a
                href="tel:8122135997"
                className="border border-white/30 hover:border-orange text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-phone-line text-orange" />
                812-213-5997
              </a>
            </div>
          </div>
        </div>

        {/* Bottom stats */}
        <div className="relative z-10 border-t border-white/10 grid grid-cols-2 md:grid-cols-4">
          {[
            { val: '500+', label: 'Commercial Projects' },
            { val: '100K', label: 'Max Sq Ft Capacity' },
            { val: '2', label: 'States Licensed' },
            { val: 'NDL', label: 'Warranty Available' },
          ].map((s, i) => (
            <div key={s.label} className={`px-6 md:px-10 py-6 md:py-8 ${i < 3 ? 'border-r border-white/10' : ''}`}>
              <p className="font-display text-white text-3xl md:text-4xl tracking-wider">{s.val}</p>
              <p className="text-white/40 text-xs uppercase tracking-widest mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      <TalkToAIExpert />

      {/* ── Industries We Serve ── */}
      <section className="bg-charcoal border-y border-white/10 py-10 px-6 md:px-10 lg:px-16">
        <div
          ref={industries.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${industries.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-white/30 text-xs uppercase tracking-widest mb-6 text-center">Industries We Serve</p>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-4">
            {INDUSTRIES.map((ind, i) => (
              <div
                key={ind.name}
                className={`flex flex-col items-center gap-2 text-center anim-fade-up ${industries.isVisible ? 'is-visible' : ''}`}
                style={{ transitionDelay: `${i * 60}ms` }}
              >
                <div className="w-12 h-12 flex items-center justify-center border border-white/10 bg-white/5 hover:border-orange/40 hover:bg-orange/10 transition-all duration-200">
                  <i className={`${ind.icon} text-white/50 text-lg`} />
                </div>
                <p className="text-white/40 text-xs leading-tight">{ind.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Roofing Systems ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14 md:mb-18">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Roofing Systems</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
            The Right System<br />For Your Building
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            We install all major commercial roofing systems and help you choose the best fit for your building type, budget, and long-term goals.
          </p>
        </div>

        <div
          ref={systems.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 lg:grid-cols-5 gap-6"
        >
          {/* System selector */}
          <div className="lg:col-span-2 flex flex-col gap-3">
            {SYSTEMS.map((sys, i) => (
              <button
                key={sys.id}
                onClick={() => setActiveSystem(sys)}
                className={`text-left border p-5 transition-all duration-300 cursor-pointer group anim-fade-up ${systems.isVisible ? 'is-visible' : ''} ${activeSystem.id === sys.id ? 'border-orange bg-orange/10' : 'border-white/10 bg-charcoal-mid hover:border-white/30'}`}
                style={{ transitionDelay: `${i * 80}ms` }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-xs font-bold px-2 py-0.5 uppercase tracking-wider ${sys.badgeColor}`}>{sys.badge}</span>
                  <span className="text-white/30 text-xs">{sys.lifespan}</span>
                </div>
                <h3 className={`font-display text-xl uppercase tracking-wider transition-colors ${activeSystem.id === sys.id ? 'text-orange' : 'text-white group-hover:text-orange'}`}>
                  {sys.name}
                </h3>
                <p className="text-white/30 text-xs mt-1">{sys.full}</p>
                <p className="text-white/40 text-xs mt-2">
                  <i className="ri-building-line mr-1 text-orange" />
                  {sys.bestFor}
                </p>
              </button>
            ))}
          </div>

          {/* System detail */}
          <div className="lg:col-span-3 flex flex-col gap-4">
            <div className="relative w-full overflow-hidden" style={{ height: '300px' }}>
              <img
                key={activeSystem.id}
                src={activeSystem.image}
                alt={activeSystem.name}
                className="w-full h-full object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-deep/80 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="flex items-center gap-3">
                  <span className={`text-xs font-bold px-3 py-1 uppercase tracking-wider ${activeSystem.badgeColor}`}>{activeSystem.badge}</span>
                  <span className="text-white/50 text-xs">{activeSystem.lifespan} lifespan</span>
                </div>
                <h3 className="font-display text-white text-3xl uppercase tracking-wider mt-2">{activeSystem.name}</h3>
              </div>
            </div>

            <div className="border border-white/10 bg-charcoal-mid p-6 md:p-8 flex-1">
              <p className="text-white/60 text-sm leading-relaxed mb-6">{activeSystem.desc}</p>
              <div className="grid grid-cols-2 gap-2 mb-6">
                {activeSystem.features.map((f) => (
                  <div key={f} className="flex items-center gap-2 text-white/50 text-xs">
                    <i className="ri-check-line text-orange text-sm" />
                    {f}
                  </div>
                ))}
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => document.getElementById('comm-form')?.scrollIntoView({ behavior: 'smooth' })}
                  className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-6 py-3 uppercase tracking-wide transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                >
                  Get {activeSystem.name} Quote
                  <i className="ri-arrow-right-line" />
                </button>
                <a
                  href="tel:8122135997"
                  className="border border-white/20 hover:border-orange text-white/70 hover:text-white text-sm font-semibold px-6 py-3 uppercase tracking-wide transition-all whitespace-nowrap flex items-center justify-center gap-2"
                >
                  <i className="ri-phone-line text-orange" />
                  Call Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Why Corner Stone for Commercial ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-14">
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Why Choose Us</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Built for Property<br />Managers &amp; Owners
          </h2>
        </div>

        <div
          ref={advantages.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {ADVANTAGES.map((adv, i) => (
            <div
              key={adv.title}
              className={`border border-white/10 bg-charcoal-mid p-8 hover:border-orange/30 transition-all duration-300 group anim-fade-up ${advantages.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="w-12 h-12 flex items-center justify-center bg-orange/15 group-hover:bg-orange/25 transition-colors mb-5">
                <i className={`${adv.icon} text-orange text-xl`} />
              </div>
              <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">{adv.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{adv.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Maintenance Plans ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Protect Your Investment</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              Commercial Roof<br />Maintenance Plans
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
              A commercial roof is a major capital investment. Our preventive maintenance programs protect that investment, extend roof life by 5–10 years, and keep your warranty valid — all for a fraction of replacement cost.
            </p>
            <div className="space-y-4 mb-8">
              {[
                { plan: 'Basic Plan', price: '$299/yr', features: 'Annual inspection + report + minor repairs' },
                { plan: 'Standard Plan', price: '$599/yr', features: 'Bi-annual inspections + drain clearing + sealant touch-ups' },
                { plan: 'Premium Plan', price: '$999/yr', features: 'Quarterly visits + priority emergency response + full documentation' },
              ].map((p) => (
                <div key={p.plan} className="flex items-center justify-between border border-white/10 bg-charcoal-mid px-6 py-4 hover:border-orange/30 transition-colors">
                  <div>
                    <p className="text-white font-semibold text-sm">{p.plan}</p>
                    <p className="text-white/40 text-xs mt-0.5">{p.features}</p>
                  </div>
                  <span className="font-display text-orange text-xl tracking-wider flex-shrink-0 ml-4">{p.price}</span>
                </div>
              ))}
            </div>
            <button
              onClick={() => document.getElementById('comm-form')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors cursor-pointer flex items-center gap-2 whitespace-nowrap"
            >
              Get Maintenance Quote
              <i className="ri-arrow-right-line" />
            </button>
          </div>

          <div className="relative">
            <div className="w-full overflow-hidden" style={{ height: '460px' }}>
              <img
                src="/placeholders/700x460.svg"
                alt="Commercial roof maintenance inspection Evansville Indiana"
                className="w-full h-full object-cover object-top"
              />
            </div>
            <div className="absolute bottom-6 left-6 right-6 bg-charcoal-deep/90 border border-white/10 p-5">
              <div className="flex items-center gap-3 mb-2">
                <i className="ri-shield-check-line text-orange text-xl" />
                <p className="text-white font-semibold text-sm">Warranty Protection Included</p>
              </div>
              <p className="text-white/40 text-xs leading-relaxed">
                Regular maintenance keeps your manufacturer warranty valid. Skipping inspections can void coverage — don't risk it.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ── Process ── */}
      <ServiceProcessStrip
        heading="How It Works"
        subheading="Your Commercial Project\nFrom Assessment to Done"
        steps={[
          { num: '01', icon: 'ri-search-eye-line', title: 'On-Site Assessment', desc: 'We conduct a thorough roof inspection using core sampling, thermal imaging, and moisture detection. You get a detailed condition report with photos.', detail: 'Free for properties up to 50K sq ft' },
          { num: '02', icon: 'ri-file-list-3-line', title: 'Detailed Proposal', desc: 'We deliver a written proposal with system recommendations, material specs, project timeline, and warranty options. We meet with you to review every detail.', detail: 'NDL warranty options included' },
          { num: '03', icon: 'ri-tools-line', title: 'Scheduled Installation', desc: 'We work nights, weekends, or in phases to minimize disruption. Our crews are OSHA-compliant and trained in your specific roofing system.', detail: 'Zero business disruption options' },
          { num: '04', icon: 'ri-award-line', title: 'Final Inspection & Warranty', desc: 'We conduct a final walkthrough with you, deliver as-built drawings, and register your manufacturer warranty. Your roof is fully protected.', detail: 'Full documentation package' },
        ]}
        ctaText="Ready to protect your building? Get your commercial quote today."
        ctaSubtext="Free assessment · Detailed proposal · No obligation · Tri-State area"
        buttonText="Get Commercial Quote"
        buttonHref="#comm-form"
      />

      {/* ── Service Area Map ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Commercial Coverage</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Serving Evansville,<br />Henderson &amp; Beyond
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-6">
              We are the Tri-State's most experienced commercial roofing contractor. Fully licensed in Indiana and Kentucky, we handle commercial projects from Evansville to Owensboro, Henderson to Jasper.
            </p>
            <div className="space-y-3 mb-8">
              {[
                { city: 'Evansville, IN', note: 'Primary Market — Headquarters' },
                { city: 'Henderson, KY', note: 'Primary KY Market' },
                { city: 'Newburgh, IN', note: 'Warrick County' },
                { city: 'Owensboro, KY', note: 'Daviess County' },
                { city: 'Boonville, IN', note: 'Warrick County' },
                { city: 'Mount Vernon, IN', note: 'Posey County' },
              ].map((loc) => (
                <div key={loc.city} className="flex items-center justify-between py-2 border-b border-white/5">
                  <div className="flex items-center gap-3">
                    <i className="ri-map-pin-2-line text-orange text-sm" />
                    <span className="text-white text-sm font-medium">{loc.city}</span>
                  </div>
                  <span className="text-white/30 text-xs">{loc.note}</span>
                </div>
              ))}
            </div>
            <button
              onClick={() => navigate('/service-areas')}
              className="border border-white/20 hover:border-orange text-white/70 hover:text-white text-sm font-semibold px-8 py-3.5 uppercase tracking-widest transition-all cursor-pointer flex items-center gap-2 whitespace-nowrap"
            >
              <i className="ri-map-2-line text-orange" />
              View Full Service Area
            </button>
          </div>

          <div className="w-full overflow-hidden border border-white/10" style={{ height: '420px' }}>
            <iframe
              title="Corner Stone Commercial Roofing Service Area"
              src="https://www.google.com/maps/embed/v1/place?key=AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY&q=Evansville,+Indiana&zoom=9"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Common Questions</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Commercial Roofing FAQ
            </h2>
          </div>
          <div
            ref={faqAnim.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${faqAnim.isVisible ? 'is-visible' : ''}`}
          >
            {FAQS.map((faq, i) => (
              <div key={i} className="border-b border-white/10">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between py-5 text-left cursor-pointer group"
                >
                  <span className="font-display text-white text-lg uppercase tracking-wider pr-4 group-hover:text-orange transition-colors">{faq.q}</span>
                  <div className={`w-8 h-8 flex items-center justify-center border flex-shrink-0 transition-all duration-300 ${openFaq === i ? 'bg-orange border-orange text-white' : 'border-white/20 text-white/40 group-hover:border-orange group-hover:text-orange'}`}>
                    <i className={`ri-${openFaq === i ? 'subtract' : 'add'}-line`} />
                  </div>
                </button>
                <div className={`overflow-hidden transition-all duration-500 ${openFaq === i ? 'max-h-48 opacity-100 pb-5' : 'max-h-0 opacity-0'}`}>
                  <p className="text-white/50 text-sm leading-relaxed pr-12">{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Quote Form ── */}
      <section id="comm-form" className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div
          ref={formAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${formAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {/* Left copy */}
            <div>
              <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">Get a Quote</p>
              <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 5vw, 5rem)' }}>
                Let's Talk<br />About Your<br /><span className="text-orange">Building.</span>
              </h2>
              <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
                Fill out the form and our commercial roofing specialist will contact you within 4 business hours. We'll schedule a free on-site assessment and provide a detailed proposal.
              </p>
              <div className="space-y-4">
                {[
                  { icon: 'ri-timer-line', text: 'Response within 4 business hours' },
                  { icon: 'ri-search-eye-line', text: 'Free on-site commercial assessment' },
                  { icon: 'ri-file-list-3-line', text: 'Detailed written proposal with options' },
                  { icon: 'ri-shield-check-line', text: 'No obligation, no pressure' },
                ].map((item) => (
                  <div key={item.text} className="flex items-center gap-3 text-white/50 text-sm">
                    <i className={`${item.icon} text-orange text-base`} />
                    {item.text}
                  </div>
                ))}
              </div>
              <div className="mt-8 pt-8 border-t border-white/10">
                <p className="text-white/30 text-xs uppercase tracking-widest mb-3">Or call us directly</p>
                <a href="tel:8122135997" className="flex items-center gap-3 text-white hover:text-orange transition-colors">
                  <i className="ri-phone-fill text-orange text-xl" />
                  <span className="font-display text-2xl tracking-wider">812-213-5997</span>
                </a>
              </div>
            </div>

            {/* Right form */}
            <div className="bg-white rounded-2xl overflow-hidden">
              <div className="bg-charcoal-deep px-8 py-6 border-b border-white/10">
                <h3 className="font-display text-white text-2xl uppercase tracking-wider">Commercial Quote Request</h3>
                <p className="text-white/50 text-sm mt-1">For offices, warehouses, retail &amp; industrial</p>
              </div>

              {formStatus === 'success' ? (
                <div className="px-8 py-14 flex flex-col items-center text-center">
                  <div className="w-16 h-16 flex items-center justify-center bg-green-100 rounded-full mb-4">
                    <i className="ri-checkbox-circle-fill text-green-600 text-3xl" />
                  </div>
                  <h4 className="font-display text-charcoal text-2xl uppercase tracking-wider mb-2">Request Received!</h4>
                  <p className="text-gray-500 text-sm leading-relaxed max-w-xs">
                    Our commercial roofing specialist will contact you within 4 business hours to schedule your free assessment.
                  </p>
                  <button onClick={() => setFormStatus('idle')} className="mt-6 text-orange text-sm font-semibold underline underline-offset-4 cursor-pointer">
                    Submit another request
                  </button>
                </div>
              ) : (
                <form
                  ref={formRef}
                  data-readdy-form
                  onSubmit={handleSubmit}
                  className="px-8 py-7 space-y-4"
                >
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Contact Name</label>
                      <input type="text" name="name" required placeholder="John Smith" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Phone</label>
                      <input type="tel" name="phone" required placeholder="812-000-0000" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Email</label>
                    <input type="email" name="email" required placeholder="you@company.com" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Company / Property Name</label>
                    <input type="text" name="company" placeholder="ABC Properties LLC" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Property Address</label>
                    <input type="text" name="address" required placeholder="123 Commerce Dr, Evansville, IN" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Building Type</label>
                      <select name="building_type" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                        <option value="">Select type</option>
                        <option value="office">Office Building</option>
                        <option value="warehouse">Warehouse / Distribution</option>
                        <option value="retail">Retail / Strip Mall</option>
                        <option value="industrial">Industrial / Manufacturing</option>
                        <option value="medical">Medical Facility</option>
                        <option value="restaurant">Restaurant / Food Service</option>
                        <option value="multifamily">Multi-Family / Apartments</option>
                        <option value="church">Church / School</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Approx. Sq Footage</label>
                      <select name="sq_footage" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                        <option value="">Select range</option>
                        <option value="under5k">Under 5,000 sq ft</option>
                        <option value="5k-15k">5,000 – 15,000 sq ft</option>
                        <option value="15k-30k">15,000 – 30,000 sq ft</option>
                        <option value="30k-60k">30,000 – 60,000 sq ft</option>
                        <option value="60k-100k">60,000 – 100,000 sq ft</option>
                        <option value="over100k">Over 100,000 sq ft</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">Service Needed</label>
                    <select name="service_needed" className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 appearance-none cursor-pointer">
                      <option value="">Select service</option>
                      <option value="replacement">Full Roof Replacement</option>
                      <option value="repair">Roof Repair</option>
                      <option value="coating">Roof Coating / Restoration</option>
                      <option value="inspection">Inspection / Assessment</option>
                      <option value="maintenance">Maintenance Plan</option>
                      <option value="emergency">Emergency Repair</option>
                      <option value="unsure">Not Sure — Need Assessment</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-1.5">
                      Additional Details <span className="text-gray-400 font-normal normal-case">(optional)</span>
                    </label>
                    <textarea
                      name="notes"
                      rows={3}
                      maxLength={500}
                      onChange={(e) => setCharCount(e.target.value.length)}
                      placeholder="Current roof condition, timeline, special requirements..."
                      className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 resize-none"
                    />
                    <p className={`text-xs mt-1 text-right ${charCount > 500 ? 'text-red-500' : 'text-gray-400'}`}>{charCount}/500</p>
                  </div>
                  <button
                    type="submit"
                    disabled={formStatus === 'submitting'}
                    className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-300 text-white font-bold text-sm uppercase tracking-widest py-4 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  >
                    {formStatus === 'submitting' ? (
                      <><i className="ri-loader-4-line animate-spin" />Sending...</>
                    ) : (
                      <><i className="ri-send-plane-line" />Submit Commercial Quote Request</>
                    )}
                  </button>
                  {formStatus === 'error' && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2">
                      <i className="ri-alert-line text-red-500" />
                      <p className="text-red-600 text-xs">Something went wrong. Please call 812-213-5997 directly.</p>
                    </div>
                  )}
                  <p className="text-gray-400 text-xs text-center">
                    <i className="ri-lock-line mr-1" />Your information is private and secure.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ── You Might Also Need ── */}
      <RelatedServicesStrip
        heading="You Might Also Need"
        subheading="Protect your commercial property from every angle — we handle it all."
        services={[
          {
            icon: 'ri-thunderstorms-line',
            label: 'Storm Damage Response',
            description: '24/7 emergency response for storm-damaged commercial roofs. We tarp, inspect, and handle your insurance claim.',
            href: '/storm-damage',
            badge: '24/7 Emergency',
          },
          {
            icon: 'ri-calendar-check-line',
            label: 'Maintenance Plans',
            description: 'Annual and bi-annual maintenance programs starting at $299/yr. Extend roof life and keep your warranty valid.',
            href: '/maintenance-plans',
            highlight: true,
            badge: 'From $299/yr',
          },
          {
            icon: 'ri-money-dollar-circle-line',
            label: 'Roof Financing',
            description: 'Flexible financing options for commercial roof replacements. Preserve capital while protecting your building.',
            href: '/roof-financing',
          },
          {
            icon: 'ri-home-smile-line',
            label: 'Residential Roofing',
            description: 'Need roofing for a residential property too? We handle homes across the entire Tri-State area.',
            href: '/residential-roofing',
          },
        ]}
      />
    </div>
  );
}
