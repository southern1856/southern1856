import { useState, useRef } from 'react';
import PageSEO from '@/components/feature/PageSEO';

interface ChecklistItem {
  id: string;
  category: 'website' | 'gbp';
  label: string;
  description: string;
  points: number;
}

const checklistItems: ChecklistItem[] = [
  // WEBSITE SECTION
  {
    id: 'w1',
    category: 'website',
    label: 'Title tag includes city + service keywords',
    description: 'Every page title should read like "Roofing Contractor Evansville IN | Company Name" — not just your brand name.',
    points: 3,
  },
  {
    id: 'w2',
    category: 'website',
    label: 'One H1 per page with a target keyword',
    description: 'Each page has exactly one H1 heading that includes a local keyword. No H1s that say "Welcome" or "Home."',
    points: 3,
  },
  {
    id: 'w3',
    category: 'website',
    label: 'NAP (Name, Address, Phone) match exactly on every page',
    description: 'Your business name, address, and phone appear in the footer and match your GBP exactly — down to "St" vs "Street."',
    points: 3,
  },
  {
    id: 'w4',
    category: 'website',
    label: 'Schema.org LocalBusiness markup is present',
    description: 'Structured data tells Google you are a local business. Check with Google Rich Results Test.',
    points: 3,
  },
  {
    id: 'w5',
    category: 'website',
    label: 'Dedicated service area / city landing pages',
    description: 'You have individual pages targeting nearby towns, not just one "Areas We Serve" list.',
    points: 3,
  },
  {
    id: 'w6',
    category: 'website',
    label: 'HTTPS enabled and working correctly',
    description: 'Your site loads with the lock icon. Mixed content warnings break trust with Google and users.',
    points: 2,
  },
  {
    id: 'w7',
    category: 'website',
    label: 'Mobile-friendly design — no horizontal scrolling',
    description: 'Test on your actual phone. Tap targets must be thumb-sized. Text must be readable without pinching.',
    points: 3,
  },
  {
    id: 'w8',
    category: 'website',
    label: 'Page load speed under 3 seconds on mobile',
    description: 'Use Google PageSpeed Insights. Slow sites rank lower and visitors leave before they call.',
    points: 2,
  },
  {
    id: 'w9',
    category: 'website',
    label: 'All images have descriptive alt text with keywords',
    description: 'Not "IMG_2345.jpg" — use "architectural-shingle-replacement-evansville.jpg" with alt="GAF Timberline roof replacement in Evansville."',
    points: 2,
  },
  {
    id: 'w10',
    category: 'website',
    label: 'XML sitemap submitted to Google Search Console',
    description: 'You have a sitemap.xml file and it is registered in GSC. Check the Coverage report for errors.',
    points: 2,
  },
  {
    id: 'w11',
    category: 'website',
    label: 'robots.txt allows indexing of key pages',
    description: 'Make sure you are not accidentally blocking Google from crawling your service pages or blog.',
    points: 1,
  },
  {
    id: 'w12',
    category: 'website',
    label: 'Blog with at least 6 posts targeting local keywords',
    description: 'Articles like "How much does a roof cost in Evansville?" attract the exact homeowners you want.',
    points: 3,
  },
  {
    id: 'w13',
    category: 'website',
    label: 'Internal links connect related pages',
    description: 'Your blog posts link to service pages. Your service pages link to estimates. No orphaned pages.',
    points: 2,
  },
  {
    id: 'w14',
    category: 'website',
    label: 'Clickable phone number on every page (tel: link)',
    description: 'Mobile users tap-to-call. Make the number big, visible, and clickable within 1 second of landing.',
    points: 2,
  },
  {
    id: 'w15',
    category: 'website',
    label: 'Google Maps embed on contact / about page',
    description: 'Embedding your verified GBP location reinforces local signals to Google and helps visitors find you.',
    points: 2,
  },
  {
    id: 'w16',
    category: 'website',
    label: 'Before/after project gallery with location tags',
    description: 'Real job photos with city names in captions and file names. This is content Google can not fake.',
    points: 2,
  },
  {
    id: 'w17',
    category: 'website',
    label: 'Customer testimonials with schema markup',
    description: 'Reviews on your site wrapped in Review schema so Google may show star ratings in search results.',
    points: 2,
  },
  {
    id: 'w18',
    category: 'website',
    label: 'Unique meta description on every page',
    description: 'Every page has a 150-160 character description that includes a CTA and local keywords.',
    points: 2,
  },
  {
    id: 'w19',
    category: 'website',
    label: 'URL structure is clean and keyword-rich',
    description: 'Use /roof-replacement-evansville/ not /page?id=234. Hyphens between words, all lowercase.',
    points: 2,
  },
  {
    id: 'w20',
    category: 'website',
    label: 'No broken links or 404 errors',
    description: 'Run a broken link checker. Dead links signal a neglected site to both Google and visitors.',
    points: 1,
  },

  // GBP SECTION
  {
    id: 'g1',
    category: 'gbp',
    label: 'Business name matches your real-world signage',
    description: 'Do not stuff keywords into your name. "Corner Stone Construction" is fine. "Corner Stone #1 Roofing Contractor Evansville" will get suspended.',
    points: 3,
  },
  {
    id: 'g2',
    category: 'gbp',
    label: 'Primary category is "Roofing Contractor"',
    description: 'This is the single most important ranking factor. Do not use "Construction Company" as your primary.',
    points: 3,
  },
  {
    id: 'g3',
    category: 'gbp',
    label: 'At least 5 additional relevant categories selected',
    description: 'Add Gutter Installation, Siding Contractor, Storm Damage Restoration, Commercial Roofing, etc.',
    points: 2,
  },
  {
    id: 'g4',
    category: 'gbp',
    label: 'Service area covers all towns you actually work in',
    description: 'List every city and county you serve. Do not rely on a single "50-mile radius" — be specific.',
    points: 2,
  },
  {
    id: 'g5',
    category: 'gbp',
    label: 'Hours are accurate and include emergency availability',
    description: 'If you answer emergency calls after hours, note it. Update for holidays and storm seasons.',
    points: 2,
  },
  {
    id: 'g6',
    category: 'gbp',
    label: 'Description is 750 characters with keywords naturally woven in',
    description: 'Write for humans first, keywords second. Mention your service areas, specialties, and years in business.',
    points: 2,
  },
  {
    id: 'g7',
    category: 'gbp',
    label: 'Website link points to your homepage (not a social profile)',
    description: 'The URL field should go to your domain root. Use UTM parameters if you want to track GBP traffic.',
    points: 2,
  },
  {
    id: 'g8',
    category: 'gbp',
    label: 'At least 20 high-quality photos uploaded',
    description: 'Team photos, job site shots, before/afters, office interior, branded vehicles. Geotag them before uploading.',
    points: 3,
  },
  {
    id: 'g9',
    category: 'gbp',
    label: 'Photos added within the last 30 days',
    description: 'Fresh photo signals tell Google your business is active. Upload new job photos weekly if possible.',
    points: 2,
  },
  {
    id: 'g10',
    category: 'gbp',
    label: 'Logo and cover photo are professional and branded',
    description: 'Your logo is crisp. Cover photo shows a real roof, real crew, or your branded truck — not stock art.',
    points: 2,
  },
  {
    id: 'g11',
    category: 'gbp',
    label: 'At least 20 reviews with a 4.5+ average rating',
    description: 'Volume matters as much as rating. 50 reviews at 4.6 beats 8 reviews at 5.0 every time.',
    points: 3,
  },
  {
    id: 'g12',
    category: 'gbp',
    label: 'You respond to 100% of reviews within 48 hours',
    description: 'Thank positive reviewers by name. Address negative reviews professionally and take it offline.',
    points: 3,
  },
  {
    id: 'g13',
    category: 'gbp',
    label: 'At least 4 GBP posts published in the last 30 days',
    description: 'Posts expire after 7 days. You need a fresh one every week minimum. Use our templates.',
    points: 3,
  },
  {
    id: 'g14',
    category: 'gbp',
    label: 'Q&A section is pre-seeded with common questions',
    description: 'Ask and answer 5-10 questions yourself. "Do you offer free estimates?" "Are you licensed and insured?" etc.',
    points: 2,
  },
  {
    id: 'g15',
    category: 'gbp',
    label: 'Messaging is enabled and you respond within 15 minutes',
    description: 'Turn on chat and set an auto-reply. Fast response time is a ranking signal and converts leads.',
    points: 2,
  },
  {
    id: 'g16',
    category: 'gbp',
    label: 'Products or services listed with descriptions and prices',
    description: 'Add each service as a product with a photo and price range. This populates your knowledge panel.',
    points: 2,
  },
  {
    id: 'g17',
    category: 'gbp',
    label: 'Attributes filled out completely (women-led, veteran-owned, etc.)',
    description: 'These badges appear in search results and filter results. Do not leave them blank if they apply.',
    points: 1,
  },
  {
    id: 'g18',
    category: 'gbp',
    label: 'Google Business Profile website is disabled or redirected',
    description: 'GBP auto-generates a microsite. Either disable it or make sure it redirects to your real domain.',
    points: 1,
  },
  {
    id: 'g19',
    category: 'gbp',
    label: 'No duplicate or suspended listings for same address',
    description: 'Old business names, partner listings, or former DBA listings dilute your authority. Merge or remove them.',
    points: 2,
  },
  {
    id: 'g20',
    category: 'gbp',
    label: 'Regular citation audit across top 15 directories',
    description: 'Your NAP is identical on Yelp, BBB, Angi, HomeAdvisor, Thumbtack, Chamber of Commerce, and local directories.',
    points: 3,
  },
];

const maxPoints = checklistItems.reduce((sum, i) => sum + i.points, 0);

function getGrade(score: number, total: number): { grade: string; color: string } {
  const pct = score / total;
  if (pct >= 0.9) return { grade: 'A+', color: 'text-green-600' };
  if (pct >= 0.85) return { grade: 'A', color: 'text-green-600' };
  if (pct >= 0.8) return { grade: 'A-', color: 'text-green-500' };
  if (pct >= 0.75) return { grade: 'B+', color: 'text-orange' };
  if (pct >= 0.7) return { grade: 'B', color: 'text-orange' };
  if (pct >= 0.65) return { grade: 'B-', color: 'text-orange' };
  if (pct >= 0.6) return { grade: 'C+', color: 'text-yellow-600' };
  if (pct >= 0.55) return { grade: 'C', color: 'text-yellow-600' };
  if (pct >= 0.5) return { grade: 'C-', color: 'text-yellow-600' };
  if (pct >= 0.4) return { grade: 'D', color: 'text-red-500' };
  return { grade: 'F', color: 'text-red-600' };
}

export default function SEOAuditChecklistPage() {
  const [checked, setChecked] = useState<Set<string>>(new Set());
  const [printMode, setPrintMode] = useState(false);
  const printRef = useRef<HTMLDivElement>(null);

  const toggleItem = (id: string) => {
    const next = new Set(checked);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setChecked(next);
  };

  const handlePrint = () => {
    setPrintMode(true);
    setTimeout(() => {
      window.print();
      setPrintMode(false);
    }, 100);
  };

  const websiteItems = checklistItems.filter((i) => i.category === 'website');
  const gbpItems = checklistItems.filter((i) => i.category === 'gbp');

  const websiteScore = websiteItems.reduce((s, i) => s + (checked.has(i.id) ? i.points : 0), 0);
  const gbpScore = gbpItems.reduce((s, i) => s + (checked.has(i.id) ? i.points : 0), 0);
  const totalScore = websiteScore + gbpScore;
  const websiteMax = websiteItems.reduce((s, i) => s + i.points, 0);
  const gbpMax = gbpItems.reduce((s, i) => s + i.points, 0);

  const overallGrade = getGrade(totalScore, maxPoints);
  const websiteGrade = getGrade(websiteScore, websiteMax);
  const gbpGrade = getGrade(gbpScore, gbpMax);

  const completedCount = checked.size;
  const totalCount = checklistItems.length;

  const schema = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: 'SEO Audit Checklist for Roofing Contractors',
    description:
      'A printable 40-point SEO audit checklist for roofing contractors. Grade your website and Google Business Profile against the exact criteria that drive local rankings.',
    url: 'https://cornerstoneconstructionevansville.com/seo-audit-checklist',
  };

  return (
    <div className="min-h-screen bg-white print:bg-white" ref={printRef}>
      <PageSEO
        title="SEO Audit Checklist for Roofing Contractors | Grade Your Website & GBP"
        description="Free printable 40-point SEO audit checklist. Grade your roofing contractor website and Google Business Profile. Know exactly what is hurting your rankings and how to fix it."
        keywords="SEO audit checklist, roofing contractor SEO, Google Business Profile audit, local SEO checklist, contractor website audit, roofing marketing checklist"
        canonical="/seo-audit-checklist"
        schema={schema}
      />

      {/* Print Header */}
      <div className="hidden print:block print:p-8">
        <div className="flex items-center justify-between border-b-2 border-gray-300 pb-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 uppercase tracking-wider">
              SEO Audit Checklist
            </h1>
            <p className="text-sm text-gray-600 mt-1">
              Grade Your Website & Google Business Profile
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600">
              Corner Stone Construction & Roofing
            </p>
            <p className="text-sm text-gray-600">812-213-5997</p>
            <p className="text-sm text-gray-600">
              cornerstoneconstructionevansville.com
            </p>
          </div>
        </div>
        <p className="text-xs text-gray-500 mb-4">
          Instructions: Check each box your business currently passes. Total your score at the bottom to see your grade.
        </p>
      </div>

      {/* Screen Header */}
      <div className={`${printMode ? 'hidden' : 'block'} bg-charcoal-deep`}>
        <div className="px-6 md:px-10 lg:px-16 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <h1 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wider">
                SEO Audit Checklist
              </h1>
              <p className="text-white/40 text-sm mt-2">
                Grade your website and Google Business Profile. 40 items. Pass or fail.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setChecked(new Set())}
                className="border border-white/20 hover:border-orange text-white/40 hover:text-orange text-xs uppercase tracking-widest py-2.5 px-5 transition-all duration-200 whitespace-nowrap cursor-pointer"
              >
                Reset
              </button>
              <button
                onClick={handlePrint}
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-5 py-2.5 uppercase tracking-wide text-xs transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <i className="ri-printer-line" />
                Print Checklist
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Score Bar (screen only) */}
      <div className={`${printMode ? 'hidden' : 'block'} bg-charcoal-mid border-y border-white/5`}>
        <div className="px-6 md:px-10 lg:px-16 py-5">
          <div className="flex flex-wrap items-center gap-4 md:gap-8">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 flex items-center justify-center border-2 border-orange/30 bg-orange/10">
                <span className={`text-xl font-bold ${overallGrade.color}`}>{overallGrade.grade}</span>
              </div>
              <div>
                <p className="text-white text-sm font-semibold">Overall Grade</p>
                <p className="text-white/40 text-xs">{totalScore} / {maxPoints} points</p>
              </div>
            </div>
            <div className="h-8 w-px bg-white/10 hidden md:block" />
            <div>
              <p className="text-white/60 text-xs uppercase tracking-wider">Website</p>
              <p className="text-white text-sm font-semibold">{websiteGrade.grade} <span className="text-white/40 font-normal">({websiteScore}/{websiteMax})</span></p>
            </div>
            <div>
              <p className="text-white/60 text-xs uppercase tracking-wider">Google Business Profile</p>
              <p className="text-white text-sm font-semibold">{gbpGrade.grade} <span className="text-white/40 font-normal">({gbpScore}/{gbpMax})</span></p>
            </div>
            <div className="h-8 w-px bg-white/10 hidden md:block" />
            <div>
              <p className="text-white/60 text-xs uppercase tracking-wider">Completed</p>
              <p className="text-white text-sm font-semibold">{completedCount} / {totalCount} <span className="text-white/40 font-normal">items</span></p>
            </div>
            <div className="flex-1 min-w-[200px]">
              <div className="h-2 bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-orange transition-all duration-500"
                  style={{ width: `${(completedCount / totalCount) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Print score section */}
      <div className="hidden print:block print:px-8 print:mb-6">
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="border border-gray-300 p-3 text-center">
            <p className="text-[10px] uppercase tracking-wider text-gray-500">Overall Grade</p>
            <p className="text-2xl font-bold text-gray-900 mt-1">{overallGrade.grade}</p>
            <p className="text-xs text-gray-500">{totalScore} / {maxPoints} pts</p>
          </div>
          <div className="border border-gray-300 p-3 text-center">
            <p className="text-[10px] uppercase tracking-wider text-gray-500">Website Score</p>
            <p className="text-2xl font-bold text-gray-900 mt-1">{websiteScore}</p>
            <p className="text-xs text-gray-500">out of {websiteMax}</p>
          </div>
          <div className="border border-gray-300 p-3 text-center">
            <p className="text-[10px] uppercase tracking-wider text-gray-500">GBP Score</p>
            <p className="text-2xl font-bold text-gray-900 mt-1">{gbpScore}</p>
            <p className="text-xs text-gray-500">out of {gbpMax}</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 md:px-8 lg:px-12 py-6 md:py-10 print:px-8 print:py-4">
        {/* Website Section */}
        <div className="mb-10 print:mb-6 print:break-inside-avoid">
          <div className="flex items-center gap-3 mb-6 print:mb-4">
            <div className="w-10 h-10 flex items-center justify-center bg-orange/15 print:bg-gray-100 print:border print:border-gray-300">
              <i className="ri-global-line text-orange print:text-gray-700" />
            </div>
            <div>
              <h2 className="font-display text-gray-900 text-lg md:text-xl uppercase tracking-wider print:text-gray-900">
                Website SEO Audit
              </h2>
              <p className="text-gray-500 text-xs print:text-gray-600">
                {websiteItems.length} items — {websiteScore}/{websiteMax} points
              </p>
            </div>
          </div>

          <div className="space-y-3 print:space-y-2">
            {websiteItems.map((item) => (
              <div
                key={item.id}
                className={`border p-4 md:p-5 print:p-3 print:bg-white print:border-gray-300 flex gap-4 items-start transition-all ${
                  checked.has(item.id)
                    ? 'border-orange/30 bg-orange/[0.03] print:border-gray-300 print:bg-white'
                    : 'border-gray-200 bg-white print:border-gray-300'
                }`}
              >
                {/* Checkbox */}
                <div className="flex-shrink-0 mt-0.5">
                  <div
                    onClick={() => toggleItem(item.id)}
                    className={`w-6 h-6 border-2 flex items-center justify-center cursor-pointer print:border-gray-400 transition-all ${
                      checked.has(item.id)
                        ? 'bg-orange border-orange'
                        : 'bg-white border-gray-300 hover:border-orange'
                    }`}
                  >
                    {checked.has(item.id) && (
                      <i className="ri-check-line text-white text-sm print:text-gray-800" />
                    )}
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3">
                    <p className={`text-sm font-semibold leading-snug ${
                      checked.has(item.id) ? 'text-gray-900 line-through print:no-underline print:text-gray-400' : 'text-gray-900'
                    }`}>
                      {item.label}
                    </p>
                    <span className={`text-[10px] font-bold uppercase tracking-wider flex-shrink-0 whitespace-nowrap ${
                      checked.has(item.id) ? 'text-orange/50 print:text-gray-400' : 'text-orange'
                    }`}>
                      +{item.points} pts
                    </span>
                  </div>
                  <p className={`text-xs leading-relaxed mt-1.5 ${
                    checked.has(item.id) ? 'text-gray-400' : 'text-gray-500'
                  } print:text-gray-600`}>
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* GBP Section */}
        <div className="mb-10 print:mb-6 print:break-inside-avoid">
          <div className="flex items-center gap-3 mb-6 print:mb-4">
            <div className="w-10 h-10 flex items-center justify-center bg-orange/15 print:bg-gray-100 print:border print:border-gray-300">
              <i className="ri-map-pin-line text-orange print:text-gray-700" />
            </div>
            <div>
              <h2 className="font-display text-gray-900 text-lg md:text-xl uppercase tracking-wider print:text-gray-900">
                Google Business Profile Audit
              </h2>
              <p className="text-gray-500 text-xs print:text-gray-600">
                {gbpItems.length} items — {gbpScore}/{gbpMax} points
              </p>
            </div>
          </div>

          <div className="space-y-3 print:space-y-2">
            {gbpItems.map((item) => (
              <div
                key={item.id}
                className={`border p-4 md:p-5 print:p-3 print:bg-white print:border-gray-300 flex gap-4 items-start transition-all ${
                  checked.has(item.id)
                    ? 'border-orange/30 bg-orange/[0.03] print:border-gray-300 print:bg-white'
                    : 'border-gray-200 bg-white print:border-gray-300'
                }`}
              >
                <div className="flex-shrink-0 mt-0.5">
                  <div
                    onClick={() => toggleItem(item.id)}
                    className={`w-6 h-6 border-2 flex items-center justify-center cursor-pointer print:border-gray-400 transition-all ${
                      checked.has(item.id)
                        ? 'bg-orange border-orange'
                        : 'bg-white border-gray-300 hover:border-orange'
                    }`}
                  >
                    {checked.has(item.id) && (
                      <i className="ri-check-line text-white text-sm print:text-gray-800" />
                    )}
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3">
                    <p className={`text-sm font-semibold leading-snug ${
                      checked.has(item.id) ? 'text-gray-900 line-through print:no-underline print:text-gray-400' : 'text-gray-900'
                    }`}>
                      {item.label}
                    </p>
                    <span className={`text-[10px] font-bold uppercase tracking-wider flex-shrink-0 whitespace-nowrap ${
                      checked.has(item.id) ? 'text-orange/50 print:text-gray-400' : 'text-orange'
                    }`}>
                      +{item.points} pts
                    </span>
                  </div>
                  <p className={`text-xs leading-relaxed mt-1.5 ${
                    checked.has(item.id) ? 'text-gray-400' : 'text-gray-500'
                  } print:text-gray-600`}>
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Grade Summary (screen only, interactive) */}
        <div className={`${printMode ? 'hidden' : 'block'} border border-gray-200 p-6 md:p-8 mb-10`}>
          <h3 className="font-display text-gray-900 text-lg uppercase tracking-wider mb-6">
            Your Score Summary
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="text-center p-5 border border-gray-200">
              <p className="text-xs uppercase tracking-wider text-gray-400 mb-2">Overall</p>
              <p className={`text-4xl font-bold ${overallGrade.color}`}>{overallGrade.grade}</p>
              <p className="text-sm text-gray-500 mt-1">{totalScore} of {maxPoints} points</p>
            </div>
            <div className="text-center p-5 border border-gray-200">
              <p className="text-xs uppercase tracking-wider text-gray-400 mb-2">Website</p>
              <p className={`text-4xl font-bold ${websiteGrade.color}`}>{websiteGrade.grade}</p>
              <p className="text-sm text-gray-500 mt-1">{websiteScore} of {websiteMax} points</p>
            </div>
            <div className="text-center p-5 border border-gray-200">
              <p className="text-xs uppercase tracking-wider text-gray-400 mb-2">GBP</p>
              <p className={`text-4xl font-bold ${gbpGrade.color}`}>{gbpGrade.grade}</p>
              <p className="text-sm text-gray-500 mt-1">{gbpScore} of {gbpMax} points</p>
            </div>
          </div>

          <div className="border-t border-gray-200 pt-6">
            <h4 className="text-sm font-semibold text-gray-900 mb-4">What Your Grade Means</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2 text-xs text-gray-600">
              <p><strong className="text-green-600">A (85%+):</strong> You are crushing it. Minor optimizations left.</p>
              <p><strong className="text-orange">B (70-84%):</strong> Solid foundation. Fix the unchecked items to break into top 3.</p>
              <p><strong className="text-yellow-600">C (50-69%):</strong> You are leaving rankings on the table. Focus on GBP first.</p>
              <p><strong className="text-red-500">D/F (&lt;50%):</strong> Your competitors are eating your lunch. Start with GBP category, reviews, and NAP consistency.</p>
            </div>
          </div>
        </div>

        {/* Print score summary */}
        <div className="hidden print:block print:mt-6 print:border-t-2 print:border-gray-300 print:pt-6 print:break-inside-avoid">
          <h3 className="font-display text-gray-900 text-base uppercase tracking-wider mb-4 print:text-gray-900">
            Score Summary
          </h3>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="border border-gray-300 p-3 text-center">
              <p className="text-[10px] uppercase tracking-wider text-gray-500">Overall</p>
              <p className="text-xl font-bold text-gray-900">{overallGrade.grade}</p>
              <p className="text-xs text-gray-500">{totalScore}/{maxPoints}</p>
            </div>
            <div className="border border-gray-300 p-3 text-center">
              <p className="text-[10px] uppercase tracking-wider text-gray-500">Website</p>
              <p className="text-xl font-bold text-gray-900">{websiteGrade.grade}</p>
              <p className="text-xs text-gray-500">{websiteScore}/{websiteMax}</p>
            </div>
            <div className="border border-gray-300 p-3 text-center">
              <p className="text-[10px] uppercase tracking-wider text-gray-500">GBP</p>
              <p className="text-xl font-bold text-gray-900">{gbpGrade.grade}</p>
              <p className="text-xs text-gray-500">{gbpScore}/{gbpMax}</p>
            </div>
          </div>
          <div className="text-xs text-gray-600 space-y-1">
            <p><strong>A (85%+):</strong> Minor optimizations left. You are competitive.</p>
            <p><strong>B (70-84%):</strong> Solid foundation. Fix unchecked items to break top 3.</p>
            <p><strong>C (50-69%):</strong> Focus on GBP category, reviews, and NAP first.</p>
            <p><strong>D/F (&lt;50%):</strong> Competitors are ahead. Prioritize GBP over website.</p>
          </div>
        </div>

        {/* Action Priority List (screen only) */}
        <div className={`${printMode ? 'hidden' : 'block'} mb-10`}>
          <h3 className="font-display text-gray-900 text-lg uppercase tracking-wider mb-5">
            Your Action Priority List
          </h3>
          {completedCount === totalCount ? (
            <div className="bg-green-50 border border-green-200 p-6 text-center">
              <i className="ri-trophy-line text-green-600 text-3xl mb-3" />
              <p className="text-green-800 font-semibold">Perfect score! You are doing everything right.</p>
              <p className="text-green-600 text-sm mt-1">Run this audit monthly to stay ahead.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {checklistItems
                .filter((i) => !checked.has(i.id))
                .sort((a, b) => b.points - a.points)
                .map((item, idx) => (
                  <div
                    key={item.id}
                    className="flex items-start gap-4 p-4 border border-gray-200 bg-white"
                  >
                    <span className="w-6 h-6 flex items-center justify-center bg-orange/10 text-orange text-xs font-bold flex-shrink-0">
                      {idx + 1}
                    </span>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-gray-900">{item.label}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{item.description}</p>
                    </div>
                    <span className="text-[10px] font-bold text-orange uppercase tracking-wider flex-shrink-0">
                      +{item.points} pts
                    </span>
                  </div>
                ))}
            </div>
          )}
        </div>

        {/* Grade Scale Reference (print) */}
        <div className="hidden print:block print:mt-6 print:break-inside-avoid">
          <h3 className="font-display text-gray-900 text-base uppercase tracking-wider mb-3 print:text-gray-900">
            Grade Scale
          </h3>
          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="border-b border-gray-300">
                <th className="text-left py-2 pr-4">Grade</th>
                <th className="text-left py-2 pr-4">Score Range</th>
                <th className="text-left py-2">What It Means</th>
              </tr>
            </thead>
            <tbody className="text-gray-700">
              <tr className="border-b border-gray-200">
                <td className="py-2 pr-4 font-bold">A+ / A / A-</td>
                <td className="py-2 pr-4">80% – 100%</td>
                <td className="py-2">You are competitive. Minor tweaks left.</td>
              </tr>
              <tr className="border-b border-gray-200">
                <td className="py-2 pr-4 font-bold">B+ / B / B-</td>
                <td className="py-2 pr-4">65% – 79%</td>
                <td className="py-2">Solid foundation. Fix unchecked items to break top 3.</td>
              </tr>
              <tr className="border-b border-gray-200">
                <td className="py-2 pr-4 font-bold">C+ / C / C-</td>
                <td className="py-2 pr-4">50% – 64%</td>
                <td className="py-2">Leaving rankings on the table. Focus on GBP first.</td>
              </tr>
              <tr>
                <td className="py-2 pr-4 font-bold">D / F</td>
                <td className="py-2 pr-4">Below 50%</td>
                <td className="py-2">Competitors are ahead. Start with GBP category and reviews.</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Print Footer */}
        <div className="hidden print:block mt-8 pt-4 border-t border-gray-300">
          <div className="flex items-center justify-between text-xs text-gray-500">
            <p>Generated from cornerstoneconstructionevansville.com/seo-audit-checklist</p>
            <p>For the full GBP playbook, visit our website.</p>
          </div>
        </div>
      </div>

      {/* Screen Footer CTA */}
      <div className={`${printMode ? 'hidden' : 'block'} bg-charcoal-deep border-t border-white/5`}>
        <div className="px-6 md:px-10 lg:px-16 py-12">
          <div className="bg-orange/10 border border-orange/20 p-8 max-w-4xl">
            <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">
              Need Help Implementing These Fixes?
            </h3>
            <p className="text-white/40 text-sm leading-relaxed mb-6">
              This checklist shows you WHAT to fix. Our GBP Optimization Guide shows you HOW to fix it — step by step, with screenshots and examples specific to roofing contractors.
            </p>
            <div className="flex flex-wrap gap-3">
              <a
                href="/google-business-profile-optimization"
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-6 py-2.5 uppercase tracking-wide text-xs transition-colors whitespace-nowrap"
              >
                GBP Optimization Playbook
              </a>
              <a
                href="/social-media-templates"
                className="border border-white/20 hover:border-orange text-white/40 hover:text-orange text-xs uppercase tracking-widest py-2.5 px-6 transition-all duration-200"
              >
                14 Social Media Templates
              </a>
              <a
                href="/content-calendar"
                className="border border-white/20 hover:border-orange text-white/40 hover:text-orange text-xs uppercase tracking-widest py-2.5 px-6 transition-all duration-200"
              >
                Printable Content Calendar
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}