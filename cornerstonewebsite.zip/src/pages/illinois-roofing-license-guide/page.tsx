import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PageSEO from '@/components/feature/PageSEO';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const schema = {
  '@context': 'https://schema.org',
  '@type': 'WebPage',
  name: 'Illinois Roofing License Guide — Why Hire IL-Licensed Contractor',
  description: 'Why Illinois homeowners should hire an Illinois-licensed roofing contractor. IL vs IN licensing differences, contractor verification, consumer protection tips. Licensed in Illinois. Corner Stone Construction & Roofing.',
  url: 'https://cornerstoneconstructionevansville.com/illinois-roofing-license-guide',
};

const faqSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: [
    {
      '@type': 'Question',
      name: 'Does Illinois require a roofing license?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Yes. Illinois requires roofing contractors to hold a state-issued roofing contractor license through the Illinois Department of Financial and Professional Regulation (IDFPR). Always verify a contractor\u2019s license before hiring.',
      },
    },
    {
      '@type': 'Question',
      name: 'Can an Indiana roofing contractor work in Illinois?',
      acceptedAnswer: {
        '@type': 'Answer',
        text: 'Only if they also hold an Illinois roofing license. Being licensed in Indiana does not authorize work in Illinois. Corner Stone Construction & Roofing holds licenses in Indiana, Kentucky, and Illinois.',
      },
    },
  ],
};

export default function IllinoisRoofingLicenseGuidePage() {
  const navigate = useNavigate();
  const hero = useScrollAnimation();
  const checklist = useScrollAnimation();
  const risks = useScrollAnimation();
  const cta = useScrollAnimation();

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Illinois Roofing License Guide | Why Hire IL-Licensed Contractor | Corner Stone"
        description="Why Illinois homeowners must hire an Illinois-licensed roofing contractor. IL vs IN licensing explained, license verification guide, red flags to avoid. Fully licensed in Illinois. Call 812-213-5997."
        keywords="Illinois roofing license, Illinois licensed roofing contractor, hire Illinois roofer, roofing contractor license IL, verify Illinois roofer, Mount Carmel licensed roofer, southeastern Illinois roofing contractor"
        canonical="/illinois-roofing-license-guide"
        schema={[schema, faqSchema]}
      />

      {/* Hero */}
      <section className="relative min-h-[60vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1400x900.svg"
            alt="Illinois licensed roofing contractor"
            className="w-full h-full object-cover object-top opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/70 via-charcoal-deep/50 to-charcoal-deep" />
        </div>

        <div
          ref={hero.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 pt-24 pb-16 anim-fade-up ${hero.isVisible ? 'is-visible' : ''}`}
        >
          <div className="flex flex-wrap items-center gap-3 mb-8">
            <span className="border border-orange/40 bg-orange/10 text-orange text-xs font-semibold px-4 py-2 uppercase tracking-widest">Licensed in IL, IN &amp; KY</span>
          </div>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 7vw, 6rem)' }}>
            Why Hire an<br />Illinois-Licensed<br /><span className="text-orange">Roofer?</span>
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-2xl leading-relaxed mb-8">
            If you are a homeowner in Mount Carmel, Carmi, Lawrenceville — anywhere in southeastern Illinois — hiring an Illinois-licensed roofing contractor is not optional. It is your legal protection. Here is what every Illinois homeowner needs to know before signing a roofing contract.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a href="tel:8122135997" className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2">
              <i className="ri-phone-line" />
              812-213-5997
            </a>
            <button onClick={() => navigate('/service-areas')} className="border border-white/30 hover:border-orange text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap cursor-pointer flex items-center gap-2">
              <i className="ri-map-pin-line text-orange" />
              View IL Service Areas
            </button>
          </div>
        </div>
      </section>

      {/* The Big Difference */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-14">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Licensing Matters</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Indiana License &ne;<br /><span className="text-orange">Illinois License.</span>
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Being licensed in one state does not mean a contractor can legally work in another. Here is why the distinction matters for your Illinois home.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="border border-white/10 bg-charcoal-mid p-8">
            <div className="w-12 h-12 flex items-center justify-center bg-red-500/10 mb-5">
              <i className="ri-close-circle-line text-red-400 text-2xl" />
            </div>
            <h3 className="font-display text-white text-2xl uppercase tracking-wider mb-4">Without an Illinois License</h3>
            <ul className="space-y-3">
              {[
                'Work is illegal — the contractor has no legal right to perform roofing in Illinois',
                'No Illinois state oversight or complaint process if something goes wrong',
                'Insurance may deny claims on work done by an unlicensed contractor',
                'No bonding protection — you have no recourse if the contractor walks off the job',
                'Manufacturer warranties may be void if installed by an unlicensed contractor in your state',
                'Property liens from unpaid subcontractors become YOUR problem',
              ].map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <i className="ri-close-line text-red-400 text-sm mt-0.5 flex-shrink-0" />
                  <span className="text-white/50 text-sm leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="border border-orange/30 bg-orange/[0.05] p-8">
            <div className="w-12 h-12 flex items-center justify-center bg-orange/20 mb-5">
              <i className="ri-shield-check-line text-orange text-2xl" />
            </div>
            <h3 className="font-display text-orange text-2xl uppercase tracking-wider mb-4">With an Illinois License</h3>
            <ul className="space-y-3">
              {[
                'Fully legal and compliant with Illinois roofing regulations',
                'Illinois Department of Financial and Professional Regulation oversight',
                'Insurance companies recognize and honor Illinois-licensed contractor work',
                'Bonded — financial protection if the contractor fails to complete the job',
                'Full manufacturer warranty validity for Illinois installations',
                'Consumer protection through the Illinois Attorney General if needed',
              ].map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <i className="ri-check-line text-orange text-sm mt-0.5 flex-shrink-0" />
                  <span className="text-white/50 text-sm leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* How to Verify */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div ref={checklist.ref as React.RefObject<HTMLDivElement>} className={`anim-fade-up ${checklist.isVisible ? 'is-visible' : ''}`}>
          <div className="text-center mb-14">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Verify Before You Sign</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              How to Verify<br /><span className="text-orange">an Illinois Roofer.</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            {[
              {
                step: '01',
                title: 'Ask for the License Number',
                desc: 'A legitimate Illinois roofing contractor will provide their license number immediately upon request. If they hesitate, deflect, or say "it\u2019s being renewed," that is a red flag. Write the number down.',
              },
              {
                step: '02',
                title: 'Verify on IDFPR Website',
                desc: 'Go to the Illinois Department of Financial and Professional Regulation license lookup portal. Enter the license number and verify the contractor name matches, the license is active, and there are no disciplinary actions.',
              },
              {
                step: '03',
                title: 'Check Insurance Directly',
                desc: 'Ask for a Certificate of Insurance (COI) sent directly from their insurance agent — not a photocopy. Verify general liability coverage of at least $1 million and active workers compensation insurance.',
              },
            ].map((item) => (
              <div key={item.step} className="border border-white/10 bg-charcoal-mid p-8">
                <span className="font-display text-orange/30 text-5xl tracking-wider block mb-4">{item.step}</span>
                <h3 className="font-display text-white text-xl uppercase tracking-wider mb-3">{item.title}</h3>
                <p className="text-white/50 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>

          <div className="border border-orange/20 bg-orange/5 p-6 text-center">
            <p className="text-white text-sm">
              <strong className="text-orange">Corner Stone Construction &amp; Roofing</strong> holds active roofing contractor licenses in Illinois, Indiana, and Kentucky. We provide our license numbers and COI at every estimate — because transparency is standard, not optional.
            </p>
          </div>
        </div>
      </section>

      {/* Red Flags */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div ref={risks.ref as React.RefObject<HTMLDivElement>} className={`anim-fade-up ${risks.isVisible ? 'is-visible' : ''}`}>
          <div className="text-center mb-14">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Protect Yourself</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Out-of-State Contractor<br /><span className="text-orange">Red Flags.</span>
            </h2>
            <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed mt-4">
              Southeastern Illinois sits near the Indiana border — which makes it a target for unlicensed out-of-state contractors. Here are the warning signs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-10">
            {[
              { icon: 'ri-truck-line', title: 'Out-of-state plates with no local office', desc: 'Storm chasers roll into Illinois with Indiana or out-of-state trucks, do a few jobs, and leave before complaints catch up. Always ask: Where is your physical office in Illinois?' },
              { icon: 'ri-file-warning-line', title: 'Cannot provide an Illinois license number', desc: 'If they say "our Indiana license covers Illinois" or "Illinois doesn\u2019t require a roofing license," they are lying. Walk away.' },
              { icon: 'ri-money-dollar-circle-line', title: 'Demands full payment upfront in cash', desc: 'Unlicensed contractors often demand cash or 100% upfront payment because they know they have no legal obligation to finish the job once they have your money.' },
              { icon: 'ri-door-open-line', title: 'Knocks on your door after a storm', desc: 'Reputable Illinois roofers do not canvas neighborhoods after storms. They get referrals and calls from homeowners who did their research. Unsolicited door-knockers are a classic storm-chaser tactic.' },
              { icon: 'ri-building-line', title: 'No Illinois business registration', desc: 'Search the contractor\u2019s business name on the Illinois Secretary of State website. If they are not registered as a business entity in Illinois, they have no legal standing to operate here.' },
              { icon: 'ri-chat-delete-line', title: 'Refuses to provide local references', desc: 'Ask for three Illinois references from the last six months — ideally in your county. If they cannot provide any, they have not done legitimate work in Illinois.' },
            ].map((item) => (
              <div key={item.title} className="flex items-start gap-4 p-5 border border-white/10 bg-charcoal-mid">
                <div className="w-10 h-10 flex items-center justify-center bg-red-500/10 flex-shrink-0 mt-0.5">
                  <i className={`${item.icon} text-red-400 text-lg`} />
                </div>
                <div>
                  <h3 className="font-display text-white text-lg uppercase tracking-wider mb-2">{item.title}</h3>
                  <p className="text-white/50 text-sm leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Licensed IL Cities */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-12">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Our Illinois Coverage</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Licensed &amp; Ready<br /><span className="text-orange">in These IL Cities.</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            { city: 'Mount Carmel', county: 'Wabash County', route: '/locations/mount-carmel-il' },
            { city: 'Grayville', county: 'Edwards County', route: '/locations/grayville-il' },
            { city: 'Carmi', county: 'White County', route: '/locations/carmi-il' },
            { city: 'Lawrenceville', county: 'Lawrence County', route: '/locations/lawrenceville-il' },
            { city: 'Olney', county: 'Richland County', route: '/locations/olney-il' },
            { city: 'Fairfield', county: 'Wayne County', route: '/locations/fairfield-il' },
          ].map((item) => (
            <button
              key={item.city}
              onClick={() => navigate(item.route)}
              className="border border-white/10 bg-charcoal-mid p-5 text-left hover:border-orange/40 transition-all cursor-pointer group flex items-center justify-between"
            >
              <div>
                <p className="font-display text-white text-lg uppercase tracking-wider group-hover:text-orange transition-colors">{item.city}</p>
                <p className="text-white/40 text-sm">{item.county}</p>
              </div>
              <i className="ri-arrow-right-line text-orange text-lg opacity-0 group-hover:opacity-100 transition-opacity" />
            </button>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16">
        <div ref={cta.ref as React.RefObject<HTMLDivElement>} className={`anim-fade-up border border-white/10 bg-charcoal-mid p-10 md:p-14 text-center ${cta.isVisible ? 'is-visible' : ''}`}>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Hire a Licensed<br /><span className="text-orange">Illinois Pro.</span>
          </h2>
          <p className="text-white/40 text-sm max-w-lg mx-auto leading-relaxed mb-8">
            Corner Stone Construction &amp; Roofing holds active roofing licenses in Illinois, Indiana, and Kentucky. We provide license verification at every estimate — because you deserve proof, not promises.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="tel:8122135997" className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2">
              <i className="ri-phone-fill" />
              Call 812-213-5997
            </a>
            <button onClick={() => navigate('/illinois-roof-financing')} className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all cursor-pointer whitespace-nowrap flex items-center gap-2">
              <i className="ri-funds-line text-orange" />
              Illinois Roof Financing
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}