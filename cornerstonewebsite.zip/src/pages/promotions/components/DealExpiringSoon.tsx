import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

interface ExpiringOffer {
  id: string;
  title: string;
  expires: string;
  savings: string;
}

interface DealExpiringSoonProps {
  offers: { id: string; title: string; savings: string; limited?: boolean; expires?: string }[];
  linkToPage?: string;
}

function calcSecondsLeft(expiresAt: string): number {
  return Math.max(0, new Date(expiresAt).getTime() - Date.now());
}

function formatCompact(seconds: number): string {
  if (seconds <= 0) return 'Expired';
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

const FIRST_VISIT_KEY = 'cs_first_visit';

function isFirstVisit(): boolean {
  try {
    return sessionStorage.getItem(FIRST_VISIT_KEY) !== '1';
  } catch {
    return true;
  }
}

function markVisited() {
  try {
    sessionStorage.setItem(FIRST_VISIT_KEY, '1');
  } catch {
    // silently skip
  }
}

export default function DealExpiringSoon({ offers, linkToPage }: DealExpiringSoonProps) {
  const navigate = useNavigate();
  const [nearest, setNearest] = useState<ExpiringOffer | null>(null);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [collapsed, setCollapsed] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [visible, setVisible] = useState(false);
  const [showWelcome, setShowWelcome] = useState(false);
  const [welcomeDismissed, setWelcomeDismissed] = useState(false);

  const handleWelcomeDismiss = () => {
    markVisited();
    setWelcomeDismissed(true);
    setVisible(false);
  };

  const handleWelcomeAction = () => {
    markVisited();
    setWelcomeDismissed(true);
    if (linkToPage) {
      navigate(linkToPage);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  useEffect(() => {
    // Check first visit before computing nearest deal
    if (isFirstVisit()) {
      setShowWelcome(true);
      const showTimer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(showTimer);
    }

    const limited = offers
      .filter((o) => o.limited && o.expires)
      .map((o) => ({ id: o.id, title: o.title, expires: o.expires!, savings: o.savings }))
      .sort((a, b) => new Date(a.expires).getTime() - new Date(b.expires).getTime());

    if (limited.length === 0) return;
    setNearest(limited[0]);
    setSecondsLeft(calcSecondsLeft(limited[0].expires));

    // Show after a short delay so it doesn't jump in immediately
    const showTimer = setTimeout(() => setVisible(true), 1500);
    return () => clearTimeout(showTimer);
  }, [offers]);

  useEffect(() => {
    if (!nearest) return;
    const timer = setInterval(() => {
      const left = calcSecondsLeft(nearest.expires);
      setSecondsLeft(left);
      if (left <= 0) clearInterval(timer);
    }, 1000);
    return () => clearInterval(timer);
  }, [nearest]);

  // Welcome mode — first-time visitor
  if (showWelcome && !welcomeDismissed) {
    const targetPage = linkToPage || '/promotions';

    return (
      <div
        className={`fixed bottom-6 right-6 z-50 max-w-[320px] w-[calc(100vw-48px)] transition-all duration-300 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}
      >
        <div className="border border-green-400/30 backdrop-blur-md bg-charcoal-mid/95 p-4 shadow-2xl bg-green-500/5">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div className="flex items-center gap-2 min-w-0">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse flex-shrink-0" />
              <span className="text-white text-xs font-bold uppercase tracking-wider truncate">
                Welcome!
              </span>
            </div>
            <button
              type="button"
              onClick={handleWelcomeDismiss}
              className="text-white/30 hover:text-white/60 transition-colors cursor-pointer p-0.5"
              title="Dismiss"
            >
              <i className="ri-close-line text-sm" />
            </button>
          </div>

          <p className="text-white/80 text-xs font-semibold leading-snug mb-2">
            First project discount available — see our best deals
          </p>

          <div className="flex items-center justify-between gap-3">
            <span className="text-green-400/70 text-[10px] font-semibold">
              Limited-time seasonal offers
            </span>
            <button
              type="button"
              onClick={handleWelcomeAction}
              className="text-green-400 hover:text-green-300 text-[10px] font-bold uppercase tracking-wider whitespace-nowrap flex items-center gap-1 transition-colors cursor-pointer"
            >
              View Deals <i className="ri-arrow-right-line" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!nearest || dismissed || secondsLeft <= 0) return null;

  const urgencyColor =
    secondsLeft < 86400 * 3 ? 'border-red-500/40 bg-red-500/10' :
    secondsLeft < 86400 * 7 ? 'border-red-400/30 bg-red-500/5' :
    'border-amber-400/30 bg-amber-500/5';

  const dotColor =
    secondsLeft < 86400 * 3 ? 'bg-red-500 animate-pulse' :
    secondsLeft < 86400 * 7 ? 'bg-red-400' :
    'bg-amber-400';

  if (collapsed) {
    return (
      <div
        className={`fixed bottom-6 right-6 z-50 transition-all duration-300 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}
      >
        <button
          type="button"
          onClick={() => setCollapsed(false)}
          className="w-12 h-12 flex items-center justify-center bg-red-500 hover:bg-red-600 text-white rounded-full shadow-lg transition-all cursor-pointer floating-bounce"
          title="Deal expiring soon — expand"
        >
          <i className="ri-timer-flash-line text-lg" />
        </button>
      </div>
    );
  }

  return (
    <div
      className={`fixed bottom-6 right-6 z-50 max-w-[320px] w-[calc(100vw-48px)] transition-all duration-300 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4 pointer-events-none'}`}
    >
      <div className={`border backdrop-blur-md bg-charcoal-mid/95 p-4 shadow-2xl ${urgencyColor}`}>
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2 min-w-0">
            <span className={`w-2 h-2 rounded-full flex-shrink-0 ${dotColor}`} />
            <span className="text-white text-xs font-bold uppercase tracking-wider truncate">
              Deal Expiring Soon
            </span>
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            <button
              type="button"
              onClick={() => setCollapsed(true)}
              className="text-white/30 hover:text-white/60 transition-colors cursor-pointer p-0.5"
              title="Minimize"
            >
              <i className="ri-subtract-line text-sm" />
            </button>
            <button
              type="button"
              onClick={() => setDismissed(true)}
              className="text-white/30 hover:text-white/60 transition-colors cursor-pointer p-0.5"
              title="Dismiss"
            >
              <i className="ri-close-line text-sm" />
            </button>
          </div>
        </div>

        <p className="text-white/80 text-xs font-semibold leading-snug mb-2 line-clamp-2">
          {nearest.title}
        </p>

        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="bg-black/30 px-2.5 py-1 rounded">
              <span className="text-red-400 text-xs font-mono font-bold tabular-nums">
                {formatCompact(secondsLeft)}
              </span>
            </div>
            <span className="text-orange/80 text-[10px] font-semibold truncate">{nearest.savings}</span>
          </div>
          <a
            href={linkToPage ? `${linkToPage}#offer-${nearest.id}` : `#offer-${nearest.id}`}
            onClick={(e) => {
              e.preventDefault();
              if (linkToPage) {
                navigate(`${linkToPage}#offer-${nearest.id}`);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              } else {
                const el = document.getElementById(`offer-${nearest.id}`);
                if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }
            }}
            className="text-orange hover:text-orange-light text-[10px] font-bold uppercase tracking-wider whitespace-nowrap flex items-center gap-1 transition-colors"
          >
            View Deal <i className="ri-arrow-right-line" />
          </a>
        </div>
      </div>
    </div>
  );
}