import { useState } from 'react';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const SEASONAL_OFFERS = [
  { id: 'storm-prep', label: 'Storm Season Protection — Save $750', expires: 'July 31, 2026' },
  { id: 'summer-roof', label: 'Summer Roof Replacement — 10% Off', expires: 'August 31, 2026' },
  { id: 'exterior-bundle', label: 'Complete Exterior Bundle — Save $2,500', expires: 'September 30, 2026' },
  { id: 'gutter-fall', label: 'Fall Gutter & Maintenance — Save $400', expires: 'November 15, 2026' },
];

export default function EmailReminderForm() {
  const [selected, setSelected] = useState<string[]>([]);
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const toggleOffer = (id: string) => {
    setSelected((prev) =>
      prev.includes(id) ? prev.filter((o) => o !== id) : [...prev, id]
    );
  };

  const toggleAll = () => {
    if (selected.length === SEASONAL_OFFERS.length) {
      setSelected([]);
    } else {
      setSelected(SEASONAL_OFFERS.map((o) => o.id));
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (selected.length === 0) return;
    setSubmitting(true);
    const form = e.currentTarget;
    const formData = new FormData(form);
    // Append selected offers as hidden fields before submission
    selected.forEach((id) => formData.append('selected_offers', id));
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
    const data = new URLSearchParams(formData as unknown as Record<string, string>);
    try {
      await fetch(WEB3FORMS_ENDPOINT, { method: 'POST', body: data });
    } catch {
      // fail silently, still show success
    }
    setSubmitted(true);
    setSubmitting(false);
  };

  if (submitted) {
    return (
      <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-8 text-center">
        <div className="w-12 h-12 flex items-center justify-center bg-green-500/20 rounded-full mx-auto mb-4">
          <i className="ri-checkbox-circle-fill text-green-400 text-xl" />
        </div>
        <h4 className="text-white text-sm font-bold uppercase tracking-wider mb-2">
          You're on the list!
        </h4>
        <p className="text-white/50 text-xs leading-relaxed max-w-sm mx-auto">
          We'll send you an email 48 hours before each selected offer expires. No spam — just a friendly heads-up so you don't miss out.
        </p>
        <button
          onClick={() => { setSubmitted(false); setSelected([]); setEmail(''); }}
          className="mt-5 text-orange text-xs font-semibold uppercase tracking-wider hover:underline underline-offset-4 cursor-pointer"
        >
          Set up another reminder
        </button>
      </div>
    );
  }

  return (
    <form
      data-readdy-form
      id="promotions-expiry-reminder"
      onSubmit={handleSubmit}
      className="space-y-5"
    >
      {/* Offer checkboxes */}
      <div className="bg-charcoal-mid border border-white/10 rounded-xl p-5 text-left">
        <div className="flex items-center justify-between mb-4">
          <p className="text-white text-xs font-semibold uppercase tracking-wider">
            Choose Offers to Track
          </p>
          <button
            type="button"
            onClick={toggleAll}
            className="text-orange text-[10px] font-semibold uppercase tracking-wider hover:underline underline-offset-4 cursor-pointer whitespace-nowrap"
          >
            {selected.length === SEASONAL_OFFERS.length ? 'Deselect All' : 'Select All'}
          </button>
        </div>
        <div className="space-y-2">
          {SEASONAL_OFFERS.map((offer) => {
            const isChecked = selected.includes(offer.id);
            return (
              <button
                key={offer.id}
                type="button"
                onClick={() => toggleOffer(offer.id)}
                className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all cursor-pointer text-left ${
                  isChecked
                    ? 'border-orange/40 bg-orange/10'
                    : 'border-white/5 bg-transparent hover:border-white/10'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
                    isChecked ? 'bg-orange border-orange' : 'border-white/20'
                  }`}
                >
                  {isChecked && <i className="ri-check-line text-white text-xs" />}
                </div>
                <div className="min-w-0 flex-1">
                  <span className={`text-xs block ${isChecked ? 'text-white font-semibold' : 'text-white/60'}`}>
                    {offer.label}
                  </span>
                  <span className="text-white/25 text-[10px] block mt-0.5">
                    Expires {offer.expires}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Email input */}
      <div className="flex flex-col sm:flex-row gap-3">
        <input
          type="email"
          name="email"
          required
          placeholder="your@email.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="flex-1 bg-charcoal-mid border border-white/10 focus:border-orange/50 text-white text-sm px-4 py-3 outline-none placeholder:text-white/25 transition-colors rounded-lg"
        />
        <button
          type="submit"
          disabled={submitting || selected.length === 0}
          className="bg-orange hover:bg-orange-dark disabled:bg-stone-600 disabled:cursor-not-allowed text-white font-semibold text-sm px-6 py-3 uppercase tracking-wider transition-colors cursor-pointer whitespace-nowrap rounded-lg flex items-center justify-center gap-2"
        >
          {submitting ? (
            <><i className="ri-loader-4-line animate-spin" /> Sending...</>
          ) : (
            <><i className="ri-notification-3-line" /> Set Reminder{selected.length > 1 ? 's' : ''}</>
          )}
        </button>
      </div>

      <p className="text-white/25 text-[10px]">
        We'll send one reminder per offer, 48 hours before expiry. No spam, ever.
      </p>
    </form>
  );
}