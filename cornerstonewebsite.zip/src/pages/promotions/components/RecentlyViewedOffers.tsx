import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

interface ViewedOffer {
  id: string;
  title: string;
  savings: string;
  icon: string;
  timestamp: number;
}

const STORAGE_KEY = 'cs_recently_viewed_offers';
const MAX_ITEMS = 3;

export function trackOfferView(offer: { id: string; title: string; savings: string; icon: string }) {
  try {
    const stored = sessionStorage.getItem(STORAGE_KEY);
    const existing: ViewedOffer[] = stored ? JSON.parse(stored) : [];
    const filtered = existing.filter((o) => o.id !== offer.id);
    const entry: ViewedOffer = { ...offer, timestamp: Date.now() };
    filtered.unshift(entry);
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(filtered.slice(0, MAX_ITEMS)));
  } catch {
    // sessionStorage unavailable — silently skip
  }
}

function getViewedOffers(): ViewedOffer[] {
  try {
    const stored = sessionStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

export default function RecentlyViewedOffers() {
  const navigate = useNavigate();
  const [offers, setOffers] = useState<ViewedOffer[]>([]);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    setOffers(getViewedOffers());
  }, []);

  // re-read on window focus in case user navigated to another tab and back
  useEffect(() => {
    if (!mounted) return;
    const onFocus = () => setOffers(getViewedOffers());
    window.addEventListener('focus', onFocus);
    return () => window.removeEventListener('focus', onFocus);
  }, [mounted]);

  if (!mounted || offers.length === 0) return null;

  return (
    <div className="mt-8 max-w-3xl mx-auto">
      <div className="flex items-center gap-2 mb-4">
        <i className="ri-history-line text-white/30 text-sm" />
        <span className="text-white/30 text-[10px] font-semibold uppercase tracking-widest">
          Recently Viewed
        </span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {offers.map((offer) => (
          <button
            key={offer.id}
            type="button"
            onClick={() => {
              const el = document.getElementById(`offer-${offer.id}`);
              if (el) {
                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }
            }}
            className="flex items-center gap-3 bg-charcoal-mid border border-white/5 hover:border-orange/30 p-4 transition-all cursor-pointer group"
          >
            <div className="w-8 h-8 flex items-center justify-center bg-orange/10 text-orange flex-shrink-0">
              <i className={`${offer.icon} text-sm`} />
            </div>
            <div className="min-w-0 text-left">
              <p className="text-white/70 text-xs font-semibold truncate group-hover:text-white transition-colors">
                {offer.title}
              </p>
              <p className="text-orange/70 text-[10px] truncate">
                {offer.savings}
              </p>
            </div>
            <i className="ri-arrow-right-line text-white/20 group-hover:text-orange transition-colors text-xs ml-auto flex-shrink-0" />
          </button>
        ))}
      </div>
    </div>
  );
}