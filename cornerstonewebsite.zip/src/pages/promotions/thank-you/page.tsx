import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import PageSEO from '@/components/feature/PageSEO';
import MyProjectsBadge from '@/components/feature/MyProjectsBadge';

interface OfferInfo {
  id: string;
  name: string;
  savings: string;
}

const OFFER_DETAILS: Record<string, { name: string; savings: string; nextSteps: string[] }> = {
  'storm-prep': {
    name: 'Storm Season Protection Package',
    savings: 'Save up to $750',
    nextSteps: [
      'Our scheduling team will call you within 24 hours to book your free drone inspection',
      'An inspector will visit your property to assess current roof condition and storm readiness',
      'You\'ll receive a detailed report with photos and a written estimate within 48 hours of inspection',
      'Priority scheduling means your roof gets reinforced before the next storm hits',
    ],
  },
  'summer-roof': {
    name: 'Summer Roof Replacement Special',
    savings: '10% Off + 0% Financing',
    nextSteps: [
      'Our estimator will call within 24 hours to schedule your free on-site measurement',
      'You\'ll receive a detailed written estimate with material options and color samples',
      'Choose your shingle color and material tier — we\'ll lock in your summer pricing',
      'Installation typically completes in 1-2 days with our dedicated roof crew',
    ],
  },
  'gutter-fall': {
    name: 'Fall Gutter & Maintenance Package',
    savings: 'Save $400',
    nextSteps: [
      'A gutter specialist will call within 24 hours to schedule your free assessment',
      'We\'ll measure every linear foot and discuss seamless gutter color options',
      'You\'ll receive a written estimate covering gutters, guards, and downspouts',
      'Installation is usually completed in a single day, often within a week of your estimate',
    ],
  },
  'referral': {
    name: 'Refer a Neighbor & Get $250',
    savings: 'Earn $250 per referral',
    nextSteps: [
      'We\'ll send you a personalized referral link to share with neighbors and friends',
      'When someone you refer books a roof replacement or major repair, you earn $250',
      'There is no limit — refer as many people as you want and earn on every completed job',
      'You can track your referrals anytime through the Customer Portal',
    ],
  },
  'military-senior': {
    name: 'Military & Senior Discount',
    savings: '5% Off Any Service',
    nextSteps: [
      'Our team will call within 24 hours to verify your eligibility and schedule your estimate',
      'The 5% discount applies automatically to any roofing, siding, or gutter service',
      'This discount stacks with any seasonal promotions you qualify for',
      'We\'ll confirm the total savings on your written estimate before any work begins',
    ],
  },
  'exterior-bundle': {
    name: 'Complete Exterior Bundle',
    savings: 'Save up to $2,500',
    nextSteps: [
      'A project consultant will call within 24 hours to discuss your exterior needs',
      'We\'ll schedule a comprehensive assessment covering your roof, siding, and gutters',
      'You\'ll receive a bundled estimate showing all three systems with maximum savings',
      'One crew, one schedule, one warranty — all coordinated for minimal disruption',
    ],
  },
};

const DEFAULT_NEXT_STEPS = [
  'A Corner Stone team member will call you within 24 hours to confirm your offer',
  'We\'ll schedule your free inspection or estimate at a time that works for you',
  'You\'ll receive a detailed written estimate with all applicable savings applied',
  'Work is scheduled at your convenience with our industry-leading warranty included',
];

export default function PromotionThankYouPage() {
  const navigate = useNavigate();
  const [offer, setOffer] = useState<OfferInfo | null>(null);
  const heroAnim = useScrollAnimation();
  const stepsAnim = useScrollAnimation({ threshold: 0.1 });

  useEffect(() => {
    const stored = sessionStorage.getItem('claimed_offer');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setOffer(parsed);
        sessionStorage.removeItem('claimed_offer');
      } catch {
        setOffer(null);
      }
    }
  }, []);

  const details = offer ? OFFER_DETAILS[offer.id] : null;
  const nextSteps = details?.nextSteps || DEFAULT_NEXT_STEPS;
  const displayName = details?.name || offer?.name || 'your offer';
  const displaySavings = details?.savings || offer?.savings || '';

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Offer Claimed — Thank You | Corner Stone Construction & Roofing"
        description="Your promotion has been claimed. See what happens next and how Corner Stone will get your roofing, siding, or gutter project started in Evansville Indiana."
        canonical="/promotions/thank-you"
      />

      {/* Hero */}
      <section className="pt-32 md:pt-40 pb-16 md:pb-20 px-6 md:px-10 lg:px-16 relative">
        {/* My Projects quick-access badge */}
        <MyProjectsBadge className="absolute top-6 right-6 md:top-8 md:right-10 lg:top-10 lg:right-16 z-10" />

        <div ref={heroAnim.ref as React.RefObject<HTMLDivElement>} className={`max-w-2xl mx-auto text-center anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}>
          <div className="w-20 h-20 flex items-center justify-center bg-green-500/15 mx-auto mb-6">
            <i className="ri-checkbox-circle-fill text-green-400 text-5xl" />
          </div>
          <p className="text-green-400 text-xs font-semibold tracking-[0.25em] uppercase mb-4">
            Offer Claimed Successfully
          </p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            You're All Set!
          </h1>

          {offer && (
            <div className="border border-white/10 bg-charcoal-mid p-5 md:p-6 mb-6">
              <p className="text-white/40 text-xs uppercase tracking-wider mb-1">Your Offer</p>
              <p className="text-white text-lg font-semibold mb-1">{displayName}</p>
              <p className="text-orange font-bold text-xl">{displaySavings}</p>
            </div>
          )}

          <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-lg mx-auto">
            We've received your claim and our team is ready to get started. Here's exactly what happens next — no surprises, no pressure.
          </p>
        </div>
      </section>

      {/* Next Steps */}
      <section className="pb-16 md:pb-24 px-6 md:px-10 lg:px-16">
        <div ref={stepsAnim.ref as React.RefObject<HTMLDivElement>} className={`max-w-2xl mx-auto anim-fade-up ${stepsAnim.isVisible ? 'is-visible' : ''}`}>
          <h2 className="font-display text-white text-xl uppercase tracking-wider mb-8 text-center">What Happens Next</h2>
          <div className="relative">
            <div className="absolute left-[19px] top-3 bottom-3 w-px bg-white/10" />
            <div className="space-y-0">
              {nextSteps.map((step, i) => (
                <div key={i} className="relative flex items-start gap-5 py-3">
                  <div className="relative z-10 w-10 h-10 flex items-center justify-center bg-orange/15 text-orange border border-orange/20 flex-shrink-0 text-sm font-bold">
                    {i + 1}
                  </div>
                  <p className="text-white/60 text-sm leading-relaxed pt-2">{step}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Estimated timeline */}
          <div className="border border-white/10 bg-charcoal-mid p-6 mt-10 text-center">
            <div className="flex items-center justify-center gap-2 mb-3">
              <i className="ri-time-line text-orange" />
              <span className="text-white text-sm font-semibold uppercase tracking-wider">Estimated Timeline</span>
            </div>
            <p className="text-white/50 text-sm leading-relaxed">
              Most customers receive their first callback within <strong className="text-white">2-4 business hours</strong>. Free inspections are typically scheduled within <strong className="text-white">3-5 business days</strong>, and depending on your project scope, work can often begin within <strong className="text-white">1-2 weeks</strong> of your estimate approval.
            </p>
          </div>
        </div>
      </section>

      {/* What else can you do */}
      <section className="pb-20 md:pb-28 px-6 md:px-10 lg:px-16">
        <div className="max-w-3xl mx-auto">
          <h3 className="text-white/40 text-xs uppercase tracking-[0.2em] text-center mb-8">While You Wait, Explore</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { icon: 'ri-shield-check-line', title: 'Customer Portal', desc: 'Track your project in real time once work begins', link: '/customer-portal' },
              { icon: 'ri-image-line', title: 'Before & After', desc: 'See our recent roof transformations in the Tri-State', link: '/before-after' },
              { icon: 'ri-star-line', title: 'Reviews', desc: 'Read 300+ five-star reviews from real customers', link: '/testimonials' },
            ].map((card) => (
              <Link
                key={card.title}
                to={card.link}
                className="border border-white/10 bg-charcoal-mid hover:border-orange/30 transition-all p-5 group text-center"
              >
                <div className="w-10 h-10 flex items-center justify-center bg-orange/10 text-orange mx-auto mb-3 group-hover:bg-orange/20 transition-colors">
                  <i className={`${card.icon}`} />
                </div>
                <h4 className="text-white text-sm font-semibold uppercase tracking-wider mb-2">{card.title}</h4>
                <p className="text-white/40 text-xs leading-relaxed">{card.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Bottom CTA */}
      <section className="pb-20 md:pb-28 px-6 md:px-10 lg:px-16">
        <div className="max-w-xl mx-auto text-center">
          <p className="text-white/30 text-xs mb-6">Have questions or need to talk to someone right now?</p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="tel:8122135997"
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-phone-line" />
              Call 812-213-5997
            </a>
            <button
              onClick={() => navigate('/promotions')}
              className="border border-white/20 hover:border-white text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              <i className="ri-arrow-left-line mr-1.5" />
              Back to Promotions
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}