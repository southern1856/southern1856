import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import PageSEO from '@/components/feature/PageSEO';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import EmailReminderForm from './components/EmailReminderForm';
import RecentlyViewedOffers, { trackOfferView } from './components/RecentlyViewedOffers';
import DealExpiringSoon from './components/DealExpiringSoon';
import { OFFERS, type Offer } from '@/mocks/promotions';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const FAQS = [
  { q: 'Can I combine multiple promotions?', a: 'Yes! Most promotions can be stacked. For example, you can combine the summer roof special with the military/senior discount. Our team will help you maximize your savings during your free estimate.' },
  { q: 'How long are these offers valid?', a: 'Limited-time offers have expiration dates listed on each card. Always-active promotions like military/senior discounts and referral rewards are ongoing and can be redeemed anytime.' },
  { q: 'How does the referral program work?', a: 'Simply refer someone to Corner Stone. When they book and complete a roof replacement or major repair, you receive $250 cash. We track referrals and you can refer as many people as you want.' },
  { q: 'Do you offer financing with promotions?', a: 'Absolutely. All promotional pricing is eligible for our financing options including 0% interest for 24 months on qualifying projects. Your estimate will include all available financing details.' },
];

function OfferCard({ offer, index }: { offer: Offer; index: number }) {
  const navigate = useNavigate();
  const [claiming, setClaiming] = useState(false);
  const [claimed, setClaimed] = useState(false);
  const anim = useScrollAnimation({ threshold: 0.1 });

  const handleClaim = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setClaiming(true);
    const form = e.currentTarget;
    const _fd = new FormData(form);
    _fd.append('access_key', WEB3FORMS_ACCESS_KEY);
    const data = new URLSearchParams(_fd as unknown as Record<string, string>);
    try {
      await fetch(WEB3FORMS_ENDPOINT, { method: 'POST', body: data });
      sessionStorage.setItem('claimed_offer', JSON.stringify({
        id: offer.id,
        name: offer.title,
        savings: offer.savings,
      }));
      navigate('/promotions/thank-you');
    } catch {
      sessionStorage.setItem('claimed_offer', JSON.stringify({
        id: offer.id,
        name: offer.title,
        savings: offer.savings,
      }));
      navigate('/promotions/thank-you');
    }
    setClaiming(false);
  };

  return (
    <div
      ref={anim.ref as React.RefObject<HTMLDivElement>}
      id={`offer-${offer.id}`}
      className={`anim-fade-up ${anim.isVisible ? 'is-visible' : ''} border border-white/10 bg-charcoal-mid hover:border-orange/30 transition-all duration-300 flex flex-col overflow-hidden group`}
      style={{ transitionDelay: `${index * 80}ms` }}
    >
      {/* Image */}
      <button
        type="button"
        onClick={() => trackOfferView({ id: offer.id, title: offer.title, savings: offer.savings, icon: offer.icon })}
        className="relative h-48 overflow-hidden cursor-pointer w-full block"
      >
        <img src={offer.bgImage} alt={offer.title} className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-600" />
        <div className="absolute inset-0 bg-gradient-to-t from-charcoal-mid via-charcoal-mid/30 to-transparent" />
        {offer.limited && offer.expires && (
          <div className="absolute top-3 right-3">
            <CountdownTimer expiresAt={offer.expires} variant="badge" />
          </div>
        )}
      </button>

      {/* Content */}
      <div className="p-6 md:p-7 flex flex-col flex-1">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 bg-orange/15 text-orange border border-orange/20">{offer.badge}</span>
        </div>
        <h3 className="font-display text-white text-lg uppercase tracking-wide mb-1 leading-tight">{offer.title}</h3>
        <p className="text-white/35 text-xs mb-3">{offer.subtitle}</p>
        <p className="text-orange font-bold text-xl mb-1">{offer.savings}</p>
        {offer.limited && offer.expires && (
          <div className="mb-3">
            <CountdownTimer expiresAt={offer.expires} variant="badge" />
          </div>
        )}
        <p className="text-white/50 text-xs leading-relaxed mb-5">{offer.description}</p>
        <ul className="space-y-2 mb-6 flex-1">
          {offer.features.map((f, i) => (
            <li key={i} className="flex items-start gap-2 text-white/60 text-xs">
              <i className="ri-check-fill text-green-500 text-xs mt-px flex-shrink-0" />{f}
            </li>
          ))}
        </ul>

        {claimed ? (
          <div className="bg-green-500/10 border border-green-500/20 p-4 text-center">
            <p className="text-green-400 text-sm font-semibold mb-1">Redirecting...</p>
            <p className="text-white/50 text-xs">Taking you to your confirmation page.</p>
          </div>
        ) : (
          <form data-readdy-form onSubmit={handleClaim} className="space-y-3 mt-auto">
            <input type="hidden" name="offer_id" value={offer.id} />
            <input type="hidden" name="offer_name" value={offer.title} />
            <input type="text" name="name" required placeholder="Your Name" className="w-full bg-charcoal-deep border border-white/10 focus:border-orange/50 text-white text-sm px-4 py-2.5 outline-none placeholder:text-white/25 transition-colors" />
            <input type="email" name="email" required placeholder="Email Address" className="w-full bg-charcoal-deep border border-white/10 focus:border-orange/50 text-white text-sm px-4 py-2.5 outline-none placeholder:text-white/25 transition-colors" />
            <input type="tel" name="phone" required placeholder="Phone Number" className="w-full bg-charcoal-deep border border-white/10 focus:border-orange/50 text-white text-sm px-4 py-2.5 outline-none placeholder:text-white/25 transition-colors" />
            <button type="submit" disabled={claiming} className="w-full bg-orange hover:bg-orange-dark disabled:bg-stone-600 text-white text-sm font-semibold py-3 uppercase tracking-wider transition-colors cursor-pointer whitespace-nowrap flex items-center justify-center gap-2">
              {claiming ? <><i className="ri-loader-4-line animate-spin" />Submitting...</> : 'Claim This Offer'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

export default function PromotionsPage() {
  const navigate = useNavigate();
  const heroAnim = useScrollAnimation();
  const ctaAnim = useScrollAnimation({ threshold: 0.1 });

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roofing Specials & Promotions | Evansville Indiana | Corner Stone"
        description="Save big on roofing, gutters, and siding in Evansville IN. Storm season prep, summer roof specials, military discounts, referral rewards — claim your offer today. Corner Stone Construction & Roofing."
        keywords="roofing specials Evansville, roof replacement deals Indiana, gutter installation discounts, roofing promotions Tri-State, military discount roofer, referral bonus roofing"
        canonical="/promotions"
      />

      {/* Hero */}
      <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1600x900.svg"
            alt="Corner Stone seasonal promotions"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-charcoal-deep" />
        </div>
        <div ref={heroAnim.ref as React.RefObject<HTMLDivElement>} className={`relative z-10 w-full px-6 md:px-10 lg:px-16 text-center anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}>
          <p className="text-orange text-xs md:text-sm font-semibold tracking-[0.25em] uppercase mb-5 animate-pulse">Limited Time Offers</p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 8vw, 7rem)' }}>
            Big Savings<br /><span className="text-orange">On Your Terms</span>
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-2xl mx-auto leading-relaxed mb-10">
            From storm prep to full roof replacements — grab a deal that fits your timeline and budget. Evansville's most trusted roofer since 1995.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="#offers" className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap">See Current Offers</a>
            <a href="tel:8122135997" className="border border-white/20 hover:border-white text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"><i className="ri-phone-line text-orange" />812-213-5997</a>
          </div>
        </div>
      </section>

      {/* Stats Banner */}
      <section className="bg-charcoal border-y border-white/10 py-10 px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {[
            { value: '$750', label: 'Max Seasonal Savings' },
            { value: '0%', label: 'Financing Available' },
            { value: '$250', label: 'Referral Reward' },
            { value: '5%', label: 'Military & Senior Off' },
          ].map((s) => (
            <div key={s.label}>
              <p className="font-display text-orange text-3xl md:text-4xl tracking-wider mb-1">{s.value}</p>
              <p className="text-white/50 text-xs uppercase tracking-wider">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Offers Grid */}
      <section id="offers" className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="mb-14 text-center">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-3">Current Promotions</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>Find Your Deal</h2>
          <p className="text-white/40 text-sm max-w-xl mx-auto">Every offer includes our industry-leading workmanship guarantee. Need help choosing? Give us a call and we'll help you pick the best deal.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {OFFERS.map((offer, i) => (
            <OfferCard key={offer.id} offer={offer} index={i} />
          ))}
        </div>
      </section>

      {/* Email Reminder Signup */}
      <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal border-y border-white/5">
        <div className="max-w-3xl mx-auto text-center">
          <div className="w-14 h-14 flex items-center justify-center bg-orange/15 text-orange mx-auto mb-5 rounded-full">
            <i className="ri-notification-3-line text-2xl" />
          </div>
          <h3 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wide mb-3">
            Don't Miss a Deadline
          </h3>
          <p className="text-white/40 text-sm max-w-lg mx-auto mb-8 leading-relaxed">
            Get an email reminder <strong className="text-white/60">48 hours before</strong> any seasonal offer you're interested in expires. Pick the deals you want to track — we'll ping you when the clock's ticking.
          </p>

          <EmailReminderForm />

          <RecentlyViewedOffers />
        </div>
      </section>

      {/* Limited Time Urgency */}
      <section className="py-16 md:py-24 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="border border-orange/20 bg-gradient-to-r from-orange/5 to-transparent p-8 md:p-12 max-w-3xl mx-auto text-center">
          <div className="w-14 h-14 flex items-center justify-center bg-orange/15 text-orange mx-auto mb-5"><i className="ri-timer-flash-line text-2xl" /></div>
          <h3 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wide mb-2">Seasonal Offers Are Closing</h3>
          <p className="text-white/40 text-xs mb-4">Next deadline approaching fast</p>
          <div className="flex justify-center mb-6">
            <CountdownTimer expiresAt="2026-07-31" variant="banner" />
          </div>
          <div className="flex justify-center mb-6">
            <SocialProofPulse />
          </div>
          <div className="space-y-1.5 mb-8 max-w-sm mx-auto">
            <div className="flex items-center justify-between text-xs">
              <span className="text-white/50">Storm Prep Package</span>
              <span className="text-red-400 font-semibold flex items-center gap-1">
                <span className="w-1 h-1 rounded-full bg-red-500 animate-pulse" />
                July 31
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-white/50">Summer Roof Special</span>
              <span className="text-red-400/70 font-semibold">Aug 31</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-white/50">Exterior Bundle</span>
              <span className="text-amber-400/70 font-semibold">Sep 30</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-white/50">Fall Gutter Package</span>
              <span className="text-amber-400/50 font-semibold">Nov 15</span>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button onClick={() => navigate('/estimate')} className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer">Get a Free Estimate</button>
            <a href="tel:8122135997" className="border border-white/20 hover:border-white text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"><i className="ri-phone-line text-orange" />812-213-5997</a>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="max-w-3xl mx-auto">
          <div className="mb-12 text-center">
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-3">Common Questions</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 3.5rem)' }}>Promotion Details</h2>
          </div>
          <div className="space-y-2">
            {FAQS.map((faq, i) => (
              <details key={i} className="group border border-white/10 bg-charcoal-mid">
                <summary className="flex items-center justify-between cursor-pointer p-5 md:p-6 text-white text-sm font-semibold hover:text-orange transition-colors">
                  {faq.q}
                  <i className="ri-arrow-down-s-line text-white/40 group-open:rotate-180 transition-transform text-lg flex-shrink-0 ml-3" />
                </summary>
                <div className="px-5 md:px-6 pb-5 md:pb-6">
                  <p className="text-white/50 text-sm leading-relaxed">{faq.a}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="pb-20 md:pb-28 px-6 md:px-10 lg:px-16">
        <div ref={ctaAnim.ref as React.RefObject<HTMLDivElement>} className={`anim-fade-up ${ctaAnim.isVisible ? 'is-visible' : ''} bg-charcoal-mid border border-white/5 p-10 md:p-16 lg:p-20 text-center`}>
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Don't Wait</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            The Best Deals<br /><span className="text-orange">Won't Last Forever</span>
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-lg mx-auto leading-relaxed mb-10">
            Claim your offer now. Free inspection, honest pricing, and the quality that's earned us 300+ five-star reviews.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button onClick={() => navigate('/estimate')} className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer">Claim Your Offer</button>
            <a href="tel:8122135997" className="border border-white/20 hover:border-white text-white font-semibold px-10 py-5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center gap-2"><i className="ri-phone-line text-orange" />812-213-5997</a>
          </div>
        </div>
      </section>

      {/* Floating Deal Expiring Soon */}
      <DealExpiringSoon offers={OFFERS} />
    </div>
  );
}