import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import PageSEO from '@/components/feature/PageSEO';
import DealExpiringSoon from '@/pages/promotions/components/DealExpiringSoon';

const serviceAreas = [
  {
    id: 'evansville',
    city: 'Evansville',
    state: 'IN',
    county: 'Vanderburgh County',
    tag: 'Headquarters',
    tagColor: 'bg-orange text-white',
    distance: 'Home Base',
    population: '117,000+',
    description: 'Our home base and primary service area. We have completed over 1,400 roofing projects in Evansville alone — from historic homes in the West Side to new construction in the East Side suburbs.',
    services: ['Residential Roofing', 'Commercial Roofing', 'Storm Damage', 'Gutters', 'Inspections', 'Emergency Repairs'],
    landmarks: ['USI Campus Area', 'Downtown Evansville', 'East Side', 'West Side', 'North Side', 'Haynie\'s Corner'],
    mapQuery: 'Evansville,+Indiana',
    lat: 37.9716,
    lng: -87.5711,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'newburgh',
    city: 'Newburgh',
    state: 'IN',
    county: 'Warrick County',
    tag: 'Top Area',
    tagColor: 'bg-white/10 text-white',
    distance: '12 mi from HQ',
    population: '3,400+',
    description: 'One of our most active service areas. Newburgh\'s mix of established neighborhoods and newer developments keeps our crews busy year-round, especially after hail season.',
    services: ['Residential Roofing', 'Metal Roofing', 'Storm Damage', 'Gutters', 'Inspections'],
    landmarks: ['Newburgh Historic District', 'Ohio River Greenway', 'Newburgh Elementary Area', 'Castle High School Area'],
    mapQuery: 'Newburgh,+Indiana',
    lat: 37.9445,
    lng: -87.4053,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'boonville',
    city: 'Boonville',
    state: 'IN',
    county: 'Warrick County',
    tag: 'Active Area',
    tagColor: 'bg-white/10 text-white',
    distance: '22 mi from HQ',
    population: '6,200+',
    description: 'Boonville homeowners trust us for everything from routine repairs to full storm damage replacements. We know the local building codes and work closely with Warrick County inspectors.',
    services: ['Residential Roofing', 'Roof Repair', 'Storm Damage', 'Gutters', 'Inspections'],
    landmarks: ['Boonville Historic Square', 'Warrick County Courthouse Area', 'Boonville High School Area'],
    mapQuery: 'Boonville,+Indiana',
    lat: 38.0492,
    lng: -87.2742,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'mount-vernon',
    city: 'Mount Vernon',
    state: 'IN',
    county: 'Posey County',
    tag: 'Active Area',
    tagColor: 'bg-white/10 text-white',
    distance: '25 mi from HQ',
    population: '6,900+',
    description: 'Serving Mount Vernon and all of Posey County. We handle both residential and agricultural roofing needs in this area, including metal barn roofs and large property estates.',
    services: ['Residential Roofing', 'Metal Roofing', 'Agricultural Roofing', 'Storm Damage', 'Gutters'],
    landmarks: ['Mount Vernon Historic District', 'Hovey Lake Area', 'Posey County Courthouse'],
    mapQuery: 'Mount+Vernon,+Indiana',
    lat: 37.9320,
    lng: -87.8978,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'princeton',
    city: 'Princeton',
    state: 'IN',
    county: 'Gibson County',
    tag: 'Expanding',
    tagColor: 'bg-white/10 text-white',
    distance: '30 mi from HQ',
    population: '8,600+',
    description: 'Growing our presence in Gibson County. Princeton homeowners get the same fast response times and quality workmanship as our core Evansville market.',
    services: ['Residential Roofing', 'Roof Repair', 'Storm Damage', 'Gutters', 'Inspections'],
    landmarks: ['Princeton Town Square', 'Gibson County Courthouse', 'Princeton Community High School Area'],
    mapQuery: 'Princeton,+Indiana',
    lat: 38.3556,
    lng: -87.5678,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'henderson',
    city: 'Henderson',
    state: 'KY',
    county: 'Henderson County',
    tag: 'Kentucky',
    tagColor: 'bg-white/10 text-white',
    distance: '15 mi from HQ',
    population: '28,000+',
    description: 'Just across the Ohio River, Henderson KY is a major part of our service territory. We are fully licensed in Kentucky and handle everything from downtown historic homes to new subdivisions.',
    services: ['Residential Roofing', 'Commercial Roofing', 'Storm Damage', 'Metal Roofing', 'Gutters', 'Inspections'],
    landmarks: ['Henderson Downtown', 'Audubon State Park Area', 'Henderson Community College Area', 'Wolf Hills'],
    mapQuery: 'Henderson,+Kentucky',
    lat: 37.8362,
    lng: -87.5900,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'owensboro',
    city: 'Owensboro',
    state: 'KY',
    county: 'Daviess County',
    tag: 'Kentucky',
    tagColor: 'bg-white/10 text-white',
    distance: '35 mi from HQ',
    population: '60,000+',
    description: 'Owensboro is our largest Kentucky market. We serve both residential neighborhoods and commercial properties throughout Daviess County with full crews dedicated to this area.',
    services: ['Residential Roofing', 'Commercial Roofing', 'Storm Damage', 'Metal Roofing', 'Gutters'],
    landmarks: ['Owensboro Downtown', 'Smothers Park Area', 'Owensboro Medical Health System Area', 'East Owensboro'],
    mapQuery: 'Owensboro,+Kentucky',
    lat: 37.7719,
    lng: -87.1112,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'jasper',
    city: 'Jasper',
    state: 'IN',
    county: 'Dubois County',
    tag: 'Expanding',
    tagColor: 'bg-white/10 text-white',
    distance: '45 mi from HQ',
    population: '15,000+',
    description: 'Expanding into Dubois County with full residential and commercial roofing services. Jasper\'s growing community and strong housing market make it a natural fit for our services.',
    services: ['Residential Roofing', 'Commercial Roofing', 'Roof Repair', 'Storm Damage', 'Gutters'],
    landmarks: ['Jasper Downtown', 'Dubois County Courthouse', 'Jasper High School Area', 'Riverwalk Area'],
    mapQuery: 'Jasper,+Indiana',
    lat: 38.3912,
    lng: -86.9311,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'greenville',
    city: 'Greenville',
    state: 'KY',
    county: 'Muhlenberg County',
    tag: 'Extended',
    tagColor: 'bg-white/10 text-white',
    distance: '55 mi from HQ',
    population: '4,300+',
    description: 'Serving Muhlenberg County with our extended range crews. Greenville homeowners get the same quality workmanship and honest pricing as our core market.',
    services: ['Residential Roofing', 'Roof Repair', 'Storm Damage', 'Gutters'],
    landmarks: ['Greenville Downtown', 'Muhlenberg County Courthouse', 'Greenville High School Area'],
    mapQuery: 'Greenville,+Kentucky',
    lat: 37.2014,
    lng: -87.1789,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'mount-carmel',
    city: 'Mount Carmel',
    state: 'IL',
    county: 'Wabash County',
    tag: 'Illinois',
    tagColor: 'bg-white/10 text-white',
    distance: '38 mi from HQ',
    population: '7,200+',
    description: 'Bringing our 25+ years of Tri-State roofing expertise to Illinois. Mount Carmel is our closest Illinois community and gets the same fast response times as our core Indiana market.',
    services: ['Residential Roofing', 'Roof Replacement', 'Storm Damage', 'Gutters', 'Emergency Repairs'],
    landmarks: ['Mount Carmel Downtown', 'Wabash County Courthouse', 'Wabash Riverfront', 'Mount Carmel High School Area'],
    mapQuery: 'Mount+Carmel,+Illinois',
    lat: 38.4103,
    lng: -87.7678,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'grayville',
    city: 'Grayville',
    state: 'IL',
    county: 'Edwards County',
    tag: 'Illinois',
    tagColor: 'bg-white/10 text-white',
    distance: '40 mi from HQ',
    population: '1,600+',
    description: 'Right on the Wabash River at I-64. Grayville is one of the most accessible Illinois towns from Evansville — just hop on the interstate and cross the bridge. Fast response, honest pricing.',
    services: ['Residential Roofing', 'Storm Damage', 'Gutters', 'Emergency Repairs'],
    landmarks: ['Grayville Downtown', 'Wabash Riverfront', 'I-64 Bridge Area', 'Grayville School Area'],
    mapQuery: 'Grayville,+Illinois',
    lat: 38.2575,
    lng: -87.9940,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'carmi',
    city: 'Carmi',
    state: 'IL',
    county: 'White County',
    tag: 'Illinois',
    tagColor: 'bg-white/10 text-white',
    distance: '50 mi from HQ',
    population: '5,200+',
    description: 'Serving Carmi and all of White County with full residential and commercial roofing services. White County homeowners get the same honest pricing and quality workmanship we are known for.',
    services: ['Residential Roofing', 'Roof Replacement', 'Storm Damage', 'Metal Roofing', 'Gutters'],
    landmarks: ['Carmi Downtown', 'White County Courthouse', 'Carmi Country Club Area', 'Rural White County Routes'],
    mapQuery: 'Carmi,+Illinois',
    lat: 38.0898,
    lng: -88.1588,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'lawrenceville',
    city: 'Lawrenceville',
    state: 'IL',
    county: 'Lawrence County',
    tag: 'Illinois',
    tagColor: 'bg-white/10 text-white',
    distance: '48 mi from HQ',
    population: '4,300+',
    description: 'Serving Lawrence County across the Embarras River valley. Lawrenceville homeowners get our 25+ years of Tri-State roofing expertise with fast response times via US 50.',
    services: ['Residential Roofing', 'Roof Replacement', 'Storm Damage', 'Gutters', 'Emergency Repairs'],
    landmarks: ['Lawrenceville Downtown', 'Lawrence County Courthouse', 'Embarras River Corridor', 'Red Hills State Park Area'],
    mapQuery: 'Lawrenceville,+Illinois',
    lat: 38.7292,
    lng: -87.6817,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'olney',
    city: 'Olney',
    state: 'IL',
    county: 'Richland County',
    tag: 'Illinois',
    tagColor: 'bg-white/10 text-white',
    distance: '60 mi from HQ',
    population: '8,700+',
    description: 'Our farthest Illinois market — Olney is Richland County\'s largest city and a regional hub. Homeowners and Olney Central College area properties get our full roofing services at extended range.',
    services: ['Residential Roofing', 'Roof Replacement', 'Storm Damage', 'Metal Roofing', 'Gutters'],
    landmarks: ['Olney Downtown', 'Olney Central College', 'Richland Memorial Hospital', 'East Fork Fox River Area'],
    mapQuery: 'Olney,+Illinois',
    lat: 38.7309,
    lng: -88.0853,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'fairfield',
    city: 'Fairfield',
    state: 'IL',
    county: 'Wayne County',
    tag: 'Illinois',
    tagColor: 'bg-white/10 text-white',
    distance: '55 mi from HQ',
    population: '5,100+',
    description: 'Serving Wayne County from our Evansville base. Fairfield is the county seat and a crossroads community — farmhouses, commercial buildings, and historic homes all get our honest pricing and quality roofing.',
    services: ['Residential Roofing', 'Roof Replacement', 'Storm Damage', 'Metal Roofing', 'Gutters'],
    landmarks: ['Fairfield Downtown', 'Wayne County Courthouse', 'Frontier Community College', 'Rural Wayne County Routes'],
    mapQuery: 'Fairfield,+Illinois',
    lat: 38.3789,
    lng: -88.3589,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'new-harmony',
    city: 'New Harmony',
    state: 'IN',
    county: 'Posey County',
    tag: 'Historic',
    tagColor: 'bg-white/10 text-white',
    distance: '28 mi from HQ',
    population: '689',
    description: 'Serving Indiana\'s most historic river town. We specialize in roofing that respects architectural heritage while providing modern protection for New Harmony\'s unique homes.',
    services: ['Residential Roofing', 'Historic Home Roofing', 'Storm Damage', 'Gutters'],
    landmarks: ['New Harmony Historic District', 'Wabash Riverfront', 'Main Street Corridor'],
    mapQuery: 'New+Harmony,+Indiana',
    lat: 38.1298,
    lng: -87.9350,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'fort-branch',
    city: 'Fort Branch',
    state: 'IN',
    county: 'Gibson County',
    tag: 'Growing',
    tagColor: 'bg-white/10 text-white',
    distance: '22 mi from HQ',
    population: '2,700+',
    description: 'Gibson County\'s growing residential community. Fort Branch homeowners trust us for honest pricing, fast storm response, and quality roofing that lasts.',
    services: ['Residential Roofing', 'Roof Replacement', 'Storm Damage', 'Gutters'],
    landmarks: ['Fort Branch Downtown', 'US 41 Corridor', 'Fort Branch School Area'],
    mapQuery: 'Fort+Branch,+Indiana',
    lat: 38.2512,
    lng: -87.5811,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'haubstadt',
    city: 'Haubstadt',
    state: 'IN',
    county: 'Gibson County',
    tag: 'Nearby',
    tagColor: 'bg-white/10 text-white',
    distance: '15 mi from HQ',
    population: '1,500+',
    description: 'Just minutes from Evansville. Haubstadt\'s German heritage community gets our fastest response times in Gibson County with same-day inspections available.',
    services: ['Residential Roofing', 'Storm Damage', 'Hail Repair', 'Gutters'],
    landmarks: ['Haubstadt Downtown', 'Gibson Southern HS Area', 'I-64 Corridor'],
    mapQuery: 'Haubstadt,+Indiana',
    lat: 38.2050,
    lng: -87.5742,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'darmstadt',
    city: 'Darmstadt',
    state: 'IN',
    county: 'Vanderburgh County',
    tag: 'Local',
    tagColor: 'bg-white/10 text-white',
    distance: '10 mi from HQ',
    population: '1,400+',
    description: 'Practically our backyard. Darmstadt receives our fastest response times — typically under 30 minutes for emergencies. We serve all the new subdivisions and established homes in this growing community.',
    services: ['Residential Roofing', 'New Construction', 'Storm Damage', 'Gutters'],
    landmarks: ['Darmstadt Town Center', 'North Green River Road', 'Kansas Road Area'],
    mapQuery: 'Darmstadt,+Indiana',
    lat: 38.0992,
    lng: -87.5790,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'petersburg',
    city: 'Petersburg',
    state: 'IN',
    county: 'Pike County',
    tag: 'Extended',
    tagColor: 'bg-white/10 text-white',
    distance: '45 mi from HQ',
    population: '2,300+',
    description: 'Expanding into Pike County. Petersburg homeowners get full roofing services backed by 25+ years of Tri-State experience — from storm damage to complete roof replacements.',
    services: ['Residential Roofing', 'Storm Damage', 'Roof Replacement', 'Gutters'],
    landmarks: ['Petersburg Downtown', 'Pike County Courthouse', 'SR 57 Corridor'],
    mapQuery: 'Petersburg,+Indiana',
    lat: 38.4920,
    lng: -87.2786,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'owensville',
    city: 'Owensville',
    state: 'IN',
    county: 'Gibson County',
    tag: 'Gibson',
    tagColor: 'bg-white/10 text-white',
    distance: '25 mi from HQ',
    population: '1,300+',
    description: 'Right on SR 65 in the heart of Gibson County. Owensville homeowners get the same fast response times and quality workmanship as our core Evansville market.',
    services: ['Residential Roofing', 'Storm Damage', 'Hail Repair', 'Gutters'],
    landmarks: ['Owensville Town Center', 'SR 65 Corridor', 'Gibson Southern School District'],
    mapQuery: 'Owensville,+Indiana',
    lat: 38.2720,
    lng: -87.6878,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'lynnville',
    city: 'Lynnville',
    state: 'IN',
    county: 'Warrick County',
    tag: 'Warrick',
    tagColor: 'bg-white/10 text-white',
    distance: '25 mi from HQ',
    population: '900+',
    description: 'Small Warrick County community. Lynnville homeowners and surrounding rural properties trust us for honest pricing and fast storm response.',
    services: ['Residential Roofing', 'Storm Damage', 'Hail Repair', 'Gutters'],
    landmarks: ['Lynnville Town Center', 'SR 68 Corridor', 'Rural Warrick County Routes'],
    mapQuery: 'Lynnville,+Indiana',
    lat: 38.1959,
    lng: -87.2967,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'elberfeld',
    city: 'Elberfeld',
    state: 'IN',
    county: 'Warrick County',
    tag: 'Nearby',
    tagColor: 'bg-white/10 text-white',
    distance: '18 mi from HQ',
    population: '650+',
    description: 'One of our closest Warrick County communities. Elberfeld homeowners get near-instant response times and full roofing services.',
    services: ['Residential Roofing', 'New Construction', 'Storm Damage', 'Gutters'],
    landmarks: ['Elberfeld Town Center', 'I-64 Corridor', 'German Ridge Road Area'],
    mapQuery: 'Elberfeld,+Indiana',
    lat: 38.1603,
    lng: -87.4481,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'cynthiana',
    city: 'Cynthiana',
    state: 'IN',
    county: 'Posey County',
    tag: 'Posey',
    tagColor: 'bg-white/10 text-white',
    distance: '25 mi from HQ',
    population: '550+',
    description: 'One of Posey County\'s oldest communities. Cynthiana homeowners trust us for quality roofing on historic farmhouses and newer homes alike.',
    services: ['Residential Roofing', 'Storm Damage', 'Metal Roofing', 'Gutters'],
    landmarks: ['Cynthiana Town Center', 'SR 68 Corridor', 'Posey County Rural Routes'],
    mapQuery: 'Cynthiana,+Indiana',
    lat: 38.1873,
    lng: -87.7100,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'dale',
    city: 'Dale',
    state: 'IN',
    county: 'Spencer County',
    tag: 'Extended',
    tagColor: 'bg-white/10 text-white',
    distance: '40 mi from HQ',
    population: '1,500+',
    description: 'At the I-64 and US 231 crossroads. Dale is a natural Spencer County gateway — homeowners get full residential roofing with our extended range crews.',
    services: ['Residential Roofing', 'Storm Damage', 'Metal Roofing', 'Gutters'],
    landmarks: ['Dale Town Center', 'I-64 Exit 57 Area', 'Spencer County Rural Routes'],
    mapQuery: 'Dale,+Indiana',
    lat: 38.1689,
    lng: -86.9900,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'santa-claus',
    city: 'Santa Claus',
    state: 'IN',
    county: 'Spencer County',
    tag: 'Extended',
    tagColor: 'bg-white/10 text-white',
    distance: '40 mi from HQ',
    population: '2,500+',
    description: 'Indiana\'s most famous small town. Santa Claus homeowners and Christmas Lake Village residents trust us for quality roofing backed by 25+ years of experience.',
    services: ['Residential Roofing', 'Storm Damage', 'Hail Repair', 'Gutters'],
    landmarks: ['Santa Claus Town Center', 'Christmas Lake Village', 'Holiday World Area'],
    mapQuery: 'Santa+Claus,+Indiana',
    lat: 38.1200,
    lng: -86.9211,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'ferdinand',
    city: 'Ferdinand',
    state: 'IN',
    county: 'Dubois County',
    tag: 'Extended',
    tagColor: 'bg-white/10 text-white',
    distance: '50 mi from HQ',
    population: '2,200+',
    description: 'Home to the iconic Monastery Immaculate Conception. Ferdinand homeowners get full roofing services — from historic preservation to modern replacements.',
    services: ['Residential Roofing', 'Historic Home Roofing', 'Storm Damage', 'Gutters'],
    landmarks: ['Ferdinand Town Center', 'Monastery Area', 'Ferdinand State Forest'],
    mapQuery: 'Ferdinand,+Indiana',
    lat: 38.2239,
    lng: -86.8619,
    image: '/placeholders/600x400.svg',
  },
  {
    id: 'huntingburg',
    city: 'Huntingburg',
    state: 'IN',
    county: 'Dubois County',
    tag: 'Extended',
    tagColor: 'bg-white/10 text-white',
    distance: '50 mi from HQ',
    population: '6,300+',
    description: 'One of Dubois County\'s largest cities with a thriving historic downtown. Huntingburg homeowners and businesses trust us for both residential and commercial roofing.',
    services: ['Residential Roofing', 'Commercial Roofing', 'Storm Damage', 'Metal Roofing', 'Gutters'],
    landmarks: ['Huntingburg Downtown', 'League Stadium', '4th Street Corridor', 'South Huntingburg'],
    mapQuery: 'Huntingburg,+Indiana',
    lat: 38.2989,
    lng: -86.9547,
    image: '/placeholders/600x400.svg',
  },
];

const stats = [
  { number: '50+', label: 'Mile Radius' },
  { number: '41', label: 'Cities Served' },
  { number: '3', label: 'States (IN, KY & IL)' },
  { number: '24hr', label: 'Response Time' },
];

function AreaCard({ area, isActive, onClick }: {
  area: typeof serviceAreas[0];
  isActive: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full text-left border transition-all duration-300 cursor-pointer group ${
        isActive
          ? 'border-orange bg-charcoal-mid'
          : 'border-white/10 bg-charcoal-mid hover:border-white/30'
      }`}
    >
      <div className="p-5 md:p-6">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className={`text-xs font-semibold px-2 py-0.5 uppercase tracking-wider ${area.tagColor}`}>
                {area.tag}
              </span>
              <span className="text-white/30 text-xs">{area.distance}</span>
            </div>
            <h3 className={`font-display text-xl md:text-2xl uppercase tracking-wider transition-colors ${isActive ? 'text-orange' : 'text-white group-hover:text-orange'}`}>
              {area.city}
            </h3>
            <p className="text-white/40 text-xs mt-0.5">{area.county}, {area.state}</p>
          </div>
          <div className={`w-8 h-8 flex items-center justify-center border flex-shrink-0 transition-all duration-300 ${isActive ? 'border-orange bg-orange text-white' : 'border-white/20 text-white/30 group-hover:border-orange group-hover:text-orange'}`}>
            <i className="ri-map-pin-line text-sm" />
          </div>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {area.services.slice(0, 3).map((s) => (
            <span key={s} className="text-white/30 text-xs bg-white/5 px-2 py-0.5">
              {s}
            </span>
          ))}
          {area.services.length > 3 && (
            <span className="text-white/30 text-xs bg-white/5 px-2 py-0.5">
              +{area.services.length - 3} more
            </span>
          )}
        </div>
      </div>
    </button>
  );
}

export default function ServiceAreasPage() {
  const navigate = useNavigate();
  const [activeArea, setActiveArea] = useState(serviceAreas[0]);
  const serviceAreasSchema = {
    '@context': 'https://schema.org',
    '@type': 'RoofingContractor',
    name: 'Corner Stone Construction & Roofing',
    telephone: '+1-812-213-5997',
    url: 'https://cornerstoneconstructionevansville.com',
    areaServed: serviceAreas.map((a) => ({
      '@type': 'City',
      name: a.city,
      containedInPlace: { '@type': 'State', name: a.state === 'IN' ? 'Indiana' : a.state === 'KY' ? 'Kentucky' : 'Illinois' },
    })),
  };
  const heroAnim = useScrollAnimation();
  const statsAnim = useScrollAnimation();
  const detailAnim = useScrollAnimation();
  const ctaAnim = useScrollAnimation();

  const mapEmbedUrl = `https://www.google.com/maps/embed/v1/place?key=AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY&q=${activeArea.mapQuery}&zoom=12`;

  return (
    <div className="min-h-screen bg-charcoal-deep">
      <PageSEO
        title="Roofing Service Areas | Evansville IN, Henderson KY, Mount Carmel IL & Tri-State"
        description="Corner Stone Construction & Roofing serves Evansville IN, Newburgh, Henderson KY, Mount Carmel IL, and the entire Tri-State area. Licensed in Indiana, Kentucky, and Illinois. Free inspections within 50 miles."
        keywords="roofing service areas Evansville Indiana, Newburgh roofing contractor, Henderson KY roofing, Mount Carmel IL roofing, Illinois roofing contractor, Tri-State roofing company, Vanderburgh County roofing"
        canonical="/service-areas"
        schema={serviceAreasSchema}
      />

      {/* ── Hero ── */}
      <section className="relative min-h-[60vh] md:min-h-[70vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/placeholders/1600x900.svg"
            alt="Service areas across Indiana and Kentucky"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-charcoal-deep" />
        </div>

        <div
          ref={heroAnim.ref as React.RefObject<HTMLDivElement>}
          className={`relative z-10 w-full px-6 md:px-10 lg:px-16 text-center anim-fade-up ${heroAnim.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs md:text-sm font-semibold tracking-[0.25em] uppercase mb-5">
            Indiana &amp; Kentucky &amp; Illinois
          </p>
          <h1 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(3rem, 8vw, 7rem)' }}>
            We Come<br />To You.<br /><span className="text-orange">Anywhere.</span>
          </h1>
          <p className="text-white/50 text-base md:text-lg max-w-2xl mx-auto leading-relaxed mb-10">
            Serving the entire Tri-State area — from Evansville to Henderson, Owensboro to Mount Carmel, Jasper to Carmi. If you are within 50 miles of Evansville, we have a crew for you.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="tel:8122135997"
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap flex items-center gap-2"
            >
              <i className="ri-phone-line" />
              Call 812-213-5997
            </a>
            <button
              onClick={() => navigate('/services')}
              className="border border-white/30 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap cursor-pointer"
            >
              View All Services
            </button>
          </div>
        </div>
      </section>

      {/* ── Stats Bar ── */}
      <section className="bg-charcoal border-y border-white/10 py-10 md:py-12 px-6 md:px-10 lg:px-16">
        <div
          ref={statsAnim.ref as React.RefObject<HTMLDivElement>}
          className={`grid grid-cols-2 lg:grid-cols-4 gap-8 text-center anim-fade-up ${statsAnim.isVisible ? 'is-visible' : ''}`}
        >
          {stats.map((stat, i) => (
            <div key={stat.label} className={`anim-fade-up ${statsAnim.isVisible ? 'is-visible' : ''}`} style={{ transitionDelay: `${i * 100}ms` }}>
              <p className="font-display text-orange text-4xl md:text-5xl uppercase tracking-wider mb-1">{stat.number}</p>
              <p className="text-white/40 text-xs uppercase tracking-wider">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Interactive Map + Area List ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="text-center mb-12 md:mb-16">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Select a Location</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Our Coverage Map
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Click any city below to explore our services in that area and see it on the map.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 md:gap-8">
          {/* Area List */}
          <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-3 max-h-[700px] overflow-y-auto pr-1">
            {serviceAreas.map((area) => (
              <AreaCard
                key={area.id}
                area={area}
                isActive={activeArea.id === area.id}
                onClick={() => setActiveArea(area)}
              />
            ))}
          </div>

          {/* Map + Detail Panel */}
          <div className="lg:col-span-3 flex flex-col gap-4">
            {/* Google Map Embed */}
            <div className="relative w-full h-[380px] md:h-[440px] overflow-hidden border border-white/10">
              <iframe
                key={activeArea.id}
                title={`Map of ${activeArea.city}, ${activeArea.state}`}
                src={mapEmbedUrl}
                width="100%"
                height="100%"
                style={{ border: 0, filter: 'grayscale(30%) invert(5%)' }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-full"
              />
              {/* Area label overlay */}
              <div className="absolute top-4 left-4 bg-charcoal-deep/90 backdrop-blur px-4 py-2 border border-white/10">
                <p className="text-white font-display text-lg uppercase tracking-wider">
                  {activeArea.city}, {activeArea.state}
                </p>
                <p className="text-white/40 text-xs">{activeArea.county}</p>
              </div>
            </div>

            {/* Detail Card */}
            <div
              ref={detailAnim.ref as React.RefObject<HTMLDivElement>}
              className="bg-charcoal-mid border border-white/10 p-6 md:p-8"
            >
              <div className="flex flex-col md:flex-row gap-6">
                {/* Area image */}
                <div className="w-full md:w-48 h-36 md:h-auto flex-shrink-0 overflow-hidden">
                  <img
                    key={activeArea.id}
                    src={activeArea.image}
                    alt={`${activeArea.city} roofing service area`}
                    className="w-full h-full object-cover object-top"
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-3">
                    <h3 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wider">
                      {activeArea.city}
                    </h3>
                    <span className={`text-xs font-semibold px-2 py-0.5 uppercase tracking-wider ${activeArea.tagColor}`}>
                      {activeArea.tag}
                    </span>
                  </div>
                  <p className="text-white/50 text-sm leading-relaxed mb-5">
                    {activeArea.description}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Services */}
                    <div>
                      <p className="text-white/30 text-xs uppercase tracking-wider mb-2">Services Available</p>
                      <div className="flex flex-wrap gap-1.5">
                        {activeArea.services.map((s) => (
                          <span key={s} className="text-orange text-xs border border-orange/30 bg-orange/10 px-2 py-0.5">
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Neighborhoods */}
                    <div>
                      <p className="text-white/30 text-xs uppercase tracking-wider mb-2">Areas We Cover</p>
                      <div className="flex flex-wrap gap-1.5">
                        {activeArea.landmarks.map((l) => (
                          <span key={l} className="text-white/40 text-xs bg-white/5 px-2 py-0.5">
                            {l}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 flex flex-col sm:flex-row gap-3">
                    <a
                      href="tel:8122135997"
                      className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-6 py-3 uppercase tracking-wide transition-colors whitespace-nowrap flex items-center justify-center gap-2"
                    >
                      <i className="ri-phone-line" />
                      Call for {activeArea.city}
                    </a>
                    <a
                      href={`https://www.google.com/maps/dir/?api=1&destination=${activeArea.mapQuery}`}
                      target="_blank"
                      rel="nofollow noreferrer"
                      className="border border-white/20 hover:border-white text-white text-sm font-semibold px-6 py-3 uppercase tracking-wide transition-colors whitespace-nowrap flex items-center justify-center gap-2"
                    >
                      <i className="ri-navigation-line" />
                      Get Directions
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── All Areas Grid ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div className="text-center mb-12 md:mb-16">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Full Coverage</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-4" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
            Every City.<br />Every Neighborhood.
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            We do not just serve the big cities — we cover the surrounding towns, rural routes, and everything in between.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
          {/* Indiana Column */}
          <div className="bg-charcoal-mid border border-white/5 p-8 md:p-10">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 flex items-center justify-center bg-orange/20 text-orange">
                <i className="ri-map-2-line text-lg" />
              </div>
              <div>
                <h3 className="font-display text-white text-2xl uppercase tracking-wider">Indiana</h3>
                <p className="text-white/30 text-xs">Primary Service State</p>
              </div>
            </div>
            <div className="space-y-3">
              {[
                { city: 'Evansville', county: 'Vanderburgh County', note: 'Headquarters', route: '/' },
                { city: 'Newburgh', county: 'Warrick County', note: '', route: '/locations/newburgh' },
                { city: 'Boonville', county: 'Warrick County', note: '', route: '/locations/boonville' },
                { city: 'Mount Vernon', county: 'Posey County', note: '', route: '/locations/mount-vernon' },
                { city: 'Princeton', county: 'Gibson County', note: '', route: '/locations/princeton' },
                { city: 'Jasper', county: 'Dubois County', note: '', route: '/locations/jasper' },
                { city: 'Vincennes', county: 'Knox County', note: 'Extended Range', route: '/locations/vincennes' },
                { city: 'Washington', county: 'Daviess County', note: 'Extended Range', route: '/locations/washington' },
                { city: 'Tell City', county: 'Perry County', note: 'Extended Range', route: '/locations/tell-city' },
                { city: 'Rockport', county: 'Spencer County', note: '', route: '/locations/rockport' },
                { city: 'Chandler', county: 'Warrick County', note: '', route: '/locations/chandler' },
                { city: 'New Harmony', county: 'Posey County', note: 'Historic', route: '/locations/new-harmony' },
                { city: 'Fort Branch', county: 'Gibson County', note: '', route: '/locations/fort-branch' },
                { city: 'Haubstadt', county: 'Gibson County', note: '', route: '/locations/haubstadt' },
                { city: 'Darmstadt', county: 'Vanderburgh County', note: 'Local', route: '/locations/darmstadt' },
                { city: 'Poseyville', county: 'Posey County', note: '', route: '/locations/poseyville' },
                { city: 'Oakland City', county: 'Gibson County', note: '', route: '/locations/oakland-city' },
                { city: 'Petersburg', county: 'Pike County', note: 'Extended Range', route: '/locations/petersburg' },
                { city: 'Owensville', county: 'Gibson County', note: '', route: '/locations/owensville' },
                { city: 'Lynnville', county: 'Warrick County', note: '', route: '/locations/lynnville' },
                { city: 'Elberfeld', county: 'Warrick County', note: 'Local', route: '/locations/elberfeld' },
                { city: 'Cynthiana', county: 'Posey County', note: '', route: '/locations/cynthiana' },
                { city: 'Dale', county: 'Spencer County', note: 'Extended Range', route: '/locations/dale' },
                { city: 'Santa Claus', county: 'Spencer County', note: 'Extended Range', route: '/locations/santa-claus' },
                { city: 'Ferdinand', county: 'Dubois County', note: 'Extended Range', route: '/locations/ferdinand' },
                { city: 'Huntingburg', county: 'Dubois County', note: 'Extended Range', route: '/locations/huntingburg' },
              ].map((item) => (
                <div key={item.city} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                  <div className="flex items-center gap-3">
                    <i className="ri-map-pin-2-line text-orange text-sm" />
                    <div>
                      {item.route ? (
                        <button
                          onClick={() => navigate(item.route!)}
                          className="text-white text-sm font-medium hover:text-orange transition-colors cursor-pointer"
                        >
                          {item.city}
                        </button>
                      ) : (
                        <span className="text-white text-sm font-medium">{item.city}</span>
                      )}
                      <span className="text-white/30 text-xs ml-2">{item.county}</span>
                    </div>
                  </div>
                  {item.note && (
                    <span className="text-white/30 text-xs bg-white/5 px-2 py-0.5 whitespace-nowrap">{item.note}</span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Kentucky Column */}
          <div className="bg-charcoal-mid border border-white/5 p-8 md:p-10">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 flex items-center justify-center bg-orange/20 text-orange">
                <i className="ri-map-2-line text-lg" />
              </div>
              <div>
                <h3 className="font-display text-white text-2xl uppercase tracking-wider">Kentucky</h3>
                <p className="text-white/30 text-xs">Fully Licensed in KY</p>
              </div>
            </div>
            <div className="space-y-3">
              {[
                { city: 'Henderson', county: 'Henderson County', note: 'Primary KY Market', route: '/locations/henderson-ky' },
                { city: 'Owensboro', county: 'Daviess County', note: '', route: '/locations/owensboro-ky' },
                { city: 'Madisonville', county: 'Hopkins County', note: '', route: '/locations/madisonville-ky' },
                { city: 'Morganfield', county: 'Union County', note: '', route: '/locations/morganfield-ky' },
                { city: 'Sturgis', county: 'Union County', note: '', route: '/locations/sturgis-ky' },
                { city: 'Providence', county: 'Webster County', note: '', route: '/locations/providence-ky' },
                { city: 'Sebree', county: 'Webster County', note: '', route: '/locations/sebree-ky' },
                { city: 'Calhoun', county: 'McLean County', note: '', route: '/locations/calhoun-ky' },
                { city: 'Livermore', county: 'McLean County', note: '', route: '/locations/livermore-ky' },
                { city: 'Beaver Dam', county: 'Ohio County', note: 'Extended Range', route: '/locations/beaver-dam-ky' },
                { city: 'Hartford', county: 'Ohio County', note: 'Extended Range', route: '/locations/hartford-ky' },
                { city: 'Greenville', county: 'Muhlenberg County', note: 'Extended Range', route: '/locations/greenville-ky' },
                { city: 'Central City', county: 'Muhlenberg County', note: 'Extended Range', route: '/locations/central-city-ky' },
                { city: 'Powderly', county: 'Muhlenberg County', note: 'Extended Range', route: '/locations/powderly-ky' },
                { city: 'Bremen', county: 'Muhlenberg County', note: 'Extended Range', route: '/locations/bremen-ky' },
              ].map((item) => (
                <div key={item.city} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                  <div className="flex items-center gap-3">
                    <i className="ri-map-pin-2-line text-orange text-sm" />
                    <div>
                      {item.route ? (
                        <button
                          onClick={() => navigate(item.route!)}
                          className="text-white text-sm font-medium hover:text-orange transition-colors cursor-pointer"
                        >
                          {item.city}
                        </button>
                      ) : (
                        <span className="text-white text-sm font-medium">{item.city}</span>
                      )}
                      <span className="text-white/30 text-xs ml-2">{item.county}</span>
                    </div>
                  </div>
                  {item.note && (
                    <span className="text-white/30 text-xs bg-white/5 px-2 py-0.5 whitespace-nowrap">{item.note}</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Illinois Row */}
        <div className="mt-6 md:mt-8">
          <div className="bg-charcoal-mid border border-white/5 p-8 md:p-10">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 flex items-center justify-center bg-orange/20 text-orange">
                <i className="ri-map-2-line text-lg" />
              </div>
              <div>
                <h3 className="font-display text-white text-2xl uppercase tracking-wider">Illinois</h3>
                <p className="text-white/30 text-xs">Expanding Across the Wabash</p>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { city: 'Mount Carmel', county: 'Wabash County', note: 'New IL Coverage', route: '/locations/mount-carmel-il' },
                { city: 'Grayville', county: 'Edwards County', note: 'New IL Coverage', route: '/locations/grayville-il' },
                { city: 'Carmi', county: 'White County', note: 'New IL Coverage', route: '/locations/carmi-il' },
                { city: 'Lawrenceville', county: 'Lawrence County', note: 'New IL Coverage', route: '/locations/lawrenceville-il' },
                { city: 'Olney', county: 'Richland County', note: 'New IL Coverage', route: '/locations/olney-il' },
                { city: 'Fairfield', county: 'Wayne County', note: 'New IL Coverage', route: '/locations/fairfield-il' },
              ].map((item) => (
                <div key={item.city} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                  <div className="flex items-center gap-3">
                    <i className="ri-map-pin-2-line text-orange text-sm" />
                    <div>
                      {item.route ? (
                        <button
                          onClick={() => navigate(item.route!)}
                          className="text-white text-sm font-medium hover:text-orange transition-colors cursor-pointer"
                        >
                          {item.city}
                        </button>
                      ) : (
                        <span className="text-white text-sm font-medium">{item.city}</span>
                      )}
                      <span className="text-white/30 text-xs ml-2">{item.county}</span>
                    </div>
                  </div>
                  {item.note && (
                    <span className="text-white/30 text-xs bg-white/5 px-2 py-0.5 whitespace-nowrap">{item.note}</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Not on the list CTA */}
        <div className="mt-8 bg-orange/10 border border-orange/20 p-6 md:p-8 text-center">
          <i className="ri-question-line text-orange text-2xl mb-3 block" />
          <h4 className="font-display text-white text-xl uppercase tracking-wider mb-2">Don't See Your City?</h4>
          <p className="text-white/50 text-sm mb-5 max-w-md mx-auto">
            We regularly travel beyond our listed areas for larger jobs. Give us a call — if we can get there, we will.
          </p>
          <a
            href="tel:8122135997"
            className="inline-flex items-center gap-2 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-3 uppercase tracking-wide text-sm transition-colors whitespace-nowrap"
          >
            <i className="ri-phone-line" />
            Call 812-213-5997
          </a>
        </div>
      </section>

      {/* ── Why Local Matters ── */}
      <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16 items-center">
          <div>
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-5">Why It Matters</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              We Know<br />These Towns.
            </h2>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-6">
              We are not a national chain dispatching strangers to your door. Our crews live in Evansville, Newburgh, and Henderson. We know the local building codes, the permit offices, the weather patterns, and the neighborhoods.
            </p>
            <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
              That local knowledge means faster permits, fewer surprises, and a crew that actually cares about the community they are working in.
            </p>
            <div className="space-y-4">
              {[
                { icon: 'ri-time-line', text: 'Same-day emergency response across all service areas' },
                { icon: 'ri-file-text-line', text: 'We handle all local permits and inspections' },
                { icon: 'ri-shield-check-line', text: 'Fully licensed and insured in Indiana, Kentucky, and Illinois' },
                { icon: 'ri-team-line', text: 'Local crews — not subcontractors from out of state' },
              ].map((item) => (
                <div key={item.text} className="flex items-start gap-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-orange/20 text-orange flex-shrink-0 mt-0.5">
                    <i className={`${item.icon} text-sm`} />
                  </div>
                  <p className="text-white/60 text-sm leading-relaxed">{item.text}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="w-full h-[420px] md:h-[520px] overflow-hidden">
              <img
                src="/placeholders/700x520.svg"
                alt="Corner Stone roofing crew serving Indiana and Kentucky"
                className="w-full h-full object-cover object-top"
              />
            </div>
            <div className="absolute bottom-6 left-6 right-6 bg-charcoal-deep/90 backdrop-blur border border-white/10 p-5">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 flex items-center justify-center bg-orange/20 text-orange flex-shrink-0">
                  <i className="ri-map-pin-line text-xl" />
                </div>
                <div>
                  <p className="text-white font-semibold text-sm">Based in Evansville, IN</p>
                  <p className="text-white/40 text-xs">5800 Kansas Rd, Evansville, IN 47725</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Final CTA ── */}
      <section id="contact" className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal">
        <div
          ref={ctaAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${ctaAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="bg-charcoal-mid border border-white/5 p-10 md:p-16 lg:p-20 text-center">
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 6vw, 5rem)' }}>
              In Our Area?<br /><span className="text-orange">Let's Talk.</span>
            </h2>
            <p className="text-white/40 text-sm md:text-base max-w-lg mx-auto leading-relaxed mb-10">
              Free inspections available across all service areas. We will come to you, assess your roof, and give you an honest quote — no pressure, no obligation.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="tel:8122135997"
                className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-phone-line" />
                Call 812-213-5997
              </a>
              <button
                onClick={() => navigate('/services')}
                className="border border-white/20 hover:border-white text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap cursor-pointer"
              >
                View Our Services
              </button>
            </div>
          </div>
        </div>
      </section>

      <DealExpiringSoon linkToPage={true} />
    </div>
  );
}