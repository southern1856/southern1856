export const SHINGLE_COLOR_PALETTES = [
  {
    key: 'three_tab',
    name: '3-Tab Asphalt',
    accentColor: '#6B7280',
    description: 'Classic flat profile, uniform color coverage',
    textureImage: '/placeholders/600x400.svg',
    colors: [
      { name: 'Onyx Black', hex: '#1a1a1a', sku: '3TAB-BLK' },
      { name: 'Charcoal Gray', hex: '#4a4a4a', sku: '3TAB-GRY' },
      { name: 'Weathered Wood', hex: '#7a6b5a', sku: '3TAB-WDW' },
      { name: 'Autumn Brown', hex: '#5c4033', sku: '3TAB-BRN' },
      { name: 'Driftwood', hex: '#8b7355', sku: '3TAB-DRF' },
      { name: 'Slate', hex: '#505a64', sku: '3TAB-SLT' },
      { name: 'Harbor Blue', hex: '#3d5a73', sku: '3TAB-BLU' },
      { name: 'Barkwood', hex: '#6b5344', sku: '3TAB-BRK' },
    ],
  },
  {
    key: 'architectural',
    name: 'Architectural Laminated',
    accentColor: '#F97316',
    description: 'Dimensional shadow lines with rich color blending',
    textureImage: '/placeholders/600x400.svg',
    colors: [
      { name: 'Pewter Gray', hex: '#6b6b6b', sku: 'ARCH-PGW' },
      { name: 'Heather Blend', hex: '#7a6e60', sku: 'ARCH-HBL' },
      { name: 'Hickory', hex: '#8b6f47', sku: 'ARCH-HCK' },
      { name: 'Barkwood', hex: '#5c4a3a', sku: 'ARCH-BRK' },
      { name: 'Slatestone Gray', hex: '#5a5a5a', sku: 'ARCH-SLG' },
      { name: 'Mission Brown', hex: '#6b4226', sku: 'ARCH-MBR' },
      { name: 'Shakewood', hex: '#a0855a', sku: 'ARCH-SKW' },
      { name: 'Charcoal', hex: '#3a3a3a', sku: 'ARCH-CHR' },
      { name: 'Sierra Gray', hex: '#7a7a72', sku: 'ARCH-SGR' },
      { name: 'Weathered Wood', hex: '#8a7b6a', sku: 'ARCH-WWD' },
      { name: 'Aged Copper', hex: '#8b6b4a', sku: 'ARCH-ACP' },
      { name: 'Tuscan Sunset', hex: '#8b5a3a', sku: 'ARCH-TUS' },
      { name: 'Colonial Slate', hex: '#4a5560', sku: 'ARCH-COL' },
      { name: 'Midnight Black', hex: '#1f1f1f', sku: 'ARCH-MBK' },
      { name: 'Shadow Gray', hex: '#5a5a5a', sku: 'ARCH-SHG' },
      { name: 'Hunter Green', hex: '#3a4a3a', sku: 'ARCH-HGR' },
      { name: 'Patriot Red', hex: '#6b2a2a', sku: 'ARCH-PAT' },
      { name: 'Harbor Fog', hex: '#6a7a7a', sku: 'ARCH-HFG' },
    ],
  },
  {
    key: 'premium',
    name: 'Designer / Luxury',
    accentColor: '#1F2937',
    description: 'Handcrafted appearance mimicking natural materials',
    textureImage: '/placeholders/600x400.svg',
    colors: [
      { name: 'Emerald Bay', hex: '#2a3a3a', sku: 'PREM-EMB' },
      { name: 'Natural Shadow', hex: '#4a4a42', sku: 'PREM-NAS' },
      { name: 'Carriage House', hex: '#5a4a3a', sku: 'PREM-CHS' },
      { name: 'Stonegate Gray', hex: '#6a6a6a', sku: 'PREM-STG' },
      { name: 'Cottage Red', hex: '#7a3a2a', sku: 'PREM-CRE' },
      { name: 'Sienna', hex: '#8b6a4a', sku: 'PREM-SIE' },
      { name: 'Black Oak', hex: '#1e1e1e', sku: 'PREM-BOK' },
      { name: 'Georgetown Gray', hex: '#5a5a5a', sku: 'PREM-GTG' },
      { name: 'Canyon Clay', hex: '#8b6b5a', sku: 'PREM-CCL' },
      { name: 'Mountain Sage', hex: '#4a5a4a', sku: 'PREM-MTS' },
      { name: 'Woodland', hex: '#5a4a3a', sku: 'PREM-WDL' },
      { name: 'Chalet Wood', hex: '#8b7b5a', sku: 'PREM-CHW' },
      { name: 'Birchwood', hex: '#a09070', sku: 'PREM-BRW' },
      { name: 'Concord', hex: '#5a5a6a', sku: 'PREM-CNC' },
      { name: 'Cedar Falls', hex: '#8b7b6a', sku: 'PREM-CDF' },
      { name: 'Slatestone', hex: '#4a4a4a', sku: 'PREM-SLS' },
      { name: 'Warm Amber', hex: '#9a7b4a', sku: 'PREM-WAM' },
      { name: 'Storm Cloud', hex: '#4a4a50', sku: 'PREM-SCL' },
      { name: 'Rustic Brown', hex: '#6b4a3a', sku: 'PREM-RBR' },
      { name: 'Highland', hex: '#5a5a4a', sku: 'PREM-HLD' },
      { name: 'Dover', hex: '#6a6a6a', sku: 'PREM-DOV' },
      { name: 'Cypress', hex: '#4a5a4a', sku: 'PREM-CYP' },
      { name: 'Autumn Canyon', hex: '#8b6b4a', sku: 'PREM-AUC' },
      { name: 'Midnight Plum', hex: '#3a2a3a', sku: 'PREM-MPM' },
    ],
  },
] as const;

export const SHINGLE_ROOF_PREVIEWS = {
  three_tab: {
    houseImage: '/placeholders/800x500.svg',
  },
  architectural: {
    houseImage: '/placeholders/800x500.svg',
  },
  premium: {
    houseImage: '/placeholders/800x500.svg',
  },
};

export type ShinglePaletteType = typeof SHINGLE_COLOR_PALETTES[number];
export type ShingleColor = ShinglePaletteType['colors'][number];

export const COLOR_PAIRINGS: Record<string, {
  siding: Array<{ name: string; hex: string; vibe: string }>;
  trim: Array<{ name: string; hex: string; accent: string }>;
  accent: Array<{ name: string; hex: string; use: string }>;
  mood: string;
  description: string;
}> = {
  '3TAB-BLK': {
    siding: [
      { name: 'Warm White', hex: '#f5f0e8', vibe: 'Classic contrast' },
      { name: 'Greige', hex: '#b8ada0', vibe: 'Modern farmhouse' },
      { name: 'Slate Blue', hex: '#4a5a6a', vibe: 'Coastal cool' },
    ],
    trim: [
      { name: 'Bright White', hex: '#ffffff', accent: 'Clean definition' },
      { name: 'Iron Black', hex: '#2a2a2a', accent: 'Monochrome drama' },
      { name: 'Soft Gray', hex: '#9a9a9a', accent: 'Subtle separation' },
    ],
    accent: [
      { name: 'Crimson Red', hex: '#8b2323', use: 'Front door pop' },
      { name: 'Oil-Rubbed Bronze', hex: '#5c4033', use: 'Hardware & gutters' },
    ],
    mood: 'Bold & Timeless',
    description: 'A black roof is the ultimate neutral — it makes light siding glow and gives dark siding depth. Works with virtually every architectural style.',
  },
  '3TAB-GRY': {
    siding: [
      { name: 'Navy Blue', hex: '#1e3a5f', vibe: 'Nautical authority' },
      { name: 'Warm Beige', hex: '#d4c5a9', vibe: 'Subtle warmth' },
      { name: 'Charcoal', hex: '#3a3a3a', vibe: 'Urban edge' },
    ],
    trim: [
      { name: 'Pure White', hex: '#fafafa', accent: 'Crisp contrast' },
      { name: 'Storm Gray', hex: '#7a7a7a', accent: 'Tonal harmony' },
      { name: 'Black', hex: '#1a1a1a', accent: 'Graphic punch' },
    ],
    accent: [
      { name: 'Teal', hex: '#2a6b6b', use: 'Shutters or door' },
      { name: 'Copper', hex: '#b87333', use: 'Downspouts & lights' },
    ],
    mood: 'Versatile & Grounded',
    description: 'Charcoal gray is the most popular roof color in America for a reason — it plays nicely with warm and cool siding tones alike.',
  },
  '3TAB-WDW': {
    siding: [
      { name: 'Cream', hex: '#e8dcc8', vibe: 'Soft warmth' },
      { name: 'Sage Green', hex: '#7a8a6a', vibe: 'Earthy natural' },
      { name: 'Terracotta', hex: '#c4956a', vibe: 'Rustic charm' },
    ],
    trim: [
      { name: 'Ivory White', hex: '#f0ead6', accent: 'Gentle glow' },
      { name: 'Dark Walnut', hex: '#4a3728', accent: 'Woodsy frame' },
      { name: 'Warm Taupe', hex: '#a09080', accent: 'Seamless blend' },
    ],
    accent: [
      { name: 'Hunter Green', hex: '#2a4a2a', use: 'Shutters & landscaping' },
      { name: 'Burnished Gold', hex: '#b5a642', use: 'Porch fixtures' },
    ],
    mood: 'Warm & Inviting',
    description: 'Weathered wood brown brings an organic warmth that pairs beautifully with greens, creams, and earth tones. Ideal for craftsman and cottage styles.',
  },
  '3TAB-BRN': {
    siding: [
      { name: 'Warm White', hex: '#f0e8d8', vibe: 'Clean contrast' },
      { name: 'Olive', hex: '#6a5a3a', vibe: 'Natural blend' },
      { name: 'Tan', hex: '#c8b898', vibe: 'Monochromatic' },
    ],
    trim: [
      { name: 'Cream', hex: '#ede4d3', accent: 'Soft border' },
      { name: 'Dark Chocolate', hex: '#3a2a1a', accent: 'Bold frame' },
      { name: 'Sand', hex: '#c4b89a', accent: 'Neutral transition' },
    ],
    accent: [
      { name: 'Forest Green', hex: '#1a3a1a', use: 'Shutters & door' },
      { name: 'Antique Brass', hex: '#c4a35a', use: 'Hardware accents' },
    ],
    mood: 'Earthy & Rich',
    description: 'Deep brown creates a warm, grounded palette. Best with light siding to create definition and avoid a too-dark overall look.',
  },
  'ARCH-PGW': {
    siding: [
      { name: 'Bright White', hex: '#f8f6f2', vibe: 'Crisp & clean' },
      { name: 'Soft Blue', hex: '#7a9aaa', vibe: 'Coastal calm' },
      { name: 'Warm Gray', hex: '#a8a098', vibe: 'Sophisticated neutral' },
    ],
    trim: [
      { name: 'Bright White', hex: '#ffffff', accent: 'Maximum contrast' },
      { name: 'Light Gray', hex: '#c4c4c4', accent: 'Soft edge' },
      { name: 'Slate', hex: '#5a5a5a', accent: 'Defined border' },
    ],
    accent: [
      { name: 'Navy Blue', hex: '#1a2a4a', use: 'Front door statement' },
      { name: 'Brushed Nickel', hex: '#b0b0b0', use: 'Modern hardware' },
    ],
    mood: 'Modern & Clean',
    description: 'Pewter Gray is Mike\'s top pick for a reason — it brightens white siding, softens bold colors, and looks consistently good in every light condition.',
  },
  'ARCH-HBL': {
    siding: [
      { name: 'Cream', hex: '#ede4d3', vibe: 'Soft warmth' },
      { name: 'Taupe', hex: '#a89880', vibe: 'Neutral blend' },
      { name: 'Light Green', hex: '#8a9a7a', vibe: 'Natural harmony' },
    ],
    trim: [
      { name: 'Ivory', hex: '#f5f0e6', accent: 'Warm border' },
      { name: 'Walnut', hex: '#5a4a3a', accent: 'Earthy frame' },
      { name: 'Stone', hex: '#9a8a7a', accent: 'Neutral transition' },
    ],
    accent: [
      { name: 'Brick Red', hex: '#8b3a3a', use: 'Door or planters' },
      { name: 'Wrought Iron', hex: '#3a3a3a', use: 'Railings & lights' },
    ],
    mood: 'Natural & Balanced',
    description: 'Heather Blend is a chameleon — it picks up warm or cool tones from siding depending on the season, giving your home a subtly shifting personality.',
  },
  'ARCH-HCK': {
    siding: [
      { name: 'Warm White', hex: '#f2ece2', vibe: 'Creamy contrast' },
      { name: 'Beige', hex: '#d4c4a4', vibe: 'Soft neutral' },
      { name: 'Olive', hex: '#6a6a4a', vibe: 'Tonal blend' },
    ],
    trim: [
      { name: 'Cream', hex: '#f0e8d6', accent: 'Warm definition' },
      { name: 'Dark Brown', hex: '#3a2a1a', accent: 'Rich frame' },
      { name: 'Tan', hex: '#c8b890', accent: 'Subtle edge' },
    ],
    accent: [
      { name: 'Forest Green', hex: '#2a3a2a', use: 'Shutters & door' },
      { name: 'Antique Gold', hex: '#c4a85a', use: 'Porch fixtures' },
    ],
    mood: 'Warm & Traditional',
    description: 'Hickory\'s golden warmth makes it perfect for homes with warm-toned brick, stone, or wood accents. It glows in late afternoon light.',
  },
  'ARCH-CHR': {
    siding: [
      { name: 'Cool White', hex: '#f0f0f0', vibe: 'Modern stark' },
      { name: 'Navy', hex: '#1a2a4a', vibe: 'Dramatic pairing' },
      { name: 'Silver Gray', hex: '#a0a0a0', vibe: 'Tonal cool' },
    ],
    trim: [
      { name: 'Bright White', hex: '#ffffff', accent: 'Sharp contrast' },
      { name: 'Charcoal', hex: '#4a4a4a', accent: 'Monochrome' },
      { name: 'Black', hex: '#1a1a1a', accent: 'Bold frame' },
    ],
    accent: [
      { name: 'Red', hex: '#8b1a1a', use: 'Front door pop' },
      { name: 'Stainless', hex: '#a0a0a0', use: 'Modern hardware' },
    ],
    mood: 'Sleek & Contemporary',
    description: 'Charcoal is the modern homeowner\'s go-to. It pairs with clean whites for a Scandinavian look or deep navies for a moody, upscale feel.',
  },
  'ARCH-SGR': {
    siding: [
      { name: 'White', hex: '#f5f5f5', vibe: 'Clean slate' },
      { name: 'Pale Blue', hex: '#8a9aaa', vibe: 'Soft contrast' },
      { name: 'Greige', hex: '#b0a898', vibe: 'Neutral blend' },
    ],
    trim: [
      { name: 'White', hex: '#ffffff', accent: 'Fresh border' },
      { name: 'Medium Gray', hex: '#8a8a8a', accent: 'Tonal edge' },
      { name: 'Dove', hex: '#b8b8b8', accent: 'Soft frame' },
    ],
    accent: [
      { name: 'Cobalt', hex: '#3a5a8a', use: 'Door or shutters' },
      { name: 'Pewter', hex: '#7a7a7a', use: 'Hardware & gutters' },
    ],
    mood: 'Soft & Airy',
    description: 'Sierra Gray is lighter than Pewter, making it ideal for homes in sunny climates or where you want a softer overall look without going too light.',
  },
  'ARCH-MBK': {
    siding: [
      { name: 'Cool White', hex: '#f0f0f0', vibe: 'Stark contrast' },
      { name: 'Light Gray', hex: '#c8c8c8', vibe: 'Soft contrast' },
      { name: 'Cream', hex: '#e8dcc8', vibe: 'Warm glow' },
    ],
    trim: [
      { name: 'White', hex: '#ffffff', accent: 'Maximum pop' },
      { name: 'Black', hex: '#1a1a1a', accent: 'Bold frame' },
      { name: 'Silver', hex: '#b0b0b0', accent: 'Cool edge' },
    ],
    accent: [
      { name: 'Cherry Red', hex: '#9b1a1a', use: 'Statement door' },
      { name: 'Bright Gold', hex: '#d4af37', use: 'House numbers & lights' },
    ],
    mood: 'Dramatic & Bold',
    description: 'Midnight Black is pure drama. It demands light siding to avoid a cave-like exterior, but the payoff is an undeniably striking, high-contrast curb appeal.',
  },
  'PREM-STG': {
    siding: [
      { name: 'White', hex: '#f5f5f0', vibe: 'Classic luxury' },
      { name: 'Soft Gray', hex: '#b8b8b0', vibe: 'Understated elegance' },
      { name: 'Pale Blue', hex: '#8a9aaa', vibe: 'Serene estate' },
    ],
    trim: [
      { name: 'Bright White', hex: '#ffffff', accent: 'Crisp luxury' },
      { name: 'Light Gray', hex: '#c0c0c0', accent: 'Subtle refinement' },
      { name: 'Charcoal', hex: '#4a4a4a', accent: 'Defined edge' },
    ],
    accent: [
      { name: 'Deep Navy', hex: '#1a2a4a', use: 'Front door elegance' },
      { name: 'Brushed Steel', hex: '#a8a8a8', use: 'Premium hardware' },
    ],
    mood: 'Elegant & Refined',
    description: 'Stonegate Gray is the premium choice for a reason — it reads as expensive from the street, hides imperfections beautifully, and elevates any siding color.',
  },
  'PREM-BOK': {
    siding: [
      { name: 'Warm White', hex: '#f0e8d8', vibe: 'Creamy glow' },
      { name: 'Beige', hex: '#d0c0a0', vibe: 'Soft neutral' },
      { name: 'Olive', hex: '#5a6a4a', vibe: 'Tonal blend' },
    ],
    trim: [
      { name: 'Ivory', hex: '#f5f0e0', accent: 'Warm border' },
      { name: 'Dark Walnut', hex: '#3a2a1a', accent: 'Rich frame' },
      { name: 'Taupe', hex: '#a09888', accent: 'Neutral edge' },
    ],
    accent: [
      { name: 'Hunter Green', hex: '#1a3a1a', use: 'Shutters & landscaping' },
      { name: 'Burnished Copper', hex: '#b87333', use: 'Premium fixtures' },
    ],
    mood: 'Sophisticated & Dark',
    description: 'Black Oak is the darkest premium option. It creates a gallery-like frame for your home — everything else becomes the artwork. Use with confidence on light siding only.',
  },
  'PREM-CCL': {
    siding: [
      { name: 'Cream', hex: '#ede4d3', vibe: 'Warm foundation' },
      { name: 'Warm White', hex: '#f5ede0', vibe: 'Soft glow' },
      { name: 'Sage', hex: '#8a9a7a', vibe: 'Natural blend' },
    ],
    trim: [
      { name: 'Cream', hex: '#f0e8d6', accent: 'Soft definition' },
      { name: 'Walnut', hex: '#5a4a3a', accent: 'Woodsy frame' },
      { name: 'Sand', hex: '#c4b898', accent: 'Neutral edge' },
    ],
    accent: [
      { name: 'Terracotta', hex: '#c4784a', use: 'Door & planters' },
      { name: 'Bronze', hex: '#8b6914', use: 'Fixtures & railings' },
    ],
    mood: 'Warm & Earthy',
    description: 'Canyon Clay brings desert warmth that pairs beautifully with Southwestern and Mediterranean architecture. It\'s unexpected and memorable.',
  },
  'PREM-MTS': {
    siding: [
      { name: 'Warm White', hex: '#f0ece0', vibe: 'Natural glow' },
      { name: 'Beige', hex: '#d4c8a8', vibe: 'Soft earth' },
      { name: 'Stone', hex: '#b0a890', vibe: 'Tonal blend' },
    ],
    trim: [
      { name: 'Ivory', hex: '#f5f0e0', accent: 'Warm border' },
      { name: 'Dark Green', hex: '#2a3a2a', accent: 'Nature frame' },
      { name: 'Tan', hex: '#c8b890', accent: 'Neutral edge' },
    ],
    accent: [
      { name: 'Forest Green', hex: '#1a3a1a', use: 'Shutters & door' },
      { name: 'Rust', hex: '#8b4513', use: 'Porch fixtures' },
    ],
    mood: 'Natural & Serene',
    description: 'Mountain Sage is perfect for homes surrounded by trees or landscaping. It literally blends with nature while still giving your roof visual weight.',
  },
};

// Fallback palette for colors not in the curated list above
export const DEFAULT_PAIRING = {
  siding: [
    { name: 'Warm White', hex: '#f5f0e8', vibe: 'Classic safe choice' },
    { name: 'Soft Gray', hex: '#b8b8b0', vibe: 'Modern neutral' },
    { name: 'Beige', hex: '#d4c8a8', vibe: 'Warm & versatile' },
  ],
  trim: [
    { name: 'Bright White', hex: '#ffffff', accent: 'Clean & crisp' },
    { name: 'Warm Cream', hex: '#ede4d3', accent: 'Soft glow' },
    { name: 'Medium Gray', hex: '#9a9a9a', accent: 'Tonal balance' },
  ],
  accent: [
    { name: 'Navy Blue', hex: '#1a2a4a', use: 'Classic door color' },
    { name: 'Forest Green', hex: '#2a4a2a', use: 'Nature accent' },
  ],
  mood: 'Versatile & Balanced',
  description: 'This color is versatile enough to pair with a wide range of siding and trim options. White, cream, and gray are always safe bets that let the roof do the talking.',
};