export interface AlexTopicResponse {
  id: string;
  label: string;
  text: string;
  actions?: {
    label: string;
    type: 'link' | 'phone' | 'input' | 'form';
    href?: string;
    phone?: string;
  }[];
}

export interface AlexKeywordMatch {
  keywords: string[];
  response: AlexTopicResponse;
}

export const alexTopicResponses: Record<string, AlexTopicResponse> = {
  '/free-inspection': {
    id: 'free-inspection',
    label: 'Free Roof Inspection',
    text: "A free inspection is the best place to start — no cost, no pressure. We'll check every inch of your roof, take photos, and tell you exactly what you're dealing with. You'll get a full report with our honest recommendation. Most folks are surprised how much peace of mind 30 minutes gives them.",
    actions: [
      { label: 'Book Inspection Now', type: 'link', href: '/free-inspection' },
      { label: 'What to Expect', type: 'link', href: '/free-inspection' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  '/estimate': {
    id: 'estimate',
    label: 'Get an Estimate',
    text: "We're happy to give you a free, no-obligation estimate for any roofing, gutter, or siding project. Just snap a few photos of your home and we'll get back to you within 24 hours with real numbers — not a ballpark. No surprises, just solid work.",
    actions: [
      { label: 'Start Free Estimate', type: 'link', href: '/estimate' },
      { label: 'See Our Pricing', type: 'link', href: '/roof-estimator' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  '/storm-damage': {
    id: 'storm-damage',
    label: 'Storm Damage Help',
    text: "Storm damage doesn't wait, and neither do we. We offer same-day emergency tarping and free storm inspections after severe weather. If you've got leaks, missing shingles, or dented gutters, give us a call. We'll even help you navigate the insurance paperwork so nothing gets missed.",
    actions: [
      { label: 'Get Emergency Help', type: 'link', href: '/emergency-services' },
      { label: 'Storm Damage Guide', type: 'link', href: '/storm-damage' },
      { label: 'Call Now — 24/7', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  '/insurance-claims': {
    id: 'insurance-claims',
    label: 'Insurance Questions',
    text: "We work directly with all major insurance companies and handle the claim paperwork for you. From damage documentation to meeting the adjuster on your roof, we'll make sure your claim gets the coverage it deserves. Most of our insurance customers pay nothing beyond their deductible.",
    actions: [
      { label: 'Insurance Help', type: 'link', href: '/insurance-claims' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
      { label: 'Free Inspection', type: 'link', href: '/free-inspection' },
    ],
  },
  'tel:8122135997': {
    id: 'phone',
    label: 'Talk to a Human',
    text: "Our team is standing by and ready to help. Call us at (812) 213-5997 — we answer Monday through Friday 7am to 6pm, and Saturday 8am to 2pm. For emergencies, call anytime. We've got crews on standby 24/7.",
    actions: [
      { label: 'Call Now', type: 'phone', phone: 'tel:8122135997' },
      { label: 'Request Callback', type: 'form' },
      { label: 'Free Inspection', type: 'link', href: '/free-inspection' },
    ],
  },
  'roof-materials': {
    id: 'roof-materials',
    label: 'Roof Materials',
    text: "For Evansville homes, most folks go with architectural shingles — they last 25–30 years, run $7–$12 per sq ft, and handle Indiana wind and hail better than basic 3-tabs. Metal roofing is the long-term champ at $12–$20 per sq ft — it lasts 40–70 years, reflects summer heat, and shrugs off hail. We install GAF, CertainTeed, and Owens Corning, all with manufacturer-backed warranties.",
    actions: [
      { label: 'Compare All Materials', type: 'link', href: '/roof-comparison' },
      { label: 'Get Material Quote', type: 'link', href: '/roof-estimator' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'how-long': {
    id: 'how-long',
    label: 'How Long Does It Take?',
    text: "Most roof replacements take 1 to 3 days. A typical 1,500 sq ft home with asphalt shingles? Usually wrapped up in a single day. Bigger homes or complex roofs with valleys and dormers might take 2–3 days. We give you a firm timeline during your estimate and we stick to it. Weather is the main wildcard, but we watch the forecast like hawks.",
    actions: [
      { label: 'Get a Timeline Quote', type: 'link', href: '/estimate' },
      { label: 'See Our Process', type: 'link', href: '/residential-roofing' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'insurance-coverage': {
    id: 'insurance-coverage',
    label: 'Will Insurance Pay?',
    text: "Homeowners insurance typically covers sudden damage from hail, wind, fallen trees, and fire. It won't cover normal wear and tear or an old roof that's just aged out. Your deductible applies — usually $1,000 to $2,500. Here's the key: don't call your insurance first. Let us inspect and document everything with photos first, then we meet the adjuster on-site to make sure nothing is missed. We handle the whole process.",
    actions: [
      { label: 'Insurance Claims Guide', type: 'link', href: '/insurance-claims' },
      { label: 'Free Storm Inspection', type: 'link', href: '/free-inspection' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'financing-options': {
    id: 'financing-options',
    label: 'Financing Options',
    text: "We offer flexible financing with $0 down and monthly payments starting around $89 a month for qualified buyers. We've got 12-month same-as-cash options too. Approval takes 5–10 minutes and it's a soft credit pull — won't ding your score. We work with all credit levels, and you can even combine financing with an insurance claim.",
    actions: [
      { label: 'Explore Financing', type: 'link', href: '/financing' },
      { label: 'Payment Calculator', type: 'link', href: '/roof-financing' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'maintenance-plans': {
    id: 'maintenance-plans',
    label: 'Maintenance Plans',
    text: "Our RoofCare plans start at $149 a year and include two seasonal inspections, gutter cleaning, minor sealant touch-ups, and priority scheduling. Think of it like an oil change for your roof — catch the small stuff before it becomes a $8,000 problem. Plus you get 10% off repairs and an extra 5 years on your workmanship warranty.",
    actions: [
      { label: 'See Maintenance Plans', type: 'link', href: '/maintenance-plans' },
      { label: 'Get an Estimate', type: 'link', href: '/estimate' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'warranty-info': {
    id: 'warranty-info',
    label: 'Warranty Info',
    text: "Every roof we install comes with a 10-year workmanship warranty — if it's our fault, we fix it free, no fine print. Manufacturer warranties range from 25 years to lifetime on the shingles. Both warranties transfer if you sell your home, and we handle all manufacturer claims at no cost to you. We register everything within 48 hours of finishing the job.",
    actions: [
      { label: 'Full Warranty Details', type: 'link', href: '/warranty' },
      { label: 'Get an Estimate', type: 'link', href: '/estimate' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'signs-new-roof': {
    id: 'signs-new-roof',
    label: 'Signs I Need a New Roof',
    text: "Watch for shingles curling at the edges, bald shiny spots where granules have worn off, granules collecting in your gutters like black sand, or daylight showing through your attic boards. If your roof is over 20 years old, it's probably time. Even one leak is a red flag — water spreads fast. Not sure? Our free inspection gives you a straight yes or no with photos.",
    actions: [
      { label: 'Free Roof Inspection', type: 'link', href: '/free-inspection' },
      { label: 'Roof Lifespan Guide', type: 'link', href: '/roof-cost-guide' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'gutter-services': {
    id: 'gutter-services',
    label: 'Gutter Services',
    text: "We install seamless aluminum gutters starting at $6–$10 per linear foot, plus gutter guards at $8–$15 per foot. Clogged or sagging gutters cause foundation damage, basement flooding, and siding rot — all way more expensive than new gutters. We also handle gutter cleaning through our RoofCare maintenance plans. Proper gutters protect your whole home, not just the roof.",
    actions: [
      { label: 'Gutter Services', type: 'link', href: '/gutters-downspouts' },
      { label: 'Get Gutter Quote', type: 'link', href: '/estimate' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'siding-options': {
    id: 'siding-options',
    label: 'Siding Options',
    text: "We install vinyl siding at $5–$9 per sq ft and fiber cement siding (James Hardie) at $9–$14 per sq ft. Vinyl is low-maintenance, affordable, and comes in tons of colors. Fiber cement looks like real wood, resists fire and pests, and laughs off Evansville humidity. We offer color visualizers and bundle discounts when you pair siding with a roof replacement.",
    actions: [
      { label: 'Siding & Exterior', type: 'link', href: '/siding-exterior' },
      { label: 'Get Siding Quote', type: 'link', href: '/estimate' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'storm-damage-signs': {
    id: 'storm-damage-signs',
    label: 'Storm Damage Signs',
    text: "After a storm, check your gutters and vents for dents — that's hail damage. Look for shingles lifted at the corners or scattered in your yard from wind. Dark bruise spots on shingles mean hail impact. And please don't climb on the roof yourself — it's dangerous and can mess up your insurance claim. Call us for a free same-day storm inspection. We'll document everything and tarp exposed areas at no charge.",
    actions: [
      { label: 'Storm Damage Help', type: 'link', href: '/storm-damage' },
      { label: 'Free Storm Inspection', type: 'link', href: '/free-inspection' },
      { label: 'Call Now — 24/7', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'roof-cost': {
    id: 'roof-cost',
    label: 'How Much Does a Roof Cost?',
    text: "In the Evansville area, a new asphalt shingle roof typically runs $7,000 to $18,000 depending on your home's size, roof pitch, and material grade. Architectural shingles average $7–$12 per sq ft installed. Metal roofing runs $12–$20 per sq ft. The fastest way to get your exact number is our free Roof Cost Estimator — it factors your home size, shape, condition, and material choice in under a minute.",
    actions: [
      { label: 'Try Cost Estimator', type: 'link', href: '/roof-estimator' },
      { label: 'Cost Breakdown Guide', type: 'link', href: '/roof-cost-guide' },
      { label: 'Get Exact Quote', type: 'link', href: '/estimate' },
    ],
  },
  'leak-emergency': {
    id: 'leak-emergency',
    label: 'I Have a Leak',
    text: "A leak is an emergency — water can ruin insulation, drywall, and framing within hours. First, grab some buckets and move anything valuable out of the way. Then call us immediately at (812) 213-5997. We offer same-day emergency tarping to stop the leak fast, then schedule the full repair. Don't wait — a small leak becomes a $10,000 problem before you know it.",
    actions: [
      { label: 'Emergency Services', type: 'link', href: '/emergency-services' },
      { label: 'Call Now — 24/7', type: 'phone', phone: 'tel:8122135997' },
      { label: 'Free Inspection', type: 'link', href: '/free-inspection' },
    ],
  },
  // ── NEW: Page-specific topics for AI fine-tuning ──
  'roof-repair-cost': {
    id: 'roof-repair-cost',
    label: 'How Much Is a Roof Repair?',
    text: "Minor repairs like sealing a leak or replacing a few shingles usually run $300–$800 in the Evansville area. Larger repairs involving decking or flashing replacement can be $1,200–$3,000. We always give exact quotes after a free inspection — no surprises. And if the repair isn't the best long-term solution, we'll tell you straight up.",
    actions: [
      { label: 'Book Free Inspection', type: 'link', href: '/free-inspection' },
      { label: 'Roof Repair Services', type: 'link', href: '/roof-repair' },
      { label: 'Call Now', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'repair-vs-replace': {
    id: 'repair-vs-replace',
    label: 'Repair or Replace?',
    text: "Not every damaged roof needs a full replacement. We look at the decking, underlayment, and shingle condition to give you an honest recommendation. If the damage is localized and your roof is under 15 years old, a repair usually makes sense. If damage covers more than 30% or your roof is 20+ years old, replacement is usually the smarter call. We'll never push a replacement you don't need.",
    actions: [
      { label: 'Free Inspection', type: 'link', href: '/free-inspection' },
      { label: 'Roof Repair Info', type: 'link', href: '/roof-repair' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'maintenance-worth-it': {
    id: 'maintenance-worth-it',
    label: 'Is a Maintenance Plan Worth It?',
    text: "A $299/year maintenance plan can prevent a $12,000 emergency repair. That's the math. We catch small issues — loose shingles, cracked sealant, clogged valleys — before they turn into leaks. Regular maintenance also adds 5–10 years to your roof's life and keeps your manufacturer warranty valid. Most homeowners who skip maintenance end up replacing their roof 8–10 years early.",
    actions: [
      { label: 'See Maintenance Plans', type: 'link', href: '/maintenance-plans' },
      { label: 'Get an Estimate', type: 'link', href: '/estimate' },
      { label: 'Call Now', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'exterior-package-cost': {
    id: 'exterior-package-cost',
    label: 'Complete Exterior Package Cost',
    text: "A complete exterior package — roof + siding + gutters — for a typical 2,000 sq ft Evansville home runs $22,000–$32,000 depending on materials. Vinyl siding with architectural shingles is at the lower end; James Hardie with metal roofing is at the higher end. Bundling saves you $800–$2,000 vs hiring separate contractors, plus you get one crew, one visit, and one warranty.",
    actions: [
      { label: 'Get Bundle Quote', type: 'link', href: '/exterior-package' },
      { label: 'Exterior Packages', type: 'link', href: '/exterior-package' },
      { label: 'Call Now', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'bundle-savings': {
    id: 'bundle-savings',
    label: 'How Much Do I Save Bundling?',
    text: "When you bundle roof, siding, and gutters with us, you save $800–$2,000 on average versus hiring three separate contractors. Here's why: one mobilization fee instead of three, bulk material pricing, and no scheduling gaps between trades. Plus everything matches perfectly — no mismatched colors or trim from different crews.",
    actions: [
      { label: 'See Bundle Packages', type: 'link', href: '/exterior-package' },
      { label: 'Get Free Quote', type: 'link', href: '/estimate' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'can-i-phase': {
    id: 'can-i-phase',
    label: 'Can I Do the Work in Phases?',
    text: "You can absolutely phase your exterior project — roof now, siding later, gutters whenever. But you'll save more by doing it all at once. If your roof is urgent but siding can wait, we'll tell you honestly. We can also quote both separately so you see the exact difference. No pressure either way.",
    actions: [
      { label: 'Get Phased Quote', type: 'link', href: '/exterior-package' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'schedule-inspection': {
    id: 'schedule-inspection',
    label: 'Schedule a Free Inspection',
    text: "We can schedule your free inspection right now — just let me know what day and time works best for you, or I can walk you through our online booking. We offer inspections Monday through Friday 7am to 6pm, and Saturday 8am to 2pm. Most inspections take about 30 minutes, and you'll get your full report within 24 hours. What's a good day for you?",
    actions: [
      { label: 'Book Online', type: 'link', href: '/free-inspection' },
      { label: 'Call to Schedule', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  // ── Commercial roofing topic (page-specific) ──
  'commercial-roofing-topic': {
    id: 'commercial-roofing',
    label: 'Commercial Roofing',
    text: "We handle commercial roofing for offices, warehouses, retail spaces, and industrial buildings across the Tri-State area — up to 100,000 sq ft. TPO, EPDM, standing seam metal, and roof coatings are our bread and butter. We're fully licensed in Indiana and Kentucky, bonded, and offer NDL (No Dollar Limit) warranties through GAF, Carlisle, and Firestone. We work nights and weekends to keep your business running, and our preventive maintenance plans start at $299/year.",
    actions: [
      { label: 'Commercial Roofing Services', type: 'link', href: '/commercial-roofing' },
      { label: 'Get Commercial Quote', type: 'link', href: '/estimate' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'commercial-cost': {
    id: 'commercial-cost',
    label: 'How Much Does a Commercial Roof Cost?',
    text: "Commercial roofing costs vary by system. TPO membranes run $6–$10 per sq ft installed. EPDM (rubber roofing) is $5–$9 per sq ft. Standing seam metal runs $10–$18 per sq ft. For a 10,000 sq ft flat roof, a TPO replacement typically runs $60,000–$100,000. Roof coatings that extend life 10–15 years run $2–$5 per sq ft. We provide free on-site commercial assessments with a detailed written proposal — no obligation.",
    actions: [
      { label: 'Commercial Services', type: 'link', href: '/commercial-roofing' },
      { label: 'Get Commercial Quote', type: 'link', href: '/estimate' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
  'commercial-timeline': {
    id: 'commercial-timeline',
    label: 'Commercial Project Timeline',
    text: "Commercial roofing projects typically take 3–14 days depending on building size, system type, and weather. A 5,000 sq ft TPO roof usually wraps in 3–5 days. A 30,000 sq ft warehouse might take 10–14 days. We work around your business hours — nights, weekends, and phased installation are all options. We provide a detailed project schedule before any work begins, and we stick to it.",
    actions: [
      { label: 'Commercial Roofing', type: 'link', href: '/commercial-roofing' },
      { label: 'Get Timeline Quote', type: 'link', href: '/estimate' },
      { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
    ],
  },
};

// URL aliases for greeting button and quick-pill lookups
alexTopicResponses['free-inspection'] = alexTopicResponses['/free-inspection'];
alexTopicResponses['estimate'] = alexTopicResponses['/estimate'];
alexTopicResponses['phone'] = alexTopicResponses['tel:8122135997'];
alexTopicResponses['/storm-damage'] = alexTopicResponses['storm-damage-signs'];
alexTopicResponses['/insurance-claims'] = alexTopicResponses['insurance-coverage'];
alexTopicResponses['/roof-estimator'] = alexTopicResponses['roof-cost'];
alexTopicResponses['/emergency-services'] = alexTopicResponses['leak-emergency'];
alexTopicResponses['/maintenance-plans'] = alexTopicResponses['maintenance-plans'];
alexTopicResponses['/warranty'] = alexTopicResponses['warranty-info'];
alexTopicResponses['/gutters-downspouts'] = alexTopicResponses['gutter-services'];
alexTopicResponses['/siding-exterior'] = alexTopicResponses['siding-options'];
alexTopicResponses['/financing'] = alexTopicResponses['financing-options'];
alexTopicResponses['/residential-roofing'] = alexTopicResponses['how-long'];
alexTopicResponses['/roof-comparison'] = alexTopicResponses['roof-materials'];
alexTopicResponses['/roof-cost-guide'] = alexTopicResponses['roof-cost'];
// New aliases
alexTopicResponses['/roof-repair'] = alexTopicResponses['roof-repair-cost'];
alexTopicResponses['exterior-package'] = alexTopicResponses['exterior-package-cost'];
alexTopicResponses['bundle'] = alexTopicResponses['bundle-savings'];
// Commercial aliases
alexTopicResponses['/commercial-roofing'] = alexTopicResponses['commercial-roofing-topic'];
alexTopicResponses['commercial-roofing-cost'] = alexTopicResponses['commercial-cost'];
alexTopicResponses['commercial-roofing-timeline'] = alexTopicResponses['commercial-timeline'];

// Option 2: Keyword-based responses for free-form user messages
export const alexKeywordMatches: AlexKeywordMatch[] = [
  {
    keywords: ['cost', 'price', 'how much', 'pricing', 'estimate', 'quote', 'expensive', 'cheap', 'budget', 'spend', 'afford', 'financing'],
    response: alexTopicResponses['roof-cost'],
  },
  {
    keywords: ['shingle', 'architectural', '3-tab', 'three tab', 'asphalt', 'metal roof', 'metal roofing', 'tile', 'slate', 'material', 'materials', 'what kind', 'which type'],
    response: alexTopicResponses['roof-materials'],
  },
  {
    keywords: ['insurance', 'claim', 'adjuster', 'deductible', 'covered', 'cover', 'policy', 'homeowners insurance', 'will insurance', 'does insurance'],
    response: alexTopicResponses['insurance-coverage'],
  },
  {
    keywords: ['time', 'long', 'days', 'how long', 'timeline', 'when', 'schedule', 'completion', 'finished', 'done', 'how soon', 'turnaround', 'duration'],
    response: alexTopicResponses['how-long'],
  },
  {
    keywords: ['gutter', 'downspout', 'gutters', 'drainage', 'seamless gutter', 'gutter guard', 'leaf guard'],
    response: alexTopicResponses['gutter-services'],
  },
  {
    keywords: ['leak', 'leaking', 'water', 'stain', 'ceiling', 'drip', 'wet', 'moisture', 'flood', 'emergency', 'urgent', 'tarP'],
    response: alexTopicResponses['leak-emergency'],
  },
  {
    keywords: ['financing', 'payment', 'monthly', 'loan', 'credit', 'down payment', '0 down', 'zero down', 'afford', 'payments', 'interest', 'approve', 'qualify'],
    response: alexTopicResponses['financing-options'],
  },
  {
    keywords: ['warranty', 'guarantee', 'guaranteed', 'workmanship', 'manufacturer warranty', 'lifetime', 'transfer', 'coverage', 'protect'],
    response: alexTopicResponses['warranty-info'],
  },
  {
    keywords: ['maintenance', 'inspect', 'inspection', 'cleaning', 'tune up', 'checkup', 'care', 'upkeep', 'service plan', ' RoofCare'],
    response: alexTopicResponses['maintenance-plans'],
  },
  {
    keywords: ['signs', 'need new roof', 'replace', 'replacement', 'when to replace', 'old roof', 'age', 'curling', 'bald', 'missing shingles', 'granules', 'damaged'],
    response: alexTopicResponses['signs-new-roof'],
  },
  {
    keywords: ['siding', 'vinyl', 'fiber cement', 'hardie', 'exterior', 'cladding', 'house wrap', 'curb appeal'],
    response: alexTopicResponses['siding-options'],
  },
  {
    keywords: ['storm', 'hail', 'wind', 'tornado', 'damage', 'dented', 'missing shingles', 'after storm', 'weather damage', 'severe weather'],
    response: alexTopicResponses['storm-damage-signs'],
  },
  {
    keywords: ['free inspection', 'inspect my roof', 'check my roof', 'roof check', 'assessment', 'evaluate', 'look at my roof'],
    response: alexTopicResponses['/free-inspection'],
  },
  {
    keywords: ['estimate', 'bid', 'proposal', 'get a quote', 'how much for', 'quote for', 'pricing for my', 'price for my'],
    response: alexTopicResponses['/estimate'],
  },
  {
    keywords: ['call', 'phone', 'talk to someone', 'human', 'person', 'representative', 'speak to', 'contact', 'reach you'],
    response: alexTopicResponses['tel:8122135997'],
  },
  {
    keywords: ['repair', 'patch', 'fix', 'broken shingle', 'small leak', 'minor damage', 'spot repair', 'partial'],
    response: alexTopicResponses['roof-repair-cost'],
  },
  {
    keywords: ['commercial', 'business', 'office', 'warehouse', 'industrial', 'retail', 'apartment building', 'multi-family'],
    response: alexTopicResponses['roof-materials'],
  },
  {
    keywords: ['energy', 'efficient', 'cool roof', 'insulation', 'save money', 'utility bill', 'reflective', 'solar'],
    response: alexTopicResponses['roof-materials'],
  },
  {
    keywords: ['attic', 'vent', 'ventilation', 'soffit', 'fascia', 'ridge vent', 'intake', 'exhaust'],
    response: alexTopicResponses['signs-new-roof'],
  },
  {
    keywords: ['resale', 'home value', 'sell my house', 'property value', 'curb appeal', 'HOA', 'association'],
    response: alexTopicResponses['roof-cost'],
  },
  // New keyword matches
  {
    keywords: ['repair cost', 'fix cost', 'patch cost', 'leak repair', 'roof repair price', 'how much to repair', 'how much to fix'],
    response: alexTopicResponses['roof-repair-cost'],
  },
  {
    keywords: ['repair or replace', 'should I repair', 'should I replace', 'patch or replace', 'fix or replace', 'worth repairing', 'too old to repair'],
    response: alexTopicResponses['repair-vs-replace'],
  },
  {
    keywords: ['maintenance worth', 'worth it', 'roof care', 'annual plan', 'yearly maintenance', 'roof maintenance value', 'is maintenance worth'],
    response: alexTopicResponses['maintenance-worth-it'],
  },
  {
    keywords: ['exterior package', 'complete exterior', 'roof and siding', 'siding and gutters', 'bundle', 'bundle price', 'package cost', 'full exterior', 'all at once'],
    response: alexTopicResponses['exterior-package-cost'],
  },
  {
    keywords: ['save bundling', 'bundle savings', 'how much save', 'separate contractors', 'phased', 'phase', 'do it in phases', 'split up'],
    response: alexTopicResponses['bundle-savings'],
  },
  {
    keywords: ['book inspection', 'schedule inspection', 'set up inspection', 'appointment', 'when can you come', 'available times', 'next available', 'book now', 'schedule now'],
    response: alexTopicResponses['schedule-inspection'],
  },
  // Commercial roofing keyword matches
  {
    keywords: ['commercial', 'business owner', 'office building', 'warehouse', 'industrial roof', 'retail space', 'property manager', 'strip mall', 'distribution center', 'church roof', 'school roof', 'medical facility roof', 'restaurant roof'],
    response: alexTopicResponses['commercial-roofing-topic'],
  },
  {
    keywords: ['tpo', 'epdm', 'flat roof', 'low slope', 'rubber roof', 'membrane roof', 'commercial roof cost', 'commercial price', 'commercial estimate', 'commercial quote', 'how much for flat roof', 'commercial roof price'],
    response: alexTopicResponses['commercial-cost'],
  },
  {
    keywords: ['ndl warranty', 'no dollar limit', 'commercial warranty', 'carlisle warranty', 'firestone warranty', 'gaf commercial', 'commercial maintenance', 'preventive maintenance contract'],
    response: alexTopicResponses['commercial-roofing-topic'],
  },
  {
    keywords: ['commercial timeline', 'how long commercial', 'business disruption', 'night work', 'weekend roofing', 'phased commercial', 'commercial schedule'],
    response: alexTopicResponses['commercial-timeline'],
  },
];

// Quick question pills that appear on TalkToAIExpert strip
export const alexQuickQuestions = [
  { label: 'How much is a new roof?', topicId: 'roof-cost' },
  { label: 'Will insurance cover it?', topicId: 'insurance-coverage' },
  { label: 'How long does it take?', topicId: 'how-long' },
  { label: 'Metal vs shingles?', topicId: 'roof-materials' },
  { label: 'Signs I need a new roof?', topicId: 'signs-new-roof' },
  { label: 'Do you offer financing?', topicId: 'financing-options' },
  { label: 'Maintenance plans?', topicId: 'maintenance-plans' },
  { label: 'Warranty info?', topicId: 'warranty-info' },
  { label: 'Gutter services?', topicId: 'gutter-services' },
  { label: 'Siding options?', topicId: 'siding-options' },
  { label: 'Storm damage signs?', topicId: 'storm-damage-signs' },
  { label: 'I have a leak!', topicId: 'leak-emergency' },
  // New quick questions
  { label: 'How much is a repair?', topicId: 'roof-repair-cost' },
  { label: 'Repair or replace?', topicId: 'repair-vs-replace' },
  { label: 'Is maintenance worth it?', topicId: 'maintenance-worth-it' },
  { label: 'Exterior package cost?', topicId: 'exterior-package-cost' },
  { label: 'How much do I save?', topicId: 'bundle-savings' },
  { label: 'Book an inspection?', topicId: 'schedule-inspection' },
  // Commercial roofing quick questions
  { label: 'Commercial roofing?', topicId: 'commercial-roofing-topic' },
  { label: 'Flat roof cost?', topicId: 'commercial-cost' },
  { label: 'TPO or EPDM?', topicId: 'commercial-roofing-topic' },
];

// All initial greeting buttons shown when chat opens
export const alexGreetingButtons = [
  { label: 'Free Roof Inspection', topicId: 'free-inspection' },
  { label: 'Get an Estimate', topicId: 'estimate' },
  { label: 'Roof Cost Estimator', topicId: 'roof-cost' },
  { label: 'Storm Damage Help', topicId: 'storm-damage-signs' },
  { label: 'Insurance Questions', topicId: 'insurance-coverage' },
  { label: 'Roof Materials', topicId: 'roof-materials' },
  { label: 'How Long Does It Take?', topicId: 'how-long' },
  { label: 'Financing Options', topicId: 'financing-options' },
  { label: 'Signs I Need a New Roof', topicId: 'signs-new-roof' },
  { label: 'Maintenance Plans', topicId: 'maintenance-plans' },
  { label: 'Warranty Info', topicId: 'warranty-info' },
  { label: 'Gutter Services', topicId: 'gutter-services' },
  { label: 'Siding Options', topicId: 'siding-options' },
  { label: 'I Have a Leak', topicId: 'leak-emergency' },
  { label: 'Commercial Roofing', topicId: 'commercial-roofing-topic' },
  { label: 'Talk to a Human', phone: 'tel:8122135997' },
  { label: 'Ask a Question', input: true },
];