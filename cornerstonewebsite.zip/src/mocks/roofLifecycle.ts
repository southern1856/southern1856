export interface LifecycleStage {
  label: string;
  startYear: number;
  endYear: number;
  color: string;
  textColor: string;
  icon: string;
  headline: string;
  description: string;
  maintenanceTasks: string[];
  averageCost: string;
  priority: 'routine' | 'recommended' | 'urgent' | 'critical';
}

export interface RoofEvent {
  year: number;
  label: string;
  icon: string;
  type: 'install' | 'inspection' | 'repair' | 'storm' | 'milestone' | 'projected';
}

export const ROOF_LIFECYCLE: LifecycleStage[] = [
  {
    label: 'New Roof',
    startYear: 0,
    endYear: 5,
    color: '#22C55E',
    textColor: 'text-green-700',
    icon: 'ri-shield-check-line',
    headline: 'Peak Performance Years',
    description:
      'Your roof is in its strongest phase. Materials are fully bonded, granule loss is minimal, and shingles flex without cracking. Annual inspections are still recommended after major storms.',
    maintenanceTasks: [
      'Annual post-storm inspection',
      'Keep gutters clear',
      'Trim overhanging branches',
    ],
    averageCost: '$0–$150/yr',
    priority: 'routine',
  },
  {
    label: 'Mature',
    startYear: 6,
    endYear: 12,
    color: '#EAB308',
    textColor: 'text-amber-700',
    icon: 'ri-tools-line',
    headline: 'Maintenance Mode',
    description:
      'Shingles begin showing wear. Minor granule loss, slight curling at edges, and sealant strip fatigue are normal. This is when proactive repairs prevent costly leaks.',
    maintenanceTasks: [
      'Bi-annual professional inspection',
      'Replace loose or missing shingles',
      'Re-seal flashing and pipe boots',
      'Address moss/algae buildup',
    ],
    averageCost: '$200–$800/yr',
    priority: 'recommended',
  },
  {
    label: 'Aging',
    startYear: 13,
    endYear: 18,
    color: '#F97316',
    textColor: 'text-orange-700',
    icon: 'ri-error-warning-line',
    headline: 'Watch Closely',
    description:
      'Shingles become brittle, fasteners loosen, and underlayment starts degrading. Repair costs rise and full replacement should be budgeted within the next 3–5 years.',
    maintenanceTasks: [
      'Annual full inspection + report',
      'Sectional repairs as needed',
      'Monitor attic for moisture stains',
      'Consider replacement planning',
    ],
    averageCost: '$800–$2,500/yr',
    priority: 'urgent',
  },
  {
    label: 'End of Life',
    startYear: 19,
    endYear: 30,
    color: '#EF4444',
    textColor: 'text-red-700',
    icon: 'ri-refresh-line',
    headline: 'Replacement Recommended',
    description:
      'System integrity is compromised. Multiple failure points, widespread granule loss, and underlayment exposure make continued repairs inefficient. Full replacement is the smart investment.',
    maintenanceTasks: [
      'Immediate full replacement estimate',
      'Temporary leak mitigation only',
      'Document condition for insurance',
      'Schedule before next storm season',
    ],
    averageCost: '$8,000–$18,000',
    priority: 'critical',
  },
];

export const ROOF_EVENTS: RoofEvent[] = [
  { year: 0, label: 'Installed', icon: 'ri-home-4-line', type: 'install' },
  { year: 5, label: 'First Inspection', icon: 'ri-search-eye-line', type: 'inspection' },
  { year: 8, label: 'Storm — Minor Repairs', icon: 'ri-thunderstorms-line', type: 'storm' },
  { year: 12, label: 'Flashing Re-Seal', icon: 'ri-tools-line', type: 'repair' },
  { year: 14, label: 'Current Inspection', icon: 'ri-file-list-3-line', type: 'inspection' },
  { year: 16, label: 'Projected: Sectional Repair', icon: 'ri-calendar-event-line', type: 'projected' },
  { year: 19, label: 'Projected: Replacement Window Opens', icon: 'ri-refresh-line', type: 'projected' },
  { year: 22, label: 'Projected: Full Replacement', icon: 'ri-refresh-line', type: 'projected' },
];

export const USER_ROOF_PROFILE = {
  installedYear: 2012,
  currentAge: 14,
  expectedLifespan: 22,
  shingleType: '3-Tab Asphalt (GAF)',
  warrantyYears: 25,
  warrantyStatus: 'Active until 2037',
  currentStage: 'Aging',
  nextMilestone: 'Sectional repairs likely within 2 years',
  projectedReplacement: 2034,
  yearsUntilReplace: 8,
  conditionScore: 62, // 0-100
  inspectorQuote:
    'At 14 years, this roof is showing expected aging signs. The hail damage on the north slope accelerated wear in that section. Repair now, plan replacement by year 19–22.',
};