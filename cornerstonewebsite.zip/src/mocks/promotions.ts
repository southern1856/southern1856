export interface Offer {
  id: string;
  badge: string;
  title: string;
  subtitle: string;
  savings: string;
  description: string;
  features: string[];
  icon: string;
  bgImage: string;
  limited?: boolean;
  expires?: string;
}

export const OFFERS: Offer[] = [
  {
    id: 'storm-prep',
    badge: 'Most Popular',
    title: 'Storm Season Protection Package',
    subtitle: 'Be ready before the next big one hits',
    savings: 'Save up to $750',
    description: 'Complete roof inspection + preventative maintenance + storm reinforcement. Includes free hail-resistance upgrade on shingles and priority scheduling when storms hit.',
    features: ['Free drone roof inspection ($299 value)', 'Hail-resistant shingle upgrade at no extra cost', 'Priority emergency response for 12 months', 'Insurance documentation pre-filed for faster claims'],
    icon: 'ri-thunderstorms-line',
    bgImage: '/placeholders/800x500.svg',
    limited: true,
    expires: '2026-07-31',
  },
  {
    id: 'summer-roof',
    badge: 'Best Value',
    title: 'Summer Roof Replacement Special',
    subtitle: 'New roof at the season\'s lowest price',
    savings: '10% Off + 0% Financing',
    description: 'Full roof replacement with Owens Corning Duration shingles. Lock in summer pricing before fall demand drives costs up. Includes free upgrade to architectural shingles.',
    features: ['10% off complete roof replacement', '0% financing for 24 months', 'Free architectural shingle upgrade', 'Free gutter cleaning with every roof'],
    icon: 'ri-home-4-line',
    bgImage: '/placeholders/800x500.svg',
    limited: true,
    expires: '2026-08-31',
  },
  {
    id: 'gutter-fall',
    badge: 'Seasonal',
    title: 'Fall Gutter & Maintenance Package',
    subtitle: 'Protect your home before winter arrives',
    savings: 'Save $400',
    description: 'Complete seamless gutter installation or replacement with gutter guards. Includes roof inspection, leaf protection, and downspout extensions to protect your foundation.',
    features: ['Seamless aluminum gutters installed', 'Gutter guards included at no extra cost', 'Free roof inspection with service', 'Downspout extensions for foundation protection'],
    icon: 'ri-drop-line',
    bgImage: '/placeholders/800x500.svg',
    limited: true,
    expires: '2026-11-15',
  },
  {
    id: 'referral',
    badge: 'Earn Cash',
    title: 'Refer a Neighbor & Get $250',
    subtitle: 'Your neighbors need a good roofer too',
    savings: 'Earn $250 per referral',
    description: 'Refer a friend, family member, or neighbor to Corner Stone and earn $250 cash for every referral that books a roof replacement or major repair. No limit — refer as many as you want.',
    features: ['$250 cash for every completed referral', 'No limit on number of referrals', 'Referral tracking through your account', 'Stackable with any other promotions'],
    icon: 'ri-group-line',
    bgImage: '/placeholders/800x500.svg',
  },
  {
    id: 'military-senior',
    badge: 'Always Active',
    title: 'Military & Senior Discount',
    subtitle: 'Thank you for your service',
    savings: '5% Off Any Service',
    description: 'Active duty, veterans, first responders, and seniors 65+ receive 5% off any roofing, siding, or gutter service. It\'s our way of saying thank you to those who serve our community.',
    features: ['5% off any roofing, siding, or gutter work', 'Stacks with seasonal promotions', 'Valid for active duty, veterans, first responders', 'Seniors 65+ automatically qualify'],
    icon: 'ri-flag-line',
    bgImage: '/placeholders/800x500.svg',
  },
  {
    id: 'exterior-bundle',
    badge: 'Premium',
    title: 'Complete Exterior Bundle',
    subtitle: 'Roof + Siding + Gutters — one price',
    savings: 'Save up to $2,500',
    description: 'Bundle your roof replacement with new siding and seamless gutters for maximum savings. One crew, one schedule, one warranty. Everything coordinated and installed together.',
    features: ['Roof + siding + gutters in one project', 'Up to $2,500 in bundle savings', 'Single warranty covering all systems', 'Coordinated scheduling — no multiple crews'],
    icon: 'ri-stack-line',
    bgImage: '/placeholders/800x500.svg',
    limited: true,
    expires: '2026-09-30',
  },
];