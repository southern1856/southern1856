export interface WeatherDay {
  date: string; // YYYY-MM-DD
  dayName: string;
  monthDay: string;
  condition: string;
  icon: string;
  tempHigh: number;
  tempLow: number;
  windSpeed: number; // mph
  humidity: number; // percent
  rainChance: number; // percent
  severity: 'clear' | 'caution' | 'warning' | 'severe';
  alertMessage?: string;
  precipType?: 'none' | 'rain' | 'storms' | 'hail';
  precipAmount?: number; // inches
}

export const EVANSVILLE_WEATHER: WeatherDay[] = [
  {
    date: '2026-05-02',
    dayName: 'Today',
    monthDay: 'May 2',
    condition: 'Partly Cloudy',
    icon: 'ri-sun-cloudy-line',
    tempHigh: 74,
    tempLow: 58,
    windSpeed: 8,
    humidity: 62,
    rainChance: 10,
    severity: 'clear',
    precipType: 'none',
  },
  {
    date: '2026-05-03',
    dayName: 'Sun',
    monthDay: 'May 3',
    condition: 'Scattered Storms',
    icon: 'ri-thunderstorms-line',
    tempHigh: 71,
    tempLow: 59,
    windSpeed: 12,
    humidity: 78,
    rainChance: 65,
    severity: 'caution',
    alertMessage: 'Scattered thunderstorms possible after 2 PM',
    precipType: 'storms',
    precipAmount: 0.3,
  },
  {
    date: '2026-05-04',
    dayName: 'Mon',
    monthDay: 'May 4',
    condition: 'Severe T-Storms',
    icon: 'ri-heavy-showers-line',
    tempHigh: 68,
    tempLow: 56,
    windSpeed: 28,
    humidity: 85,
    rainChance: 90,
    severity: 'severe',
    alertMessage: 'Severe thunderstorms expected. High winds up to 60 mph and heavy rain. Roof work should be postponed.',
    precipType: 'storms',
    precipAmount: 1.8,
  },
  {
    date: '2026-05-05',
    dayName: 'Tue',
    monthDay: 'May 5',
    condition: 'Showers',
    icon: 'ri-showers-line',
    tempHigh: 65,
    tempLow: 54,
    windSpeed: 15,
    humidity: 82,
    rainChance: 75,
    severity: 'warning',
    alertMessage: 'Steady rain likely throughout the day. Exterior roofing work not recommended.',
    precipType: 'rain',
    precipAmount: 0.7,
  },
  {
    date: '2026-05-06',
    dayName: 'Wed',
    monthDay: 'May 6',
    condition: 'Partly Cloudy',
    icon: 'ri-cloudy-line',
    tempHigh: 70,
    tempLow: 55,
    windSpeed: 10,
    humidity: 68,
    rainChance: 20,
    severity: 'caution',
    alertMessage: 'Damp conditions from prior rain. Morning crews may start late.',
    precipType: 'none',
  },
  {
    date: '2026-05-07',
    dayName: 'Thu',
    monthDay: 'May 7',
    condition: 'Mostly Sunny',
    icon: 'ri-sun-line',
    tempHigh: 76,
    tempLow: 57,
    windSpeed: 6,
    humidity: 55,
    rainChance: 5,
    severity: 'clear',
    precipType: 'none',
  },
  {
    date: '2026-05-08',
    dayName: 'Fri',
    monthDay: 'May 8',
    condition: 'Sunny',
    icon: 'ri-sun-line',
    tempHigh: 78,
    tempLow: 59,
    windSpeed: 5,
    humidity: 50,
    rainChance: 0,
    severity: 'clear',
    precipType: 'none',
  },
];

export const REPAIR_WINDOW_DAYS = 5; // "ASAP" = within 3-5 days

export interface WeatherAlertSummary {
  hasAlert: boolean;
  worstSeverity: 'clear' | 'caution' | 'warning' | 'severe';
  activeAlerts: WeatherDay[];
  safeDays: WeatherDay[];
  recommendedDate: string | null;
}

export function getWeatherAlertSummary(
  weatherData: WeatherDay[],
  daysWindow: number
): WeatherAlertSummary {
  const windowData = weatherData.slice(0, daysWindow + 1);
  const activeAlerts = windowData.filter(
    (d) => d.severity === 'warning' || d.severity === 'severe'
  );
  const safeDays = windowData.filter((d) => d.severity === 'clear');

  const severities = windowData.map((d) => d.severity);
  const worstSeverity = severities.includes('severe')
    ? 'severe'
    : severities.includes('warning')
    ? 'warning'
    : severities.includes('caution')
    ? 'caution'
    : 'clear';

  // Find the first clear or caution-only day after any warnings
  const recommended = safeDays.length > 0 ? safeDays[0].date : null;

  return {
    hasAlert: activeAlerts.length > 0,
    worstSeverity,
    activeAlerts,
    safeDays,
    recommendedDate: recommended,
  };
}