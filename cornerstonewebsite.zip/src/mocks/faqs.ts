export const faqs = [
  {
    id: 1,
    question: 'How much does a new roof cost in Evansville, Indiana?',
    answer: 'The average cost of a new roof in Evansville ranges from $8,000 to $25,000 depending on your home\'s size, the roofing material you choose, and the complexity of the job. Asphalt shingles typically cost $4-7 per square foot installed, while metal roofing runs $8-14 per square foot. We offer free, no-obligation estimates so you know exactly what to expect before any work begins.',
  },
  {
    id: 2,
    question: 'How much does a roof replacement cost?',
    answer: 'Every roof is different, so the best way to get a realistic ballpark is to use our interactive Roof Cost Estimator right here on this page. In about 30 seconds you can select your home size and preferred material to see an instant price range based on current Evansville-area rates — no email or phone number required.',
    link: {
      text: 'Try the Roof Cost Estimator',
      href: '#roof-estimator',
    },
  },
  {
    id: 3,
    question: 'How long does a roof replacement take in Evansville?',
    answer: 'Most residential roof replacements in Evansville are completed in 1-3 days. Smaller homes with simple rooflines may take just a single day, while larger homes or those with complex architecture, multiple dormers, or steep pitches can take 3-5 days. Weather is also a factor — we monitor Indiana forecasts closely and will reschedule if conditions are unsafe.',
  },
  {
    id: 4,
    question: 'What roofing material is best for Indiana weather?',
    answer: 'For Indiana\'s climate — hot humid summers, heavy spring rains, and winter ice dams — architectural asphalt shingles are the most popular and cost-effective choice. They handle temperature swings well and resist wind up to 130 mph. For maximum durability, metal roofing is excellent for Indiana and can last 40-70 years. We also install impact-resistant shingles that are ideal for areas prone to hail, like Vanderburgh County.',
  },
  {
    id: 5,
    question: 'Do you offer emergency roof repair in Evansville?',
    answer: 'Yes! We provide 24/7 emergency roof repair services throughout Evansville, Newburgh, and Vanderburgh County. If a storm has damaged your roof, we can typically arrive within 2-4 hours to tarp the damaged area and prevent further water damage to your home. Call our emergency line at 812-213-5997 any time, day or night.',
  },
  {
    id: 6,
    question: 'Will my insurance cover roof damage in Indiana?',
    answer: 'Most Indiana homeowners insurance policies cover roof damage caused by sudden, accidental events like hail, windstorms, falling trees, or fire. They typically do NOT cover damage from normal wear and tear or lack of maintenance. We work directly with all major insurance companies and can help document damage, provide detailed estimates, and guide you through the claims process to maximize your coverage.',
  },
  {
    id: 7,
    question: 'How often should I have my roof inspected in Evansville?',
    answer: 'We recommend having your roof professionally inspected at least once a year, ideally in the fall before winter weather hits. You should also schedule an inspection after any major storm, if you notice leaks or water stains inside your home, or if your roof is over 15 years old. Our Evansville roof inspections are thorough, free, and come with a detailed report and photo documentation.',
  },
  {
    id: 8,
    question: 'What areas do you serve besides Evansville?',
    answer: 'Corner Stone Construction & Roofing proudly serves all of Vanderburgh County including Evansville, Newburgh, and McCutchanville. We also work in surrounding areas such as Boonville (Warrick County), Mount Vernon (Posey County), Princeton (Gibson County), and across the river in Henderson, Kentucky. If you are unsure whether we cover your area, just give us a call — we likely do!',
  },
  {
    id: 9,
    question: 'Do you offer financing for roof replacement in Evansville?',
    answer: 'Yes, we offer flexible financing options for qualified homeowners in Evansville and the surrounding area. We partner with several financing providers to offer plans with low monthly payments, deferred interest options, and terms up to 120 months. During your free estimate, we can discuss financing options that fit your budget so you can get the roof you need without the upfront financial stress.',
  },
];
