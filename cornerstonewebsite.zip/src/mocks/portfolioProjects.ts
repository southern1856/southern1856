export interface PortfolioProject {
  id: number;
  title: string;
  subtitle: string;
  type: 'Residential' | 'Commercial' | 'Repair' | 'Multi-Family';
  location: string;
  year: number;
  duration: string;
  squareFootage: string;
  material: string;
  description: string;
  highlights: string[];
  beforeImage: string;
  afterImage: string;
  galleryImages: string[];
  featured: boolean;
  badge: 'Before & After' | 'Completed' | 'Storm Damage' | 'Insurance Claim' | 'Commercial';
}

export const portfolioProjects: PortfolioProject[] = [
  {
    id: 1,
    title: 'Full Shingle Replacement',
    subtitle: 'Age & Wear — Complete Transformation',
    type: 'Residential',
    location: 'Evansville, IN',
    year: 2024,
    duration: '2 days',
    squareFootage: '2,400 sq ft',
    material: 'GAF Timberline HDZ Shingles',
    description: 'This Evansville home had 22-year-old shingles showing severe granule loss, curling edges, and multiple leak points. We performed a full tear-off, replaced damaged decking, installed ToughSkin underlayment, and finished with GAF Timberline HDZ in Charcoal — a complete transformation that added 30+ years of life.',
    highlights: ['Full tear-off & deck inspection', 'Replaced 3 sections of damaged OSB decking', 'ToughSkin synthetic underlayment', 'New ridge cap & drip edge', 'Ice & water shield in valleys'],
    beforeImage: '/placeholders/800x600.svg',
    afterImage: '/placeholders/800x600.svg',
    galleryImages: [
      '/placeholders/800x600.svg',
      '/placeholders/800x600.svg',
      '/placeholders/800x600.svg',
    ],
    featured: true,
    badge: 'Before & After',
  },
  {
    id: 2,
    title: 'Hail Damage Insurance Claim',
    subtitle: 'Storm Damage — Full Insurance Replacement',
    type: 'Repair',
    location: 'Evansville, IN',
    year: 2024,
    duration: '1 day',
    squareFootage: '1,850 sq ft',
    material: 'Owens Corning Duration Shingles',
    description: 'After a severe hailstorm swept through Vanderburgh County, this homeowner called us for a damage assessment. We documented every impact point, worked directly with their insurance adjuster, and got a full replacement approved. Completed in a single day with zero out-of-pocket cost to the homeowner.',
    highlights: ['Free storm damage inspection', 'Full insurance claim documentation', 'Adjuster coordination & approval', 'Owens Corning Duration in Estate Gray', 'Completed in 1 day'],
    beforeImage: '/placeholders/900x600.svg',
    afterImage: '/placeholders/900x600.svg',
    galleryImages: [
      '/placeholders/600x400.svg',
      '/placeholders/600x400.svg',
    ],
    featured: true,
    badge: 'Insurance Claim',
  },
  {
    id: 3,
    title: 'Standing Seam Metal Roof',
    subtitle: 'Premium Metal — 50-Year Warranty',
    type: 'Residential',
    location: 'Newburgh, IN',
    year: 2024,
    duration: '4 days',
    squareFootage: '3,100 sq ft',
    material: 'Charcoal Gray Standing Seam Metal',
    description: 'This Newburgh homeowner wanted the last roof they\'d ever need. We installed a full standing seam metal roof system in charcoal gray — the most durable roofing option available. With a 50-year warranty and wind resistance up to 140 mph, this roof will outlast the house.',
    highlights: ['Standing seam metal panels', '50-year manufacturer warranty', '140 mph wind resistance', 'Energy Star certified', 'Custom flashing & trim work'],
    beforeImage: '/placeholders/900x600.svg',
    afterImage: '/placeholders/900x600.svg',
    galleryImages: [
      '/placeholders/600x400.svg',
      '/placeholders/600x400.svg',
      '/placeholders/600x400.svg',
    ],
    featured: true,
    badge: 'Completed',
  },
  {
    id: 4,
    title: 'Multi-Family Complex Reroof',
    subtitle: '48-Unit Apartment Complex',
    type: 'Multi-Family',
    location: 'Evansville, IN',
    year: 2023,
    duration: '8 days',
    squareFootage: '18,400 sq ft',
    material: 'GAF Timberline HDZ — Weathered Wood',
    description: 'One of our largest residential projects — a 48-unit apartment complex in Evansville that needed a full reroof across 6 buildings. We coordinated with property management to minimize tenant disruption, completed all 6 buildings in 8 days, and handled the full insurance claim process.',
    highlights: ['6 buildings, 48 units total', 'Coordinated with property management', 'Minimal tenant disruption', 'Full insurance claim handled', 'Completed 2 weeks ahead of schedule'],
    beforeImage: '/placeholders/900x600.svg',
    afterImage: '/placeholders/900x600.svg',
    galleryImages: [
      '/placeholders/600x400.svg',
      '/placeholders/600x400.svg',
    ],
    featured: false,
    badge: 'Commercial',
  },
  {
    id: 5,
    title: 'Commercial TPO Flat Roof',
    subtitle: 'Retail Strip Mall — Full Membrane Replacement',
    type: 'Commercial',
    location: 'Evansville, IN',
    year: 2023,
    duration: '5 days',
    squareFootage: '12,000 sq ft',
    material: 'Firestone TPO 60-mil Membrane',
    description: 'A local retail strip mall had a failing EPDM flat roof with multiple active leaks causing interior damage. We removed the old membrane, repaired the insulation board, and installed a Firestone TPO 60-mil system with heat-welded seams — the gold standard for commercial flat roofing.',
    highlights: ['Full EPDM tear-off', 'Insulation board repair & replacement', 'Firestone TPO 60-mil membrane', 'Heat-welded seams throughout', '20-year commercial warranty'],
    beforeImage: '/placeholders/900x600.svg',
    afterImage: '/placeholders/900x600.svg',
    galleryImages: [
      '/placeholders/600x400.svg',
      '/placeholders/600x400.svg',
    ],
    featured: false,
    badge: 'Commercial',
  },
  {
    id: 6,
    title: 'Wind Damage Emergency Repair',
    subtitle: 'Storm Response — Same Day Service',
    type: 'Repair',
    location: 'Henderson, KY',
    year: 2024,
    duration: '6 hours',
    squareFootage: '800 sq ft affected',
    material: 'Matching Architectural Shingles',
    description: 'A severe wind event tore off nearly 40 shingles from this Henderson home overnight. The homeowner called us at 7am and we had a crew on-site by 9am. We tarped the exposed areas immediately, matched the existing shingle color perfectly, and completed the repair the same day — preventing any interior water damage.',
    highlights: ['Same-day emergency response', 'Immediate tarping to prevent water damage', 'Perfect color match to existing shingles', 'Reinforced fastening pattern', 'Insurance claim filed same day'],
    beforeImage: '/placeholders/900x600.svg',
    afterImage: '/placeholders/900x600.svg',
    galleryImages: [
      '/placeholders/600x400.svg',
    ],
    featured: false,
    badge: 'Storm Damage',
  },
  {
    id: 7,
    title: 'Historic Craftsman Reroof',
    subtitle: '1920s Home — Preserved Character',
    type: 'Residential',
    location: 'Newburgh, IN',
    year: 2023,
    duration: '3 days',
    squareFootage: '2,800 sq ft',
    material: 'CertainTeed Landmark Pro — Moire Black',
    description: 'This 1920s craftsman home in Newburgh required special care — the original wood decking needed reinforcement, and the complex hip-and-valley roof geometry demanded experienced hands. We preserved the home\'s historic character while bringing it fully up to modern standards with CertainTeed Landmark Pro shingles.',
    highlights: ['Historic wood deck reinforcement', 'Complex hip & valley geometry', 'CertainTeed Landmark Pro shingles', 'Custom copper valley flashing', 'Preserved original architectural details'],
    beforeImage: '/placeholders/900x600.svg',
    afterImage: '/placeholders/900x600.svg',
    galleryImages: [
      '/placeholders/600x400.svg',
      '/placeholders/600x400.svg',
    ],
    featured: false,
    badge: 'Completed',
  },
  {
    id: 8,
    title: 'Chimney & Flashing Overhaul',
    subtitle: 'Leak Source Eliminated — Guaranteed',
    type: 'Repair',
    location: 'Evansville, IN',
    year: 2024,
    duration: '1 day',
    squareFootage: 'Targeted repair',
    material: 'Lead-Free Aluminum Flashing',
    description: 'This homeowner had been chasing a mysterious leak for 3 years. Two other contractors couldn\'t find the source. We identified failing step flashing and a cracked chimney crown as the culprits, rebuilt the entire flashing system, and applied a waterproof chimney crown coat. Leak-free since day one.',
    highlights: ['Leak source identified & eliminated', 'Full step flashing replacement', 'Chimney crown rebuild & waterproofing', 'Counter flashing re-sealed', '5-year leak-free guarantee'],
    beforeImage: '/placeholders/900x600.svg',
    afterImage: '/placeholders/900x600.svg',
    galleryImages: [
      '/placeholders/600x400.svg',
    ],
    featured: false,
    badge: 'Completed',
  },
];

export const projectStats = [
  { value: '2,500+', label: 'Roofs Installed', icon: 'ri-home-4-line' },
  { value: '25+', label: 'Years in Business', icon: 'ri-calendar-line' },
  { value: '$4.2M+', label: 'Insurance Claims Won', icon: 'ri-shield-check-line' },
  { value: '4.9★', label: 'Google Rating', icon: 'ri-star-fill' },
];
