export const SIDING_COLOR_PALETTES = [
  {
    key: 'vinyl',
    name: 'Premium Vinyl',
    accentColor: '#F97316',
    description: 'Fade-resistant, insulated, zero maintenance. 200+ colors.',
    textureImage:
      '/placeholders/600x400.svg',
    colors: [
      { name: 'Arctic White', hex: '#F8F8F8', sku: 'VNL-ARW' },
      { name: 'Linen', hex: '#EDE8DC', sku: 'VNL-LIN' },
      { name: 'Sandstone', hex: '#C8B89A', sku: 'VNL-SND' },
      { name: 'Clay', hex: '#B8A080', sku: 'VNL-CLY' },
      { name: 'Wheat', hex: '#D4C4A0', sku: 'VNL-WHT' },
      { name: 'Sage Green', hex: '#7A8C6E', sku: 'VNL-SGE' },
      { name: 'Hunter Green', hex: '#2A3A2A', sku: 'VNL-HGR' },
      { name: 'Colonial Blue', hex: '#4A5A6E', sku: 'VNL-CBL' },
      { name: 'Slate Gray', hex: '#6B7280', sku: 'VNL-SLG' },
      { name: 'Charcoal', hex: '#3D3D3D', sku: 'VNL-CHR' },
      { name: 'Midnight', hex: '#1E2330', sku: 'VNL-MID' },
      { name: 'Cranberry', hex: '#8B2A2A', sku: 'VNL-CRB' },
      { name: 'Autumn Red', hex: '#A04030', sku: 'VNL-AUR' },
      { name: 'Warm Beige', hex: '#D0C0A0', sku: 'VNL-WBG' },
      { name: 'Mocha', hex: '#6E4E3A', sku: 'VNL-MCH' },
      { name: 'Cream', hex: '#F0EAD6', sku: 'VNL-CRM' },
    ],
  },
  {
    key: 'hardie',
    name: 'James Hardie ColorPlus',
    accentColor: '#1F2937',
    description: 'Baked-on ColorPlus finish. 15-year color warranty.',
    textureImage:
      '/placeholders/600x400.svg',
    colors: [
      { name: 'Arctic White', hex: '#F5F5F0', sku: 'HDI-ARW' },
      { name: 'Cobble Stone', hex: '#A8A090', sku: 'HDI-CBS' },
      { name: 'Monterey Taupe', hex: '#9A8A7A', sku: 'HDI-MTP' },
      { name: 'Heathered Moss', hex: '#6A7A5A', sku: 'HDI-HMS' },
      { name: 'Iron Gray', hex: '#4A4A4A', sku: 'HDI-IRG' },
      { name: 'Night Gray', hex: '#3A3A3A', sku: 'HDI-NGR' },
      { name: 'Pearl Gray', hex: '#B8B8B0', sku: 'HDI-PGR' },
      { name: 'Sail Cloth', hex: '#E0D8C8', sku: 'HDI-SCL' },
      { name: 'Woodstock Brown', hex: '#5A4A3A', sku: 'HDI-WBR' },
      { name: 'Timber Bark', hex: '#4A3A2A', sku: 'HDI-TBR' },
      { name: 'Rich Espresso', hex: '#3A2A1A', sku: 'HDI-ESP' },
      { name: 'Countrylane Red', hex: '#7A2A2A', sku: 'HDI-CRE' },
      { name: 'Boothbay Blue', hex: '#3A4A5A', sku: 'HDI-BBL' },
      { name: 'Deep Ocean', hex: '#1E2A3A', sku: 'HDI-DOC' },
      { name: 'Summit Brown', hex: '#6A5A4A', sku: 'HDI-SBR' },
    ],
  },
  {
    key: 'wood',
    name: 'Natural Wood / Cedar',
    accentColor: '#92400E',
    description: 'Cedar & redwood. Timeless warmth. Stainable and paintable.',
    textureImage:
      '/placeholders/600x400.svg',
    colors: [
      { name: 'Natural Cedar', hex: '#C8A880', sku: 'WOD-NCD' },
      { name: 'Redwood', hex: '#A06850', sku: 'WOD-RED' },
      { name: 'Honey Amber', hex: '#D4A860', sku: 'WOD-HAM' },
      { name: 'Driftwood', hex: '#A89880', sku: 'WOD-DRF' },
      { name: 'Weathered Gray', hex: '#7A7A6E', sku: 'WOD-WGR' },
      { name: 'Charred Black', hex: '#2A2A2A', sku: 'WOD-CHB' },
      { name: 'Western Red', hex: '#8B3A2A', sku: 'WOD-WRE' },
      { name: 'Golden Oak', hex: '#C09040', sku: 'WOD-GOK' },
      { name: 'Clear Pine', hex: '#E8D8B8', sku: 'WOD-CPN' },
      { name: 'Dark Walnut', hex: '#3A2A1A', sku: 'WOD-DWN' },
      { name: 'Coastal Teak', hex: '#B8A070', sku: 'WOD-CTE' },
      { name: 'Silver Fir', hex: '#A0A8A0', sku: 'WOD-SFR' },
    ],
  },
] as const;

export const SIDING_HOUSE_PREVIEWS = {
  vinyl: {
    houseImage:
      '/placeholders/800x500.svg',
  },
  hardie: {
    houseImage:
      '/placeholders/800x500.svg',
  },
  wood: {
    houseImage:
      '/placeholders/800x500.svg',
  },
};

export type SidingPaletteType = typeof SIDING_COLOR_PALETTES[number];
export type SidingColor = SidingPaletteType['colors'][number];

export const SIDING_COLOR_PAIRINGS: Record<string, {
  roof: Array<{ name: string; hex: string; vibe: string }>;
  trim: Array<{ name: string; hex: string; accent: string }>;
  accent: Array<{ name: string; hex: string; use: string }>;
  mood: string;
  description: string;
}> = {
  'VNL-ARW': {
    roof: [
      { name: 'Charcoal', hex: '#3a3a3a', vibe: 'Crisp contrast' },
      { name: 'Pewter Gray', hex: '#6b6b6b', vibe: 'Soft modern' },
      { name: 'Slate', hex: '#505a64', vibe: 'Coastal calm' },
    ],
    trim: [
      { name: 'Bright White', hex: '#ffffff', accent: 'Seamless blend' },
      { name: 'Soft Gray', hex: '#b0b0b0', accent: 'Subtle edge' },
      { name: 'Black', hex: '#1a1a1a', accent: 'Bold frame' },
    ],
    accent: [
      { name: 'Navy Blue', hex: '#1a2a4a', use: 'Front door' },
      { name: 'Brushed Nickel', hex: '#b0b0b0', use: 'Hardware' },
    ],
    mood: 'Clean & Timeless',
    description: 'White siding is the blank canvas that lets your roof and front door do the talking. It reflects heat, keeps interiors cool, and pairs with virtually any roof color.',
  },
  'VNL-SGE': {
    roof: [
      { name: 'Weathered Wood', hex: '#7a6b5a', vibe: 'Natural harmony' },
      { name: 'Heather Blend', hex: '#7a6e60', vibe: 'Tonal blend' },
      { name: 'Charcoal', hex: '#3a3a3a', vibe: 'Modern contrast' },
    ],
    trim: [
      { name: 'Cream', hex: '#f0ead6', accent: 'Warm glow' },
      { name: 'White', hex: '#fafafa', accent: 'Fresh border' },
      { name: 'Walnut', hex: '#5a4a3a', accent: 'Woodsy frame' },
    ],
    accent: [
      { name: 'Barn Red', hex: '#8b2a2a', use: 'Door & shutters' },
      { name: 'Wrought Iron', hex: '#3a3a3a', use: 'Railings' },
    ],
    mood: 'Natural & Fresh',
    description: 'Sage green siding blends beautifully with Evansville\'s mature tree canopy. It feels organic and calming while still giving your home a distinctive identity.',
  },
  'VNL-SLG': {
    roof: [
      { name: 'Black Oak', hex: '#1e1e1e', vibe: 'Dramatic depth' },
      { name: 'Slatestone Gray', hex: '#6a6a6a', vibe: 'Tonal harmony' },
      { name: 'Pewter Gray', hex: '#6b6b6b', vibe: 'Soft contrast' },
    ],
    trim: [
      { name: 'Bright White', hex: '#ffffff', accent: 'Maximum pop' },
      { name: 'Light Gray', hex: '#c0c0c0', accent: 'Subtle edge' },
      { name: 'Charcoal', hex: '#4a4a4a', accent: 'Defined frame' },
    ],
    accent: [
      { name: 'Yellow', hex: '#d4af37', use: 'Door & planters' },
      { name: 'Cobalt', hex: '#3a5a8a', use: 'Shutters' },
    ],
    mood: 'Sophisticated & Modern',
    description: 'Slate gray siding is the modern homeowner\'s go-to. It pairs with clean whites for a Scandinavian look or deep navies for an upscale, moody feel.',
  },
  'HDI-IRG': {
    roof: [
      { name: 'Stonegate Gray', hex: '#6a6a6a', vibe: 'Premium blend' },
      { name: 'Black Oak', hex: '#1e1e1e', vibe: 'Bold contrast' },
      { name: 'Sierra Gray', hex: '#7a7a72', vibe: 'Soft pairing' },
    ],
    trim: [
      { name: 'White', hex: '#f5f5f0', accent: 'Crisp luxury' },
      { name: 'Light Gray', hex: '#c0c0c0', accent: 'Subtle refinement' },
      { name: 'Charcoal', hex: '#4a4a4a', accent: 'Defined edge' },
    ],
    accent: [
      { name: 'Deep Navy', hex: '#1a2a4a', use: 'Front door elegance' },
      { name: 'Brushed Steel', hex: '#a8a8a8', use: 'Premium hardware' },
    ],
    mood: 'Elegant & Understated',
    description: 'Iron Gray Hardie reads as expensive from the street. It hides imperfections beautifully and elevates any trim and door combination you choose.',
  },
  'HDI-MTP': {
    roof: [
      { name: 'Heather Blend', hex: '#7a6e60', vibe: 'Warm harmony' },
      { name: 'Pewter Gray', hex: '#6b6b6b', vibe: 'Neutral contrast' },
      { name: 'Hickory', hex: '#8b6f47', vibe: 'Golden warmth' },
    ],
    trim: [
      { name: 'Cream', hex: '#f0e8d6', accent: 'Warm border' },
      { name: 'White', hex: '#ffffff', accent: 'Clean frame' },
      { name: 'Walnut', hex: '#5a4a3a', accent: 'Woodsy edge' },
    ],
    accent: [
      { name: 'Brick Red', hex: '#8b3a3a', use: 'Door or planters' },
      { name: 'Wrought Iron', hex: '#3a3a3a', use: 'Railings & lights' },
    ],
    mood: 'Warm & Refined',
    description: 'Monterey Taupe is a chameleon — warm in morning light, sophisticated in shade. It is the most versatile Hardie color for Evansville\'s mixed-tree neighborhoods.',
  },
  'HDI-ESP': {
    roof: [
      { name: 'Pewter Gray', hex: '#6b6b6b', vibe: 'Soft contrast' },
      { name: 'Sierra Gray', hex: '#7a7a72', vibe: 'Airiness' },
      { name: 'White', hex: '#ffffff', vibe: 'Crisp definition' },
    ],
    trim: [
      { name: 'Bright White', hex: '#ffffff', accent: 'Maximum pop' },
      { name: 'Cream', hex: '#f5f0e0', accent: 'Warm glow' },
      { name: 'Light Gray', hex: '#c0c0c0', accent: 'Subtle edge' },
    ],
    accent: [
      { name: 'Gold', hex: '#d4af37', use: 'House numbers & lights' },
      { name: 'Teal', hex: '#2a6b6b', use: 'Shutters' },
    ],
    mood: 'Dramatic & Luxe',
    description: 'Rich Espresso is the darkest Hardie option. It demands light trim to avoid a cave-like exterior, but the payoff is an undeniably striking, high-contrast curb appeal.',
  },
  'WOD-NCD': {
    roof: [
      { name: 'Weathered Wood', hex: '#7a6b5a', vibe: 'Natural blend' },
      { name: 'Heather Blend', hex: '#7a6e60', vibe: 'Tonal harmony' },
      { name: 'Slate', hex: '#505a64', vibe: 'Cool contrast' },
    ],
    trim: [
      { name: 'Ivory', hex: '#f5f0e0', accent: 'Warm border' },
      { name: 'White', hex: '#ffffff', accent: 'Crisp frame' },
      { name: 'Dark Brown', hex: '#3a2a1a', accent: 'Rich edge' },
    ],
    accent: [
      { name: 'Forest Green', hex: '#1a3a1a', use: 'Shutters & landscaping' },
      { name: 'Burnished Copper', hex: '#b87333', use: 'Premium fixtures' },
    ],
    mood: 'Warm & Organic',
    description: 'Natural cedar siding brings unmatched warmth and character. It literally glows in golden hour light and ages gracefully into a silver-gray patina if left unstained.',
  },
  'WOD-WGR': {
    roof: [
      { name: 'Black Oak', hex: '#1e1e1e', vibe: 'Modern contrast' },
      { name: 'Stonegate', hex: '#6a6a6a', vibe: 'Tonal blend' },
      { name: 'Slate', hex: '#505a64', vibe: 'Cool harmony' },
    ],
    trim: [
      { name: 'White', hex: '#fafafa', accent: 'Maximum pop' },
      { name: 'Light Gray', hex: '#c0c0c0', accent: 'Soft edge' },
      { name: 'Charcoal', hex: '#4a4a4a', accent: 'Defined frame' },
    ],
    accent: [
      { name: 'Navy Blue', hex: '#1a2a4a', use: 'Door statement' },
      { name: 'Stainless', hex: '#a0a0a0', use: 'Modern hardware' },
    ],
    mood: 'Coastal & Serene',
    description: 'Weathered gray cedar evokes beach house elegance. It pairs beautifully with crisp white trim and navy accents for a look that feels intentional and serene.',
  },
};

export const SIDING_DEFAULT_PAIRING = {
  roof: [
    { name: 'Pewter Gray', hex: '#6b6b6b', vibe: 'Safe & versatile' },
    { name: 'Weathered Wood', hex: '#7a6b5a', vibe: 'Warm & organic' },
    { name: 'Charcoal', hex: '#3a3a3a', vibe: 'Modern contrast' },
  ],
  trim: [
    { name: 'Bright White', hex: '#ffffff', accent: 'Clean & crisp' },
    { name: 'Warm Cream', hex: '#f0ead6', accent: 'Soft glow' },
    { name: 'Medium Gray', hex: '#9a9a9a', accent: 'Tonal balance' },
  ],
  accent: [
    { name: 'Navy Blue', hex: '#1a2a4a', use: 'Classic door' },
    { name: 'Forest Green', hex: '#2a4a2a', use: 'Nature accent' },
  ],
  mood: 'Versatile & Balanced',
  description: 'This siding color is versatile enough to pair with a wide range of roof and trim options. White, cream, and gray are always safe bets that let your siding do the talking.',
};