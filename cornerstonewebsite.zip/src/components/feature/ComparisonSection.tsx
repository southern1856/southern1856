import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const rows = [
  {
    feature: 'Free On-Roof Inspection',
    us: true,
    usNote: 'We get on the roof every time',
    them: false,
    themNote: 'Most eyeball from the driveway',
  },
  {
    feature: 'Adjuster Meeting Included',
    us: true,
    usNote: 'We show up with your adjuster',
    them: false,
    themNote: 'You\'re on your own',
  },
  {
    feature: 'Manufacturer Certified',
    us: true,
    usNote: 'GAF, Owens Corning, CertainTeed',
    them: null,
    themNote: 'Varies — often uncertified',
  },
  {
    feature: 'Lifetime Workmanship Warranty',
    us: true,
    usNote: 'On qualifying installs',
    them: false,
    themNote: 'Typically 1–2 years only',
  },
  {
    feature: 'Daily Job Site Cleanup',
    us: true,
    usNote: 'Magnetic nail sweep every evening',
    them: null,
    themNote: 'Inconsistent',
  },
  {
    feature: 'Financing Available',
    us: true,
    usNote: 'From $89/mo, same-day approval',
    them: false,
    themNote: 'Cash or check only',
  },
  {
    feature: 'Photo Documentation',
    us: true,
    usNote: 'Before, during, and after every job',
    them: false,
    themNote: 'Rarely provided',
  },
  {
    feature: 'Supplement Filing',
    us: true,
    usNote: 'We fight for every dollar',
    them: false,
    themNote: 'Accept first offer',
  },
  {
    feature: 'Local Evansville Crew',
    us: true,
    usNote: 'Our guys live here',
    them: null,
    themNote: 'Often out-of-state subs',
  },
  {
    feature: '24/7 Emergency Line',
    us: true,
    usNote: 'Real person, always',
    them: false,
    themNote: 'Voicemail after hours',
  },
];

export default function ComparisonSection() {
  const navigate = useNavigate();
  const header = useScrollAnimation({ threshold: 0.1 });
  const table = useScrollAnimation({ threshold: 0.05 });

  return (
    <section className="py-20 md:py-28 px-6 md:px-10 lg:px-16 bg-charcoal overflow-hidden">
      <div className="w-full">
        {/* Header */}
        <div
          ref={header.ref as React.RefObject<HTMLDivElement>}
          className={`text-center mb-14 md:mb-18 anim-fade-up ${header.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Why Corner Stone</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
            Us vs. The Other Guys
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Not all roofers are the same. Here is what separates Corner Stone from the competition — in plain English.
          </p>
        </div>

        {/* Comparison Table */}
        <div
          ref={table.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${table.isVisible ? 'is-visible' : ''}`}
        >
          {/* Column headers */}
          <div className="grid grid-cols-[1fr_auto_auto] md:grid-cols-[1fr_280px_280px] gap-0 mb-2">
            <div className="px-4 py-3" />
            <div className="px-4 py-3 bg-orange text-center">
              <div className="flex items-center justify-center gap-2">
                <img
                  src="/logo.svg"
                  alt="Corner Stone"
                  className="w-6 h-6 object-contain rounded"
                />
                <span className="font-display text-white text-sm md:text-base uppercase tracking-wider">Corner Stone</span>
              </div>
            </div>
            <div className="px-4 py-3 bg-charcoal-mid border border-white/10 text-center">
              <span className="font-display text-white/40 text-sm md:text-base uppercase tracking-wider">Other Roofers</span>
            </div>
          </div>

          {/* Rows */}
          <div className="border border-white/10 overflow-hidden">
            {rows.map((row, i) => (
              <div
                key={row.feature}
                className={`grid grid-cols-[1fr_auto_auto] md:grid-cols-[1fr_280px_280px] gap-0 border-b border-white/10 last:border-0 transition-colors duration-200 hover:bg-white/[0.02] ${
                  i % 2 === 0 ? 'bg-transparent' : 'bg-white/[0.015]'
                }`}
              >
                {/* Feature name */}
                <div className="px-4 md:px-6 py-4 flex items-center">
                  <span className="text-white/70 text-sm font-medium">{row.feature}</span>
                </div>

                {/* Corner Stone */}
                <div className="px-4 md:px-6 py-4 bg-orange/5 border-l border-orange/20 flex flex-col items-center justify-center text-center gap-1">
                  <div className="w-6 h-6 flex items-center justify-center bg-orange rounded-full flex-shrink-0">
                    <i className="ri-check-line text-white text-xs" />
                  </div>
                  <span className="text-white/60 text-xs leading-tight hidden md:block">{row.usNote}</span>
                </div>

                {/* Others */}
                <div className="px-4 md:px-6 py-4 border-l border-white/10 flex flex-col items-center justify-center text-center gap-1">
                  {row.them === true ? (
                    <div className="w-6 h-6 flex items-center justify-center bg-white/10 rounded-full flex-shrink-0">
                      <i className="ri-check-line text-white/40 text-xs" />
                    </div>
                  ) : row.them === null ? (
                    <div className="w-6 h-6 flex items-center justify-center bg-amber-500/20 rounded-full flex-shrink-0">
                      <i className="ri-subtract-line text-amber-500 text-xs" />
                    </div>
                  ) : (
                    <div className="w-6 h-6 flex items-center justify-center bg-red-500/15 rounded-full flex-shrink-0">
                      <i className="ri-close-line text-red-400 text-xs" />
                    </div>
                  )}
                  <span className="text-white/30 text-xs leading-tight hidden md:block">{row.themNote}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center gap-5 mt-4 px-1">
            <div className="flex items-center gap-2 text-white/40 text-xs">
              <div className="w-5 h-5 flex items-center justify-center bg-orange rounded-full">
                <i className="ri-check-line text-white text-xs" />
              </div>
              Included
            </div>
            <div className="flex items-center gap-2 text-white/40 text-xs">
              <div className="w-5 h-5 flex items-center justify-center bg-amber-500/20 rounded-full">
                <i className="ri-subtract-line text-amber-500 text-xs" />
              </div>
              Varies by contractor
            </div>
            <div className="flex items-center gap-2 text-white/40 text-xs">
              <div className="w-5 h-5 flex items-center justify-center bg-red-500/15 rounded-full">
                <i className="ri-close-line text-red-400 text-xs" />
              </div>
              Typically not included
            </div>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className={`mt-12 flex flex-col md:flex-row items-center justify-between gap-6 border border-white/10 bg-charcoal-mid px-8 py-7 anim-fade-up ${table.isVisible ? 'is-visible' : ''}`} style={{ transitionDelay: '200ms' }}>
          <div>
            <p className="text-white font-display text-xl md:text-2xl uppercase tracking-wider mb-1">
              The difference is clear.
            </p>
            <p className="text-white/40 text-sm">
              Free inspection · No pressure · Serving Evansville &amp; Tri-State since 1995
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 flex-shrink-0">
            <button
              onClick={() => navigate('/estimate')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              Get a Free Estimate
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/20 hover:border-white text-white font-semibold px-8 py-4 uppercase tracking-wide text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
