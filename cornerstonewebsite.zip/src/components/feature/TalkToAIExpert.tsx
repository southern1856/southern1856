import { useEffect, useRef, useState } from 'react';
import { alexQuickQuestions } from '@/mocks/alexKnowledgeBase';

export default function TalkToAIExpert() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const handleOpenAgent = () => {
    const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
    if (btn) btn.click();
  };

  const handleAskQuestion = (label: string) => {
    const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
    if (btn) btn.click();
    // After a short delay for the widget to open, send the pre-filled question
    setTimeout(() => {
      const input = document.querySelector('input[placeholder*="message"], textarea[placeholder*="message"], input[placeholder*="ask"], textarea[placeholder*="ask"]') as HTMLInputElement | HTMLTextAreaElement | null;
      if (input) {
        input.value = label;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        // Try to submit
        const form = input.closest('form');
        if (form) {
          const submitBtn = form.querySelector('button[type="submit"], button[aria-label*="send"], button svg') as HTMLElement | null;
          if (submitBtn) submitBtn.click();
        }
      }
    }, 800);
  };

  return (
    <section
      ref={sectionRef}
      className={`bg-charcoal-deep border-y border-white/5 transition-all duration-700 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4 md:px-8 py-6 md:py-12">
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-10">
          {/* Avatar / Icon side */}
          <button
            onClick={handleOpenAgent}
            className="relative flex-shrink-0 group cursor-pointer"
            aria-label="Open AI roofing assistant"
          >
            <div className="absolute inset-0 bg-orange/20 rounded-full blur-2xl animate-pulse" />
            <div className="relative w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 flex items-center justify-center bg-charcoal border-2 border-orange/40 rounded-full group-hover:border-orange transition-colors duration-300">
              <i className="ri-mic-line text-2xl sm:text-3xl md:text-4xl text-orange" />
            </div>
            <span className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-400 border-2 border-charcoal-deep rounded-full" />
          </button>

          {/* Text content */}
          <div className="flex-1 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
              <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <span className="text-green-400 text-xs font-semibold uppercase tracking-widest">
                AI Assistant Online — Voice or Chat
              </span>
            </div>
            <h3 className="text-white text-lg md:text-2xl font-bold mb-2">
              Ask Our Roofing AI Anything
            </h3>
            <p className="text-white/50 text-sm md:text-base max-w-lg leading-relaxed mb-4">
              Get instant Evansville pricing, insurance guidance, material comparisons,
              timeline estimates, and even book a free inspection — all through natural
              conversation. Type or talk, your choice.
            </p>

            {/* Quick question pills */}
            <div className="flex flex-wrap justify-center md:justify-start gap-2">
              {alexQuickQuestions.map((q) => (
                <button
                  key={q.label}
                  onClick={() => handleAskQuestion(q.label)}
                  className="text-xs font-medium px-3 py-2 md:px-3.5 bg-charcoal border border-white/10 hover:border-orange/50 hover:text-orange text-white/60 transition-all duration-200 whitespace-nowrap cursor-pointer rounded-md"
                >
                  {q.label}
                </button>
              ))}
            </div>
          </div>

          {/* CTA side */}
          <div className="flex-shrink-0 space-y-3">
            <button
              onClick={handleOpenAgent}
              className="group flex items-center justify-center gap-3 bg-orange hover:bg-orange-dark text-white px-6 py-3.5 font-semibold text-sm uppercase tracking-widest transition-colors duration-300 cursor-pointer w-full sm:w-auto whitespace-nowrap"
            >
              <i className="ri-mic-line text-lg" />
              <span>Talk or Chat Now</span>
              <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform duration-200" />
            </button>
            <p className="text-white/25 text-xs text-center md:text-left hidden sm:block">
              Click the floating button in the bottom-right corner from any page
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}