export default function BrandedSignatureBlock() {
  return (
    <div className="w-full bg-white border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-10">
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-8">
          <div className="flex items-center justify-center h-14 w-14 bg-charcoal-deep rounded-xl shrink-0">
            <img
              src="/logo.svg"
              alt="Corner Stone Construction & Roofing"
              className="h-10 w-10 object-contain rounded"
            />
          </div>
          <div className="text-center sm:text-left">
            <p className="font-display text-charcoal-deep text-xl tracking-wider uppercase leading-none">
              Corner Stone
            </p>
            <p className="text-gray-400 text-[0.65rem] tracking-[0.2em] uppercase font-medium mt-1">
              Construction & Roofing — Evansville, Indiana
            </p>
          </div>
          <div className="hidden sm:block w-px h-10 bg-gray-200" />
          <div className="flex flex-col sm:flex-row items-center gap-3 text-xs text-gray-400">
            <a
              href="tel:8122135997"
              className="flex items-center gap-1.5 hover:text-orange transition-colors whitespace-nowrap"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
            <span className="hidden sm:inline text-gray-300">|</span>
            <a
              href="mailto:themainstoneconstruction@gmail.com"
              className="flex items-center gap-1.5 hover:text-orange transition-colors whitespace-nowrap"
            >
              <i className="ri-mail-line text-orange" />
              Email Us
            </a>
          </div>
          <div className="hidden md:block w-px h-10 bg-gray-200" />
          <div className="hidden md:flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((s) => (
              <i key={s} className="ri-star-fill text-orange text-xs" />
            ))}
            <span className="text-gray-400 text-[0.6rem] ml-1 uppercase tracking-wider">
              287+ Reviews
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}