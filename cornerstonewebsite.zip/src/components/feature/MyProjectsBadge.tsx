import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';

interface MyProjectsBadgeProps {
  className?: string;
}

export default function MyProjectsBadge({ className = '' }: MyProjectsBadgeProps) {
  const [activeCount, setActiveCount] = useState<number | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function fetchActiveProjects() {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user?.id) {
        if (!cancelled) setActiveCount(0);
        return;
      }

      const { data, error } = await supabase
        .from('customer_projects')
        .select('id', { count: 'exact', head: true })
        .eq('customer_id', session.user.id)
        .not('current_phase', 'in', '("completed","cancelled")');

      if (error) {
        console.error('Failed to fetch active projects:', error.message);
        if (!cancelled) setActiveCount(0);
        return;
      }

      if (!cancelled) setActiveCount(data === null ? 0 : (data as unknown as number));
    }

    fetchActiveProjects();

    return () => { cancelled = true; };
  }, []);

  const hasNotifications = activeCount !== null && activeCount > 0;

  return (
    <Link
      to="/customer-portal"
      className={`relative inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 border border-white/15 hover:border-orange/40 px-4 py-2 rounded-full text-white text-xs font-bold uppercase tracking-widest transition-all duration-300 cursor-pointer whitespace-nowrap group/projects ${className}`}
    >
      <div className="w-5 h-5 flex items-center justify-center relative">
        <i className="ri-folder-user-line text-sm group-hover/projects:text-orange transition-colors" />
        {hasNotifications && (
          <span className="absolute -top-1.5 -right-2.5 min-w-[16px] h-4 flex items-center justify-center px-1 bg-orange text-white text-[9px] font-bold rounded-full leading-none">
            {activeCount}
          </span>
        )}
      </div>
      <span className="group-hover/projects:text-orange transition-colors">My Projects</span>
      <div className="w-4 h-4 flex items-center justify-center">
        <i className="ri-arrow-right-up-line text-[10px] text-white/40 group-hover/projects:text-orange transition-colors" />
      </div>

      {/* Tooltip */}
      {hasNotifications && (
        <div className="absolute -top-9 left-1/2 -translate-x-1/2 opacity-0 invisible group-hover/projects:opacity-100 group-hover/projects:visible transition-all duration-200 pointer-events-none">
          <div className="bg-foreground-900 text-background-50 text-[11px] font-semibold px-3 py-1.5 rounded-md whitespace-nowrap shadow-lg">
            {activeCount} update{activeCount !== 1 ? 's' : ''}
          </div>
          <div className="absolute left-1/2 -translate-x-1/2 -bottom-1 w-2 h-2 bg-foreground-900 rotate-45" />
        </div>
      )}
    </Link>
  );
}