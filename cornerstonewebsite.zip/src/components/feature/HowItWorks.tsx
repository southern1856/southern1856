import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const STEPS = [
  {
    number: '01',
    icon: 'ri-phone-line',
    title: 'Call or Click',
    desc: 'Reach out by phone or fill out our quick online form. We respond within 2 hours — often same day.',
    detail: 'No robots, no call centers. A real Corner Stone team member picks up.',
    color: 'from-orange/20 to-transparent',
  },
  {
    number: '02',
    icon: 'ri-search-eye-line',
    title: 'Free Inspection',
    desc: 'We come to you. Our certified inspector climbs up, documents everything, and gives you a full photo report.',
    detail: '100% free, no obligation. We find what others miss.',
    color: 'from-orange/15 to-transparent',
  },
  {
    number: '03',
    icon: 'ri-file-list-3-line',
    title: 'Clear Quote',
    desc: 'You get a written, itemized estimate with zero hidden fees. We walk you through every line item.',
    detail: 'We also handle your insurance claim paperwork if needed.',
    color: 'from-orange/10 to-transparent',
  },
  {
    number: '04',
    icon: 'ri-hammer-line',
    title: 'We Get to Work',
    desc: 'Our crew shows up on time, works clean, and finishes strong. Final walkthrough with you before we leave.',
    detail: 'Average job start: 48 hours after approval.',
    color: 'from-orange/20 to-transparent',
  },
];

export default function HowItWorks() {
  const navigate = useNavigate();
  const header = useScrollAnimation({ threshold: 0.1 });
  const steps = useScrollAnimation({ threshold: 0.05 });
  const cta = useScrollAnimation({ threshold: 0.1 });

  return (
    <section className="bg-charcoal py-20 md:py-28 overflow-hidden">
      <div className="w-full px-6 md:px-10 lg:px-16">

        {/* Header */}
        <div
          ref={header.ref as React.RefObject<HTMLDivElement>}
          className={`flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16 md:mb-20 anim-fade-up ${header.isVisible ? 'is-visible' : ''}`}
        >
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Simple Process</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
              From Call<br />To Complete
            </h2>
          </div>
          <p className="text-white/40 text-sm md:text-base max-w-xs leading-relaxed">
            We made it dead simple. Four steps and your roof is done — no stress, no surprises.
          </p>
        </div>

        {/* Steps */}
        <div
          ref={steps.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
        >
          {STEPS.map((step, i) => (
            <div
              key={step.number}
              className={`relative border border-white/10 bg-charcoal-mid p-8 md:p-10 group hover:border-orange/40 transition-all duration-300 anim-fade-up ${steps.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 120}ms` }}
            >
              {/* Connector line (desktop) */}
              {i < STEPS.length - 1 && (
                <div className="hidden lg:block absolute top-10 -right-2 w-4 h-px bg-white/10 z-10" />
              )}

              {/* Step number */}
              <div className="flex items-center justify-between mb-8">
                <span className="font-display text-white/10 text-6xl leading-none tracking-wider group-hover:text-orange/20 transition-colors duration-300">
                  {step.number}
                </span>
                <div className="w-12 h-12 flex items-center justify-center border border-white/10 group-hover:border-orange group-hover:bg-orange/10 transition-all duration-300">
                  <i className={`${step.icon} text-white/40 group-hover:text-orange text-xl transition-colors duration-300`} />
                </div>
              </div>

              <h3 className="font-display text-white text-2xl uppercase tracking-wider mb-3 group-hover:text-orange transition-colors duration-300">
                {step.title}
              </h3>
              <p className="text-white/50 text-sm leading-relaxed mb-4">{step.desc}</p>
              <p className="text-orange/70 text-xs leading-relaxed border-t border-white/5 pt-4">
                <i className="ri-check-line mr-1" />
                {step.detail}
              </p>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div
          ref={cta.ref as React.RefObject<HTMLDivElement>}
          className={`mt-12 flex flex-col sm:flex-row items-center justify-between gap-6 border border-white/10 bg-charcoal-mid px-8 py-6 anim-fade-up ${cta.isVisible ? 'is-visible' : ''}`}
        >
          <div>
            <p className="text-white font-semibold text-lg">Ready to start? Step 1 takes 60 seconds.</p>
            <p className="text-white/40 text-sm mt-1">Free inspection · No pressure · Tri-State area</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 flex-shrink-0">
            <button
              onClick={() => navigate('/estimate')}
              className="bg-orange hover:bg-orange-dark text-white text-sm font-bold px-8 py-4 uppercase tracking-widest transition-colors duration-200 whitespace-nowrap cursor-pointer"
            >
              Get Free Estimate
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/20 hover:border-orange text-white/70 hover:text-white text-sm font-semibold px-8 py-4 uppercase tracking-widest transition-all duration-200 whitespace-nowrap flex items-center justify-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
