import { useEffect, useRef, useState } from 'react';

export default function BrandWatermark() {
  const [visible, setVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        setVisible(entry.isIntersecting);
      },
      { threshold: 0.05, rootMargin: '0px 0px -200px 0px' }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <div ref={ref} className="relative">
      {/* Watermark layer */}
      <div
        className="fixed inset-0 pointer-events-none z-[1] transition-opacity duration-700"
        style={{ opacity: visible ? 1 : 0 }}
        aria-hidden="true"
      >
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-4 opacity-[0.035]">
          <img
            src="/logo.svg"
            alt=""
            className="w-40 h-40 md:w-56 md:h-56 object-contain rounded-2xl grayscale"
          />
          <span className="font-display text-charcoal-deep text-6xl md:text-8xl tracking-[0.15em] uppercase whitespace-nowrap">
            Corner Stone
          </span>
        </div>
      </div>
    </div>
  );
}