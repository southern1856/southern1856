import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { trackConversion } from '@/lib/toolAnalytics';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

export default function ContactSection() {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [charCount, setCharCount] = useState(0);
  const formRef = useRef<HTMLFormElement>(null);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;

    const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
    const message = formData.get('message') as string;

    if (message && message.length > 500) {
      setStatus('error');
      return;
    }

    setStatus('submitting');

    try {
      const response = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      });

      if (response.ok) {
        setStatus('success');
        formRef.current.reset();
        setCharCount(0);
        trackConversion('contact_form');
        navigate('/thank-you');
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    }
  };

  const handleMessageChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setCharCount(e.target.value.length);
  };

  return (
    <section id="contact" className="bg-charcoal py-20 md:py-28 lg:py-32">
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="max-w-3xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-10 md:mb-16">
            <p className="text-orange text-xs md:text-sm font-semibold tracking-[0.2em] uppercase mb-4">
              Get In Touch
            </p>
            <h2 className="font-display font-bold text-white text-3xl md:text-4xl lg:text-5xl mb-5">
              Free Roofing Estimate in Evansville
            </h2>
            <p className="text-white/60 text-base md:text-lg leading-relaxed">
              Serving Evansville, Newburgh, Boonville, and all of Vanderburgh County. Fill out the form and our local team will respond within 24 hours.
            </p>
          </div>

          {/* Form Container */}
          <div className="bg-white rounded-3xl p-6 md:p-10 lg:p-14">
            <form
              ref={formRef}
              data-readdy-form
              onSubmit={handleSubmit}
              className="space-y-5 md:space-y-6"
            >
              {/* Row 1: Name & Email */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-6">
                <div>
                  <label htmlFor="name" className="block text-charcoal text-sm font-medium mb-2">
                    Full Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    required
                    placeholder="John Smith"
                    className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:ring-0 border-b-3 border-transparent focus:border-orange transition-colors"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-charcoal text-sm font-medium mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    placeholder="your@email.com"
                    className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:ring-0 border-b-3 border-transparent focus:border-orange transition-colors"
                  />
                </div>
              </div>

              {/* Row 2: Phone & Service */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-6">
                <div>
                  <label htmlFor="phone" className="block text-charcoal text-sm font-medium mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    required
                    placeholder="812-213-5997"
                    className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:ring-0 border-b-3 border-transparent focus:border-orange transition-colors"
                  />
                </div>
                <div>
                  <label htmlFor="service" className="block text-charcoal text-sm font-medium mb-2">
                    Service Type
                  </label>
                  <select
                    id="service"
                    name="service"
                    required
                    className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm focus:outline-none focus:ring-0 border-b-3 border-transparent focus:border-orange transition-colors appearance-none cursor-pointer"
                  >
                    <option value="">Select a service</option>
                    <option value="residential">Residential Roofing</option>
                    <option value="commercial">Commercial Roofing</option>
                    <option value="repair">Roof Repair</option>
                    <option value="inspection">Roof Inspection</option>
                    <option value="emergency">Emergency Service</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              {/* Row 3: Message */}
              <div>
                <label htmlFor="message" className="block text-charcoal text-sm font-medium mb-2">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows={4}
                  maxLength={500}
                  onChange={handleMessageChange}
                  placeholder="Tell us about your Evansville roofing project..."
                  className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:ring-0 border-b-3 border-transparent focus:border-orange transition-colors resize-none"
                />
                <p className={`text-xs mt-1 text-right ${charCount > 500 ? 'text-red-500' : 'text-gray-400'}`}>
                  {charCount}/500
                </p>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={status === 'submitting'}
                className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-400 text-white font-semibold text-base py-4 rounded-xl transition-colors duration-300 flex items-center justify-center gap-2 cursor-pointer"
              >
                {status === 'submitting' ? (
                  <>
                    <i className="ri-loader-4-line animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    Send Message
                    <i className="ri-arrow-right-line" />
                  </>
                )}
              </button>

              {/* Status Messages */}
              {status === 'success' && (
                <div className="bg-green-50 border border-green-200 rounded-xl p-4 flex items-center gap-3">
                  <i className="ri-checkbox-circle-line text-green-600 text-xl" />
                  <p className="text-green-700 text-sm">
                    Thank you! Your message has been sent. Our Evansville team will contact you within 24 hours.
                  </p>
                </div>
              )}
              {status === 'error' && (
                <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-3">
                  <i className="ri-alert-line text-red-600 text-xl" />
                  <p className="text-red-700 text-sm">
                    Something went wrong. Please try again or call our Evansville office directly.
                  </p>
                </div>
              )}
            </form>
          </div>

          {/* Contact Info Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 md:gap-8 mt-10 md:mt-14">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 flex items-center justify-center bg-white/10 rounded-full">
                <i className="ri-phone-line text-orange text-xl" />
              </div>
              <div>
                <p className="text-white/50 text-xs uppercase tracking-wider mb-1">Phone</p>
                <p className="text-white text-sm md:text-base font-medium">812-213-5997</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 flex items-center justify-center bg-white/10 rounded-full">
                <i className="ri-mail-line text-orange text-xl" />
              </div>
              <div>
                <p className="text-white/50 text-xs uppercase tracking-wider mb-1">Email</p>
                <p className="text-white text-sm md:text-base font-medium">themainstoneconstruction@gmail.com</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 flex items-center justify-center bg-white/10 rounded-full">
                <i className="ri-map-pin-line text-orange text-xl" />
              </div>
              <div>
                <p className="text-white/50 text-xs uppercase tracking-wider mb-1">Address</p>
                <p className="text-white text-sm md:text-base font-medium">5800 Kansas Rd, Evansville, IN 47725</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
