import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function WorkmanshipGuaranteeWidget() {
  const [visible, setVisible] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      const halfway = document.documentElement.scrollHeight / 2;
      setVisible(window.scrollY > halfway && window.scrollY < document.documentElement.scrollHeight - window.innerHeight - 400);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!visible) return null;

  return (
    <div className={`fixed right-4 md:right-8 top-1/3 z-[56] transition-all duration-500 ${visible ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'}`}>
      <div
        onClick={() => setExpanded(!expanded)}
        className="cursor-pointer group"
      >
        {/* Collapsed pill */}
        <div className={`${expanded ? 'hidden' : 'flex'} items-center gap-2 bg-charcoal-deep border border-orange/30 hover:border-orange px-4 py-3 transition-all`}>
          <i className="ri-shield-star-line text-orange text-lg" />
          <span className="text-white text-xs font-bold uppercase tracking-wider">Lifetime Guarantee</span>
          <i className="ri-arrow-left-s-line text-white/40 text-sm" />
        </div>

        {/* Expanded card */}
        <div className={`${expanded ? 'block' : 'hidden'} bg-charcoal-deep border border-orange/30 w-64 p-5 shadow-2xl`}>
          <div className="flex items-start justify-between mb-3">
            <div className="w-10 h-10 flex items-center justify-center bg-orange/15 text-orange">
              <i className="ri-shield-star-line text-xl" />
            </div>
            <button
              onClick={(e) => { e.stopPropagation(); setExpanded(false); }}
              className="text-white/30 hover:text-white transition-colors"
            >
              <i className="ri-close-line" />
            </button>
          </div>

          <h3 className="font-display text-white text-lg uppercase tracking-wider mb-2">Lifetime Workmanship Warranty</h3>
          <p className="text-white/45 text-xs leading-relaxed mb-4">
            Every roof we install is backed by our lifetime workmanship guarantee. If anything fails due to installation error, we fix it — no questions, no cost, no expiration.
          </p>

          <div className="space-y-2 mb-4">
            {[
              { icon: 'ri-tools-line', text: 'Installation defects covered for life' },
              { icon: 'ri-money-dollar-circle-line', text: 'Zero-cost repairs, no deductible' },
              { icon: 'ri-user-follow-line', text: 'Same crew who installed it returns' },
            ].map((item) => (
              <div key={item.text} className="flex items-center gap-2">
                <i className={`${item.icon} text-orange text-xs`} />
                <span className="text-white/50 text-xs">{item.text}</span>
              </div>
            ))}
          </div>

          <button
            onClick={(e) => { e.stopPropagation(); navigate('/warranty'); }}
            className="bg-orange hover:bg-orange-dark text-white font-semibold w-full py-2.5 uppercase tracking-widest text-xs transition-colors whitespace-nowrap"
          >
            See Full Warranty
          </button>
        </div>
      </div>
    </div>
  );
}