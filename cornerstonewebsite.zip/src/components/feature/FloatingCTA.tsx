import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import CallbackWidget from './CallbackWidget';

export default function FloatingCTA() {
  const [visible, setVisible] = useState(false);
  const [nearFooter, setNearFooter] = useState(false);
  const [showReviewTooltip, setShowReviewTooltip] = useState(false);
  const [showCallback, setShowCallback] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const windowHeight = window.innerHeight;
      const docHeight = document.documentElement.scrollHeight;
      setVisible(scrollY > windowHeight * 0.8);
      setNearFooter(scrollY + windowHeight > docHeight - 400);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleEstimate = () => {
    const el = document.querySelector('#remote-estimate');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else {
      navigate('/estimate');
    }
  };

  const handleBackToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenAIChat = () => {
    const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
    if (btn) btn.click();
  };

  const isShown = visible && !nearFooter;

  return (
    <div className="hidden md:flex fixed bottom-8 right-8 z-50 flex-col items-end gap-3">
      {/* AI Chat button */}
      <button
        onClick={handleOpenAIChat}
        className={`group items-center gap-2 bg-charcoal-light border border-orange/30 hover:border-orange text-orange hover:text-white text-xs font-medium px-4 py-2.5 transition-all duration-500 whitespace-nowrap cursor-pointer ${
          isShown ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
        style={{ transitionDelay: isShown ? '180ms' : '0ms' }}
      >
        <i className="ri-robot-2-line text-sm" />
        Ask AI Assistant
      </button>

      {/* Callback Widget */}
      <div className="relative">
        <CallbackWidget isOpen={showCallback} onClose={() => setShowCallback(false)} />
        <button
          onClick={() => setShowCallback(!showCallback)}
          className={`flex items-center gap-2 bg-charcoal-light border border-white/10 hover:border-orange/50 text-white/70 hover:text-white text-xs font-medium px-4 py-2.5 transition-all duration-500 whitespace-nowrap cursor-pointer ${
            isShown ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 translate-y-4 pointer-events-none'
          }`}
          style={{ transitionDelay: isShown ? '150ms' : '0ms' }}
        >
          <i className="ri-phone-fill text-orange text-sm" />
          Request Callback
        </button>
      </div>
      {/* Phone & Email pill */}
      <div className={`flex items-center gap-0 bg-charcoal-deep border border-white/10 transition-all duration-500 ${
          isShown ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
        style={{ transitionDelay: isShown ? '100ms' : '0ms' }}
      >
        <a
          href="tel:8122135997"
          className="flex items-center gap-2 text-white hover:text-orange text-sm font-bold px-4 py-3 transition-colors whitespace-nowrap cursor-pointer"
        >
          <i className="ri-phone-line text-orange text-lg" />
          812-213-5997
        </a>
        <span className="text-white/10 text-lg">|</span>
        <a
          href="mailto:themainstoneconstruction@gmail.com"
          className="flex items-center gap-2 text-white/70 hover:text-orange text-sm font-semibold px-4 py-3 transition-colors whitespace-nowrap"
          aria-label="Email Corner Stone Construction & Roofing"
        >
          <i className="ri-mail-line text-orange text-lg" />
          Email Us
        </a>
      </div>

      {/* Main CTA button */}
      <button
        onClick={handleEstimate}
        className={`group flex items-center gap-3 bg-orange hover:bg-orange-dark text-white font-semibold px-6 py-4 uppercase tracking-widest text-sm transition-all duration-500 whitespace-nowrap cursor-pointer ${
          isShown ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
      >
        <i className="ri-file-list-3-line text-base" />
        Free Estimate
        <i className="ri-arrow-right-line text-base group-hover:translate-x-1 transition-transform duration-200" />
      </button>

      {/* Leave a Review button */}
      <div className="relative">
        {showReviewTooltip && (
          <div className="absolute bottom-full right-0 mb-2 bg-charcoal-deep border border-white/10 px-4 py-3 whitespace-nowrap">
            <p className="text-white text-xs font-semibold mb-0.5">Happy with our work?</p>
            <p className="text-white/40 text-xs">Leave us a Google review!</p>
            <div className="absolute bottom-0 right-4 translate-y-full w-0 h-0 border-l-4 border-r-4 border-t-4 border-l-transparent border-r-transparent border-t-white/10" />
          </div>
        )}
        <a
          href="https://share.google/ta8gqakRmfIlctL3K"
          target="_blank"
          rel="noopener noreferrer"
          onMouseEnter={() => setShowReviewTooltip(true)}
          onMouseLeave={() => setShowReviewTooltip(false)}
          className={`w-11 h-11 flex items-center justify-center border border-white/20 hover:border-orange bg-charcoal-deep hover:bg-orange/10 text-white/40 hover:text-orange transition-all duration-300 cursor-pointer ${
            isShown ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 translate-y-4 pointer-events-none'
          }`}
          style={{ transitionDelay: isShown ? '50ms' : '0ms' }}
          aria-label="Leave a Google Review"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none">
            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
          </svg>
        </a>
      </div>

      {/* Back to Top button */}
      <button
        onClick={handleBackToTop}
        aria-label="Back to top"
        className={`w-11 h-11 flex items-center justify-center border border-white/20 hover:border-orange bg-charcoal-deep hover:bg-orange text-white/50 hover:text-white transition-all duration-300 cursor-pointer ${
          visible ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 translate-y-4 pointer-events-none'
        }`}
        style={{ transitionDelay: visible ? '200ms' : '0ms' }}
      >
        <i className="ri-arrow-up-line text-lg" />
      </button>
    </div>
  );
}
