import { useEffect, useState } from 'react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

function ElfsightWidget() {
  useEffect(() => {
    if (!document.querySelector('script[src="https://elfsightcdn.com/platform.js"]')) {
      const script = document.createElement('script');
      script.src = 'https://elfsightcdn.com/platform.js';
      script.async = true;
      document.body.appendChild(script);
    }
  }, []);

  return (
    <div className="max-w-5xl mx-auto">
      <div
        className="elfsight-app-70a6ef1c-ade3-4d9e-9610-cf20524e71cc"
        data-elfsight-app-lazy
      />
    </div>
  );
}

export default function GoogleReviewsWidget() {
  const header = useScrollAnimation();
  const widget = useScrollAnimation({ threshold: 0.15 });

  return (
    <section className="bg-charcoal-mid py-20 md:py-28 overflow-hidden">
      <div className="w-full px-6 md:px-10 lg:px-16">

        {/* Header */}
        <div
          ref={header.ref as React.RefObject<HTMLDivElement>}
          className={`text-center mb-12 anim-fade-up ${header.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">
            Live from Google
          </p>
          <h2
            className="font-display text-white uppercase tracking-wider leading-none mb-4"
            style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}
          >
            What Google Says About Us
          </h2>
          <p className="text-white/50 text-base md:text-lg max-w-2xl mx-auto">
            Real reviews from real customers — pulled straight from our Google Business profile and updated automatically.
          </p>
        </div>

        {/* Widget container */}
        <div
          ref={widget.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${widget.isVisible ? 'is-visible' : ''}`}
          style={{ transitionDelay: '150ms' }}
        >
          <ElfsightWidget />
        </div>

        {/* Trust bar + Leave a Review CTA */}
        <div className="mt-12 flex flex-col md:flex-row items-center justify-between gap-6 border-t border-white/10 pt-10">
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-6 md:gap-10">
            <div className="flex items-center gap-2 text-white/30 text-sm">
              <i className="ri-shield-check-line text-orange" />
              <span>Auto-synced from Google</span>
            </div>
            <div className="flex items-center gap-2 text-white/30 text-sm">
              <i className="ri-refresh-line text-orange" />
              <span>Updates in real time</span>
            </div>
            <div className="flex items-center gap-2 text-white/30 text-sm">
              <i className="ri-verified-badge-line text-orange" />
              <span>100% authentic reviews</span>
            </div>
          </div>
          <a
            href="https://share.google/ta8gqakRmfIlctL3K"
            target="_blank"
            rel="noopener noreferrer"
            className="flex-shrink-0 flex items-center gap-3 border border-white/20 hover:border-orange px-6 py-3.5 text-white/60 hover:text-white transition-all duration-200 group whitespace-nowrap"
          >
            <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 24 24" fill="none">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
            </svg>
            <div>
              <p className="text-xs font-semibold text-white group-hover:text-orange transition-colors uppercase tracking-wide">Leave Us a Review</p>
              <p className="text-white/30 text-xs">Takes 30 seconds &mdash; means the world to us</p>
            </div>
            <i className="ri-external-link-line text-white/20 group-hover:text-orange transition-colors" />
          </a>
        </div>

      </div>
    </section>
  );
}