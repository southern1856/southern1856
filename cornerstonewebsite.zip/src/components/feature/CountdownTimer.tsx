import { useState, useEffect } from 'react';

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

interface CountdownTimerProps {
  expiresAt: string; // ISO date string like "2026-07-31"
  variant?: 'banner' | 'inline' | 'card' | 'badge';
  onExpired?: () => void;
}

function calcTimeLeft(expiresAt: string): TimeLeft | null {
  const diff = new Date(expiresAt).getTime() - Date.now();
  if (diff <= 0) return null;

  return {
    days: Math.floor(diff / (1000 * 60 * 60 * 24)),
    hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
    minutes: Math.floor((diff / (1000 * 60)) % 60),
    seconds: Math.floor((diff / 1000) % 60),
  };
}

function pad(n: number): string {
  return n.toString().padStart(2, '0');
}

function getUrgencyLabel(days: number): { text: string; urgency: 'critical' | 'high' | 'medium' | 'low' } {
  if (days <= 0) return { text: 'Expired', urgency: 'critical' };
  if (days <= 1) return { text: 'Ends today!', urgency: 'critical' };
  if (days <= 3) return { text: `Only ${days} days left`, urgency: 'critical' };
  if (days <= 7) return { text: `Ends in ${days} days`, urgency: 'high' };
  if (days <= 14) return { text: `Only ${Math.ceil(days / 7)} week${Math.ceil(days / 7) > 1 ? 's' : ''} left`, urgency: 'high' };
  if (days <= 30) return { text: `Ends in ${days} days`, urgency: 'medium' };
  if (days <= 60) return { text: `${Math.round(days / 7)} weeks remaining`, urgency: 'low' };
  return { text: `${Math.round(days / 30)} months remaining`, urgency: 'low' };
}

const urgencyColors = {
  critical: 'bg-red-500/90 text-white border-red-400/30',
  high: 'bg-red-500/70 text-white border-red-400/20',
  medium: 'bg-amber-500/80 text-white border-amber-400/20',
  low: 'bg-amber-500/60 text-white border-amber-400/15',
};

export default function CountdownTimer({ expiresAt, variant = 'inline', onExpired }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState<TimeLeft | null>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    setTimeLeft(calcTimeLeft(expiresAt));
  }, [expiresAt]);

  useEffect(() => {
    if (!mounted) return;
    const timer = setInterval(() => {
      const remaining = calcTimeLeft(expiresAt);
      setTimeLeft(remaining);
      if (!remaining && onExpired) {
        onExpired();
        clearInterval(timer);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [expiresAt, mounted, onExpired]);

  if (!mounted || !timeLeft) {
    return (
      <div className="text-red-400 text-[10px] font-bold uppercase tracking-widest flex items-center gap-1.5">
        <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
        EXPIRED
      </div>
    );
  }

  const digitClass = "bg-black/30 text-white text-sm md:text-base font-mono font-bold w-8 md:w-10 h-8 md:h-10 flex items-center justify-center tabular-nums";
  const labelClass = "text-white/40 text-[9px] md:text-[10px] uppercase tracking-wider mt-0.5";
  const separatorClass = "text-white/30 text-sm md:text-base font-bold px-0.5";

  if (variant === 'card') {
    return (
      <div className="flex items-center gap-0.5">
        <div className="flex flex-col items-center">
          <span className={digitClass}>{pad(timeLeft.days)}</span>
          <span className={labelClass}>Days</span>
        </div>
        <span className={separatorClass}>:</span>
        <div className="flex flex-col items-center">
          <span className={digitClass}>{pad(timeLeft.hours)}</span>
          <span className={labelClass}>Hrs</span>
        </div>
        <span className={separatorClass}>:</span>
        <div className="flex flex-col items-center">
          <span className={digitClass}>{pad(timeLeft.minutes)}</span>
          <span className={labelClass}>Min</span>
        </div>
        <span className={separatorClass}>:</span>
        <div className="flex flex-col items-center">
          <span className={digitClass}>{pad(timeLeft.seconds)}</span>
          <span className={labelClass}>Sec</span>
        </div>
      </div>
    );
  }

  if (variant === 'banner') {
    return (
      <div className="flex items-center gap-3 flex-wrap">
        <span className="text-red-400 text-xs font-bold uppercase tracking-widest flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
          Ends in
        </span>
        <div className="flex items-center gap-1">
          <div className="flex flex-col items-center">
            <span className="bg-red-500/20 text-red-400 text-lg md:text-xl font-mono font-bold w-10 md:w-12 h-10 md:h-12 flex items-center justify-center tabular-nums rounded">{pad(timeLeft.days)}</span>
            <span className="text-red-400/60 text-[9px] md:text-[10px] uppercase tracking-wider mt-0.5">Days</span>
          </div>
          <span className="text-red-400/40 font-bold text-lg px-0.5">:</span>
          <div className="flex flex-col items-center">
            <span className="bg-red-500/20 text-red-400 text-lg md:text-xl font-mono font-bold w-10 md:w-12 h-10 md:h-12 flex items-center justify-center tabular-nums rounded">{pad(timeLeft.hours)}</span>
            <span className="text-red-400/60 text-[9px] md:text-[10px] uppercase tracking-wider mt-0.5">Hrs</span>
          </div>
          <span className="text-red-400/40 font-bold text-lg px-0.5">:</span>
          <div className="flex flex-col items-center">
            <span className="bg-red-500/20 text-red-400 text-lg md:text-xl font-mono font-bold w-10 md:w-12 h-10 md:h-12 flex items-center justify-center tabular-nums rounded">{pad(timeLeft.minutes)}</span>
            <span className="text-red-400/60 text-[9px] md:text-[10px] uppercase tracking-wider mt-0.5">Min</span>
          </div>
          <span className="text-red-400/40 font-bold text-lg px-0.5">:</span>
          <div className="flex flex-col items-center">
            <span className="bg-red-500/20 text-red-400 text-lg md:text-xl font-mono font-bold w-10 md:w-12 h-10 md:h-12 flex items-center justify-center tabular-nums rounded">{pad(timeLeft.seconds)}</span>
            <span className="text-red-400/60 text-[9px] md:text-[10px] uppercase tracking-wider mt-0.5">Sec</span>
          </div>
        </div>
      </div>
    );
  }

  if (variant === 'badge') {
    const { text, urgency } = getUrgencyLabel(timeLeft.days);
    const pulseAnim = urgency === 'critical' ? 'urgency-pulse' : '';
    const glowAnim = urgency === 'high' ? 'urgency-glow' : '';
    return (
      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-wider border ${urgencyColors[urgency]} ${pulseAnim} ${glowAnim}`}>
        <span className={`w-1.5 h-1.5 rounded-full ${urgency === 'critical' ? 'bg-white animate-pulse' : urgency === 'high' ? 'bg-white/80' : 'bg-white/70'}`} />
        {text}
      </span>
    );
  }

  // inline variant (default)
  return (
    <span className="inline-flex items-center gap-1.5 text-red-400 text-[10px] font-bold uppercase tracking-wider">
      <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
      {timeLeft.days > 0 && <span>{timeLeft.days}d </span>}
      <span>{pad(timeLeft.hours)}h {pad(timeLeft.minutes)}m {pad(timeLeft.seconds)}s</span>
    </span>
  );
}