import { useState } from 'react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

interface VideoTestimonial {
  id: number;
  customerName: string;
  location: string;
  projectType: string;
  headline: string;
  thumbnail: string;
  videoUrl: string;
  duration: string;
}

const VIDEO_TESTIMONIALS: VideoTestimonial[] = [
  {
    id: 1,
    customerName: 'Mark & Lisa Reynolds',
    location: 'Evansville, IN',
    projectType: 'Full Roof Replacement',
    headline: 'From disaster to dream home — our storm damage story',
    thumbnail: '/placeholders/800x450.svg',
    videoUrl: '#',
    duration: '3:42',
  },
  {
    id: 2,
    customerName: 'James Carter',
    location: 'Newburgh, IN',
    projectType: 'Storm Damage Repair',
    headline: 'Corner Stone caught what two other roofers missed',
    thumbnail: '/placeholders/800x450.svg',
    videoUrl: '#',
    duration: '2:15',
  },
  {
    id: 3,
    customerName: 'The Williamson Family',
    location: 'Henderson, KY',
    projectType: 'Roof + Siding Package',
    headline: 'Our complete exterior transformation — one crew, one week',
    thumbnail: '/placeholders/800x450.svg',
    videoUrl: '#',
    duration: '4:08',
  },
  {
    id: 4,
    customerName: 'Robert Kim',
    location: 'Boonville, IN',
    projectType: 'Commercial Roofing',
    headline: 'Our warehouse roof was done without shutting down operations',
    thumbnail: '/placeholders/800x450.svg',
    videoUrl: '#',
    duration: '3:20',
  },
  {
    id: 5,
    customerName: 'Debbie Morrison',
    location: 'Mount Vernon, IN',
    projectType: 'Gutter Installation',
    headline: 'No more basement flooding — best investment I ever made',
    thumbnail: '/placeholders/800x450.svg',
    videoUrl: '#',
    duration: '1:55',
  },
  {
    id: 6,
    customerName: 'Tony & Maria Sanchez',
    location: 'Jasper, IN',
    projectType: 'Insurance Claim Roof',
    headline: 'Our insurance wanted to deny — Corner Stone fought for us',
    thumbnail: '/placeholders/800x450.svg',
    videoUrl: '#',
    duration: '5:12',
  },
];

function VideoCard({ video, index }: { video: VideoTestimonial; index: number }) {
  const [playing, setPlaying] = useState(false);
  const anim = useScrollAnimation({ threshold: 0.1 });

  return (
    <div
      ref={anim.ref as React.RefObject<HTMLDivElement>}
      className={`anim-fade-up ${anim.isVisible ? 'is-visible' : ''} group`}
      style={{ transitionDelay: `${index * 80}ms` }}
    >
      {/* Thumbnail */}
      <div className="relative overflow-hidden border border-white/10 group-hover:border-orange/40 transition-all duration-300 cursor-pointer" onClick={() => setPlaying(true)}>
        <div className="relative" style={{ aspectRatio: '16/9' }}>
          <img src={video.thumbnail} alt={video.headline} className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105" />
          <div className="absolute inset-0 bg-black/30 group-hover:bg-black/20 transition-colors" />

          {/* Play Button */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 md:w-20 md:h-20 flex items-center justify-center bg-orange/90 group-hover:bg-orange rounded-full transition-all duration-300 group-hover:scale-110 shadow-lg">
              <i className="ri-play-fill text-white text-2xl md:text-3xl ml-1" />
            </div>
          </div>

          {/* Duration badge */}
          <div className="absolute bottom-3 right-3 bg-black/70 text-white text-xs px-2 py-1 font-mono">{video.duration}</div>
        </div>
      </div>

      {/* Info */}
      <div className="pt-4">
        <p className="text-white text-sm font-semibold leading-tight group-hover:text-orange transition-colors cursor-pointer" onClick={() => setPlaying(true)}>
          {video.headline}
        </p>
        <div className="flex items-center gap-2 mt-2">
          <p className="text-white/60 text-xs font-medium">{video.customerName}</p>
          <span className="text-white/20 text-xs">•</span>
          <p className="text-white/40 text-xs">{video.location}</p>
        </div>
        <span className="inline-block mt-1.5 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-white/5 text-white/30 border border-white/10">{video.projectType}</span>
      </div>

      {/* Video Modal */}
      {playing && (
        <div className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-4" onClick={() => setPlaying(false)}>
          <button onClick={() => setPlaying(false)} className="absolute top-4 right-4 w-10 h-10 flex items-center justify-center bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer z-10" aria-label="Close video">
            <i className="ri-close-line text-xl" />
          </button>
          <div className="relative w-full max-w-4xl" onClick={(e) => e.stopPropagation()} style={{ aspectRatio: '16/9' }}>
            <div className="w-full h-full bg-black flex items-center justify-center border border-white/10">
              <div className="text-center p-8">
                <div className="w-20 h-20 flex items-center justify-center bg-orange/20 text-orange mx-auto mb-5"><i className="ri-video-line text-3xl" /></div>
                <p className="text-white text-lg font-semibold mb-2">{video.customerName}</p>
                <p className="text-white/40 text-sm mb-6">{video.headline}</p>
                <p className="text-white/25 text-xs">Video testimonial — connect your YouTube account to display real videos here.</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function VideoTestimonialsSection() {
  const headerAnim = useScrollAnimation();
  const bodyAnim = useScrollAnimation({ threshold: 0.1 });

  return (
    <section className="bg-charcoal-deep py-20 md:py-28 overflow-hidden">
      <div className="w-full px-6 md:px-10 lg:px-16">
        {/* Header */}
        <div
          ref={headerAnim.ref as React.RefObject<HTMLDivElement>}
          className={`flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-14 anim-fade-up ${headerAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Video Stories</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              See What Our<br />Customers Have<br /><span className="text-orange">To Say</span>
            </h2>
          </div>
          <div className="flex items-center gap-6">
            <div className="hidden md:block">
              <div className="flex items-center gap-2 text-white/40 text-xs">
                <i className="ri-play-circle-line text-orange text-lg" />
                Real customers, real results
              </div>
            </div>
          </div>
        </div>

        {/* Video Grid */}
        <div
          ref={bodyAnim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${bodyAnim.isVisible ? 'is-visible' : ''}`}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {VIDEO_TESTIMONIALS.map((video, i) => (
              <VideoCard key={video.id} video={video} index={i} />
            ))}
          </div>
        </div>

        {/* Bottom note */}
        <div className={`mt-12 text-center anim-fade-up ${bodyAnim.isVisible ? 'is-visible' : ''}`} style={{ transitionDelay: '300ms' }}>
          <p className="text-white/25 text-xs">
            Every story is from a real Corner Stone customer in the Tri-State area.
            <a href="/testimonials" className="text-orange hover:text-orange-dark ml-1 transition-colors">Read all 300+ reviews →</a>
          </p>
        </div>
      </div>
    </section>
  );
}

export { VideoTestimonialsSection };