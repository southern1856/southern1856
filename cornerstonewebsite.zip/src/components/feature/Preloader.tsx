import { useEffect, useState } from 'react';

export default function Preloader() {
  const [phase, setPhase] = useState<'loading' | 'fading' | 'done'>('loading');

  useEffect(() => {
    const fadeTimer = setTimeout(() => setPhase('fading'), 900);
    const doneTimer = setTimeout(() => setPhase('done'), 1400);
    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(doneTimer);
    };
  }, []);

  if (phase === 'done') return null;

  return (
    <div
      className="fixed inset-0 z-[100] bg-charcoal-deep flex flex-col items-center justify-center transition-opacity duration-500"
      style={{ opacity: phase === 'fading' ? 0 : 1, pointerEvents: phase === 'fading' ? 'none' : 'auto' }}
    >
      {/* Logo mark */}
      <div
        className="flex flex-col items-center gap-5"
        style={{
          animation: 'preloaderLogoIn 0.6s ease 0.1s both',
        }}
      >
        <div className="relative flex items-center justify-center h-24 w-24 bg-white rounded-2xl shadow-xl">
          <img
            src="/logo.svg"
            alt="Corner Stone Construction & Roofing"
            className="h-20 w-20 object-contain rounded-lg"
          />
        </div>
        <div className="flex flex-col items-center leading-none gap-1">
          <span className="font-display text-white text-2xl md:text-3xl tracking-wider uppercase">
            Corner Stone
          </span>
          <span className="text-white/40 text-[0.65rem] tracking-[0.3em] uppercase font-medium">
            Construction & Roofing
          </span>
        </div>
      </div>

      {/* Animated progress bar */}
      <div className="mt-8 w-40 h-[3px] bg-white/10 rounded-full overflow-hidden">
        <div
          className="h-full bg-orange rounded-full origin-left"
          style={{
            animation: 'preloaderBar 0.9s ease-in-out forwards',
          }}
        />
      </div>

      <style>{`
        @keyframes preloaderLogoIn {
          from { opacity: 0; transform: translateY(16px) scale(0.92); }
          to   { opacity: 1; transform: translateY(0)     scale(1); }
        }
        @keyframes preloaderBar {
          from { transform: scaleX(0); }
          to   { transform: scaleX(1); }
        }
      `}</style>
    </div>
  );
}