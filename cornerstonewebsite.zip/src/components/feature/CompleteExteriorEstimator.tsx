import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

type HomeSize = {
  key: string;
  label: string;
  sqft: string;
  baseMin: number;
  baseMax: number;
};

type PackageTier = {
  key: string;
  name: string;
  tagline: string;
  icon: string;
  roof: string;
  siding: string;
  gutters: string;
  savingsMin: number;
  savingsMax: number;
  multiplier: number;
  desc: string;
};

const homeSizes: HomeSize[] = [
  { key: 'small', label: 'Small Home', sqft: '1,000 – 1,400 sq ft', baseMin: 14500, baseMax: 24000 },
  { key: 'medium', label: 'Medium Home', sqft: '1,500 – 2,200 sq ft', baseMin: 22000, baseMax: 36000 },
  { key: 'large', label: 'Large Home', sqft: '2,300 – 3,200 sq ft', baseMin: 32000, baseMax: 52000 },
  { key: 'xlarge', label: 'Extra Large', sqft: '3,300+ sq ft', baseMin: 45000, baseMax: 78000 },
];

const packageTiers: PackageTier[] = [
  {
    key: 'essential',
    name: 'Essential',
    tagline: 'Roof + Gutters',
    icon: 'ri-home-4-line',
    roof: 'Architectural Shingles',
    siding: 'Siding Not Included',
    gutters: 'Seamless Aluminum',
    savingsMin: 400,
    savingsMax: 700,
    multiplier: 0.55,
    desc: 'New roof and gutters only — perfect if your siding is still in good shape',
  },
  {
    key: 'complete',
    name: 'Complete',
    tagline: 'Roof + Siding + Gutters',
    icon: 'ri-layout-masonry-line',
    roof: 'Architectural Shingles',
    siding: 'Premium Vinyl Siding',
    gutters: 'Seamless Aluminum',
    savingsMin: 800,
    savingsMax: 2000,
    multiplier: 1.0,
    desc: 'The full exterior overhaul — most popular choice for a total refresh',
  },
  {
    key: 'premium',
    name: 'Premium',
    tagline: 'Metal + Hardie + Copper',
    icon: 'ri-vip-crown-line',
    roof: 'Standing Seam Metal',
    siding: 'James Hardie Fiber Cement',
    gutters: 'Copper Gutter System',
    savingsMin: 2000,
    savingsMax: 4000,
    multiplier: 2.1,
    desc: 'The ultimate exterior — lifetime materials that add serious value',
  },
];

function formatCurrency(n: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);
}

export default function CompleteExteriorEstimator() {
  const navigate = useNavigate();
  const sectionAnim = useScrollAnimation({ threshold: 0.06 });
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [selectedSize, setSelectedSize] = useState<HomeSize | null>(null);
  const [selectedPackage, setSelectedPackage] = useState<PackageTier | null>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  const handleSizeSelect = (size: HomeSize) => {
    setSelectedSize(size);
    setStep(2);
  };

  const handlePackageSelect = (pkg: PackageTier) => {
    setSelectedPackage(pkg);
    setStep(3);
    setTimeout(() => {
      resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);
  };

  const handleReset = () => {
    setStep(1);
    setSelectedSize(null);
    setSelectedPackage(null);
  };

  const minPrice = selectedSize && selectedPackage
    ? Math.round(selectedSize.baseMin * selectedPackage.multiplier)
    : 0;
  const maxPrice = selectedSize && selectedPackage
    ? Math.round(selectedSize.baseMax * selectedPackage.multiplier)
    : 0;
  const avgPrice = Math.round((minPrice + maxPrice) / 2);

  const separateMin = selectedSize && selectedPackage
    ? minPrice + selectedPackage.savingsMin
    : 0;
  const separateMax = selectedSize && selectedPackage
    ? maxPrice + selectedPackage.savingsMax
    : 0;

  return (
    <section id="exterior-estimator" className="bg-warm-beige py-20 md:py-28 px-6 md:px-10 lg:px-16">
      <div
        ref={sectionAnim.ref as React.RefObject<HTMLDivElement>}
        className={`anim-fade-up ${sectionAnim.isVisible ? 'is-visible' : ''}`}
      >
        {/* Header */}
        <div className="text-center mb-12 md:mb-16">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Quick & Free</p>
          <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Complete Exterior<br /><span className="text-orange">Cost Estimator</span>
          </h2>
          <p className="text-charcoal-mid/50 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            See how much a bundled roof + siding + gutters project costs in under 30 seconds. Includes your bundle savings.
          </p>
        </div>

        {/* Main estimator card */}
        <div className="max-w-4xl mx-auto bg-white border border-charcoal/5 overflow-hidden">
          {/* Progress bar */}
          <div className="flex items-center bg-charcoal-deep px-6 md:px-10 py-5">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center flex-1">
                <div className={`w-8 h-8 flex items-center justify-center text-xs font-bold uppercase tracking-wider transition-colors ${s <= step ? 'bg-orange text-white' : 'bg-white/10 text-white/30'}`}>
                  {s}
                </div>
                <span className={`ml-3 text-xs font-semibold uppercase tracking-wider hidden sm:block transition-colors ${s <= step ? 'text-white' : 'text-white/30'}`}>
                  {s === 1 ? 'Home Size' : s === 2 ? 'Package' : 'Your Estimate'}
                </span>
                {s < 3 && (
                  <div className="flex-1 h-px mx-3 md:mx-4 bg-white/10">
                    <div className={`h-full bg-orange transition-all duration-500 ${s < step ? 'w-full' : 'w-0'}`} />
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Step 1: Home Size */}
          {step === 1 && (
            <div className="p-6 md:p-10">
              <h3 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider mb-2">Select Your Home Size</h3>
              <p className="text-charcoal-mid/40 text-sm mb-8">Pick the option closest to your home&apos;s footprint.</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {homeSizes.map((size) => (
                  <button
                    key={size.key}
                    onClick={() => handleSizeSelect(size)}
                    className="group text-left p-5 md:p-6 border border-charcoal/10 hover:border-orange hover:bg-orange/5 transition-all duration-200 cursor-pointer"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className="font-display text-charcoal-deep text-lg uppercase tracking-wide">{size.label}</span>
                      <div className="w-8 h-8 flex items-center justify-center border border-charcoal/10 group-hover:border-orange group-hover:bg-orange group-hover:text-white transition-all">
                        <i className="ri-arrow-right-line text-sm" />
                      </div>
                    </div>
                    <p className="text-charcoal-mid/50 text-sm">{size.sqft}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Package Tier */}
          {step === 2 && (
            <div className="p-6 md:p-10">
              <div className="flex items-center gap-3 mb-2">
                <button
                  onClick={() => { setStep(1); setSelectedSize(null); }}
                  className="text-charcoal-mid/40 hover:text-orange text-xs uppercase tracking-wider flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <i className="ri-arrow-left-line" /> Back
                </button>
              </div>
              <h3 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider mb-2">Choose Your Package</h3>
              <p className="text-charcoal-mid/40 text-sm mb-8">{selectedSize?.label} selected. Pick the bundle that fits your needs.</p>
              <div className="grid grid-cols-1 gap-4">
                {packageTiers.map((pkg) => (
                  <button
                    key={pkg.key}
                    onClick={() => handlePackageSelect(pkg)}
                    className="group text-left p-5 md:p-6 border border-charcoal/10 hover:border-orange hover:bg-orange/5 transition-all duration-200 cursor-pointer"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start gap-4">
                      <div className="flex items-center gap-3 sm:w-48 flex-shrink-0">
                        <div className="w-12 h-12 flex items-center justify-center bg-charcoal-deep text-white group-hover:bg-orange transition-colors flex-shrink-0">
                          <i className={`${pkg.icon} text-xl`} />
                        </div>
                        <div>
                          <span className="font-display text-charcoal-deep text-lg uppercase tracking-wide block">{pkg.name}</span>
                          <span className="text-orange text-xs font-semibold uppercase tracking-wider">{pkg.tagline}</span>
                        </div>
                      </div>
                      <div className="flex-1">
                        <div className="flex flex-wrap gap-2 mb-2">
                          <span className="inline-flex items-center gap-1 bg-charcoal-deep/5 text-charcoal-deep text-xs font-semibold px-2.5 py-1 uppercase tracking-wider">
                            <i className="ri-home-4-line text-xs" />
                            {pkg.roof}
                          </span>
                          {pkg.siding !== 'Siding Not Included' && (
                            <span className="inline-flex items-center gap-1 bg-charcoal-deep/5 text-charcoal-deep text-xs font-semibold px-2.5 py-1 uppercase tracking-wider">
                              <i className="ri-layout-masonry-line text-xs" />
                              {pkg.siding}
                            </span>
                          )}
                          <span className="inline-flex items-center gap-1 bg-charcoal-deep/5 text-charcoal-deep text-xs font-semibold px-2.5 py-1 uppercase tracking-wider">
                            <i className="ri-water-flash-line text-xs" />
                            {pkg.gutters}
                          </span>
                        </div>
                        <p className="text-charcoal-mid/50 text-sm">{pkg.desc}</p>
                      </div>
                      <div className="w-8 h-8 flex items-center justify-center border border-charcoal/10 group-hover:border-orange group-hover:bg-orange group-hover:text-white transition-all flex-shrink-0 self-center">
                        <i className="ri-arrow-right-line text-sm" />
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 3: Result */}
          {step === 3 && selectedSize && selectedPackage && (
            <div className="p-6 md:p-10" ref={resultRef}>
              <div className="flex items-center gap-3 mb-6">
                <button
                  onClick={handleReset}
                  className="text-charcoal-mid/40 hover:text-orange text-xs uppercase tracking-wider flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <i className="ri-restart-line" /> Start Over
                </button>
              </div>

              {/* Selected summary */}
              <div className="flex flex-wrap gap-2 mb-6">
                <span className="inline-flex items-center gap-1.5 bg-charcoal-deep text-white text-xs font-semibold px-3 py-1.5 uppercase tracking-wider">
                  <i className="ri-home-4-line text-xs" />
                  {selectedSize.label}
                </span>
                <span className="inline-flex items-center gap-1.5 bg-orange text-white text-xs font-semibold px-3 py-1.5 uppercase tracking-wider">
                  <i className={`${selectedPackage.icon} text-xs`} />
                  {selectedPackage.name} Package
                </span>
              </div>

              {/* What's included */}
              <div className="bg-charcoal-deep/5 border border-charcoal/5 p-5 mb-6">
                <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-3">What&apos;s Included</p>
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 flex items-center justify-center bg-charcoal-deep text-orange flex-shrink-0">
                      <i className="ri-home-4-line text-xs" />
                    </div>
                    <span className="text-charcoal-mid text-sm">{selectedPackage.roof} — full tear-off &amp; replacement</span>
                  </div>
                  {selectedPackage.siding !== 'Siding Not Included' && (
                    <div className="flex items-center gap-3">
                      <div className="w-6 h-6 flex items-center justify-center bg-charcoal-deep text-orange flex-shrink-0">
                        <i className="ri-layout-masonry-line text-xs" />
                      </div>
                      <span className="text-charcoal-mid text-sm">{selectedPackage.siding} — complete siding replacement</span>
                    </div>
                  )}
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 flex items-center justify-center bg-charcoal-deep text-orange flex-shrink-0">
                      <i className="ri-water-flash-line text-xs" />
                    </div>
                    <span className="text-charcoal-mid text-sm">{selectedPackage.gutters} — full gutter &amp; downspout system</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 flex items-center justify-center bg-charcoal-deep text-orange flex-shrink-0">
                      <i className="ri-tools-line text-xs" />
                    </div>
                    <span className="text-charcoal-mid text-sm">Lifetime workmanship warranty on all labor</span>
                  </div>
                </div>
              </div>

              {/* Price display */}
              <div className="bg-charcoal-deep p-8 md:p-10 text-center mb-6">
                <p className="text-white/30 text-xs font-semibold uppercase tracking-[0.25em] mb-4">Estimated Ballpark Range</p>
                <div className="flex items-baseline justify-center gap-3 mb-2">
                  <span className="font-display text-orange text-4xl md:text-5xl lg:text-6xl uppercase tracking-wider">{formatCurrency(minPrice)}</span>
                  <span className="text-white/20 text-lg md:text-xl font-display uppercase">–</span>
                  <span className="font-display text-orange text-4xl md:text-5xl lg:text-6xl uppercase tracking-wider">{formatCurrency(maxPrice)}</span>
                </div>
                <p className="text-white/30 text-sm mt-2">
                  Average for your selection: <span className="text-white font-semibold">{formatCurrency(avgPrice)}</span>
                </p>
              </div>

              {/* Savings banner */}
              <div className="bg-orange/10 border border-orange/20 p-5 md:p-6 mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 flex items-center justify-center bg-orange text-white flex-shrink-0">
                    <i className="ri-money-dollar-circle-line text-lg" />
                  </div>
                  <div>
                    <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider">You Save vs. Separate Contractors</p>
                    <p className="text-charcoal-mid/50 text-xs">One crew, one visit, one cleanup</p>
                  </div>
                </div>
                <span className="font-display text-orange text-2xl md:text-3xl uppercase tracking-wider">
                  {formatCurrency(selectedPackage.savingsMin)}–{formatCurrency(selectedPackage.savingsMax)}
                </span>
              </div>

              {/* Fine print */}
              <div className="bg-warm-beige border border-charcoal/5 p-5 md:p-6 mb-8">
                <p className="text-charcoal-mid/40 text-xs leading-relaxed">
                  <strong className="text-charcoal-mid">This is a ballpark estimate only.</strong> Final pricing depends on roof pitch, number of stories, substrate condition, trim complexity, scaffolding needs, permit fees, and site accessibility. For an accurate, itemized written estimate, schedule a free full exterior inspection — no obligation, no pressure.
                </p>
              </div>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <button
                  onClick={() => navigate('/estimate')}
                  className="flex-1 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                >
                  Get a Real Estimate
                  <i className="ri-arrow-right-line" />
                </button>
                <a
                  href="tel:8122135997"
                  className="flex-1 border border-charcoal/20 hover:border-charcoal-deep text-charcoal-deep font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2"
                >
                  <i className="ri-phone-line text-orange" />
                  Call 812-213-5997
                </a>
              </div>

              {/* Why the range varies */}
              <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { icon: 'ri-ruler-line', title: 'Roof Pitch', desc: 'Steeper roofs require more safety equipment and labor time.' },
                  { icon: 'ri-building-line', title: 'Stories', desc: 'Two-story and three-story homes increase scaffolding costs.' },
                  { icon: 'ri-hammer-line', title: 'Substrate', desc: 'Rotted decking or sheathing adds material + labor.' },
                  { icon: 'ri-scissors-cut-line', title: 'Trim & Details', desc: 'Lots of corners, windows, and decorative elements increase cuts.' },
                ].map((item) => (
                  <div key={item.title} className="flex items-start gap-3">
                    <div className="w-8 h-8 flex items-center justify-center bg-charcoal-deep text-orange flex-shrink-0">
                      <i className={`${item.icon} text-sm`} />
                    </div>
                    <div>
                      <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-0.5">{item.title}</p>
                      <p className="text-charcoal-mid/40 text-xs leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Bottom trust line */}
        <div className="max-w-4xl mx-auto mt-8 flex flex-wrap items-center justify-center gap-6 md:gap-10">
          <div className="flex items-center gap-2 text-charcoal-mid/40 text-xs">
            <i className="ri-shield-check-line text-orange" />
            <span>Based on Evansville-area pricing</span>
          </div>
          <div className="flex items-center gap-2 text-charcoal-mid/40 text-xs">
            <i className="ri-time-line text-orange" />
            <span>Updated April 2026</span>
          </div>
          <div className="flex items-center gap-2 text-charcoal-mid/40 text-xs">
            <i className="ri-lock-line text-orange" />
            <span>No email or phone required</span>
          </div>
        </div>
      </div>
    </section>
  );
}