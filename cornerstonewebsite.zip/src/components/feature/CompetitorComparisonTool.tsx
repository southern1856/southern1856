import { useState, useRef } from 'react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

interface CompetitorQuote {
  roof: number;
  siding: number;
  gutters: number;
  roofHidden: number;
  sidingHidden: number;
  guttersHidden: number;
}

const DEFAULT_COMPETITOR: CompetitorQuote = {
  roof: 14500,
  siding: 11000,
  gutters: 1800,
  roofHidden: 800,
  sidingHidden: 600,
  guttersHidden: 200,
};

const CORNER_STONE_PACKAGES = [
  { label: 'Essential (Roof + Gutters)', base: 12000, range: [12000, 17000] },
  { label: 'Complete (Roof + Siding + Gutters)', base: 22000, range: [22000, 32000] },
  { label: 'Premium (Metal + Hardie + Copper)', base: 45000, range: [45000, 65000] },
];

function formatCurrency(n: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);
}

export default function CompetitorComparisonTool() {
  const sectionAnim = useScrollAnimation({ threshold: 0.06 });
  const resultRef = useRef<HTMLDivElement>(null);

  const [quotes, setQuotes] = useState<CompetitorQuote>({ ...DEFAULT_COMPETITOR });
  const [showResults, setShowResults] = useState(false);
  const [activePackage, setActivePackage] = useState(1); // Complete package default

  const updateQuote = (field: keyof CompetitorQuote, value: string) => {
    const num = value === '' ? 0 : Number(value);
    setQuotes((prev) => ({ ...prev, [field]: Math.max(0, num) }));
    setShowResults(false);
  };

  const handleQuickFill = (preset: 'low' | 'mid' | 'high') => {
    const presets = {
      low: { roof: 12500, siding: 9500, gutters: 1500, roofHidden: 500, sidingHidden: 400, guttersHidden: 150 },
      mid: { roof: 14500, siding: 11000, gutters: 1800, roofHidden: 800, sidingHidden: 600, guttersHidden: 200 },
      high: { roof: 18000, siding: 13500, gutters: 2500, roofHidden: 1200, sidingHidden: 900, guttersHidden: 350 },
    };
    setQuotes(presets[preset]);
    setShowResults(false);
  };

  const competitorTotal = quotes.roof + quotes.siding + quotes.gutters + quotes.roofHidden + quotes.sidingHidden + quotes.guttersHidden;
  const competitorVisible = quotes.roof + quotes.siding + quotes.gutters;
  const competitorHidden = quotes.roofHidden + quotes.sidingHidden + quotes.guttersHidden;
  const ourRange = CORNER_STONE_PACKAGES[activePackage].range;
  const ourMid = Math.round((ourRange[0] + ourRange[1]) / 2);
  const savingsLow = competitorTotal - ourRange[1];
  const savingsHigh = competitorTotal - ourRange[0];
  const savingsMid = competitorTotal - ourMid;

  const handleCompare = () => {
    setShowResults(true);
    setTimeout(() => {
      resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const hiddenPercent = competitorVisible > 0 ? Math.round((competitorHidden / competitorVisible) * 100) : 0;

  return (
    <section id="compare-quotes" className="bg-charcoal-deep py-20 md:py-28 px-6 md:px-10 lg:px-16">
      <div
        ref={sectionAnim.ref as React.RefObject<HTMLDivElement>}
        className={`anim-fade-up ${sectionAnim.isVisible ? 'is-visible' : ''}`}
      >
        {/* Header */}
        <div className="text-center mb-12 md:mb-16">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">See the Real Numbers</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Compare Quotes.<br /><span className="text-orange">See the Difference.</span>
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Enter what other contractors quoted you for roof, siding, and gutters. We'll show you exactly how much Corner Stone saves you — and what hidden costs you're already paying.
          </p>
        </div>

        {/* Main card */}
        <div className="max-w-5xl mx-auto bg-charcoal-mid border border-white/10 overflow-hidden">
          {/* Quick fill presets */}
          <div className="bg-charcoal-deep border-b border-white/10 px-6 md:px-10 py-5">
            <p className="text-white/30 text-xs font-semibold uppercase tracking-wider mb-3">Quick Fill — Typical Evansville Quotes</p>
            <div className="flex flex-wrap gap-2">
              {[
                { key: 'low' as const, label: 'Low-Ball Quotes', desc: 'Budget contractors' },
                { key: 'mid' as const, label: 'Typical Quotes', desc: 'Mid-tier contractors' },
                { key: 'high' as const, label: 'High Quotes', desc: 'Premium contractors' },
              ].map((preset) => (
                <button
                  key={preset.key}
                  onClick={() => handleQuickFill(preset.key)}
                  className="text-left p-3 border border-white/10 hover:border-orange hover:bg-orange/5 transition-all cursor-pointer min-w-[160px]"
                >
                  <p className="text-white/60 text-sm font-semibold uppercase tracking-wider">{preset.label}</p>
                  <p className="text-white/25 text-xs mt-0.5">{preset.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Input grid */}
          <div className="p-6 md:p-10">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {/* Roof */}
              <div className="border border-white/10 bg-charcoal-deep/30 p-5">
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-orange/15 flex-shrink-0">
                    <i className="ri-home-4-line text-orange text-sm" />
                  </div>
                  <p className="text-white text-sm font-semibold uppercase tracking-wider">Roof Replacement</p>
                </div>
                <div className="space-y-3">
                  <div>
                    <label className="text-white/30 text-xs uppercase tracking-wider block mb-1">Quoted Price</label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/20 text-sm">$</span>
                      <input
                        type="number"
                        min={0}
                        step={100}
                        value={quotes.roof || ''}
                        onChange={(e) => updateQuote('roof', e.target.value)}
                        className="w-full bg-charcoal-deep border border-white/10 text-white text-sm font-semibold px-3 py-2.5 pl-7 focus:outline-none focus:border-orange transition-colors"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-white/20 text-xs uppercase tracking-wider block mb-1">
                      Hidden Fees <span className="normal-case text-white/10">(permits, disposal, etc.)</span>
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/20 text-sm">$</span>
                      <input
                        type="number"
                        min={0}
                        step={50}
                        value={quotes.roofHidden || ''}
                        onChange={(e) => updateQuote('roofHidden', e.target.value)}
                        className="w-full bg-charcoal-deep border border-white/10 text-white/60 text-sm font-semibold px-3 py-2.5 pl-7 focus:outline-none focus:border-orange/50 transition-colors"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Siding */}
              <div className="border border-white/10 bg-charcoal-deep/30 p-5">
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-orange/15 flex-shrink-0">
                    <i className="ri-layout-masonry-line text-orange text-sm" />
                  </div>
                  <p className="text-white text-sm font-semibold uppercase tracking-wider">Siding Replacement</p>
                </div>
                <div className="space-y-3">
                  <div>
                    <label className="text-white/30 text-xs uppercase tracking-wider block mb-1">Quoted Price</label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/20 text-sm">$</span>
                      <input
                        type="number"
                        min={0}
                        step={100}
                        value={quotes.siding || ''}
                        onChange={(e) => updateQuote('siding', e.target.value)}
                        className="w-full bg-charcoal-deep border border-white/10 text-white text-sm font-semibold px-3 py-2.5 pl-7 focus:outline-none focus:border-orange transition-colors"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-white/20 text-xs uppercase tracking-wider block mb-1">
                      Hidden Fees <span className="normal-case text-white/10">(trim, fascia, etc.)</span>
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/20 text-sm">$</span>
                      <input
                        type="number"
                        min={0}
                        step={50}
                        value={quotes.sidingHidden || ''}
                        onChange={(e) => updateQuote('sidingHidden', e.target.value)}
                        className="w-full bg-charcoal-deep border border-white/10 text-white/60 text-sm font-semibold px-3 py-2.5 pl-7 focus:outline-none focus:border-orange/50 transition-colors"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Gutters */}
              <div className="border border-white/10 bg-charcoal-deep/30 p-5">
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-orange/15 flex-shrink-0">
                    <i className="ri-water-flash-line text-orange text-sm" />
                  </div>
                  <p className="text-white text-sm font-semibold uppercase tracking-wider">Gutter System</p>
                </div>
                <div className="space-y-3">
                  <div>
                    <label className="text-white/30 text-xs uppercase tracking-wider block mb-1">Quoted Price</label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/20 text-sm">$</span>
                      <input
                        type="number"
                        min={0}
                        step={100}
                        value={quotes.gutters || ''}
                        onChange={(e) => updateQuote('gutters', e.target.value)}
                        className="w-full bg-charcoal-deep border border-white/10 text-white text-sm font-semibold px-3 py-2.5 pl-7 focus:outline-none focus:border-orange transition-colors"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-white/20 text-xs uppercase tracking-wider block mb-1">
                      Hidden Fees <span className="normal-case text-white/10">(downspouts, guards, etc.)</span>
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/20 text-sm">$</span>
                      <input
                        type="number"
                        min={0}
                        step={50}
                        value={quotes.guttersHidden || ''}
                        onChange={(e) => updateQuote('guttersHidden', e.target.value)}
                        className="w-full bg-charcoal-deep border border-white/10 text-white/60 text-sm font-semibold px-3 py-2.5 pl-7 focus:outline-none focus:border-orange/50 transition-colors"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Select our package to compare against */}
            <div className="mb-8">
              <label className="text-white text-xs font-semibold uppercase tracking-wider mb-3 block">
                Compare Against Which Corner Stone Package?
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {CORNER_STONE_PACKAGES.map((pkg, i) => (
                  <button
                    key={i}
                    onClick={() => { setActivePackage(i); setShowResults(false); }}
                    className={`p-4 border text-left transition-all cursor-pointer ${
                      activePackage === i
                        ? 'bg-orange/10 border-orange'
                        : 'border-white/10 hover:border-white/25'
                    }`}
                  >
                    <p className={`text-sm font-semibold uppercase tracking-wider mb-1 ${activePackage === i ? 'text-orange' : 'text-white/60'}`}>
                      {pkg.label}
                    </p>
                    <p className="text-white/25 text-xs">
                      From {formatCurrency(pkg.range[0])} – {formatCurrency(pkg.range[1])}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Compare button */}
            <button
              onClick={handleCompare}
              className="w-full bg-orange hover:bg-orange-dark text-white font-bold text-sm uppercase tracking-widest py-4 transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
            >
              <i className="ri-scales-3-line" />
              Compare My Quotes
            </button>
          </div>

          {/* Results */}
          {showResults && (
            <div className="border-t border-white/10" ref={resultRef}>
              {/* Competitor total */}
              <div className="bg-charcoal-deep p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                  <p className="text-white/30 text-xs font-semibold uppercase tracking-[0.25em] mb-1">Your Competitor Total</p>
                  <p className="text-white/50 text-sm">Quoted: {formatCurrency(competitorVisible)} + Hidden: {formatCurrency(competitorHidden)}</p>
                </div>
                <span className="font-display text-white text-4xl md:text-5xl uppercase tracking-wider">{formatCurrency(competitorTotal)}</span>
              </div>

              {/* Hidden fees alert */}
              {competitorHidden > 0 && (
                <div className="bg-orange/5 border-y border-orange/10 px-6 md:px-10 py-4 flex flex-col sm:flex-row items-start sm:items-center gap-3">
                  <div className="w-8 h-8 flex items-center justify-center bg-orange/15 flex-shrink-0">
                    <i className="ri-alert-line text-orange text-sm" />
                  </div>
                  <div>
                    <p className="text-orange text-sm font-semibold uppercase tracking-wider">
                      {hiddenPercent}% in Hidden Fees
                    </p>
                    <p className="text-white/40 text-xs mt-0.5">
                      Competitors often tack on {formatCurrency(competitorHidden)} in permits, disposal, trim, and extra charges after the quote — we include everything upfront.
                    </p>
                  </div>
                </div>
              )}

              {/* Side by side comparison */}
              <div className="p-6 md:p-10">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  {/* Competitor column */}
                  <div className="border border-white/10 bg-charcoal-deep/30 p-6">
                    <div className="flex items-center gap-2 mb-5">
                      <div className="w-8 h-8 flex items-center justify-center bg-white/10 flex-shrink-0">
                        <i className="ri-building-2-line text-white/40 text-sm" />
                      </div>
                      <p className="text-white/40 text-sm font-semibold uppercase tracking-wider">3 Separate Contractors</p>
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-white/40 text-sm">Roof Contractor</span>
                        <span className="text-white text-sm font-semibold">{formatCurrency(quotes.roof + quotes.roofHidden)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white/40 text-sm">Siding Contractor</span>
                        <span className="text-white text-sm font-semibold">{formatCurrency(quotes.siding + quotes.sidingHidden)}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white/40 text-sm">Gutter Contractor</span>
                        <span className="text-white text-sm font-semibold">{formatCurrency(quotes.gutters + quotes.guttersHidden)}</span>
                      </div>
                      <div className="h-px bg-white/10 my-3" />
                      <div className="flex justify-between items-center">
                        <span className="text-white/40 text-xs uppercase tracking-wider">Separate Mobilizations</span>
                        <span className="text-white/30 text-sm">×3 visits, ×3 cleanups</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white/40 text-xs uppercase tracking-wider">Warranty</span>
                        <span className="text-white/30 text-sm">3 different companies</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white/40 text-xs uppercase tracking-wider">Scheduling</span>
                        <span className="text-white/30 text-sm">3–6 weeks total</span>
                      </div>
                      <div className="h-px bg-white/10 my-3" />
                      <div className="flex justify-between items-center">
                        <span className="text-white text-sm font-bold uppercase tracking-wider">Total Cost</span>
                        <span className="font-display text-white text-2xl uppercase tracking-wider">{formatCurrency(competitorTotal)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Corner Stone column */}
                  <div className="border-2 border-orange bg-orange/5 p-6">
                    <div className="flex items-center gap-2 mb-5">
                      <div className="w-8 h-8 flex items-center justify-center bg-orange flex-shrink-0">
                        <i className="ri-shield-check-line text-white text-sm" />
                      </div>
                      <p className="text-orange text-sm font-semibold uppercase tracking-wider">Corner Stone — Bundled</p>
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-white/50 text-sm">{CORNER_STONE_PACKAGES[activePackage].label}</span>
                        <span className="text-white text-sm font-semibold">{formatCurrency(ourMid)} <span className="text-white/30 text-xs">(avg)</span></span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white/40 text-xs uppercase tracking-wider">One Mobilization</span>
                        <span className="text-white/50 text-sm">One crew, one visit</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white/40 text-xs uppercase tracking-wider">Warranty</span>
                        <span className="text-orange text-sm font-semibold">Lifetime — one company</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white/40 text-xs uppercase tracking-wider">Scheduling</span>
                        <span className="text-white/50 text-sm">3–7 days total</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white/40 text-xs uppercase tracking-wider">Hidden Fees</span>
                        <span className="text-orange text-sm font-semibold">Zero — all included</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-white/40 text-xs uppercase tracking-wider">Insurance Claims</span>
                        <span className="text-white/50 text-sm">One claim, handled for you</span>
                      </div>
                      <div className="h-px bg-orange/20 my-3" />
                      <div className="flex justify-between items-center">
                        <span className="text-orange text-sm font-bold uppercase tracking-wider">Your Range</span>
                        <span className="font-display text-orange text-2xl uppercase tracking-wider">
                          {formatCurrency(ourRange[0])}–{formatCurrency(ourRange[1])}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Big savings banner */}
                <div className="bg-orange/10 border-2 border-orange p-6 md:p-8 mb-8 text-center">
                  <p className="text-orange/60 text-xs font-semibold uppercase tracking-[0.25em] mb-3">You Save With Corner Stone</p>
                  <div className="flex items-baseline justify-center gap-2 mb-2">
                    <span className="font-display text-orange text-5xl md:text-6xl uppercase tracking-wider">
                      {formatCurrency(Math.min(savingsLow, savingsHigh))}
                    </span>
                    <span className="text-orange/40 text-xl font-display uppercase">–</span>
                    <span className="font-display text-orange text-5xl md:text-6xl uppercase tracking-wider">
                      {formatCurrency(Math.max(savingsLow, savingsHigh))}
                    </span>
                  </div>
                  <p className="text-white/40 text-sm">
                    That's a {Math.round((savingsMid / competitorTotal) * 100)}% savings on average vs. hiring 3 separate contractors
                  </p>
                </div>

                {/* Breakdown of where savings come from */}
                <div className="mb-8">
                  <p className="text-white text-xs font-semibold uppercase tracking-wider mb-4">Where Your Savings Come From</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {[
                      {
                        icon: 'ri-truck-line',
                        label: 'One Mobilization',
                        value: formatCurrency(1200),
                        desc: 'Avoid 3 separate setup/cleanup fees',
                      },
                      {
                        icon: 'ri-price-tag-3-line',
                        label: 'Bundled Materials',
                        value: formatCurrency(600),
                        desc: 'Bulk ordering discount on shingles + siding',
                      },
                      {
                        icon: 'ri-file-list-3-line',
                        label: 'No Hidden Fees',
                        value: formatCurrency(competitorHidden),
                        desc: 'Everything included in your quote upfront',
                      },
                      {
                        icon: 'ri-calendar-event-line',
                        label: 'Time Saved',
                        value: '2–4 Weeks',
                        desc: 'One project window vs. three separate schedules',
                      },
                    ].map((item) => (
                      <div key={item.label} className="border border-white/10 bg-charcoal-deep/20 p-5">
                        <div className="w-10 h-10 flex items-center justify-center bg-orange/15 mb-3">
                          <i className={`${item.icon} text-orange text-lg`} />
                        </div>
                        <p className="text-white text-sm font-semibold uppercase tracking-wider mb-1">{item.label}</p>
                        <p className="text-orange font-display text-lg uppercase tracking-wider mb-1">{item.value}</p>
                        <p className="text-white/30 text-xs leading-relaxed">{item.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* The "what you're really paying for" section */}
                <div className="bg-charcoal-deep/50 border border-white/5 p-5 md:p-6 mb-8">
                  <p className="text-white/40 text-xs leading-relaxed">
                    <strong className="text-white/60">What you're really paying for with 3 contractors:</strong> Each contractor charges a separate mobilization fee ($300–$500), separate permit fees, separate dumpster rentals, and separate cleanup. Add the headache of coordinating 3 schedules, 3 inspections, and 3 warranty claims — and the real cost is far more than just the line items on their quotes. With Corner Stone, one crew handles everything in sequence, one permit covers all trades, and one warranty covers your entire exterior.
                  </p>
                </div>

                {/* CTAs */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                  <button
                    onClick={() => document.getElementById('package-form')?.scrollIntoView({ behavior: 'smooth' })}
                    className="flex-1 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                  >
                    <i className="ri-file-list-3-line" />
                    Get a Bundled Quote
                  </button>
                  <a
                    href="tel:8122135997"
                    className="flex-1 border border-white/20 hover:border-orange text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2"
                  >
                    <i className="ri-phone-line text-orange" />
                    Call 812-213-5997
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom trust line */}
        <div className="max-w-5xl mx-auto mt-8 flex flex-wrap items-center justify-center gap-6 md:gap-10">
          <div className="flex items-center gap-2 text-white/30 text-xs">
            <i className="ri-shield-check-line text-orange" />
            <span>All-in pricing — no surprises</span>
          </div>
          <div className="flex items-center gap-2 text-white/30 text-xs">
            <i className="ri-file-list-3-line text-orange" />
            <span>Itemized quotes in writing</span>
          </div>
          <div className="flex items-center gap-2 text-white/30 text-xs">
            <i className="ri-money-dollar-circle-line text-orange" />
            <span>Price match on comparable scope</span>
          </div>
        </div>
      </div>
    </section>
  );
}