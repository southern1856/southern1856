import type { PortfolioProject } from '@/mocks/portfolioProjects';
import SocialShareCard from './SocialShareCard';

interface BrandedShareCardProps {
  project: PortfolioProject | null;
  onClose: () => void;
}

export default function BrandedShareCard({ project, onClose }: BrandedShareCardProps) {
  if (!project) return null;

  const shareText = `Check out this ${project.type.toLowerCase()} roofing project by Corner Stone Construction & Roofing in ${project.location}.\n\n${project.title} — ${project.subtitle}\n${project.material}\n\n${project.duration} | ${project.squareFootage}\n\nBook your free inspection at cornerstoneconstruction.com or call 812-213-5997.`;

  return (
    <SocialShareCard
      title={project.title}
      subtitle={project.subtitle}
      type={project.type}
      location={project.location}
      year={project.year}
      image={project.afterImage}
      badge={project.badge}
      stats={[
        { label: 'Duration', value: project.duration, icon: 'ri-time-line' },
        { label: 'Scope', value: project.squareFootage, icon: 'ri-ruler-line' },
        { label: 'Material', value: project.material.split(' ')[0], icon: 'ri-stack-line' },
      ]}
      highlights={project.highlights.slice(0, 4)}
      description={project.description}
      shareText={shareText}
      onClose={onClose}
    />
  );
}