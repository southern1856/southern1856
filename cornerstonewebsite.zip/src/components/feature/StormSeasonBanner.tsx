import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function StormSeasonBanner() {
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const wasDismissed = sessionStorage.getItem('storm-banner-dismissed');
    if (wasDismissed) return;

    const timer = setTimeout(() => {
      setVisible(true);
    }, 15000);

    return () => clearTimeout(timer);
  }, []);

  const handleDismiss = () => {
    setDismissed(true);
    sessionStorage.setItem('storm-banner-dismissed', '1');
    setTimeout(() => setVisible(false), 400);
  };

  const handleCTA = () => {
    handleDismiss();
    navigate('/insurance-claims');
  };

  if (!visible) return null;

  return (
    <>
      {/* Backdrop - fixed non-scrollable */}
      <div
        className={`fixed inset-0 bg-black/70 z-[60] transition-opacity duration-400 ${dismissed ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}
        onClick={handleDismiss}
      />

      {/* Modal - centered, scrollable content */}
      <div
        className={`fixed inset-0 z-[61] flex items-center justify-center p-4 transition-all duration-400 ${dismissed ? 'opacity-0 scale-95 pointer-events-none' : 'opacity-100 scale-100'}`}
      >
        <div className="relative bg-charcoal-deep border border-white/10 max-w-md w-full max-h-[90vh] overflow-y-auto overflow-x-hidden">
          {/* Close button */}
          <button
            onClick={handleDismiss}
            className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center text-white/40 hover:text-white transition-colors cursor-pointer z-10"
            aria-label="Close"
          >
            <i className="ri-close-line text-xl" />
          </button>

          <div className="p-5 md:p-7">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-orange/15 border border-orange/30 text-orange px-3 py-1.5 text-xs font-bold uppercase tracking-widest mb-4">
              <span className="w-2 h-2 rounded-full bg-orange animate-pulse" />
              Storm Alert — Spring 2026
            </div>

            {/* Headline */}
            <h2 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider leading-tight mb-2">
              Hail Season Is Here.<br />
              <span className="text-orange">Is Your Roof Ready?</span>
            </h2>

            <p className="text-white/50 text-xs md:text-sm leading-relaxed mb-4">
              Indiana and Kentucky see some of the most severe spring hail in the Midwest. Recent storms in Vanderburgh County have already caused significant roof damage.
            </p>

            {/* Storm stats - compact on mobile */}
            <div className="grid grid-cols-3 gap-2 mb-4">
              {[
                { value: '34', label: 'Claims', sub: 'April 2026' },
                { value: '1.75"', label: 'Hail Size', sub: 'Evansville' },
                { value: '12 mo', label: 'Window', sub: 'To file' },
              ].map((s) => (
                <div key={s.label} className="bg-white/5 border border-white/10 p-2 md:p-3 text-center">
                  <p className="font-display text-orange text-lg md:text-xl tracking-wider">{s.value}</p>
                  <p className="text-white text-[10px] md:text-xs font-semibold mt-0.5">{s.label}</p>
                  <p className="text-white/30 text-[10px] md:text-xs">{s.sub}</p>
                </div>
              ))}
            </div>

            {/* What we offer */}
            <div className="space-y-1.5 mb-5">
              {[
                'Free storm damage inspection',
                'We meet your adjuster on-site',
                'Most clients pay only deductible',
                '24/7 emergency tarping available',
              ].map((item) => (
                <div key={item} className="flex items-center gap-2 text-white/60 text-xs md:text-sm">
                  <div className="w-4 h-4 flex items-center justify-center bg-orange/20 text-orange flex-shrink-0">
                    <i className="ri-check-line text-xs" />
                  </div>
                  {item}
                </div>
              ))}
            </div>

            {/* CTAs */}
            <div className="flex flex-col gap-2">
              <button
                onClick={handleCTA}
                className="w-full bg-orange hover:bg-orange-dark text-white font-semibold py-3 uppercase tracking-widest text-xs md:text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
              >
                <i className="ri-thunderstorms-line" />
                Check My Roof for Free
              </button>
              <a
                href="tel:8122135997"
                className="w-full border border-white/20 hover:border-orange text-white font-semibold py-3 uppercase tracking-wide text-xs md:text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2"
              >
                <i className="ri-phone-line text-orange" />
                Call 812-213-5997
              </a>
            </div>

            <p className="text-white/20 text-xs text-center mt-3">
              Free inspection · No pressure · Evansville &amp; Tri-State
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
