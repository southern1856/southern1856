import { useState } from 'react';
import { projects } from '@/mocks/projects';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import BeforeAfterSlider from '@/components/feature/BeforeAfterSlider';

const getBadgeStyle = (badge: string) => {
  switch (badge) {
    case 'Before & After':
      return 'bg-orange text-white';
    case 'Before':
      return 'bg-rose-600 text-white';
    case 'After':
      return 'bg-emerald-600 text-white';
    case 'In Progress':
    default:
      return 'bg-white/20 backdrop-blur-sm text-white border border-white/30';
  }
};

const getBadgeIcon = (badge: string) => {
  switch (badge) {
    case 'Before & After':
      return 'ri-arrow-left-right-line';
    case 'Before':
      return 'ri-error-warning-line';
    case 'After':
      return 'ri-checkbox-circle-line';
    case 'In Progress':
    default:
      return 'ri-tools-line';
  }
};

export default function ProjectsSection() {
  const [hoveredId, setHoveredId] = useState<number | null>(null);
  const [activeFilter, setActiveFilter] = useState<string>('All');
  const header = useScrollAnimation();
  const row1 = useScrollAnimation({ threshold: 0.1 });
  const row2 = useScrollAnimation({ threshold: 0.1 });
  const row3 = useScrollAnimation({ threshold: 0.1 });

  const filters = ['All', 'Residential', 'Commercial', 'Repair', 'Multi-Family'];

  const filteredProjects = activeFilter === 'All'
    ? projects
    : projects.filter((p) => p.type === activeFilter);

  const featuredJobIds = [19, 20, 1, 2, 21];

  const largeProjects = filteredProjects.filter((p) => p.size === 'large');
  const mediumProjects = filteredProjects.filter((p) => p.size === 'medium' && !featuredJobIds.includes(p.id));
  const smallProjects = filteredProjects.filter((p) => p.size === 'small');

  // Detect Before/After pairs in the large projects
  const beforeProject = largeProjects.find((p) => p.badge === 'Before');
  const afterProject = largeProjects.find((p) => p.badge === 'After');
  const hasSliderPair = !!(beforeProject && afterProject);

  const beforeProject2 = largeProjects.find((p) => p.badge === 'Before2');
  const afterProject2 = largeProjects.find((p) => p.badge === 'After2');
  const hasSliderPair2 = !!(beforeProject2 && afterProject2);

  const sliderIds = [
    beforeProject?.id, afterProject?.id,
    beforeProject2?.id, afterProject2?.id,
  ].filter(Boolean) as number[];

  const remainingLarge = largeProjects.filter((p) => !sliderIds.includes(p.id));

  return (
    <section id="projects" className="bg-charcoal-deep py-20 md:py-28 overflow-hidden">
      <div className="w-full px-6 md:px-10 lg:px-16">
        {/* Header */}
        <div
          ref={header.ref as React.RefObject<HTMLDivElement>}
          className={`flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-10 anim-fade-up ${header.isVisible ? 'is-visible' : ''}`}
        >
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Our Portfolio</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              A Look at What<br />We've Nailed
            </h2>
          </div>
          <button
            onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="self-start md:self-end border border-white/20 hover:border-orange text-white/70 hover:text-white text-xs uppercase tracking-widest px-6 py-3 transition-all duration-200 whitespace-nowrap cursor-pointer"
          >
            Start Your Project
          </button>
        </div>

        {/* Filter Bar */}
        <div className={`flex flex-wrap gap-2 mb-10 anim-fade-up ${header.isVisible ? 'is-visible' : ''}`} style={{ transitionDelay: '150ms' }}>
          {filters.map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-5 py-2 text-xs uppercase tracking-widest font-semibold transition-all duration-200 whitespace-nowrap cursor-pointer border ${
                activeFilter === filter
                  ? 'bg-orange border-orange text-white'
                  : 'border-white/20 text-white/50 hover:border-white/50 hover:text-white'
              }`}
            >
              {filter}
            </button>
          ))}
          <span className="ml-auto self-center text-white/70 text-xs uppercase tracking-widest">
            {filteredProjects.length} project{filteredProjects.length !== 1 ? 's' : ''}
          </span>
        </div>

        {/* Gallery Grid */}
        {filteredProjects.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="w-12 h-12 flex items-center justify-center mb-4">
              <i className="ri-folder-open-line text-white/20 text-4xl" />
            </div>
            <p className="text-white/30 text-sm uppercase tracking-widest">No projects in this category yet</p>
          </div>
        ) : (
          <div className="space-y-2">

            {/* ── Featured Job Group ── */}
            {(hasSliderPair || hasSliderPair2) && (
              <div
                ref={row1.ref as React.RefObject<HTMLDivElement>}
                className={`anim-fade-up ${row1.isVisible ? 'is-visible' : ''}`}
              >
                {/* Group header */}
                <div className="flex items-center gap-4 mb-2 pl-1">
                  <div className="w-1 h-8 bg-orange flex-shrink-0" />
                  <div>
                    <p className="text-orange text-xs font-bold uppercase tracking-[0.25em]">Featured Job</p>
                    <p className="text-white font-display text-lg uppercase tracking-wider leading-none">Evansville Full Replacement</p>
                  </div>
                  <div className="ml-auto flex items-center gap-2 text-white/70 text-xs uppercase tracking-widest">
                    <i className="ri-map-pin-line text-xs" />
                    Evansville, IN
                  </div>
                </div>

                {/* Stage labels row */}
                <div className="grid grid-cols-3 gap-2 mb-2">
                  {(['1 — Rotted Deck', '2 — Install Underway', '3 — Finished Roof'] as const).map((label, i) => (
                    <div key={i} className="flex items-center gap-2 px-3 py-2 border border-white/10 bg-white/5">
                      <span className="w-5 h-5 flex items-center justify-center rounded-full bg-orange text-white text-xs font-bold flex-shrink-0">{i + 1}</span>
                      <span className="text-white/70 text-xs uppercase tracking-wider">{label.split('— ')[1]}</span>
                    </div>
                  ))}
                </div>

                {/* Slider 2: Rotted deck → Finished roof */}
                {hasSliderPair2 && (
                  <div className="mb-2">
                    <BeforeAfterSlider
                      beforeImage={beforeProject2!.image}
                      afterImage={afterProject2!.image}
                      beforeLabel="Before"
                      afterLabel="After"
                      title="Rotted Deck — Brand New Roof"
                      type="Residential"
                      location={beforeProject2!.location}
                    />
                  </div>
                )}

                {/* Mid-install card inline */}
                {(() => {
                  const midCard = filteredProjects.find((p) => p.id === 21);
                  return midCard ? (
                    <div
                      className="relative overflow-hidden group cursor-pointer"
                      onMouseEnter={() => setHoveredId(midCard.id)}
                      onMouseLeave={() => setHoveredId(null)}
                    >
                      <img
                        src={midCard.image}
                        alt={midCard.title}
                        className="w-full h-52 md:h-64 object-cover object-top group-hover:scale-105 transition-transform duration-700"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                      <div className="absolute top-3 left-3">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-bold uppercase tracking-widest bg-white/20 backdrop-blur-sm text-white border border-white/30">
                          <i className="ri-tools-line text-xs" />
                          Stage 2 — In Progress
                        </span>
                      </div>
                      <div className="absolute bottom-0 left-0 p-5 md:p-6">
                        <p className="text-orange text-xs font-semibold tracking-widest uppercase mb-1">{midCard.type}</p>
                        <h3 className="font-display text-white text-xl md:text-2xl tracking-wider uppercase">{midCard.title}</h3>
                        <p className="text-white/70 text-xs mt-1">{midCard.location}</p>
                      </div>
                    </div>
                  ) : null;
                })()}

                {/* Slider 1: Tear-off deck → Finished roof */}
                {hasSliderPair && (
                  <div className="mt-2">
                    <BeforeAfterSlider
                      beforeImage={beforeProject!.image}
                      afterImage={afterProject!.image}
                      beforeLabel="Before"
                      afterLabel="After"
                      title="Tear-Off to Finished Roof"
                      type="Residential"
                      location={beforeProject!.location}
                    />
                  </div>
                )}

                {/* Job Summary Strip */}
                <div className="mt-2 border border-white/10 bg-white/5">
                  <div className="grid grid-cols-2 md:grid-cols-4 divide-y md:divide-y-0 divide-x-0 md:divide-x divide-white/10">
                    <div className="flex flex-col gap-1 px-5 py-4">
                      <p className="text-white/70 text-xs uppercase tracking-widest">Materials</p>
                      <p className="text-white text-sm font-semibold">GAF Timberline HD</p>
                      <p className="text-white/70 text-xs">Charcoal — Lifetime warranty</p>
                    </div>
                    <div className="flex flex-col gap-1 px-5 py-4">
                      <p className="text-white/70 text-xs uppercase tracking-widest">Underlayment</p>
                      <p className="text-white text-sm font-semibold">GAF FeltBuster</p>
                      <p className="text-white/70 text-xs">Synthetic roofing felt</p>
                    </div>
                    <div className="flex flex-col gap-1 px-5 py-4">
                      <p className="text-white/70 text-xs uppercase tracking-widest">Scope</p>
                      <p className="text-white text-sm font-semibold">Full Replacement</p>
                      <p className="text-white/70 text-xs">Tear-off, deck repair, reroof</p>
                    </div>
                    <div className="flex flex-col gap-1 px-5 py-4">
                      <p className="text-white/70 text-xs uppercase tracking-widest">Timeline</p>
                      <p className="text-white text-sm font-semibold">1 Day</p>
                      <p className="text-white/70 text-xs">Evansville, IN</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Remaining large cards (if any) */}
            {remainingLarge.length > 0 && (
              <div
                ref={!hasSliderPair ? row1.ref as React.RefObject<HTMLDivElement> : undefined}
                className="grid grid-cols-1 sm:grid-cols-2 gap-2"
              >
                {remainingLarge.map((project, i) => (
                  <div
                    key={project.id}
                    className={`relative overflow-hidden group cursor-pointer anim-fade-up ${row1.isVisible ? 'is-visible' : ''}`}
                    style={{ transitionDelay: `${i * 150}ms` }}
                    onMouseEnter={() => setHoveredId(project.id)}
                    onMouseLeave={() => setHoveredId(null)}
                  >
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-64 md:h-80 object-cover object-top group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                    {project.badge && (
                      <div className="absolute top-4 left-4">
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold uppercase tracking-widest ${getBadgeStyle(project.badge)}`}>
                          <i className={`${getBadgeIcon(project.badge)} text-xs`} />
                          {project.badge}
                        </span>
                      </div>
                    )}
                    <div className="absolute bottom-0 left-0 p-6 md:p-8">
                      <p className="text-orange text-xs font-semibold tracking-widest uppercase mb-2">{project.type}</p>
                      <h3 className="font-display text-white text-2xl md:text-3xl tracking-wider uppercase">{project.title}</h3>
                      <p className="text-white/70 text-sm mt-1">{project.location}</p>
                    </div>
                    <div className={`absolute top-4 right-4 w-10 h-10 flex items-center justify-center bg-orange transition-all duration-300 ${hoveredId === project.id ? 'opacity-100 scale-100' : 'opacity-0 scale-75'}`}>
                      <i className="ri-arrow-right-up-line text-white text-lg" />
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Row 2: medium */}
            {mediumProjects.length > 0 && (
              <div
                ref={row2.ref as React.RefObject<HTMLDivElement>}
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2"
              >
                {mediumProjects.map((project, i) => (
                  <div
                    key={project.id}
                    className={`relative overflow-hidden group cursor-pointer anim-fade-up ${row2.isVisible ? 'is-visible' : ''}`}
                    style={{ transitionDelay: `${i * 120}ms` }}
                    onMouseEnter={() => setHoveredId(project.id)}
                    onMouseLeave={() => setHoveredId(null)}
                  >
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-52 md:h-60 object-cover object-top group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                    {project.badge && (
                      <div className="absolute top-3 left-3">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-bold uppercase tracking-widest ${getBadgeStyle(project.badge)}`}>
                          <i className={`${getBadgeIcon(project.badge)} text-xs`} />
                          {project.badge}
                        </span>
                      </div>
                    )}
                    <div className="absolute bottom-0 left-0 p-5 md:p-6">
                      <p className="text-orange text-xs font-semibold tracking-widest uppercase mb-1">{project.type}</p>
                      <h3 className="font-display text-white text-xl md:text-2xl tracking-wider uppercase">{project.title}</h3>
                      <p className="text-white/70 text-xs mt-1">{project.location}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Row 3: small */}
            {smallProjects.length > 0 && (
              <div
                ref={row3.ref as React.RefObject<HTMLDivElement>}
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2"
              >
                {smallProjects.map((project, i) => (
                  <div
                    key={project.id}
                    className={`relative overflow-hidden group cursor-pointer anim-fade-up ${row3.isVisible ? 'is-visible' : ''}`}
                    style={{ transitionDelay: `${i * 100}ms` }}
                    onMouseEnter={() => setHoveredId(project.id)}
                    onMouseLeave={() => setHoveredId(null)}
                  >
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-44 md:h-52 object-cover object-top group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                    {project.badge && (
                      <div className="absolute top-2.5 left-2.5">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 text-xs font-bold uppercase tracking-wider ${getBadgeStyle(project.badge)}`}>
                          <i className={`${getBadgeIcon(project.badge)} text-xs`} />
                          {project.badge}
                        </span>
                      </div>
                    )}
                    <div className="absolute bottom-0 left-0 p-4">
                      <p className="text-orange text-xs font-semibold tracking-widest uppercase mb-0.5">{project.type}</p>
                      <h3 className="font-display text-white text-base md:text-lg tracking-wider uppercase">{project.title}</h3>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
