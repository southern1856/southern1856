import { useState, useRef } from 'react';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

export default function RemoteEstimateSection() {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [step, setStep] = useState(1);
  const formRef = useRef<HTMLFormElement>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;

    setStatus('submitting');

    try {
      const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
      const response = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      });

      if (response.ok) {
        setStatus('success');
        formRef.current.reset();
        setStep(1);
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    }
  };

  const nextStep = () => setStep((s) => Math.min(s + 1, 3));
  const prevStep = () => setStep((s) => Math.max(s - 1, 1));

  return (
    <section id="remote-estimate" className="bg-warm-beige py-20 md:py-28 lg:py-32">
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-10 md:mb-14">
            <div className="inline-flex items-center gap-2 bg-orange/10 text-orange font-semibold text-sm px-4 py-2 rounded-full mb-5">
              <i className="ri-computer-line" />
              No Home Visit Required
            </div>
            <h2 className="font-display font-bold text-charcoal text-3xl md:text-4xl lg:text-5xl mb-5">
              Get a Remote Roof Estimate
            </h2>
            <p className="text-gray-500 text-base md:text-lg leading-relaxed max-w-2xl mx-auto">
              Using satellite imagery, your roof measurements, and photos, we can generate an accurate estimate for your roof replacement — no in-person visit needed. Most estimates delivered within 4 hours.
            </p>
          </div>

          {/* How It Works */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-10 md:mb-14">
            {[
              {
                step: '1',
                title: 'Submit Your Info',
                desc: 'Fill out the form with your address, home details, and roof measurements if you have them.',
              },
              {
                step: '2',
                title: 'We Analyze & Quote',
                desc: 'Our team reviews your details, satellite imagery, and any photos or measurements you provide.',
              },
              {
                step: '3',
                title: 'Receive Your Estimate',
                desc: 'Get a detailed written estimate via email or text within 4 business hours.',
              },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="w-12 h-12 flex items-center justify-center bg-orange text-white font-bold text-lg rounded-full mx-auto mb-4">
                  {item.step}
                </div>
                <h3 className="font-display font-bold text-charcoal text-lg mb-2">{item.title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>

          {/* Form */}
          <div className="bg-white rounded-3xl p-6 md:p-10 lg:p-12 shadow-[0_4px_20px_rgba(0,0,0,0.06)]">
            {status === 'success' ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 flex items-center justify-center bg-green-100 rounded-full mx-auto mb-5">
                  <i className="ri-checkbox-circle-line text-green-600 text-3xl" />
                </div>
                <h3 className="font-display font-bold text-charcoal text-2xl md:text-3xl mb-3">
                  Estimate Request Received!
                </h3>
                <p className="text-gray-500 text-base max-w-md mx-auto mb-4">
                  Our team is reviewing your details, measurements, and any photos you sent. You will receive a detailed estimate within 4 business hours.
                </p>
                <div className="bg-orange/5 border border-orange/20 rounded-xl p-4 max-w-md mx-auto mb-6">
                  <p className="text-charcoal font-semibold text-sm mb-2 flex items-center gap-2 justify-center">
                    <i className="ri-image-line text-orange" />
                    Have roof photos? Send them now for a more accurate quote!
                  </p>
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                    <a href="tel:8122135997" className="flex items-center gap-2 text-orange font-semibold text-sm hover:text-orange-dark transition-colors">
                      <i className="ri-message-3-line" />
                      Text to 812-213-5997
                    </a>
                    <a href="mailto:themainstoneconstruction@gmail.com" className="flex items-center gap-2 text-orange font-semibold text-sm hover:text-orange-dark transition-colors">
                      <i className="ri-mail-send-line" />
                      Email Photos
                    </a>
                  </div>
                </div>
                <button
                  onClick={() => setStatus('idle')}
                  className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-3 rounded-full transition-colors cursor-pointer"
                >
                  Submit Another Request
                </button>
              </div>
            ) : (
              <form
                ref={formRef}
                data-readdy-form
                onSubmit={handleSubmit}
              >
                {/* Step indicator */}
                <div className="flex items-center justify-center gap-3 mb-8">
                  {[1, 2, 3].map((s) => (
                    <div key={s} className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 flex items-center justify-center rounded-full font-bold text-sm transition-colors ${
                          s <= step
                            ? 'bg-orange text-white'
                            : 'bg-gray-100 text-gray-400'
                        }`}
                      >
                        {s}
                      </div>
                      {s < 3 && (
                        <div
                          className={`w-12 h-0.5 transition-colors ${
                            s < step ? 'bg-orange' : 'bg-gray-200'
                          }`}
                        />
                      )}
                    </div>
                  ))}
                </div>

                {/* Step 1: Contact & Address */}
                {step === 1 && (
                  <div className="space-y-5 animate-in fade-in duration-300">
                    <h3 className="font-display font-bold text-charcoal text-xl mb-1">Your Contact Info</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-2">Full Name *</label>
                        <input type="text" name="name" required placeholder="John Smith" className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors" />
                      </div>
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-2">Email *</label>
                        <input type="email" name="email" required placeholder="your@email.com" className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors" />
                      </div>
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-2">Phone *</label>
                        <input type="tel" name="phone" required placeholder="812-213-5997" className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors" />
                      </div>
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-2">Property Address *</label>
                        <input type="text" name="address" required placeholder="123 Main St, Evansville, IN" className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors" />
                      </div>
                    </div>
                    <div className="flex justify-end pt-4">
                      <button type="button" onClick={nextStep} className="bg-charcoal hover:bg-charcoal-deep text-white font-semibold px-8 py-3 rounded-full transition-colors cursor-pointer flex items-center gap-2">
                        Next Step <i className="ri-arrow-right-line" />
                      </button>
                    </div>
                  </div>
                )}

                {/* Step 2: Home & Roof Details */}
                {step === 2 && (
                  <div className="space-y-5 animate-in fade-in duration-300">
                    <h3 className="font-display font-bold text-charcoal text-xl mb-1">Home & Roof Details</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-2">Home Type *</label>
                        <select name="home_type" required className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors appearance-none cursor-pointer">
                          <option value="">Select home type</option>
                          <option value="single-story">Single Story</option>
                          <option value="two-story">Two Story</option>
                          <option value="split-level">Split Level</option>
                          <option value="ranch">Ranch</option>
                          <option value="townhouse">Townhouse / Duplex</option>
                          <option value="other">Other</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-2">Approx. Home Size *</label>
                        <select name="home_size" required className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors appearance-none cursor-pointer">
                          <option value="">Select size range</option>
                          <option value="under-1000">Under 1,000 sq ft</option>
                          <option value="1000-1500">1,000 - 1,500 sq ft</option>
                          <option value="1500-2000">1,500 - 2,000 sq ft</option>
                          <option value="2000-2500">2,000 - 2,500 sq ft</option>
                          <option value="2500-3000">2,500 - 3,000 sq ft</option>
                          <option value="over-3000">Over 3,000 sq ft</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-2">Current Roof Condition *</label>
                        <select name="roof_condition" required className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors appearance-none cursor-pointer">
                          <option value="">Select condition</option>
                          <option value="new">New / Recently Replaced</option>
                          <option value="good">Good — Minor Wear</option>
                          <option value="fair">Fair — Some Damage</option>
                          <option value="poor">Poor — Leaks or Major Damage</option>
                          <option value="emergency">Emergency — Active Leak</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-2">Desired Material *</label>
                        <select name="material" required className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors appearance-none cursor-pointer">
                          <option value="">Select material</option>
                          <option value="architectural-shingles">Architectural Shingles</option>
                          <option value="3-tab-shingles">3-Tab Shingles</option>
                          <option value="metal">Metal Roofing</option>
                          <option value="luxury-shingles">Luxury / Designer Shingles</option>
                          <option value="unsure">Unsure — Need Recommendations</option>
                        </select>
                      </div>
                    </div>
                    <div className="bg-orange/5 border border-orange/20 rounded-xl p-4">
                      <label className="block text-charcoal text-sm font-medium mb-2 flex items-center gap-2">
                        <i className="ri-ruler-line text-orange" />
                        Already Have Roof Measurements?
                      </label>
                      <input
                        type="text"
                        name="roof_measurements"
                        placeholder="e.g. 24 squares, 2,400 sq ft, or insurance adjuster report"
                        className="w-full bg-white rounded-xl px-4 py-3 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border border-gray-200 transition-colors mb-2"
                      />
                      <p className="text-gray-500 text-xs">
                        If you have measurements from an insurance adjuster, previous contractor, or your own calculations, enter them here. This helps us give you the most accurate estimate possible.
                      </p>
                    </div>
                    <div className="flex justify-between pt-4">
                      <button type="button" onClick={prevStep} className="text-charcoal font-semibold px-6 py-3 hover:bg-gray-100 rounded-full transition-colors cursor-pointer flex items-center gap-2">
                        <i className="ri-arrow-left-line" /> Back
                      </button>
                      <button type="button" onClick={nextStep} className="bg-charcoal hover:bg-charcoal-deep text-white font-semibold px-8 py-3 rounded-full transition-colors cursor-pointer flex items-center gap-2">
                        Next Step <i className="ri-arrow-right-line" />
                      </button>
                    </div>
                  </div>
                )}

                {/* Step 3: Additional Info & Submit */}
                {step === 3 && (
                  <div className="space-y-5 animate-in fade-in duration-300">
                    <h3 className="font-display font-bold text-charcoal text-xl mb-1">Additional Details</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-2">Roof Features</label>
                        <div className="space-y-2">
                          {['Chimney', 'Skylights', 'Dormers', 'Gutters Need Replacement', 'Solar Panels'].map((feature) => (
                            <label key={feature} className="flex items-center gap-3 cursor-pointer">
                              <input type="checkbox" name="features" value={feature.toLowerCase().replace(/\s+/g, '-')} className="w-5 h-5 accent-orange rounded" />
                              <span className="text-gray-600 text-sm">{feature}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-2">Preferred Timeline</label>
                        <select name="timeline" className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors appearance-none cursor-pointer mb-4">
                          <option value="">When do you need it done?</option>
                          <option value="asap">ASAP — Emergency</option>
                          <option value="1-2-months">1-2 Months</option>
                          <option value="3-6-months">3-6 Months</option>
                          <option value="planning">Just Planning / Budgeting</option>
                        </select>
                        <div className="bg-orange/5 border border-orange/20 rounded-xl p-4">
                          <p className="text-charcoal font-semibold text-sm mb-2 flex items-center gap-2">
                            <i className="ri-image-line text-orange" />
                            Have Roof Photos?
                          </p>
                          <p className="text-gray-600 text-sm leading-relaxed mb-3">
                            Snap a few pictures of your roof from the ground and send them to us. Photos help us give you a more accurate estimate.
                          </p>
                          <div className="space-y-2">
                            <a href="tel:8122135997" className="flex items-center gap-2 text-orange font-semibold text-sm hover:text-orange-dark transition-colors">
                              <i className="ri-message-3-line" />
                              Text to 812-213-5997
                            </a>
                            <a href="mailto:themainstoneconstruction@gmail.com" className="flex items-center gap-2 text-orange font-semibold text-sm hover:text-orange-dark transition-colors">
                              <i className="ri-mail-send-line" />
                              Email to themainstoneconstruction@gmail.com
                            </a>
                          </div>
                          <p className="text-gray-400 text-xs mt-2">
                            Please include your name and address with the photos.
                          </p>
                        </div>
                      </div>
                    </div>
                    <div>
                      <label className="block text-charcoal text-sm font-medium mb-2">Anything Else We Should Know?</label>
                      <textarea name="notes" rows={3} placeholder="Describe any specific concerns, previous repairs, insurance claims, etc." className="w-full bg-gray-100 rounded-xl px-5 py-4 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors resize-none" />
                    </div>
                    <div className="flex justify-between pt-4">
                      <button type="button" onClick={prevStep} className="text-charcoal font-semibold px-6 py-3 hover:bg-gray-100 rounded-full transition-colors cursor-pointer flex items-center gap-2">
                        <i className="ri-arrow-left-line" /> Back
                      </button>
                      <button
                        type="submit"
                        disabled={status === 'submitting'}
                        className="bg-orange hover:bg-orange-dark disabled:bg-gray-400 text-white font-semibold px-8 py-4 rounded-full transition-colors cursor-pointer flex items-center gap-2"
                      >
                        {status === 'submitting' ? (
                          <>
                            <i className="ri-loader-4-line animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          <>
                            Get My Remote Estimate
                            <i className="ri-arrow-right-line" />
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                )}

                {status === 'error' && (
                  <div className="mt-4 bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-3">
                    <i className="ri-alert-line text-red-600 text-xl" />
                    <p className="text-red-700 text-sm">Something went wrong. Please try again or call us at 812-213-5997.</p>
                  </div>
                )}
              </form>
            )}
          </div>

          {/* Trust badges below form */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-6 md:gap-10">
            <div className="flex items-center gap-2 text-gray-500 text-sm">
              <i className="ri-shield-check-line text-orange" />
              <span>Accurate within 10%</span>
            </div>
            <div className="flex items-center gap-2 text-gray-500 text-sm">
              <i className="ri-time-line text-orange" />
              <span>Delivered in 4 hours</span>
            </div>
            <div className="flex items-center gap-2 text-gray-500 text-sm">
              <i className="ri-lock-line text-orange" />
              <span>No obligation</span>
            </div>
            <div className="flex items-center gap-2 text-gray-500 text-sm">
              <i className="ri-map-pin-line text-orange" />
              <span>Satellite verified</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}