import { useState, useEffect, useCallback } from 'react';

export default function EmergencyPhoneSticky() {
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [hovered, setHovered] = useState(false);

  const checkAlert = useCallback(() => {
    const alertActive = sessionStorage.getItem('severe-weather-alert-active');
    const wasDismissed = sessionStorage.getItem('emergency-phone-dismissed');
    if (alertActive === '1' && !wasDismissed) {
      setVisible(true);
    } else {
      setVisible(false);
    }
  }, []);

  useEffect(() => {
    checkAlert();
    const handleStorage = () => checkAlert();
    window.addEventListener('storage', handleStorage);
    const handleCustom = () => checkAlert();
    window.addEventListener('emergency-alert-changed', handleCustom);
    const interval = setInterval(checkAlert, 2000);
    return () => {
      window.removeEventListener('storage', handleStorage);
      window.removeEventListener('emergency-alert-changed', handleCustom);
      clearInterval(interval);
    };
  }, [checkAlert]);

  const handleDismiss = () => {
    setDismissed(true);
    sessionStorage.setItem('emergency-phone-dismissed', '1');
    setTimeout(() => setVisible(false), 400);
  };

  if (!visible) return null;

  return (
    <div
      className={`fixed left-0 top-1/2 -translate-y-1/2 z-[55] hidden md:block transition-all duration-500 ${
        dismissed ? '-translate-x-full opacity-0' : 'translate-x-0 opacity-100'
      }`}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className="flex flex-col items-center relative">
        {/* Emergency phone */}
        <a
          href="tel:8122135997"
          className="group flex flex-col items-center cursor-pointer relative"
          aria-label="Emergency roof repair phone number"
        >
          <div
            className={`relative bg-red-600 hover:bg-red-500 text-white shadow-xl transition-all duration-300 ${
              hovered ? 'scale-105' : ''
            }`}
            style={{
              borderTopRightRadius: '8px',
            }}
          >
            <div className="flex flex-col items-center py-4 px-2.5 gap-2.5">
              {/* Pulse dot */}
              <span className="relative flex items-center justify-center w-3 h-3">
                <span className="absolute inset-0 rounded-full bg-white/40 animate-ping" />
                <span className="relative w-2 h-2 rounded-full bg-white" />
              </span>

              {/* Phone icon */}
              <div className="w-8 h-8 flex items-center justify-center">
                <i className="ri-phone-fill text-white text-lg" />
              </div>

              {/* Rotated text */}
              <div
                className="font-bold text-[10px] uppercase tracking-[0.2em] text-white/90"
                style={{ writingMode: 'vertical-rl', textOrientation: 'mixed' }}
              >
                Emergency
              </div>

              {/* Number shown on hover */}
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  hovered ? 'max-h-20 opacity-100 mt-1' : 'max-h-0 opacity-0'
                }`}
              >
                <div
                  className="font-display text-[11px] tracking-wider text-white"
                  style={{ writingMode: 'vertical-rl', textOrientation: 'mixed' }}
                >
                  812-213-5997
                </div>
              </div>
            </div>
          </div>
        </a>

        {/* Email link — styled to match */}
        <a
          href="mailto:themainstoneconstruction@gmail.com"
          className="group flex flex-col items-center cursor-pointer relative"
          aria-label="Email Corner Stone Construction & Roofing"
        >
          <div
            className={`relative bg-charcoal-deep hover:bg-charcoal-light border-l-0 border border-white/10 border-t-0 text-white shadow-xl transition-all duration-300 ${
              hovered ? 'scale-105' : ''
            }`}
            style={{
              borderBottomRightRadius: '8px',
              borderTopRightRadius: '0px',
            }}
          >
            <div className="flex flex-col items-center py-3 px-2.5 gap-2.5">
              <div className="w-8 h-8 flex items-center justify-center">
                <i className="ri-mail-line text-orange text-lg" />
              </div>
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  hovered ? 'max-h-20 opacity-100' : 'max-h-0 opacity-0'
                }`}
              >
                <div
                  className="font-display text-[10px] tracking-wider text-white/80"
                  style={{ writingMode: 'vertical-rl', textOrientation: 'mixed' }}
                >
                  Email Us
                </div>
              </div>
            </div>
          </div>
        </a>
      </div>

      {/* Dismiss button */}
      <button
        onClick={handleDismiss}
        className="absolute -right-2 -top-2 w-5 h-5 bg-charcoal-deep border border-white/15 flex items-center justify-center text-white/40 hover:text-white hover:border-orange/50 transition-colors cursor-pointer z-10"
        aria-label="Dismiss emergency button"
        style={{ borderRadius: '3px' }}
      >
        <i className="ri-close-line text-[10px]" />
      </button>
    </div>
  );
}