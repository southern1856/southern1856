import { useState, useRef, useCallback, useEffect } from 'react';

interface BeforeAfterSliderProps {
  beforeImage: string;
  afterImage: string;
  beforeLabel?: string;
  afterLabel?: string;
  title?: string;
  type?: string;
  location?: string;
}

export default function BeforeAfterSlider({
  beforeImage,
  afterImage,
  beforeLabel = 'Before',
  afterLabel = 'After',
  title,
  type,
  location,
}: BeforeAfterSliderProps) {
  const [sliderPos, setSliderPos] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const getPos = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
    setSliderPos((x / rect.width) * 100);
  }, []);

  const onMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    getPos(e.clientX);
  }, [getPos]);

  const onTouchStart = useCallback((e: React.TouchEvent) => {
    setIsDragging(true);
    getPos(e.touches[0].clientX);
  }, [getPos]);

  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      getPos(e.clientX);
    };
    const onTouchMove = (e: TouchEvent) => {
      if (!isDragging) return;
      getPos(e.touches[0].clientX);
    };
    const onUp = () => setIsDragging(false);

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onUp);
    window.addEventListener('touchmove', onTouchMove);
    window.addEventListener('touchend', onUp);
    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onUp);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onUp);
    };
  }, [isDragging, getPos]);

  return (
    <div
      ref={containerRef}
      className="relative overflow-hidden select-none cursor-col-resize group w-full h-64 md:h-80"
      onMouseDown={onMouseDown}
      onTouchStart={onTouchStart}
    >
      {/* After image (base layer) */}
      <img
        src={afterImage}
        alt={afterLabel}
        className="absolute inset-0 w-full h-full object-cover object-top"
        draggable={false}
      />

      {/* Before image (clipped layer) */}
      <div
        className="absolute inset-0 overflow-hidden"
        style={{ width: `${sliderPos}%` }}
      >
        <img
          src={beforeImage}
          alt={beforeLabel}
          className="absolute inset-0 w-full h-full object-cover object-top"
          style={{ width: containerRef.current ? `${containerRef.current.offsetWidth}px` : '100%', maxWidth: 'none' }}
          draggable={false}
        />
      </div>

      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent pointer-events-none" />

      {/* Divider line */}
      <div
        className="absolute top-0 bottom-0 w-0.5 bg-white z-10 pointer-events-none"
        style={{ left: `${sliderPos}%` }}
      />

      {/* Handle */}
      <div
        className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 z-20 pointer-events-none"
        style={{ left: `${sliderPos}%` }}
      >
        <div className={`w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-lg transition-transform duration-150 ${isDragging ? 'scale-110' : 'scale-100'}`}>
          <i className="ri-arrow-left-right-line text-charcoal-deep text-base" />
        </div>
      </div>

      {/* Before label */}
      <div className="absolute top-3 left-3 z-10 pointer-events-none">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold uppercase tracking-widest bg-rose-600 text-white">
          <i className="ri-error-warning-line text-xs" />
          {beforeLabel}
        </span>
      </div>

      {/* After label */}
      <div className="absolute top-3 right-3 z-10 pointer-events-none">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold uppercase tracking-widest bg-emerald-600 text-white">
          <i className="ri-checkbox-circle-line text-xs" />
          {afterLabel}
        </span>
      </div>

      {/* Drag hint — fades after first interaction */}
      <div className={`absolute inset-0 flex items-center justify-center z-10 pointer-events-none transition-opacity duration-500 ${isDragging || sliderPos !== 50 ? 'opacity-0' : 'opacity-100'}`}>
        <div className="bg-black/40 backdrop-blur-sm px-4 py-2 flex items-center gap-2">
          <i className="ri-drag-move-line text-white text-sm" />
          <span className="text-white text-xs uppercase tracking-widest font-semibold">Drag to Compare</span>
        </div>
      </div>

      {/* Project info */}
      {title && (
        <div className="absolute bottom-0 left-0 p-6 md:p-8 pointer-events-none">
          {type && <p className="text-orange text-xs font-semibold tracking-widest uppercase mb-2">{type}</p>}
          <h3 className="font-display text-white text-2xl md:text-3xl tracking-wider uppercase">{title}</h3>
          {location && <p className="text-white/50 text-sm mt-1">{location}</p>}
        </div>
      )}
    </div>
  );
}
