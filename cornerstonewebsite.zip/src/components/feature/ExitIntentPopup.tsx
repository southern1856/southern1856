import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const STORAGE_KEY = 'exit_intent_dismissed';
const MIN_TIME_ON_PAGE = 8000; // 8 seconds before it can trigger
const COOLDOWN_HOURS = 24; // don't show again for 24h

export default function ExitIntentPopup() {
  const [visible, setVisible] = useState(false);
  const [closed, setClosed] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const shouldShow = useCallback(() => {
    if (typeof window === 'undefined') return false;
    const dismissed = localStorage.getItem(STORAGE_KEY);
    if (dismissed) {
      const ts = parseInt(dismissed, 10);
      if (!Number.isNaN(ts)) {
        const hoursAgo = (Date.now() - ts) / (1000 * 60 * 60);
        if (hoursAgo < COOLDOWN_HOURS) return false;
      }
    }
    return true;
  }, []);

  useEffect(() => {
    if (!shouldShow()) return;

    const pageEnterTime = Date.now();
    let triggered = false;

    // Desktop: mouse leaving toward top
    const handleMouseLeave = (e: MouseEvent) => {
      if (triggered) return;
      if (e.clientY < 10 && e.relatedTarget === null) {
        const timeOnPage = Date.now() - pageEnterTime;
        if (timeOnPage >= MIN_TIME_ON_PAGE) {
          triggered = true;
          setVisible(true);
        }
      }
    };

    // Mobile/tablet: scroll up fast near top after some time
    let lastScrollY = window.scrollY;
    let scrollTimeout: ReturnType<typeof setTimeout>;
    const handleScroll = () => {
      if (triggered) return;
      const currentY = window.scrollY;
      const timeOnPage = Date.now() - pageEnterTime;
      const scrollingUp = currentY < lastScrollY;
      const nearTop = currentY < 80;
      if (scrollingUp && nearTop && timeOnPage >= MIN_TIME_ON_PAGE) {
        clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(() => {
          if (!triggered) {
            triggered = true;
            setVisible(true);
          }
        }, 400);
      }
      lastScrollY = currentY;
    };

    document.addEventListener('mouseleave', handleMouseLeave);
    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      document.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('scroll', handleScroll);
      clearTimeout(scrollTimeout);
    };
  }, [shouldShow]);

  const handleClose = () => {
    setClosed(true);
    setVisible(false);
    localStorage.setItem(STORAGE_KEY, String(Date.now()));
  };

  const handleBookNow = () => {
    setVisible(false);
    navigate('/free-inspection');
  };

  const handleFormSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    const form = e.currentTarget;
    const _fd = new FormData(form);
    _fd.append('access_key', WEB3FORMS_ACCESS_KEY);
    const data = new URLSearchParams(_fd as unknown as Record<string, string>);
    try {
      await fetch(WEB3FORMS_ENDPOINT, { method: 'POST', body: data });
    } catch {
      // silent
    } finally {
      setLoading(false);
      setSubmitted(true);
      setTimeout(() => {
        handleClose();
      }, 2500);
    }
  };

  if (closed) return null;

  return (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm transition-opacity duration-400 ${
          visible ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={handleClose}
        aria-hidden={!visible}
      />

      {/* Popup */}
      <div
        className={`fixed inset-0 z-[61] flex items-center justify-center p-4 transition-all duration-500 ${
          visible ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div
          className="relative w-full max-w-lg bg-charcoal-deep border border-white/10 shadow-2xl overflow-hidden"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Decorative top bar */}
          <div className="h-1.5 bg-orange w-full" />

          {/* Close button */}
          <button
            onClick={handleClose}
            className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center text-white/30 hover:text-white transition-colors cursor-pointer z-10"
            aria-label="Close"
          >
            <i className="ri-close-line text-xl" />
          </button>

          {/* Content */}
          <div className="p-6 md:p-8">
            {/* Icon */}
            <div className="w-14 h-14 flex items-center justify-center bg-orange/10 border border-orange/20 text-orange mx-auto mb-5">
              <i className="ri-home-smile-line text-2xl" />
            </div>

            {!showForm ? (
              <>
                <h3 className="text-white text-xl md:text-2xl font-bold text-center mb-2 tracking-wide">
                  Wait — Don't Leave Yet!
                </h3>
                <p className="text-white/50 text-sm text-center mb-1 max-w-sm mx-auto">
                  Before you go, claim your <strong className="text-orange">FREE roof inspection</strong> — no strings attached.
                </p>
                <p className="text-white/30 text-xs text-center mb-6">
                  Evansville homeowners save an average of <strong className="text-white/50">$1,200–$3,400</strong> by catching problems early.
                </p>

                {/* Benefits list */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-7">
                  {[
                    { icon: 'ri-shield-check-line', text: 'Licensed & insured since 1995' },
                    { icon: 'ri-calendar-check-line', text: 'Same-week scheduling available' },
                    { icon: 'ri-file-list-3-line', text: 'Detailed photo report included' },
                    { icon: 'ri-price-tag-3-line', text: '100% free, zero obligation' },
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-start gap-2.5">
                      <div className="w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <i className={`${item.icon} text-orange text-sm`} />
                      </div>
                      <p className="text-white/60 text-xs leading-relaxed">{item.text}</p>
                    </div>
                  ))}
                </div>

                {/* CTAs */}
                <div className="flex flex-col sm:flex-row gap-3">
                  <button
                    onClick={handleBookNow}
                    className="flex-1 bg-orange hover:bg-orange-dark text-white font-semibold text-sm px-6 py-3.5 uppercase tracking-widest transition-colors duration-200 whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                  >
                    <i className="ri-calendar-line text-base" />
                    Book Free Inspection
                  </button>
                  <button
                    onClick={() => setShowForm(true)}
                    className="flex-1 border border-white/15 hover:border-orange/50 text-white/60 hover:text-orange text-sm font-medium px-6 py-3.5 uppercase tracking-widest transition-all duration-200 whitespace-nowrap cursor-pointer"
                  >
                    <i className="ri-phone-line text-base mr-2" />
                    Request Callback
                  </button>
                </div>

                <p className="text-white/20 text-xs text-center mt-4">
                  Or call us now at{' '}
                  <a href="tel:8122135997" className="text-orange hover:text-orange-dark transition-colors">
                    (812) 213-5997
                  </a>
                </p>
              </>
            ) : submitted ? (
              <div className="text-center py-4">
                <div className="w-14 h-14 flex items-center justify-center bg-orange/20 text-orange mx-auto mb-4">
                  <i className="ri-check-line text-2xl" />
                </div>
                <h3 className="text-white text-lg font-bold mb-2">You're All Set!</h3>
                <p className="text-white/50 text-sm mb-1">
                  We'll call you from <strong className="text-white/70">(812) 213-5997</strong> within the hour.
                </p>
                <p className="text-white/30 text-xs">Mon–Fri 7am–6pm · Sat 8am–2pm</p>
              </div>
            ) : (
              <>
                <h3 className="text-white text-lg font-bold text-center mb-1 tracking-wide">
                  Request a Callback
                </h3>
                <p className="text-white/40 text-xs text-center mb-5">
                  Leave your info and we'll call you back within 1 business hour.
                </p>

                <form data-readdy-form onSubmit={handleFormSubmit} className="space-y-3">
                  <div>
                    <label className="text-white/30 text-xs uppercase tracking-wider block mb-1.5">Your Name</label>
                    <input
                      type="text"
                      name="name"
                      required
                      placeholder="John Smith"
                      className="w-full bg-charcoal border border-white/10 focus:border-orange/50 text-white text-sm px-3 py-2.5 outline-none placeholder:text-white/40 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="text-white/30 text-xs uppercase tracking-wider block mb-1.5">Phone Number</label>
                    <input
                      type="tel"
                      name="phone"
                      required
                      placeholder="812-555-0000"
                      className="w-full bg-charcoal border border-white/10 focus:border-orange/50 text-white text-sm px-3 py-2.5 outline-none placeholder:text-white/40 transition-colors"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-white/30 text-xs uppercase tracking-wider block mb-1.5">Best Time</label>
                      <select
                        name="best_time"
                        className="w-full bg-charcoal border border-white/10 focus:border-orange/50 text-white text-sm px-3 py-2.5 outline-none transition-colors cursor-pointer appearance-none"
                      >
                        <option value="ASAP">ASAP</option>
                        <option value="Morning">Morning</option>
                        <option value="Afternoon">Afternoon</option>
                        <option value="Evening">Evening</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-white/30 text-xs uppercase tracking-wider block mb-1.5">Topic</label>
                      <select
                        name="topic"
                        className="w-full bg-charcoal border border-white/10 focus:border-orange/50 text-white text-sm px-3 py-2.5 outline-none transition-colors cursor-pointer appearance-none"
                      >
                        <option value="Free Inspection">Free Inspection</option>
                        <option value="Estimate">Estimate</option>
                        <option value="Storm Damage">Storm Damage</option>
                        <option value="Insurance">Insurance</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-orange hover:bg-orange-dark text-white font-semibold py-3 uppercase tracking-widest text-xs transition-colors whitespace-nowrap cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed mt-1"
                  >
                    {loading ? 'Sending...' : 'Request Callback'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="w-full text-white/30 hover:text-white/60 text-xs text-center transition-colors cursor-pointer py-1"
                  >
                    Go back
                  </button>
                </form>
              </>
            )}
          </div>

          {/* Bottom trust strip */}
          {!showForm && !submitted && (
            <div className="bg-charcoal border-t border-white/5 px-6 py-3 flex items-center justify-center gap-4 md:gap-6">
              <div className="flex items-center gap-1.5">
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <i key={n} className="ri-star-fill text-orange text-xs" />
                  ))}
                </div>
                <span className="text-white/40 text-xs">4.9 (127 reviews)</span>
              </div>
              <div className="w-px h-3 bg-white/10" />
              <span className="text-white/40 text-xs">A+ BBB Rated</span>
              <div className="w-px h-3 bg-white/10 hidden sm:block" />
              <span className="text-white/40 text-xs hidden sm:block">Evansville Since 1995</span>
            </div>
          )}
        </div>
      </div>
    </>
  );
}