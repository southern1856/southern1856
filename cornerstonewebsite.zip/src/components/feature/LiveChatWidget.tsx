import { useState, useRef, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';
import {
  alexTopicResponses,
  alexKeywordMatches,
  alexGreetingButtons,
  type AlexTopicResponse,
} from '@/mocks/alexKnowledgeBase';

interface ChatMessage {
  id: number;
  sender: 'bot' | 'user';
  text: string;
  actions?: ChatAction[];
  delay?: boolean;
  aiPowered?: boolean;
}

interface ChatAction {
  label: string;
  type: 'link' | 'phone' | 'input' | 'form' | 'topic';
  href?: string;
  phone?: string;
  topicId?: string;
}

function buildInitialMessage(): ChatMessage {
  return {
    id: 1,
    sender: 'bot',
    text: "Hi there! I am Alex from Corner Stone Roofing. I can answer questions about pricing, materials, insurance, timelines, and more — what brings you here today?",
    actions: alexGreetingButtons.map((btn) => {
      if (btn.input) {
        return { label: btn.label, type: 'input' };
      }
      if (btn.phone) {
        return { label: btn.label, type: 'phone', phone: btn.phone };
      }
      if (btn.topicId) {
        return { label: btn.label, type: 'topic', topicId: btn.topicId };
      }
      return { label: btn.label, type: 'link', href: btn.href };
    }),
  };
}

function topicToChatMessage(topic: AlexTopicResponse): ChatMessage {
  return {
    id: 999,
    sender: 'bot',
    text: topic.text,
    actions: topic.actions?.map((a) => {
      if (a.type === 'link' && a.href) {
        return { label: a.label, type: 'link', href: a.href };
      }
      if (a.type === 'phone' && a.phone) {
        return { label: a.label, type: 'phone', phone: a.phone };
      }
      if (a.type === 'form') {
        return { label: a.label, type: 'form' };
      }
      return { label: a.label, type: 'input' };
    }),
  };
}

function findKeywordResponse(text: string): AlexTopicResponse | null {
  const lower = text.toLowerCase();
  for (const match of alexKeywordMatches) {
    if (match.keywords.some((kw) => lower.includes(kw.toLowerCase()))) {
      return match.response;
    }
  }
  return null;
}

function generateSessionId(): string {
  return `alex_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

function getOrCreateSessionId(): string {
  const stored = localStorage.getItem('alex_session_id');
  if (stored) return stored;
  const newId = generateSessionId();
  localStorage.setItem('alex_session_id', newId);
  return newId;
}

const EDGE_FUNCTION_URL = `${import.meta.env.VITE_PUBLIC_SUPABASE_URL}/functions/v1/alex-ai`;

export default function LiveChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [typing, setTyping] = useState(false);
  const [showInput, setShowInput] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [hasInteracted, setHasInteracted] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [showCallbackForm, setShowCallbackForm] = useState(false);
  const [pendingTopic, setPendingTopic] = useState<string | null>(null);
  const [sessionId] = useState(() => getOrCreateSessionId());
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const idCounter = useRef(2);

  // Listen for external open-chat event
  useEffect(() => {
    const handleOpenChat = () => {
      setIsOpen(true);
    };
    window.addEventListener('open-chat', handleOpenChat);
    return () => window.removeEventListener('open-chat', handleOpenChat);
  }, []);

  // Listen for ask-alex topic event from TalkToAIExpert pills
  useEffect(() => {
    const handleAskAlex = (e: Event) => {
      const customEvent = e as CustomEvent<{ topicId: string }>;
      const topicId = customEvent.detail?.topicId;
      if (!topicId) return;
      setPendingTopic(topicId);
      setIsOpen(true);
    };
    window.addEventListener('ask-alex', handleAskAlex);
    return () => window.removeEventListener('ask-alex', handleAskAlex);
  }, []);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  // Typing indicator helper
  const simulateTyping = useCallback((duration = 800) => {
    setTyping(true);
    return new Promise<void>((resolve) => {
      setTimeout(() => {
        setTyping(false);
        resolve();
      }, duration);
    });
  }, []);

  // Open chat and show greeting after short delay
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setTyping(true);
      const timer = setTimeout(() => {
        setTyping(false);
        setMessages([buildInitialMessage()]);
      }, 900);
      return () => clearTimeout(timer);
    }
  }, [isOpen, messages.length]);

  // Handle pending topic from external ask-alex event
  useEffect(() => {
    if (!pendingTopic || !isOpen || messages.length === 0) return;

    const processPending = async () => {
      const topic = alexTopicResponses[pendingTopic];
      if (!topic) {
        setPendingTopic(null);
        return;
      }

      // Add user message showing what they asked
      const userMsg: ChatMessage = {
        id: idCounter.current++,
        sender: 'user',
        text: topic.label,
      };
      setMessages((prev) => [...prev, userMsg]);

      await simulateTyping(700);

      setMessages((prev) => [
        ...prev,
        { ...topicToChatMessage(topic), id: idCounter.current++ },
      ]);
      setPendingTopic(null);
    };

    processPending();
  }, [pendingTopic, isOpen, messages.length, simulateTyping]);

  // Keyboard shortcut: press 'C' to toggle chat
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'c' || e.key === 'C') {
        if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
        setIsOpen((prev) => !prev);
      }
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  const handleAction = async (action: ChatAction) => {
    setHasInteracted(true);
    setShowInput(false);
    setShowCallbackForm(false);

    if (action.type === 'input') {
      setShowInput(true);
      setTimeout(() => inputRef.current?.focus(), 100);
      return;
    }

    if (action.type === 'form') {
      setShowCallbackForm(true);
      setTimeout(() => scrollToBottom(), 50);
      return;
    }

    if (action.type === 'topic' && action.topicId) {
      const userMsg: ChatMessage = {
        id: idCounter.current++,
        sender: 'user',
        text: action.label,
      };
      setMessages((prev) => [...prev, userMsg]);

      await simulateTyping(600);

      const topic = alexTopicResponses[action.topicId];
      if (topic) {
        setMessages((prev) => [
          ...prev,
          { ...topicToChatMessage(topic), id: idCounter.current++ },
        ]);
      }
      return;
    }

    if (action.type === 'link' && action.href) {
      const userMsg: ChatMessage = {
        id: idCounter.current++,
        sender: 'user',
        text: action.label,
      };
      setMessages((prev) => [...prev, userMsg]);

      await simulateTyping(600);

      const response = alexTopicResponses[action.href];
      if (response) {
        setMessages((prev) => [
          ...prev,
          { ...topicToChatMessage(response), id: idCounter.current++ },
        ]);
      } else {
        handleNavigate(action.href);
      }
    }

    if (action.type === 'phone' && action.phone) {
      const userMsg: ChatMessage = {
        id: idCounter.current++,
        sender: 'user',
        text: action.label,
      };
      setMessages((prev) => [...prev, userMsg]);

      await simulateTyping(600);

      const response = alexTopicResponses['tel:8122135997'];
      if (response) {
        setMessages((prev) => [
          ...prev,
          { ...topicToChatMessage(response), id: idCounter.current++ },
        ]);
      }
    }
  };

  const handleUserMessageSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const text = inputValue.trim();
    if (!text) return;

    setHasInteracted(true);
    const userMsg: ChatMessage = {
      id: idCounter.current++,
      sender: 'user',
      text,
    };
    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');
    setShowInput(false);

    await simulateTyping(1200);

    // Option 2: Keyword matching for intelligent free-form responses
    const keywordMatch = findKeywordResponse(text);
    if (keywordMatch) {
      setMessages((prev) => [
        ...prev,
        { ...topicToChatMessage(keywordMatch), id: idCounter.current++ },
      ]);
      return;
    }

    // Option 3: AI fallback via Supabase Edge Function
    try {
      const res = await fetch(EDGE_FUNCTION_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({ message: text, sessionId }),
      });

      if (res.ok) {
        const data = await res.json();
        const aiReply: ChatMessage = {
          id: idCounter.current++,
          sender: 'bot',
          text: data.response,
          aiPowered: data.aiPowered,
          actions: [
            { label: 'Free Inspection', type: 'link', href: '/free-inspection' },
            { label: 'Get Estimate', type: 'link', href: '/estimate' },
            { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
          ],
        };
        setMessages((prev) => [...prev, aiReply]);
        return;
      }
    } catch {
      // Silent fail — fall through to human handoff
    }

    // Fallback for unrecognized questions
    const botReply: ChatMessage = {
      id: idCounter.current++,
      sender: 'bot',
      text: "That is a great question! I want to make sure you get the most accurate answer. A member of our roofing team will personally review your message and get back to you within 1 business hour. If it is urgent, feel free to call us directly at (812) 213-5997.",
      actions: [
        { label: 'Call Now', type: 'phone', phone: 'tel:8122135997' },
        { label: 'Free Inspection', type: 'link', href: '/free-inspection' },
        { label: 'Get Estimate', type: 'link', href: '/estimate' },
      ],
    };
    setMessages((prev) => [...prev, botReply]);
  };

  const handleCallbackSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const _fd = new FormData(form);
    _fd.append('access_key', WEB3FORMS_ACCESS_KEY);
    const data = new URLSearchParams(_fd as unknown as Record<string, string>);
    try {
      await fetch(WEB3FORMS_ENDPOINT, { method: 'POST', body: data });
    } catch {
      // silent
    }
    setSubmitted(true);
    setTimeout(() => {
      setShowCallbackForm(false);
      setSubmitted(false);
      const botReply: ChatMessage = {
        id: idCounter.current++,
        sender: 'bot',
        text: "Your callback request has been sent! We will call you from (812) 213-5997 within the hour during business hours.",
        actions: [
          { label: 'Free Inspection', type: 'link', href: '/free-inspection' },
          { label: 'Talk to a Human', type: 'phone', phone: 'tel:8122135997' },
        ],
      };
      setMessages((prev) => [...prev, botReply]);
    }, 1500);
  };

  const handleNavigate = (href: string) => {
    setIsOpen(false);
    navigate(href);
  };

  return (
    <>
      {/* Chat window */}
      <div
        className={`fixed bottom-20 left-4 md:bottom-24 md:left-8 z-50 transition-all duration-500 ${
          isOpen ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 translate-y-6 pointer-events-none'
        }`}
        style={{ width: 'min(380px, calc(100vw - 2rem))' }}
      >
        <div className="bg-charcoal-deep border border-white/10 overflow-hidden flex flex-col shadow-2xl" style={{ maxHeight: '560px' }}>
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3.5 border-b border-white/10 bg-charcoal">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-9 h-9 flex items-center justify-center bg-orange text-white rounded">
                  <i className="ri-message-3-line text-lg" />
                </div>
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-400 border-2 border-charcoal-deep rounded-full" />
              </div>
              <div>
                <p className="text-white text-sm font-semibold leading-tight">Corner Stone Team</p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-green-400 text-xs">Online now</span>
                </div>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="w-8 h-8 flex items-center justify-center text-white/30 hover:text-white transition-colors cursor-pointer"
              aria-label="Close chat"
            >
              <i className="ri-close-line text-lg" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4" style={{ maxHeight: '400px' }}>
            {messages.map((msg) => (
              <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[90%] ${msg.sender === 'user' ? 'bg-orange/20 border border-orange/20' : 'bg-charcoal border border-white/5'} px-3.5 py-2.5`}>
                  {msg.sender === 'bot' && (
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-orange text-xs font-semibold uppercase tracking-wider">Alex</p>
                      {msg.aiPowered && (
                        <span className="text-[10px] text-white/30 bg-white/5 px-1.5 py-0.5 rounded whitespace-nowrap">
                          AI powered
                        </span>
                      )}
                    </div>
                  )}
                  <p className={`text-sm leading-relaxed ${msg.sender === 'user' ? 'text-white' : 'text-white/80'}`}>
                    {msg.text}
                  </p>
                  {msg.actions && (
                    <div className="flex flex-wrap gap-2 mt-3">
                      {msg.actions.map((action, idx) => (
                        <button
                          key={idx}
                          onClick={() => {
                            if (action.type === 'link' && action.href) {
                              handleAction(action);
                            } else if (action.type === 'phone' && action.phone) {
                              handleAction(action);
                            } else if (action.type === 'topic' && action.topicId) {
                              handleAction(action);
                            } else {
                              handleAction(action);
                            }
                          }}
                          className="text-xs font-medium px-3 py-1.5 border border-white/10 hover:border-orange/50 hover:text-orange text-white/60 transition-all duration-200 whitespace-nowrap cursor-pointer"
                        >
                          {action.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {/* Typing indicator */}
            {typing && (
              <div className="flex justify-start">
                <div className="bg-charcoal border border-white/5 px-3.5 py-2.5">
                  <p className="text-orange text-xs font-semibold uppercase tracking-wider mb-1">Alex</p>
                  <div className="flex items-center gap-1 h-5">
                    <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-white/40 animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}

            {/* Text input form */}
            {showInput && !typing && (
              <div className="flex justify-end">
                <form onSubmit={handleUserMessageSubmit} className="w-full max-w-[90%]">
                  <div className="flex gap-2">
                    <input
                      ref={inputRef}
                      type="text"
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      placeholder="Type your question..."
                      maxLength={500}
                      className="flex-1 bg-charcoal border border-white/10 focus:border-orange/50 text-white text-sm px-3 py-2.5 outline-none placeholder:text-white/40 transition-colors"
                    />
                    <button
                      type="submit"
                      disabled={!inputValue.trim()}
                      className="bg-orange hover:bg-orange-dark text-white px-3 py-2 transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
                    >
                      <i className="ri-send-plane-fill text-sm" />
                    </button>
                  </div>
                  <p className="text-white/20 text-xs mt-1.5">Max 500 characters</p>
                </form>
              </div>
            )}

            {/* Callback form */}
            {showCallbackForm && !typing && (
              <div className="flex justify-start">
                <div className="w-full max-w-[90%] bg-charcoal border border-white/10 px-4 py-4">
                  <p className="text-white/40 text-xs uppercase tracking-wider mb-3">Request a Callback</p>
                  {submitted ? (
                    <div className="text-center py-3">
                      <div className="w-10 h-10 flex items-center justify-center bg-orange/20 text-orange mx-auto mb-2">
                        <i className="ri-check-line text-xl" />
                      </div>
                      <p className="text-white text-sm font-semibold">Sent! We will call you soon.</p>
                    </div>
                  ) : (
                    <form data-readdy-form onSubmit={handleCallbackSubmit} className="space-y-2.5">
                      <input
                        type="text"
                        name="name"
                        required
                        placeholder="Your name"
                        className="w-full bg-charcoal-deep border border-white/10 focus:border-orange/50 text-white text-sm px-3 py-2 outline-none placeholder:text-white/40 transition-colors"
                      />
                      <input
                        type="tel"
                        name="phone"
                        required
                        placeholder="Phone number"
                        className="w-full bg-charcoal-deep border border-white/10 focus:border-orange/50 text-white text-sm px-3 py-2 outline-none placeholder:text-white/40 transition-colors"
                      />
                      <select
                        name="best_time"
                        className="w-full bg-charcoal-deep border border-white/10 focus:border-orange/50 text-white text-sm px-3 py-2 outline-none transition-colors cursor-pointer appearance-none"
                      >
                        <option value="ASAP">As soon as possible</option>
                        <option value="Morning">Morning (8am–12pm)</option>
                        <option value="Afternoon">Afternoon (12pm–5pm)</option>
                        <option value="Evening">Evening (5pm–7pm)</option>
                      </select>
                      <button
                        type="submit"
                        className="w-full bg-orange hover:bg-orange-dark text-white text-xs font-semibold py-2.5 uppercase tracking-widest transition-colors cursor-pointer"
                      >
                        Request Callback
                      </button>
                    </form>
                  )}
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Footer */}
          <div className="px-4 py-2.5 border-t border-white/10 bg-charcoal flex items-center justify-between">
            <p className="text-white/20 text-xs">Press C to toggle · Esc to close</p>
            <div className="flex items-center gap-3">
              <button
                onClick={() => handleNavigate('/free-inspection')}
                className="text-xs text-orange hover:text-orange-dark transition-colors cursor-pointer whitespace-nowrap"
              >
                Book Inspection
              </button>
              <a
                href="tel:8122135997"
                className="text-xs text-orange hover:text-orange-dark transition-colors cursor-pointer whitespace-nowrap"
              >
                Call
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Floating trigger button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-4 left-4 md:bottom-6 md:left-8 z-50 group transition-all duration-500 ${
          isOpen ? 'opacity-0 pointer-events-none scale-90' : 'opacity-100 pointer-events-auto scale-100'
        }`}
        aria-label="Open chat"
      >
        <div className="relative">
          <div className="w-14 h-14 flex items-center justify-center bg-orange hover:bg-orange-dark text-white transition-colors duration-300 cursor-pointer shadow-lg">
            <i className="ri-message-3-line text-2xl" />
          </div>
          {!hasInteracted && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-charcoal-deep animate-pulse" />
          )}
          {/* Tooltip on hover */}
          <div className="absolute left-full ml-3 top-1/2 -translate-y-1/2 bg-charcoal-deep border border-white/10 px-3 py-2 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
            <p className="text-white text-xs font-medium">Chat with us</p>
            <div className="absolute left-0 top-1/2 -translate-x-full -translate-y-1/2 w-0 h-0 border-t-4 border-b-4 border-r-4 border-t-transparent border-b-transparent border-r-white/10" />
          </div>
        </div>
      </button>
    </>
  );
}