export default function MetalRoofingSection() {
  const metalStyles = [
    {
      name: 'Standing Seam',
      price: '$10-14/sq ft',
      lifespan: '40-70 years',
      description: 'The premium choice for modern and traditional homes. Concealed fasteners create clean vertical lines. Best water shedding for Indiana rain and snow.',
    },
    {
      name: 'Metal Shingles',
      price: '$8-12/sq ft',
      lifespan: '30-50 years',
      description: 'Mimics the look of slate, tile, or wood shakes but with metal durability. Interlocking design resists wind uplift up to 140 mph.',
    },
    {
      name: 'Corrugated Metal',
      price: '$6-9/sq ft',
      lifespan: '30-40 years',
      description: 'Classic wavy profile, often used for barns, sheds, and rustic homes. Exposed fasteners make it the most affordable metal option.',
    },
  ];

  const benefits = [
    'Lasts 2-3x longer than asphalt — up to 70 years',
    'Reflects heat, reducing cooling costs by 10-25%',
    'Withstands Indiana hail, wind, and fire (Class A rating)',
    '100% recyclable — the eco-friendly roofing choice',
    'Lightweight — no need to reinforce roof structure',
    'Increases home resale value by up to 6%',
  ];

  return (
    <section id="metal-roofing" className="bg-charcoal py-20 md:py-28 lg:py-32">
      <div className="w-full px-4 md:px-8 lg:px-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 md:mb-20">
          <p className="text-orange text-xs md:text-sm font-semibold tracking-[0.2em] uppercase mb-4">
            Premium Investment
          </p>
          <h2 className="font-display font-bold text-white text-3xl md:text-4xl lg:text-5xl mb-5">
            Metal Roofing in Evansville
          </h2>
          <p className="text-white/60 text-base md:text-lg leading-relaxed">
            Metal roofing is the smart long-term investment for Evansville homeowners. Unmatched durability, energy savings, and a lifespan that can outlast your mortgage.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row-reverse gap-12 lg:gap-16 items-start">
          {/* Right: Image + Benefits */}
          <div className="w-full lg:w-[50%]">
            <div className="relative rounded-3xl overflow-hidden mb-8">
              <img
                src="/placeholders/700x500.svg"
                alt="Metal roof on Evansville home"
                className="w-full h-72 md:h-80 object-cover"
              />
            </div>

            <h3 className="font-display font-bold text-white text-xl md:text-2xl mb-5">
              Why Metal Roofing Pays Off
            </h3>
            <ul className="space-y-3">
              {benefits.map((benefit, i) => (
                <li key={i} className="flex items-start gap-3">
                  <div className="w-6 h-6 flex-shrink-0 flex items-center justify-center bg-orange/20 rounded-full mt-0.5">
                    <i className="ri-check-line text-orange text-sm" />
                  </div>
                  <span className="text-white/70 text-sm md:text-base">{benefit}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Left: Metal Styles */}
          <div className="w-full lg:w-[50%]">
            <h3 className="font-display font-bold text-white text-xl md:text-2xl mb-6">
              Metal Roofing Styles & Pricing
            </h3>
            <div className="space-y-4">
              {metalStyles.map((style) => (
                <div
                  key={style.name}
                  className="border border-white/15 rounded-2xl p-5 md:p-6 hover:border-orange/40 transition-colors"
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-display font-bold text-white text-lg">
                      {style.name}
                    </h4>
                    <span className="bg-orange/20 text-orange font-semibold text-sm px-3 py-1 rounded-full">
                      {style.price}
                    </span>
                  </div>
                  <p className="text-white/60 text-sm mb-2">{style.description}</p>
                  <p className="text-white/40 text-xs">
                    <i className="ri-time-line mr-1" />
                    Expected lifespan: {style.lifespan}
                  </p>
                </div>
              ))}
            </div>

            {/* Cost estimate box */}
            <div className="mt-6 bg-white/5 rounded-2xl p-5 md:p-6 border border-white/10">
              <h4 className="font-display font-bold text-white text-lg mb-2">
                Average Cost for Evansville Homes
              </h4>
              <p className="text-white/60 text-sm leading-relaxed mb-3">
                A typical 2,000 sq ft Evansville home costs <strong className="text-white">$16,000 - $28,000</strong> for a complete metal roof replacement. While the upfront cost is higher, metal roofs last 40-70 years vs. 20-30 for asphalt — making them the cheaper option over time.
              </p>
              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="inline-flex items-center gap-2 text-orange font-semibold text-sm hover:text-orange-light transition-colors cursor-pointer"
              >
                Get Your Free Metal Roof Estimate
                <i className="ri-arrow-right-line" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}