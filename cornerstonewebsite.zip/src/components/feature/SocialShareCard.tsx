import { useState, useRef, useCallback } from 'react';

export interface SocialShareCardProps {
  title: string;
  subtitle?: string;
  type?: string;
  location?: string;
  year?: string | number;
  image: string;
  badge?: string;
  stats: { label: string; value: string; icon?: string }[];
  highlights?: string[];
  description?: string;
  shareText?: string;
  onClose: () => void;
}

export default function SocialShareCard({
  title,
  subtitle,
  type,
  location,
  year,
  image,
  badge,
  stats,
  highlights,
  description,
  shareText: customShareText,
  onClose,
}: SocialShareCardProps) {
  const [copied, setCopied] = useState(false);
  const [flashCopied, setFlashCopied] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const defaultShareText = `${title}${type ? ` — ${type}` : ''}${location ? ` in ${location}` : ''} by Corner Stone Construction & Roofing.${description ? ` ${description.slice(0, 120)}${description.length > 120 ? '...' : ''}` : ''} Book your free inspection at cornerstoneconstructionevansville.com or call 812-213-5997.`;
  const shareText = customShareText || defaultShareText;

  const handleCopyText = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(shareText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* ignore */ }
  }, [shareText]);

  const handleNativeShare = useCallback(async () => {
    if (!navigator.share) return;
    try {
      await navigator.share({
        title: `${title} — Corner Stone Construction & Roofing`,
        text: shareText,
        url: window.location.href,
      });
    } catch { /* ignore */ }
  }, [title, shareText]);

  const handleScreenshotFlash = useCallback(() => {
    setFlashCopied(true);
    setTimeout(() => setFlashCopied(false), 3000);
  }, []);

  const handlePrint = useCallback(() => {
    document.body.classList.add('share-card-printing');
    setTimeout(() => {
      window.print();
      setTimeout(() => document.body.classList.remove('share-card-printing'), 500);
    }, 100);
  }, []);

  return (
    <div
      className="fixed inset-0 z-[110] flex items-center justify-center p-4 md:p-8 share-card-modal"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/90 backdrop-blur-sm print:bg-white print:backdrop-blur-none"
        onClick={onClose}
      />

      {/* Modal wrapper */}
      <div className="relative z-10 w-full max-w-lg max-h-[92vh] overflow-y-auto print:max-w-none print:max-h-none print:overflow-visible">
        {/* Top actions */}
        <div className="flex items-center justify-between mb-4 print-hide">
          <h3 className="font-display text-white text-sm uppercase tracking-wider">
            Share This Project
          </h3>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-white/60 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-file-download-line text-sm" />
              Save as PDF
            </button>
            <button
              onClick={handleCopyText}
              className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-white/60 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className={`ri-${copied ? 'checkbox-circle' : 'clipboard'} text-sm`} />
              {copied ? 'Copied' : 'Copy Text'}
            </button>
            {typeof navigator !== 'undefined' && (navigator as unknown as { share?: unknown }).share && (
              <button
                onClick={handleNativeShare}
                className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-white/60 hover:text-white transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-share-forward-line text-sm" />
                Share
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center bg-white/10 hover:bg-orange text-white transition-colors cursor-pointer ml-2"
            >
              <i className="ri-close-line text-lg" />
            </button>
          </div>
        </div>

        {/* Screenshot flash message */}
        {flashCopied && (
          <div className="mb-4 bg-orange/20 border border-orange rounded-lg px-4 py-3 flex items-center gap-2 print-hide">
            <i className="ri-camera-line text-orange" />
            <span className="text-white text-sm font-semibold">Screenshot this card and share it to your feed!</span>
          </div>
        )}

        {/* ── THE SHAREABLE CARD ── */}
        <div
          ref={cardRef}
          className="bg-white overflow-hidden shadow-2xl print:shadow-none print:rounded-none"
        >
          {/* Card Header with brand */}
          <div className="bg-charcoal-deep px-6 py-5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 flex items-center justify-center bg-white rounded-lg shrink-0">
                <img
                  src="/logo.svg"
                  alt="Corner Stone"
                  className="h-7 w-7 object-contain rounded"
                />
              </div>
              <div>
                <p className="font-display text-white text-sm uppercase tracking-wider leading-tight">
                  Corner Stone
                </p>
                <p className="text-white/40 text-[10px] uppercase tracking-widest">
                  Construction & Roofing
                </p>
              </div>
            </div>
            <div className="text-right">
              {badge && (
                <p className="text-orange text-[10px] uppercase tracking-widest font-semibold">
                  {badge}
                </p>
              )}
              {location && (
                <p className="text-white/30 text-[10px] uppercase tracking-widest">
                  {location}
                </p>
              )}
            </div>
          </div>

          {/* Project Hero Image */}
          <div className="relative w-full h-56 md:h-64">
            <img
              src={image}
              alt={title}
              className="w-full h-full object-cover object-top"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className="absolute bottom-4 left-6 right-6">
              {type && (
                <p className="text-orange text-[10px] uppercase tracking-[0.25em] font-semibold mb-1">
                  {type}
                </p>
              )}
              <h2 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider leading-tight">
                {title}
              </h2>
              {subtitle && (
                <p className="text-white/70 text-xs mt-0.5">
                  {subtitle}
                </p>
              )}
              {year && (
                <p className="text-white/50 text-[10px] mt-1 uppercase tracking-wider">{year}</p>
              )}
            </div>
          </div>

          {/* Stats Bar */}
          <div className="grid grid-cols-3 border-b border-gray-100">
            {stats.slice(0, 3).map((stat) => (
              <div key={stat.label} className="px-4 py-4 text-center border-r border-gray-100 last:border-r-0">
                {stat.icon && (
                  <i className={`${stat.icon} text-orange text-sm mb-1 block`} />
                )}
                <p className="text-charcoal-deep text-sm font-semibold leading-tight">
                  {stat.value}
                </p>
                <p className="text-gray-400 text-[10px] uppercase tracking-wider mt-0.5">
                  {stat.label}
                </p>
              </div>
            ))}
          </div>

          {/* Highlights */}
          {highlights && highlights.length > 0 && (
            <div className="px-6 py-5 border-b border-gray-100">
              <p className="text-orange text-[10px] uppercase tracking-[0.25em] font-semibold mb-3">
                Project Highlights
              </p>
              <ul className="space-y-2">
                {highlights.slice(0, 4).map((h) => (
                  <li key={h} className="flex items-start gap-2 text-gray-600 text-xs leading-relaxed">
                    <i className="ri-checkbox-circle-fill text-orange text-xs mt-0.5 shrink-0" />
                    {h}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Description snippet */}
          {description && (
            <div className="px-6 py-5 border-b border-gray-100">
              <p className="text-gray-500 text-xs leading-relaxed line-clamp-3">
                {description}
              </p>
            </div>
          )}

          {/* CTA Bar */}
          <div className="px-6 py-5 flex items-center justify-between bg-gray-50">
            <div>
              <p className="text-gray-400 text-[10px] uppercase tracking-widest mb-0.5">
                Free Estimate
              </p>
              <p className="font-display text-charcoal-deep text-lg uppercase tracking-wider">
                812-213-5997
              </p>
            </div>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((s) => (
                <i key={s} className="ri-star-fill text-orange text-xs" />
              ))}
              <span className="text-charcoal-deep text-xs font-semibold ml-1">4.9</span>
            </div>
          </div>

          {/* Footer Branding */}
          <div className="bg-charcoal-deep px-6 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 flex items-center justify-center bg-orange">
                <i className="ri-shield-check-line text-white text-[10px]" />
              </div>
              <p className="text-white/60 text-[10px] uppercase tracking-wider">
                Licensed & Insured — IN & KY
              </p>
            </div>
            <p className="text-white/30 text-[10px] uppercase tracking-wider">
              Evansville, Indiana
            </p>
          </div>
        </div>

        {/* Screenshot CTA */}
        <div className="mt-6 flex items-center justify-center print-hide">
          <button
            onClick={handleScreenshotFlash}
            className="flex items-center gap-2 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-xs transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-camera-line text-sm" />
            Tap to Screenshot This Card
          </button>
        </div>

        {/* Helper text */}
        <p className="text-center text-white/30 text-xs mt-3 print-hide">
          Screenshot the card above and post to Instagram, Facebook, or text it to a friend.
        </p>
      </div>
    </div>
  );
}