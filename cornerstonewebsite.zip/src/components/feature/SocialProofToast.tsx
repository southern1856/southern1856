import { useState, useEffect, useCallback } from 'react';

const notifications = [
  { name: 'Jennifer from Newburgh', action: 'booked a free inspection', time: '2 min ago' },
  { name: 'Michael from Evansville', action: 'got a $14,200 roof estimate', time: '4 min ago' },
  { name: 'Sarah from Henderson, KY', action: 'scheduled storm damage repair', time: '7 min ago' },
  { name: 'David from Boonville', action: 'filed an insurance claim with us', time: '9 min ago' },
  { name: 'The Wilsons', action: 'received their free roof report', time: '12 min ago' },
  { name: 'Angela from Mount Vernon', action: 'called 812-213-5997', time: '15 min ago' },
  { name: 'Tom from Owensboro, KY', action: 'got approved for $0-down financing', time: '18 min ago' },
  { name: 'Lisa from Princeton', action: 'booked a same-day inspection', time: '21 min ago' },
  { name: 'Mark from Evansville', action: 'signed up for maintenance plan', time: '25 min ago' },
  { name: 'The Henderson family', action: 'got a complete exterior package quote', time: '30 min ago' },
];

export default function SocialProofToast() {
  const [active, setActive] = useState(false);
  const [current, setCurrent] = useState(0);
  const [hidden, setHidden] = useState(false);

  const showNext = useCallback(() => {
    setCurrent((prev) => (prev + 1) % notifications.length);
    setActive(true);
    setTimeout(() => setActive(false), 5500);
  }, []);

  useEffect(() => {
    if (hidden) return;
    // First show after 8 seconds
    const initial = setTimeout(showNext, 8000);
    // Cycle every 12 seconds
    const interval = setInterval(showNext, 12000);
    return () => {
      clearTimeout(initial);
      clearInterval(interval);
    };
  }, [hidden, showNext]);

  if (hidden) return null;

  const note = notifications[current];

  return (
    <div
      className={`fixed bottom-28 left-4 md:left-8 z-[60] max-w-sm transition-all duration-700 ease-out ${
        active ? 'translate-x-0 opacity-100' : '-translate-x-8 opacity-0 pointer-events-none'
      }`}
    >
      <div className="bg-charcoal-deep/95 backdrop-blur-md border border-white/10 p-4 pr-10 shadow-2xl">
        <button
          onClick={() => setHidden(true)}
          className="absolute top-2 right-2 w-6 h-6 flex items-center justify-center text-white/30 hover:text-white transition-colors cursor-pointer"
          aria-label="Dismiss"
        >
          <i className="ri-close-line text-sm" />
        </button>
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 flex items-center justify-center bg-orange/20 text-orange flex-shrink-0">
            <i className="ri-check-line text-sm" />
          </div>
          <div className="min-w-0">
            <p className="text-white text-sm font-medium leading-snug">
              {note.name} {note.action}
            </p>
            <p className="text-white/35 text-xs mt-1">{note.time}</p>
          </div>
        </div>
      </div>
    </div>
  );
}