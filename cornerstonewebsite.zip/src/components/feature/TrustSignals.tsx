import { useScrollAnimation } from '@/hooks/useScrollAnimation';

export default function TrustSignals() {
  const header = useScrollAnimation();
  const grid = useScrollAnimation({ threshold: 0.1 });

  const reasons = [
    {
      icon: 'ri-shield-check-line',
      title: 'No Worries, No What-Ifs.',
      desc: "We're fully licensed and insured — your home and peace of mind are always protected.",
      delay: '',
    },
    {
      icon: 'ri-award-line',
      title: 'Certified, Verified & Trusted.',
      desc: "A+ BBB rating, certified contractors, and 25+ years of proven results in Evansville.",
      delay: 'anim-delay-200',
    },
    {
      icon: 'ri-tools-line',
      title: 'Only the Good Stuff Up Top.',
      desc: 'We use top-tier materials that hold strong through Indiana storms, sun, and everything in between.',
      delay: 'anim-delay-400',
    },
    {
      icon: 'ri-price-tag-3-line',
      title: 'Fair Prices, No Funny Business.',
      desc: 'Honest quotes, no hidden fees, no pressure — great roofs at great value for Evansville families.',
      delay: 'anim-delay-600',
    },
  ];

  return (
    <section className="bg-charcoal-mid py-20 md:py-28 overflow-hidden">
      <div className="w-full px-6 md:px-10 lg:px-16">
        <div
          ref={header.ref as React.RefObject<HTMLDivElement>}
          className={`text-center mb-14 md:mb-20 anim-fade-up ${header.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Why Choose Us</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
            Because Your Roof Deserves<br />Better Than "Good Enough"
          </h2>
        </div>

        <div
          ref={grid.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-white/10"
        >
          {reasons.map((r) => (
            <div
              key={r.title}
              className={`bg-charcoal-mid p-8 md:p-10 group hover:bg-charcoal-light transition-colors duration-300 anim-fade-up ${r.delay} ${grid.isVisible ? 'is-visible' : ''}`}
            >
              <div className="w-12 h-12 flex items-center justify-center border border-orange/40 mb-6 group-hover:bg-orange group-hover:border-orange transition-all duration-300">
                <i className={`${r.icon} text-orange group-hover:text-white text-xl transition-colors duration-300`} />
              </div>
              <h3 className="font-serif font-bold text-white text-lg md:text-xl mb-3 leading-snug">{r.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{r.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}