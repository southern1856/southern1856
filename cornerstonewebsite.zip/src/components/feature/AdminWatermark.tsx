export default function AdminWatermark() {
  return (
    <div
      className="fixed bottom-4 right-4 z-[5] pointer-events-none opacity-[0.06]"
      aria-hidden="true"
    >
      <div className="flex flex-col items-center gap-2">
        <img
          src="/logo.svg"
          alt=""
          className="w-24 h-24 md:w-32 md:h-32 object-contain rounded-xl grayscale"
        />
        <span className="font-display text-charcoal-deep text-sm md:text-base tracking-[0.2em] uppercase whitespace-nowrap">
          Corner Stone
        </span>
      </div>
    </div>
  );
}