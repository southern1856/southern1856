import { useState, useEffect } from 'react';

const MANUFACTURERS = [
  {
    name: 'GAF',
    badge: 'Master Elite',
    warranty: 'Golden Pledge® 50 Years',
    icon: 'ri-award-line',
    color: 'text-amber-300',
  },
  {
    name: 'Owens Corning',
    badge: 'Platinum Preferred',
    warranty: 'System Protection®',
    icon: 'ri-medal-line',
    color: 'text-orange',
  },
  {
    name: 'CertainTeed',
    badge: 'SELECT ShingleMaster',
    warranty: 'SureStart™ PLUS',
    icon: 'ri-shield-star-line',
    color: 'text-green-400',
  },
  {
    name: 'Atlas Roofing',
    badge: 'Signature Select',
    warranty: 'Pinnacle Pristine™',
    icon: 'ri-verified-badge-line',
    color: 'text-amber-400',
  },
];

export default function ManufacturerCertBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPercent = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
      setVisible(scrollPercent > 15 && scrollPercent < 85);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!visible) return null;

  return (
    <div className="fixed top-[50%] -translate-y-1/2 left-0 z-[54] hidden xl:block">
      <div className="bg-charcoal-deep/90 backdrop-blur border border-white/8 border-l-0 p-4 w-48 shadow-2xl">
        <p className="text-white/40 text-[9px] uppercase tracking-widest mb-3 text-center">Certified Installer For</p>
        <div className="space-y-3">
          {MANUFACTURERS.map((m) => (
            <div key={m.name} className="group">
              <div className="flex items-center gap-2 mb-0.5">
                <i className={`${m.icon} ${m.color} text-xs`} />
                <span className="text-white/70 text-[11px] font-semibold uppercase tracking-wider">{m.name}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-white/40 text-[9px] uppercase tracking-wider">{m.badge}</span>
                <span className="text-white/20 text-[8px]">{m.warranty}</span>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-3 pt-3 border-t border-white/5">
          <p className="text-orange text-[9px] uppercase tracking-widest text-center">Better warranties unlocked</p>
        </div>
      </div>
    </div>
  );
}