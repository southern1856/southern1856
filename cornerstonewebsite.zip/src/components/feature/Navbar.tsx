import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import EmergencyTopBanner from './EmergencyTopBanner';
import CallbackWidget from './CallbackWidget';

const navLinks = [
  { label: 'Services', href: '/services', isPage: true },
  { label: 'Residential', href: '/residential-roofing', isPage: true },
  { label: 'Commercial', href: '/commercial-roofing', isPage: true },
  { label: 'Roof Repair', href: '/roof-repair', isPage: true },
  { label: 'Gutters', href: '/gutters-downspouts', isPage: true },
  { label: 'Siding', href: '/siding-exterior', isPage: true },
  { label: 'Ext. Package', href: '/exterior-package', isPage: true },
  { label: 'Before & After', href: '/before-after', isPage: true },
  { label: 'Service Areas', href: '/service-areas', isPage: true },
  { label: 'Projects', href: '/projects', isPage: true },
  { label: 'Case Studies', href: '/case-studies', isPage: true },
  { label: 'About', href: '/about', isPage: true },
  { label: 'Reviews', href: '/testimonials', isPage: true },
  { label: 'My Projects', href: '/customer-portal', isPage: true },
  { label: 'Financing', href: '/roof-financing', isPage: true },
  { label: 'Blog', href: '/blog', isPage: true },
  { label: 'AI Inspector', href: '/ai-inspector', isPage: true },
  { label: 'Tools', href: '/tools', isPage: true },
  { label: 'Storm Damage', href: '/storm-damage', isPage: true },
  { label: 'Emergency', href: '/emergency-services', isPage: true },
  { label: 'Free Inspection', href: '/free-inspection', isPage: true },
  { label: 'Deals', href: '/promotions', isPage: true },
  { label: 'Cost Guide', href: '/roof-cost-guide', isPage: true },
  { label: 'Roof Estimator', href: '/roof-estimator', isPage: true },
  { label: 'Compare Materials', href: '/roof-comparison', isPage: true },
  { label: 'Compare Quotes', href: '/quote-comparison', isPage: true },
  { label: 'Scheduler', href: '/instant-scheduler', isPage: true },
  { label: 'Financing Calc', href: '/financing-calculator', isPage: true },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [showCallback, setShowCallback] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === '/';

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string, isPage?: boolean) => {
    e.preventDefault();
    setMobileOpen(false);
    if (isPage) {
      navigate(href);
      return;
    }
    if (!isHome) {
      navigate('/' + href);
      return;
    }
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleLogoClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    setMobileOpen(false);
    if (!isHome) {
      navigate('/');
      return;
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-400 ${scrolled ? 'bg-charcoal-deep border-b border-white/10' : 'bg-transparent'}`}>
      {/* Skip link for keyboard navigation */}
      <a href="#main-content" className="skip-link">Skip to main content</a>

      {/* Emergency banner - stacked inside nav when at top */}
      <EmergencyTopBanner />

      <div className="w-full px-6 md:px-10 lg:px-16">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <a href="/" onClick={handleLogoClick} className="flex items-center gap-3.5 cursor-pointer group">
            <div className="relative flex items-center justify-center h-14 w-14 bg-white rounded-lg shadow-sm">
              <img
                src="/logo.svg"
                alt="Corner Stone Construction & Roofing"
                className="h-12 w-12 object-contain rounded-md"
              />
            </div>
            <div className="flex flex-col leading-none">
              <span className="font-display text-white text-2xl md:text-[1.65rem] tracking-wider uppercase">
                Corner Stone
              </span>
              <span className="hidden md:block text-white/40 text-[0.65rem] tracking-[0.25em] uppercase font-medium mt-0.5">
                Construction & Roofing
              </span>
            </div>
          </a>

          {/* Desktop Nav — compact on md-lg, full on xl+ */}
          <div className="hidden md:flex xl:hidden items-center gap-5">
            {[
              { label: 'Services', href: '/services', isPage: true },
              { label: 'Roof Repair', href: '/roof-repair', isPage: true },
              { label: 'Cost Guide', href: '/roof-cost-guide', isPage: true },
              { label: 'Tools', href: '/tools', isPage: true },
              { label: 'Compare', href: '/roof-comparison', isPage: true },
              { label: 'Case Studies', href: '/case-studies', isPage: true },
              { label: 'Projects', href: '/projects', isPage: true },
              { label: 'My Projects', href: '/customer-portal', isPage: true },
              { label: 'Reviews', href: '/testimonials', isPage: true },
              { label: 'Free Inspection', href: '/free-inspection', isPage: true },
            ].map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href, link.isPage)}
                className={`text-xs font-medium tracking-wide transition-colors duration-200 uppercase ${link.isPage && location.pathname === link.href ? 'text-orange' : 'text-white/60 hover:text-white'}`}
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="hidden xl:flex items-center gap-6">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href, link.isPage)}
                className={`text-sm font-medium tracking-wide transition-colors duration-200 uppercase ${link.isPage && location.pathname === link.href ? 'text-orange' : 'text-white/60 hover:text-white'}`}
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-3">
            <a
              href="/insurance-claims"
              onClick={(e) => { e.preventDefault(); navigate('/insurance-claims'); }}
              className={`text-sm font-medium tracking-wide transition-colors duration-200 uppercase ${location.pathname === '/insurance-claims' ? 'text-orange' : 'text-white/60 hover:text-white'}`}
            >
              Insurance Claims
            </a>
            {/* Contact pair — always visible */}
            <div className="flex items-center gap-2 bg-white/5 border border-white/10 px-3 py-1.5">
              <a
                href="mailto:themainstoneconstruction@gmail.com"
                className="flex items-center gap-1.5 text-white/80 hover:text-orange text-sm font-semibold transition-colors whitespace-nowrap"
                aria-label="Email Corner Stone Construction & Roofing"
              >
                <i className="ri-mail-line text-orange text-base" />
                <span className="hidden lg:inline">themainstoneconstruction@gmail.com</span>
              </a>
              <span className="hidden lg:block text-white/40 text-xs">|</span>
              <a
                href="tel:8122135997"
                className="flex items-center gap-1.5 text-white hover:text-orange text-sm font-bold transition-colors whitespace-nowrap cursor-pointer"
              >
                <i className="ri-phone-fill text-orange text-base" />
                <span>812-213-5997</span>
              </a>
            </div>
            <a
              href="/estimate"
              onClick={(e) => { e.preventDefault(); navigate('/estimate'); }}
              className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-5 py-2.5 transition-colors duration-200 whitespace-nowrap uppercase tracking-wide"
            >
              Free Estimate
            </a>
          </div>

          {/* Mobile Hamburger */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden w-10 h-10 flex items-center justify-center text-white focus-visible:ring-2 focus-visible:ring-orange focus-visible:ring-offset-2 focus-visible:ring-offset-charcoal-deep"
            aria-label="Toggle menu"
          >
            <i className={`ri-${mobileOpen ? 'close' : 'menu'}-line text-2xl`} />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`md:hidden bg-charcoal-deep border-t border-white/10 transition-all duration-300 overflow-hidden ${mobileOpen ? 'max-h-[48rem] opacity-100' : 'max-h-0 opacity-0'}`}>
        <div className="px-6 py-5 flex flex-col gap-4">
          {navLinks.slice(0, 11).map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => handleNavClick(e, link.href, link.isPage)}
              className={`text-base font-medium py-1 transition-colors uppercase tracking-wide ${link.isPage && location.pathname === link.href ? 'text-orange' : 'text-white/70 hover:text-white'}`}
            >
              {link.label}
            </a>
          ))}
          {/* CTA buttons */}
          <div className="flex flex-col gap-3 mt-2 pt-4 border-t border-white/10">
            <a
              href="/promotions"
              onClick={(e) => { e.preventDefault(); setMobileOpen(false); navigate('/promotions'); }}
              className="text-base font-medium py-1 transition-colors uppercase tracking-wide text-white/70 hover:text-white flex items-center gap-2"
            >
              <i className="ri-price-tag-3-line text-orange text-sm" />
              Deals &amp; Promotions
            </a>
            <a
              href="/customer-portal"
              onClick={(e) => { e.preventDefault(); setMobileOpen(false); navigate('/customer-portal'); }}
              className="text-base font-medium py-1 transition-colors uppercase tracking-wide text-white/70 hover:text-white flex items-center gap-2"
            >
              <i className="ri-user-line text-orange text-sm" />
              My Projects
            </a>
            <a
              href="/tools"
              onClick={(e) => { e.preventDefault(); setMobileOpen(false); navigate('/tools'); }}
              className="text-base font-medium py-1 transition-colors uppercase tracking-wide text-orange"
            >
              Tools & Calculators
            </a>
            <a
              href="/estimate"
              onClick={(e) => { e.preventDefault(); setMobileOpen(false); navigate('/estimate'); }}
              className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-5 py-3.5 transition-colors text-center uppercase tracking-widest whitespace-nowrap"
            >
              Free Estimate
            </a>
            <button
              onClick={() => setShowCallback(!showCallback)}
              className="flex items-center justify-center gap-2 border border-white/30 hover:border-orange text-white/80 hover:text-white text-sm font-semibold px-5 py-3.5 transition-colors uppercase tracking-widest whitespace-nowrap cursor-pointer"
            >
              <i className="ri-phone-fill text-orange text-sm" />
              Request a Callback
            </button>
            {/* Inline Callback Form */}
            {showCallback && (
              <CallbackWidget
                isOpen={showCallback}
                onClose={() => setShowCallback(false)}
                mode="inline"
              />
            )}
            <a
              href="tel:8122135997"
              className="flex items-center justify-center gap-2 text-white/50 hover:text-white text-sm transition-colors py-1"
            >
              <i className="ri-phone-line text-orange text-sm" />
              812-213-5997
            </a>
            <a
              href="mailto:themainstoneconstruction@gmail.com"
              className="flex items-center justify-center gap-2 text-white/50 hover:text-white text-sm transition-colors py-1"
            >
              <i className="ri-mail-line text-orange text-sm" />
              themainstoneconstruction@gmail.com
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
}