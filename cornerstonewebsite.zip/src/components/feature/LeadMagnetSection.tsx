import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const GUIDE_PERKS = [
  { icon: 'ri-file-list-3-line', text: 'Complete cost breakdown by material (asphalt, metal, tile, slate)' },
  { icon: 'ri-map-pin-line', text: 'Evansville-specific pricing vs. national averages' },
  { icon: 'ri-calculator-line', text: 'Square footage cost estimator with examples' },
  { icon: 'ri-shield-check-line', text: 'Hidden fees to watch for (permits, tear-off, disposal)' },
  { icon: 'ri-bank-card-line', text: 'Financing options explained for Indiana homeowners' },
  { icon: 'ri-timer-line', text: 'How to time your replacement for maximum savings' },
];

export default function LeadMagnetSection({ variant = 'inline' }: { variant?: 'inline' | 'dark' | 'light' }) {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const formRef = useRef<HTMLFormElement>(null);
  const navigate = useNavigate();
  const left = useScrollAnimation({ threshold: 0.1 });
  const right = useScrollAnimation({ threshold: 0.1 });

  const isDark = variant === 'dark';
  const isInline = variant === 'inline';
  const bgClass = isDark ? 'bg-charcoal-deep' : isInline ? 'bg-warm-beige' : 'bg-white';
  const textMain = isDark ? 'text-white' : 'text-charcoal';
  const textSub = isDark ? 'text-white/50' : 'text-charcoal/60';
  const textDim = isDark ? 'text-white/30' : 'text-charcoal/40';
  const borderClass = isDark ? 'border-white/10' : 'border-charcoal/10';
  const inputBg = isDark ? 'bg-white/5 text-white placeholder:text-white/30 border-white/10 focus:border-orange' : 'bg-white text-charcoal placeholder:text-gray-400 border-gray-200 focus:border-orange';
  const cardBg = isDark ? 'bg-white/5' : 'bg-white';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current || !name.trim() || !email.trim()) return;

    setStatus('submitting');
    try {
      const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
      const response = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      if (response.ok) {
        setStatus('success');
        setEmail('');
        setName('');
        formRef.current.reset();
        navigate('/guide-sent');
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    }
  };

  if (status === 'success') return null; // redirected to /guide-sent

  return (
    <section className={`${bgClass} py-16 md:py-20 lg:py-24`}>
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-start max-w-6xl mx-auto">
          {/* LEFT — The offer */}
          <div
            ref={left.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${left.isVisible ? 'is-visible' : ''}`}
          >
            {/* Tag */}
            <div className={`inline-flex items-center gap-2 ${isDark ? 'bg-orange/15 border-orange/30' : 'bg-orange/10 border-orange/20'} border px-4 py-2 mb-6`}>
              <i className="ri-file-download-line text-orange text-sm" />
              <span className="text-orange text-xs font-bold uppercase tracking-[0.2em]">Free PDF Download</span>
            </div>

            <h2 className={`font-display ${textMain} uppercase tracking-wider leading-none mb-5`} style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
              2026 Roof Replacement<br />
              <span className="text-orange">Cost Guide</span> for Evansville
            </h2>

            <p className={`${textSub} text-base md:text-lg leading-relaxed mb-8 max-w-md`}>
              Stop guessing what your new roof will cost. This 18-page guide breaks down real pricing for every material, every home size, and every situation — specifically for Evansville and the Tri-State area.
            </p>

            {/* What's inside list */}
            <div className="space-y-3 mb-8">
              {GUIDE_PERKS.map((perk, i) => (
                <div
                  key={perk.text}
                  className={`flex items-start gap-3 anim-fade-up ${left.isVisible ? 'is-visible' : ''}`}
                  style={{ transitionDelay: `${i * 60 + 150}ms` }}
                >
                  <div className={`w-8 h-8 flex-shrink-0 flex items-center justify-center ${isDark ? 'bg-orange/15' : 'bg-orange/10'} rounded-md mt-0.5`}>
                    <i className={`${perk.icon} text-orange text-sm`} />
                  </div>
                  <p className={`${textSub} text-sm leading-relaxed`}>{perk.text}</p>
                </div>
              ))}
            </div>

            {/* Trust micro-bar */}
            <div className={`flex flex-wrap items-center gap-4 pt-6 border-t ${borderClass}`}>
              <div className="flex items-center gap-2">
                <div className="flex">
                  {[1,2,3,4,5].map(i => <i key={i} className="ri-star-fill text-orange text-xs" />)}
                </div>
                <span className={`${textDim} text-xs`}>Trusted by 2,500+ homeowners</span>
              </div>
              <div className={`w-px h-4 ${isDark ? 'bg-white/10' : 'bg-charcoal/10'}`} />
              <span className={`${textDim} text-xs`}>No spam — unsubscribe anytime</span>
            </div>
          </div>

          {/* RIGHT — Form card */}
          <div
            ref={right.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${right.isVisible ? 'is-visible' : ''}`}
            style={{ transitionDelay: '150ms' }}
          >
            <div className={`${cardBg} border ${borderClass} rounded-2xl p-6 md:p-10`}>
              {/* PDF preview visual */}
              <div className="flex items-center gap-4 mb-6 pb-6 border-b border-dashed border-charcoal/10">
                <div className="w-14 h-16 flex-shrink-0 bg-orange/10 border border-orange/20 rounded flex flex-col items-center justify-center">
                  <i className="ri-file-pdf-2-line text-orange text-xl" />
                  <span className="text-orange/60 text-[10px] font-bold mt-0.5">PDF</span>
                </div>
                <div>
                  <p className={`${textMain} font-semibold text-sm`}>2026 Roof Replacement Cost Guide</p>
                  <p className={`${textDim} text-xs mt-0.5`}>18 pages · Evansville-specific pricing · Instant download</p>
                </div>
              </div>

              <p className={`${textMain} font-semibold text-base mb-4`}>
                Enter your info to get instant access:
              </p>

              <form
                ref={formRef}
                data-readdy-form
                onSubmit={handleSubmit}
                className="space-y-4"
              >
                <div>
                  <label htmlFor="guide-name" className={`block ${textMain} text-xs font-semibold uppercase tracking-wider mb-2`}>
                    Full Name
                  </label>
                  <input
                    type="text"
                    id="guide-name"
                    name="name"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="John Smith"
                    className={`w-full rounded-xl px-5 py-3.5 text-sm focus:outline-none border transition-colors ${inputBg}`}
                  />
                </div>

                <div>
                  <label htmlFor="guide-email" className={`block ${textMain} text-xs font-semibold uppercase tracking-wider mb-2`}>
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="guide-email"
                    name="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className={`w-full rounded-xl px-5 py-3.5 text-sm focus:outline-none border transition-colors ${inputBg}`}
                  />
                </div>

                <div>
                  <label htmlFor="guide-phone" className={`block ${textMain} text-xs font-semibold uppercase tracking-wider mb-2`}>
                    Phone <span className={`${textDim} font-normal normal-case`}>(optional — for follow-up tips)</span>
                  </label>
                  <input
                    type="tel"
                    id="guide-phone"
                    name="phone"
                    placeholder="812-000-0000"
                    className={`w-full rounded-xl px-5 py-3.5 text-sm focus:outline-none border transition-colors ${inputBg}`}
                  />
                </div>

                <button
                  type="submit"
                  disabled={status === 'submitting'}
                  className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-400 text-white font-bold text-sm uppercase tracking-widest py-4 rounded-xl transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  {status === 'submitting' ? (
                    <>
                      <i className="ri-loader-4-line animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <i className="ri-download-2-line" />
                      Get My Free Cost Guide
                    </>
                  )}
                </button>

                {status === 'error' && (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2">
                    <i className="ri-alert-line text-red-500 text-sm" />
                    <p className="text-red-600 text-xs">Something went wrong. Please try again.</p>
                  </div>
                )}

                <p className={`${textDim} text-xs text-center leading-relaxed`}>
                  <i className="ri-lock-line mr-1" />
                  Your info is safe. We never sell or share your data.
                </p>
              </form>

              {/* Alternative CTA */}
              <div className={`mt-6 pt-6 border-t ${borderClass} text-center`}>
                <p className={`${textDim} text-xs mb-2`}>Rather talk to a human?</p>
                <a
                  href="tel:8122135997"
                  className="inline-flex items-center gap-2 text-orange hover:text-orange-dark text-sm font-semibold transition-colors cursor-pointer"
                >
                  <i className="ri-phone-line" />
                  Call 812-213-5997
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}