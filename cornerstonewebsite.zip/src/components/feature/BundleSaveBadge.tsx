import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { trackOfferView } from '@/pages/promotions/components/RecentlyViewedOffers';

interface BundleSaveBadgeProps {
  triggerOffset?: number;
}

export default function BundleSaveBadge({ triggerOffset = 600 }: BundleSaveBadgeProps) {
  const navigate = useNavigate();
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setVisible(window.scrollY > triggerOffset);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, [triggerOffset]);

  if (dismissed) return null;

  const show = visible && !dismissed;

  return (
    <div
      className={`fixed right-0 top-1/2 -translate-y-1/2 z-50 flex items-stretch transition-all duration-500 ease-out ${
        show ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'
      }`}
      style={{ pointerEvents: show ? 'auto' : 'none' }}
    >
      {/* Expanded panel */}
      <div
        className="bg-charcoal-deep border-l border-t border-b border-white/10 flex flex-col overflow-hidden transition-all duration-500 ease-out"
        style={{ width: expanded ? '272px' : '0px', opacity: expanded ? 1 : 0 }}
      >
        <div className="p-5 flex flex-col gap-4" style={{ minWidth: '272px' }}>
          {/* Header */}
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <div className="w-5 h-5 flex items-center justify-center bg-orange/20">
                  <i className="ri-price-tag-3-line text-orange text-xs" />
                </div>
                <span className="text-orange text-xs font-bold uppercase tracking-widest">Bundle &amp; Save</span>
              </div>
              <p className="font-display text-white uppercase tracking-wider text-lg leading-tight">
                Save $800–$2,000
              </p>
            </div>
            <button
              onClick={() => setDismissed(true)}
              className="text-white/30 hover:text-white/70 transition-colors cursor-pointer flex-shrink-0 mt-0.5"
              aria-label="Dismiss"
            >
              <i className="ri-close-line text-base" />
            </button>
          </div>

          {/* Services */}
          <div className="space-y-2">
            {[
              { icon: 'ri-home-2-line', label: 'Roof Replacement' },
              { icon: 'ri-building-line', label: 'Siding Installation' },
              { icon: 'ri-drop-line', label: 'Gutter Replacement' },
            ].map((s) => (
              <div key={s.label} className="flex items-center gap-2.5 text-white/60 text-xs">
                <div className="w-6 h-6 flex items-center justify-center bg-orange/15 flex-shrink-0">
                  <i className={`${s.icon} text-orange text-xs`} />
                </div>
                {s.label}
              </div>
            ))}
          </div>

          <div className="border-t border-white/10 pt-3">
            <p className="text-white/40 text-xs leading-relaxed mb-3">
              One crew. One visit. One cleanup. Bundle all three and save big on mobilization.
            </p>
            <button
              onClick={() => {
                trackOfferView({
                  id: 'exterior-complete',
                  title: 'Complete Exterior Package',
                  savings: 'Save $800–$2,000',
                  icon: 'ri-home-gear-line',
                });
                navigate('/exterior-package');
              }}
              className="w-full bg-orange hover:bg-orange-dark text-white text-xs font-bold uppercase tracking-widest py-3 transition-colors cursor-pointer flex items-center justify-center gap-2 whitespace-nowrap"
            >
              <i className="ri-home-gear-line" />
              See Exterior Package
            </button>
            <button
              onClick={() => setExpanded(false)}
              className="w-full mt-2 text-white/30 hover:text-white/60 text-xs uppercase tracking-widest py-1.5 transition-colors cursor-pointer flex items-center justify-center gap-1 whitespace-nowrap"
            >
              <i className="ri-arrow-right-line text-xs" />
              Collapse
            </button>
          </div>
        </div>
      </div>

      {/* Collapsed vertical pill — always visible when badge is shown */}
      <button
        onClick={() => {
          setExpanded((p) => !p);
          if (!expanded) {
            trackOfferView({
              id: 'exterior-complete',
              title: 'Complete Exterior Package',
              savings: 'Save $800–$2,000',
              icon: 'ri-home-gear-line',
            });
          }
        }}
        className="bg-orange hover:bg-orange-dark text-white flex flex-col items-center justify-center gap-2 py-6 px-3 cursor-pointer transition-colors flex-shrink-0"
        aria-label={expanded ? 'Collapse bundle offer' : 'Show bundle offer'}
      >
        <i className="ri-price-tag-3-line text-sm" />
        <span
          className="text-xs font-bold uppercase"
          style={{ writingMode: 'vertical-rl', letterSpacing: '0.12em', transform: 'rotate(180deg)' }}
        >
          Bundle &amp; Save
        </span>
        <i className={`text-xs ${expanded ? 'ri-arrow-right-line' : 'ri-arrow-left-line'}`} />
      </button>
    </div>
  );
}
