import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function UrgencyBanner() {
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const [hoursLeft, setHoursLeft] = useState(0);
  const [minutesLeft, setMinutesLeft] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    // Calculate time until end of current month
    const now = new Date();
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
    const diff = endOfMonth.getTime() - now.getTime();
    setHoursLeft(Math.floor(diff / (1000 * 60 * 60)));
    setMinutesLeft(Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)));

    // Show after scrolling 600px
    const handleScroll = () => {
      if (window.scrollY > 600 && !dismissed) {
        setVisible(true);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [dismissed]);

  // Update countdown every minute
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
      const diff = Math.max(0, endOfMonth.getTime() - now.getTime());
      setHoursLeft(Math.floor(diff / (1000 * 60 * 60)));
      setMinutesLeft(Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)));
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const handleDismiss = () => {
    setDismissed(true);
    setVisible(false);
    sessionStorage.setItem('urgency-banner-dismissed', '1');
  };

  if (!visible) return null;

  return (
    <div className="fixed top-[72px] left-0 right-0 z-[45] bg-orange border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-2.5 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-wrap">
          <span className="relative flex items-center justify-center w-4 h-4">
            <span className="absolute inset-0 rounded-full bg-white/40 animate-ping" />
            <span className="relative inline-flex rounded-full w-2 h-2 bg-white" />
          </span>
          <p className="text-white text-xs md:text-sm font-bold uppercase tracking-wider">
            Free Inspection + $500 Repair Credit
          </p>
          <span className="hidden sm:inline text-white/50 text-xs">
            Ends this month · {hoursLeft}h {minutesLeft}m remaining
          </span>
        </div>
        <div className="flex items-center gap-3 flex-shrink-0">
          <button
            onClick={() => navigate('/estimate')}
            className="bg-white hover:bg-white/90 text-orange text-xs font-bold px-4 py-2 uppercase tracking-widest transition-colors whitespace-nowrap cursor-pointer"
          >
            Claim Now
          </button>
          <button
            onClick={handleDismiss}
            className="w-7 h-7 flex items-center justify-center text-white/50 hover:text-white transition-colors cursor-pointer"
            aria-label="Dismiss"
          >
            <i className="ri-close-line" />
          </button>
        </div>
      </div>
    </div>
  );
}