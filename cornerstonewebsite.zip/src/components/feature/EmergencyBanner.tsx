import { useState } from 'react';

export default function EmergencyBanner() {
  const [dismissed, setDismissed] = useState(false);

  if (dismissed) return null;

  return (
    <div className="relative bg-orange py-2.5 z-40">
      <div className="w-full px-6 md:px-10 lg:px-16">
        <div className="flex items-center justify-center gap-3 md:gap-8 text-center pr-8">
          <div className="flex items-center gap-2 flex-shrink-0">
            <span className="w-2 h-2 rounded-full bg-white animate-pulse flex-shrink-0" />
            <span className="text-white text-xs md:text-sm font-bold uppercase tracking-widest whitespace-nowrap">
              24/7 Emergency Roof Repair
            </span>
          </div>
          <span className="hidden sm:block text-white/60 text-xs">|</span>
          <a
            href="tel:8122135997"
            className="inline-flex items-center gap-2 text-white font-bold text-sm hover:text-white/80 transition-colors whitespace-nowrap"
          >
            <i className="ri-phone-fill text-base" />
            812-213-5997
          </a>
          <span className="hidden md:block text-white/60 text-xs">|</span>
          <span className="hidden md:block text-white/80 text-xs uppercase tracking-wider">
            Evansville, Indiana &amp; Tri-State Area
          </span>
        </div>
      </div>
      <button
        onClick={() => setDismissed(true)}
        className="absolute right-4 top-1/2 -translate-y-1/2 w-6 h-6 flex items-center justify-center text-white/70 hover:text-white transition-colors cursor-pointer"
        aria-label="Dismiss banner"
      >
        <i className="ri-close-line text-base" />
      </button>
    </div>
  );
}
