import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const COMPARISONS = [
  { feature: 'Free Roof Inspection', us: true, them: false },
  { feature: 'Insurance Claim Assistance', us: true, them: false },
  { feature: 'GAF Master Elite Certified', us: true, them: false },
  { feature: 'Financing From $89/Month', us: true, them: false },
  { feature: '25+ Years Local Experience', us: true, them: false },
  { feature: 'Lifetime Workmanship Warranty', us: true, them: false },
  { feature: '24/7 Emergency Response', us: true, them: false },
  { feature: 'Photo Documentation Report', us: true, them: false },
];

const AWARDS = [
  { icon: 'ri-award-fill', title: 'GAF Master Elite', sub: 'Top 3% of Contractors' },
  { icon: 'ri-shield-star-line', title: 'A+ BBB Rating', sub: 'Accredited Since 2001' },
  { icon: 'ri-star-fill', title: '4.9 Google Stars', sub: '200+ Verified Reviews' },
  { icon: 'ri-home-heart-line', title: 'Owens Corning', sub: 'Preferred Contractor' },
];

export default function WhyNumberOne() {
  const navigate = useNavigate();
  const header = useScrollAnimation({ threshold: 0.1 });
  const left = useScrollAnimation({ threshold: 0.1 });
  const right = useScrollAnimation({ threshold: 0.1 });

  return (
    <section className="bg-charcoal-deep py-20 md:py-28 overflow-hidden">
      <div className="w-full px-6 md:px-10 lg:px-16">

        {/* Header */}
        <div
          ref={header.ref as React.RefObject<HTMLDivElement>}
          className={`text-center mb-16 md:mb-20 anim-fade-up ${header.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">The Corner Stone Difference</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 6rem)' }}>
            Why We're Evansville's<br /><span className="text-orange">#1 Roofer</span>
          </h2>
          <p className="text-white/60 text-sm md:text-base mt-6 max-w-xl mx-auto leading-relaxed">
            Not all roofing companies are created equal. Here's what separates Corner Stone from the rest.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-start">

          {/* Left — Comparison Table */}
          <div
            ref={left.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-left ${left.isVisible ? 'is-visible' : ''}`}
          >
            <div className="border border-white/10 overflow-hidden">
              {/* Table header */}
              <div className="grid grid-cols-3 bg-charcoal-mid border-b border-white/10">
                <div className="col-span-1 px-6 py-4 text-white/60 text-xs uppercase tracking-widest">Feature</div>
                <div className="px-4 py-4 text-center">
                  <span className="text-orange text-xs font-bold uppercase tracking-widest">Corner Stone</span>
                </div>
                <div className="px-4 py-4 text-center">
                  <span className="text-white/60 text-xs uppercase tracking-widest">Others</span>
                </div>
              </div>
              {/* Rows */}
              {COMPARISONS.map((row, i) => (
                <div
                  key={row.feature}
                  className={`grid grid-cols-3 border-b border-white/5 last:border-b-0 transition-colors duration-200 hover:bg-white/[0.02] ${i % 2 === 0 ? 'bg-transparent' : 'bg-white/[0.015]'}`}
                >
                  <div className="col-span-1 px-6 py-4 text-white/60 text-sm">{row.feature}</div>
                  <div className="px-4 py-4 flex items-center justify-center">
                    <div className="w-6 h-6 flex items-center justify-center bg-orange/20 rounded-full">
                      <i className="ri-check-line text-orange text-xs font-bold" />
                    </div>
                  </div>
                  <div className="px-4 py-4 flex items-center justify-center">
                    <div className="w-6 h-6 flex items-center justify-center bg-white/5 rounded-full">
                      <i className="ri-close-line text-white/50 text-xs" />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={() => navigate('/estimate')}
              className="mt-6 w-full bg-orange hover:bg-orange-dark text-white font-semibold py-4 uppercase tracking-widest text-sm transition-colors duration-200 cursor-pointer flex items-center justify-center gap-2"
            >
              Get My Free Estimate
              <i className="ri-arrow-right-line" />
            </button>
          </div>

          {/* Right — Awards + Image */}
          <div
            ref={right.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-right ${right.isVisible ? 'is-visible' : ''} flex flex-col gap-6`}
          >
            {/* Awards grid */}
            <div className="grid grid-cols-2 gap-3">
              {AWARDS.map((award, i) => (
                <div
                  key={award.title}
                  className={`border border-white/10 bg-charcoal-mid p-6 flex flex-col items-center text-center hover:border-orange/40 transition-all duration-300 anim-fade-up ${right.isVisible ? 'is-visible' : ''}`}
                  style={{ transitionDelay: `${i * 100}ms` }}
                >
                  <div className="w-12 h-12 flex items-center justify-center bg-orange/15 mb-3">
                    <i className={`${award.icon} text-orange text-xl`} />
                  </div>
                  <p className="text-white font-semibold text-sm mb-1">{award.title}</p>
                  <p className="text-white/60 text-xs">{award.sub}</p>
                </div>
              ))}
            </div>

            {/* Image */}
            <div className="relative overflow-hidden" style={{ height: '280px' }}>
              <img
                src="/placeholders/800x500.svg"
                alt="Corner Stone roofing crew at work in Evansville Indiana"
                className="w-full h-full object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-deep/80 via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <p className="text-white font-display text-2xl uppercase tracking-wider">Certified. Trusted. Local.</p>
                <p className="text-white/70 text-sm mt-1">Evansville's most awarded roofing contractor</p>
              </div>
            </div>

            {/* Quick stats */}
            <div className="grid grid-cols-3 border border-white/10">
              {[
                { val: '100%', label: 'Satisfaction Rate' },
                { val: '$0', label: 'Down Financing' },
                { val: '48hr', label: 'Avg Job Start' },
              ].map((s, i) => (
                <div key={s.label} className={`px-4 py-5 text-center ${i < 2 ? 'border-r border-white/10' : ''}`}>
                  <p className="font-display text-orange text-2xl tracking-wider">{s.val}</p>
                  <p className="text-white/60 text-xs uppercase tracking-widest mt-1">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
