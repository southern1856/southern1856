import { useState } from 'react';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

interface CallbackWidgetProps {
  isOpen: boolean;
  onClose: () => void;
  /** inline = renders flat inside a container; popup = absolute floating panel (default) */
  mode?: 'popup' | 'inline';
}

function CallbackForm({ onClose, onSubmitted }: { onClose: () => void; onSubmitted: () => void }) {
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    const form = e.currentTarget;
    const _fd = new FormData(form);
    _fd.append('access_key', WEB3FORMS_ACCESS_KEY);
    const data = new URLSearchParams(_fd as unknown as Record<string, string>);
    try {
      await fetch(WEB3FORMS_ENDPOINT, { method: 'POST', body: data });
    } catch {
      // silent
    } finally {
      setLoading(false);
      onSubmitted();
    }
  };

  return (
    <form data-readdy-form onSubmit={handleSubmit} className="space-y-3">
      <div>
        <label className="text-white/60 text-xs uppercase tracking-wider block mb-1.5">Your Name</label>
        <input
          type="text"
          name="name"
          required
          placeholder="John Smith"
          className="w-full bg-charcoal border border-white/10 focus:border-orange/50 text-white text-sm px-3 py-2.5 outline-none placeholder:text-white/40 transition-colors"
        />
      </div>
      <div>
        <label className="text-white/60 text-xs uppercase tracking-wider block mb-1.5">Phone Number</label>
        <input
          type="tel"
          name="phone"
          required
          placeholder="812-555-0000"
          className="w-full bg-charcoal border border-white/10 focus:border-orange/50 text-white text-sm px-3 py-2.5 outline-none placeholder:text-white/40 transition-colors"
        />
      </div>
      <div>
        <label className="text-white/60 text-xs uppercase tracking-wider block mb-1.5">Best Time to Call</label>
        <select
          name="best_time"
          className="w-full bg-charcoal border border-white/10 focus:border-orange/50 text-white text-sm px-3 py-2.5 outline-none transition-colors cursor-pointer appearance-none"
        >
          <option value="ASAP">As soon as possible</option>
          <option value="Morning (8am–12pm)">Morning (8am–12pm)</option>
          <option value="Afternoon (12pm–5pm)">Afternoon (12pm–5pm)</option>
          <option value="Evening (5pm–7pm)">Evening (5pm–7pm)</option>
        </select>
      </div>
      <div>
        <label className="text-white/60 text-xs uppercase tracking-wider block mb-1.5">
          What&apos;s it about? <span className="text-white/20 normal-case">(optional)</span>
        </label>
        <select
          name="topic"
          className="w-full bg-charcoal border border-white/10 focus:border-orange/50 text-white text-sm px-3 py-2.5 outline-none transition-colors cursor-pointer appearance-none"
        >
          <option value="Free Estimate">Free Estimate</option>
          <option value="Storm Damage">Storm Damage</option>
          <option value="Insurance Claim">Insurance Claim</option>
          <option value="Roof Repair">Roof Repair</option>
          <option value="General Question">General Question</option>
        </select>
      </div>
      <button
        type="submit"
        disabled={loading}
        className="w-full bg-orange hover:bg-orange-dark text-white font-semibold py-3 uppercase tracking-widest text-xs transition-colors whitespace-nowrap cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed mt-1"
      >
        {loading ? 'Sending...' : 'Request Callback'}
      </button>
      <p className="text-white/20 text-xs text-center">Mon–Fri 7am–6pm · Sat 8am–2pm</p>
    </form>
  );
}

function CallbackSuccess({ onClose }: { onClose: () => void }) {
  return (
    <div className="text-center py-4">
      <div className="w-12 h-12 flex items-center justify-center bg-orange/20 text-orange mx-auto mb-3">
        <i className="ri-check-line text-2xl" />
      </div>
      <p className="text-white font-semibold text-sm mb-1">Got it! We&apos;ll call you soon.</p>
      <p className="text-white/60 text-xs leading-relaxed">
        Expect a call from <strong className="text-white/60">812-213-5997</strong> within the hour during business hours.
      </p>
      <button
        onClick={onClose}
        className="mt-4 text-orange text-xs font-semibold uppercase tracking-wider hover:text-orange-dark transition-colors cursor-pointer"
      >
        Close
      </button>
    </div>
  );
}

export default function CallbackWidget({ isOpen, onClose, mode = 'popup' }: CallbackWidgetProps) {
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const header = (
    <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 bg-charcoal">
      <div className="flex items-center gap-2.5">
        <div className="w-7 h-7 flex items-center justify-center bg-orange">
          <i className="ri-phone-line text-white text-sm" />
        </div>
        <div>
          <p className="text-white text-xs font-semibold uppercase tracking-wider">Request a Callback</p>
          <p className="text-white/50 text-xs">We&apos;ll call you within 1 hour</p>
        </div>
      </div>
      <button
        onClick={onClose}
        className="w-6 h-6 flex items-center justify-center text-white/50 hover:text-white transition-colors cursor-pointer"
      >
        <i className="ri-close-line text-base" />
      </button>
    </div>
  );

  const body = (
    <div className="p-5">
      {submitted
        ? <CallbackSuccess onClose={onClose} />
        : <CallbackForm onClose={onClose} onSubmitted={() => setSubmitted(true)} />
      }
    </div>
  );

  if (mode === 'inline') {
    return (
      <div className="w-full bg-charcoal-deep border border-white/10 overflow-hidden">
        {header}
        {body}
      </div>
    );
  }

  // popup mode — absolute floating panel
  return (
    <div className="absolute bottom-full right-0 mb-3 w-80 bg-charcoal-deep border border-white/10 overflow-hidden">
      {header}
      {body}
    </div>
  );
}
