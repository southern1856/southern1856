import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';

export default function InactivityModal() {
  const [show, setShow] = useState(false);
  const [hidden, setHidden] = useState(false);
  const navigate = useNavigate();

  const INACTIVE_MS = 30000; // 30 seconds

  const resetTimer = useCallback(() => {
    if (hidden) return;
    setShow(false);
  }, [hidden]);

  useEffect(() => {
    if (hidden) return;
    const wasDismissed = sessionStorage.getItem('inactivity-modal-dismissed');
    if (wasDismissed) return;

    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    events.forEach((e) => window.addEventListener(e, resetTimer, { passive: true }));

    let timer: ReturnType<typeof setTimeout>;

    const startTimer = () => {
      timer = setTimeout(() => {
        setShow(true);
      }, INACTIVE_MS);
    };

    startTimer();

    return () => {
      clearTimeout(timer);
      events.forEach((e) => window.removeEventListener(e, resetTimer));
    };
  }, [hidden, resetTimer]);

  const handleDismiss = () => {
    setShow(false);
    setHidden(true);
    sessionStorage.setItem('inactivity-modal-dismissed', '1');
  };

  const handleCTA = () => {
    setShow(false);
    setHidden(true);
    navigate('/estimate');
  };

  if (!show) return null;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/70 backdrop-blur-sm">
      <div className="relative bg-charcoal-deep border border-white/10 max-w-md w-[calc(100%-2rem)] p-8 md:p-10 shadow-2xl">
        {/* Close */}
        <button
          onClick={handleDismiss}
          className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center text-white/30 hover:text-white transition-colors cursor-pointer"
          aria-label="Close"
        >
          <i className="ri-close-line text-lg" />
        </button>

        {/* Urgency header */}
        <div className="flex items-center gap-2 mb-5">
          <span className="relative flex items-center justify-center w-5 h-5">
            <span className="absolute inset-0 rounded-full bg-red-500/40 animate-ping" />
            <span className="relative inline-flex rounded-full w-2.5 h-2.5 bg-red-500" />
          </span>
          <span className="text-red-400 text-xs font-bold uppercase tracking-widest">Limited Slots Available</span>
        </div>

        <h2 className="font-display text-white text-2xl md:text-3xl uppercase tracking-wider leading-tight mb-3">
          Still Thinking It Over?
        </h2>
        <p className="text-white/50 text-sm leading-relaxed mb-6">
          Free roof inspections are booking up fast this week. Evansville homeowners who schedule today get priority crew assignment — no wait, no hassle.
        </p>

        {/* Social proof line */}
        <div className="flex items-center gap-2 mb-6 bg-white/5 border border-white/5 px-4 py-3">
          <div className="flex -space-x-2">
            {[1,2,3].map((i) => (
              <div key={i} className="w-7 h-7 bg-charcoal-mid border border-charcoal-deep flex items-center justify-center">
                <i className="ri-user-line text-white/30 text-xs" />
              </div>
            ))}
          </div>
          <p className="text-white/50 text-xs">
            <span className="text-orange font-bold">47 people</span> from Evansville scheduled inspections in the last 48 hours
          </p>
        </div>

        <div className="flex flex-col gap-3">
          <button
            onClick={handleCTA}
            className="bg-orange hover:bg-orange-dark text-white font-semibold px-6 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer w-full"
          >
            Book Free Inspection — Takes 60 Seconds
          </button>
          <a
            href="tel:8122135997"
            onClick={handleDismiss}
            className="border border-white/15 hover:border-orange text-white/60 hover:text-white text-sm font-semibold px-6 py-3 uppercase tracking-widest transition-all whitespace-nowrap flex items-center justify-center gap-2"
          >
            <i className="ri-phone-line text-orange" />
            Call 812-213-5997
          </a>
        </div>

        <p className="text-white/20 text-xs text-center mt-4">
          No obligation. No pressure. Free detailed report.
        </p>
      </div>
    </div>
  );
}