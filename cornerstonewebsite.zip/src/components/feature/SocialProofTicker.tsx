const ITEMS = [
  { icon: 'ri-star-fill', text: '4.9★ on Google — 200+ Reviews' },
  { icon: 'ri-shield-check-line', text: 'A+ BBB Accredited Business' },
  { icon: 'ri-award-line', text: 'GAF Certified Master Elite Contractor' },
  { icon: 'ri-home-4-line', text: '2,500+ Roofs Installed Since 1995' },
  { icon: 'ri-map-pin-line', text: 'Serving Evansville, Newburgh & Tri-State Area' },
  { icon: 'ri-tools-line', text: 'Licensed & Fully Insured in Indiana & Kentucky' },
  { icon: 'ri-timer-line', text: '24/7 Emergency Storm Response' },
  { icon: 'ri-bank-card-line', text: 'Financing From $89/Month — Same Day Approval' },
  { icon: 'ri-file-list-3-line', text: 'Insurance Claim Specialists — We Handle Everything' },
  { icon: 'ri-thumb-up-line', text: '100% Satisfaction Guarantee on Every Job' },
];

export default function SocialProofTicker() {
  const doubled = [...ITEMS, ...ITEMS];

  return (
    <div className="bg-orange overflow-hidden py-3.5 border-y border-orange-dark">
      <div className="ticker-track flex items-center gap-0 whitespace-nowrap">
        {doubled.map((item, i) => (
          <div key={i} className="flex items-center gap-8 flex-shrink-0">
            <div className="flex items-center gap-2.5 px-8">
              <i className={`${item.icon} text-white/80 text-sm`} />
              <span className="text-white text-xs font-semibold uppercase tracking-[0.15em]">{item.text}</span>
            </div>
            <span className="text-white/40 text-xs">•</span>
          </div>
        ))}
      </div>
    </div>
  );
}
