import { useEffect, useState } from 'react';

export default function BrandedLoadingSkeleton() {
  const [dots, setDots] = useState('');

  useEffect(() => {
    const timer = setInterval(() => {
      setDots((prev) => (prev.length >= 3 ? '' : prev + '.'));
    }, 500);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="fixed inset-0 z-[90] bg-white flex flex-col items-center justify-center">
      <div className="flex flex-col items-center gap-6">
        <div className="flex items-center justify-center h-20 w-20 bg-charcoal-deep rounded-xl shadow-lg animate-pulse">
          <img
            src="/logo.svg"
            alt="Corner Stone Construction & Roofing"
            className="h-14 w-14 object-contain rounded-lg"
          />
        </div>
        <div className="flex flex-col items-center gap-1">
          <span className="font-display text-charcoal-deep text-xl tracking-wider uppercase">
            Corner Stone
          </span>
          <span className="text-gray-400 text-xs tracking-[0.2em] uppercase font-medium">
            Loading{dots}
          </span>
        </div>
      </div>
    </div>
  );
}