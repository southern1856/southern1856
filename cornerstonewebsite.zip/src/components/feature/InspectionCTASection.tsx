import { useState, useRef } from 'react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

const PERKS = [
  { icon: 'ri-search-eye-line', label: 'Full Roof Assessment', desc: 'We inspect every inch — shingles, flashing, gutters, and decking.' },
  { icon: 'ri-camera-line', label: 'Photo Documentation', desc: 'You get a full photo report of any damage or wear we find.' },
  { icon: 'ri-file-list-3-line', label: 'Written Estimate', desc: 'Clear, itemized quote with no hidden fees or pressure to buy.' },
  { icon: 'ri-shield-check-line', label: 'Insurance Guidance', desc: 'We flag storm damage and walk you through the claims process.' },
];

export default function InspectionCTASection() {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [charCount, setCharCount] = useState(0);
  const formRef = useRef<HTMLFormElement>(null);
  const left = useScrollAnimation({ threshold: 0.1 });
  const right = useScrollAnimation({ threshold: 0.1 });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;

    const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
    const notes = formData.get('notes') as string;
    if (notes && notes.length > 500) return;

    setStatus('submitting');
    try {
      const res = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      });
      if (res.ok) {
        setStatus('success');
        formRef.current.reset();
        setCharCount(0);
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    }
  };

  return (
    <section id="free-inspection" className="relative overflow-hidden py-20 md:py-28" style={{ background: 'linear-gradient(135deg, #1a1a1a 0%, #111111 60%, #1f1008 100%)' }}>
      {/* Decorative background accent */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-32 -right-32 w-[600px] h-[600px] rounded-full opacity-10" style={{ background: 'radial-gradient(circle, #e8621a 0%, transparent 70%)' }} />
        <div className="absolute -bottom-20 -left-20 w-[400px] h-[400px] rounded-full opacity-5" style={{ background: 'radial-gradient(circle, #e8621a 0%, transparent 70%)' }} />
        {/* Grid lines */}
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '80px 80px' }} />
      </div>

      <div className="relative z-10 w-full px-6 md:px-10 lg:px-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">

          {/* LEFT — Copy & Perks */}
          <div
            ref={left.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${left.isVisible ? 'is-visible' : ''}`}
          >
            {/* Urgency badge */}
            <div className="inline-flex items-center gap-2 bg-orange/15 border border-orange/30 px-4 py-2 mb-8">
              <span className="w-2 h-2 rounded-full bg-orange animate-pulse" />
              <span className="text-orange text-xs font-bold uppercase tracking-[0.2em]">Limited Slots This Month</span>
            </div>

            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.2rem, 5vw, 4.5rem)' }}>
              Get Your Free<br />
              <span className="text-orange">Roof Inspection</span><br />
              Today
            </h2>

            <p className="text-white/50 text-base md:text-lg leading-relaxed max-w-md mb-10">
              Most roof problems are invisible from the ground. Our certified inspectors catch issues early — before a small leak becomes a $15,000 replacement. No cost, no obligation, no pressure.
            </p>

            {/* Perks grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
              {PERKS.map((perk, i) => (
                <div
                  key={perk.label}
                  className={`border border-white/10 p-5 anim-fade-up ${left.isVisible ? 'is-visible' : ''}`}
                  style={{ transitionDelay: `${i * 80 + 200}ms` }}
                >
                  <div className="w-9 h-9 flex items-center justify-center bg-orange/15 mb-3">
                    <i className={`${perk.icon} text-orange text-lg`} />
                  </div>
                  <p className="text-white text-sm font-semibold mb-1">{perk.label}</p>
                  <p className="text-white/40 text-xs leading-relaxed">{perk.desc}</p>
                </div>
              ))}
            </div>

            {/* Social proof strip */}
            <div className="flex flex-wrap items-center gap-6 pt-8 border-t border-white/10">
              <div className="text-center">
                <p className="font-display text-white text-3xl tracking-wider">500+</p>
                <p className="text-white/40 text-xs uppercase tracking-widest mt-1">Inspections Done</p>
              </div>
              <div className="w-px h-10 bg-white/10" />
              <div className="text-center">
                <p className="font-display text-white text-3xl tracking-wider">4.9</p>
                <div className="flex gap-0.5 justify-center my-1">
                  {[1,2,3,4,5].map(i => <i key={i} className="ri-star-fill text-orange text-xs" />)}
                </div>
                <p className="text-white/40 text-xs uppercase tracking-widest">Google Rating</p>
              </div>
              <div className="w-px h-10 bg-white/10" />
              <div className="text-center">
                <p className="font-display text-white text-3xl tracking-wider">24h</p>
                <p className="text-white/40 text-xs uppercase tracking-widest mt-1">Response Time</p>
              </div>
            </div>
          </div>

          {/* RIGHT — Form */}
          <div
            ref={right.ref as React.RefObject<HTMLDivElement>}
            className={`anim-fade-up ${right.isVisible ? 'is-visible' : ''}`}
            style={{ transitionDelay: '150ms' }}
          >
            <div className="bg-white rounded-2xl overflow-hidden">
              {/* Form header */}
              <div className="bg-orange px-8 py-6">
                <h3 className="font-display text-white text-2xl uppercase tracking-wider">Book Your Inspection</h3>
                <p className="text-white/80 text-sm mt-1">Takes 60 seconds — we'll handle the rest</p>
              </div>

              {status === 'success' ? (
                <div className="px-8 py-16 flex flex-col items-center text-center">
                  <div className="w-16 h-16 flex items-center justify-center bg-green-100 rounded-full mb-5">
                    <i className="ri-checkbox-circle-fill text-green-600 text-3xl" />
                  </div>
                  <h4 className="text-charcoal font-display text-2xl uppercase tracking-wider mb-3">You're Booked!</h4>
                  <p className="text-gray-500 text-sm leading-relaxed max-w-xs">
                    Our Evansville team will call you within 24 hours to confirm your free inspection time.
                  </p>
                  <button
                    onClick={() => setStatus('idle')}
                    className="mt-8 text-orange text-sm font-semibold underline underline-offset-4 cursor-pointer"
                  >
                    Submit another request
                  </button>
                </div>
              ) : (
                <form
                  ref={formRef}
                  data-readdy-form
                  onSubmit={handleSubmit}
                  className="px-8 py-8 space-y-5"
                >
                  {/* Name + Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="insp-name" className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-2">Full Name</label>
                      <input
                        type="text"
                        id="insp-name"
                        name="name"
                        required
                        placeholder="John Smith"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 transition"
                      />
                    </div>
                    <div>
                      <label htmlFor="insp-phone" className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-2">Phone Number</label>
                      <input
                        type="tel"
                        id="insp-phone"
                        name="phone"
                        required
                        placeholder="812-000-0000"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 transition"
                      />
                    </div>
                  </div>

                  {/* Email */}
                  <div>
                    <label htmlFor="insp-email" className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-2">Email Address</label>
                    <input
                      type="email"
                      id="insp-email"
                      name="email"
                      required
                      placeholder="your@email.com"
                      className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 transition"
                    />
                  </div>

                  {/* Address */}
                  <div>
                    <label htmlFor="insp-address" className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-2">Property Address</label>
                    <input
                      type="text"
                      id="insp-address"
                      name="address"
                      required
                      placeholder="123 Main St, Evansville, IN"
                      className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 transition"
                    />
                  </div>

                  {/* Roof type + Concern */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="insp-roof-type" className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-2">Roof Type</label>
                      <select
                        id="insp-roof-type"
                        name="roof_type"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 transition appearance-none cursor-pointer"
                      >
                        <option value="">Not sure</option>
                        <option value="asphalt">Asphalt Shingles</option>
                        <option value="metal">Metal Roof</option>
                        <option value="flat">Flat / TPO</option>
                        <option value="tile">Tile</option>
                        <option value="other">Other</option>
                      </select>
                    </div>
                    <div>
                      <label htmlFor="insp-concern" className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-2">Main Concern</label>
                      <select
                        id="insp-concern"
                        name="concern"
                        className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm focus:outline-none focus:ring-2 focus:ring-orange/40 transition appearance-none cursor-pointer"
                      >
                        <option value="">Select one</option>
                        <option value="leak">Active Leak</option>
                        <option value="storm">Storm / Hail Damage</option>
                        <option value="age">Age / General Wear</option>
                        <option value="insurance">Insurance Claim</option>
                        <option value="buying">Buying / Selling Home</option>
                        <option value="routine">Routine Checkup</option>
                      </select>
                    </div>
                  </div>

                  {/* Notes */}
                  <div>
                    <label htmlFor="insp-notes" className="block text-gray-700 text-xs font-semibold uppercase tracking-wider mb-2">
                      Additional Notes <span className="text-gray-400 font-normal normal-case">(optional)</span>
                    </label>
                    <textarea
                      id="insp-notes"
                      name="notes"
                      rows={3}
                      maxLength={500}
                      onChange={(e) => setCharCount(e.target.value.length)}
                      placeholder="Anything else we should know before we arrive..."
                      className="w-full bg-gray-100 rounded-lg px-4 py-3 text-gray-800 text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40 transition resize-none"
                    />
                    <p className={`text-xs mt-1 text-right ${charCount > 500 ? 'text-red-500' : 'text-gray-400'}`}>{charCount}/500</p>
                  </div>

                  {/* Submit */}
                  <button
                    type="submit"
                    disabled={status === 'submitting'}
                    className="w-full bg-orange hover:bg-orange/90 disabled:bg-gray-300 text-white font-bold text-sm uppercase tracking-widest py-4 rounded-lg transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer whitespace-nowrap"
                  >
                    {status === 'submitting' ? (
                      <>
                        <i className="ri-loader-4-line animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      <>
                        <i className="ri-calendar-check-line" />
                        Schedule My Free Inspection
                      </>
                    )}
                  </button>

                  {status === 'error' && (
                    <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-2">
                      <i className="ri-alert-line text-red-500 text-base" />
                      <p className="text-red-600 text-xs">Something went wrong. Please call us at 812-213-5997.</p>
                    </div>
                  )}

                  <p className="text-gray-400 text-xs text-center leading-relaxed">
                    <i className="ri-lock-line mr-1" />
                    Your info is private. We never share or sell your data.
                  </p>
                </form>
              )}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
