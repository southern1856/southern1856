import { useState, useEffect } from 'react';

const SEALS = [
  {
    icon: 'ri-shield-check-line',
    label: 'Licensed \u0026 Insured',
    detail: 'IN \u0026 KY',
    color: 'text-green-400',
    bg: 'bg-green-400/8',
  },
  {
    icon: 'ri-building-4-line',
    label: 'BBB A+ Rated',
    detail: 'Since 1995',
    color: 'text-amber-400',
    bg: 'bg-amber-400/8',
  },
  {
    icon: 'ri-award-line',
    label: 'GAF Master Elite',
    detail: 'Top 3%',
    color: 'text-amber-300',
    bg: 'bg-amber-300/8',
  },
  {
    icon: 'ri-medal-line',
    label: 'Owens Corning',
    detail: 'Platinum Preferred',
    color: 'text-orange',
    bg: 'bg-orange/8',
  },
  {
    icon: 'ri-star-fill',
    label: '4.9 Google Rating',
    detail: '340+ Reviews',
    color: 'text-amber-500',
    bg: 'bg-amber-500/8',
  },
  {
    icon: 'ri-secure-payment-line',
    label: '$2M Liability',
    detail: 'Full Coverage',
    color: 'text-green-300',
    bg: 'bg-green-300/8',
  },
];

export default function TrustSealStrip() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setVisible(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div
      className={`fixed top-[72px] left-0 right-0 z-[44] border-b border-white/5 bg-charcoal/90 backdrop-blur-md transition-all duration-500 ${
        visible ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0 pointer-events-none'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-2 flex items-center justify-center gap-4 md:gap-8 overflow-x-auto scrollbar-hide">
        {SEALS.map((seal) => (
          <div
            key={seal.label}
            className="flex items-center gap-2 flex-shrink-0"
          >
            <div className={`w-6 h-6 flex items-center justify-center ${seal.bg} ${seal.color}`}>
              <i className={`${seal.icon} text-sm`} />
            </div>
            <div className="hidden md:block">
              <p className="text-white/70 text-[10px] font-bold uppercase tracking-wider leading-none">{seal.label}</p>
              <p className="text-white/30 text-[9px] uppercase tracking-wider mt-0.5">{seal.detail}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}