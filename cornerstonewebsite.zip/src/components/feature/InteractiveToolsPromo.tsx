import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { useToolUsage } from '@/hooks/useToolUsage';

function formatCount(n: number): string {
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
  return String(n);
}

const TOOLS = [
  {
    key: 'quote-comparison',
    label: 'Compare Roofing Quotes',
    description: 'Paste in up to 4 quotes and our AI engine scores each on price, materials, warranties, and red flags. Spot bait-and-switch before you sign.',
    icon: 'ri-scales-3-line',
    badge: 'AI Scoring Engine',
    route: '/quote-comparison',
    stat: '100% Private',
  },
  {
    key: 'financing-calculator',
    label: 'Financing Calculator',
    description: '3 tools in one: monthly payment estimator, reverse affordability calculator, and cash-vs-financing comparison with AI guidance.',
    icon: 'ri-calculator-line',
    badge: '3-in-1 Calculator',
    route: '/financing-calculator',
    stat: 'No Credit Check',
  },
  {
    key: 'instant-scheduler',
    label: 'Instant Scheduler',
    description: 'Book your free inspection, repair, or estimate in under 60 seconds. Pick your service, choose a date and time, and lock it in.',
    icon: 'ri-calendar-check-line',
    badge: 'Book in 60 Secs',
    route: '/instant-scheduler',
    stat: 'Same-Day Available',
  },
];

export default function InteractiveToolsPromo() {
  const navigate = useNavigate();
  const anim = useScrollAnimation({ threshold: 0.12 });
  const { stats, mostUsed } = useToolUsage();

  return (
    <section
      ref={anim.ref as React.RefObject<HTMLElement>}
      className={`anim-fade-up ${anim.isVisible ? 'is-visible' : ''} bg-charcoal-deep py-16 md:py-24 px-6 md:px-10 lg:px-16 border-y border-white/5`}
    >
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-12 md:mb-16">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-3">
            Free Interactive Tools
          </p>
          <h2 className="font-display text-white text-2xl md:text-3xl lg:text-4xl uppercase tracking-wider mb-4">
            Smart Tools, Better Decisions
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-2xl mx-auto leading-relaxed">
            Not ready to call? Use these interactive tools to compare quotes, run financing numbers,
            or book an appointment — no pressure, no signup, and your data never leaves the page.
          </p>
        </div>

        {/* Tool Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-6">
          {TOOLS.map((tool) => {
            const toolStat = stats.find((s) => s.tool_id === tool.key);
            const isMostUsed = mostUsed?.tool_id === tool.key;

            return (
              <button
                key={tool.key}
                onClick={() => navigate(tool.route)}
                className="group text-left bg-charcoal-mid border border-white/10 hover:border-orange/40 transition-all duration-300 cursor-pointer"
              >
                {/* Top bar with icon */}
                <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
                  <div className="w-12 h-12 flex items-center justify-center bg-charcoal-deep text-orange group-hover:bg-orange group-hover:text-white transition-colors duration-300">
                    <i className={`${tool.icon} text-xl`} />
                  </div>
                  <span className="text-orange/70 text-[10px] font-semibold uppercase tracking-widest border border-orange/20 px-2.5 py-1">
                    {isMostUsed ? 'Most Popular' : tool.badge}
                  </span>
                </div>

                {/* Body */}
                <div className="p-6">
                  <h3 className="font-display text-white text-lg uppercase tracking-wide mb-2 group-hover:text-orange transition-colors duration-200">
                    {tool.label}
                  </h3>
                  <p className="text-white/40 text-sm leading-relaxed mb-5">
                    {tool.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-white/25 text-xs uppercase tracking-wider">
                      <i className="ri-shield-check-line text-orange mr-1.5" />
                      {tool.stat}
                    </span>
                    <span className="flex items-center gap-1.5 text-orange text-xs font-semibold uppercase tracking-wider group-hover:translate-x-1 transition-transform duration-200">
                      Try It <i className="ri-arrow-right-line" />
                    </span>
                  </div>
                  {toolStat && toolStat.usage_count > 0 && (
                    <div className="mt-3 pt-3 border-t border-white/5 flex items-center gap-1.5">
                      <i className="ri-fire-line text-orange text-[10px]" />
                      <span className="text-white/30 text-[10px] font-medium uppercase tracking-wider">
                        Used by {formatCount(toolStat.usage_count)} homeowners
                      </span>
                    </div>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="mt-12 text-center">
          <p className="text-white/30 text-sm mb-4">
            Need help using a tool? Talk to Alex — he walks through each one step by step.
          </p>
          <button
            onClick={() => window.dispatchEvent(new CustomEvent('open-chat'))}
            className="inline-flex items-center gap-2 text-orange text-xs font-semibold uppercase tracking-widest hover:text-orange-dark transition-colors cursor-pointer"
          >
            <i className="ri-robot-2-line" />
            Ask Alex for Help
          </button>
        </div>
      </div>
    </section>
  );
}