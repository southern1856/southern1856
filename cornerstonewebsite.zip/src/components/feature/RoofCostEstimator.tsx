import { useState, useRef, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

/* ─── Types ─── */
type Material = {
  key: string;
  label: string;
  minPerSq: number;
  maxPerSq: number;
  icon: string;
  desc: string;
  lifespan: string;
};

type StoriesKey = '1' | '2' | '3';
type PitchKey = 'low' | 'medium' | 'steep' | 'very_steep';
type LayersKey = '1' | '2' | '3plus';
type DeckingKey = 'good' | 'soft' | 'widespread';
type ComplexityKey = 'simple' | 'moderate' | 'complex';
type AccessKey = 'easy' | 'tight';

/* ─── Data ─── */
const MATERIALS: Material[] = [
  { key: '3tab', label: '3-Tab Shingles', minPerSq: 350, maxPerSq: 480, icon: 'ri-layout-grid-line', desc: 'Entry-level, clean look', lifespan: '20–25 yrs' },
  { key: 'arch', label: 'Architectural Shingles', minPerSq: 450, maxPerSq: 620, icon: 'ri-stack-line', desc: 'Most popular, dimensional style', lifespan: '30–50 yrs' },
  { key: 'luxury', label: 'Luxury / Designer', minPerSq: 650, maxPerSq: 850, icon: 'ri-vip-crown-line', desc: 'Premium look & performance', lifespan: '40–50 yrs' },
  { key: 'metal', label: 'Metal Roofing', minPerSq: 800, maxPerSq: 1100, icon: 'ri-shield-check-line', desc: 'Permanent, energy efficient', lifespan: '50+ yrs' },
];

const STORIES: { key: StoriesKey; label: string; multiplier: number }[] = [
  { key: '1', label: '1 Story', multiplier: 1.0 },
  { key: '2', label: '2 Stories', multiplier: 1.12 },
  { key: '3', label: '3+ Stories', multiplier: 1.30 },
];

const PITCHES: { key: PitchKey; label: string; desc: string; multiplier: number }[] = [
  { key: 'low', label: 'Low Slope', desc: '4/12 pitch or less — walkable', multiplier: 1.0 },
  { key: 'medium', label: 'Medium', desc: '5/12 to 8/12 — standard', multiplier: 1.08 },
  { key: 'steep', label: 'Steep', desc: '9/12 to 12/12 — harness work', multiplier: 1.18 },
  { key: 'very_steep', label: 'Very Steep', desc: '12/12+ — special equipment', multiplier: 1.28 },
];

const LAYERS: { key: LayersKey; label: string; multiplier: number }[] = [
  { key: '1', label: '1 Layer', multiplier: 1.0 },
  { key: '2', label: '2 Layers', multiplier: 1.10 },
  { key: '3plus', label: '3+ Layers', multiplier: 1.20 },
];

const DECKING: { key: DeckingKey; label: string; desc: string; addMin: number; addMax: number }[] = [
  { key: 'good', label: 'Good / Unknown', desc: 'No known decking issues', addMin: 0, addMax: 0 },
  { key: 'soft', label: 'Some Soft Spots', desc: 'A few areas need new plywood', addMin: 800, addMax: 1500 },
  { key: 'widespread', label: 'Widespread Damage', desc: 'Significant rot or sagging', addMin: 2000, addMax: 4500 },
];

const COMPLEXITY: { key: ComplexityKey; label: string; desc: string; featureAdd: number }[] = [
  { key: 'simple', label: 'Simple Gable', desc: '2 straight planes, no valleys', featureAdd: 0 },
  { key: 'moderate', label: 'Moderate', desc: 'A few valleys, one chimney', featureAdd: 400 },
  { key: 'complex', label: 'Complex', desc: 'Multiple dormers, valleys, peaks', featureAdd: 900 },
];

const ACCESS: { key: AccessKey; label: string; multiplier: number }[] = [
  { key: 'easy', label: 'Easy Access', multiplier: 1.0 },
  { key: 'tight', label: 'Tight / Limited', multiplier: 1.05 },
];

/* ─── Helpers ─── */
function formatCurrency(n: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);
}

/* ─── Component ─── */
interface RoofCostEstimatorProps {
  onResultShown?: () => void;
  prefill?: {
    roofSqft?: string;
    inputMode?: 'home_sqft' | 'roof_sqft' | 'squares';
    stories?: StoriesKey;
    pitch?: PitchKey;
    complexity?: ComplexityKey;
    access?: AccessKey;
    layers?: LayersKey;
    decking?: DeckingKey;
    materialKey?: string;
    chimneys?: number;
    skylights?: number;
    dormers?: number;
  } | null;
}

export default function RoofCostEstimator({ onResultShown, prefill }: RoofCostEstimatorProps) {
  const navigate = useNavigate();
  const sectionAnim = useScrollAnimation({ threshold: 0.04 });
  const resultRef = useRef<HTMLDivElement>(null);

  /* Steps 1-4 */
  const [step, setStep] = useState(1);

  /* Step 1 */
  const [roofSqft, setRoofSqft] = useState('');
  const [stories, setStories] = useState<StoriesKey>('1');
  const [inputMode, setInputMode] = useState<'home_sqft' | 'roof_sqft' | 'squares'>('home_sqft');

  /* Step 2 */
  const [pitch, setPitch] = useState<PitchKey>('low');
  const [complexity, setComplexity] = useState<ComplexityKey>('simple');
  const [access, setAccess] = useState<AccessKey>('easy');

  /* Step 3 */
  const [layers, setLayers] = useState<LayersKey>('1');
  const [decking, setDecking] = useState<DeckingKey>('good');

  /* Step 4 */
  const [material, setMaterial] = useState<Material | null>(null);
  const [chimneys, setChimneys] = useState(0);
  const [skylights, setSkylights] = useState(0);
  const [dormers, setDormers] = useState(0);
  const [prefillApplied, setPrefillApplied] = useState(false);

  // Track when results are shown
  useEffect(() => {
    if (step === 4 && material && calc().min > 0) {
      onResultShown?.();
    }
  }, [step, material, onResultShown]);

  // Apply prefill defaults when triggered from external CTA (e.g. countdown banner)
  useEffect(() => {
    if (!prefill) return;
    if (prefill.roofSqft) setRoofSqft(prefill.roofSqft);
    if (prefill.inputMode) setInputMode(prefill.inputMode);
    if (prefill.stories) setStories(prefill.stories);
    if (prefill.pitch) setPitch(prefill.pitch);
    if (prefill.complexity) setComplexity(prefill.complexity);
    if (prefill.access) setAccess(prefill.access);
    if (prefill.layers) setLayers(prefill.layers);
    if (prefill.decking) setDecking(prefill.decking);
    if (prefill.materialKey) {
      const mat = MATERIALS.find((m) => m.key === prefill.materialKey);
      if (mat) setMaterial(mat);
    }
    if (prefill.chimneys !== undefined) setChimneys(prefill.chimneys);
    if (prefill.skylights !== undefined) setSkylights(prefill.skylights);
    if (prefill.dormers !== undefined) setDormers(prefill.dormers);
    // Jump to results step so user sees the estimate instantly
    setStep(4);
    setPrefillApplied(true);
  }, [prefill]);

  /* Derived roof squares */
  const roofSquares = useCallback(() => {
    const num = parseFloat(roofSqft);
    if (!num || num <= 0) return 0;
    if (inputMode === 'home_sqft') return Math.round((num * 1.35) / 100);
    if (inputMode === 'roof_sqft') return Math.round(num / 100);
    return Math.round(num);
  }, [roofSqft, inputMode]);

  /* Calculation */
  const calc = useCallback(() => {
    const sq = roofSquares();
    const mat = material;
    if (!sq || !mat) return { min: 0, max: 0, sq };

    const sMult = STORIES.find((s) => s.key === stories)?.multiplier ?? 1;
    const pMult = PITCHES.find((p) => p.key === pitch)?.multiplier ?? 1;
    const lMult = LAYERS.find((l) => l.key === layers)?.multiplier ?? 1;
    const aMult = ACCESS.find((a) => a.key === access)?.multiplier ?? 1;
    const dAdd = DECKING.find((d) => d.key === decking) ?? { addMin: 0, addMax: 0 };
    const cAdd = COMPLEXITY.find((c) => c.key === complexity)?.featureAdd ?? 0;

    const featureAdd = cAdd + chimneys * 275 + skylights * 400 + dormers * 475;

    const minPrice = sq * mat.minPerSq * sMult * pMult * lMult * aMult + dAdd.addMin + featureAdd;
    const maxPrice = sq * mat.maxPerSq * sMult * pMult * lMult * aMult + dAdd.addMax + featureAdd;

    return { min: Math.round(minPrice), max: Math.round(maxPrice), sq };
  }, [roofSquares, material, stories, pitch, layers, access, decking, complexity, chimneys, skylights, dormers]);

  const { min, max, sq } = calc();
  const avg = min && max ? Math.round((min + max) / 2) : 0;

  /* Navigation */
  const goNext = () => {
    setStep((s) => Math.min(s + 1, 4));
    if (step === 3 && resultRef.current) {
      setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 150);
    }
  };
  const goBack = () => setStep((s) => Math.max(s - 1, 1));
  const reset = () => {
    setStep(1);
    setRoofSqft('');
    setStories('1');
    setInputMode('home_sqft');
    setPitch('low');
    setComplexity('simple');
    setAccess('easy');
    setLayers('1');
    setDecking('good');
    setMaterial(null);
    setChimneys(0);
    setSkylights(0);
    setDormers(0);
    setPrefillApplied(false);
  };

  /* Validation */
  const step1Valid = roofSqft && parseFloat(roofSqft) > 0;
  const step4Valid = !!material;

  return (
    <section id="roof-estimator" className="bg-warm-beige py-20 md:py-28 px-6 md:px-10 lg:px-16">
      <div
        ref={sectionAnim.ref as React.RefObject<HTMLDivElement>}
        className={`anim-fade-up ${sectionAnim.isVisible ? 'is-visible' : ''}`}
      >
        {/* Header */}
        <div className="text-center mb-12 md:mb-16">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Quick &amp; Personalized</p>
          <h2
            className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-5"
            style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}
          >
            Roof Cost
            <br />
            <span className="text-orange">Estimator</span>
          </h2>
          <p className="text-charcoal-mid/50 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Enter your roof details and get a personalized price range in under 60 seconds. No email required.
          </p>
        </div>

        {/* Estimator Card */}
        <div className="max-w-4xl mx-auto bg-white border border-charcoal/5 overflow-hidden">
          {/* Progress */}
          <div className="flex items-center bg-charcoal-deep px-6 md:px-10 py-5">
            {[1, 2, 3, 4].map((s) => (
              <div key={s} className="flex items-center flex-1">
                <div
                  className={`w-8 h-8 flex items-center justify-center text-xs font-bold uppercase tracking-wider transition-colors ${
                    s <= step ? 'bg-orange text-white' : 'bg-white/10 text-white/30'
                  }`}
                >
                  {s}
                </div>
                <span
                  className={`ml-3 text-xs font-semibold uppercase tracking-wider hidden sm:block transition-colors ${
                    s <= step ? 'text-white' : 'text-white/30'
                  }`}
                >
                  {s === 1 ? 'Size' : s === 2 ? 'Pitch & Shape' : s === 3 ? 'Condition' : 'Material'}
                </span>
                {s < 4 && (
                  <div className="flex-1 h-px mx-3 md:mx-4 bg-white/10">
                    <div className={`h-full bg-orange transition-all duration-500 ${s < step ? 'w-full' : 'w-0'}`} />
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* ── Step 1: Size & Stories ── */}
          {step === 1 && (
            <div className="p-6 md:p-10">
              <h3 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider mb-2">
                Roof Size &amp; Height
              </h3>
              <p className="text-charcoal-mid/40 text-sm mb-8">These two factors account for about 60% of your total cost.</p>

              {/* Input mode toggle */}
              <div className="flex flex-wrap gap-2 mb-6">
                {[
                  { key: 'home_sqft' as const, label: 'Home Sq Ft' },
                  { key: 'roof_sqft' as const, label: 'Roof Sq Ft' },
                  { key: 'squares' as const, label: 'Roofing Squares' },
                ].map((m) => (
                  <button
                    key={m.key}
                    onClick={() => { setInputMode(m.key); setRoofSqft(''); }}
                    className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer ${
                      inputMode === m.key
                        ? 'bg-charcoal-deep text-white'
                        : 'border border-charcoal/15 text-charcoal-mid/60 hover:border-charcoal/30'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>

              {/* Size input */}
              <div className="mb-8">
                <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-2">
                  {inputMode === 'home_sqft' && 'Approximate Home Square Footage'}
                  {inputMode === 'roof_sqft' && 'Approximate Roof Surface Area'}
                  {inputMode === 'squares' && 'Number of Roofing Squares'}
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={roofSqft}
                    onChange={(e) => setRoofSqft(e.target.value)}
                    placeholder={
                      inputMode === 'home_sqft' ? 'e.g. 1800' : inputMode === 'roof_sqft' ? 'e.g. 2400' : 'e.g. 24'
                    }
                    className="w-full bg-gray-100 rounded-lg px-4 py-3.5 text-charcoal-deep text-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange/40"
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-charcoal-mid/30 text-xs font-semibold uppercase">
                    {inputMode === 'squares' ? 'squares' : 'sq ft'}
                  </span>
                </div>
                <p className="text-charcoal-mid/30 text-xs mt-2">
                  {inputMode === 'home_sqft' && 'Roof area is typically 1.2–1.5x your home footprint. We use 1.35x as a standard estimate.'}
                  {inputMode === 'roof_sqft' && 'Total surface area including overhangs. 1 roofing square = 100 sq ft.'}
                  {inputMode === 'squares' && 'Roofers measure in "squares" — each square is 100 sq ft of roof surface.'}
                </p>
                {sq > 0 && (
                  <p className="text-orange text-xs font-semibold mt-2">
                    Estimated roof: <span className="font-display text-sm">{sq}</span> squares
                    {inputMode === 'home_sqft' && ` (${Math.round(parseFloat(roofSqft) * 1.35)} sq ft roof area)`}
                  </p>
                )}
              </div>

              {/* Stories */}
              <div>
                <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-3">
                  How Many Stories?
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {STORIES.map((s) => (
                    <button
                      key={s.key}
                      onClick={() => setStories(s.key)}
                      className={`text-left p-4 border transition-all duration-200 cursor-pointer ${
                        stories === s.key
                          ? 'border-orange bg-orange/5'
                          : 'border-charcoal/10 hover:border-charcoal/30'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-display text-charcoal-deep text-base uppercase tracking-wide">{s.label}</span>
                        {stories === s.key && <i className="ri-check-line text-orange" />}
                      </div>
                      <p className="text-charcoal-mid/40 text-xs">
                        {s.multiplier === 1.0 ? 'Standard labor rate' : `+${Math.round((s.multiplier - 1) * 100)}% labor &amp; safety`}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Next */}
              <div className="mt-8 flex justify-end">
                <button
                  onClick={goNext}
                  disabled={!step1Valid}
                  className="bg-charcoal-deep hover:bg-charcoal-mid disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
                >
                  Continue
                  <i className="ri-arrow-right-line" />
                </button>
              </div>
            </div>
          )}

          {/* ── Step 2: Pitch & Shape ── */}
          {step === 2 && (
            <div className="p-6 md:p-10">
              <div className="flex items-center gap-3 mb-6">
                <button
                  onClick={goBack}
                  className="text-charcoal-mid/40 hover:text-orange text-xs uppercase tracking-wider flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <i className="ri-arrow-left-line" /> Back
                </button>
              </div>

              <h3 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider mb-2">
                Roof Pitch &amp; Shape
              </h3>
              <p className="text-charcoal-mid/40 text-sm mb-8">
                Steeper roofs and complex shapes take more time, materials, and safety gear.
              </p>

              {/* Pitch */}
              <div className="mb-8">
                <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-3">
                  How Steep Is Your Roof?
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {PITCHES.map((p) => (
                    <button
                      key={p.key}
                      onClick={() => setPitch(p.key)}
                      className={`text-left p-4 border transition-all duration-200 cursor-pointer ${
                        pitch === p.key ? 'border-orange bg-orange/5' : 'border-charcoal/10 hover:border-charcoal/30'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-display text-charcoal-deep text-base uppercase tracking-wide">{p.label}</span>
                        {pitch === p.key && <i className="ri-check-line text-orange" />}
                      </div>
                      <p className="text-charcoal-mid/40 text-xs">{p.desc}</p>
                      <p className="text-orange text-xs font-semibold mt-1">
                        {p.multiplier === 1.0 ? 'Base rate' : `+${Math.round((p.multiplier - 1) * 100)}% labor cost`}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Complexity */}
              <div className="mb-8">
                <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-3">
                  Roof Complexity
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {COMPLEXITY.map((c) => (
                    <button
                      key={c.key}
                      onClick={() => setComplexity(c.key)}
                      className={`text-left p-4 border transition-all duration-200 cursor-pointer ${
                        complexity === c.key ? 'border-orange bg-orange/5' : 'border-charcoal/10 hover:border-charcoal/30'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-display text-charcoal-deep text-sm uppercase tracking-wide">{c.label}</span>
                        {complexity === c.key && <i className="ri-check-line text-orange" />}
                      </div>
                      <p className="text-charcoal-mid/40 text-xs">{c.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Access */}
              <div>
                <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-3">
                  Site Access
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {ACCESS.map((a) => (
                    <button
                      key={a.key}
                      onClick={() => setAccess(a.key)}
                      className={`text-left p-4 border transition-all duration-200 cursor-pointer ${
                        access === a.key ? 'border-orange bg-orange/5' : 'border-charcoal/10 hover:border-charcoal/30'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-display text-charcoal-deep text-base uppercase tracking-wide">{a.label}</span>
                        {access === a.key && <i className="ri-check-line text-orange" />}
                      </div>
                      <p className="text-charcoal-mid/40 text-xs">
                        {a.key === 'easy' ? 'Open driveway, clear yard, standard lot' : 'Narrow driveway, fences, obstacles near home'}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-8 flex justify-between">
                <button
                  onClick={goBack}
                  className="border border-charcoal/20 text-charcoal-mid font-semibold px-6 py-3 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
                >
                  <i className="ri-arrow-left-line" />
                  Back
                </button>
                <button
                  onClick={goNext}
                  className="bg-charcoal-deep hover:bg-charcoal-mid text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
                >
                  Continue
                  <i className="ri-arrow-right-line" />
                </button>
              </div>
            </div>
          )}

          {/* ── Step 3: Condition ── */}
          {step === 3 && (
            <div className="p-6 md:p-10">
              <div className="flex items-center gap-3 mb-6">
                <button
                  onClick={goBack}
                  className="text-charcoal-mid/40 hover:text-orange text-xs uppercase tracking-wider flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <i className="ri-arrow-left-line" /> Back
                </button>
              </div>

              <h3 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider mb-2">
                Current Roof Condition
              </h3>
              <p className="text-charcoal-mid/40 text-sm mb-8">
                Tear-off depth and decking condition are the biggest surprise costs on most jobs.
              </p>

              {/* Layers */}
              <div className="mb-8">
                <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-3">
                  How Many Existing Layers?
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {LAYERS.map((l) => (
                    <button
                      key={l.key}
                      onClick={() => setLayers(l.key)}
                      className={`text-left p-4 border transition-all duration-200 cursor-pointer ${
                        layers === l.key ? 'border-orange bg-orange/5' : 'border-charcoal/10 hover:border-charcoal/30'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-display text-charcoal-deep text-base uppercase tracking-wide">{l.label}</span>
                        {layers === l.key && <i className="ri-check-line text-orange" />}
                      </div>
                      <p className="text-orange text-xs font-semibold mt-1">
                        {l.multiplier === 1.0 ? 'Standard tear-off' : `+${Math.round((l.multiplier - 1) * 100)}% tear-off labor &amp; disposal`}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Decking */}
              <div className="mb-8">
                <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-3">
                  Decking (Plywood Under Shingles)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {DECKING.map((d) => (
                    <button
                      key={d.key}
                      onClick={() => setDecking(d.key)}
                      className={`text-left p-4 border transition-all duration-200 cursor-pointer ${
                        decking === d.key ? 'border-orange bg-orange/5' : 'border-charcoal/10 hover:border-charcoal/30'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-display text-charcoal-deep text-sm uppercase tracking-wide">{d.label}</span>
                        {decking === d.key && <i className="ri-check-line text-orange" />}
                      </div>
                      <p className="text-charcoal-mid/40 text-xs">{d.desc}</p>
                      {d.addMax > 0 && (
                        <p className="text-orange text-xs font-semibold mt-1">
                          +{formatCurrency(d.addMin)}–{formatCurrency(d.addMax)}
                        </p>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-8 flex justify-between">
                <button
                  onClick={goBack}
                  className="border border-charcoal/20 text-charcoal-mid font-semibold px-6 py-3 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
                >
                  <i className="ri-arrow-left-line" />
                  Back
                </button>
                <button
                  onClick={goNext}
                  className="bg-charcoal-deep hover:bg-charcoal-mid text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
                >
                  Continue
                  <i className="ri-arrow-right-line" />
                </button>
              </div>
            </div>
          )}

          {/* ── Step 4: Material & Features ── */}
          {step === 4 && (
            <div className="p-6 md:p-10">
              <div className="flex items-center gap-3 mb-6">
                <button
                  onClick={goBack}
                  className="text-charcoal-mid/40 hover:text-orange text-xs uppercase tracking-wider flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <i className="ri-arrow-left-line" /> Back
                </button>
              </div>

              <h3 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider mb-2">
                Material &amp; Roof Features
              </h3>
              <p className="text-charcoal-mid/40 text-sm mb-8">
                Choose your material and count the penetrations that require custom flashing.
              </p>

              {/* Material */}
              <div className="mb-8">
                <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-3">
                  Roofing Material
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {MATERIALS.map((m) => (
                    <button
                      key={m.key}
                      onClick={() => setMaterial(m)}
                      className={`text-left p-4 border transition-all duration-200 cursor-pointer ${
                        material?.key === m.key ? 'border-orange bg-orange/5' : 'border-charcoal/10 hover:border-charcoal/30'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-10 h-10 flex items-center justify-center flex-shrink-0 ${
                              material?.key === m.key ? 'bg-orange text-white' : 'bg-charcoal-deep text-white'
                            }`}
                          >
                            <i className={`${m.icon} text-base`} />
                          </div>
                          <div>
                            <span className="font-display text-charcoal-deep text-base uppercase tracking-wide block">{m.label}</span>
                            <span className="text-charcoal-mid/40 text-xs">{m.desc}</span>
                          </div>
                        </div>
                        {material?.key === m.key && <i className="ri-check-line text-orange text-lg" />}
                      </div>
                      <div className="flex items-center justify-between mt-2 pt-2 border-t border-charcoal/5">
                        <span className="text-charcoal-mid/40 text-xs">Lifespan: {m.lifespan}</span>
                        <span className="text-orange text-xs font-semibold">
                          {formatCurrency(m.minPerSq)}–{formatCurrency(m.maxPerSq)}/sq
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Features */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
                {/* Chimneys */}
                <div>
                  <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-2">
                    Chimneys
                  </label>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setChimneys(Math.max(0, chimneys - 1))}
                      className="w-10 h-10 flex items-center justify-center border border-charcoal/15 hover:border-orange text-charcoal-mid transition-colors cursor-pointer"
                    >
                      <i className="ri-subtract-line" />
                    </button>
                    <span className="font-display text-charcoal-deep text-xl w-8 text-center">{chimneys}</span>
                    <button
                      onClick={() => setChimneys(chimneys + 1)}
                      className="w-10 h-10 flex items-center justify-center border border-charcoal/15 hover:border-orange text-charcoal-mid transition-colors cursor-pointer"
                    >
                      <i className="ri-add-line" />
                    </button>
                  </div>
                  <p className="text-charcoal-mid/30 text-xs mt-1">+{formatCurrency(250)}–{formatCurrency(400)} each</p>
                </div>

                {/* Skylights */}
                <div>
                  <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-2">
                    Skylights
                  </label>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setSkylights(Math.max(0, skylights - 1))}
                      className="w-10 h-10 flex items-center justify-center border border-charcoal/15 hover:border-orange text-charcoal-mid transition-colors cursor-pointer"
                    >
                      <i className="ri-subtract-line" />
                    </button>
                    <span className="font-display text-charcoal-deep text-xl w-8 text-center">{skylights}</span>
                    <button
                      onClick={() => setSkylights(skylights + 1)}
                      className="w-10 h-10 flex items-center justify-center border border-charcoal/15 hover:border-orange text-charcoal-mid transition-colors cursor-pointer"
                    >
                      <i className="ri-add-line" />
                    </button>
                  </div>
                  <p className="text-charcoal-mid/30 text-xs mt-1">+{formatCurrency(350)}–{formatCurrency(550)} each</p>
                </div>

                {/* Dormers */}
                <div>
                  <label className="block text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-2">
                    Dormers
                  </label>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setDormers(Math.max(0, dormers - 1))}
                      className="w-10 h-10 flex items-center justify-center border border-charcoal/15 hover:border-orange text-charcoal-mid transition-colors cursor-pointer"
                    >
                      <i className="ri-subtract-line" />
                    </button>
                    <span className="font-display text-charcoal-deep text-xl w-8 text-center">{dormers}</span>
                    <button
                      onClick={() => setDormers(dormers + 1)}
                      className="w-10 h-10 flex items-center justify-center border border-charcoal/15 hover:border-orange text-charcoal-mid transition-colors cursor-pointer"
                    >
                      <i className="ri-add-line" />
                    </button>
                  </div>
                  <p className="text-charcoal-mid/30 text-xs mt-1">+{formatCurrency(400)}–{formatCurrency(600)} each</p>
                </div>
              </div>

              <div className="mt-4 flex justify-between">
                <button
                  onClick={goBack}
                  className="border border-charcoal/20 text-charcoal-mid font-semibold px-6 py-3 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
                >
                  <i className="ri-arrow-left-line" />
                  Back
                </button>
                <button
                  onClick={goNext}
                  disabled={!step4Valid}
                  className="bg-orange hover:bg-orange-dark disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-semibold px-8 py-3.5 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
                >
                  See My Estimate
                  <i className="ri-arrow-right-line" />
                </button>
              </div>
            </div>
          )}

          {/* ── Step 5: Result ── */}
          {step === 4 && material && min > 0 && (
            <div className="border-t border-charcoal/5 p-6 md:p-10" ref={resultRef}>
              <div className="flex items-center gap-3 mb-6">
                <button
                  onClick={reset}
                  className="text-charcoal-mid/40 hover:text-orange text-xs uppercase tracking-wider flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <i className="ri-restart-line" /> Start Over
                </button>
              </div>

              {/* Summary tags */}
              <div className="flex flex-wrap gap-2 mb-6">
                <span className="inline-flex items-center gap-1.5 bg-charcoal-deep text-white text-xs font-semibold px-3 py-1.5 uppercase tracking-wider">
                  <i className="ri-home-4-line text-xs" />
                  {sq} Squares
                </span>
                <span className="inline-flex items-center gap-1.5 bg-charcoal-deep text-white text-xs font-semibold px-3 py-1.5 uppercase tracking-wider">
                  <i className="ri-building-line text-xs" />
                  {STORIES.find((s) => s.key === stories)?.label}
                </span>
                <span className="inline-flex items-center gap-1.5 bg-orange text-white text-xs font-semibold px-3 py-1.5 uppercase tracking-wider">
                  <i className={`${material.icon} text-xs`} />
                  {material.label}
                </span>
              </div>

              {/* Deal-applied badge when prefill came from Lock In Deal */}
              {prefillApplied && (
                <div className="mb-6 bg-orange/5 border border-orange/20 px-5 py-3 flex items-center gap-3">
                  <div className="w-10 h-10 flex items-center justify-center bg-orange flex-shrink-0">
                    <i className="ri-flashlight-line text-white text-lg" />
                  </div>
                  <div>
                    <p className="text-orange text-sm font-semibold uppercase tracking-wider">Limited-Time Deal Applied</p>
                    <p className="text-charcoal-mid/50 text-xs leading-relaxed mt-0.5">Your estimate reflects a special promotional offer. Lock it in before the deal expires to guarantee this pricing.</p>
                  </div>
                </div>
              )}

              {/* Price */}
              <div className="bg-charcoal-deep p-8 md:p-10 text-center mb-6">
                <p className="text-white/30 text-xs font-semibold uppercase tracking-[0.25em] mb-4">
                  Your Personalized Estimate
                </p>
                <div className="flex items-baseline justify-center gap-3 mb-2 flex-wrap">
                  <span className="font-display text-orange text-4xl md:text-5xl lg:text-6xl uppercase tracking-wider">
                    {formatCurrency(min)}
                  </span>
                  <span className="text-white/20 text-lg md:text-xl font-display uppercase">–</span>
                  <span className="font-display text-orange text-4xl md:text-5xl lg:text-6xl uppercase tracking-wider">
                    {formatCurrency(max)}
                  </span>
                </div>
                <p className="text-white/30 text-sm mt-2">
                  Midpoint: <span className="text-white font-semibold">{formatCurrency(avg)}</span>
                </p>
                <p className="text-white/20 text-xs mt-3">
                  Range width: {formatCurrency(max - min)} — based on {sq} squares of {material.label.toLowerCase()}
                </p>
              </div>

              {/* Breakdown */}
              <div className="bg-warm-beige border border-charcoal/5 p-5 md:p-6 mb-6">
                <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-4">
                  What Drives Your Price
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {[
                    {
                      label: 'Roof Size',
                      value: `${sq} squares`,
                      note: `Base: ${formatCurrency(material.minPerSq)}–${formatCurrency(material.maxPerSq)}/sq`,
                    },
                    {
                      label: 'Stories',
                      value: STORIES.find((s) => s.key === stories)?.label ?? '',
                      note: `${Math.round(((STORIES.find((s) => s.key === stories)?.multiplier ?? 1) - 1) * 100)}% labor adjustment`,
                    },
                    {
                      label: 'Pitch',
                      value: PITCHES.find((p) => p.key === pitch)?.label ?? '',
                      note: `${Math.round(((PITCHES.find((p) => p.key === pitch)?.multiplier ?? 1) - 1) * 100)}% labor adjustment`,
                    },
                    {
                      label: 'Tear-Off',
                      value: LAYERS.find((l) => l.key === layers)?.label ?? '',
                      note: `${Math.round(((LAYERS.find((l) => l.key === layers)?.multiplier ?? 1) - 1) * 100)}% disposal & labor`,
                    },
                    {
                      label: 'Decking',
                      value: DECKING.find((d) => d.key === decking)?.label ?? '',
                      note:
                        (DECKING.find((d) => d.key === decking)?.addMax ?? 0) > 0
                          ? `+${formatCurrency(DECKING.find((d) => d.key === decking)?.addMin ?? 0)}–${formatCurrency(DECKING.find((d) => d.key === decking)?.addMax ?? 0)}`
                          : 'No additional cost',
                    },
                    {
                      label: 'Features',
                      value: `${chimneys + skylights + dormers} items`,
                      note:
                        chimneys + skylights + dormers > 0
                          ? `+${formatCurrency(chimneys * 250 + skylights * 350 + dormers * 400)}–${formatCurrency(chimneys * 400 + skylights * 550 + dormers * 600)}`
                          : 'No additional cost',
                    },
                  ].map((row) => (
                    <div key={row.label} className="flex items-start gap-3">
                      <div className="w-6 h-6 flex items-center justify-center bg-charcoal-deep text-orange flex-shrink-0 mt-0.5">
                        <i className="ri-check-line text-xs" />
                      </div>
                      <div>
                        <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider">{row.label}</p>
                        <p className="text-charcoal-mid text-sm">{row.value}</p>
                        <p className="text-charcoal-mid/40 text-xs">{row.note}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Disclaimer */}
              <div className="border border-orange/15 bg-orange/5 p-5 mb-8">
                <div className="flex items-start gap-3">
                  <i className="ri-information-line text-orange text-lg flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-charcoal-deep text-sm font-semibold mb-1">This is an approximate estimate only.</p>
                    <p className="text-charcoal-mid/50 text-xs leading-relaxed">
                      Final pricing requires a physical inspection to verify exact measurements, decking condition, ventilation
                      requirements, permit fees, and site-specific factors. Many homeowners find our final written estimate falls
                      within this range.
                    </p>
                  </div>
                </div>
              </div>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 mb-8">
                <button
                  onClick={() => navigate('/estimate')}
                  className="flex-1 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                >
                  Get Your Exact Estimate
                  <i className="ri-arrow-right-line" />
                </button>
                <a
                  href="tel:8122135997"
                  className="flex-1 border border-charcoal/20 hover:border-charcoal-deep text-charcoal-deep font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2"
                >
                  <i className="ri-phone-line text-orange" />
                  Call 812-213-5997
                </a>
              </div>

              {/* Why ranges differ */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {[
                  {
                    icon: 'ri-ruler-line',
                    title: 'Exact Measurements',
                    desc: 'We measure every plane, valley, and overhang on-site. Satellite estimates can be off by 5–10%.',
                  },
                  {
                    icon: 'ri-hammer-line',
                    title: 'Decking Surprises',
                    desc: 'Rotten plywood is hidden until tear-off. Our estimate includes a per-sheet rate so there are no surprises.',
                  },
                  {
                    icon: 'ri-file-list-3-line',
                    title: 'Itemized Written Quote',
                    desc: 'You get a line-by-line breakdown of materials, labor, and permits — no vague lump sums.',
                  },
                ].map((item) => (
                  <div key={item.title} className="flex items-start gap-3">
                    <div className="w-8 h-8 flex items-center justify-center bg-charcoal-deep text-orange flex-shrink-0">
                      <i className={`${item.icon} text-sm`} />
                    </div>
                    <div>
                      <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-0.5">{item.title}</p>
                      <p className="text-charcoal-mid/40 text-xs leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Trust line */}
        <div className="max-w-4xl mx-auto mt-8 flex flex-wrap items-center justify-center gap-6 md:gap-10">
          <div className="flex items-center gap-2 text-charcoal-mid/40 text-xs">
            <i className="ri-shield-check-line text-orange" />
            <span>Based on Evansville-area 2026 pricing</span>
          </div>
          <div className="flex items-center gap-2 text-charcoal-mid/40 text-xs">
            <i className="ri-lock-line text-orange" />
            <span>No email or phone required</span>
          </div>
          <div className="flex items-center gap-2 text-charcoal-mid/40 text-xs">
            <i className="ri-time-line text-orange" />
            <span>Updated May 2026</span>
          </div>
        </div>
      </div>
    </section>
  );
}