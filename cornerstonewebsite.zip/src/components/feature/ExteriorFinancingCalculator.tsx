import { useState, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const TERM_OPTIONS = [
  { months: 12, label: '12 Months', rate: 0, desc: 'Same-As-Cash' },
  { months: 24, label: '24 Months', rate: 6.99, desc: 'Low APR' },
  { months: 36, label: '36 Months', rate: 8.99, desc: 'Standard' },
  { months: 60, label: '5 Years', rate: 9.99, desc: 'Extended' },
  { months: 84, label: '7 Years', rate: 10.99, desc: 'Long Term' },
  { months: 120, label: '10 Years', rate: 11.99, desc: 'Maximum' },
  { months: 180, label: '15 Years', rate: 12.99, desc: 'Lowest Payment' },
];

const CREDIT_TIERS = [
  { label: 'Excellent (720+)', rateMod: -1.5 },
  { label: 'Good (680–719)', rateMod: 0 },
  { label: 'Fair (620–679)', rateMod: 2.5 },
  { label: 'Building (below 620)', rateMod: 5.0 },
];

function formatCurrency(n: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);
}

export default function ExteriorFinancingCalculator() {
  const navigate = useNavigate();
  const sectionAnim = useScrollAnimation({ threshold: 0.06 });
  const resultRef = useRef<HTMLDivElement>(null);

  const [projectCost, setProjectCost] = useState<number>(25000);
  const [downPayment, setDownPayment] = useState<number>(0);
  const [termIndex, setTermIndex] = useState<number>(4); // default 84 months
  const [creditTier, setCreditTier] = useState<number>(1); // default Good
  const [showResults, setShowResults] = useState(false);

  const selectedTerm = TERM_OPTIONS[termIndex];
  const selectedCredit = CREDIT_TIERS[creditTier];
  const effectiveRate = Math.max(0, selectedTerm.rate + selectedCredit.rateMod);

  const principal = Math.max(0, projectCost - downPayment);
  const monthlyRate = effectiveRate / 100 / 12;
  const numPayments = selectedTerm.months;

  let monthlyPayment = 0;
  let totalPaid = 0;
  let totalInterest = 0;

  if (effectiveRate === 0) {
    monthlyPayment = principal / numPayments;
    totalPaid = principal;
    totalInterest = 0;
  } else {
    monthlyPayment = (principal * monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / (Math.pow(1 + monthlyRate, numPayments) - 1);
    totalPaid = monthlyPayment * numPayments;
    totalInterest = totalPaid - principal;
  }

  const handleCalculate = useCallback(() => {
    setShowResults(true);
    setTimeout(() => {
      resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  }, []);

  const handlePreset = (amount: number) => {
    setProjectCost(amount);
    setShowResults(false);
  };

  return (
    <section id="financing-calculator" className="bg-charcoal py-20 md:py-28 px-6 md:px-10 lg:px-16">
      <div
        ref={sectionAnim.ref as React.RefObject<HTMLDivElement>}
        className={`anim-fade-up ${sectionAnim.isVisible ? 'is-visible' : ''}`}
      >
        {/* Header */}
        <div className="text-center mb-12 md:mb-16">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Payment Planning</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Exterior Project<br /><span className="text-orange">Financing Calculator</span>
          </h2>
          <p className="text-white/40 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Turn that bundle price into a real monthly budget. See exactly what you&apos;ll pay each month based on your credit and preferred term.
          </p>
        </div>

        {/* Main calculator card */}
        <div className="max-w-4xl mx-auto bg-charcoal-mid border border-white/10 overflow-hidden">
          {/* Input section */}
          <div className="p-6 md:p-10">
            {/* Project Cost */}
            <div className="mb-8">
              <label className="block text-white text-xs font-semibold uppercase tracking-wider mb-3">
                Estimated Project Cost
              </label>
              <div className="flex flex-col sm:flex-row gap-3 mb-3">
                <div className="flex-1 relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30 text-sm font-semibold">$</span>
                  <input
                    type="number"
                    min={5000}
                    max={200000}
                    step={1000}
                    value={projectCost}
                    onChange={(e) => { setProjectCost(Number(e.target.value)); setShowResults(false); }}
                    className="w-full bg-charcoal-deep border border-white/10 text-white text-lg font-semibold px-4 py-3.5 pl-8 focus:outline-none focus:border-orange transition-colors"
                  />
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {[
                  { label: 'Small Essential', amount: 15000 },
                  { label: 'Complete Package', amount: 25000 },
                  { label: 'Large Complete', amount: 35000 },
                  { label: 'Premium', amount: 50000 },
                  { label: 'Luxury', amount: 75000 },
                ].map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() => handlePreset(preset.amount)}
                    className={`text-xs font-semibold uppercase tracking-wider px-3 py-1.5 border transition-all cursor-pointer whitespace-nowrap ${
                      projectCost === preset.amount
                        ? 'bg-orange border-orange text-white'
                        : 'border-white/15 text-white/40 hover:border-white/40 hover:text-white/60'
                    }`}
                  >
                    {preset.label} — {formatCurrency(preset.amount)}
                  </button>
                ))}
              </div>
            </div>

            {/* Two columns: Down Payment + Term */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mb-8">
              {/* Down Payment */}
              <div>
                <label className="block text-white text-xs font-semibold uppercase tracking-wider mb-3">
                  Down Payment
                </label>
                <div className="relative mb-3">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30 text-sm font-semibold">$</span>
                  <input
                    type="number"
                    min={0}
                    max={projectCost}
                    step={500}
                    value={downPayment}
                    onChange={(e) => { setDownPayment(Number(e.target.value)); setShowResults(false); }}
                    className="w-full bg-charcoal-deep border border-white/10 text-white text-lg font-semibold px-4 py-3.5 pl-8 focus:outline-none focus:border-orange transition-colors"
                  />
                </div>
                <div className="flex flex-wrap gap-2">
                  {[
                    { label: '$0', amount: 0 },
                    { label: '$2,500', amount: 2500 },
                    { label: '$5,000', amount: 5000 },
                    { label: '$10,000', amount: 10000 },
                  ].map((preset) => (
                    <button
                      key={preset.label}
                      onClick={() => { setDownPayment(preset.amount); setShowResults(false); }}
                      className={`text-xs font-semibold uppercase tracking-wider px-3 py-1.5 border transition-all cursor-pointer whitespace-nowrap ${
                        downPayment === preset.amount
                          ? 'bg-orange border-orange text-white'
                          : 'border-white/15 text-white/40 hover:border-white/40 hover:text-white/60'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
                <p className="text-white/20 text-xs mt-2">
                  Amount financed: <span className="text-white/40 font-semibold">{formatCurrency(principal)}</span>
                </p>
              </div>

              {/* Term */}
              <div>
                <label className="block text-white text-xs font-semibold uppercase tracking-wider mb-3">
                  Financing Term
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-3 lg:grid-cols-4 gap-2">
                  {TERM_OPTIONS.map((term, i) => (
                    <button
                      key={term.months}
                      onClick={() => { setTermIndex(i); setShowResults(false); }}
                      className={`text-left p-3 border transition-all cursor-pointer ${
                        termIndex === i
                          ? 'bg-orange/10 border-orange'
                          : 'border-white/10 hover:border-white/25'
                      }`}
                    >
                      <p className={`text-sm font-semibold uppercase tracking-wider ${termIndex === i ? 'text-orange' : 'text-white/60'}`}>
                        {term.label}
                      </p>
                      <p className="text-white/25 text-xs mt-0.5">{term.desc}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Credit Score */}
            <div className="mb-8">
              <label className="block text-white text-xs font-semibold uppercase tracking-wider mb-3">
                Estimated Credit Tier
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {CREDIT_TIERS.map((tier, i) => (
                  <button
                    key={tier.label}
                    onClick={() => { setCreditTier(i); setShowResults(false); }}
                    className={`p-4 border text-left transition-all cursor-pointer ${
                      creditTier === i
                        ? 'bg-orange/10 border-orange'
                        : 'border-white/10 hover:border-white/25'
                    }`}
                  >
                    <p className={`text-sm font-semibold uppercase tracking-wider mb-1 ${creditTier === i ? 'text-orange' : 'text-white/60'}`}>
                      {tier.label}
                    </p>
                    <p className="text-white/25 text-xs">
                      {tier.rateMod <= 0 ? (tier.rateMod < 0 ? `${Math.abs(tier.rateMod)}% below base rate` : 'Base rate') : `+${tier.rateMod}% above base`}
                    </p>
                  </button>
                ))}
              </div>
            </div>

            {/* Calculate button */}
            <button
              onClick={handleCalculate}
              className="w-full bg-orange hover:bg-orange-dark text-white font-bold text-sm uppercase tracking-widest py-4 transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
            >
              <i className="ri-calculator-line" />
              Calculate My Monthly Payment
            </button>
          </div>

          {/* Results section */}
          {showResults && (
            <div className="border-t border-white/10" ref={resultRef}>
              {/* Big monthly payment */}
              <div className="bg-charcoal-deep p-8 md:p-12 text-center">
                <p className="text-white/30 text-xs font-semibold uppercase tracking-[0.25em] mb-4">Estimated Monthly Payment</p>
                <div className="flex items-baseline justify-center gap-2 mb-3">
                  <span className="font-display text-orange text-5xl md:text-6xl lg:text-7xl uppercase tracking-wider">
                    {formatCurrency(monthlyPayment)}
                  </span>
                  <span className="text-white/20 text-lg font-display uppercase">/mo</span>
                </div>
                <p className="text-white/30 text-sm">
                  Based on {formatCurrency(principal)} financed at {effectiveRate.toFixed(2)}% APR for {selectedTerm.label}
                </p>
                {effectiveRate === 0 && (
                  <div className="inline-flex items-center gap-2 bg-orange/15 border border-orange/30 px-4 py-2 mt-4">
                    <i className="ri-percent-line text-orange text-sm" />
                    <span className="text-orange text-xs font-semibold uppercase tracking-wider">0% Interest — Same-As-Cash</span>
                  </div>
                )}
              </div>

              {/* Breakdown grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-white/5">
                {[
                  { label: 'Project Cost', value: formatCurrency(projectCost), note: 'Total scope' },
                  { label: 'Down Payment', value: formatCurrency(downPayment), note: 'Paid upfront' },
                  { label: 'Amount Financed', value: formatCurrency(principal), note: 'Loan principal', highlight: true },
                  { label: 'Interest Rate', value: `${effectiveRate.toFixed(2)}% APR`, note: `${selectedTerm.label} term`, highlight: true },
                ].map((item) => (
                  <div key={item.label} className={`p-5 md:p-6 bg-charcoal-mid ${item.highlight ? 'bg-charcoal-deep/50' : ''}`}>
                    <p className="text-white/30 text-xs uppercase tracking-wider mb-1">{item.label}</p>
                    <p className={`font-display text-xl tracking-wider ${item.highlight ? 'text-orange' : 'text-white'}`}>{item.value}</p>
                    <p className="text-white/20 text-xs mt-0.5">{item.note}</p>
                  </div>
                ))}
              </div>

              {/* Total cost summary */}
              <div className="p-6 md:p-10">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="border border-white/10 p-6 text-center">
                    <p className="text-white/30 text-xs uppercase tracking-wider mb-2">Total of Payments</p>
                    <p className="font-display text-white text-3xl uppercase tracking-wider">{formatCurrency(totalPaid + downPayment)}</p>
                    <p className="text-white/20 text-xs mt-1">Principal + interest + down payment</p>
                  </div>
                  <div className="border border-white/10 p-6 text-center">
                    <p className="text-white/30 text-xs uppercase tracking-wider mb-2">Total Interest Paid</p>
                    <p className={`font-display text-3xl uppercase tracking-wider ${totalInterest === 0 ? 'text-orange' : 'text-white'}`}>
                      {formatCurrency(totalInterest)}
                    </p>
                    <p className="text-white/20 text-xs mt-1">{totalInterest === 0 ? 'Zero interest — Same-As-Cash' : 'Over the full term'}</p>
                  </div>
                  <div className="border border-orange/20 bg-orange/5 p-6 text-center">
                    <p className="text-orange/60 text-xs uppercase tracking-wider mb-2">Your Bundle Already Saves</p>
                    <p className="font-display text-orange text-3xl uppercase tracking-wider">$800–$4,000</p>
                    <p className="text-orange/40 text-xs mt-1">vs hiring separate contractors</p>
                  </div>
                </div>

                {/* Payment schedule teaser */}
                <div className="bg-charcoal-deep border border-white/10 p-5 md:p-6 mb-8">
                  <p className="text-white text-xs font-semibold uppercase tracking-wider mb-4">Payment Schedule Highlights</p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[
                      { label: 'Payment 1', value: formatCurrency(monthlyPayment), note: 'First payment' },
                      { label: `Payment ${Math.floor(numPayments / 2)}`, value: formatCurrency(monthlyPayment), note: 'Halfway point' },
                      { label: `Payment ${numPayments}`, value: formatCurrency(monthlyPayment), note: 'Final payment' },
                      { label: 'Payoff Date', value: `${new Date(Date.now() + numPayments * 30 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}`, note: 'Estimated' },
                    ].map((item) => (
                      <div key={item.label} className="text-center">
                        <p className="text-white/30 text-xs uppercase tracking-wider mb-1">{item.label}</p>
                        <p className="font-display text-white text-lg tracking-wider">{item.value}</p>
                        <p className="text-white/20 text-xs mt-0.5">{item.note}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Disclaimer + CTAs */}
                <div className="bg-charcoal-deep/50 border border-white/5 p-5 md:p-6 mb-8">
                  <p className="text-white/30 text-xs leading-relaxed">
                    <strong className="text-white/50">This is an estimate only.</strong> Actual APR, monthly payment, and approval depend on your credit profile, income verification, and lender terms. Rates shown are representative for Evansville-area financing partners (GreenSky, Synchrony, EnerBank). Final terms are determined at application. No hard credit check for pre-qualification.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                  <button
                    onClick={() => navigate('/financing')}
                    className="flex-1 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                  >
                    <i className="ri-bank-card-line" />
                    See Full Financing Options
                  </button>
                  <a
                    href="tel:8122135997"
                    className="flex-1 border border-white/20 hover:border-orange text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2"
                  >
                    <i className="ri-phone-line text-orange" />
                    Call 812-213-5997
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Bottom trust line */}
        <div className="max-w-4xl mx-auto mt-8 flex flex-wrap items-center justify-center gap-6 md:gap-10">
          <div className="flex items-center gap-2 text-white/30 text-xs">
            <i className="ri-shield-check-line text-orange" />
            <span>Soft credit check only</span>
          </div>
          <div className="flex items-center gap-2 text-white/30 text-xs">
            <i className="ri-time-line text-orange" />
            <span>Same-day approval available</span>
          </div>
          <div className="flex items-center gap-2 text-white/30 text-xs">
            <i className="ri-lock-line text-orange" />
            <span>No prepayment penalty</span>
          </div>
          <div className="flex items-center gap-2 text-white/30 text-xs">
            <i className="ri-customer-service-2-line text-orange" />
            <span>We help with the application</span>
          </div>
        </div>
      </div>
    </section>
  );
}