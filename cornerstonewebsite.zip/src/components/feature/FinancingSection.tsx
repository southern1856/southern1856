import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const plans = [
  {
    icon: 'ri-percent-line',
    rate: '0%',
    label: 'Interest',
    name: 'Same-As-Cash',
    desc: '12-month plan. Pay nothing extra if paid in full — perfect for smaller jobs.',
    highlight: false,
  },
  {
    icon: 'ri-calendar-line',
    rate: '$89',
    label: '/ Month',
    name: 'Low Monthly',
    desc: 'Up to 120 months. Predictable payments for full roof replacements.',
    highlight: true,
  },
  {
    icon: 'ri-time-line',
    rate: '90',
    label: 'Days No Payment',
    name: 'Deferred',
    desc: 'No payments while your insurance claim processes. Start now, pay later.',
    highlight: false,
  },
];

export default function FinancingSection() {
  const navigate = useNavigate();
  const anim = useScrollAnimation({ threshold: 0.1 });
  const cardsAnim = useScrollAnimation({ threshold: 0.1 });

  return (
    <section id="financing" className="bg-charcoal py-20 md:py-28 overflow-hidden">
      <div className="w-full px-6 md:px-10 lg:px-16">

        {/* Header */}
        <div
          ref={anim.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${anim.isVisible ? 'is-visible' : ''} flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8 mb-14`}
        >
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Flexible Financing</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              Don't Let Cost<br />Stop a Leaking Roof
            </h2>
          </div>
          <p className="text-white/40 text-sm md:text-base leading-relaxed max-w-md lg:text-right">
            A roof that needs replacing costs more every day you wait. We offer plans starting at $89/month so you can fix it now and pay on your terms.
          </p>
        </div>

        {/* Plan Cards */}
        <div
          ref={cardsAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10"
        >
          {plans.map((plan, i) => (
            <div
              key={plan.name}
              className={`anim-fade-up ${cardsAnim.isVisible ? 'is-visible' : ''} relative border p-8 md:p-10 transition-all duration-300 ${
                plan.highlight
                  ? 'border-orange bg-orange/5'
                  : 'border-white/10 bg-charcoal-mid hover:border-white/30'
              }`}
              style={{ transitionDelay: `${i * 120}ms` }}
            >
              {plan.highlight && (
                <div className="absolute top-0 right-0 bg-orange text-white text-xs font-bold uppercase tracking-widest px-3 py-1">
                  Most Popular
                </div>
              )}
              <div className="w-10 h-10 flex items-center justify-center bg-orange/20 text-orange mb-5">
                <i className={`${plan.icon} text-base`} />
              </div>
              <div className="flex items-end gap-1.5 mb-1">
                <span className={`font-display text-5xl uppercase tracking-wider leading-none ${plan.highlight ? 'text-orange' : 'text-white'}`}>
                  {plan.rate}
                </span>
                <span className="text-white/40 text-sm mb-1.5">{plan.label}</span>
              </div>
              <p className="text-white font-semibold text-sm uppercase tracking-widest mb-3">{plan.name}</p>
              <p className="text-white/40 text-sm leading-relaxed">{plan.desc}</p>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className={`anim-fade-up ${cardsAnim.isVisible ? 'is-visible' : ''} flex flex-col md:flex-row items-center justify-between gap-6 border border-white/10 bg-charcoal-mid px-8 py-6`} style={{ transitionDelay: '360ms' }}>
          <div className="flex flex-wrap items-center gap-6 md:gap-10">
            {[
              { icon: 'ri-checkbox-circle-line', text: 'Same-day approval' },
              { icon: 'ri-shield-check-line', text: 'Soft credit check only' },
              { icon: 'ri-file-list-3-line', text: 'No prepayment penalty' },
              { icon: 'ri-customer-service-2-line', text: 'We walk you through it' },
            ].map((item) => (
              <div key={item.text} className="flex items-center gap-2 text-white/50 text-xs uppercase tracking-wider">
                <i className={`${item.icon} text-orange text-sm`} />
                {item.text}
              </div>
            ))}
          </div>
          <button
            onClick={() => navigate('/financing')}
            className="bg-orange hover:bg-orange-dark text-white text-sm font-semibold px-8 py-3.5 uppercase tracking-widest transition-colors duration-200 whitespace-nowrap cursor-pointer flex-shrink-0"
          >
            See All Plans
            <i className="ri-arrow-right-line ml-2" />
          </button>
        </div>

      </div>
    </section>
  );
}
