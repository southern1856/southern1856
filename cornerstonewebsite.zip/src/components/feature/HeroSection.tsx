import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import CountdownTimer from '@/components/feature/CountdownTimer';
import SocialProofPulse from '@/components/feature/SocialProofPulse';
import { OFFERS } from '@/mocks/promotions';

// Compute nearest expiring offer date
const nearestExpiry = OFFERS
  .filter((o) => o.expires)
  .map((o) => o.expires!)
  .sort()[0] || '2026-12-31';

const ACTIVITY_FEED = [
  { name: 'Mike T.', city: 'Evansville', action: 'just booked a free inspection', time: '2 min ago' },
  { name: 'Sarah K.', city: 'Newburgh', action: 'got a free estimate today', time: '8 min ago' },
  { name: 'James R.', city: 'Henderson KY', action: 'approved for $0 down financing', time: '14 min ago' },
  { name: 'Linda M.', city: 'Boonville', action: 'roof replacement completed', time: '1 hr ago' },
  { name: 'Tom W.', city: 'Evansville', action: 'filed insurance claim with us', time: '2 hr ago' },
];

const STATS = [
  { value: 2500, suffix: '+', label: 'Roofs Completed' },
  { value: 25, suffix: '+', label: 'Years Experience' },
  { value: 4.9, suffix: '★', label: 'Google Rating', isDecimal: true },
  { value: 24, suffix: '/7', label: 'Emergency Service' },
];

function useCountUp(target: number, isDecimal: boolean, isVisible: boolean) {
  const [count, setCount] = useState(0);
  const started = useRef(false);

  useEffect(() => {
    if (!isVisible || started.current) return;
    started.current = true;
    const duration = 1800;
    const steps = 60;
    const increment = target / steps;
    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(isDecimal ? Math.round(current * 10) / 10 : Math.floor(current));
      }
    }, duration / steps);
    return () => clearInterval(timer);
  }, [isVisible, target, isDecimal]);

  return count;
}

function StatItem({ stat, isVisible }: { stat: typeof STATS[0]; isVisible: boolean }) {
  const count = useCountUp(stat.value, !!stat.isDecimal, isVisible);
  return (
    <div className="px-4 md:px-10 py-4 md:py-8 border-r border-white/10 last:border-r-0">
      <p className="font-display text-white text-2xl md:text-4xl tracking-wider">
        {stat.isDecimal ? count.toFixed(1) : count.toLocaleString()}{stat.suffix}
      </p>
      <p className="text-white/40 text-[10px] md:text-xs uppercase tracking-widest mt-1">{stat.label}</p>
    </div>
  );
}

export default function HeroSection() {
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bgRef = useRef<HTMLImageElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const [statsVisible, setStatsVisible] = useState(false);
  const [activityIndex, setActivityIndex] = useState(0);
  const [activityVisible, setActivityVisible] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const el = headlineRef.current;
    if (!el) return;
    el.style.opacity = '0';
    el.style.transform = 'translateY(40px)';
    const t = setTimeout(() => {
      el.style.transition = 'opacity 0.9s ease, transform 0.9s ease';
      el.style.opacity = '1';
      el.style.transform = 'translateY(0)';
    }, 100);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const img = bgRef.current;
      if (!img) return;
      img.style.transform = `translateY(${window.scrollY * 0.35}px) scale(1.15)`;
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const el = statsRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) setStatsVisible(true);
    }, { threshold: 0.3 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActivityVisible(false);
      setTimeout(() => {
        setActivityIndex((i) => (i + 1) % ACTIVITY_FEED.length);
        setActivityVisible(true);
      }, 400);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const activity = ACTIVITY_FEED[activityIndex];

  return (
    <section id="home" className="relative min-h-[100dvh] bg-charcoal-deep flex flex-col overflow-hidden">
      {/* Background image with parallax */}
      <div className="absolute inset-0 overflow-hidden">
        <img
          ref={bgRef}
          src="/placeholders/1200x900.svg"
          alt="Roofing Evansville Indiana"
          className="w-full h-full object-cover object-top opacity-30 will-change-transform"
          style={{ transform: 'translateY(0) scale(1.15)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-charcoal-deep/60 via-charcoal-deep/40 to-charcoal-deep" />
        <div className="absolute inset-0 opacity-[0.025]" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '80px 80px' }} />
      </div>

      {/* Logo mark — brand reinforcement */}
      <div className="relative z-10 px-4 md:px-10 lg:px-16 pt-28 md:pt-36">
        <div
          className="inline-flex items-center gap-3 md:gap-4 bg-white/95 backdrop-blur-sm rounded-xl px-4 md:px-6 py-3 md:py-4 shadow-lg"
          style={{
            animation: 'logoMarkIn 0.8s ease 0.2s both',
          }}
        >
          <div className="flex items-center justify-center h-14 w-14 md:h-20 md:w-20 bg-charcoal-deep rounded-lg shrink-0">
            <img
              src="/logo.svg"
              alt="Corner Stone Construction & Roofing"
              className="h-12 w-12 md:h-16 md:w-16 object-contain rounded"
            />
          </div>
          <div className="flex flex-col leading-none">
            <span className="font-display text-charcoal-deep text-xl md:text-3xl tracking-wider uppercase">
              Corner Stone
            </span>
            <span className="text-charcoal-deep/50 text-[0.6rem] md:text-xs tracking-[0.2em] uppercase font-medium mt-0.5">
              Construction & Roofing — Evansville, IN
            </span>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes logoMarkIn {
          from { opacity: 0; transform: translateY(20px) scale(0.95); }
          to   { opacity: 1; transform: translateY(0)     scale(1); }
        }
      `}</style>

      {/* Badge row - fewer on mobile */}
      <div className="relative z-10 flex flex-wrap items-center gap-2 md:gap-3 px-4 md:px-10 lg:px-16 pt-28 md:pt-36">
        <div className="flex items-center gap-1.5 md:gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-3 md:px-4 py-1.5 md:py-2 text-white/60 text-[10px] md:text-xs uppercase tracking-widest">
          <span className="w-1.5 h-1.5 rounded-full bg-orange inline-block" />
          Since 1995
        </div>
        <div className="flex items-center gap-1.5 md:gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-3 md:px-4 py-1.5 md:py-2 text-white/60 text-[10px] md:text-xs uppercase tracking-widest">
          <span className="w-1.5 h-1.5 rounded-full bg-orange inline-block" />
          Evansville, IN
        </div>
        <div className="hidden sm:flex items-center gap-2 border border-white/15 bg-white/5 backdrop-blur-sm px-4 py-2 text-white/60 text-xs uppercase tracking-widest">
          <span className="w-1.5 h-1.5 rounded-full bg-orange inline-block" />
          2,500+ Roofs
        </div>
        <a
          href="/financing"
          onClick={(e) => { e.preventDefault(); navigate('/financing'); }}
          className="hidden md:flex items-center gap-2 border border-orange/60 hover:border-orange bg-orange/10 hover:bg-orange/20 backdrop-blur-sm px-4 py-2 text-orange text-xs uppercase tracking-widest transition-all duration-200 cursor-pointer whitespace-nowrap"
        >
          <i className="ri-bank-card-line text-sm" />
          Financing Available
        </a>
      </div>

      {/* Main headline */}
      <div className="relative z-10 flex-1 flex flex-col justify-center px-4 md:px-10 lg:px-16 py-8 md:py-12">
        <h1
          ref={headlineRef}
          className="font-display text-white leading-none tracking-wider uppercase text-5xl md:text-7xl lg:text-9xl"
        >
          Evansville's
          <br />
          <span className="text-orange">Most Trusted</span>
          <br className="hidden md:block" />
          <span className="md:hidden">Roofers</span><span className="hidden md:inline"> Roofers</span>
        </h1>

        <div className="mt-6 md:mt-10">
          <p className="text-white/60 text-sm md:text-base max-w-sm leading-relaxed">
            Serving Evansville, Newburgh, and Vanderburgh County with expert craftsmanship for over 25 years.
          </p>
          <div className="mt-3 md:mt-4">
            <CountdownTimer expiresAt={nearestExpiry} variant="banner" />
            <div className="mt-3">
              <SocialProofPulse />
            </div>
          </div>
          <div className="mt-4 md:mt-5 flex flex-col sm:flex-row items-start sm:items-center gap-4 md:gap-10">
            <button
              onClick={() => navigate('/estimate')}
              className="group relative bg-orange hover:bg-orange-dark text-white font-semibold px-6 md:px-8 py-3.5 md:py-4 uppercase tracking-widest text-xs md:text-sm transition-all duration-300 whitespace-nowrap cursor-pointer overflow-hidden w-full sm:w-auto text-center"
            >
              <span className="relative z-10 flex items-center justify-center gap-2">
                Free Estimate
                <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform duration-200" />
              </span>
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/30 hover:border-orange hover:bg-orange/10 text-white font-semibold px-6 md:px-8 py-3.5 md:py-4 uppercase tracking-widest text-xs md:text-sm transition-all duration-300 whitespace-nowrap flex items-center justify-center gap-3 w-full sm:w-auto"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>

        {/* Storm damage CTA — compact on mobile */}
        <div className="mt-3 md:mt-4 flex items-center gap-2">
          <button
            onClick={() => navigate('/storm-damage')}
            className="group flex items-center gap-2 bg-red-600/90 hover:bg-red-500 text-white text-[10px] md:text-xs uppercase tracking-widest px-3 md:px-4 py-1.5 md:py-2 transition-all duration-200 cursor-pointer whitespace-nowrap"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
            Storm Damage? Get Help Now
            <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform duration-200" />
          </button>
        </div>

        {/* AI chat prompt - compact */}
        <div className="mt-3 md:mt-6 flex items-center gap-2">
          <button
            onClick={() => {
              const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
              if (btn) btn.click();
            }}
            className="group flex items-center gap-2 text-white/50 hover:text-orange text-[10px] md:text-xs uppercase tracking-widest transition-colors duration-200 cursor-pointer"
          >
            <i className="ri-robot-2-line text-sm group-hover:text-orange transition-colors" />
            Chat with our AI for instant answers
            <i className="ri-arrow-right-line text-xs group-hover:translate-x-1 transition-transform duration-200" />
          </button>
        </div>

        {/* Live activity feed */}
        <div className="mt-6 md:mt-10 flex items-center gap-2 md:gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
            <span className="text-white/60 text-[10px] md:text-xs uppercase tracking-widest">Live</span>
          </div>
          <div
            className="flex items-center gap-1.5 md:gap-2 transition-all duration-400"
            style={{ opacity: activityVisible ? 1 : 0, transform: activityVisible ? 'translateY(0)' : 'translateY(8px)' }}
          >
            <span className="text-white/50 text-[10px] md:text-xs">
              <strong className="text-white/70">{activity.name}</strong> {activity.action}
            </span>
            <span className="text-white/60 text-[10px] md:text-xs hidden sm:inline">{activity.time}</span>
          </div>
        </div>
      </div>

      {/* Bottom stats bar */}
      <div
        ref={statsRef}
        className="relative z-10 border-t border-white/10 grid grid-cols-2 md:grid-cols-4"
      >
        {STATS.map((stat) => (
          <StatItem key={stat.label} stat={stat} isVisible={statsVisible} />
        ))}
      </div>
    </section>
  );
}
