import { useState, useRef, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

type UploadStep = 'upload' | 'analyzing' | 'results';

type DamageItem = {
  label: string;
  severity: 'none' | 'mild' | 'moderate' | 'severe';
  description: string;
};

type AssessmentResult = {
  overallGrade: string;
  overallLabel: string;
  urgency: string;
  estimatedAge: string;
  damages: DamageItem[];
  recommendations: string[];
};

const assessmentDatabase: AssessmentResult[] = [
  {
    overallGrade: 'B+',
    overallLabel: 'Minor Wear Detected',
    urgency: 'Schedule inspection within 3–6 months',
    estimatedAge: '8–12 years old',
    damages: [
      { label: 'Shingle Granule Loss', severity: 'mild', description: 'Minor granule loss visible in valleys and ridge cap area. Common for roofs in this age range.' },
      { label: 'Flashing Condition', severity: 'mild', description: 'Chimney flashing shows slight lifting. No active leaks detected, but re-sealing recommended.' },
      { label: 'Gutter & Downspout', severity: 'none', description: 'Gutters appear clean and properly attached. No sagging or separation visible.' },
      { label: 'Hail Impact Indicators', severity: 'none', description: 'No visible hail strike patterns or dimpled shingles detected in the image.' },
      { label: 'Moss / Algae Growth', severity: 'mild', description: 'Light moss present on north-facing slope. Not urgent but may accelerate wear over time.' },
    ],
    recommendations: [
      'Schedule a professional roof inspection within 3–6 months',
      'Consider gutter cleaning and valley debris removal',
      'Ask your inspector about algae-resistant shingles for future replacement',
    ],
  },
  {
    overallGrade: 'C',
    overallLabel: 'Moderate Concerns Found',
    urgency: 'Inspection recommended within 30 days',
    estimatedAge: '15–20 years old',
    damages: [
      { label: 'Missing / Damaged Shingles', severity: 'moderate', description: 'Several shingles appear cracked or missing in the ridge and edge areas. These are primary water entry points.' },
      { label: 'Shingle Granule Loss', severity: 'moderate', description: 'Significant bald spots visible on multiple shingles. The protective asphalt layer may be exposed.' },
      { label: 'Flashing Condition', severity: 'moderate', description: 'Step flashing around the dormer shows separation gaps. Water intrusion risk during heavy rain.' },
      { label: 'Hail Impact Indicators', severity: 'mild', description: 'A few shingles show subtle dimple patterns. Not definitive without closer inspection but worth documenting.' },
      { label: 'Moss / Algae Growth', severity: 'moderate', description: 'Moderate moss buildup in shaded valleys. Can trap moisture and accelerate shingle decay.' },
    ],
    recommendations: [
      'Schedule a professional inspection within 30 days — water damage risk is elevated',
      'Document all visible damage with photos for potential insurance claim',
      'Consider a full replacement if the roof is over 15 years old with multiple failure points',
    ],
  },
  {
    overallGrade: 'D+',
    overallLabel: 'Significant Wear — Action Needed',
    urgency: 'Schedule inspection within 1–2 weeks',
    estimatedAge: '20–25+ years old',
    damages: [
      { label: 'Missing / Damaged Shingles', severity: 'severe', description: 'Multiple large areas with missing shingles. Underlayment may be exposed to weather.' },
      { label: 'Shingle Granule Loss', severity: 'severe', description: 'Extensive bald patches. The fiberglass mat is visible in several areas — the roof is near end of life.' },
      { label: 'Flashing Condition', severity: 'moderate', description: 'Valley flashing is rusted and pulling away. This is a critical leak pathway during storms.' },
      { label: 'Hail Impact Indicators', severity: 'moderate', description: 'Visible strike marks on ridge cap and vent areas. Likely qualifies for insurance coverage.' },
      { label: 'Moss / Algae Growth', severity: 'severe', description: 'Heavy moss and algae coverage on multiple slopes. May indicate prolonged moisture retention.' },
    ],
    recommendations: [
      'Book an emergency inspection within 1–2 weeks — water damage risk is high',
      'File an insurance claim — hail and storm damage may be covered',
      'Plan for a full roof replacement; repair-only may be a short-term patch',
    ],
  },
  {
    overallGrade: 'A-',
    overallLabel: 'Good Condition — Monitor',
    urgency: 'Routine annual inspection sufficient',
    estimatedAge: '3–7 years old',
    damages: [
      { label: 'Shingle Granule Loss', severity: 'none', description: 'Granule layer appears intact and uniform. No wear patterns visible.' },
      { label: 'Flashing Condition', severity: 'none', description: 'All flashing is sealed and properly seated. No gaps or rust visible.' },
      { label: 'Gutter & Downspout', severity: 'mild', description: 'Minor leaf debris in gutters. Not a roof issue but worth cleaning to prevent overflow.' },
      { label: 'Hail Impact Indicators', severity: 'none', description: 'No hail damage patterns visible. Shingle surfaces are smooth and uniform.' },
      { label: 'Moss / Algae Growth', severity: 'none', description: 'No biological growth visible. Roof has good sun exposure and drainage.' },
    ],
    recommendations: [
      'Continue annual inspections to maintain this condition',
      'Clean gutters twice a year to prevent water backup',
      'Keep tree branches trimmed back from the roof surface',
    ],
  },
];

const severityConfig: Record<string, { color: string; bg: string; label: string }> = {
  none: { color: 'text-emerald-400', bg: 'bg-emerald-400/10 border-emerald-400/20', label: 'Good' },
  mild: { color: 'text-amber-400', bg: 'bg-amber-400/10 border-amber-400/20', label: 'Mild' },
  moderate: { color: 'text-orange-400', bg: 'bg-orange-400/10 border-orange-400/20', label: 'Moderate' },
  severe: { color: 'text-red-400', bg: 'bg-red-400/10 border-red-400/20', label: 'Severe' },
};

const gradeColor: Record<string, string> = {
  'A-': 'text-emerald-400',
  'B+': 'text-emerald-300',
  'C': 'text-amber-400',
  'D+': 'text-orange-400',
};

interface AIRoofInspectorProps {
  onAnalysisComplete?: () => void;
}

export default function AIRoofInspector({ onAnalysisComplete }: AIRoofInspectorProps) {
  const [step, setStep] = useState<UploadStep>('upload');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [result, setResult] = useState<AssessmentResult | null>(null);
  const [progress, setProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const sectionAnim = useScrollAnimation({ threshold: 0.05 });

  // Track when analysis completes
  useEffect(() => {
    if (step === 'results' && result && onAnalysisComplete) {
      onAnalysisComplete();
    }
  }, [step, result, onAnalysisComplete]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setUploadedImage(reader.result as string);
      startAnalysis();
    };
    reader.readAsDataURL(file);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setUploadedImage(reader.result as string);
      startAnalysis();
    };
    reader.readAsDataURL(file);
  }, []);

  const startAnalysis = () => {
    setStep('analyzing');
    setProgress(0);
    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(interval);
          const randomResult = assessmentDatabase[Math.floor(Math.random() * assessmentDatabase.length)];
          setResult(randomResult);
          setStep('results');
          return 100;
        }
        return p + Math.random() * 15 + 5;
      });
    }, 300);
  };

  const handleReset = () => {
    setStep('upload');
    setUploadedImage(null);
    setResult(null);
    setProgress(0);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const openWidget = () => {
    const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
    if (btn) btn.click();
  };

  return (
    <section id="ai-inspector" className="bg-warm-beige py-20 md:py-28 px-6 md:px-10 lg:px-16">
      <div
        ref={sectionAnim.ref as React.RefObject<HTMLDivElement>}
        className={`anim-fade-up ${sectionAnim.isVisible ? 'is-visible' : ''}`}
      >
        {/* Header */}
        <div className="text-center mb-12 md:mb-16">
          <div className="inline-flex items-center gap-2 border border-orange/30 bg-orange/5 px-4 py-2 mb-5">
            <i className="ri-robot-2-line text-orange text-sm" />
            <span className="text-orange text-xs font-semibold uppercase tracking-[0.25em]">AI-Powered</span>
          </div>
          <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            AI Roof<br /><span className="text-orange">Inspector</span>
          </h2>
          <p className="text-charcoal-mid/50 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Snap a photo of your roof from the ground or driveway and get an instant AI damage assessment — no ladder, no risk, no waiting.
          </p>
        </div>

        {/* Main card */}
        <div className="max-w-3xl mx-auto bg-white border border-charcoal/5 overflow-hidden">
          {/* Step: Upload */}
          {step === 'upload' && (
            <div className="p-8 md:p-12">
              <div className="text-center mb-8">
                <div className="w-16 h-16 flex items-center justify-center bg-charcoal-deep text-orange mx-auto mb-5">
                  <i className="ri-camera-line text-2xl" />
                </div>
                <h3 className="font-display text-charcoal-deep text-xl uppercase tracking-wider mb-2">Upload a Roof Photo</h3>
                <p className="text-charcoal-mid/40 text-sm">Take the photo from your driveway or yard — the AI works best with a clear view of the full roof slope.</p>
              </div>

              <div
                onClick={() => fileInputRef.current?.click()}
                onDrop={handleDrop}
                onDragOver={(e) => e.preventDefault()}
                className="border-2 border-dashed border-charcoal/15 hover:border-orange/40 bg-warm-beige/50 hover:bg-orange/5 transition-all duration-300 p-10 md:p-14 text-center cursor-pointer"
              >
                <div className="w-12 h-12 flex items-center justify-center bg-charcoal-deep/5 text-charcoal-mid/30 mx-auto mb-4">
                  <i className="ri-upload-cloud-2-line text-xl" />
                </div>
                <p className="text-charcoal-deep font-semibold text-sm mb-1">Click or drag & drop a photo here</p>
                <p className="text-charcoal-mid/30 text-xs">JPG, PNG, WEBP — up to 10MB</p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileSelect}
                  className="hidden"
                />
              </div>

              <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4">
                {[
                  { icon: 'ri-time-line', title: 'Under 30 seconds', desc: 'Instant results' },
                  { icon: 'ri-shield-check-line', title: 'No contact required', desc: '100% anonymous' },
                  { icon: 'ri-user-smile-line', title: '2,500+ roofs analyzed', desc: 'Trained on real data' },
                ].map((item) => (
                  <div key={item.title} className="flex items-start gap-3">
                    <div className="w-8 h-8 flex items-center justify-center bg-charcoal-deep text-orange flex-shrink-0">
                      <i className={`${item.icon} text-sm`} />
                    </div>
                    <div>
                      <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider">{item.title}</p>
                      <p className="text-charcoal-mid/40 text-xs">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              <p className="text-charcoal-mid/25 text-xs text-center mt-8">
                <i className="ri-information-line text-xs mr-1" />
                This is an AI estimate for informational purposes only. A professional inspection is required for insurance or repair decisions.
              </p>
            </div>
          )}

          {/* Step: Analyzing */}
          {step === 'analyzing' && uploadedImage && (
            <div className="p-8 md:p-12">
              <div className="flex flex-col md:flex-row gap-8">
                {/* Image preview */}
                <div className="w-full md:w-72 flex-shrink-0">
                  <img src={uploadedImage} alt="Uploaded roof" className="w-full h-56 object-cover border border-charcoal/5" />
                </div>

                {/* Analysis animation */}
                <div className="flex-1 flex flex-col justify-center">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-10 h-10 flex items-center justify-center bg-orange/10 text-orange">
                      <i className="ri-robot-2-line text-lg animate-pulse" />
                    </div>
                    <div>
                      <p className="font-display text-charcoal-deep text-lg uppercase tracking-wider">Analyzing Your Roof...</p>
                      <p className="text-charcoal-mid/40 text-xs mt-0.5">Scanning shingles, flashing, and wear patterns</p>
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full h-1.5 bg-charcoal/5 mb-6">
                    <div
                      className="h-full bg-orange transition-all duration-300"
                      style={{ width: `${Math.min(progress, 100)}%` }}
                    />
                  </div>

                  {/* Analysis steps */}
                  <div className="space-y-3">
                    {[
                      { label: 'Detecting roof slope & pitch', at: 15 },
                      { label: 'Analyzing shingle condition', at: 35 },
                      { label: 'Checking flashing & valleys', at: 55 },
                      { label: 'Scanning for hail impact marks', at: 70 },
                      { label: 'Evaluating moss & algae growth', at: 85 },
                      { label: 'Generating assessment report', at: 95 },
                    ].map((stepItem) => (
                      <div key={stepItem.label} className="flex items-center gap-3">
                        <div className={`w-5 h-5 flex items-center justify-center transition-all duration-300 ${progress >= stepItem.at ? 'bg-orange text-white' : 'bg-charcoal/5 text-charcoal-mid/20'}`}>
                          <i className={`${progress >= stepItem.at ? 'ri-check-line' : 'ri-loader-4-line animate-spin'} text-xs`} />
                        </div>
                        <span className={`text-xs transition-colors duration-300 ${progress >= stepItem.at ? 'text-charcoal-deep font-medium' : 'text-charcoal-mid/25'}`}>
                          {stepItem.label}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step: Results */}
          {step === 'results' && result && (
            <div className="p-8 md:p-12">
              {/* Result header */}
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8 pb-8 border-b border-charcoal/5">
                <div className="flex items-center gap-5">
                  <div className={`w-20 h-20 flex items-center justify-center bg-charcoal-deep ${gradeColor[result.overallGrade]}`}>
                    <span className="font-display text-3xl tracking-wider">{result.overallGrade}</span>
                  </div>
                  <div>
                    <h3 className="font-display text-charcoal-deep text-xl uppercase tracking-wider">{result.overallLabel}</h3>
                    <p className="text-charcoal-mid/50 text-sm mt-1">Estimated age: {result.estimatedAge}</p>
                  </div>
                </div>
                <div className="flex-shrink-0">
                  <span className="inline-flex items-center gap-2 bg-orange/10 border border-orange/20 text-orange text-xs font-semibold px-4 py-2 uppercase tracking-wider">
                    <i className="ri-alarm-warning-line" />
                    {result.urgency}
                  </span>
                </div>
              </div>

              {/* Damage breakdown */}
              <div className="mb-8">
                <h4 className="font-display text-charcoal-deep text-sm uppercase tracking-widest mb-5">Damage Breakdown</h4>
                <div className="space-y-4">
                  {result.damages.map((damage) => {
                    const config = severityConfig[damage.severity];
                    return (
                      <div key={damage.label} className={`border ${config.bg} p-4 md:p-5`}>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-charcoal-deep text-sm font-semibold">{damage.label}</span>
                          <span className={`text-xs font-bold uppercase tracking-wider ${config.color}`}>{config.label}</span>
                        </div>
                        <p className="text-charcoal-mid/50 text-xs leading-relaxed">{damage.description}</p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Recommendations */}
              <div className="bg-warm-beige border border-charcoal/5 p-6 md:p-8 mb-8">
                <h4 className="font-display text-charcoal-deep text-sm uppercase tracking-widest mb-5 flex items-center gap-2">
                  <i className="ri-lightbulb-line text-orange" />
                  AI Recommendations
                </h4>
                <ul className="space-y-3">
                  {result.recommendations.map((rec, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <div className="w-5 h-5 flex items-center justify-center bg-orange text-white flex-shrink-0 mt-0.5">
                        <span className="text-xs font-bold">{i + 1}</span>
                      </div>
                      <span className="text-charcoal-mid/60 text-sm leading-relaxed">{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Disclaimers */}
              <div className="border-t border-charcoal/5 pt-6 mb-8">
                <p className="text-charcoal-mid/30 text-xs leading-relaxed">
                  <strong className="text-charcoal-mid/50">Disclaimer:</strong> This assessment is generated by AI based on visual analysis of your uploaded photo. It cannot detect hidden damage, leaks, or structural issues that require physical inspection. For insurance claims, warranty decisions, or repair scheduling, a licensed roofing professional must perform an on-site inspection. Corner Stone Construction & Roofing offers free, no-obligation inspections throughout Evansville and the Tri-State area.
                </p>
              </div>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <button
                  onClick={openWidget}
                  className="flex-1 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                >
                  <i className="ri-calendar-check-line" />
                  Book Free Inspection
                </button>
                <button
                  onClick={handleReset}
                  className="flex-1 border border-charcoal/20 hover:border-charcoal-deep text-charcoal-deep font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                >
                  <i className="ri-restart-line" />
                  Analyze Another Photo
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Trust badges */}
        <div className="max-w-3xl mx-auto mt-8 flex flex-wrap items-center justify-center gap-6 md:gap-10">
          <div className="flex items-center gap-2 text-charcoal-mid/40 text-xs">
            <i className="ri-shield-check-line text-orange" />
            <span>Free professional inspection available</span>
          </div>
          <div className="flex items-center gap-2 text-charcoal-mid/40 text-xs">
            <i className="ri-file-list-3-line text-orange" />
            <span>Detailed photo report included</span>
          </div>
          <div className="flex items-center gap-2 text-charcoal-mid/40 text-xs">
            <i className="ri-phone-line text-orange" />
            <span>Results in 30 seconds, 24/7</span>
          </div>
        </div>
      </div>
    </section>
  );
}