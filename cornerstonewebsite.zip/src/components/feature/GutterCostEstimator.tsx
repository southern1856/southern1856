import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

type HomeSize = {
  key: string;
  label: string;
  sqft: string;
  linearFt: string;
  baseMin: number;
  baseMax: number;
};

type Material = {
  key: string;
  label: string;
  multiplier: number;
  icon: string;
  desc: string;
  lifespan: string;
};

const homeSizes: HomeSize[] = [
  { key: 'small', label: 'Small Home', sqft: '1,000 – 1,400 sq ft', linearFt: '~100–140 linear ft of gutters', baseMin: 1000, baseMax: 1700 },
  { key: 'medium', label: 'Medium Home', sqft: '1,500 – 2,200 sq ft', linearFt: '~150–200 linear ft of gutters', baseMin: 1500, baseMax: 2500 },
  { key: 'large', label: 'Large Home', sqft: '2,300 – 3,200 sq ft', linearFt: '~220–300 linear ft of gutters', baseMin: 2200, baseMax: 3600 },
  { key: 'xlarge', label: 'Extra Large', sqft: '3,300+ sq ft', linearFt: '~320+ linear ft of gutters', baseMin: 3000, baseMax: 5000 },
];

const materials: Material[] = [
  { key: 'aluminum', label: 'Seamless Aluminum', multiplier: 1.0, icon: 'ri-drop-line', desc: 'Best value — rust-proof, 30+ colors, same-day install', lifespan: '20–30 yrs' },
  { key: 'aluminum-guards', label: 'Aluminum + Guards', multiplier: 1.65, icon: 'ri-shield-star-line', desc: 'Never clean again — micro-mesh keeps all debris out', lifespan: '20–30 yrs' },
  { key: 'copper', label: 'Copper Gutters', multiplier: 2.8, icon: 'ri-vip-crown-line', desc: 'Premium heirloom quality — develops stunning patina', lifespan: '50–100 yrs' },
  { key: 'copper-guards', label: 'Copper + Guards', multiplier: 3.5, icon: 'ri-vip-diamond-line', desc: 'The ultimate system — copper beauty, zero maintenance', lifespan: '50–100 yrs' },
];

function formatCurrency(n: number) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(n);
}

export default function GutterCostEstimator() {
  const navigate = useNavigate();
  const sectionAnim = useScrollAnimation({ threshold: 0.06 });
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [selectedSize, setSelectedSize] = useState<HomeSize | null>(null);
  const [selectedMaterial, setSelectedMaterial] = useState<Material | null>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  const handleSizeSelect = (size: HomeSize) => {
    setSelectedSize(size);
    setStep(2);
  };

  const handleMaterialSelect = (mat: Material) => {
    setSelectedMaterial(mat);
    setStep(3);
    setTimeout(() => {
      resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);
  };

  const handleReset = () => {
    setStep(1);
    setSelectedSize(null);
    setSelectedMaterial(null);
  };

  const minPrice = selectedSize && selectedMaterial ? Math.round(selectedSize.baseMin * selectedMaterial.multiplier) : 0;
  const maxPrice = selectedSize && selectedMaterial ? Math.round(selectedSize.baseMax * selectedMaterial.multiplier) : 0;
  const avgPrice = Math.round((minPrice + maxPrice) / 2);

  return (
    <section id="gutter-estimator" className="bg-warm-beige py-20 md:py-28 px-6 md:px-10 lg:px-16">
      <div
        ref={sectionAnim.ref as React.RefObject<HTMLDivElement>}
        className={`anim-fade-up ${sectionAnim.isVisible ? 'is-visible' : ''}`}
      >
        {/* Header */}
        <div className="text-center mb-12 md:mb-16">
          <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Quick & Free</p>
          <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
            Gutter Cost<br /><span className="text-orange">Estimator</span>
          </h2>
          <p className="text-charcoal-mid/50 text-sm md:text-base max-w-xl mx-auto leading-relaxed">
            Get an instant ballpark range for your gutter replacement in under 30 seconds. No email required.
          </p>
        </div>

        {/* Main estimator card */}
        <div className="max-w-4xl mx-auto bg-white border border-charcoal/5 overflow-hidden">
          {/* Progress bar */}
          <div className="flex items-center bg-charcoal-deep px-6 md:px-10 py-5">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center flex-1">
                <div className={`w-8 h-8 flex items-center justify-center text-xs font-bold uppercase tracking-wider transition-colors ${s <= step ? 'bg-orange text-white' : 'bg-white/10 text-white/30'}`}>
                  {s}
                </div>
                <span className={`ml-3 text-xs font-semibold uppercase tracking-wider hidden sm:block transition-colors ${s <= step ? 'text-white' : 'text-white/30'}`}>
                  {s === 1 ? 'Home Size' : s === 2 ? 'Material' : 'Your Estimate'}
                </span>
                {s < 3 && (
                  <div className="flex-1 h-px mx-3 md:mx-4 bg-white/10">
                    <div className={`h-full bg-orange transition-all duration-500 ${s < step ? 'w-full' : 'w-0'}`} />
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Step 1: Home Size */}
          {step === 1 && (
            <div className="p-6 md:p-10">
              <h3 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider mb-2">Select Your Home Size</h3>
              <p className="text-charcoal-mid/40 text-sm mb-8">Pick the option closest to your home&apos;s footprint (living area sq ft).</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {homeSizes.map((size) => (
                  <button
                    key={size.key}
                    onClick={() => handleSizeSelect(size)}
                    className="group text-left p-5 md:p-6 border border-charcoal/10 hover:border-orange hover:bg-orange/5 transition-all duration-200 cursor-pointer"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className="font-display text-charcoal-deep text-lg uppercase tracking-wide">{size.label}</span>
                      <div className="w-8 h-8 flex items-center justify-center border border-charcoal/10 group-hover:border-orange group-hover:bg-orange group-hover:text-white transition-all">
                        <i className="ri-arrow-right-line text-sm" />
                      </div>
                    </div>
                    <p className="text-charcoal-mid/50 text-sm">{size.sqft}</p>
                    <p className="text-charcoal-mid/30 text-xs mt-1">{size.linearFt}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Material */}
          {step === 2 && (
            <div className="p-6 md:p-10">
              <div className="flex items-center gap-3 mb-2">
                <button
                  onClick={() => { setStep(1); setSelectedSize(null); }}
                  className="text-charcoal-mid/40 hover:text-orange text-xs uppercase tracking-wider flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <i className="ri-arrow-left-line" /> Back
                </button>
              </div>
              <h3 className="font-display text-charcoal-deep text-xl md:text-2xl uppercase tracking-wider mb-2">Choose Your Material</h3>
              <p className="text-charcoal-mid/40 text-sm mb-8">{selectedSize?.label} selected. Pick the gutter system you&apos;re considering.</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {materials.map((mat) => (
                  <button
                    key={mat.key}
                    onClick={() => handleMaterialSelect(mat)}
                    className="group text-left p-5 md:p-6 border border-charcoal/10 hover:border-orange hover:bg-orange/5 transition-all duration-200 cursor-pointer"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 flex items-center justify-center bg-charcoal-deep text-white group-hover:bg-orange transition-colors">
                          <i className={`${mat.icon} text-base`} />
                        </div>
                        <span className="font-display text-charcoal-deep text-lg uppercase tracking-wide">{mat.label}</span>
                      </div>
                      <div className="w-8 h-8 flex items-center justify-center border border-charcoal/10 group-hover:border-orange group-hover:bg-orange group-hover:text-white transition-all flex-shrink-0">
                        <i className="ri-arrow-right-line text-sm" />
                      </div>
                    </div>
                    <p className="text-charcoal-mid/50 text-sm">{mat.desc}</p>
                    <p className="text-charcoal-mid/30 text-xs mt-1">Lifespan: {mat.lifespan}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 3: Result */}
          {step === 3 && selectedSize && selectedMaterial && (
            <div className="p-6 md:p-10" ref={resultRef}>
              <div className="flex items-center gap-3 mb-6">
                <button
                  onClick={handleReset}
                  className="text-charcoal-mid/40 hover:text-orange text-xs uppercase tracking-wider flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <i className="ri-restart-line" /> Start Over
                </button>
              </div>

              {/* Selected summary */}
              <div className="flex flex-wrap gap-2 mb-8">
                <span className="inline-flex items-center gap-1.5 bg-charcoal-deep text-white text-xs font-semibold px-3 py-1.5 uppercase tracking-wider">
                  <i className="ri-home-4-line text-xs" />
                  {selectedSize.label}
                </span>
                <span className="inline-flex items-center gap-1.5 bg-orange text-white text-xs font-semibold px-3 py-1.5 uppercase tracking-wider">
                  <i className={`${selectedMaterial.icon} text-xs`} />
                  {selectedMaterial.label}
                </span>
              </div>

              {/* Price display */}
              <div className="bg-charcoal-deep p-8 md:p-10 text-center mb-8">
                <p className="text-white/30 text-xs font-semibold uppercase tracking-[0.25em] mb-4">Estimated Ballpark Range</p>
                <div className="flex items-baseline justify-center gap-3 mb-2">
                  <span className="font-display text-orange text-4xl md:text-5xl lg:text-6xl uppercase tracking-wider">{formatCurrency(minPrice)}</span>
                  <span className="text-white/20 text-lg md:text-xl font-display uppercase">–</span>
                  <span className="font-display text-orange text-4xl md:text-5xl lg:text-6xl uppercase tracking-wider">{formatCurrency(maxPrice)}</span>
                </div>
                <p className="text-white/30 text-sm mt-2">
                  Average for your selection: <span className="text-white font-semibold">{formatCurrency(avgPrice)}</span>
                </p>
              </div>

              {/* Fine print */}
              <div className="bg-warm-beige border border-charcoal/5 p-5 md:p-6 mb-8">
                <p className="text-charcoal-mid/40 text-xs leading-relaxed">
                  <strong className="text-charcoal-mid">This is a ballpark estimate only.</strong> Final pricing depends on home height (one vs two story), fascia board condition (rotted wood adds cost), number of downspouts, underground drainage needs, gutter size (5&quot; vs 6&quot;), and site accessibility. For an accurate, written estimate, schedule a free in-person inspection — no obligation, no pressure.
                </p>
              </div>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <button
                  onClick={() => navigate('/estimate')}
                  className="flex-1 bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                >
                  Get a Real Estimate
                  <i className="ri-arrow-right-line" />
                </button>
                <a
                  href="tel:8122135997"
                  className="flex-1 border border-charcoal/20 hover:border-charcoal-deep text-charcoal-deep font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap flex items-center justify-center gap-2"
                >
                  <i className="ri-phone-line text-orange" />
                  Call 812-213-5997
                </a>
              </div>

              {/* Why the range varies */}
              <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4">
                {[
                  { icon: 'ri-building-line', title: 'Home Height', desc: 'Two-story homes require taller ladders, more labor time, and sometimes lifts — increasing cost.' },
                  { icon: 'ri-hammer-line', title: 'Fascia Board Condition', desc: 'Rotted fascia behind old gutters must be replaced before new gutters can be properly hung.' },
                  { icon: 'ri-drop-line', title: 'Downspouts & Drainage', desc: 'Extra downspouts, underground extensions, and splash blocks add material and labor.' },
                ].map((item) => (
                  <div key={item.title} className="flex items-start gap-3">
                    <div className="w-8 h-8 flex items-center justify-center bg-charcoal-deep text-orange flex-shrink-0">
                      <i className={`${item.icon} text-sm`} />
                    </div>
                    <div>
                      <p className="text-charcoal-deep text-xs font-semibold uppercase tracking-wider mb-0.5">{item.title}</p>
                      <p className="text-charcoal-mid/40 text-xs leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Bottom trust line */}
        <div className="max-w-4xl mx-auto mt-8 flex flex-wrap items-center justify-center gap-6 md:gap-10">
          <div className="flex items-center gap-2 text-charcoal-mid/40 text-xs">
            <i className="ri-shield-check-line text-orange" />
            <span>Based on Evansville-area pricing</span>
          </div>
          <div className="flex items-center gap-2 text-charcoal-mid/40 text-xs">
            <i className="ri-time-line text-orange" />
            <span>Updated April 2026</span>
          </div>
          <div className="flex items-center gap-2 text-charcoal-mid/40 text-xs">
            <i className="ri-lock-line text-orange" />
            <span>No email or phone required</span>
          </div>
        </div>
      </div>
    </section>
  );
}