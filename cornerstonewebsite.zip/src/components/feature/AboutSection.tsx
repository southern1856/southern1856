import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

export default function AboutSection() {
  const navigate = useNavigate();
  const stats = useScrollAnimation({ threshold: 0.1 });
  const image = useScrollAnimation({ threshold: 0.1 });
  const content = useScrollAnimation({ threshold: 0.1 });

  const statsData = [
    { number: '2,500+', label: 'Roofs Installed', desc: 'From cozy homes to large commercial builds across Evansville' },
    { number: '1,000+', label: 'Repairs Completed', desc: 'Fast, reliable, and leak-proof — just how repairs should be' },
    { number: '25+', label: 'Years in Business', desc: 'Serving Evansville and Vanderburgh County since 1995' },
  ];

  const benefits = [
    'Every roof we build is made to fit your home — not some template.',
    'We live here too, so we treat your home like our own.',
    'From your first call to final cleanup, you speak with real people who know roofs.',
    'From hidden damage to tiny leaks — we catch the small stuff before it becomes big.',
  ];

  return (
    <section id="about" className="bg-charcoal-deep overflow-hidden">
      {/* Stats strip */}
      <div
        ref={stats.ref as React.RefObject<HTMLDivElement>}
        className="border-b border-white/10 grid grid-cols-1 md:grid-cols-3"
      >
        {statsData.map((stat, i) => (
          <div
            key={stat.label}
            className={`px-8 md:px-12 py-10 md:py-14 anim-fade-up ${i < 2 ? 'border-b md:border-b-0 md:border-r border-white/10' : ''} ${stats.isVisible ? 'is-visible' : ''}`}
            style={{ transitionDelay: `${i * 150}ms` }}
          >
            <div className="flex items-end gap-2 mb-2">
              <span className="font-display text-white leading-none tracking-wider" style={{ fontSize: 'clamp(2.5rem, 5vw, 4rem)' }}>{stat.number}</span>
            </div>
            <p className="font-serif font-bold text-white/80 text-lg mb-1">{stat.label}</p>
            <p className="text-white/40 text-sm leading-relaxed">{stat.desc}</p>
          </div>
        ))}
      </div>

      {/* Main about content */}
      <div className="flex flex-col lg:flex-row">
        {/* Left image */}
        <div
          ref={image.ref as React.RefObject<HTMLDivElement>}
          className={`w-full lg:w-1/2 relative min-h-[400px] md:min-h-[600px] anim-fade-left ${image.isVisible ? 'is-visible' : ''}`}
        >
          <img
            src="/placeholders/800x600.svg"
            alt="Corner Stone Construction & Roofing team Evansville Indiana"
            className="absolute inset-0 w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-transparent to-charcoal-deep/60" />
          {/* Floating badge */}
          <div className="absolute bottom-8 left-8 bg-orange px-6 py-4">
            <p className="font-display text-white text-3xl tracking-wider">25+</p>
            <p className="text-white/80 text-xs uppercase tracking-widest">Years in Evansville</p>
          </div>
        </div>

        {/* Right content */}
        <div
          ref={content.ref as React.RefObject<HTMLDivElement>}
          className={`w-full lg:w-1/2 px-8 md:px-12 lg:px-16 py-16 md:py-20 flex flex-col justify-center anim-fade-right ${content.isVisible ? 'is-visible' : ''}`}
        >
          <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">About Us</p>
          <h2 className="font-display text-white uppercase tracking-wider leading-none mb-8" style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
            Serving Roofs<br />Since 1995
          </h2>
          <p className="text-white/50 text-sm md:text-base leading-relaxed mb-8">
            We're a family-run roofing company that's been keeping Evansville homes dry and happy since 1995. Whether it's a sneaky leak or a full roof makeover, we show up with tools in hand, smiles on our faces, and zero drama. Great work, fair prices, and roofs that last — that's how we roll.
          </p>

          {/* Benefits list */}
          <div className="space-y-4 mb-10">
            {benefits.map((b, i) => (
              <div
                key={b}
                className={`flex items-start gap-4 anim-fade-up ${content.isVisible ? 'is-visible' : ''}`}
                style={{ transitionDelay: `${200 + i * 100}ms` }}
              >
                <div className="w-5 h-5 flex-shrink-0 flex items-center justify-center border border-orange/50 mt-0.5">
                  <i className="ri-check-line text-orange text-xs" />
                </div>
                <p className="text-white/60 text-sm leading-relaxed">{b}</p>
              </div>
            ))}
          </div>

          <button
            onClick={() => navigate('/about')}
            className="self-start bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap cursor-pointer flex items-center gap-3"
          >
            Our Full Story
            <i className="ri-arrow-right-line" />
          </button>
        </div>
      </div>
    </section>
  );
}