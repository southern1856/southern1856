import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

export interface ProcessStep {
  num: string;
  icon: string;
  title: string;
  desc: string;
  detail?: string;
}

interface ServiceProcessStripProps {
  heading: string;
  subheading: string;
  steps: ProcessStep[];
  ctaText: string;
  ctaSubtext?: string;
  buttonText: string;
  buttonHref?: string;
  onButtonClick?: () => void;
}

export default function ServiceProcessStrip({
  heading,
  subheading,
  steps,
  ctaText,
  ctaSubtext = 'Free inspection · No pressure · Tri-State area',
  buttonText,
  buttonHref,
  onButtonClick,
}: ServiceProcessStripProps) {
  const navigate = useNavigate();
  const header = useScrollAnimation({ threshold: 0.1 });
  const stepsAnim = useScrollAnimation({ threshold: 0.05 });
  const cta = useScrollAnimation({ threshold: 0.1 });

  const handleClick = () => {
    if (onButtonClick) {
      onButtonClick();
      return;
    }
    if (buttonHref?.startsWith('#')) {
      const el = document.querySelector(buttonHref);
      el?.scrollIntoView({ behavior: 'smooth' });
      return;
    }
    if (buttonHref) {
      navigate(buttonHref);
    }
  };

  return (
    <section className="bg-charcoal py-20 md:py-28 overflow-hidden">
      <div className="w-full px-6 md:px-10 lg:px-16">
        {/* Header */}
        <div
          ref={header.ref as React.RefObject<HTMLDivElement>}
          className={`flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16 md:mb-20 anim-fade-up ${header.isVisible ? 'is-visible' : ''}`}
        >
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">{heading}</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
              {subheading.split('\n').map((line, i) => (
                <span key={i}>
                  {line}
                  {i < subheading.split('\n').length - 1 && <br />}
                </span>
              ))}
            </h2>
          </div>
          <p className="text-white/40 text-sm md:text-base max-w-xs leading-relaxed">
            {ctaSubtext}
          </p>
        </div>

        {/* Steps */}
        <div
          ref={stepsAnim.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4"
        >
          {steps.map((step, i) => (
            <div
              key={step.num}
              className={`relative border border-white/10 bg-charcoal-mid p-8 md:p-10 group hover:border-orange/40 transition-all duration-300 anim-fade-up ${stepsAnim.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 120}ms` }}
            >
              {/* Connector line (desktop) */}
              {i < steps.length - 1 && (
                <div className="hidden lg:block absolute top-10 -right-2 w-4 h-px bg-white/10 z-10" />
              )}

              {/* Step number */}
              <div className="flex items-center justify-between mb-8">
                <span className="font-display text-white/10 text-6xl leading-none tracking-wider group-hover:text-orange/20 transition-colors duration-300">
                  {step.num}
                </span>
                <div className="w-12 h-12 flex items-center justify-center border border-white/10 group-hover:border-orange group-hover:bg-orange/10 transition-all duration-300">
                  <i className={`${step.icon} text-white/40 group-hover:text-orange text-xl transition-colors duration-300`} />
                </div>
              </div>

              <h3 className="font-display text-white text-2xl uppercase tracking-wider mb-3 group-hover:text-orange transition-colors duration-300">
                {step.title}
              </h3>
              <p className="text-white/50 text-sm leading-relaxed mb-4">{step.desc}</p>
              {step.detail && (
                <p className="text-orange/70 text-xs leading-relaxed border-t border-white/5 pt-4">
                  <i className="ri-check-line mr-1" />
                  {step.detail}
                </p>
              )}
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div
          ref={cta.ref as React.RefObject<HTMLDivElement>}
          className={`mt-12 flex flex-col sm:flex-row items-center justify-between gap-6 border border-white/10 bg-charcoal-mid px-8 py-6 anim-fade-up ${cta.isVisible ? 'is-visible' : ''}`}
        >
          <div>
            <p className="text-white font-semibold text-lg">{ctaText}</p>
            <p className="text-white/40 text-sm mt-1">{ctaSubtext}</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 flex-shrink-0">
            <button
              onClick={handleClick}
              className="bg-orange hover:bg-orange-dark text-white text-sm font-bold px-8 py-4 uppercase tracking-widest transition-colors duration-200 whitespace-nowrap cursor-pointer"
            >
              {buttonText}
            </button>
            <a
              href="tel:8122135997"
              className="border border-white/20 hover:border-orange text-white/70 hover:text-white text-sm font-semibold px-8 py-4 uppercase tracking-widest transition-all duration-200 whitespace-nowrap flex items-center justify-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}