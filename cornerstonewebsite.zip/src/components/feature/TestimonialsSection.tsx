import { useState, useRef, useEffect } from 'react';
import { testimonials } from '@/mocks/testimonials';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import GoogleReviewsBadge from './GoogleReviewsBadge';

export default function TestimonialsSection() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [animating, setAnimating] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const header = useScrollAnimation();
  const body = useScrollAnimation({ threshold: 0.1 });

  const goTo = (index: number) => {
    if (animating || index === activeIndex) return;
    setAnimating(true);
    setTimeout(() => {
      setActiveIndex(index);
      setAnimating(false);
    }, 250);
  };

  const goNext = () => goTo((activeIndex + 1) % testimonials.length);
  const goPrev = () => goTo((activeIndex - 1 + testimonials.length) % testimonials.length);

  useEffect(() => {
    intervalRef.current = setInterval(goNext, 6000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [activeIndex]);

  const active = testimonials[activeIndex];

  return (
    <section id="testimonials" className="bg-charcoal-mid py-20 md:py-28 overflow-hidden">
      <div className="w-full px-6 md:px-10 lg:px-16">

        {/* Header */}
        <div
          ref={header.ref as React.RefObject<HTMLDivElement>}
          className={`flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16 anim-fade-up ${header.isVisible ? 'is-visible' : ''}`}
        >
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Customer Reviews</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              Don't Take Our Word<br />For It — Take Theirs
            </h2>
          </div>

          {/* Rating badges */}
          <div className={`flex items-center gap-6 md:gap-8 anim-fade-up ${header.isVisible ? 'is-visible' : ''}`} style={{ transitionDelay: '150ms' }}>
            <div className="text-center">
              <p className="font-display text-white text-4xl tracking-wider">4.9</p>
              <div className="flex gap-0.5 justify-center my-1.5">
                {[1,2,3,4,5].map(i => <i key={i} className="ri-star-fill text-orange text-sm" />)}
              </div>
              <p className="text-white/60 text-xs uppercase tracking-widest">Google</p>
            </div>
            <div className="w-px h-14 bg-white/10" />
            <div className="text-center">
              <p className="font-display text-white text-4xl tracking-wider">A+</p>
              <p className="text-white/60 text-xs uppercase tracking-widest mt-2">BBB Rating</p>
            </div>
            <div className="w-px h-14 bg-white/10 hidden md:block" />
            <div className="text-center hidden md:block">
              <p className="font-display text-white text-4xl tracking-wider">500+</p>
              <p className="text-white/60 text-xs uppercase tracking-widest mt-2">Roofs Done</p>
            </div>
            <div className="hidden lg:block">
              <GoogleReviewsBadge variant="dark" />
            </div>
          </div>
        </div>

        {/* Main testimonial */}
        <div
          ref={body.ref as React.RefObject<HTMLDivElement>}
          className={`anim-fade-up ${body.isVisible ? 'is-visible' : ''}`}
        >
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-2">

            {/* Featured quote — spans 2 cols */}
            <div className="lg:col-span-2 bg-charcoal-deep border border-white/10 p-8 md:p-12 flex flex-col justify-between min-h-[320px]">
              <div>
                <i className="ri-double-quotes-l text-orange text-5xl mb-6 block" />
                <p
                  className={`font-serif text-white text-xl md:text-2xl leading-relaxed transition-opacity duration-250 ${animating ? 'opacity-0' : 'opacity-100'}`}
                >
                  "{active.text}"
                </p>
              </div>
              <div className={`flex flex-col sm:flex-row sm:items-center gap-4 mt-8 pt-8 border-t border-white/10 transition-opacity duration-250 ${animating ? 'opacity-0' : 'opacity-100'}`}>
                <img
                  src={active.avatar}
                  alt={active.name}
                  className="w-14 h-14 object-cover"
                />
                <div className="flex-1">
                  <p className="font-semibold text-white text-base">{active.name}</p>
                  <p className="text-white/60 text-sm">{active.role} · {active.location}</p>
                </div>
                <div className="flex gap-1">
                  {Array.from({ length: active.rating }).map((_, i) => (
                    <i key={i} className="ri-star-fill text-orange text-sm" />
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar list */}
            <div className="flex flex-col gap-2">
              {testimonials.map((t, i) => (
                <button
                  key={t.id}
                  onClick={() => goTo(i)}
                  className={`text-left p-5 border transition-all duration-200 cursor-pointer flex-1 ${
                    activeIndex === i
                      ? 'bg-orange/10 border-orange/40'
                      : 'bg-charcoal-deep border-white/10 hover:border-white/30 hover:bg-white/5'
                  }`}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <img src={t.avatar} alt={t.name} className="w-8 h-8 object-cover" />
                    <div>
                      <p className={`text-sm font-semibold leading-tight ${activeIndex === i ? 'text-orange' : 'text-white/80'}`}>{t.name}</p>
                      <p className="text-white/50 text-xs">{t.location}</p>
                    </div>
                    {activeIndex === i && (
                      <div className="ml-auto w-1.5 h-1.5 rounded-full bg-orange" />
                    )}
                  </div>
                  <p className="text-white/60 text-xs leading-relaxed line-clamp-2">{t.headline}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Navigation + dots */}
          <div className="flex items-center justify-between mt-6">
            <div className="flex gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => goTo(i)}
                  className={`transition-all duration-300 cursor-pointer ${
                    activeIndex === i ? 'w-8 h-1.5 bg-orange' : 'w-1.5 h-1.5 bg-white/20 hover:bg-white/40'
                  }`}
                />
              ))}
            </div>
            <div className="flex items-center gap-4">
              <GoogleReviewsBadge variant="inline" className="lg:hidden" />
              <div className="flex gap-2">
                <button
                  onClick={goPrev}
                  className="w-10 h-10 flex items-center justify-center border border-white/20 text-white/50 hover:border-orange hover:text-white transition-all duration-200 cursor-pointer"
                >
                  <i className="ri-arrow-left-line text-sm" />
                </button>
                <button
                  onClick={goNext}
                  className="w-10 h-10 flex items-center justify-center border border-white/20 text-white/50 hover:border-orange hover:text-white transition-all duration-200 cursor-pointer"
                >
                  <i className="ri-arrow-right-line text-sm" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom CTA strip */}
        <div className={`mt-16 border border-white/10 p-8 flex flex-col sm:flex-row items-center justify-between gap-6 anim-fade-up ${body.isVisible ? 'is-visible' : ''}`} style={{ transitionDelay: '200ms' }}>
          <div>
            <p className="text-white font-semibold text-lg">Ready to join our happy customers?</p>
            <p className="text-white/60 text-sm mt-1">Free estimates · No pressure · Tri-state area</p>
          </div>
          <button
            onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-orange hover:bg-orange/90 text-white text-xs uppercase tracking-widest font-bold px-8 py-4 transition-all duration-200 whitespace-nowrap cursor-pointer"
          >
            Get a Free Estimate
          </button>
        </div>

      </div>
    </section>
  );
}
