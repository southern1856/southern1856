import { useNavigate } from 'react-router-dom';
import { blogPosts } from '@/mocks/blog';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

export default function BlogSection() {
  const navigate = useNavigate();
  const header = useScrollAnimation();
  const grid = useScrollAnimation({ threshold: 0.05 });

  return (
    <section className="bg-charcoal-mid py-20 md:py-28 overflow-hidden">
      <div className="w-full px-6 md:px-10 lg:px-16">
        {/* Header */}
        <div
          ref={header.ref as React.RefObject<HTMLDivElement>}
          className={`flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16 md:mb-20 anim-fade-up ${header.isVisible ? 'is-visible' : ''}`}
        >
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Blogs</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4.5rem)' }}>
              The Roof Files —<br />Stories, Guides &amp; Good Advice
            </h2>
          </div>
          <button
            onClick={() => navigate('/blog')}
            className="self-start md:self-end border border-white/20 hover:border-orange text-white/60 hover:text-white text-xs uppercase tracking-widest px-6 py-3 transition-all duration-200 whitespace-nowrap cursor-pointer"
          >
            Read All Articles
          </button>
          <a
            href="/google-business-profile-optimization"
            onClick={(e) => { e.preventDefault(); navigate('/google-business-profile-optimization'); }}
            className="self-start md:self-end border border-white/20 hover:border-orange text-white/60 hover:text-white text-xs uppercase tracking-widest px-6 py-3 transition-all duration-200 whitespace-nowrap"
          >
            GBP Optimization Guide
          </a>
        </div>

        {/* Blog Grid */}
        <div
          ref={grid.ref as React.RefObject<HTMLDivElement>}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-white/10"
        >
          {blogPosts.map((post, i) => (
            <article
              key={post.id}
              onClick={() => navigate(`/blog/${post.slug}`)}
              className={`group bg-charcoal-mid hover:bg-charcoal-light transition-colors duration-300 flex flex-col cursor-pointer anim-fade-up ${grid.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${i * 120}ms` }}
            >
              {/* Image */}
              <div className="relative h-52 overflow-hidden">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80 group-hover:opacity-100"
                />
                <div className="absolute top-4 left-4">
                  <span className="bg-orange text-white text-xs font-semibold px-3 py-1.5 uppercase tracking-wider">
                    {post.category}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 md:p-8 flex flex-col flex-grow">
                <div className="flex items-center gap-3 text-white/30 text-xs mb-4 uppercase tracking-wider">
                  <span className="flex items-center gap-1">
                    <i className="ri-time-line" />
                    {post.readTime}
                  </span>
                </div>
                <h3 className="font-serif font-bold text-white text-lg md:text-xl mb-3 leading-snug group-hover:text-orange transition-colors">
                  {post.title}
                </h3>
                <p className="text-white/40 text-sm leading-relaxed flex-grow mb-5">
                  {post.excerpt}
                </p>
                <div className="flex items-center gap-2 text-orange text-sm font-semibold">
                  Read Article
                  <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform duration-200" />
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}