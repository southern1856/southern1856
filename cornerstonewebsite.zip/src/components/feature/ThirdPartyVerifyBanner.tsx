import { useState, useEffect } from 'react';

const VERIFIERS = [
  {
    name: 'Better Business Bureau',
    status: 'A+ Accredited',
    detail: 'Zero complaints in 29 years',
    icon: 'ri-building-4-line',
    color: 'text-amber-400',
  },
  {
    name: 'HomeAdvisor',
    status: 'Elite Service Pro',
    detail: 'Top-rated in Evansville',
    icon: 'ri-home-gear-line',
    color: 'text-green-400',
  },
  {
    name: 'Angi (Angie\'s List)',
    status: 'Super Service Award',
    detail: 'Consistently 5-star rated',
    icon: 'ri-star-fill',
    color: 'text-amber-500',
  },
  {
    name: 'GAF',
    status: 'Master Elite',
    detail: 'Top 3% nationwide',
    icon: 'ri-award-line',
    color: 'text-amber-300',
  },
];

export default function ThirdPartyVerifyBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPercent = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
      setVisible(scrollPercent > 25 && scrollPercent < 75);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!visible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[35] bg-charcoal-deep/95 backdrop-blur-sm border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-2 flex items-center justify-center gap-6 md:gap-10 overflow-x-auto">
        {VERIFIERS.map((v) => (
          <div key={v.name} className="flex items-center gap-2 flex-shrink-0">
            <i className={`${v.icon} ${v.color} text-sm`} />
            <div className="hidden sm:block">
              <p className="text-white/60 text-[10px] font-semibold uppercase tracking-wider leading-none">{v.name}</p>
              <p className="text-white/30 text-[9px] uppercase tracking-wider mt-0.5">{v.status}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}