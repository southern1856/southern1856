import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

interface PriceMatchBannerProps {
  serviceName?: string;
  highlightSavings?: string;
}

export default function PriceMatchBanner({ serviceName = 'your project', highlightSavings }: PriceMatchBannerProps) {
  const navigate = useNavigate();
  const anim = useScrollAnimation({ threshold: 0.1 });

  return (
    <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16">
      <div
        ref={anim.ref as React.RefObject<HTMLDivElement>}
        className={`relative overflow-hidden border border-orange/30 bg-charcoal-mid anim-fade-up ${anim.isVisible ? 'is-visible' : ''}`}
      >
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'linear-gradient(45deg, #fff 25%, transparent 25%), linear-gradient(-45deg, #fff 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #fff 75%), linear-gradient(-45deg, transparent 75%, #fff 75%)', backgroundSize: '20px 20px', backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px' }} />
        <div className="absolute top-0 right-0 w-72 h-72 bg-orange/5 rounded-full -translate-y-1/2 translate-x-1/2 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-56 h-56 bg-orange/5 rounded-full translate-y-1/2 -translate-x-1/2 pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-center justify-between gap-10 p-8 md:p-12 lg:p-14">
          {/* Left content */}
          <div className="flex-1">
            <div className="inline-flex items-center gap-2 bg-orange text-white text-xs font-bold uppercase tracking-widest px-4 py-2 mb-6">
              <i className="ri-shield-check-line" />
              Price Match Guarantee
            </div>

            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-5" style={{ fontSize: 'clamp(2rem, 4.5vw, 4rem)' }}>
              Found a Lower<br />Quote? We&apos;ll <span className="text-orange">Match It.</span>
            </h2>

            <p className="text-white/50 text-sm md:text-base leading-relaxed max-w-lg mb-6">
              Show us any competitor&apos;s <strong className="text-white/70">written estimate</strong> for the same scope of work and materials. If their price is lower, we&apos;ll match it — no questions asked. You get Corner Stone quality, warranty, and service at the best possible price.
            </p>

            {highlightSavings && (
              <div className="flex items-center gap-3 bg-orange/10 border border-orange/20 px-5 py-3 mb-6 w-fit">
                <i className="ri-money-dollar-circle-line text-orange text-lg" />
                <span className="text-orange font-semibold text-sm">{highlightSavings}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-lg">
              {[
                { icon: 'ri-file-list-3-line', text: 'Written estimate required' },
                { icon: 'ri-equalizer-line', text: 'Same scope & materials' },
                { icon: 'ri-eye-off-line', text: 'No hidden fees or tricks' },
                { icon: 'ri-shield-check-line', text: 'Match guaranteed in writing' },
              ].map((item) => (
                <div key={item.text} className="flex items-center gap-2.5 text-white/50 text-xs">
                  <div className="w-6 h-6 flex items-center justify-center bg-orange/15 flex-shrink-0">
                    <i className={`${item.icon} text-orange text-xs`} />
                  </div>
                  {item.text}
                </div>
              ))}
            </div>
          </div>

          {/* Right CTA */}
          <div className="flex flex-col gap-4 flex-shrink-0 w-full lg:w-auto">
            <div className="text-center lg:text-left mb-2">
              <p className="text-white/30 text-xs uppercase tracking-widest mb-1">How it works</p>
              <div className="flex items-center gap-3 text-white/50 text-xs">
                <span className="flex items-center gap-1.5">
                  <span className="w-5 h-5 flex items-center justify-center bg-orange/20 text-orange text-[10px] font-bold">1</span>
                  Get our quote
                </span>
                <i className="ri-arrow-right-line text-white/20" />
                <span className="flex items-center gap-1.5">
                  <span className="w-5 h-5 flex items-center justify-center bg-orange/20 text-orange text-[10px] font-bold">2</span>
                  Show competitor&apos;s
                </span>
                <i className="ri-arrow-right-line text-white/20" />
                <span className="flex items-center gap-1.5">
                  <span className="w-5 h-5 flex items-center justify-center bg-orange/20 text-orange text-[10px] font-bold">3</span>
                  We match it
                </span>
              </div>
            </div>

            <button
              onClick={() => navigate('/estimate')}
              className="bg-orange hover:bg-orange-dark text-white font-bold px-10 py-4 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
            >
              <i className="ri-file-list-3-line" />
              Get Your Price-Matched Quote
            </button>

            <a
              href="tel:8122135997"
              className="border border-white/20 hover:border-orange text-white/70 hover:text-white font-semibold px-10 py-4 uppercase tracking-widest text-sm transition-all whitespace-nowrap flex items-center justify-center gap-2"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>

            <p className="text-white/25 text-xs text-center lg:text-left">
              <i className="ri-time-line mr-1" />
              Valid on quotes received within 30 days of our estimate
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}