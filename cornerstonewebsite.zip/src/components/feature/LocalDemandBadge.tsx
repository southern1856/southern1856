import { useState, useEffect } from 'react';

const MESSAGES = [
  '3 inspections scheduled today in Evansville',
  '2 homeowners from Newburgh just called for quotes',
  'Storm damage team dispatched to Henderson, KY',
  'Same-day slot just booked — limited availability',
  'Free roof report delivered in Boonville',
  'Insurance adjuster meeting scheduled for Mount Vernon',
  'Roof replacement starting tomorrow in Owensboro',
  'Maintenance plan renewed in Princeton',
];

export default function LocalDemandBadge() {
  const [visible, setVisible] = useState(false);
  const [messageIndex, setMessageIndex] = useState(0);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    if (dismissed) return;

    // Show after 15 seconds
    const showTimer = setTimeout(() => setVisible(true), 15000);

    // Cycle messages every 20 seconds
    const msgInterval = setInterval(() => {
      setMessageIndex((prev) => (prev + 1) % MESSAGES.length);
    }, 20000);

    return () => {
      clearTimeout(showTimer);
      clearInterval(msgInterval);
    };
  }, [dismissed]);

  const handleDismiss = () => {
    setDismissed(true);
    setVisible(false);
    sessionStorage.setItem('demand-badge-dismissed', '1');
  };

  if (!visible || dismissed) return null;

  return (
    <div className="fixed bottom-20 md:bottom-24 left-4 md:left-8 z-[55] max-w-xs animate-in slide-in-from-bottom-4 duration-700">
      <div className="bg-charcoal-deep/95 backdrop-blur-md border border-orange/30 p-3 pr-9 shadow-2xl">
        <button
          onClick={handleDismiss}
          className="absolute top-1.5 right-1.5 w-5 h-5 flex items-center justify-center text-white/25 hover:text-white transition-colors cursor-pointer"
          aria-label="Dismiss"
        >
          <i className="ri-close-line text-xs" />
        </button>
        <div className="flex items-center gap-2.5">
          <span className="relative flex items-center justify-center w-5 h-5 flex-shrink-0">
            <span className="absolute inset-0 rounded-full bg-orange/30 animate-ping" />
            <span className="relative inline-flex rounded-full w-2.5 h-2.5 bg-orange" />
          </span>
          <p className="text-white/70 text-xs leading-snug">
            {MESSAGES[messageIndex]}
          </p>
        </div>
      </div>
    </div>
  );
}