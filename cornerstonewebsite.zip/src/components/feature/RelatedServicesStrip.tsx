import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { trackOfferView } from '@/pages/promotions/components/RecentlyViewedOffers';

export interface RelatedService {
  icon: string;
  label: string;
  description: string;
  href: string;
  badge?: string;
  highlight?: boolean;
  trackOffer?: { id: string; title: string; savings: string; icon: string };
}

interface RelatedServicesStripProps {
  heading?: string;
  subheading?: string;
  services: RelatedService[];
}

export default function RelatedServicesStrip({
  heading = 'You Might Also Need',
  subheading = 'Corner Stone handles every part of your exterior — one crew, one company, one call.',
  services,
}: RelatedServicesStripProps) {
  const navigate = useNavigate();
  const anim = useScrollAnimation({ threshold: 0.1 });

  const colClass =
    services.length === 2
      ? 'grid-cols-1 sm:grid-cols-2'
      : services.length === 3
      ? 'grid-cols-1 sm:grid-cols-3'
      : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4';

  return (
    <section className="py-16 md:py-20 px-6 md:px-10 lg:px-16 bg-charcoal border-t border-white/10">
      <div
        ref={anim.ref as React.RefObject<HTMLDivElement>}
        className={`anim-fade-up ${anim.isVisible ? 'is-visible' : ''}`}
      >
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-10">
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-2">Related Services</p>
            <h2
              className="font-display text-white uppercase tracking-wider leading-none"
              style={{ fontSize: 'clamp(1.8rem, 4vw, 3.2rem)' }}
            >
              {heading}
            </h2>
          </div>
          <p className="text-white/40 text-sm max-w-sm leading-relaxed md:text-right">{subheading}</p>
        </div>

        {/* Cards */}
        <div className={`grid gap-4 ${colClass}`}>
          {services.map((svc, i) => (
            <button
              key={svc.href}
              onClick={() => {
                if (svc.trackOffer) trackOfferView(svc.trackOffer);
                navigate(svc.href);
              }}
              className={`group text-left border p-6 transition-all duration-300 cursor-pointer relative overflow-hidden anim-fade-up ${anim.isVisible ? 'is-visible' : ''} ${svc.highlight ? 'border-orange/50 bg-orange/5 hover:border-orange hover:bg-orange/10' : 'border-white/10 bg-charcoal-mid hover:border-orange/40'}`}
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              {/* Decorative corner triangle */}
              <div className="absolute top-0 right-0 w-0 h-0 border-l-[48px] border-l-transparent border-t-[48px] border-t-orange/0 group-hover:border-t-orange/15 transition-all duration-300" />

              {/* Badge */}
              {svc.badge && (
                <div
                  className={`inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-widest px-3 py-1 mb-4 ${
                    svc.highlight ? 'bg-orange text-white' : 'bg-white/8 text-white/50'
                  }`}
                >
                  {svc.badge}
                </div>
              )}

              {/* Icon */}
              <div
                className={`w-11 h-11 flex items-center justify-center mb-4 transition-colors duration-300 ${
                  svc.highlight
                    ? 'bg-orange/20 group-hover:bg-orange/30'
                    : 'bg-white/5 group-hover:bg-orange/15'
                }`}
              >
                <i className={`${svc.icon} text-orange text-xl`} />
              </div>

              {/* Content */}
              <h3
                className={`font-display text-lg uppercase tracking-wider mb-2 transition-colors duration-200 ${
                  svc.highlight ? 'text-orange' : 'text-white group-hover:text-orange'
                }`}
              >
                {svc.label}
              </h3>
              <p className="text-white/45 text-xs leading-relaxed mb-4">{svc.description}</p>

              {/* CTA arrow */}
              <div className="flex items-center gap-2 text-orange text-xs font-semibold uppercase tracking-widest">
                <span>Learn More</span>
                <i className="ri-arrow-right-line transition-transform duration-200 group-hover:translate-x-1" />
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
