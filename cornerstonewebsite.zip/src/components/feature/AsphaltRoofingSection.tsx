export default function AsphaltRoofingSection() {
  const shingleTypes = [
    {
      name: '3-Tab Shingles',
      price: '$4-5/sq ft',
      lifespan: '15-20 years',
      description: 'The most affordable option. Flat, uniform appearance with a 25-year warranty. Great for budget-conscious homeowners.',
    },
    {
      name: 'Architectural Shingles',
      price: '$5-7/sq ft',
      lifespan: '25-30 years',
      description: 'Dimensional look with shadow lines for depth. Heavier and more durable than 3-tab. 30-50 year warranty. Most popular choice in Evansville.',
    },
    {
      name: 'Luxury Shingles',
      price: '$7-10/sq ft',
      lifespan: '30-50 years',
      description: 'Premium thickness and weight. Mimics slate or wood shake appearance. Best impact resistance for Indiana hail storms.',
    },
  ];

  const benefits = [
    'Most affordable roofing material on the market',
    'Wide variety of colors and styles to match any home',
    'Quick installation — most jobs done in 1-2 days',
 'Easy to repair individual damaged shingles',
    'Proven performance in Indiana\'s climate for decades',
    'Excellent fire resistance rating (Class A)',
  ];

  return (
    <section id="asphalt-roofing" className="bg-white py-20 md:py-28 lg:py-32">
      <div className="w-full px-4 md:px-8 lg:px-12">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 md:mb-20">
          <p className="text-orange text-xs md:text-sm font-semibold tracking-[0.2em] uppercase mb-4">
            Popular Choice
          </p>
          <h2 className="font-display font-bold text-charcoal text-3xl md:text-4xl lg:text-5xl mb-5">
            Asphalt Roofing in Evansville
          </h2>
          <p className="text-gray-500 text-base md:text-lg leading-relaxed">
            Asphalt shingles are the #1 roofing choice for Evansville homeowners — and for good reason. Affordable, durable, and available in hundreds of styles and colors to match any Indiana home.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-12 lg:gap-16 items-start">
          {/* Left: Image + Benefits */}
          <div className="w-full lg:w-[50%]">
            <div className="relative rounded-3xl overflow-hidden mb-8">
              <img
                src="/placeholders/700x500.svg"
                alt="Asphalt shingle roof on Evansville home"
                className="w-full h-72 md:h-80 object-cover"
              />
            </div>

            <h3 className="font-display font-bold text-charcoal text-xl md:text-2xl mb-5">
              Why Evansville Homeowners Choose Asphalt
            </h3>
            <ul className="space-y-3">
              {benefits.map((benefit, i) => (
                <li key={i} className="flex items-start gap-3">
                  <div className="w-6 h-6 flex-shrink-0 flex items-center justify-center bg-orange/10 rounded-full mt-0.5">
                    <i className="ri-check-line text-orange text-sm" />
                  </div>
                  <span className="text-gray-600 text-sm md:text-base">{benefit}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Right: Shingle Types */}
          <div className="w-full lg:w-[50%]">
            <h3 className="font-display font-bold text-charcoal text-xl md:text-2xl mb-6">
              Asphalt Shingle Types & Pricing
            </h3>
            <div className="space-y-4">
              {shingleTypes.map((type) => (
                <div
                  key={type.name}
                  className="border border-gray-200 rounded-2xl p-5 md:p-6 hover:border-orange/30 transition-colors"
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-display font-bold text-charcoal text-lg">
                      {type.name}
                    </h4>
                    <span className="bg-orange/10 text-orange font-semibold text-sm px-3 py-1 rounded-full">
                      {type.price}
                    </span>
                  </div>
                  <p className="text-gray-500 text-sm mb-2">{type.description}</p>
                  <p className="text-gray-400 text-xs">
                    <i className="ri-time-line mr-1" />
                    Expected lifespan: {type.lifespan}
                  </p>
                </div>
              ))}
            </div>

            {/* Cost estimate box */}
            <div className="mt-6 bg-warm-cream rounded-2xl p-5 md:p-6">
              <h4 className="font-display font-bold text-charcoal text-lg mb-2">
                Average Cost for Evansville Homes
              </h4>
              <p className="text-gray-600 text-sm leading-relaxed mb-3">
                A typical 2,000 sq ft Evansville home costs <strong className="text-charcoal">$8,000 - $14,000</strong> for a complete asphalt roof replacement, including removal of the old roof, new underlayment, and installation.
              </p>
              <a
                href="#contact"
                onClick={(e) => {
                  e.preventDefault();
                  document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="inline-flex items-center gap-2 text-orange font-semibold text-sm hover:text-orange-dark transition-colors cursor-pointer"
              >
                Get Your Free Asphalt Roof Estimate
                <i className="ri-arrow-right-line" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}