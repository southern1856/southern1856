import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { services } from '@/mocks/services';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

export default function ServicesSection() {
  const navigate = useNavigate();
  const [hoveredId, setHoveredId] = useState<number | null>(null);
  const header = useScrollAnimation();
  const list = useScrollAnimation({ threshold: 0.05 });
  const cta = useScrollAnimation();

  return (
    <section id="services" className="bg-charcoal-deep py-20 md:py-28 overflow-hidden">
      <div className="w-full px-6 md:px-10 lg:px-16">
        {/* Header */}
        <div
          ref={header.ref as React.RefObject<HTMLDivElement>}
          className={`flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16 md:mb-20 anim-fade-up ${header.isVisible ? 'is-visible' : ''}`}
        >
          <div>
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-4">Our Services</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2.5rem, 6vw, 5.5rem)' }}>
              We Climb So You<br />Don't Have To
            </h2>
          </div>
          <p className="text-white/60 text-sm md:text-base max-w-xs leading-relaxed">
            Expert roofing services for Evansville homeowners and businesses — from emergency repairs to full replacements.
          </p>
        </div>

        {/* Service List */}
        <div
          ref={list.ref as React.RefObject<HTMLDivElement>}
          className="border-t border-white/10"
        >
          {services.map((service, index) => (
            <div
              key={service.id}
              className={`group border-b border-white/10 cursor-pointer anim-fade-up ${list.isVisible ? 'is-visible' : ''}`}
              style={{ transitionDelay: `${index * 80}ms` }}
              onMouseEnter={() => setHoveredId(service.id)}
              onMouseLeave={() => setHoveredId(null)}
              onClick={() => service.link ? navigate(service.link) : document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <div className="flex items-center justify-between py-6 md:py-8 gap-6 transition-all duration-300">
                <div className="flex items-center gap-6 md:gap-10 flex-1 min-w-0">
                  <span className="font-display text-white/40 text-2xl md:text-3xl tracking-wider w-10 flex-shrink-0">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                  <div className="flex-1 min-w-0">
                    <h3
                      className={`font-display uppercase tracking-wider transition-colors duration-300 leading-none ${hoveredId === service.id ? 'text-orange' : 'text-white'}`}
                      style={{ fontSize: 'clamp(1.4rem, 3vw, 2.5rem)' }}
                    >
                      {service.title}
                    </h3>
                    <p className={`text-sm mt-2 leading-relaxed transition-all duration-300 max-w-xl ${hoveredId === service.id ? 'text-white/60 max-h-20 opacity-100' : 'text-white/30 max-h-0 opacity-0 overflow-hidden'}`}>
                      {service.description}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4 flex-shrink-0">
                  <div className={`w-10 h-10 flex items-center justify-center border transition-all duration-300 ${hoveredId === service.id ? 'border-orange bg-orange text-white' : 'border-white/20 text-white/40'}`}>
                    <i className="ri-arrow-right-up-line text-lg" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div
          ref={cta.ref as React.RefObject<HTMLDivElement>}
          className={`mt-12 flex items-center gap-6 anim-fade-up ${cta.isVisible ? 'is-visible' : ''}`}
        >
          <button
            onClick={() => navigate('/free-inspection')}
            className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-4 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap cursor-pointer"
          >
            Get Free Estimate
          </button>
          <a href="tel:8122135997" className="text-white/70 hover:text-white text-sm transition-colors flex items-center gap-2">
            <i className="ri-phone-line" />
            Or call 812-213-5997
          </a>
        </div>
      </div>
    </section>
  );
}