import { useState, useEffect, useRef } from 'react';

function stableRandom(seed: number, min: number, max: number): number {
  return min + Math.floor(((Math.sin(seed) * 10000) % 1) * (max - min + 1));
}

export default function SocialProofPulse() {
  const [viewers, setViewers] = useState(0);
  const base = useRef(0);
  const mounted = useRef(false);

  useEffect(() => {
    // Seed a stable base number per session (between 5–22)
    const seed = Math.floor(Date.now() / 1000) % 1000 + Math.floor(Math.random() * 500);
    base.current = stableRandom(seed, 5, 22);
    setViewers(base.current);
    mounted.current = true;
  }, []);

  useEffect(() => {
    if (!mounted.current) return;
    // Gently fluctuate ±3 every 8–15 seconds
    const fluctuate = () => {
      const delta = Math.floor(Math.random() * 7) - 3; // -3 to +3
      setViewers(Math.max(2, Math.min(28, base.current + delta)));
    };

    const getInterval = () => 8000 + Math.floor(Math.random() * 7000);

    let timeout: ReturnType<typeof setTimeout>;
    const schedule = () => {
      timeout = setTimeout(() => {
        fluctuate();
        schedule();
      }, getInterval());
    };
    schedule();

    return () => clearTimeout(timeout);
  }, []);

  if (viewers === 0) return null;

  return (
    <div className="inline-flex items-center gap-2 text-white/50 text-[11px] md:text-xs">
      <span className="relative w-2 h-2">
        <span className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-60" />
        <span className="relative w-2 h-2 rounded-full bg-green-400 block" />
      </span>
      <span>
        <strong className="text-white/70 font-semibold">{viewers}</strong> people are viewing this deal
      </span>
    </div>
  );
}