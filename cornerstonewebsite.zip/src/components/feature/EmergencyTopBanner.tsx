import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function EmergencyTopBanner() {
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const wasDismissed = sessionStorage.getItem('emergency-top-banner-dismissed');
    if (wasDismissed) {
      sessionStorage.removeItem('severe-weather-alert-active');
      setVisible(false);
      return;
    }
    setVisible(true);
    sessionStorage.setItem('severe-weather-alert-active', '1');
    window.dispatchEvent(new CustomEvent('emergency-alert-changed'));
  }, []);

  const navigate = useNavigate();

  const handleDismiss = () => {
    setDismissed(true);
    sessionStorage.setItem('emergency-top-banner-dismissed', '1');
    sessionStorage.removeItem('severe-weather-alert-active');
    window.dispatchEvent(new CustomEvent('emergency-alert-changed'));
    setTimeout(() => setVisible(false), 400);
  };

  if (!visible) return null;

  return (
    <div
      className={`relative transition-all duration-400 ${
        dismissed ? 'opacity-0 max-h-0 overflow-hidden' : 'opacity-100 max-h-20'
      }`}
    >
      <div className="bg-orange flex items-center justify-between gap-3 px-4 md:px-8 py-2">
        <div className="flex items-center gap-3 min-w-0">
          <span className="relative flex-shrink-0 w-2.5 h-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-60" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-white" />
          </span>
          <p className="text-white text-xs font-semibold uppercase tracking-wide whitespace-nowrap">
            Storm Alert — Evansville
          </p>
          <span className="hidden md:inline text-white/70 text-xs">
            Hail &amp; wind damage in Vanderburgh County. Free same-day inspections.
          </span>
        </div>
        <div className="flex items-center gap-3 flex-shrink-0">
          <a
            href="tel:8122135997"
            className="hidden sm:inline-flex items-center gap-1.5 text-white/80 hover:text-white text-xs font-semibold transition-colors whitespace-nowrap"
          >
            <i className="ri-phone-line" />
            812-213-5997
          </a>
          <button
            onClick={handleDismiss}
            aria-label="Dismiss banner"
            className="w-6 h-6 flex items-center justify-center text-white/70 hover:text-white transition-colors cursor-pointer flex-shrink-0"
          >
            <i className="ri-close-line text-base" />
          </button>
        </div>
      </div>
    </div>
  );
}
