import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function ScrollTriggerOffer() {
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (dismissed) return;

    const handleScroll = () => {
      const scrollPercent =
        (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
      // Show when user has scrolled past 65% of page
      if (scrollPercent > 65 && !dismissed) {
        setVisible(true);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [dismissed]);

  const handleDismiss = () => {
    setDismissed(true);
    setVisible(false);
    sessionStorage.setItem('scroll-offer-dismissed', '1');
  };

  if (!visible) return null;

  return (
    <div
      className={`fixed bottom-6 right-4 md:bottom-10 md:right-10 z-[58] max-w-xs w-[calc(100%-2rem)] transition-all duration-700 ease-out ${
        visible ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0 pointer-events-none'
      }`}
    >
      <div className="bg-charcoal-deep/95 backdrop-blur-md border border-orange/30 p-6 shadow-2xl">
        <button
          onClick={handleDismiss}
          className="absolute top-2 right-2 w-7 h-7 flex items-center justify-center text-white/25 hover:text-white transition-colors cursor-pointer"
          aria-label="Dismiss"
        >
          <i className="ri-close-line text-sm" />
        </button>

        <div className="flex items-center gap-2 mb-3">
          <i className="ri-gift-line text-orange text-lg" />
          <span className="text-orange text-xs font-bold uppercase tracking-widest">Exclusive Offer</span>
        </div>

        <h3 className="font-display text-white text-lg uppercase tracking-wider leading-snug mb-2">
          Free Roof Inspection + $500 Credit
        </h3>
        <p className="text-white/45 text-xs leading-relaxed mb-4">
          You've been researching for a while. Lock in this month's offer before it expires — Evansville homeowners who book today get priority scheduling and a $500 repair credit.
        </p>

        <div className="bg-white/5 border border-white/5 px-3 py-2 mb-4">
          <div className="flex items-center justify-between text-xs">
            <span className="text-white/40">Spots remaining this month</span>
            <span className="text-orange font-bold">8 left</span>
          </div>
          <div className="w-full bg-white/5 h-1 mt-1.5">
            <div className="bg-orange h-1" style={{ width: '20%' }} />
          </div>
        </div>

        <button
          onClick={() => {
            handleDismiss();
            navigate('/estimate');
          }}
          className="bg-orange hover:bg-orange-dark text-white font-semibold w-full py-3 uppercase tracking-widest text-xs transition-colors whitespace-nowrap cursor-pointer"
        >
          Claim Free Inspection
        </button>
      </div>
    </div>
  );
}