import { useToolUsage } from '@/hooks/useToolUsage';

function formatCount(n: number): string {
  if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
  return String(n);
}

interface MostUsedToolBadgeProps {
  className?: string;
}

/**
 * Inline badge that highlights the current most-used tool.
 * Updates live every 60 seconds.
 */
export default function MostUsedToolBadge({ className = '' }: MostUsedToolBadgeProps) {
  const { mostUsed, loading } = useToolUsage();

  if (loading || !mostUsed) return null;

  return (
    <div
      className={`inline-flex items-center gap-2 bg-orange/10 border border-orange/30 px-3 py-1.5 ${className}`}
    >
      <span className="w-4 h-4 flex items-center justify-center flex-shrink-0">
        <i className="ri-fire-line text-orange text-xs animate-pulse" />
      </span>
      <span className="text-orange text-[11px] font-semibold uppercase tracking-wider">
        Most Used: {mostUsed.tool_name}
      </span>
      <span className="text-orange/50 text-[10px] font-medium uppercase tracking-wider">
        {formatCount(mostUsed.usage_count)} homeowners
      </span>
    </div>
  );
}