import { useState, useRef } from 'react';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

export default function AdjusterSection() {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const formRef = useRef<HTMLFormElement>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;

    setStatus('submitting');

    try {
      const formData = new FormData(formRef.current);
    formData.append('access_key', WEB3FORMS_ACCESS_KEY);
      const response = await fetch(WEB3FORMS_ENDPOINT, {
        method: 'POST',
        body: new URLSearchParams(formData as never),
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
      });

      if (response.ok) {
        setStatus('success');
        formRef.current.reset();
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    }
  };

  return (
    <section id="adjusters" className="bg-charcoal py-20 md:py-28 lg:py-32">
      <div className="w-full px-4 md:px-8 lg:px-12">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12 md:mb-16">
            <div className="inline-flex items-center gap-2 bg-orange/20 text-orange font-semibold text-sm px-4 py-2 rounded-full mb-5">
              <i className="ri-briefcase-line" />
              For Insurance Professionals
            </div>
            <h2 className="font-display font-bold text-white text-3xl md:text-4xl lg:text-5xl mb-5">
              Insurance Adjusters & Agents
            </h2>
            <p className="text-white/60 text-base md:text-lg leading-relaxed max-w-2xl mx-auto">
              Corner Stone Construction & Roofing partners with insurance adjusters and agents throughout Evansville, Vanderburgh County, and surrounding areas. Fast response, detailed documentation, and seamless claims processing.
            </p>
          </div>

          <div className="flex flex-col lg:flex-row gap-10 lg:gap-12">
            {/* Left: Benefits */}
            <div className="w-full lg:w-[50%]">
              <h3 className="font-display font-bold text-white text-xl md:text-2xl mb-6">
                Why Adjusters Choose Corner Stone
              </h3>
              <div className="space-y-4">
                {[
                  {
                    icon: 'ri-flashlight-line',
                    title: '2-Hour Emergency Response',
                    desc: 'We tarp and secure damaged roofs within 2 hours of your referral, preventing further property damage.',
                  },
                  {
                    icon: 'ri-file-text-line',
                    title: 'Detailed Photo Documentation',
                    desc: 'We provide comprehensive before, during, and after photo reports that support your claim files.',
                  },
                  {
                    icon: 'ri-calculator-line',
                    title: 'Xactimate-Compatible Estimates',
                    desc: 'Our estimates align with industry-standard pricing to streamline your approval process.',
                  },
                  {
                    icon: 'ri-shield-check-line',
                    title: 'Licensed & Insurance-Approved',
                    desc: 'Fully licensed Indiana contractor with liability and workers comp. Approved by all major carriers.',
                  },
                  {
                    icon: 'ri-customer-service-2-line',
                    title: 'Dedicated Adjuster Liaison',
                    desc: 'A single point of contact for all your referrals. Direct line, no runaround.',
                  },
                ].map((item) => (
                  <div key={item.title} className="flex items-start gap-4">
                    <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center bg-orange/20 rounded-xl">
                      <i className={`${item.icon} text-orange text-lg`} />
                    </div>
                    <div>
                      <h4 className="font-semibold text-white text-sm md:text-base mb-1">{item.title}</h4>
                      <p className="text-white/60 text-sm leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Direct Contact */}
              <div className="mt-8 bg-white/5 border border-white/10 rounded-2xl p-5 md:p-6">
                <h4 className="font-display font-bold text-white text-lg mb-4">Direct Adjuster Line</h4>
                <div className="space-y-3">
                  <a href="tel:8122135997" className="flex items-center gap-3 text-white/80 hover:text-orange transition-colors">
                    <div className="w-10 h-10 flex items-center justify-center bg-orange/20 rounded-full">
                      <i className="ri-phone-line text-orange" />
                    </div>
                    <div>
                      <p className="text-white font-semibold text-sm">812-213-5997</p>
                      <p className="text-white/50 text-xs">24/7 Emergency Referrals</p>
                    </div>
                  </a>
                  <a href="mailto:themainstoneconstruction@gmail.com" className="flex items-center gap-3 text-white/80 hover:text-orange transition-colors">
                    <div className="w-10 h-10 flex items-center justify-center bg-orange/20 rounded-full">
                      <i className="ri-mail-line text-orange" />
                    </div>
                    <div>
                      <p className="text-white font-semibold text-sm">themainstoneconstruction@gmail.com</p>
                      <p className="text-white/50 text-xs">For claims & documentation</p>
                    </div>
                  </a>
                </div>
              </div>
            </div>

            {/* Right: Referral Form */}
            <div className="w-full lg:w-[50%]">
              <div className="bg-white rounded-3xl p-6 md:p-8">
                <h3 className="font-display font-bold text-charcoal text-xl md:text-2xl mb-1">
                  Submit a Referral
                </h3>
                <p className="text-gray-500 text-sm mb-6">
                  Send us a new claim referral and we will respond within 1 hour during business hours.
                </p>

                {status === 'success' ? (
                  <div className="text-center py-6">
                    <div className="w-14 h-14 flex items-center justify-center bg-green-100 rounded-full mx-auto mb-4">
                      <i className="ri-checkbox-circle-line text-green-600 text-2xl" />
                    </div>
                    <h4 className="font-display font-bold text-charcoal text-lg mb-2">
                      Referral Submitted!
                    </h4>
                    <p className="text-gray-500 text-sm mb-4">
                      We will contact the homeowner within 1 hour and keep you updated on the claim progress.
                    </p>
                    <button
                      onClick={() => setStatus('idle')}
                      className="bg-orange hover:bg-orange-dark text-white font-semibold px-6 py-2.5 rounded-full transition-colors cursor-pointer text-sm"
                    >
                      Submit Another
                    </button>
                  </div>
                ) : (
                  <form
                    ref={formRef}
                    data-readdy-form
                    onSubmit={handleSubmit}
                    className="space-y-4"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-1.5">Adjuster Name *</label>
                        <input type="text" name="adjuster_name" required placeholder="Your name" className="w-full bg-gray-100 rounded-xl px-4 py-3 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors" />
                      </div>
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-1.5">Insurance Company *</label>
                        <input type="text" name="insurance_company" required placeholder="e.g. State Farm, Allstate" className="w-full bg-gray-100 rounded-xl px-4 py-3 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors" />
                      </div>
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-1.5">Adjuster Phone *</label>
                        <input type="tel" name="adjuster_phone" required placeholder="812-213-5997" className="w-full bg-gray-100 rounded-xl px-4 py-3 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors" />
                      </div>
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-1.5">Adjuster Email *</label>
                        <input type="email" name="adjuster_email" required placeholder="you@company.com" className="w-full bg-gray-100 rounded-xl px-4 py-3 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors" />
                      </div>
                    </div>

                    <div className="border-t border-gray-200 pt-4">
                      <h4 className="font-semibold text-charcoal text-sm mb-3">Policyholder Information</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-charcoal text-sm font-medium mb-1.5">Homeowner Name *</label>
                          <input type="text" name="homeowner_name" required placeholder="Homeowner name" className="w-full bg-gray-100 rounded-xl px-4 py-3 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors" />
                        </div>
                        <div>
                          <label className="block text-charcoal text-sm font-medium mb-1.5">Homeowner Phone *</label>
                          <input type="tel" name="homeowner_phone" required placeholder="812-213-5997" className="w-full bg-gray-100 rounded-xl px-4 py-3 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors" />
                        </div>
                        <div className="md:col-span-2">
                          <label className="block text-charcoal text-sm font-medium mb-1.5">Property Address *</label>
                          <input type="text" name="property_address" required placeholder="123 Main St, Evansville, IN 47710" className="w-full bg-gray-100 rounded-xl px-4 py-3 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors" />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-1.5">Claim Number</label>
                        <input type="text" name="claim_number" placeholder="Optional" className="w-full bg-gray-100 rounded-xl px-4 py-3 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors" />
                      </div>
                      <div>
                        <label className="block text-charcoal text-sm font-medium mb-1.5">Damage Type *</label>
                        <select name="damage_type" required className="w-full bg-gray-100 rounded-xl px-4 py-3 text-charcoal text-sm focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors appearance-none cursor-pointer">
                          <option value="">Select damage type</option>
                          <option value="hail">Hail Damage</option>
                          <option value="wind">Wind Damage</option>
                          <option value="fallen-tree">Fallen Tree / Debris</option>
                          <option value="fire">Fire</option>
                          <option value="water">Water / Leak</option>
                          <option value="other">Other</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-charcoal text-sm font-medium mb-1.5">Notes / Special Instructions</label>
                      <textarea name="adjuster_notes" rows={3} placeholder="Any specific requirements, access instructions, or timeline needs..." className="w-full bg-gray-100 rounded-xl px-4 py-3 text-charcoal text-sm placeholder:text-gray-400 focus:outline-none focus:border-orange border-b-3 border-transparent transition-colors resize-none" />
                    </div>

                    <button
                      type="submit"
                      disabled={status === 'submitting'}
                      className="w-full bg-orange hover:bg-orange-dark disabled:bg-gray-400 text-white font-semibold py-3.5 rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2"
                    >
                      {status === 'submitting' ? (
                        <>
                          <i className="ri-loader-4-line animate-spin" />
                          Sending Referral...
                        </>
                      ) : (
                        <>
                          Submit Referral
                          <i className="ri-send-plane-line" />
                        </>
                      )}
                    </button>

                    {status === 'error' && (
                      <div className="bg-red-50 border border-red-200 rounded-xl p-3 flex items-center gap-2">
                        <i className="ri-alert-line text-red-600" />
                        <p className="text-red-700 text-sm">Something went wrong. Please call us directly at 812-213-5997.</p>
                      </div>
                    )}
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}