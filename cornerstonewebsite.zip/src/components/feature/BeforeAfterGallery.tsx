import { useState, useRef, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

interface FeaturedProject {
  id: number;
  title: string;
  location: string;
  tag: string;
  before: string;
  after: string;
}

const featuredProjects: FeaturedProject[] = [
  {
    id: 1,
    title: 'Hail Damage — Full Replacement',
    location: 'Evansville, IN',
    tag: 'Insurance Claim',
    before: '/placeholders/900x520.svg',
    after: '/placeholders/900x520.svg',
  },
  {
    id: 2,
    title: 'Full Residential Replacement',
    location: 'Newburgh, IN',
    tag: 'Full Replacement',
    before: '/placeholders/900x520.svg',
    after: '/placeholders/900x520.svg',
  },
  {
    id: 3,
    title: 'Standing Seam Metal Upgrade',
    location: 'Henderson, KY',
    tag: 'Metal Upgrade',
    before: '/placeholders/900x520.svg',
    after: '/placeholders/900x520.svg',
  },
];

function GallerySlider({ project, index }: { project: FeaturedProject; index: number }) {
  const [sliderPos, setSliderPos] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const updateSlider = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const pos = Math.min(100, Math.max(0, ((clientX - rect.left) / rect.width) * 100));
    setSliderPos(pos);
  }, []);

  useEffect(() => {
    if (!isDragging) return;
    const onMove = (e: MouseEvent) => updateSlider(e.clientX);
    const onUp = () => setIsDragging(false);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
  }, [isDragging, updateSlider]);

  return (
    <div
      className="group relative bg-white border border-white/5 overflow-hidden"
      style={{ transitionDelay: `${index * 120}ms` }}
    >
      {/* Slider */}
      <div
        ref={containerRef}
        className="relative h-56 sm:h-64 md:h-72 overflow-hidden cursor-col-resize select-none"
        onMouseDown={(e) => { e.preventDefault(); setIsDragging(true); updateSlider(e.clientX); }}
        onTouchMove={(e) => updateSlider(e.touches[0].clientX)}
        onTouchStart={(e) => updateSlider(e.touches[0].clientX)}
      >
        {/* After (full width behind) */}
        <img
          src={project.after}
          alt={`After — ${project.title}`}
          className="absolute inset-0 w-full h-full object-cover object-top"
        />
        {/* Before (clipped) */}
        <div className="absolute inset-0 overflow-hidden" style={{ width: `${sliderPos}%` }}>
          <img
            src={project.before}
            alt={`Before — ${project.title}`}
            className="absolute inset-0 h-full object-cover object-top"
            style={{ width: containerRef.current ? `${containerRef.current.offsetWidth}px` : '100%', maxWidth: 'none' }}
          />
        </div>
        {/* Gradient overlay for readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent pointer-events-none" />

        {/* Divider line with handle */}
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-white z-10 pointer-events-none"
          style={{ left: `${sliderPos}%`, transform: 'translateX(-50%)' }}
        >
          <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-lg transition-transform duration-150 ${isDragging ? 'scale-110' : 'scale-100'}`}>
            <i className="ri-arrow-left-right-line text-charcoal-deep text-base" />
          </div>
        </div>

        {/* Before label */}
        <div className="absolute top-3 left-3 z-10 pointer-events-none">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold uppercase tracking-widest bg-rose-600 text-white">
            <i className="ri-error-warning-line text-xs" />
            Before
          </span>
        </div>

        {/* After label */}
        <div className="absolute top-3 right-3 z-10 pointer-events-none">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-bold uppercase tracking-widest bg-emerald-600 text-white">
            <i className="ri-checkbox-circle-line text-xs" />
            After
          </span>
        </div>

        {/* Drag hint */}
        <div className={`absolute bottom-3 left-1/2 -translate-x-1/2 z-10 pointer-events-none transition-opacity duration-500 ${isDragging || sliderPos !== 50 ? 'opacity-0' : 'opacity-100'}`}>
          <div className="bg-black/40 backdrop-blur-sm px-4 py-2 flex items-center gap-2">
            <i className="ri-drag-move-line text-white text-sm" />
            <span className="text-white text-xs uppercase tracking-widest font-semibold">Drag to Compare</span>
          </div>
        </div>

        {/* Tag */}
        <div className="absolute bottom-3 left-3 z-10 pointer-events-none">
          <span className="inline-block bg-orange/90 text-white text-xs font-bold px-2.5 py-1 uppercase tracking-wider">
            {project.tag}
          </span>
        </div>
      </div>

      {/* Card footer */}
      <div className="px-5 py-4 md:px-6 md:py-5">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-display text-charcoal-deep text-lg md:text-xl uppercase tracking-wide leading-snug">{project.title}</h3>
            <p className="text-charcoal-mid/50 text-xs mt-0.5 flex items-center gap-1">
              <i className="ri-map-pin-line text-xs" />
              {project.location}
            </p>
          </div>
          <div className="w-9 h-9 flex items-center justify-center bg-charcoal-deep text-white opacity-0 group-hover:opacity-100 transition-opacity">
            <i className="ri-arrow-right-up-line text-sm" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default function BeforeAfterGallery() {
  const navigate = useNavigate();
  const sectionAnim = useScrollAnimation({ threshold: 0.06 });

  return (
    <section className="bg-neutral-light py-20 md:py-28 px-6 md:px-10 lg:px-16">
      <div
        ref={sectionAnim.ref as React.RefObject<HTMLDivElement>}
        className={`anim-fade-up ${sectionAnim.isVisible ? 'is-visible' : ''}`}
      >
        {/* Section header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-12 md:mb-16">
          <div>
            <p className="text-orange text-xs font-semibold tracking-[0.25em] uppercase mb-4">Real Transformations</p>
            <h2 className="font-display text-charcoal-deep uppercase tracking-wider leading-none" style={{ fontSize: 'clamp(2rem, 5vw, 4rem)' }}>
              Before &amp; After<br /><span className="text-orange">Gallery</span>
            </h2>
          </div>
          <button
            onClick={() => navigate('/before-after')}
            className="inline-flex items-center gap-2 text-charcoal-deep text-xs font-semibold uppercase tracking-widest hover:text-orange transition-colors cursor-pointer whitespace-nowrap self-start md:self-auto"
          >
            View All Projects
            <i className="ri-arrow-right-line" />
          </button>
        </div>

        {/* Gallery grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-6">
          {featuredProjects.map((project, i) => (
            <GallerySlider key={project.id} project={project} index={i} />
          ))}
        </div>

        {/* Bottom CTA bar */}
        <div className="mt-12 md:mt-16 bg-charcoal-deep p-8 md:p-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="font-display text-white text-xl md:text-2xl uppercase tracking-wider leading-snug">
              Your Home Could Be Next
            </h3>
            <p className="text-white/40 text-sm mt-1 max-w-lg leading-relaxed">
              Free inspections start every transformation. See the full gallery with 9+ real projects and filter by service type.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-3 flex-shrink-0">
            <button
              onClick={() => navigate('/before-after')}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-8 py-3 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
            >
              See Full Gallery
              <i className="ri-arrow-right-line" />
            </button>
            <button
              onClick={() => navigate('/estimate')}
              className="border border-white/30 hover:border-white text-white font-semibold px-8 py-3 uppercase tracking-widest text-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              Free Estimate
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}