import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import GoogleReviewsBadge from './GoogleReviewsBadge';
import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';

export default function Footer() {
  const [submitted, setSubmitted] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === '/';

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    if (!isHome) {
      navigate('/' + href);
      return;
    }
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleNewsletterSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const _fd = new FormData(form);
    _fd.append('access_key', WEB3FORMS_ACCESS_KEY);
    const data = new URLSearchParams(_fd as unknown as Record<string, string>);
    try {
      await fetch(WEB3FORMS_ENDPOINT, { method: 'POST', body: data });
      setSubmitted(true);
    } catch {
      setSubmitted(true);
    }
  };

  return (
    <footer className="bg-charcoal-deep">
      {/* CTA Section */}
      <div className="border-t border-white/10 py-20 md:py-28 px-6 md:px-10 lg:px-16">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-10">
          <div className="max-w-2xl">
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2.5rem, 6vw, 6rem)' }}>
              You Click.<br />We Climb.<br /><span className="text-orange">Deal?</span>
            </h2>
            <p className="text-white/60 text-sm md:text-base leading-relaxed max-w-md">
              Tell us what you need — we'll handle the rest. No ladders required on your part.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href={isHome ? '#contact' : '/#contact'}
              onClick={(e) => {
                e.preventDefault();
                if (!isHome) {
                  navigate('/#contact');
                  return;
                }
                document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="bg-orange hover:bg-orange-dark text-white font-semibold px-10 py-5 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap text-center"
            >
              Request Free Estimate
            </a>
            <a
              href="tel:8122135997"
              className="border border-white/20 hover:border-white text-white font-semibold px-10 py-5 uppercase tracking-widest text-sm transition-colors duration-200 whitespace-nowrap text-center flex items-center justify-center gap-3"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>
        </div>
      </div>

      {/* Customer Portal Widget */}
      <div className="border-t border-white/10 px-6 md:px-10 lg:px-16 py-0">
        <div className="bg-gradient-to-r from-orange/10 via-orange/5 to-transparent border border-orange/20 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 flex items-center justify-center bg-orange/20 rounded-xl flex-shrink-0">
              <i className="ri-folder-user-line text-orange text-xl" />
            </div>
            <div>
              <h3 className="text-white text-sm font-bold uppercase tracking-wider mb-1">
                Customer Portal
              </h3>
              <p className="text-white/50 text-xs leading-relaxed max-w-md">
                Track your project timeline, photos, messages, and documents in real time. Already have an active project? Jump in and see what your crew is working on today.
              </p>
            </div>
          </div>
          <a
            href="/customer-portal"
            onClick={(e) => { e.preventDefault(); navigate('/customer-portal'); }}
            className="inline-flex items-center gap-2 bg-orange hover:bg-orange-dark text-white font-bold text-xs uppercase tracking-widest px-6 py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap flex-shrink-0"
          >
            <i className="ri-arrow-right-up-line" />
            Open My Projects
          </a>
        </div>
      </div>

      {/* Main footer grid */}
      <div className="border-t border-white/10 px-6 md:px-10 lg:px-16 py-16 md:py-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 md:gap-8">
          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <a href="/" onClick={(e) => { e.preventDefault(); navigate('/'); }} className="flex items-center gap-3.5 mb-6 group">
              <div className="relative flex items-center justify-center h-14 w-14 bg-white rounded-lg shadow-sm">
                <img
                  src="/logo.svg"
                  alt="Corner Stone Construction & Roofing"
                  className="h-12 w-12 object-contain rounded-md"
                />
              </div>
              <div className="flex flex-col leading-none">
                <span className="font-display text-white text-xl tracking-wider uppercase">
                  Corner Stone
                </span>
                <span className="text-white/40 text-[0.65rem] tracking-[0.25em] uppercase font-medium mt-0.5">
                  Construction & Roofing
                </span>
              </div>
            </a>
            <p className="text-white/60 text-sm leading-relaxed mb-6">
              Evansville Indiana's premier roofing contractor. Protecting homes across Vanderburgh County since 1995.
            </p>
            <div className="flex gap-3">
              {['ri-facebook-fill', 'ri-instagram-line', 'ri-linkedin-fill'].map((icon) => (
                <a key={icon} href="#" className="w-9 h-9 flex items-center justify-center border border-white/20 text-white/40 hover:text-orange hover:border-orange transition-colors">
                  <i className={`${icon} text-sm`} />
                </a>
              ))}
              <a
                href="https://g.page/r/cornerstoneconstructionevansville/review"
                target="_blank"
                rel="nofollow noreferrer"
                className="w-9 h-9 flex items-center justify-center border border-white/20 text-white/40 hover:text-orange hover:border-orange transition-colors"
                title="Review us on Google"
              >
                <i className="ri-google-fill text-sm" />
              </a>
            </div>
            <a
              href="https://g.page/r/cornerstoneconstructionevansville"
              target="_blank"
              rel="nofollow noreferrer"
              className="mt-4 inline-flex items-center gap-2 text-white/60 text-xs hover:text-orange transition-colors"
            >
              <i className="ri-map-pin-line text-orange text-xs" />
              View us on Google Maps
            </a>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-[0.2em] mb-5">Quick Links</h4>
            <ul className="space-y-3">
              {[
                { label: 'Home', href: '#home' },
                { label: 'Services', href: '/services', isPage: true },
                { label: 'Roof Repair', href: '/roof-repair', isPage: true },
                { label: 'Evansville Roof Repair', href: '/evansville-roof-repair', isPage: true },
                { label: 'Evansville Roof Replacement', href: '/evansville-roof-replacement', isPage: true },
                { label: 'Service Areas', href: '/service-areas', isPage: true },
                { label: 'About Us', href: '/about', isPage: true },
                { label: 'Projects', href: '/projects', isPage: true },
                { label: 'Case Studies', href: '/case-studies', isPage: true },
                { label: 'Before & After', href: '/before-after', isPage: true },
                { label: 'Reviews', href: '/testimonials', isPage: true },
                { label: 'Financing', href: '/financing', isPage: true },
                { label: 'Maintenance Plans', href: '/maintenance-plans', isPage: true },
                { label: 'Warranty', href: '/warranty', isPage: true },
                { label: 'Insurance Claims', href: '/insurance-claims', isPage: true },
                { label: 'Blog', href: '/blog', isPage: true },
                { label: 'AI Inspector', href: '/ai-inspector', isPage: true },
                { label: 'GBP Optimization', href: '/google-business-profile-optimization', isPage: true },
                { label: 'Social Templates', href: '/social-media-templates', isPage: true },
                { label: 'Content Calendar', href: '/content-calendar', isPage: true },
                { label: 'SEO Audit Checklist', href: '/seo-audit-checklist', isPage: true },
                { label: 'Hire a Roofer Guide', href: '/before-you-hire-a-roofer', isPage: true },
                { label: 'Maintenance Calendar', href: '/roof-maintenance-calendar', isPage: true },
                { label: 'Cost Guide', href: '/roof-cost-guide', isPage: true },
                { label: 'Compare Materials', href: '/roof-comparison', isPage: true },
                { label: 'Compare Quotes', href: '/quote-comparison', isPage: true },
                { label: 'Tools', href: '/tools', isPage: true },
                { label: 'Financing Calc', href: '/financing-calculator', isPage: true },
                { label: 'Instant Scheduler', href: '/instant-scheduler', isPage: true },
                { label: 'My Projects', href: '/customer-portal', isPage: true },
                { label: 'Deals & Promotions', href: '/promotions', isPage: true },
                { label: 'Free Estimate', href: '/estimate', isPage: true },
                { label: 'Contact', href: '#contact' },
              ].map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={(e) => {
                      if (link.isPage) {
                        e.preventDefault();
                        navigate(link.href);
                      } else {
                        handleNavClick(e, link.href);
                      }
                    }}
                    className="text-white/60 text-sm hover:text-orange transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Service Areas */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-[0.2em] mb-5">Service Areas</h4>
            <ul className="grid grid-cols-2 gap-x-6 gap-y-2.5">
              {[
                { label: 'Evansville, IN', path: '/' },
                { label: 'Newburgh, IN', path: '/locations/newburgh' },
                { label: 'Boonville, IN', path: '/locations/boonville' },
                { label: 'Mount Vernon, IN', path: '/locations/mount-vernon' },
                { label: 'Princeton, IN', path: '/locations/princeton' },
                { label: 'Jasper, IN', path: '/locations/jasper' },
                { label: 'Chandler, IN', path: '/locations/chandler' },
                { label: 'Tell City, IN', path: '/locations/tell-city' },
                { label: 'Rockport, IN', path: '/locations/rockport' },
                { label: 'Vincennes, IN', path: '/locations/vincennes' },
                { label: 'Washington, IN', path: '/locations/washington' },
                { label: 'New Harmony, IN', path: '/locations/new-harmony' },
                { label: 'Fort Branch, IN', path: '/locations/fort-branch' },
                { label: 'Oakland City, IN', path: '/locations/oakland-city' },
                { label: 'Haubstadt, IN', path: '/locations/haubstadt' },
                { label: 'Poseyville, IN', path: '/locations/poseyville' },
                { label: 'Darmstadt, IN', path: '/locations/darmstadt' },
                { label: 'Petersburg, IN', path: '/locations/petersburg' },
                { label: 'Elberfeld, IN', path: '/locations/elberfeld' },
                { label: 'Lynnville, IN', path: '/locations/lynnville' },
                { label: 'Owensville, IN', path: '/locations/owensville' },
                { label: 'Cynthiana, IN', path: '/locations/cynthiana' },
                { label: 'Dale, IN', path: '/locations/dale' },
                { label: 'Santa Claus, IN', path: '/locations/santa-claus' },
                { label: 'Ferdinand, IN', path: '/locations/ferdinand' },
                { label: 'Huntingburg, IN', path: '/locations/huntingburg' },
                { label: 'Henderson, KY', path: '/locations/henderson-ky' },
                { label: 'Owensboro, KY', path: '/locations/owensboro-ky' },
                { label: 'Madisonville, KY', path: '/locations/madisonville-ky' },
                { label: 'Greenville, KY', path: '/locations/greenville-ky' },
                { label: 'Morganfield, KY', path: '/locations/morganfield-ky' },
                { label: 'Sturgis, KY', path: '/locations/sturgis-ky' },
                { label: 'Providence, KY', path: '/locations/providence-ky' },
                { label: 'Sebree, KY', path: '/locations/sebree-ky' },
                { label: 'Calhoun, KY', path: '/locations/calhoun-ky' },
                { label: 'Livermore, KY', path: '/locations/livermore-ky' },
                { label: 'Beaver Dam, KY', path: '/locations/beaver-dam-ky' },
                { label: 'Hartford, KY', path: '/locations/hartford-ky' },
                { label: 'Central City, KY', path: '/locations/central-city-ky' },
                { label: 'Powderly, KY', path: '/locations/powderly-ky' },
                { label: 'Bremen, KY', path: '/locations/bremen-ky' },
                { label: 'Mount Carmel, IL', path: '/locations/mount-carmel-il' },
                { label: 'Grayville, IL', path: '/locations/grayville-il' },
                { label: 'Carmi, IL', path: '/locations/carmi-il' },
                { label: 'Lawrenceville, IL', path: '/locations/lawrenceville-il' },
                { label: 'Olney, IL', path: '/locations/olney-il' },
                { label: 'Fairfield, IL', path: '/locations/fairfield-il' },
              ].map((area) => (
                <li key={area.path}>
                  <a
                    href={area.path}
                    onClick={(e) => { e.preventDefault(); navigate(area.path); }}
                    className="text-white/60 text-sm hover:text-orange transition-colors"
                  >
                    {area.label}
                  </a>
                </li>
              ))}
            </ul>
            <a
              href="/service-areas"
              onClick={(e) => { e.preventDefault(); navigate('/service-areas'); }}
              className="inline-flex items-center gap-1.5 text-orange text-xs font-medium mt-5 hover:text-orange-dark transition-colors"
            >
              View full coverage map
              <i className="ri-arrow-right-line text-xs" />
            </a>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-white text-xs font-semibold uppercase tracking-[0.2em] mb-5">Newsletter</h4>
            <p className="text-white/60 text-sm mb-5 leading-relaxed">
              Get Indiana roofing tips, storm prep advice, and local offers.
            </p>
            {submitted ? (
              <p className="text-orange text-sm font-semibold">Thanks for subscribing!</p>
            ) : (
              <form
                data-readdy-form
                onSubmit={handleNewsletterSubmit}
                className="flex border border-white/20"
              >
                <input
                  type="email"
                  name="email"
                  placeholder="your@email.com"
                  required
                  className="flex-1 bg-transparent text-white text-sm py-3 px-4 focus:outline-none placeholder:text-white/50 min-w-0"
                />
                <button type="submit" className="px-4 text-white/60 hover:text-orange transition-colors cursor-pointer border-l border-white/20">
                  <i className="ri-arrow-right-line text-lg" />
                </button>
              </form>
            )}
            <div className="mt-6 space-y-3">
              <a href="tel:8122135997" className="flex items-center gap-2 text-white/60 text-sm hover:text-orange transition-colors">
                <i className="ri-phone-line text-orange text-xs" />
                812-213-5997
              </a>
              <a href="mailto:themainstoneconstruction@gmail.com" className="flex items-center gap-2 text-white/60 text-sm hover:text-orange transition-colors">
                <i className="ri-mail-line text-orange text-xs" />
                themainstoneconstruction@gmail.com
              </a>
              <GoogleReviewsBadge variant="inline" />
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10 px-6 md:px-10 lg:px-16 py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <p className="text-white/50 text-xs">
          &copy; {new Date().getFullYear()} Corner Stone Construction & Roofing. Evansville Indiana's trusted roofer.
        </p>
        <div className="flex items-center gap-4">
          <a href="/privacy-policy" onClick={(e) => { e.preventDefault(); navigate('/privacy-policy'); }} className="text-white/50 text-xs hover:text-orange transition-colors">Privacy Policy</a>
          <span className="text-white/40">|</span>
          <a href="/terms-of-service" onClick={(e) => { e.preventDefault(); navigate('/terms-of-service'); }} className="text-white/50 text-xs hover:text-orange transition-colors">Terms of Service</a>
        </div>
      </div>

      {/* Large brand type */}
      <div className="overflow-hidden pb-2">
        <p className="font-display text-white/5 leading-none tracking-tighter whitespace-nowrap select-none" style={{ fontSize: 'clamp(3rem, 8vw, 10rem)' }}>
          CORNER STONE
        </p>
      </div>
    </footer>
  );
}
