import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function StickyCTABar() {
  const [visible, setVisible] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setVisible(window.scrollY > window.innerHeight * 0.8);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleOpenAIChat = () => {
    const btn = document.querySelector('#vapi-widget-floating-button') as HTMLElement | null;
    if (btn) btn.click();
  };

  return (
    <div
      className={`fixed bottom-0 left-0 right-0 z-40 transition-all duration-500 ${visible ? 'translate-y-0 opacity-100' : 'translate-y-full opacity-0'}`}
    >
      <div className="bg-charcoal-deep/95 backdrop-blur-sm border-t border-white/10 px-3 md:px-8 py-2.5 flex flex-row items-center justify-between gap-2">
        {/* Logo + brand — always visible, smaller on mobile */}
        <div className="flex items-center gap-2.5 md:gap-3 shrink-0">
          <div className="flex items-center justify-center h-9 w-9 bg-white rounded-md">
            <img
              src="/logo.svg"
              alt="Corner Stone"
              className="h-7 w-7 object-contain rounded"
            />
          </div>
          <div className="hidden sm:flex flex-col leading-none">
            <span className="text-white text-xs font-semibold tracking-wide uppercase">Corner Stone</span>
            <span className="text-white/40 text-[0.55rem] tracking-wider uppercase">Call Now — We're Available</span>
          </div>
        </div>

        {/* Desktop center info */}
        <div className="hidden md:flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-white/50 text-xs uppercase tracking-widest">Available Now</span>
          </div>
          <p className="text-white text-sm font-semibold">
            Evansville's #1 Roofer Since 1995
          </p>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <button
            onClick={handleOpenAIChat}
            className="hidden sm:flex items-center gap-2 border border-orange/30 hover:border-orange text-orange hover:text-white text-xs font-semibold px-4 py-2.5 uppercase tracking-widest transition-all duration-200 whitespace-nowrap cursor-pointer"
          >
            <i className="ri-robot-2-line text-sm" />
            Ask AI
          </button>

          {/* Desktop contact row */}
          <div className="hidden lg:flex items-center gap-0 border border-white/20">
            <a
              href="mailto:themainstoneconstruction@gmail.com"
              className="flex items-center gap-1.5 text-white/60 hover:text-orange text-xs font-semibold px-3 py-2.5 uppercase tracking-widest transition-all duration-200 whitespace-nowrap"
              aria-label="Email Corner Stone Construction & Roofing"
            >
              <i className="ri-mail-line text-orange text-sm" />
              Email
            </a>
            <span className="text-white/10">|</span>
            <a
              href="tel:8122135997"
              className="flex items-center gap-1.5 text-white hover:text-orange text-xs font-bold px-3 py-2.5 uppercase tracking-widest transition-all duration-200 whitespace-nowrap"
            >
              <i className="ri-phone-fill text-orange text-sm" />
              812-213-5997
            </a>
          </div>

          {/* Mobile Call Now — big and bold */}
          <a
            href="tel:8122135997"
            className="sm:hidden flex items-center gap-2 bg-orange hover:bg-orange-dark text-white text-xs font-bold px-4 py-2.5 uppercase tracking-widest transition-colors duration-200 whitespace-nowrap rounded-md"
          >
            <i className="ri-phone-fill text-sm" />
            Call Now
          </a>

          {/* Tablet+ Call button */}
          <a
            href="tel:8122135997"
            className="hidden sm:inline-flex lg:hidden items-center gap-2 border border-white/20 hover:border-orange text-white/70 hover:text-white text-xs font-semibold px-4 py-2.5 uppercase tracking-widest transition-all duration-200 whitespace-nowrap"
          >
            <i className="ri-phone-fill text-orange text-sm" />
            812-213-5997
          </a>

          <button
            onClick={() => navigate('/estimate')}
            className="bg-white hover:bg-white/90 text-charcoal-deep text-xs font-bold px-4 md:px-5 py-2.5 uppercase tracking-widest transition-colors duration-200 whitespace-nowrap cursor-pointer rounded-md"
          >
            Free Est.
          </button>
        </div>
      </div>
    </div>
  );
}