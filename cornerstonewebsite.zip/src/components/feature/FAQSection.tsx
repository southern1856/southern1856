import { useState } from 'react';
import { faqs } from '@/mocks/faqs';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

export default function FAQSection() {
  const [openId, setOpenId] = useState<number | null>(1);
  const left = useScrollAnimation({ threshold: 0.1 });
  const right = useScrollAnimation({ threshold: 0.05 });

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section className="bg-charcoal-deep py-20 md:py-28 overflow-hidden">
      <div className="w-full px-6 md:px-10 lg:px-16">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-20">
          {/* Left sticky header */}
          <div
            ref={left.ref as React.RefObject<HTMLDivElement>}
            className={`w-full lg:w-80 flex-shrink-0 anim-fade-left ${left.isVisible ? 'is-visible' : ''}`}
          >
            <p className="text-orange text-xs uppercase tracking-[0.25em] font-semibold mb-5">FAQs</p>
            <h2 className="font-display text-white uppercase tracking-wider leading-none mb-6" style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
              Let's Climb Through Your Questions, One By One.
            </h2>
            <p className="text-white/60 text-sm leading-relaxed mb-8">
              Can't find your answer? Our Evansville roofing experts are standing by.
            </p>
            <a
              href="tel:8122135997"
              className="inline-flex items-center gap-3 border border-white/20 hover:border-orange px-6 py-4 text-white/70 hover:text-white text-sm uppercase tracking-widest transition-all duration-200"
            >
              <i className="ri-phone-line text-orange" />
              812-213-5997
            </a>
          </div>

          {/* Right accordion */}
          <div
            ref={right.ref as React.RefObject<HTMLDivElement>}
            className="flex-1"
            itemScope
            itemType="https://schema.org/FAQPage"
          >
            {faqs.map((faq, index) => (
              <div
                key={faq.id}
                itemScope
                itemProp="mainEntity"
                itemType="https://schema.org/Question"
                className={`border-b border-white/10 anim-fade-up ${right.isVisible ? 'is-visible' : ''}`}
                style={{ transitionDelay: `${index * 80}ms` }}
              >
                <button
                  onClick={() => setOpenId(openId === faq.id ? null : faq.id)}
                  className="w-full flex items-center justify-between py-6 md:py-7 text-left gap-6 cursor-pointer group"
                  aria-expanded={openId === faq.id}
                >
                  <div className="flex items-center gap-5">
                    <span className="font-display text-white/20 text-xl tracking-wider w-8 flex-shrink-0">
                      {String(index + 1).padStart(2, '0')}
                    </span>
                    <h3
                      itemProp="name"
                      className={`font-serif font-bold text-base md:text-lg transition-colors duration-200 ${openId === faq.id ? 'text-orange' : 'text-white group-hover:text-white/80'}`}
                    >
                      {faq.question}
                    </h3>
                  </div>
                  <div className={`w-8 h-8 flex-shrink-0 flex items-center justify-center border transition-all duration-300 ${openId === faq.id ? 'border-orange bg-orange text-white rotate-45' : 'border-white/20 text-white/40'}`}>
                    <i className="ri-add-line text-sm" />
                  </div>
                </button>

                <div
                  itemScope
                  itemProp="acceptedAnswer"
                  itemType="https://schema.org/Answer"
                  className={`overflow-hidden transition-all duration-500 ${openId === faq.id ? 'max-h-[800px] pb-6' : 'max-h-0'}`}
                >
                  <p
                    itemProp="text"
                    className="text-white/70 text-sm md:text-base leading-relaxed"
                    style={{ paddingLeft: '3.25rem' }}
                  >
                    {faq.answer}
                  </p>
                  {'link' in faq && faq.link && (
                    <a
                      href={faq.link.href}
                      onClick={(e) => handleLinkClick(e, faq.link!.href)}
                      className="inline-flex items-center gap-2 mt-4 text-orange hover:text-white text-sm font-semibold uppercase tracking-wider transition-colors cursor-pointer"
                      style={{ marginLeft: '3.25rem' }}
                    >
                      {faq.link.text}
                      <i className="ri-arrow-down-line" />
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
