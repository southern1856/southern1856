import { BrowserRouter, useLocation } from 'react-router-dom';
import { Suspense, useEffect } from 'react';
import { AppRoutes } from './router';
import Navbar from './components/feature/Navbar';
import Footer from './components/feature/Footer';
import BrandedSignatureBlock from './components/feature/BrandedSignatureBlock';
import BrandedLoadingSkeleton from './components/feature/BrandedLoadingSkeleton';
import Preloader from './components/feature/Preloader';
import BrandWatermark from './components/feature/BrandWatermark';
import FloatingCTA from './components/feature/FloatingCTA';
import StickyCTABar from './components/feature/StickyCTABar';
import LiveChatWidget from './components/feature/LiveChatWidget';
import ExitIntentPopup from './components/feature/ExitIntentPopup';
import GoogleReviewsWidget from './components/feature/GoogleReviewsWidget';
import CallbackWidget from './components/feature/CallbackWidget';
import SocialProofToast from './components/feature/SocialProofToast';
import UrgencyBanner from './components/feature/UrgencyBanner';
import InactivityModal from './components/feature/InactivityModal';
import LocalDemandBadge from './components/feature/LocalDemandBadge';
import ScrollTriggerOffer from './components/feature/ScrollTriggerOffer';
import TrustSealStrip from './components/feature/TrustSealStrip';
import WorkmanshipGuaranteeWidget from './components/feature/WorkmanshipGuaranteeWidget';
import ThirdPartyVerifyBanner from './components/feature/ThirdPartyVerifyBanner';
import ManufacturerCertBanner from './components/feature/ManufacturerCertBanner';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter basename={__BASE_PATH__}>
      <Preloader />
      <BrandWatermark />
      <ScrollToTop />
      <Navbar />
      <UrgencyBanner />
      <main>
        <Suspense fallback={<BrandedLoadingSkeleton />}>
          <AppRoutes />
        </Suspense>
      </main>
      <BrandedSignatureBlock />
      <Footer />
      <FloatingCTA />
      <StickyCTABar />
      <LiveChatWidget />
      <ExitIntentPopup />
      <GoogleReviewsWidget />
      <CallbackWidget />
      <SocialProofToast />
      <InactivityModal />
      <LocalDemandBadge />
      <ScrollTriggerOffer />
      <TrustSealStrip />
      <WorkmanshipGuaranteeWidget />
      <ThirdPartyVerifyBanner />
      <ManufacturerCertBanner />
    </BrowserRouter>
  );
}