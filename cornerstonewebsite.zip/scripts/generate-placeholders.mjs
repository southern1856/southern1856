// Generates branded placeholder SVGs to replace broken Readdy-hosted images.
// Run: node scripts/generate-placeholders.mjs
import { mkdirSync, writeFileSync, readdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const outDir = join(__dirname, '..', 'public', 'placeholders');
mkdirSync(outDir, { recursive: true });

const COLORS = {
  charcoal: '#1C1C1C',
  charcoalMid: '#242424',
  orange: '#E8622A',
  orangeLight: '#F07840',
  offWhite: '#F2EDE8',
};

function houseIcon(cx, cy, scale, color) {
  // simple roofline glyph, centered at (cx, cy)
  const w = 60 * scale;
  const h = 44 * scale;
  const x = cx - w / 2;
  const y = cy - h / 2;
  return `
    <g>
      <path d="M ${x} ${y + h * 0.55} L ${x + w / 2} ${y} L ${x + w} ${y + h * 0.55} L ${x + w} ${y + h} L ${x} ${y + h} Z"
            fill="none" stroke="${color}" stroke-width="${3 * scale}" stroke-linejoin="round" />
      <rect x="${x + w * 0.42}" y="${y + h * 0.6}" width="${w * 0.16}" height="${h * 0.4}" fill="${color}" />
    </g>`;
}

function makeSvg(width, height, { style = 'photo', label = '' } = {}) {
  const w = Number(width) || 800;
  const h = Number(height) || 600;
  const isTiny = w <= 120 || h <= 120;
  const scale = Math.max(0.6, Math.min(w, h) / 220);

  const bg = style === 'light'
    ? `<rect width="${w}" height="${h}" fill="${COLORS.offWhite}"/>`
    : `<rect width="${w}" height="${h}" fill="${COLORS.charcoal}"/>
       <rect width="${w}" height="${h}" fill="url(#g)"/>`;

  const iconColor = COLORS.orange;
  const icon = houseIcon(w / 2, isTiny ? h / 2 : h / 2 - (h * 0.06), scale, iconColor);

  const showText = !isTiny && w >= 260;
  const fontSize = Math.max(11, Math.min(18, w / 32));
  const text = showText
    ? `<text x="${w / 2}" y="${h / 2 + (h * 0.16)}" font-family="Arial, sans-serif" font-size="${fontSize}"
         fill="${style === 'light' ? COLORS.charcoal : COLORS.offWhite}" text-anchor="middle" opacity="0.85">PHOTO COMING SOON</text>`
    : '';

  const border = `<rect x="1.5" y="1.5" width="${w - 3}" height="${h - 3}" fill="none" stroke="${COLORS.orange}" stroke-width="3" opacity="0.55"/>`;

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="${COLORS.charcoalMid}" stop-opacity="0.4"/>
      <stop offset="1" stop-color="${COLORS.charcoal}" stop-opacity="0.9"/>
    </linearGradient>
  </defs>
  ${bg}
  ${icon}
  ${text}
  ${border}
</svg>`;
}

// Dimension pairs pulled from the readdy.ai search-image query strings in this project.
const dims = [
  [600,400],[1400,900],[700,400],[800,500],[900,600],[800,560],[900,520],[1600,900],
  [100,100],[400,300],[600,720],[40,40],[800,450],[600,380],[400,480],[400,400],
  [800,600],[700,460],[700,450],[900,500],[700,500],[1600,700],[1200,800],[1200,600],
  [700,520],[700,420],[600,500],[1400,700],[1400,500],[1200,900],[1200,500],[1200,400],
];

for (const [w, h] of dims) {
  const svg = makeSvg(w, h, { style: 'photo' });
  writeFileSync(join(outDir, `${w}x${h}.svg`), svg, 'utf8');
}

// A distinct square "logo" placeholder for the repeated static.readdy.ai brand mark.
writeFileSync(join(outDir, 'logo.svg'), makeSvg(200, 200, { style: 'light' }), 'utf8');

console.log(`Generated ${dims.length + 1} placeholder SVGs in ${outDir}`);
console.log(readdirSync(outDir).length, 'files total');
