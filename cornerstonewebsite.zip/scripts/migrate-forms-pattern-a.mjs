// Migrates the common `fetch(readdyUrl, { body: new URLSearchParams(VAR as CAST) })`
// pattern to Web3Forms, injecting the access_key into the payload.
import { readFileSync, writeFileSync, readdirSync, statSync } from 'node:fs';
import { join, extname, relative } from 'node:path';

const SRC = join(process.cwd(), 'src');

function walk(dir, files = []) {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    const st = statSync(full);
    if (st.isDirectory()) walk(full, files);
    else if (['.ts', '.tsx'].includes(extname(full))) files.push(full);
  }
  return files;
}

const IMPORT_LINE = `import { WEB3FORMS_ENDPOINT, WEB3FORMS_ACCESS_KEY } from '@/lib/web3forms';\n`;

let changedFiles = [];

for (const file of walk(SRC)) {
  let content = readFileSync(file, 'utf8');
  const original = content;

  const hadReaddyForm = /https:\/\/readdy\.ai\/api\/form\/[a-zA-Z0-9]+/.test(content);
  if (!hadReaddyForm) continue;

  // Replace URL string literals used directly in fetch() calls
  content = content.replace(
    /fetch\(\s*'https:\/\/readdy\.ai\/api\/form\/[a-zA-Z0-9]+'/g,
    `fetch(WEB3FORMS_ENDPOINT`
  );

  // Wrap `new URLSearchParams(VAR as CAST)` to inject access_key
  content = content.replace(
    /new URLSearchParams\((\w+)(\s+as\s+[^)]+)?\)/g,
    (m, varName, cast) => `new URLSearchParams({ ...${varName}, access_key: WEB3FORMS_ACCESS_KEY }${cast || ' as never'})`
  );

  if (content !== original) {
    if (!content.includes("from '@/lib/web3forms'")) {
      // insert import after the last existing import line
      const lines = content.split('\n');
      let lastImportIdx = -1;
      for (let i = 0; i < lines.length; i++) {
        if (/^import .+ from ['"].+['"];?$/.test(lines[i])) lastImportIdx = i;
      }
      if (lastImportIdx >= 0) {
        lines.splice(lastImportIdx + 1, 0, IMPORT_LINE.trimEnd());
        content = lines.join('\n');
      } else {
        content = IMPORT_LINE + content;
      }
    }
    writeFileSync(file, content, 'utf8');
    changedFiles.push(relative(process.cwd(), file));
  }
}

console.log(`Pattern A migrated in ${changedFiles.length} files:`);
changedFiles.forEach(f => console.log(' -', f));
