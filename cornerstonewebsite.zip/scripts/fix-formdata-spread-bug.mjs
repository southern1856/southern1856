// Fixes a bug from the earlier form migration: spreading a real browser
// FormData instance with {...formData} silently drops all its fields
// (FormData isn't a plain enumerable object). Fix: append access_key to
// the FormData instance directly, then pass it straight to URLSearchParams.
import { readFileSync, writeFileSync, readdirSync, statSync } from 'node:fs';
import { join, extname, relative } from 'node:path';

const SRC = join(process.cwd(), 'src');

function walk(dir, files = []) {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    const st = statSync(full);
    if (st.isDirectory()) walk(full, files);
    else if (['.ts', '.tsx'].includes(extname(full))) files.push(full);
  }
  return files;
}

let changed = [];

for (const file of walk(SRC)) {
  let content = readFileSync(file, 'utf8');
  const original = content;

  // Only touch files where the spread var is a real FormData instance.
  if (!/const formData = new FormData\(/.test(content)) continue;
  if (!/\{\s*\.\.\.formData,\s*access_key:\s*WEB3FORMS_ACCESS_KEY\s*\}/.test(content)) continue;

  // Insert formData.append('access_key', ...) right after its declaration.
  content = content.replace(
    /(const formData = new FormData\([^)]*\);)/,
    `$1\n    formData.append('access_key', WEB3FORMS_ACCESS_KEY);`
  );

  // Un-spread: pass formData straight through instead of a broken spread copy.
  content = content.replace(
    /new URLSearchParams\(\{\s*\.\.\.formData,\s*access_key:\s*WEB3FORMS_ACCESS_KEY\s*\}(\s+as\s+[^)]+)?\)/g,
    (m, cast) => `new URLSearchParams(formData${cast || ' as never'})`
  );

  if (content !== original) {
    writeFileSync(file, content, 'utf8');
    changed.push(relative(process.cwd(), file));
  }
}

console.log(`Fixed ${changed.length} files:`);
changed.forEach(f => console.log(' -', f));
