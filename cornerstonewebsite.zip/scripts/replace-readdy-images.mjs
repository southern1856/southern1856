// Replaces all readdy.ai / static.readdy.ai image URLs in source with local
// branded placeholder SVGs (see generate-placeholders.mjs), so the site
// doesn't depend on Readdy's live image API once it's running outside Readdy.
import { readFileSync, writeFileSync, readdirSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';

const SRC = join(process.cwd(), 'src');
const LOGO_ID = '1254e00daca40ebca216e2f97f6d62f6';

function walk(dir, files = []) {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    const st = statSync(full);
    if (st.isDirectory()) walk(full, files);
    else if (['.ts', '.tsx'].includes(extname(full))) files.push(full);
  }
  return files;
}

function replaceSearchImage(content) {
  return content.replace(
    /https:\/\/readdy\.ai\/api\/search-image\?[^"'`]*/g,
    (match) => {
      const w = match.match(/width=(\d+)/)?.[1] ?? '800';
      const h = match.match(/height=(\d+)/)?.[1] ?? '600';
      return `/placeholders/${w}x${h}.svg`;
    }
  );
}

function replaceStatic(content) {
  return content.replace(
    /https:\/\/static\.readdy\.ai\/image\/[a-zA-Z0-9]+\/([a-zA-Z0-9]+)\.jpeg/g,
    (match, id) => (id === LOGO_ID ? '/placeholders/logo.svg' : '/placeholders/800x600.svg')
  );
}

let filesChanged = 0;
let totalReplacements = 0;

for (const file of walk(SRC)) {
  const original = readFileSync(file, 'utf8');
  let updated = replaceSearchImage(original);
  updated = replaceStatic(updated);
  if (updated !== original) {
    const before = (original.match(/readdy\.ai/g) || []).length;
    const after = (updated.match(/readdy\.ai/g) || []).length;
    totalReplacements += before - after;
    writeFileSync(file, updated, 'utf8');
    filesChanged++;
  }
}

console.log(`Updated ${filesChanged} files, replaced ${totalReplacements} readdy.ai references.`);
