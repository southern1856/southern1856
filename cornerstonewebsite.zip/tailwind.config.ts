/** @type {import('tailwindcss').Config} */
export default {
    content: [
      "./index.html",
      "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
      extend: {
        colors: {
          charcoal: '#1C1C1C',
          'charcoal-deep': '#111111',
          'charcoal-mid': '#242424',
          'charcoal-light': '#2E2E2E',
          'warm-beige': '#F5F1ED',
          'warm-cream': '#FAF8F5',
          orange: '#E8622A',
          'orange-dark': '#C94E1A',
          'orange-light': '#F07840',
          'off-white': '#F2EDE8',
        },
        fontFamily: {
          sans: ['"DM Sans"', 'system-ui', 'sans-serif'],
          display: ['"Bebas Neue"', 'Impact', 'sans-serif'],
          serif: ['"Playfair Display"', 'Georgia', 'serif'],
        },
      },
    },
    plugins: [],
  }