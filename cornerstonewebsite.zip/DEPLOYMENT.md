# Deployment Guide - Corner Stone Construction & Roofing

## Quick Start: Deploy in 3 Minutes

### Option 1: Vercel (Recommended)
Vercel is purpose-built for React/Vite apps with automatic deployments on every push.

1. **Push to GitHub** (when git server is accessible)
   ```bash
   git push -u origin claude/project-ready-status-7x6drd
   ```

2. **Go to [vercel.com](https://vercel.com)**
   - Click "New Project"
   - Select your GitHub repository
   - Vercel auto-detects Vite config
   - Click Deploy

3. **Set Environment Variables** (in Vercel dashboard)
   - `VITE_PUBLIC_SUPABASE_URL`: `https://ytfmdvmrlrysblkljkoi.supabase.co`
   - `VITE_PUBLIC_SUPABASE_ANON_KEY`: `sb_publishable__pTLRlFSTgrGBaeIPa2BOA_ROE0IYkj`

4. **Your site is live!** 🎉
   - Vercel provides a `.vercel.app` domain immediately
   - Connect your custom domain: `cornerstoneconstructionevansville.com`

---

### Option 2: Netlify
Similar to Vercel with excellent React support.

1. **Go to [netlify.com](https://netlify.com)**
   - Click "Add new site" → "Import an existing project"
   - Connect GitHub
   - Build command: `npm run build`
   - Publish directory: `out`

2. **Set Environment Variables** (same as Vercel above)

3. **Deploy!**

---

### Option 3: GitHub Pages (Free)
Works but requires more manual setup.

```bash
npm run build
# Upload contents of 'out' folder to GitHub Pages
```

---

## Environment Variables Needed

All services need these two variables:
- `VITE_PUBLIC_SUPABASE_URL` = `https://ytfmdvmrlrysblkljkoi.supabase.co`
- `VITE_PUBLIC_SUPABASE_ANON_KEY` = `sb_publishable__pTLRlFSTgrGBaeIPa2BOA_ROE0IYkj`

These are public keys (safe to commit), but keep your Supabase Service Role Key secret.

---

## Custom Domain Setup

After deployment:

1. **Update domain DNS** to point to your hosting provider:
   - **Vercel**: Use nameservers or CNAME record
   - **Netlify**: Use nameservers or CNAME record
   - Instructions provided in each platform's dashboard

2. **Update BASE_URL** in code (if needed)
   - Edit `src/components/feature/PageSEO.tsx`
   - Change `BASE_URL = 'https://cornerstoneconstructionevansville.com'`

3. **SSL Certificate** - Automatic! Both Vercel and Netlify provision free SSL.

---

## Build & Test Locally

```bash
# Install dependencies
npm install

# Development server (http://localhost:3000)
npm run dev

# Production build
npm run build

# Preview production build locally
npm preview
```

Output folder: `out/`

---

## What's Deployed

✓ Full React website with routing  
✓ AI chatbot (Supabase Edge Functions)  
✓ Form tracking (Web3Forms + Supabase)  
✓ Tool usage analytics  
✓ SEO optimization  
✓ Social media sharing cards  
✓ Responsive design (mobile-first)  

---

## Troubleshooting

### Build fails with "env variable not found"
- Ensure environment variables are set in your host's dashboard
- Vercel/Netlify need explicit setup; they don't read `.env` files

### Blank page after deploy
- Check browser console for errors
- Verify `VITE_PUBLIC_*` variables are set
- Check that Supabase URL is accessible from your domain

### Forms not submitting
- Ensure Web3Forms access key is correct in `src/lib/web3forms.ts`
- Check network tab for failed requests

---

## Next Steps

1. **Connect to Vercel/Netlify** → Site is live
2. **Add custom domain** → `cornerstoneconstructionevansville.com`
3. **Replace placeholder images** → Add your actual roofing photos
4. **Replace social logo** → Upload actual PNG to `public/logo-social.png`
5. **Enable analytics** → Set up Google Analytics/Mixpanel

---

## Support
Need help? Check the platform docs:
- Vercel: https://vercel.com/docs
- Netlify: https://docs.netlify.com
